package com.lenovo.bi.dto;

public class TTVOutlookCause {
	private int healthValue;
	private int currentValue;
	private int gap;
	private String causeKey;  //TODO: may use enum
	public int getHealthValue() {
		return healthValue;
	}
	public void setHealthValue(int healthValue) {
		this.healthValue = healthValue;
	}
	public int getCurrentValue() {
		return currentValue;
	}
	public void setCurrentValue(int currentValue) {
		this.currentValue = currentValue;
	}
	public int getGap() {
		return gap;
	}
	public void setGap(int gap) {
		this.gap = gap;
	}
	public String getCauseKey() {
		return causeKey;
	}
	public void setCauseKey(String causeKey) {
		this.causeKey = causeKey;
	}
	
	
}
