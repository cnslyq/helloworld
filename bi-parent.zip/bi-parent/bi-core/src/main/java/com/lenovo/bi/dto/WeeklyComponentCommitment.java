package com.lenovo.bi.dto;

public class WeeklyComponentCommitment {
	private Integer pmsWaveId;
	private Integer cvkey;
	private Integer commitment;
	public Integer getCvkey() {
		return cvkey;
	}
	public void setCvkey(Integer cvkey) {
		this.cvkey = cvkey;
	}
	public Integer getCommitment() {
		return commitment;
	}
	public void setCommitment(Integer commitment) {
		this.commitment = commitment;
	}
	public Integer getPmsWaveId() {
		return pmsWaveId;
	}
	public void setPmsWaveId(Integer pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}
	
}
