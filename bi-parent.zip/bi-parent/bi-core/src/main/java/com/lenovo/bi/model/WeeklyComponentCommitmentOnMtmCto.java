package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BI_WeeklyComponentCommitmentOnMTMCTO")
public class WeeklyComponentCommitmentOnMtmCto {
	@Id
	@GeneratedValue
	@Column
	private int weeklyComponentCommitmentOnMtmCtoId;
	
	@Column
	private String bomNumber;
	
	@Column
	private int globalCvKey;
	
	@Column
	private String geographyName;
	
	@Column
	private String odmName;
	
	@Column
	private boolean cto;
	
	@Column
	private int commitment;
	
	@Column
	private Date versionDate;
	
	@Column
	private Date targetDate;
	
	@Column
	private Date createdDate;
	
	@Column
	private Date lastModifiedDate;

	public int getWeeklyComponentCommitmentOnMtmCtoId() {
		return weeklyComponentCommitmentOnMtmCtoId;
	}

	public void setWeeklyComponentCommitmentOnMtmCtoId(
			int weeklyComponentCommitmentOnMtmCtoId) {
		this.weeklyComponentCommitmentOnMtmCtoId = weeklyComponentCommitmentOnMtmCtoId;
	}

	public String getBomNumber() {
		return bomNumber;
	}

	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}

	public int getGlobalCvKey() {
		return globalCvKey;
	}

	public void setGlobalCvKey(int globalCvKey) {
		this.globalCvKey = globalCvKey;
	}

	public String getGeographyName() {
		return geographyName;
	}

	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}

	public String getOdmName() {
		return odmName;
	}

	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}

	public boolean isCto() {
		return cto;
	}

	public void setCto(boolean cto) {
		this.cto = cto;
	}

	public int getCommitment() {
		return commitment;
	}

	public void setCommitment(int commitment) {
		this.commitment = commitment;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String toString() {
		return "WeeklyComponentCommitmentOnMtmCto [weeklyComponentCommitmentOnMtmCtoId="
				+ weeklyComponentCommitmentOnMtmCtoId
				+ ", bomNumber="
				+ bomNumber
				+ ", globalCvKey="
				+ globalCvKey
				+ ", cto="
				+ cto
				+ ", commitment="
				+ commitment
				+ ", versionDate="
				+ versionDate
				+ ", targetDate="
				+ targetDate
				+ ", createdDate="
				+ createdDate
				+ ", lastModifiedDate=" + lastModifiedDate + "]";
	}
	
	
}
