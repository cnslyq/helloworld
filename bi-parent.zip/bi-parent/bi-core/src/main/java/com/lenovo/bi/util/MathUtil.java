package com.lenovo.bi.util;

import java.util.List;

public class MathUtil {
	public static int min(int... numbers) {
		if (numbers.length < 1) {
			throw new IllegalArgumentException("No number is passed in.");
		}
		
		int smallest = numbers[0];

		for (int number : numbers) {
			smallest = Math.min(smallest, number);
		}
		
		return smallest;
	}
	
	public static int min(List<Integer> numbers) {
		if (numbers.isEmpty()) {
			throw new IllegalArgumentException("No number is passed in.");
		}
		
		int smallest = numbers.get(0);

		for (int number : numbers) {
			smallest = Math.min(smallest, number);
		}
		
		return smallest;
	}
}
