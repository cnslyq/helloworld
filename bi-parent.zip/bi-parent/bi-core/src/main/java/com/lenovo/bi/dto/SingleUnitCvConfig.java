package com.lenovo.bi.dto;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SingleUnitCvConfig {
	private Map<Integer, Integer> cvQuantityMap = new HashMap<Integer, Integer>();
	
	public void addCv(int cvKey, int quantity) {
		cvQuantityMap.put(cvKey, quantity);
	}
	
	public int getQuantity(int cvKey) {
		Integer quantity = cvQuantityMap.get(cvKey);
		if (quantity == null) {
			return 0;
		}
		else {
			return quantity; 
		}
	}
	
	public Set<Integer> getAllCvs() {
		return cvQuantityMap.keySet();
	}
}
