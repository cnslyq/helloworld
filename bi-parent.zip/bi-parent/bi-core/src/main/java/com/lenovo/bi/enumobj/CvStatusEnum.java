package com.lenovo.bi.enumobj;

public enum CvStatusEnum {
	HAVE_SHORTAGE, NO_SHORTAGE, TIMING_ISSUE;
}
