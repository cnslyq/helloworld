package com.lenovo.bi.dto;

public class PieDivider {
	private String level1Name;
	private int level1Num;
	private String level2Name;
	private int level2Num;

	public String getLevel2Name() {
		return level2Name;
	}

	public void setLevel2Name(String level2Name) {
		this.level2Name = level2Name;
	}

	public int getLevel2Num() {
		return level2Num;
	}

	public void setLevel2Num(int level2Num) {
		this.level2Num = level2Num;
	}

	public String getLevel1Name() {
		return level1Name;
	}

	public void setLevel1Name(String level1Name) {
		this.level1Name = level1Name;
	}

	public int getLevel1Num() {
		return level1Num;
	}

	public void setLevel1Num(int level1Num) {
		this.level1Num = level1Num;
	}

}
