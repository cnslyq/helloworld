package com.lenovo.bi.dto;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;


public class CtoCvConfig {
	private Map<Integer, Integer> cvQuantityMap = new HashMap<Integer, Integer>();
	
	private String productKey;
	private String bomNumber;  // BOM number can be null, depending on the usage
	private int numberOfUnits;
	private String geographyName;  // Geography name can be null, depending on the usage
	private String odmName; // ODM name can be null, depending on the usage

	public void addCv(int cvKey, int quantity) {
		cvQuantityMap.put(cvKey, quantity);
	}
	
	public int getQuantity(int cvKey) {
		Integer quantity = cvQuantityMap.get(cvKey);
		if (quantity == null) {
			return 0;
		}
		else {
			return quantity; 
		}
	}
	
	public Set<Integer> getAllCvs() {
		return cvQuantityMap.keySet();
	}
	
	public String getProductKey() {
		return productKey;
	}

	public void setProductKey(Integer productKey) {
		if(productKey != null){
			this.productKey = Integer.toString(productKey);
		}
	}

	public void setNumberOfUnits(int numberOfUnits) {
		this.numberOfUnits = numberOfUnits;
	}

	public int getNumberOfUnits() {
		return numberOfUnits;
	}
	
	public String getBomNumber() {
		return bomNumber;
	}

	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}

	public String getGeographyName() {
		return geographyName;
	}

	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}

	public String getOdmName() {
		return odmName;
	}

	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}

	/**
	 * Return the max number of units of the MTM current CTO CV configuration can fulfill.  The max number
	 * does not exceed the number of units in the MTM configuration, or the number of units in this CTO.
	 * @param mtmCvConfig
	 * @return
	 */
	public int calculateMaxMtmNumberOfUnits(MtmCvConfig mtmCvConfig) {
		int min = Math.min(mtmCvConfig.getNumberOfUnits(), this.numberOfUnits);
		
		for (Integer cv : mtmCvConfig.getAllCvs()) {
			int available = getQuantity(cv) / mtmCvConfig.getSingleUnitQuantity(cv);
			min = Math.min(min, available);
		}
		
		return min;
	}
	
	/**
	 * Deduct the number of units and the corresponding CVs from the CTO CV configuration.  The max number of units that can
	 * be passed in should be calculated by <CODE>calculateMaxMtmNumberOfUnits()</CODE>. 
	 * @param singleUnitCvConfig
	 * @param numberOfUnits
	 * @exception IllegalArgumentException Thrown if the CTO cannot meet the quantity requirement. 
	 */
	public void deductMtmUnits(SingleUnitCvConfig singleUnitCvConfig, int numberOfUnits) {
		MtmCvConfig mtmCvConfig = new MtmCvConfig(singleUnitCvConfig, numberOfUnits);
		
		if (numberOfUnits > calculateMaxMtmNumberOfUnits(mtmCvConfig)) {
			throw new IllegalArgumentException("The number of MTM units cannot be covered by current CTO with BOM Number: "
					+ this.bomNumber);
		}
		
		this.numberOfUnits -= numberOfUnits;
		if(singleUnitCvConfig != null && CollectionUtils.isNotEmpty(singleUnitCvConfig.getAllCvs())){
			for (Integer cvKey : singleUnitCvConfig.getAllCvs()) {
				reduceCvQuantity(cvKey, mtmCvConfig.getQuantity(cvKey));
			}
		}
	}
	
	private void reduceCvQuantity(int cvKey, int quantity) {
		cvQuantityMap.put(cvKey, cvQuantityMap.get(cvKey) - quantity);
	}
}
