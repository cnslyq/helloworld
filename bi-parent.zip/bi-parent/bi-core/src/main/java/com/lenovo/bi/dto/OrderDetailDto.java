package com.lenovo.bi.dto;

import java.text.SimpleDateFormat;
import java.util.Date;

public class OrderDetailDto {

	private Date versionDate;
	private Date targetDate;
	private Date rsdDate;
	private Date orderDate;
	private int productKey;
	private int waveKey;
	private int mtmKey;
	private String bomNumber;
	private int quantity;
	private int regionKey;
	private String geographyName;
	private int odmKey;
	private String odmName;
	private String poItem;
	private String poNumber;
	
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	public Date getVersionDate() {
		return versionDate;
	}
	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}
	public Date getRsdDate() {
		return rsdDate;
	}
	public void setRsdDate(Date rsdDate) {
		this.rsdDate = rsdDate;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public int getProductKey() {
		return productKey;
	}
	public void setProductKey(int productKey) {
		this.productKey = productKey;
	}
	public int getWaveKey() {
		return waveKey;
	}
	public void setWaveKey(int waveKey) {
		this.waveKey = waveKey;
	}
	public int getMtmKey() {
		return mtmKey;
	}
	public void setMtmKey(int mtmKey) {
		this.mtmKey = mtmKey;
	}
	public String getBomNumber() {
		return bomNumber;
	}
	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getRegionKey() {
		return regionKey;
	}
	public void setRegionKey(int regionKey) {
		this.regionKey = regionKey;
	}
	public int getOdmKey() {
		return odmKey;
	}
	public void setOdmKey(int odmKey) {
		this.odmKey = odmKey;
	}
	public String getGeographyName() {
		return geographyName;
	}
	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}
	public String getOdmName() {
		return odmName;
	}
	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}
	public String getPoItem() {
		return poItem;
	}
	public void setPoItem(String poItem) {
		this.poItem = poItem;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	
	public String toString(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		return sdf.format(versionDate) + "\t" + sdf.format(targetDate) + "\t" + sdf.format(rsdDate) + "\t" + sdf.format(orderDate) + "\t" + 
				productKey + "\t" + waveKey + "\t" + mtmKey + "\t" + quantity + "\t" + regionKey + "\t" + odmKey;
	}
	
}
