package com.lenovo.bi.enumobj;

public enum NPISimulationType {
	Public,Private;
}
