package com.lenovo.bi.enumobj;

public enum FailProductType {
	All,
	DOI_Not_Ready,
	Gating_Defects;
	
	@Override
	public String toString() {
		return name().replaceAll("_", " ");
	}
	
}
