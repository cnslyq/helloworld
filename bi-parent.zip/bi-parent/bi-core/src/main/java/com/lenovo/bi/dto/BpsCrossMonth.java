package com.lenovo.bi.dto;

public class BpsCrossMonth {
	private int rowValue;
	private String rowName;
	private float unshippedOrder;
	private float bpsOrder;
	private float bpsRate;
	private String bpsTarget;
	private String yearMonthDay;
	private String type;
	
	public int getRowValue() {
		return rowValue;
	}
	public void setRowValue(int rowValue) {
		this.rowValue = rowValue;
	}
	public String getRowName() {
		return rowName;
	}
	public void setRowName(String rowName) {
		this.rowName = rowName;
	}
	public float getUnshippedOrder() {
		return unshippedOrder;
	}
	public void setUnshippedOrder(float unshippedOrder) {
		this.unshippedOrder = unshippedOrder;
	}
	public float getBpsOrder() {
		return bpsOrder;
	}
	public void setBpsOrder(float bpsOrder) {
		this.bpsOrder = bpsOrder;
	}
	public float getBpsRate() {
		return bpsRate;
	}
	public void setBpsRate(float bpsRate) {
		this.bpsRate = bpsRate;
	}
	public String getBpsTarget() {
		return bpsTarget;
	}
	public void setBpsTarget(String bpsTarget) {
		this.bpsTarget = bpsTarget;
	}
	public String getYearMonthDay() {
		return yearMonthDay;
	}
	public void setYearMonthDay(String yearMonthDay) {
		this.yearMonthDay = yearMonthDay;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
