package com.lenovo.bi.dto;

import java.util.Date;

/**
 * 
 * 
 * @author Henry_Lian
 * 
 */
public class TTMProduct {

	private int waveId;
	private String productName;
	private String waveName;
	private String ttmStatus;
	private String doi;
	private String defects;
	private String fpy;
	private String odm;
	private String tooling;
	private String currentPhase;
	private String pm;
	private String pmMail;
	private Date startDate;

	private Date ttmTargetDate;

	private Date ttmSignOffDate;

	private boolean isRisk;

	private Integer successDelays;

	private int projectId;

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public Integer getSuccessDelays() {
		return successDelays;
	}

	public void setSuccessDelays(Integer successDelays) {
		this.successDelays = successDelays;
	}

	public boolean isRisk() {
		return isRisk;
	}

	public void setRisk(boolean isRisk) {
		this.isRisk = isRisk;
	}

	public Date getTtmTargetDate() {
		return ttmTargetDate;
	}

	public void setTtmTargetDate(Date ttmTargetDate) {
		this.ttmTargetDate = ttmTargetDate;
	}

	public Date getTtmSignOffDate() {
		return ttmSignOffDate;
	}

	public void setTtmSignOffDate(Date ttmSignOffDate) {
		this.ttmSignOffDate = ttmSignOffDate;
	}

	public int getNpiWaveId() {
		return waveId;
	}

	public void setNpiWaveId(int npiWaveId) {
		this.waveId = npiWaveId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getWaveName() {
		return waveName;
	}

	public void setWaveName(String waveName) {
		this.waveName = waveName;
	}

	public String getTtmStatus() {
		return ttmStatus;
	}

	public void setTtmStatus(String ttmStatus) {
		this.ttmStatus = ttmStatus;
	}

	public String getDoi() {
		return doi;
	}

	public void setDoi(String doi) {
		this.doi = doi;
	}

	public String getDefects() {
		return defects;
	}

	public void setDefects(String defects) {
		this.defects = defects;
	}

	public String getFpy() {
		return fpy;
	}

	public void setFpy(String fpy) {
		this.fpy = fpy;
	}

	public String getOdm() {
		return odm;
	}

	public void setOdm(String odm) {
		this.odm = odm;
	}

	public String getTooling() {
		return tooling;
	}

	public void setTooling(String tooling) {
		this.tooling = tooling;
	}

	public String getCurrentPhase() {
		return currentPhase;
	}

	public void setCurrentPhase(String currentPhase) {
		this.currentPhase = currentPhase;
	}

	public String getPm() {
		return pm;
	}

	public void setPm(String pm) {
		this.pm = pm;
	}

	public String getPmMail() {
		return pmMail;
	}

	public void setPmMail(String pmMail) {
		this.pmMail = pmMail;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public TTMProduct(int waveId, String productName, String waveName, String ttmStatus, String doi, String defects, String fpy, String odm, String tooling,
			Date ttmTargetDate, Date ttmSignOffDate, boolean isRisk, Integer successDelays, int projectId, String currentPhase, String pm, Date startDate) {
		super();
		this.waveId = waveId;
		this.productName = productName;
		this.waveName = waveName;
		this.ttmStatus = ttmStatus;
		this.doi = doi;
		this.defects = defects;
		this.fpy = fpy;
		this.odm = odm;
		this.tooling = tooling;
		this.ttmTargetDate = ttmTargetDate;
		this.ttmSignOffDate = ttmSignOffDate;
		this.isRisk = isRisk;
		this.successDelays = successDelays;
		this.projectId = projectId;
		this.currentPhase = currentPhase;
		this.pm = pm;
		this.startDate = startDate;
	}
}
