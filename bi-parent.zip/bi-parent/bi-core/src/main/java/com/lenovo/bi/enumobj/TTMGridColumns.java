package com.lenovo.bi.enumobj;

public enum TTMGridColumns {
	
	Product("ProductName"),
	Status("TTM_Status"),
	Risk("TTMRisk"),
	DelayDays("TTMSuccessDelay"),
	DOI("DOI"),
	GatingDefects("GatingDefects"),
	FPY("FPY"),
	ODM("ODM"),
	Tooling("Tooling"),
	TTMTargetDate("TTMTargetDate"),
	TTMSignOff("TTMSignOffDate"),
	CurrentPhase("CurrentPhase"),
	PM("pm"),
	StartDate("StartDate"),
	TtmTargetDate("TTMTargetDate"),
	C("C"),
	PurchaseType("PurchaseType");
	
	private String dbColumnName;

	TTMGridColumns(String dbColumnName){
		this.dbColumnName = dbColumnName;
	}

	public String getDbColumnName() {
		return dbColumnName;
	}

	public void setDbColumnName(String dbColumnName) {
		this.dbColumnName = dbColumnName;
	}
	
}
