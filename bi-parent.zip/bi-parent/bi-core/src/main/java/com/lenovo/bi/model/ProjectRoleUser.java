package com.lenovo.bi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * 
 * 
 * @author henry_lian
 *
 */
@Entity
@Table(name="V_PMS_Project_Role_User")
public class ProjectRoleUser {
	@Id
	@Column(name="id")
	private int id;
	@OneToOne
	@JoinColumn(name="UserId", referencedColumnName="UserId")
	private User user;
	@OneToOne
	@JoinColumn(name = "RoleId")  
	private PMSRole pmsRole;
	@Column(name="ProjectId")
	private int projectId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public PMSRole getPmsRole() {
		return pmsRole;
	}
	public void setPmsRole(PMSRole pmsRole) {
		this.pmsRole = pmsRole;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
}
