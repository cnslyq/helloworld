package com.lenovo.bi.enumobj;

public enum DateEnum {

	SS_Plan_Date("TTM Target Date",""),
	SS_Actual_Date("TTM Signoff Date",""),
	SGA_Plan_Date("TTV Target Date",""),
	SGA_Actual_Date("TTV Signoff Date",""),
	SVT("SVT",""),
	SOVP("SOVP","")
	;
	
	private String typeName;
	private String value;
	
	private DateEnum(String typeName,String value) {
		this.typeName = typeName;
		this.value = value;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
