package com.lenovo.bi.model;

import java.text.ParseException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.lenovo.bi.enumobj.ForecastComparisonTypeEnum;
import com.lenovo.bi.util.CalendarUtil;

@Entity
@Table(name = "BI_OrderData")
public class OrderData {
	@Id
	@GeneratedValue
	private int orderDataId;

	@Column
	private String bomNumber;

	@Column
	private String poNumber;

	@Column
	private String poItem;

	@Enumerated(EnumType.STRING)
	@Column
	private ForecastComparisonTypeEnum orderLabel;

	@Column
	private int quantity;

	@Column
	private int normalQuantity;

	@Column
	private int abnormalQuantity;

	@Column
	private int materialShortage;

	@Column
	private int materialCommit;

	@Column
	private int coverAShortage;

	@Column
	private int coverACommit;

	@Column
	private int coverBShortage;

	@Column
	private int coverBCommit;

	@Column
	private int coverCShortage;

	@Column
	private int coverCCommit;

	@Column
	private int coverDShortage;

	@Column
	private int coverDCommit;

	@Column
	private int odmShortage;

	@Column
	private int odmCommit;

	@Column
	private int tdmsOdmShortage;

	@Column
	private int tdmsOdmCommit;

	@Column
	private String geographyName;

	@Column
	private String odmName;

	@Column
	private boolean forNpi;

	@Column
	private String productKey;

	@Column
	private Date versionDate;

	@Column
	private Date createdDate;

	@Column
	private Date lastModifiedDate;

	@Column
	private Date orderDate;

	@Column
	private Date rsdDate;

	@Column
	private Date shipDate;

	@Column
	private Date fgDate;

	@Column
	private String ttvPhase;

	@Transient
	private String pmsWaveId;

	public String getTtvPhase() {
		return ttvPhase;
	}

	public void setTtvPhase(String ttvPhase) {
		this.ttvPhase = ttvPhase;
	}

	public int getOrderDataId() {
		return orderDataId;
	}

	public void setOrderDataId(int orderDataId) {
		this.orderDataId = orderDataId;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoItem() {
		return poItem;
	}

	public void setPoItem(String poItem) {
		this.poItem = poItem;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getBomNumber() {
		return bomNumber;
	}

	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}

	public ForecastComparisonTypeEnum getOrderLabel() {
		return orderLabel;
	}

	public void setOrderLabel(ForecastComparisonTypeEnum orderLabel) {
		this.orderLabel = orderLabel;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getNormalQuantity() {
		return normalQuantity;
	}

	public void setNormalQuantity(int normalQuantity) {
		this.normalQuantity = normalQuantity;
	}

	public int getAbnormalQuantity() {
		return abnormalQuantity;
	}

	public void setAbnormalQuantity(int abnormalQuantity) {
		this.abnormalQuantity = abnormalQuantity;
	}

	public int getMaterialShortage() {
		return materialShortage;
	}

	public void setMaterialShortage(int materialShortage) {
		this.materialShortage = materialShortage;
	}

	public int getMaterialCommit() {
		return materialCommit;
	}

	public void setMaterialCommit(int materialCommit) {
		this.materialCommit = materialCommit;
	}

	public int getCoverAShortage() {
		return coverAShortage;
	}

	public void setCoverAShortage(int coverAShortage) {
		this.coverAShortage = coverAShortage;
	}

	public int getCoverACommit() {
		return coverACommit;
	}

	public void setCoverACommit(int coverACommit) {
		this.coverACommit = coverACommit;
	}

	public int getCoverBShortage() {
		return coverBShortage;
	}

	public void setCoverBShortage(int coverBShortage) {
		this.coverBShortage = coverBShortage;
	}

	public int getCoverBCommit() {
		return coverBCommit;
	}

	public void setCoverBCommit(int coverBCommit) {
		this.coverBCommit = coverBCommit;
	}

	public int getCoverCShortage() {
		return coverCShortage;
	}

	public void setCoverCShortage(int coverCShortage) {
		this.coverCShortage = coverCShortage;
	}

	public int getCoverCCommit() {
		return coverCCommit;
	}

	public void setCoverCCommit(int coverCCommit) {
		this.coverCCommit = coverCCommit;
	}

	public int getCoverDShortage() {
		return coverDShortage;
	}

	public void setCoverDShortage(int coverDShortage) {
		this.coverDShortage = coverDShortage;
	}

	public int getCoverDCommit() {
		return coverDCommit;
	}

	public void setCoverDCommit(int coverDCommit) {
		this.coverDCommit = coverDCommit;
	}

	public int getOdmShortage() {
		return odmShortage;
	}

	public void setOdmShortage(int odmShortage) {
		this.odmShortage = odmShortage;
	}

	public int getOdmCommit() {
		return odmCommit;
	}

	public void setOdmCommit(int odmCommit) {
		this.odmCommit = odmCommit;
	}

	public int getTdmsOdmShortage() {
		return tdmsOdmShortage;
	}

	public void setTdmsOdmShortage(int tdmsOdmShortage) {
		this.tdmsOdmShortage = tdmsOdmShortage;
	}

	public int getTdmsOdmCommit() {
		return tdmsOdmCommit;
	}

	public void setTdmsOdmCommit(int tdmsOdmCommit) {
		this.tdmsOdmCommit = tdmsOdmCommit;
	}

	public boolean isForNpi() {
		return forNpi;
	}

	public void setForNpi(boolean forNpi) {
		this.forNpi = forNpi;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getGeographyName() {
		return geographyName;
	}

	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}

	public String getOdmName() {
		return odmName;
	}

	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}

	public String getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(String pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public String getProductKey() {
		return productKey;
	}

	public void setProductKey(Integer productKey) {
		this.productKey = Integer.toString(productKey);
	}

	public String getUniqueIdentifier() {
		try {
			return poNumber + "|" + poItem + "|" + bomNumber + "|" + CalendarUtil.date2String(orderDate) + "|" + CalendarUtil.date2String(rsdDate) + "|"
					+ String.valueOf(quantity) + "|" + geographyName;
		} catch (ParseException e) {
		}
		return null;
	}

	public Date getRsdDate() {
		return rsdDate;
	}

	public void setRsdDate(Date rsdDate) {
		this.rsdDate = rsdDate;
	}

	public Date getShipDate() {
		return shipDate;
	}

	public void setShipDate(Date shipDate) {
		this.shipDate = shipDate;
	}

	public Date getFgDate() {
		return fgDate;
	}

	public void setFgDate(Date fgDate) {
		this.fgDate = fgDate;
	}

	public void setProductKey(String productKey) {
		this.productKey = productKey;
	}

	@Override
	public String toString() {
		return "OrderData [orderDataId=" + orderDataId + ", bomNumber=" + bomNumber + ", poNumber=" + poNumber + ", poItem=" + poItem + ", orderLabel="
				+ orderLabel + ", quantity=" + quantity + ", normalQuantity=" + normalQuantity + ", abnormalQuantity=" + abnormalQuantity
				+ ", materialShortage=" + materialShortage + ", materialCommit=" + materialCommit + ", coverAShortage=" + coverAShortage + ", coverACommit="
				+ coverACommit + ", coverBShortage=" + coverBShortage + ", coverBCommit=" + coverBCommit + ", coverCShortage=" + coverCShortage
				+ ", coverCCommit=" + coverCCommit + ", coverDShortage=" + coverDShortage + ", coverDCommit=" + coverDCommit + ", odmShortage=" + odmShortage
				+ ", odmCommit=" + odmCommit + ", tdmsOdmShortage=" + tdmsOdmShortage + ", tdmsOdmCommit=" + tdmsOdmCommit + ", forNpi=" + forNpi
				+ ", versionDate=" + versionDate + ", createdDate=" + createdDate + ", lastModifiedDate=" + lastModifiedDate + ", orderDate=" + orderDate
				+ ", geographyName=" + geographyName + ", odmName=" + odmName + ", pmsWaveId=" + pmsWaveId + ", productKey=" + productKey + "]";
	}

}
