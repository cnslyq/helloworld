package com.lenovo.bi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DimDetractor")
public class DimDetractor {
	@Id
	@Column(name="detractorKey")
	private Integer detractorKey;
	@Column(name="level1")
	private String level1;
	@Column(name="level2")
	private String level2;
	@Column(name="isCurrent")
	private Boolean isCurrent;
	public Integer getDetractorKey() {
		return detractorKey;
	}
	public void setDetractorKey(Integer detractorKey) {
		this.detractorKey = detractorKey;
	}
	public String getLevel1() {
		return level1;
	}
	public void setLevel1(String level1) {
		this.level1 = level1;
	}
	public String getLevel2() {
		return level2;
	}
	public void setLevel2(String level2) {
		this.level2 = level2;
	}
	public Boolean getIsCurrent() {
		return isCurrent;
	}
	public void setIsCurrent(Boolean isCurrent) {
		this.isCurrent = isCurrent;
	} 
}
