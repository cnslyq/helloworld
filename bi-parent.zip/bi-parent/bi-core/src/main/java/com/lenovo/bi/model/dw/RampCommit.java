package com.lenovo.bi.model.dw;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "FactRampCommit")
public class RampCommit {
	@Id
	@GeneratedValue
	private int id;

	@Column
	private int pMSRampIDAlternateKey;

	@Column
	private int nPIWaveKey;

	@Column
	private int targetDateKey;

	@Column
	private int quantity;

	@Column
	private Date createdDate;

	@Column
	private Date lastModifiedDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getpMSRampIDAlternateKey() {
		return pMSRampIDAlternateKey;
	}

	public void setpMSRampIDAlternateKey(int pMSRampIDAlternateKey) {
		this.pMSRampIDAlternateKey = pMSRampIDAlternateKey;
	}

	public int getnPIWaveKey() {
		return nPIWaveKey;
	}

	public void setnPIWaveKey(int nPIWaveKey) {
		this.nPIWaveKey = nPIWaveKey;
	}

	public int getTargetDateKey() {
		return targetDateKey;
	}

	public void setTargetDateKey(int targetDateKey) {
		this.targetDateKey = targetDateKey;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

}
