package com.lenovo.bi.util;

import java.math.BigDecimal;
import java.util.Comparator;

import com.lenovo.bi.dto.sc.CARemarkChartData;

public class CARemarkChartDataComparator implements Comparator {

	@Override
	public int compare(Object obj1, Object obj2) {
		CARemarkChartData caRemarkChartData1 = (CARemarkChartData) obj1;
		CARemarkChartData caRemarkChartData2 = (CARemarkChartData) obj2;

		int flag = 0;
		/*if("Region".equals(caRemarkChartData1.getRemarkType()) && "Region".equals(caRemarkChartData2.getRemarkType())) {
			BigDecimal ca1 = new BigDecimal(caRemarkChartData1.getCaAchievementRate());
			BigDecimal ca2 = new BigDecimal(caRemarkChartData2.getCaAchievementRate());
			flag = ca1.compareTo(ca2);
		}
		else {
			BigDecimal ca1 = new BigDecimal(caRemarkChartData1.getCommitmentAchievementRate());
			BigDecimal ca2 = new BigDecimal(caRemarkChartData2.getCommitmentAchievementRate());
			flag = ca1.compareTo(ca2);
		}*/
		
		BigDecimal ca1 = new BigDecimal(caRemarkChartData1.getTotal());
		BigDecimal ca2 = new BigDecimal(caRemarkChartData2.getTotal());
		flag = ca2.compareTo(ca1);
		
		return flag;
	}

}
