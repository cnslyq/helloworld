package com.lenovo.bi.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BI_WeeklyComponentCommitmentOnForecast")
public class NpiWeeklyComponentCommitmentOnForecast {
	@Id
	@GeneratedValue
	private int id;
	
	@Column
	private int productKey;
	
	@Column
	private int pmsWaveId;
	
	@Column
	private int mtmKey;
	
	@Column
	private String bomNumber;
	
	@Column
	private int geographyKey;
	
	@Column
	private String geographyName;
	
	@Column
	private int odmKey;
	
	@Column
	private String odmName;
	
	@Column
	private int quantity;
	
	@Column
	private String forecastLabel;
	
	@Column
	private int abnormalQuantity;
	
	@Column
	private int materialShortage;
	
	@Column
	private int coverAShortage;
	
	@Column
	private int coverBShortage;
	
	@Column
	private int coverCShortage;
	
	@Column
	private int coverDShortage;
	
	@Column
	private int odmShortage;
	
	@Column
	private String ttvPhase;
	
	@Column
	private Date targetDate;
	
	@Column
	private Date versionDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProductKey() {
		return productKey;
	}

	public void setProductKey(int productKey) {
		this.productKey = productKey;
	}

	public int getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(int pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public int getMtmKey() {
		return mtmKey;
	}

	public void setMtmKey(int mtmKey) {
		this.mtmKey = mtmKey;
	}

	public int getGeographyKey() {
		return geographyKey;
	}

	public void setGeographyKey(int geographyKey) {
		this.geographyKey = geographyKey;
	}

	public int getOdmKey() {
		return odmKey;
	}

	public void setOdmKey(int odmKey) {
		this.odmKey = odmKey;
	}

	public String getBomNumber() {
		return bomNumber;
	}

	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}

	public String getGeographyName() {
		return geographyName;
	}

	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}

	public String getOdmName() {
		return odmName;
	}

	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getForecastLabel() {
		return forecastLabel;
	}

	public void setForecastLabel(String forecastLabel) {
		this.forecastLabel = forecastLabel;
	}

	public int getMaterialShortage() {
		return materialShortage;
	}

	public void setMaterialShortage(int materialShortage) {
		this.materialShortage = materialShortage;
	}

	public int getCoverAShortage() {
		return coverAShortage;
	}

	public void setCoverAShortage(int coverAShortage) {
		this.coverAShortage = coverAShortage;
	}

	public int getCoverBShortage() {
		return coverBShortage;
	}

	public void setCoverBShortage(int coverBShortage) {
		this.coverBShortage = coverBShortage;
	}

	public int getCoverCShortage() {
		return coverCShortage;
	}

	public void setCoverCShortage(int coverCShortage) {
		this.coverCShortage = coverCShortage;
	}

	public int getCoverDShortage() {
		return coverDShortage;
	}

	public void setCoverDShortage(int coverDShortage) {
		this.coverDShortage = coverDShortage;
	}

	public int getOdmShortage() {
		return odmShortage;
	}

	public void setOdmShortage(int odmShortage) {
		this.odmShortage = odmShortage;
	}

	public String getTtvPhase() {
		return ttvPhase;
	}

	public void setTtvPhase(String ttvPhase) {
		this.ttvPhase = ttvPhase;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public int getAbnormalQuantity() {
		return abnormalQuantity;
	}

	public void setAbnormalQuantity(int abnormalQuantity) {
		this.abnormalQuantity = abnormalQuantity;
	}
	
	public String toString(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		return "NpiWeeklyComponentCommitmentOnOrder [id=" + id
				+ ", productKey=" + productKey
				+ ", pmsWaveId=" + pmsWaveId
				+ ", bomNumber=" + bomNumber
				+ ", geographyName=" + geographyName
				+ ", odmName=" + odmName
				+ ", quantity=" + quantity
				+ ", forecastLabel=" + forecastLabel
				+ ", abnormalQuantity=" + abnormalQuantity
				+ ", materialShortage=" + materialShortage
				+ ", coverAShortage=" + coverAShortage
				+ ", coverBShortage=" + coverBShortage
				+ ", coverCShortage=" + coverCShortage
				+ ", coverDShortage=" + coverDShortage
				+ ", odmShortage=" + odmShortage
				+ ", ttvPhase=" + ttvPhase
				+ ", targetDate=" + sdf.format(targetDate)
				+ ", versionDate=" + sdf.format(versionDate)
				+ "]";
	}
	
}
