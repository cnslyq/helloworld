package com.lenovo.bi.dto.sc;

public class ScOverViewChartData {

	private String scStatusName;
	private int orderNum;	
	private String poNumber;
	private String poItem;

	public String getScStatusName() {
		return scStatusName;
	}

	public void setScStatusName(String fpsdStatusName) {
		this.scStatusName = fpsdStatusName;
	}

	public int getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoItem() {
		return poItem;
	}

	public void setPoItem(String poItem) {
		this.poItem = poItem;
	}
}
