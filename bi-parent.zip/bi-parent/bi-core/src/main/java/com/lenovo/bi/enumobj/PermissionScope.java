package com.lenovo.bi.enumobj;

public enum PermissionScope {

	all,my
}
