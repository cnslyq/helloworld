package com.lenovo.bi.util;

import java.math.BigDecimal;
import java.util.Comparator;

import com.lenovo.bi.dto.sc.FpsdRemarkChartData;

public class FpsdRemarkChartDataComparator implements Comparator {

	@Override
	public int compare(Object obj1, Object obj2) {
		FpsdRemarkChartData fpsdRemarkChartData1 = (FpsdRemarkChartData) obj1;
		FpsdRemarkChartData fpsdRemarkChartData2 = (FpsdRemarkChartData) obj2;

		BigDecimal failRate1 = new BigDecimal(fpsdRemarkChartData1.getFailRate());
		BigDecimal failRate2 = new BigDecimal(fpsdRemarkChartData2.getFailRate());
		
		int flag = failRate2.compareTo(failRate1);
		
		return flag;
	}

}
