package com.lenovo.bi.dto;

public class MtmGeographyOdmCvConfig extends MtmCvConfig {
	private String geographyName;
	private String odmName;
	
	public MtmGeographyOdmCvConfig(SingleUnitCvConfig singleUnitCvConfig,
			int unitQuantity, String geographyName, String odmName) {
		super(singleUnitCvConfig, unitQuantity);
		this.geographyName = geographyName;
		this.odmName = odmName;
	}
	
	public String getGeographyName() {
		return geographyName;
	}
	
	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}
	
	public String getOdmName() {
		return odmName;
	}
	
	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}	
}
