package com.lenovo.bi.enumobj;

public enum CausesCategory {

	ODM_CAPACITY("ODM Capacity"),
	SUPPLY_CAPACITY("Supply Capacity"),
	TOOLING_CAPACITY("Tooling Capacity"),
	DEMAND("Demand"),
	DEFECT("Defect");
	
	private String cause;
	
	CausesCategory(String cause){
		this.cause = cause;
	}
	
	@Override
	public String toString() {
		return name();
	}
	
	public String getCause(){
		return cause;
	}
}
