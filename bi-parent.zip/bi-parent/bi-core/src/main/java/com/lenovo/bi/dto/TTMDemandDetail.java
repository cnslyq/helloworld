package com.lenovo.bi.dto;
/**
 * 
 * @author henry_lian
 *
 */
public class TTMDemandDetail extends TTMDemand {

	private String c;
	private String v;
	private String purchaseType;
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	public String getV() {
		return v;
	}
	public void setV(String v) {
		this.v = v;
	}
	public String getPurchaseType() {
		return purchaseType;
	}
	public void setPurchaseType(String purchaseType) {
		this.purchaseType = purchaseType;
	}
}
