package com.lenovo.bi.dto;

public class ProductKeyPmsWaveId {
	private String productKey;
	private String pmsWaveId;
	public String getProductKey() {
		return productKey;
	}
	public void setProductKey(Integer productKey) {
		this.productKey = productKey.toString();
	}
	public String getPmsWaveId() {
		return pmsWaveId;
	}
	public void setPmsWaveId(Integer pmsWaveId) {
		this.pmsWaveId = pmsWaveId.toString();
	}
	
	
}
