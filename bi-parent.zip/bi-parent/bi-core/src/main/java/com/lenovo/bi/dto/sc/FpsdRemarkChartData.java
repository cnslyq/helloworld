package com.lenovo.bi.dto.sc;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

public class FpsdRemarkChartData {

	private int ok;
	private int early;
	private int late;
	private int toBeOk;
	private int toBeEarly;
	private int toBeLate;
	private int total;//for each product or region or odm or detractor code
	
	private int orderNum;
	private int statusKey;
	private String statusName;
	private int dimensionKey;
	private String dimensionName;
	private double failRate;
	private double earlyRate;
	private double lateRate;
	private double toBeEarlyRate;
	private double toBeLateRate;
	
	private String remarkType;//region;odm,product,detractor
	
	MathContext mc = new MathContext(2, RoundingMode.HALF_UP);
	
	public int getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}
	public int getStatusKey() {
		return statusKey;
	}
	public void setStatusKey(int statusKey) {
		this.statusKey = statusKey;
	}
	public int getDimensionKey() {
		return dimensionKey;
	}
	public void setDimensionKey(int dimensionKey) {
		this.dimensionKey = dimensionKey;
	}
	public String getDimensionName() {
		return dimensionName;
	}
	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public int getEarly() {
		return early;
	}
	public void setEarly(int early) {
		this.early = early;
	}
	public int getLate() {
		return late;
	}
	public void setLate(int late) {
		this.late = late;
	}
	public int getToBeEarly() {
		return toBeEarly;
	}
	public void setToBeEarly(int toBeEarly) {
		this.toBeEarly = toBeEarly;
	}
	public int getToBeLate() {
		return toBeLate;
	}
	public void setToBeLate(int toBeLate) {
		this.toBeLate = toBeLate;
	}
	
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public double getFailRate() {
		return new BigDecimal(getEarlyRate()).add(new BigDecimal(getLateRate()))
				.add(new BigDecimal(getToBeEarlyRate())).add(new BigDecimal(getToBeLateRate())).doubleValue();
	}
	public void setFailRate(double failRate) {
		this.failRate = failRate;
	}
	
	public double getEarlyRate() {
		return Math.round(new BigDecimal(early).divide(
				new BigDecimal(ok).add(new BigDecimal(early))
				.add(new BigDecimal(late)).add(new BigDecimal(toBeOk))
				.add(new BigDecimal(toBeEarly)).add(new BigDecimal(toBeLate))
				,mc
			    )
				.multiply(new BigDecimal(100)).doubleValue());
	}
	public void setEarlyRate(double earlyRate) {
		this.earlyRate = earlyRate;
	}
	
	public double getLateRate() {
		return Math.round(new BigDecimal(late).divide(
				new BigDecimal(ok).add(new BigDecimal(early))
				.add(new BigDecimal(late)).add(new BigDecimal(toBeOk))
				.add(new BigDecimal(toBeEarly)).add(new BigDecimal(toBeLate))
				,mc
			    )
				.multiply(new BigDecimal(100)).doubleValue());
	}
	public void setLateRate(double lateRate) {
		this.lateRate = lateRate;
	}
	
	public double getToBeEarlyRate() {
		return Math.round(new BigDecimal(toBeEarly).divide(
				new BigDecimal(ok).add(new BigDecimal(early))
				.add(new BigDecimal(late)).add(new BigDecimal(toBeOk))
				.add(new BigDecimal(toBeEarly)).add(new BigDecimal(toBeLate))
				,mc
			    )
				.multiply(new BigDecimal(100)).doubleValue());
	}
	public void setToBeEarlyRate(double toBeEarlyRate) {
		this.toBeEarlyRate = toBeEarlyRate;
	}
	
	public double getToBeLateRate() {
		return Math.round(new BigDecimal(toBeLate).divide(
				new BigDecimal(ok).add(new BigDecimal(early))
				.add(new BigDecimal(late)).add(new BigDecimal(toBeOk))
				.add(new BigDecimal(toBeEarly)).add(new BigDecimal(toBeLate))
				,mc
			    )
				.multiply(new BigDecimal(100)).doubleValue());
	}
	public void setToBeLateRate(double toBeLateRate) {
		this.toBeLateRate = toBeLateRate;
	}
	
	public int getOk() {
		return ok;
	}
	public void setOk(int ok) {
		this.ok = ok;
	}
	public int getToBeOk() {
		return toBeOk;
	}
	public void setToBeOk(int toBeOk) {
		this.toBeOk = toBeOk;
	}
	public String getRemarkType() {
		return remarkType;
	}
	public void setRemarkType(String remarkType) {
		this.remarkType = remarkType;
	}
	
}
