package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
/**
 * 
 * 
 * @author henry_lian
 *
 */
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="BI_ProjectSummary")
public class ProjectSummary {
	
	@Id
	@GeneratedValue
	@Column(name="ProjectSummaryId")
	private Integer id;
	@Column(name="PMSWaveId")
	private Integer pmsWaveId;
	@Column(name="DOI")
	private String doi;
	@Column(name="GatingDefects")
	private String defects;
	@Column(name="FPY")
	private String fpy;
	@Column(name="ODM")
	private String odm;
	@Column(name="Tooling")
	private String tooling;
	@Column(name="TTMRisk")
	private Boolean isTTMRisk = false;
	@Column(name="TTMSuccessDelay")
	private Integer ttmDelays;
	@Column(name="TTVRisk")
	private Boolean isTTVRisk = false;
	@Column(name="PMSProjectId")
	private Integer pmsProjectId;
	@Column(name="StartDate")
	private Date startDate;
	@Column(name="EndDate")
	private Date endDate;
	@Column(name="ProductName")
	private String productName;
	@Column(name="WaveName")
	private String waveName;
	@Column(name="TTM_Status")
	private String ttmStatus;
	@Column(name="TTV_Status")
	private String ttvStatus;
	@Column(name="TTMTargetDate")
	private Date ttmTargetDate;
	@Column(name="TTMSignOffDate")
	private Date ttmSignOffDate;
	@Column(name="TTVTargetDate")
	private Date ttvTargetDate;
	@Column(name="TTVSignOffDate")
	private Date ttvSignOffDate;
	@Column(name="TTVTarget")
	private Float ttvTarget = 0f;
	@Column(name="EstimatedTTV")
	private Float estimatedTTV = 0f;
	@Column(name="ActualTTV")
	private Float actualTTV = 0f;
	@ManyToOne
	@JoinColumn(name = "pmsProjectId", referencedColumnName="ProjectId",insertable = false, updatable = false)  
	private ProjectRoleUser projectRoleUser;
	@Column(name="Family")
	private String family;
	@Column(name="OBE")
	private String obe;
	@Column(name="pm")
	private String pm;
	@Column(name="VersionDate")
	private Date versionDate;
	@Column(name="SVTPLanDate")
	private Date svtPlanDate;
	@Column(name="SOVPPlanDate")
	private Date sovpPlanDate;
	@Column(name="isProjectPlanned")
	private Boolean isProjectPlanned = false;
	@Column(name="ObeTarget")
	private Float obeTarget = 0f;
	@Column(name="ttmTargetDateDemand")
	private Integer ttmTargetDateDemand = 0;
	@Column(name="CurrentPhase")
	private String currentPhase;
	@Transient
	private Integer phaseNumber = 0;
	
	@Column(name="SGA_ttvTargetDate")
	private Date sgaTtvTargetDate;
	@Column(name="SGA_TTV_Status")
	private String sgaTtvStatus;
	@Column(name="SGA_TTVRisk")
	private Boolean isSgaTtvRisk = false;
	@Column(name="SGA_ttvSignOffDate")
	private Date sgaTtvSignOffDate;
	@Column(name="SGA_TTVTarget")
	private Float sgaTtvTarget = 0f;
	@Column(name="SGA_EstimatedTTV")
	private Float sgaEstimatedTTV = 0f;
	@Column(name="SGA_ActualTTV")
	private Float sgaActualTTV = 0f;
	@Column(name="FPYTarget")
	private Float fpyTarget = 0f;
	
	public Integer getPhaseNumber() {
		return phaseNumber;
	}
	public void setPhaseNumber(Integer phaseNumber) {
		this.phaseNumber = phaseNumber;
	}
	public ProjectSummary() {
		super();
	}
	public ProjectSummary(Integer pmsWaveId, String doi, String defects,
			String fpy, String odm, String tooling, Boolean isTTMRisk,
			Integer ttmDelays, Boolean isTTVRisk, Integer pmsProjectId, Date startDate,
			String productName, String waveName, String ttmStatus,
			String ttvStatus, Date ttmTargetDate, Date ttmSignOffDate,
			Date ttvTargetDate, Date ttvSignOffDate, Float ttvTarget,
			Float estimatedTTV, Float actualTTV,
			String family, String obe,
			String pm, Date versionDate, Date svtPlanDate, Date sovpPlanDate,
			Boolean isProjectPlanned, Float obeTarget,Integer ttmTargetDateDemand, String currentPhase) {
		super();
		this.pmsWaveId = pmsWaveId;
		this.doi = doi;
		this.defects = defects;
		this.fpy = fpy;
		this.odm = odm;
		this.tooling = tooling;
		this.isTTMRisk = isTTMRisk;
		this.ttmDelays = ttmDelays;
		this.isTTVRisk = isTTVRisk;
		this.pmsProjectId = pmsProjectId;
		this.startDate = startDate;
		this.productName = productName;
		this.waveName = waveName;
		this.ttmStatus = ttmStatus;
		this.ttvStatus = ttvStatus;
		this.ttmTargetDate = ttmTargetDate;
		this.ttmSignOffDate = ttmSignOffDate;
		this.ttvTargetDate = ttvTargetDate;
		this.ttvSignOffDate = ttvSignOffDate;
		this.ttvTarget = ttvTarget;
		this.estimatedTTV = estimatedTTV;
		this.actualTTV = actualTTV;
		this.family = family;
		this.obe = obe;
		this.pm = pm;
		this.versionDate = versionDate;
		this.svtPlanDate = svtPlanDate;
		this.sovpPlanDate = sovpPlanDate;
		this.isProjectPlanned = isProjectPlanned;
		this.obeTarget = obeTarget;
		this.ttmTargetDateDemand = ttmTargetDateDemand;
		this.currentPhase = currentPhase;
	}
	
	public ProjectSummary(Integer pmsWaveId, String doi, String defects,
			String fpy, String odm, String tooling, Boolean isTTMRisk,
			Integer ttmDelays, Boolean isTTVRisk, Integer pmsProjectId, Date startDate,
			String productName, String waveName, String ttmStatus,
			String ttvStatus, Date ttmTargetDate, Date ttmSignOffDate,
			Date ttvTargetDate, Date ttvSignOffDate, Float ttvTarget,
			Float estimatedTTV, Float actualTTV,
			String family, String obe,
			String pm, Date versionDate, Date svtPlanDate, Date sovpPlanDate,
			Boolean isProjectPlanned, Float obeTarget,Integer ttmTargetDateDemand, String currentPhase, Date sgaTTVTargetDate) {
		super();
		this.pmsWaveId = pmsWaveId;
		this.doi = doi;
		this.defects = defects;
		this.fpy = fpy;
		this.odm = odm;
		this.tooling = tooling;
		this.isTTMRisk = isTTMRisk;
		this.ttmDelays = ttmDelays;
		this.isTTVRisk = isTTVRisk;
		this.pmsProjectId = pmsProjectId;
		this.startDate = startDate;
		this.productName = productName;
		this.waveName = waveName;
		this.ttmStatus = ttmStatus;
		this.ttvStatus = ttvStatus;
		this.ttmTargetDate = ttmTargetDate;
		this.ttmSignOffDate = ttmSignOffDate;
		this.ttvTargetDate = ttvTargetDate;
		this.ttvSignOffDate = ttvSignOffDate;
		this.ttvTarget = ttvTarget;
		this.estimatedTTV = estimatedTTV;
		this.actualTTV = actualTTV;
		this.family = family;
		this.obe = obe;
		this.pm = pm;
		this.versionDate = versionDate;
		this.svtPlanDate = svtPlanDate;
		this.sovpPlanDate = sovpPlanDate;
		this.isProjectPlanned = isProjectPlanned;
		this.obeTarget = obeTarget;
		this.ttmTargetDateDemand = ttmTargetDateDemand;
		this.currentPhase = currentPhase;
		this.sgaTtvTargetDate = sgaTTVTargetDate;
	}
	public ProjectSummary(Integer pmsWaveId, String doi, String defects,
			String fpy, String odm, String tooling, Boolean isTTMRisk,
			Integer ttmDelays, Boolean isTTVRisk, Integer pmsProjectId, Date startDate,
			String productName, String waveName, String ttmStatus,
			String ttvStatus, Date ttmTargetDate, Date ttmSignOffDate,
			Date ttvTargetDate, Date ttvSignOffDate, Float ttvTarget,
			Float estimatedTTV, Float actualTTV,
			String family, String obe,
			String pm, Date versionDate, Date svtPlanDate, Date sovpPlanDate,
			Boolean isProjectPlanned, Float obeTarget,Integer ttmTargetDateDemand, String currentPhase, 
			Date sgaTTVTargetDate,
			String sgaTTVStatus,
			Boolean isSgaTTVRisk,
			Date sgaTtvSignOffDate,
			Float sgaTTVTarget,
			Float sgaEstimatedTTV,
			Float sgaActualTTV) {
		super();
		this.pmsWaveId = pmsWaveId;
		this.doi = doi;
		this.defects = defects;
		this.fpy = fpy;
		this.odm = odm;
		this.tooling = tooling;
		this.isTTMRisk = isTTMRisk;
		this.ttmDelays = ttmDelays;
		this.isTTVRisk = isTTVRisk;
		this.pmsProjectId = pmsProjectId;
		this.startDate = startDate;
		this.productName = productName;
		this.waveName = waveName;
		this.ttmStatus = ttmStatus;
		this.ttvStatus = ttvStatus;
		this.ttmTargetDate = ttmTargetDate;
		this.ttmSignOffDate = ttmSignOffDate;
		this.ttvTargetDate = ttvTargetDate;
		this.ttvSignOffDate = ttvSignOffDate;
		this.ttvTarget = ttvTarget;
		this.estimatedTTV = estimatedTTV;
		this.actualTTV = actualTTV;
		this.family = family;
		this.obe = obe;
		this.pm = pm;
		this.versionDate = versionDate;
		this.svtPlanDate = svtPlanDate;
		this.sovpPlanDate = sovpPlanDate;
		this.isProjectPlanned = isProjectPlanned;
		this.obeTarget = obeTarget;
		this.ttmTargetDateDemand = ttmTargetDateDemand;
		this.currentPhase = currentPhase;
		this.sgaTtvTargetDate = sgaTTVTargetDate;
		this.sgaActualTTV = sgaActualTTV;
		this.sgaEstimatedTTV = sgaEstimatedTTV;
		this.sgaTtvSignOffDate = sgaTtvSignOffDate;
		this.sgaTtvStatus = sgaTTVStatus;
		this.sgaTtvTarget = sgaTTVTarget;
		this.isSgaTtvRisk = isSgaTTVRisk;
	}
	public ProjectSummary(Integer pmsWaveId, String doi, String defects,
			String fpy, String odm, String tooling, Boolean isTTMRisk,
			Integer ttmDelays, Boolean isTTVRisk, Integer pmsProjectId, Date startDate,
			String productName, String waveName, String ttmStatus,
			String ttvStatus, Date ttmTargetDate, Date ttmSignOffDate,
			Date ttvTargetDate, Date ttvSignOffDate, Float ttvTarget,
			Float estimatedTTV, Float actualTTV,
			String family, String obe,
			String pm, Date versionDate, Date svtPlanDate, Date sovpPlanDate,
			Boolean isProjectPlanned, Float obeTarget,Integer ttmTargetDateDemand, String currentPhase, 
			Date sgaTTVTargetDate,
			String sgaTTVStatus,
			Boolean isSgaTTVRisk,
			Date sgaTtvSignOffDate,
			Float sgaTTVTarget,
			Float sgaEstimatedTTV,
			Float sgaActualTTV,
			Float fpyTarget) {
		super();
		this.pmsWaveId = pmsWaveId;
		this.doi = doi;
		this.defects = defects;
		this.fpy = fpy;
		this.odm = odm;
		this.tooling = tooling;
		this.isTTMRisk = isTTMRisk;
		this.ttmDelays = ttmDelays;
		this.isTTVRisk = isTTVRisk;
		this.pmsProjectId = pmsProjectId;
		this.startDate = startDate;
		this.productName = productName;
		this.waveName = waveName;
		this.ttmStatus = ttmStatus;
		this.ttvStatus = ttvStatus;
		this.ttmTargetDate = ttmTargetDate;
		this.ttmSignOffDate = ttmSignOffDate;
		this.ttvTargetDate = ttvTargetDate;
		this.ttvSignOffDate = ttvSignOffDate;
		this.ttvTarget = ttvTarget;
		this.estimatedTTV = estimatedTTV;
		this.actualTTV = actualTTV;
		this.family = family;
		this.obe = obe;
		this.pm = pm;
		this.versionDate = versionDate;
		this.svtPlanDate = svtPlanDate;
		this.sovpPlanDate = sovpPlanDate;
		this.isProjectPlanned = isProjectPlanned;
		this.obeTarget = obeTarget;
		this.ttmTargetDateDemand = ttmTargetDateDemand;
		this.currentPhase = currentPhase;
		this.sgaTtvTargetDate = sgaTTVTargetDate;
		this.sgaActualTTV = sgaActualTTV;
		this.sgaEstimatedTTV = sgaEstimatedTTV;
		this.sgaTtvSignOffDate = sgaTtvSignOffDate;
		this.sgaTtvStatus = sgaTTVStatus;
		this.sgaTtvTarget = sgaTTVTarget;
		this.isSgaTtvRisk = isSgaTTVRisk;
		this.fpyTarget = fpyTarget;
	}
	public Boolean getIsTTMRisk() {
		return isTTMRisk;
	}
	public void setIsTTMRisk(Boolean isTTMRisk) {
		this.isTTMRisk = isTTMRisk;
	}
	public Boolean getIsTTVRisk() {
		return isTTVRisk;
	}
	public void setIsTTVRisk(Boolean isTTVRisk) {
		this.isTTVRisk = isTTVRisk;
	}
	public Boolean getIsProjectPlanned() {
		return isProjectPlanned;
	}
	public void setIsProjectPlanned(Boolean isProjectPlanned) {
		this.isProjectPlanned = isProjectPlanned;
	}
	public Integer getTtmTargetDateDemand() {
		return ttmTargetDateDemand;
	}
	public void setTtmTargetDateDemand(Integer ttmTargetDateDemand) {
		this.ttmTargetDateDemand = ttmTargetDateDemand;
	}
	public Date getVersionDate() {
		return versionDate;
	}
	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}
	public Date getSvtPlanDate() {
		return svtPlanDate;
	}
	public void setSvtPlanDate(Date svtPlanDate) {
		this.svtPlanDate = svtPlanDate;
	}
	public Date getSovpPlanDate() {
		return sovpPlanDate;
	}
	public void setSovpPlanDate(Date sovpPlanDate) {
		this.sovpPlanDate = sovpPlanDate;
	}
	public Boolean isProjectPlanned() {
		return isProjectPlanned;
	}
	public void setProjectPlanned(Boolean isProjectPlanned) {
		this.isProjectPlanned = isProjectPlanned;
	}
	public Float getObeTarget() {
		return obeTarget;
	}
	public void setObeTarget(Float obeTarget) {
		this.obeTarget = obeTarget;
	}
	public ProjectRoleUser getProjectRoleUser() {
		return projectRoleUser;
	}
	public void setProjectRoleUser(ProjectRoleUser projectRoleUser) {
		this.projectRoleUser = projectRoleUser;
	}
	public String getFamily() {
		return family;
	}
	public void setFamily(String family) {
		this.family = family;
	}
	public String getObe() {
		return obe;
	}
	public void setObe(String obe) {
		this.obe = obe;
	}
	public String getPm() {
		return pm;
	}
	public void setPm(String pm) {
		this.pm = pm;
	}
	public Float getEstimatedTTV() {
		return estimatedTTV;
	}
	public void setEstimatedTTV(Float estimatedTTV) {
		this.estimatedTTV = estimatedTTV;
	}
	public Float getActualTTV() {
		return actualTTV;
	}
	public void setActualTTV(Float actualTTV) {
		this.actualTTV = actualTTV;
	}
	public Date getTtmTargetDate() {
		return ttmTargetDate;
	}
	public void setTtmTargetDate(Date ttmTargetDate) {
		this.ttmTargetDate = ttmTargetDate;
	}
	public Date getTtmSignOffDate() {
		return ttmSignOffDate;
	}
	public void setTtmSignOffDate(Date ttmSignOffDate) {
		this.ttmSignOffDate = ttmSignOffDate;
	}
	public Date getTtvTargetDate() {
		return ttvTargetDate;
	}
	public void setTtvTargetDate(Date ttvTargetDate) {
		this.ttvTargetDate = ttvTargetDate;
	}
	public Date getTtvSignOffDate() {
		return ttvSignOffDate;
	}
	public void setTtvSignOffDate(Date ttvSignOffDate) {
		this.ttvSignOffDate = ttvSignOffDate;
	}

	public Float getTtvTarget() {
		return ttvTarget;
	}
	public void setTtvTarget(Float ttvTarget) {
		this.ttvTarget = ttvTarget;
	}
	public Integer getPmsProjectId() {
		return pmsProjectId;
	}
	public void setPmsProjectId(Integer pmsProjectId) {
		this.pmsProjectId = pmsProjectId;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getWaveName() {
		return waveName;
	}
	public void setWaveName(String waveName) {
		this.waveName = waveName;
	}
	public String getTtmStatus() {
		return ttmStatus;
	}
	public void setTtmStatus(String ttmStatus) {
		this.ttmStatus = ttmStatus;
	}
	public String getTtvStatus() {
		return ttvStatus;
	}
	public void setTtvStatus(String ttvStatus) {
		this.ttvStatus = ttvStatus;
	}
	public Integer getPmsWaveId() {
		return pmsWaveId;
	}
	public void setPmsWaveId(Integer pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}
	public String getDoi() {
		return doi;
	}
	public void setDoi(String doi) {
		this.doi = doi;
	}
	public String getDefects() {
		return defects;
	}
	public void setDefects(String defects) {
		this.defects = defects;
	}
	public String getFpy() {
		return fpy;
	}
	public void setFpy(String fpy) {
		this.fpy = fpy;
	}
	public String getOdm() {
		return odm;
	}
	public void setOdm(String odm) {
		this.odm = odm;
	}
	public String getTooling() {
		return tooling;
	}
	public void setTooling(String tooling) {
		this.tooling = tooling;
	}
	public Boolean isTTMRisk() {
		return isTTMRisk;
	}
	public void setTTMRisk(Boolean isTTMRisk) {
		this.isTTMRisk = isTTMRisk;
	}
	public Integer getTtmDelays() {
		return ttmDelays;
	}
	public void setTtmDelays(Integer ttmDelays) {
		this.ttmDelays = ttmDelays;
	}
	public Boolean isTTVRisk() {
		return isTTVRisk;
	}
	public void setTTVRisk(Boolean isTTVRisk) {
		this.isTTVRisk = isTTVRisk;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCurrentPhase() {
		return currentPhase;
	}
	public void setCurrentPhase(String currentPhase) {
		this.currentPhase = currentPhase;
	}
	public Date getSgaTtvSignOffDate() {
		return sgaTtvSignOffDate;
	}
	public void setSgaTtvSignOffDate(Date sgaTtvSignOffDate) {
		this.sgaTtvSignOffDate = sgaTtvSignOffDate;
	}
	public Float getSgaEstimatedTTV() {
		return sgaEstimatedTTV;
	}
	public void setSgaEstimatedTTV(Float sgaEstimatedTTV) {
		this.sgaEstimatedTTV = sgaEstimatedTTV;
	}
	public Float getSgaActualTTV() {
		return sgaActualTTV;
	}
	public void setSgaActualTTV(Float sgaActualTTV) {
		this.sgaActualTTV = sgaActualTTV;
	}
	public Date getSgaTtvTargetDate() {
		return sgaTtvTargetDate;
	}
	public void setSgaTtvTargetDate(Date sgaTtvTargetDate) {
		this.sgaTtvTargetDate = sgaTtvTargetDate;
	}
	public String getSgaTtvStatus() {
		return sgaTtvStatus;
	}
	public void setSgaTtvStatus(String sgaTtvStatus) {
		this.sgaTtvStatus = sgaTtvStatus;
	}
	public Boolean getIsSgaTtvRisk() {
		return isSgaTtvRisk;
	}
	public void setIsSgaTtvRisk(Boolean isSgaTtvRisk) {
		this.isSgaTtvRisk = isSgaTtvRisk;
	}
	public Float getSgaTtvTarget() {
		return sgaTtvTarget;
	}
	public void setSgaTtvTarget(Float sgaTtvTarget) {
		this.sgaTtvTarget = sgaTtvTarget;
	}
	public Float getFpyTarget() {
		return fpyTarget;
	}
	public void setFpyTarget(Float fpyTarget) {
		this.fpyTarget = fpyTarget;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
}
