package com.lenovo.bi.enumobj;

import java.util.Date;

public enum Threshold {

	PAGE_SIZE(Integer.class),
	TTM_STATUS_GRACE(Integer.class),
	TTM_SUCCESS_THRESHOLD(Integer.class),
	TTM_ODM(Float.class),
	TTM_TOOLING(Float.class),
	TTV_TARGET(Float.class),
	TTV_OUTLOOK_STARTDATE(Integer.class),
	TTV_OUTLOOK_ENDDATE(Integer.class),
	TTV_OUTLOOK_DURATION(Integer.class),
	SGA_TTV_OUTLOOK_STARTDATE(Integer.class),
	SGA_TTV_OUTLOOK_ENDDATE(Integer.class),
	SGA_TTV_OUTLOOK_DURATION(Integer.class),
	FORECAST_VERSION_COUNT(Integer.class),
	ORDER_VERSION_COUNT(Integer.class),
	FORECAST_COMPARISON_DEFAULT(Integer.class),
	FORECAST_OFFSET(Integer.class),
	NPI_FPY_TARGET(Float.class),
	NPI_OBE_TARGET(Float.class),
	
	SC_OTS_OTS_TARGET(Integer.class),
	SC_OTS_FPSD_TARGET(Integer.class),
	SC_OTS_ONS_TARGET(Integer.class),
	NPI_LOAD_DATE(Integer.class),
	CURRENTSGAWAVE(Integer.class);
	
	private Class<? extends Number> type;

	public Class<? extends Number> getType() {
		return type;
	}

	public void setType(Class<Number> type) {
		this.type = type;
	}
	
	Threshold(Class<? extends Number> type){
		this.type = type;
	}
}
