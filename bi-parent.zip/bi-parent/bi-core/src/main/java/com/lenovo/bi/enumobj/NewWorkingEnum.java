package com.lenovo.bi.enumobj;

public enum NewWorkingEnum {

	Working("666666");
	
	private String color;
	
	NewWorkingEnum(){
		
	}
	
	NewWorkingEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		return name();
	}
	
	public String getColor(){
		return color;
	}
}
