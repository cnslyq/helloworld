package com.lenovo.bi.dto.sc;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

import com.lenovo.bi.enumobj.ChartTypeEnum;

public class CARemarkChartData {

	private int commitment;
	private int shipment;
	private int risk;
	private int committed;
	private int future;
	
	private int caAchievement;
	private int commitmentAchievement;

	private int total;
	private String dimensionKey;
	private String dimensionName;

	private double commitmentRate;
	private double shipmentRate;
	private double riskRate;
	private double bohRate;
	private double totalRate;
	private double committedRate;
	
	private double caAchievementRate;
	private double commitmentAchievementRate;

	private int boh = 0;
	private int caTarget = 1000000;
	private int odmCommitment = 500000;

	private String remarkType;//region;family,product,portfolio
	private String chartType;//overview, crossmonth, dashboard

	MathContext mc = new MathContext(3, RoundingMode.HALF_UP);

	public String getDimensionKey() {
		return dimensionKey;
	}

	public void setDimensionKey(String dimensionKey) {
		this.dimensionKey = dimensionKey;
	}

	public String getDimensionName() {
		return dimensionName;
	}

	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}

	public int getCommitment() {
		return commitment;
	}

	public void setCommitment(int commitment) {
		this.commitment = commitment;
	}

	public int getShipment() {
		return shipment;
	}

	public void setShipment(int shipment) {
		this.shipment = shipment;
	}

	public int getRisk() {
		return risk;
	}

	public void setRisk(int risk) {
		this.risk = risk;
	}
	
	public int getBoh() {
		return boh;
	}

	public void setBoh(int boh) {
		this.boh = boh;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}
	
	public int getCommitted() {
		return committed;
	}

	public void setCommitted(int committed) {
		this.committed = committed;
	}

	public String getRemarkType() {
		return remarkType;
	}

	public void setRemarkType(String remarkType) {
		this.remarkType = remarkType;
	}

	public double getCommitmentRate() {
		return Math.round(new BigDecimal(commitment).divide(
				new BigDecimal(odmCommitment)
				,mc
			    )
				.multiply(new BigDecimal(100)).doubleValue());
	}

	public void setCommitmentRate(double commitmentRate) {
		this.commitmentRate = commitmentRate;
	}

	public double getShipmentRate() {
		if("Region".equals(remarkType) && ChartTypeEnum.OverView.getTypeName().equals(chartType))
			return Math.round(new BigDecimal(shipment).divide(
					new BigDecimal(caTarget)
					,mc
				    )
					.multiply(new BigDecimal(100)).doubleValue());
		else
			return Math.round(new BigDecimal(shipment).divide(
					new BigDecimal(odmCommitment)
					,mc
				    )
					.multiply(new BigDecimal(100)).doubleValue());
	}

	public void setShipmentRate(double shipmentRate) {
		this.shipmentRate = shipmentRate;
	}

	public double getRiskRate() {
		if("Region".equals(remarkType) && ChartTypeEnum.OverView.getTypeName().equals(chartType))
			return Math.round(new BigDecimal(risk).divide(
					new BigDecimal(caTarget)
					,mc
				    )
					.multiply(new BigDecimal(100)).doubleValue());
		else
			return Math.round(new BigDecimal(risk).divide(
					new BigDecimal(odmCommitment)
					,mc
				    )
					.multiply(new BigDecimal(100)).doubleValue());
	}

	public void setRiskRate(double riskRate) {
		this.riskRate = riskRate;
	}
	
	public double getCommittedRate() {
		if("Region".equals(remarkType) && ChartTypeEnum.OverView.getTypeName().equals(chartType))
			return Math.round(new BigDecimal(committed).divide(
					new BigDecimal(caTarget)
					,mc
				    )
					.multiply(new BigDecimal(100)).doubleValue());
		else
			return Math.round(new BigDecimal(committed).divide(
					new BigDecimal(odmCommitment)
					,mc
				    )
					.multiply(new BigDecimal(100)).doubleValue());
	}

	public void setCommittedRate(double committedRate) {
		this.committedRate = committedRate;
	}

	public double getBohRate() {
		if("Region".equals(remarkType) && ChartTypeEnum.OverView.getTypeName().equals(chartType))
			return Math.round(new BigDecimal(boh).divide(
					new BigDecimal(caTarget)
					,mc
				    )
					.multiply(new BigDecimal(100)).doubleValue());
		else
			return Math.round(new BigDecimal(boh).divide(
					new BigDecimal(odmCommitment)
					,mc
				    )
					.multiply(new BigDecimal(100)).doubleValue());
	}

	public void setBohRate(double bohRate) {
		this.bohRate = bohRate;
	}

	public double getTotalRate() {
		if("Region".equals(remarkType) && ChartTypeEnum.OverView.getTypeName().equals(chartType))
			return Math.round(new BigDecimal(total).divide(
					new BigDecimal(caTarget)
					,mc
				    )
					.multiply(new BigDecimal(100)).doubleValue());
		else
			return Math.round(new BigDecimal(total).divide(
					new BigDecimal(odmCommitment)
					,mc
				    )
					.multiply(new BigDecimal(100)).doubleValue());
	}
	
	
	/**
	 * for fusioncharts rendering, total column include shipment and risk
	 * @return
	 */
	public double getTotalRateForRender() {
		if("Region".equals(remarkType) && ChartTypeEnum.OverView.getTypeName().equals(chartType))
			return Math.round(new BigDecimal(total)
					.subtract(new BigDecimal(this.shipment).add(new BigDecimal(this.risk)))
					.divide(new BigDecimal(caTarget),mc)
					.multiply(new BigDecimal(100)).doubleValue());
		else
			return Math.round(new BigDecimal(total)
						.subtract(new BigDecimal(this.shipment).add(new BigDecimal(this.risk)))
						.divide(new BigDecimal(odmCommitment),mc)
						.multiply(new BigDecimal(100)).doubleValue());
	}

	public void setTotalRate(double totalRate) {
		this.totalRate = totalRate;
	}

	public double getCaAchievementRate() {
		return new BigDecimal(getShipmentRate()).add(new BigDecimal(getRiskRate()))
					.add(new BigDecimal(getTotalRate())).doubleValue();
	}

	public void setCaAchievementRate(double caAchievementRate) {
		this.caAchievementRate = caAchievementRate;
	}

	public double getCommitmentAchievementRate() {
		return new BigDecimal(getShipmentRate()).add(new BigDecimal(getRiskRate()))
				.add(new BigDecimal(getCommitmentRate())).doubleValue();
	}

	public void setCommitmentAchievementRate(double commitmentAchievementRate) {
		this.commitmentAchievementRate = commitmentAchievementRate;
	}
	
	public int getCaAchievement() {
		return new BigDecimal(getShipment()).add(new BigDecimal(getRisk()))
				.add(new BigDecimal(getTotal())).intValue();
	}

	public void setCaAchievement(int caAchievement) {
		this.caAchievement = caAchievement;
	}

	public int getCommitmentAchievement() {
		return new BigDecimal(getShipment()).add(new BigDecimal(getRisk()))
				.add(new BigDecimal(getCommitment())).intValue();
	}

	public void setCommitmentAchievement(int commitmentAchievement) {
		this.commitmentAchievement = commitmentAchievement;
	}

	public int getCaTarget() {
		return caTarget;
	}

	public void setCaTarget(int caTarget) {
		this.caTarget = caTarget;
	}

	public int getOdmCommitment() {
		return odmCommitment;
	}

	public void setOdmCommitment(int odmCommitment) {
		this.odmCommitment = odmCommitment;
	}

	public String getChartType() {
		return chartType;
	}

	public void setChartType(String chartType) {
		this.chartType = chartType;
	}

	public int getFuture() {
		return future;
	}

	public void setFuture(int future) {
		this.future = future;
	}

}
