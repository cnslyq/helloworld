package com.lenovo.bi.dto;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class WeeklyComponentCommitmentOnProductDto {

	private Integer productKey;
	private List<Integer> targetDateList;
	private Map<Integer, Map<Integer, Long>> targetDateCvMap;
	private Date versionDate;
	
	public Integer getProductKey() {
		return productKey;
	}
	public void setProductKey(Integer productKey) {
		this.productKey = productKey;
	}
	public List<Integer> getTargetDateList() {
		return targetDateList;
	}
	public void setTargetDateList(List<Integer> targetDateList) {
		this.targetDateList = targetDateList;
	}
	public Map<Integer, Map<Integer, Long>> getTargetDateCvMap() {
		return targetDateCvMap;
	}
	public void setTargetDateCvMap(Map<Integer, Map<Integer, Long>> targetDateCvMap) {
		this.targetDateCvMap = targetDateCvMap;
	}
	public Date getVersionDate() {
		return versionDate;
	}
	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}
	
}
