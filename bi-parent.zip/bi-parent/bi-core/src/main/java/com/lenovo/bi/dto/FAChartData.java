package com.lenovo.bi.dto;

public class FAChartData {

	private float mps;
	private float outlook;
	private float grossForecast;
	private float target;
	
	public float getMps() {
		return mps;
	}
	public void setMps(float mps) {
		this.mps = mps;
	}
	public float getOutlook() {
		return outlook;
	}
	public void setOutlook(float outlook) {
		this.outlook = outlook;
	}
	public float getGrossForecast() {
		return grossForecast;
	}
	public void setGrossForecast(float grossForecast) {
		this.grossForecast = grossForecast;
	}
	public float getTarget() {
		return target;
	}
	public void setTarget(float target) {
		this.target = target;
	}
}
