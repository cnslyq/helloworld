package com.lenovo.bi.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;

public class CalendarUtil {
	private static final int MS_IN_WEEK = 7 * 24 * 60 * 60 * 1000;

	// YYYY-MM/YYYY-M convert to YYYYMM
	public static String yearMonthConvert(String date) {
		if (StringUtils.isNotBlank(date)) {
			String newDate = date.replaceAll("-", "");
			if (StringUtils.isBlank(newDate) && newDate.length() >= 5) {
				return null;
			} else if (newDate.length() == 5) {
				newDate = new StringBuffer(newDate).insert(4, "0").toString();
			}
			return newDate;
		} else {
			return null;
		}
	}

	public static Date getCurrentFiscalYearStartDate() {
		Calendar now = Calendar.getInstance();
		int year = now.get(Calendar.YEAR);
		Calendar startDate = Calendar.getInstance();
		startDate.set(year, 3, 1);
		if (now.before(startDate)) {
			startDate.set(year - 1, 3, 1);
		}
		return startDate.getTime();
	}

	public static Date getCurrentFiscalYearEndDate() {
		Calendar now = Calendar.getInstance();
		int year = now.get(Calendar.YEAR);
		Calendar endDate = Calendar.getInstance();
		endDate.set(year, 2, 31);
		if (now.after(endDate)) {
			endDate.set(year + 1, 2, 31);
		}
		return endDate.getTime();
	}

	public static Date stringT2Date(String string) throws ParseException {
		if (string == null || string.trim().equals("")) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.parse(string);
	}

	public static String date2String(Date date) throws ParseException {
		if (date == null) {
			return "";
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(date);
	}

	public static String timestamp2String(Date date) throws ParseException {
		if (date == null) {
			return "";
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		return sdf.format(date);
	}

	public static Date adjustTimeToMidnight(Date date) {
		if (date == null) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	/**
	 * 根据日期计算所在周的周一的日期
	 * 
	 * @param date
	 */
	public static Date getMondayDateByDate(Date date) {
		Calendar cal = Calendar.getInstance();

		cal.setTime(date);

		cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);

		return cal.getTime();
	}

	public static Date getMonday() {
		return getMondayDateByDate(CalendarUtil.getTodayWithoutMins());
	}

	/**
	 * 根据日期计算所在周的周日的日期
	 * 
	 * @param date
	 */
	public static Date getSundayDateByDate(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		cal.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);

		return cal.getTime();
	}

	/**
	 * 根据日期计算几周之后的星期一的日期
	 * 
	 * @param date
	 * @param weeks
	 * @return
	 */
	public static Date getMondayDateByWeeks(Date date, int weeks) {
		int days = weeks * 7;
		Calendar calendar = Calendar.getInstance();
		Date modayDate = getMondayDateByDate(date);
		calendar.setTime(modayDate);
		calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + days);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	/**
	 * Add number of days to the date passed in
	 * 
	 * @param date
	 * @param days
	 */
	public static Date addDays(Date date, int days) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + days);
		return calendar.getTime();
	}

	/**
	 * 根据日期计算几天之后的日期:yyyy-MM-dd
	 * 
	 * @param date
	 * @param weeks
	 * @return
	 * @throws ParseException
	 */
	public static String getDateByDays(Date date, int days) throws ParseException {
		return date2String(addDays(date, days));
	}
	
	public static String getDateByDays1(String date, int days) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
		return date2String(addDays(sdf.parse(date), days));
	}

	/**
	 * 根据制定日期获取是第几周
	 * 
	 * @param dateStr
	 * @return
	 * @throws ParseException
	 */
	public static int getWeekNoByDate(String dateStr) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date = format.parse(dateStr);
		Calendar calendar = Calendar.getInstance();
		calendar.setFirstDayOfWeek(Calendar.MONDAY);
		calendar.setTime(date);

		return calendar.get(Calendar.WEEK_OF_YEAR);
	}

	/**
	 * 获取当前日期是第几周
	 * 
	 * @return
	 */
	public static int getCurrentWeekNo() {
		/*
		 * TimeZone zone=TimeZone.getTimeZone("Asia/Shanghai"); Calendar cal =
		 * Calendar.getInstance(zone);
		 */
		Calendar cal = Calendar.getInstance();
		int weekNo = cal.get(cal.WEEK_OF_YEAR);
		return weekNo;
	}

	public static boolean isSameWeek(Date date1, Date date2) {
		Calendar instance1 = Calendar.getInstance();
		instance1.setTime(date1);

		Calendar instance2 = Calendar.getInstance();
		instance2.setTime(date2);

		int year1 = instance1.get(Calendar.YEAR);
		int year2 = instance2.get(Calendar.YEAR);
		int week1 = instance1.get(Calendar.WEEK_OF_YEAR);
		int week2 = instance2.get(Calendar.WEEK_OF_YEAR);

		if (year1 == year2 && week1 == week2) {
			return true;
		}

		if (year2 - year1 == 1 && week1 == week2) {
			if (instance2.getTimeInMillis() - instance1.getTimeInMillis() < MS_IN_WEEK) {
				return true;
			}
		}

		if (year1 - year2 == 1 && week1 == week2) {
			if (instance1.getTimeInMillis() - instance2.getTimeInMillis() < MS_IN_WEEK) {
				return true;
			}
		}

		return false;
	}

	public static boolean isSameDay(Date date1, Date date2) {
		Calendar instance1 = Calendar.getInstance();
		instance1.setTime(date1);

		Calendar instance2 = Calendar.getInstance();
		instance2.setTime(date2);

		return instance1.get(Calendar.YEAR) == instance2.get(Calendar.YEAR) && instance1.get(Calendar.DAY_OF_YEAR) == instance2.get(Calendar.DAY_OF_YEAR);
	}

	public static boolean isSameMonth(Date date1, Date date2) {
		Calendar instance1 = Calendar.getInstance();
		instance1.setTime(date1);

		Calendar instance2 = Calendar.getInstance();
		instance2.setTime(date2);

		return instance1.get(Calendar.YEAR) == instance2.get(Calendar.YEAR) && instance1.get(Calendar.MONTH) == instance2.get(Calendar.MONTH);
	}

	public static boolean isSunday(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;
	}

	public static Date getTodayWithoutMins() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	public static String getYearMonthByMonths(String date, int months) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
		Date yearMonthDate;
		try {
			yearMonthDate = DateUtils.addMonths(sdf.parse(date), months);
		} catch (ParseException e) {
			sdf = new SimpleDateFormat("yyyyMM");
			yearMonthDate = DateUtils.addMonths(sdf.parse(date), months);
		}
		return sdf.format(yearMonthDate);
	}

	/**
	 * Get the first date of a month
	 * 
	 * @param yearMonth
	 * @return
	 */
	public static String getFirstDayOfMonth(String yearMonth) {
		int year = Integer.parseInt(yearMonth.substring(0, 4));
		int month = Integer.parseInt(yearMonth.substring(yearMonth.indexOf('-') + 1)) - 1;
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month);
		cal.set(Calendar.DAY_OF_MONTH, cal.getMinimum(Calendar.DATE));
		return new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
	}

	/**
	 * Get the last date of a month
	 * 
	 * @param yearMonth
	 * @return
	 */
	public static String getLastDayOfMonth(String yearMonth) {
		if (StringUtils.isNotBlank(yearMonth)) {
			int year = Integer.parseInt(yearMonth.substring(0, 4));
			int month = Integer.parseInt(yearMonth.substring(yearMonth.indexOf('-') + 1)) - 1;
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.YEAR, year);
			cal.set(Calendar.MONTH, month);
			cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DATE));
			return new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
		} else {
			return null;
		}
	}
	
	public static Date getDateByString(String yyyyMMdd){
		Date result = null;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	try {
		result = sdf.parse(yyyyMMdd);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return result;
	}
	
	public static int getQuarterByMonth(int month) {
		if(month >= 1 && month <= 3 )
			return 4;
		else if(month >= 4 && month <= 6 )
			return 1;
		else if(month >= 7 && month <= 9 )
			return 2;
		else 
			return 3;
	}

	public static void main(String[] args) throws Exception {
		// Monday is the first day
		Locale.setDefault(Locale.UK);

		System.out.println(getMondayDateByDate(stringT2Date("2014-01-01")));
		System.out.println(getMondayDateByDate(stringT2Date("2014-02-09")));
		System.out.println(getMondayDateByDate(stringT2Date("2014-02-10")));
		System.out.println(getMondayDateByDate(stringT2Date("2014-02-12")));

		System.out.println(getMondayDateByWeeks(stringT2Date("2014-02-12"), 3));

		System.out.println(getDateByDays(stringT2Date("2014-02-12"), 3));

		System.out.println(getWeekNoByDate("2014-02-09"));

		System.out.println(getCurrentWeekNo());

		System.out.println(date2String(Calendar.getInstance().getTime()));

		System.out.println("2014-02-12".compareTo("2004-02-17"));
		System.out.println("02/11/2013".compareTo("02/10/2014"));

		System.out.println(isSameWeek(stringT2Date("2014-02-10"), stringT2Date("2014-02-16")));
		System.out.println(isSameWeek(stringT2Date("2014-02-10"), stringT2Date("2014-02-18")));

		System.out.println(getYearMonthByMonths("2014-01", 13));

		System.out.println(getFirstDayOfMonth("2014-02"));
		System.out.println(getLastDayOfMonth("2014-02"));

	}

	public static List<String> getDatesByString(String date) {
		if (StringUtils.isNotBlank(date)) {
			Pattern pattern = Pattern.compile("[0-9]{4}[-][0-9]+");
			Matcher matcher = pattern.matcher(date);
			List<String> dateList = new ArrayList<String>();
			while (matcher.find()) {
				dateList.add(matcher.group());
			}
			return dateList;
		} else {
			return null;
		}
	}
}
