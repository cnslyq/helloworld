package com.lenovo.bi.dto.sc;

public class ScRemarkChartData {

	private String scStatusName;
	private int failRate;
	private int orderNum;
	private String subDimensionName;
	private int subDimensionValue;
	private int subDimensionKey;
	private float ltfcRate;
	private int minQTY;
	private int maxQTY;
		
	private float faRateDashboardChart;
	private float faRate;

	
	
	public float getRate() {
		return ltfcRate;
	}

	public void setRate(float rate) {
		this.ltfcRate = rate;
	}

	public int getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}

	public int getSubDimensionKey() {
		return subDimensionKey;
	}

	public void setSubDimensionKey(int subDimensionKey) {
		this.subDimensionKey = subDimensionKey;
	}

	public String getSubDimensionName() {
		return subDimensionName;
	}

	public void setSubDimensionName(String subDimensionName) {
		this.subDimensionName = subDimensionName;
	}

	public int getSubDimensionValue() {
		return subDimensionValue;
	}

	public void setSubDimensionValue(int subDimensionValue) {
		this.subDimensionValue = subDimensionValue;
	}

	public String getScStatusName() {
		return scStatusName;
	}

	public void setScStatusName(String fpsdStatusName) {
		this.scStatusName = fpsdStatusName;
	}

	public int getFailRate() {
		return failRate;
	}

	public void setFailRate(int failRate) {
		this.failRate = failRate;
	}

	public int getMinQTY() {
		return minQTY;
	}

	public void setMinQTY(int minQTY) {
		this.minQTY = minQTY;
	}

	public int getMaxQTY() {
		return maxQTY;
	}

	public void setMaxQTY(int maxQTY) {
		this.maxQTY = maxQTY;
	}
	
	public float getFaRateDashboardChart() {
		return faRateDashboardChart;
	}

	public void setFaRateDashboardChart(float faRateDashboardChart) {
		this.faRateDashboardChart = faRateDashboardChart;
	}

	public float getFaRate() {
		return faRate;
	}

	public void setFaRate(float faRate) {
		this.faRate = faRate;
	}
	

}
