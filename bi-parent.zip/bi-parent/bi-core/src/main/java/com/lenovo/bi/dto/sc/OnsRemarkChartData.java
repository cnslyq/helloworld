package com.lenovo.bi.dto.sc;

import java.math.MathContext;
import java.math.RoundingMode;

public class OnsRemarkChartData {

	private int orderNum;
	private int orderQuantity;
	private int dimensionKey;
	private String dimensionName;
	
	MathContext mc = new MathContext(2, RoundingMode.HALF_UP);
	
	public int getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}
	
	public int getDimensionKey() {
		return dimensionKey;
	}
	public void setDimensionKey(int dimensionKey) {
		this.dimensionKey = dimensionKey;
	}
	public String getDimensionName() {
		return dimensionName;
	}
	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}
	public int getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	
	
	
}
