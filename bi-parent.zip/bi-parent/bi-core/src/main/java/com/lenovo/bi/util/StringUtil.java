package com.lenovo.bi.util;

import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;

import org.apache.commons.lang.StringUtils;

public class StringUtil {

	public static boolean isEmpty(String str) {
		if(str != null && !str.isEmpty())
			return false;
		else
			return true;
	}
	
	/**
	 * 右补位，左对齐
	 * @param oriStr 原字符串
	 * @param len 目标字符串长度
	 * @param alexin 补位字符
	 * @return 目标字符串
	 */
	public static String padRight(String oriStr,int len,char alexin){
		String str = "";
		int strlen = oriStr.length();
		if(strlen < len){
			for(int i=0;i<len-strlen;i++){
				str = str+alexin;
			}
		}
		str = oriStr + str;
		return str;
	}
	 
	/**
	 * 左补位，右对齐
	 * @param oriStr 原字符串
	 * @param len 目标字符串长度
	 * @param alexin 补位字符
	 * @return 目标字符串
	 */
	public static String padLeft(String oriStr,int len,char alexin){
		String str = "";
		int strlen = oriStr.length();
		if(strlen < len){
			for(int i=0;i<len-strlen;i++){
				str = str+alexin;
			}
		}
		str = str + oriStr;
		return str;
	}
	
	public static String float2String(float num){
		num = num*100;
		return new DecimalFormat("##.##").format(num)+"%";
	}
	
	 //首字母转大写
    public static String toUpperCaseFirstOne(String s)
    {
    	if(StringUtils.isBlank(s)){
    		return s;
    	}
        if(Character.isUpperCase(s.charAt(0)))
            return s;
        else
            return (new StringBuilder()).append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).toString();
    }
	
	public static void main(String[] args){
		String ss = "test";
		System.out.println(padLeft(ss,2,'0'));
	}
	/**
     * 全角转半角
     * @param input String.
     * @return 半角字符串
     */
	public static String toDBC(String input) {
        if(StringUtils.isBlank(input)){
        	return input;
        }
        try {
			input = new String(input.getBytes("ISO-8859-1"),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
        char c[] = input.toCharArray();
        for (int i = 0; i < c.length; i++) {
          if (c[i] == '\u3000') {
            c[i] = ' ';
          } else if (c[i] > '\uFF00' && c[i] < '\uFF5F') {
            c[i] = (char) (c[i] - 65248);

          }
        }
        String returnString = new String(c);
        return returnString;
	}
	
}
