package com.lenovo.bi.enumobj;

public enum LateOrderEnum {

	LATE_ORDER_L("5F9EA0");
	
	private String color;
	
	LateOrderEnum(){
		
	}
	
	LateOrderEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		return name();
	}
	
	public String getName(){
		return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}
}
