package com.lenovo.bi.enumobj;

import java.util.HashMap;
import java.util.Map;

public enum ForecastCommitTypeEnum {
	FIFTY_NINE("59"), // forecast and commit  
	FIFTY_NINE_PLUS_CV("59+CV"), // forecast
	MTM("MTM"), // forecast and commit
	MTM_PLUS_SBB("MTM+SBB"), // forecast
	CTO("CTO"), // forecast and commit
	CTO_PLUS_SBB("CTO+SBB"), // forecast
	CV("CV"), // commit
	SBB("SBB"); // commit
	
	private String value;
	
	private static Map<String, ForecastCommitTypeEnum> valueToEnumMap = new HashMap<String, ForecastCommitTypeEnum>();

	static {
		for (ForecastCommitTypeEnum type : ForecastCommitTypeEnum.values()) {
			valueToEnumMap.put(type.getValue(), type);
		}
	}
	
	private ForecastCommitTypeEnum(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	
	public static ForecastCommitTypeEnum getEnumFromValue(String value) {
		return valueToEnumMap.get(value);
	}
}
