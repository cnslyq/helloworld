package com.lenovo.bi.enumobj;

public enum OrderTypeEnum {

	PRC_BTP("PRC BTP"),
	
	PRC_BTO("PRC BTO"),
	PRC_BTS_FORWARD("PRC BTS/FORWARD"),
	WW_BTP("WW BTP"),
	WW_FORWARD("WW FORWARD"),
	WW_BTO_SEA("WW BTO SEA"),
	WW_BTO_AIR("WW BTO AIR"),
	//Defect 10757 modify by Dolly 2014-08-15
	FPSD("fpsd"),
	BPS("bps"),
	CA("CA"),
	FA("FA"),
	COMPONENTFA("COMPONENTFA");
	
	private String type;
	private OrderTypeEnum(String type) {
		this.type = type;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
