package com.lenovo.bi.dto.sc;

import java.util.Date;

public class DimOrderDtoExtension extends DimOrderDto {
	
	private String odm;
	private String geo;
	private String region;
	private String country;
	private String product;
	private String pn;
	private String itemDesc;
	private String poNumber;
	private Date orderDate;
	private Date rsd;
	private String fpsd;
	private Date targetDate;
	private Date shippedDate;
	private String shipped;
	private String level1;
	private String level2;
	public String getOdm() {
		return odm;
	}
	public void setOdm(String odm) {
		this.odm = odm;
	}
	public String getGeo() {
		return geo;
	}
	public void setGeo(String geo) {
		this.geo = geo;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getPn() {
		return pn;
	}
	public void setPn(String pn) {
		this.pn = pn;
	}
	public String getItemDesc() {
		return itemDesc;
	}
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Date getRsd() {
		return rsd;
	}
	public void setRsd(Date rsd) {
		this.rsd = rsd;
	}
	public String getFpsd() {
		return fpsd;
	}
	public void setFpsd(String fpsd) {
		this.fpsd = fpsd;
	}
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	public Date getShippedDate() {
		return shippedDate;
	}
	public void setShippedDate(Date shippedDate) {
		this.shippedDate = shippedDate;
	}
	public String getShipped() {
		return shipped;
	}
	public void setShipped(String shipped) {
		this.shipped = shipped;
	}
	public String getLevel1() {
		return level1;
	}
	public void setLevel1(String level1) {
		this.level1 = level1;
	}
	public String getLevel2() {
		return level2;
	}
	public void setLevel2(String level2) {
		this.level2 = level2;
	}
	
	

}
