package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BI_SGATTVWeeklySummary")
public class SGATtvWeeklySummary {
	@Id
	@GeneratedValue
	@Column
	private int ttvWeeklySummaryId;
	
	@Column
	private int pmsWaveId;
	
	@Column
	private float ttvOdm;
	
	@Column
	private float ttvTdms;
	
	@Column
	private int accumulatedDemand;
	
	@Column
	private int weeklyCapacityOdm;
	
	@Column
	private int weeklyCapacityTdms;
	
	@Column
	private int accumulatedCapacityOdm;
	
	@Column
	private int accumulatedCapacityTdms;
	
	@Column
	private int weeklyGapOdm;
	
	@Column
	private int weeklyGapTdms;
	
	@Column
	private int totalWeeklyGapOdm;
	
	@Column
	private int totalWeeklyGapTdms;
	
	@Column
	private Date targetDate;
	
	@Column
	private Date versionDate;
	
	@Column
	private Date createdDate;
	
	@Column
	private Date lastModifiedDate;

	public int getTtvWeeklySummaryId() {
		return ttvWeeklySummaryId;
	}

	public void setTtvWeeklySummaryId(int ttvWeeklySummaryId) {
		this.ttvWeeklySummaryId = ttvWeeklySummaryId;
	}

	public int getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(int pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public float getTtvOdm() {
		return ttvOdm;
	}

	public void setTtvOdm(float ttvOdm) {
		this.ttvOdm = ttvOdm;
	}

	public float getTtvTdms() {
		return ttvTdms;
	}

	public void setTtvTdms(float ttvTdms) {
		this.ttvTdms = ttvTdms;
	}

	public int getAccumulatedDemand() {
		return accumulatedDemand;
	}

	public void setAccumulatedDemand(int accumulatedDemand) {
		this.accumulatedDemand = accumulatedDemand;
	}	

	public int getWeeklyCapacityOdm() {
		return weeklyCapacityOdm;
	}

	public void setWeeklyCapacityOdm(int weeklyCapacityOdm) {
		this.weeklyCapacityOdm = weeklyCapacityOdm;
	}

	public int getWeeklyCapacityTdms() {
		return weeklyCapacityTdms;
	}

	public void setWeeklyCapacityTdms(int weeklyCapacityTdms) {
		this.weeklyCapacityTdms = weeklyCapacityTdms;
	}

	public int getAccumulatedCapacityOdm() {
		return accumulatedCapacityOdm;
	}

	public void setAccumulatedCapacityOdm(int accumulatedCapacityOdm) {
		this.accumulatedCapacityOdm = accumulatedCapacityOdm;
	}

	public int getAccumulatedCapacityTdms() {
		return accumulatedCapacityTdms;
	}

	public void setAccumulatedCapacityTdms(int accumulatedCapacityTdms) {
		this.accumulatedCapacityTdms = accumulatedCapacityTdms;
	}

	public int getWeeklyGapOdm() {
		return weeklyGapOdm;
	}

	public void setWeeklyGapOdm(int weeklyGapOdm) {
		this.weeklyGapOdm = weeklyGapOdm;
	}

	public int getWeeklyGapTdms() {
		return weeklyGapTdms;
	}

	public void setWeeklyGapTdms(int weeklyGapTdms) {
		this.weeklyGapTdms = weeklyGapTdms;
	}

	public int getTotalWeeklyGapOdm() {
		return totalWeeklyGapOdm;
	}

	public void setTotalWeeklyGapOdm(int totalWeeklyGapOdm) {
		this.totalWeeklyGapOdm = totalWeeklyGapOdm;
	}

	public int getTotalWeeklyGapTdms() {
		return totalWeeklyGapTdms;
	}

	public void setTotalWeeklyGapTdms(int totalWeeklyGapTdms) {
		this.totalWeeklyGapTdms = totalWeeklyGapTdms;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	
	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String toString() {
		return "TtvWeeklySummary [ttvWeeklySummaryId=" + ttvWeeklySummaryId
				+ ", pmsWaveId=" + pmsWaveId + ", ttvOdm=" + ttvOdm
				+ ", ttvTdms=" + ttvTdms + ", accumulatedDemand="
				+ accumulatedDemand + ", weeklyCapacityOdm="
				+ weeklyCapacityOdm + ", weeklyCapacityTdms="
				+ weeklyCapacityTdms + ", accumulatedCapacityOdm="
				+ accumulatedCapacityOdm + ", accumulatedCapacityTdms="
				+ accumulatedCapacityTdms + ", weeklyGapOdm=" + weeklyGapOdm
				+ ", weeklyGapTdms=" + weeklyGapTdms + ", totalWeeklyGapOdm="
				+ totalWeeklyGapOdm + ", totalWeeklyGapTdms="
				+ totalWeeklyGapTdms + ", targetDate=" + targetDate
				+ ", versionDate=" + versionDate + ", createdDate="
				+ createdDate + ", lastModifiedDate=" + lastModifiedDate + "]";
	}
		
	
}
