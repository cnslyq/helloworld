package com.lenovo.bi.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

public class ExcelConfig {

	// 设置cell编码解决中文高位字节截断
	// private static short XLS_ENCODING = HSSFWorkbook.;

	// 定制日期格式
	public static String DATE_FORMAT = " m/d/yy "; // "m/d/yy h:mm"

	// 定制浮点数格式
	public static String NUMBER_FORMAT = " #,##0.00 ";

	public String xlsFileName;

	public HSSFWorkbook workbook;

	public HSSFSheet sheet;

	public HSSFRow row;

	/**
	 * 初始化Excel
	 * 
	 * @param fileName
	 *            导出文件名
	 */
	public ExcelConfig(String fileName) {
		this.xlsFileName = fileName;
		this.workbook = new HSSFWorkbook();
		this.sheet = workbook.createSheet();
		this.sheet.autoSizeColumn((short)0);
		this.sheet.autoSizeColumn((short)1);
		this.sheet.autoSizeColumn((short)2);
		this.sheet.autoSizeColumn((short)3);
		this.sheet.autoSizeColumn((short)4);
		this.sheet.autoSizeColumn((short)5);
		this.sheet.autoSizeColumn((short)6);
		this.sheet.autoSizeColumn((short)7);
		this.sheet.autoSizeColumn((short)8);
		this.sheet.autoSizeColumn((short)9);
		this.sheet.autoSizeColumn((short)10);
		this.sheet.autoSizeColumn((short)11);
		this.sheet.autoSizeColumn((short)12);
		this.sheet.autoSizeColumn((short)13);
		this.sheet.autoSizeColumn((short)14);
		this.sheet.autoSizeColumn((short)15);
	}
	
	/**
	 * 初始化Excel
	 * 
	 * @param fileName
	 *            导出文件名
	 */
	public ExcelConfig() {
		this.workbook = new HSSFWorkbook();
		this.sheet = workbook.createSheet();
		this.sheet.autoSizeColumn((short)0);
		this.sheet.autoSizeColumn((short)1);
		this.sheet.autoSizeColumn((short)2);
		this.sheet.autoSizeColumn((short)3);
		this.sheet.autoSizeColumn((short)4);
		this.sheet.autoSizeColumn((short)5);
		this.sheet.autoSizeColumn((short)6);
	}

	/**
	 * 导出Excel文件
	 * 
	 * @throws XLSException
	 */
	public void exportXLS() throws Exception {
		try {
			FileOutputStream fOut = new FileOutputStream(xlsFileName);
			workbook.write(fOut);
			fOut.flush();
			fOut.close();
		} catch (FileNotFoundException e) {
			throw new Exception(" 生成导出Excel文件出错! ", e);
		} catch (IOException e) {
			throw new Exception(" 写入Excel文件出错! ", e);
		}

	}

	/**
	 * 增加一行
	 * 
	 * @param index
	 *            行号
	 */
	public void createRow(int index) {
		if(index < Short.MAX_VALUE){
			this.row = this.sheet.createRow(index);
		}
	}

	/**
	 * 设置表头单元格
	 * 
	 * @param index
	 *            列号
	 * @param value
	 *            单元格填充值
	 */
	public void setHeadCell(int index, String value) {
		HSSFCell cell = this.row.createCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		
		// 设置字体   
	    HSSFFont headFont = workbook.createFont();   
	    //headFont.setFontName("黑体");
	    headFont.setColor(HSSFColor.WHITE.index);
	    headFont.setFontHeightInPoints((short) 10);// 字体大小   
	    headFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);// 加粗   
	    // 设置样式   
	    HSSFCellStyle headStyle = workbook.createCellStyle();
	    headStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	    headStyle.setFillForegroundColor(HSSFColor.DARK_TEAL.index);
	    headStyle.setFillBackgroundColor(HSSFColor.DARK_TEAL.index);
	    cell.setCellStyle(headStyle);
	    headStyle.setFont(headFont);   
	    headStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);// 左右居中   
	    headStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_BOTTOM);// 靠底居中   
	    //headStyle.setLocked(true);   
	    headStyle.setWrapText(true);// 自动换行 
	    
	    cell.setCellValue(value);
		cell.setCellStyle(headStyle);
	}
	
	/**
	 * 设置单元格
	 * 
	 * @param index
	 *            列号
	 * @param value
	 *            单元格填充值
	 */
	public void setCell(int index, String value) {
		HSSFCell cell = this.row.createCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	    cell.setCellValue(value);
	}

	
	/**
	 * 设置单元格
	 * 
	 * @param index
	 *            列号
	 * @param value
	 *            单元格填充值
	 */
	public void setCell(int index, Calendar value) {
		HSSFCell cell = this.row.createCell(index);
		// cell.setEncoding(XLS_ENCODING);
		cell.setCellValue(value.getTime());
		HSSFCellStyle cellStyle = workbook.createCellStyle(); // 建立新的cell样式
		cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat(DATE_FORMAT)); // 设置cell样式为定制的日期格式
		cell.setCellStyle(cellStyle); // 设置该cell日期的显示格式
	}

	/**
	 * 设置单元格
	 * 
	 * @param index
	 *            列号
	 * @param value
	 *            单元格填充值
	 */
	public void setCell(int index, int value) {
		HSSFCell cell = this.row.createCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);
	}

	public void setCell(int index, long value) {
		HSSFCell cell = this.row.createCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);
	}
	
	/**
	 * 设置单元格
	 * 
	 * @param index
	 *            列号
	 * @param value
	 *            单元格填充值
	 */
	public void setCell(int index, double value) {
		HSSFCell cell = this.row.createCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);
		HSSFCellStyle cellStyle = workbook.createCellStyle(); // 建立新的cell样式
		HSSFDataFormat format = workbook.createDataFormat();
		cellStyle.setDataFormat(format.getFormat(NUMBER_FORMAT)); // 设置cell样式为定制的浮点数格式
		cell.setCellStyle(cellStyle); // 设置该cell浮点数的显示格式
	}
	
	/**
	 * 设置单元格
	 * 
	 * @param index
	 *            列号
	 * @param value
	 *            单元格填充值
	 */
	public void setPercentCell(int index, String value ,HSSFCellStyle cellStyle) {
		HSSFCell cell = this.row.createCell(index);
		// = workbook.createCellStyle(); // 建立新的cell样式
		cell.setCellStyle(cellStyle); // 设置该cell浮点数的显示格式
		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		cell.setCellValue(Double.parseDouble(value));
	}
	
	//------------------------下面的这些方法用来生成各种报表模板的通用方法----------------------//
	/**
	 * 设定报表列宽
	 * @param xlsExport
	 * @param cols
	 * @param width
	 * @param map
	 * @param otherWidth
	 */
	public void setCellWidth(ExcelConfig xlsExport,int cols,int width,Map<String,Integer> map, int otherWidth) {
		for(int i=0; i<=cols; i++) {
			if(map.containsKey(i + "")) {
				xlsExport.sheet.setColumnWidth(i, otherWidth);
			}
			else {
				xlsExport.sheet.setColumnWidth(i, width);
			}
		}
	}
	
	
	/**
	 * 生成header
	 * @param xlsExport
	 * @param row
	 * @param map
	 * @param cols
	 */
	public void generateHeader(ExcelConfig xlsExport,int row,Map<String,String> map,int cols) {
		xlsExport.createRow(row);
		for(int i=0; i<=cols; i++) {
			if(map.containsKey(i + "")) {
				xlsExport.setHeadCell(i,map.get(i+""));
			}
			
		}
	}
	
	
	
}