package com.lenovo.bi.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.util.CellRangeAddress;

public class ExcelUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		String path = "D:/exceltest/Report" + ".xls";
		ExcelConfig xlsConfig = new ExcelConfig(path);
		generateGroupExcel(xlsConfig);
		try {
			xlsConfig.exportXLS();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public static void generateGroupExcel(ExcelConfig xlsConfig) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "Group Name");
		map.put("1", "Created By");
		map.put("2", "Created Date");
		xlsConfig.generateHeader(xlsConfig, 0, map, 3);

	}
	
	public static void generateGroupPrivilegeExcel(ExcelConfig xlsConfig,List<String> groupList) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "Privilege");
		map.put("1", "Description");
		
		for(int i=0; i<groupList.size(); i++) {
			map.put(i+2+"", groupList.get(i));
		}
		
		xlsConfig.generateHeader(xlsConfig, 0, map, groupList.size() + 2);

	}
	
	public static void generateOrderDetailExcelHead(ExcelConfig xlsConfig) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "ODM");
		map.put("1", "GEO");
		map.put("2", "Region");
		map.put("3", "Country");
		map.put("4", "Product");
		map.put("5", "59 P/N");
		map.put("6", "Item_Description");
		map.put("7", "PO#");
		map.put("8", "PO item#");
		map.put("9", "QTY");
		map.put("10", "Order Date");
		map.put("11", "RSD");
		map.put("12", "FPSD");
		map.put("13", "Target Date");
		map.put("14", "Shipped Date");
		map.put("15", "Detractor Code");
		map.put("16", "");
		map.put("17", "");
		xlsConfig.generateHeader(xlsConfig, 0, map, 17);
		
		Map<String, String> map2 = new HashMap<String, String>();
		map2.put("0", "");
		map2.put("1", "");
		map2.put("2", "");
		map2.put("3", "");
		map2.put("4", "");
		map2.put("5", "");
		map2.put("6", "");
		map2.put("7", "");
		map2.put("8", "");
		map2.put("9", "");
		map2.put("10", "");
		map2.put("11", "");
		map2.put("12", "");
		map2.put("13", "");
		map2.put("14", "");
		map2.put("15", "Level 1");
		map2.put("16", "Level 2");
		map2.put("17", "Level 3");
		xlsConfig.generateHeader(xlsConfig, 1, map2, 17);
		
		xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 0, 15, 17));
		for (int i=0;i<=14;i++){
			xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));
		}
		
	}
	
	public static void generateLtfcOrderDetailExcelHead(ExcelConfig xlsConfig,String ltfcType) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "Month");
		map.put("1", "ODM");
		map.put("2", "Family");
		map.put("3", "Product");
		map.put("4", "LTFC");
		map.put("5", "Order");
		map.put("6", "MPS Forecast");
		if("Mps".equals(ltfcType)){
			map.put("7", "Root Cause(.Vs Mps)");
			map.put("8", "LTFC VS Mps");
		}else{
			map.put("7", "Root Cause(.Vs Order)");
			map.put("8", "LTFC VS Order");
		}
		
		xlsConfig.generateHeader(xlsConfig, 0, map, 8);
		//xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 0, 15, 17));
					//i是标题个数
		for (int i=0;i<=8;i++){
			xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));
		}
		
	}
	
	//FA Detail
	public static void FADetailExcelHead(ExcelConfig xlsConfig,String faType) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "Month");
		map.put("1", "Geo");
		map.put("2", "Region");
		map.put("3", "odm");
		map.put("4", "Family");
		map.put("5", "Product");
		if("Mps".equals(faType)){
			map.put("6", "MPS");
		}else if("GrossForecast".equals(faType)){
			map.put("6", "GrossForecast");
		}
		map.put("7", "OrderQty");
		map.put("8", "Root Cause");
		
		xlsConfig.generateHeader(xlsConfig, 0, map, 8);
		//xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 0, 15, 17));
					//i是标题个数
		for (int i=0;i<=8;i++){
			xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));
		}
	}
	
	//ComponentFA Detail
	public static void ComponentFADetailExcelHead(ExcelConfig xlsConfig,String componentType) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "Month");
		map.put("1", "Geo");
		map.put("2", "Region");
		map.put("3", "odm");
		map.put("4", "Family");
		map.put("5", "Product");
		map.put("6", "Component");
		map.put("7", "CV");
		if("Mps".equals(componentType)){
			map.put("8", "MPS");
		}else if("GrossForecast".equals(componentType)){
			map.put("8", "GrossForecast");
		}
		map.put("9", "OrderQty");
		map.put("10", "Root Cause");
		
		xlsConfig.generateHeader(xlsConfig, 0, map, 10);
		//xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 0, 15, 17));
					//i是标题个数
		for (int i=0;i<=10;i++){
			xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));
		}
	}
	
	//Generate SBB detail head
	public static void generateSBBDetailExcelHead(ExcelConfig xlsConfig) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 31, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "Current Date");
		map.put("1", "EOL Date");
		map.put("2", "Product");
		map.put("3", "Region");
		map.put("4", "SBB");
		map.put("5", "Demand Status");
		map.put("6", "Final Liability");
		map.put("7", "Original Liability");
		map.put("8", "Liability above Pre Lock");
		map.put("9", "Act Input(EOL Date — " + new SimpleDateFormat("yyyy/MM/dd").format(CalendarUtil.addDays(new Date(), -1)) + ")");
		map.put("10", "Open Order");
		map.put("11", "Left to Build");
		map.put("12", "Left to Sell");
		map.put("13", "Daily Running Rate");
		map.put("14", "Projected Cons. Date");
		map.put("15", "PSD Shipment Rest");
		map.put("16", "PSD Shipment Last13wk");
		map.put("17", "WK0 PSD Shipment");
		map.put("18", "WK1 PSD Shipment");
		map.put("19", "WK2 PSD Shipment");
		map.put("20", "WK3 PSD Shipment");
		map.put("21", "WK4 PSD Shipment");
		map.put("22", "WK5 PSD Shipment");
		map.put("23", "WK6 PSD Shipment");
		map.put("24", "WK7 PSD Shipment");
		map.put("25", "WK8 PSD Shipment");
		map.put("26", "WK9 PSD Shipment");
		map.put("27", "WK10 PSD Shipment");
		map.put("28", "WK11 PSD Shipment");
		map.put("29", "WK12 PSD Shipment");
		map.put("30", "WK13 PSD Shipment");
		
		xlsConfig.generateHeader(xlsConfig, 0, map, 30);
	}
	
	public static void generateBpsDetailExcelHead(ExcelConfig xlsConfig) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "ODM");
		map.put("1", "GEO");
		map.put("2", "Region");
		map.put("3", "Product");
		map.put("4", "Parts");
		map.put("5", "Commodity");
		map.put("6", "PurchaseType");
		map.put("7", "59 P/N");
		map.put("8", "Description");
		map.put("9", "CVShortage");
		map.put("10", "Classification");
		map.put("11", "Supply");
		
		xlsConfig.generateHeader(xlsConfig, 0, map, 11);
		
		Map<String, String> map2 = new HashMap<String, String>();
		map2.put("0", "");
		map2.put("1", "");
		map2.put("2", "");
		map2.put("3", "");
		map2.put("4", "");
		map2.put("5", "");
		map2.put("6", "");
		map2.put("7", "");
		map2.put("8", "");
		map2.put("9", "");
		map2.put("10", "");
		map2.put("11", "");
		
		xlsConfig.generateHeader(xlsConfig, 1, map2, 11);
		
		//xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 0, 15, 17));
		for (int i=0;i<=11;i++){
			xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));
		}
		
	}
	
	public static void generateMWDDetailExcelHead(ExcelConfig xlsConfig) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "GEO");
		map.put("1", "Region");
		map.put("2", "ODM");
		map.put("3", "Product");
		map.put("4", "PurchaseType");
		map.put("5", "Commodity");
		map.put("6", "Description");
		map.put("7", "EOL");
		map.put("8", "Highlight Date");
		map.put("9", "Aging");
		map.put("10", "MWD");
		map.put("11", "Remark");
		xlsConfig.generateHeader(xlsConfig, 0, map, 11);
		
		Map<String, String> map2 = new HashMap<String, String>();
		map2.put("0", "");
		map2.put("1", "");
		map2.put("2", "");
		map2.put("3", "");
		map2.put("4", "");
		map2.put("5", "");
		map2.put("6", "");
		map2.put("7", "");
		map2.put("8", "");
		map2.put("9", "");
		map2.put("10", "");
		map2.put("11", "");
		xlsConfig.generateHeader(xlsConfig, 1, map2, 11);
		
		//xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 0, 15, 17));
		for (int i=0;i<=11;i++){
			xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));
		}
		
	}
	
	public static void generateFactDetailExcelHead(ExcelConfig xlsConfig) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "Version");
		map.put("1", "Site");
		map.put("2", "Classification");
		map.put("3", "Project1");
		map.put("4", "Project2");
		map.put("5", "Commodity");
		map.put("6", "Description");
		map.put("7", "59 P/N");
		map.put("8", "Description");
		map.put("9", "RealOrderShortage");
		map.put("10", "LastModifiedDate");
		map.put("11", "Supply");
		
		xlsConfig.generateHeader(xlsConfig, 0, map, 11);
		
		Map<String, String> map2 = new HashMap<String, String>();
		map2.put("0", "");
		map2.put("1", "");
		map2.put("2", "");
		map2.put("3", "");
		map2.put("4", "");
		map2.put("5", "");
		map2.put("6", "");
		map2.put("7", "");
		map2.put("8", "");
		map2.put("9", "");
		map2.put("10", "");
		map2.put("11", "");
		
		xlsConfig.generateHeader(xlsConfig, 1, map2, 11);
		
		//xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 0, 15, 17));
		for (int i=0;i<=11;i++){
			xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));
		}
		
	}
	
	public static void generateDetractorOrderExcelHead(ExcelConfig xlsConfig) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "ODM");
		map.put("1", "GEO");
		map.put("2", "Region");
		map.put("3", "Country");
		map.put("4", "Series");
		map.put("5", "59 P/N");
		map.put("6", "Item_Description");
		map.put("7", "PO#");
		map.put("8", "QTY");
		map.put("9", "Order Date");
		map.put("10", "RSD");
		map.put("11", "FPSD");
		map.put("12", "Target Date");
		map.put("13", "Shipped Date");
		map.put("14", "Shipped");
		map.put("15", "Detractor Code");
		map.put("16", "");
		map.put("17", "");
		xlsConfig.generateHeader(xlsConfig, 0, map, 17);
		
		Map<String, String> map2 = new HashMap<String, String>();
		map2.put("0", "");
		map2.put("1", "");
		map2.put("2", "");
		map2.put("3", "");
		map2.put("4", "");
		map2.put("5", "");
		map2.put("6", "");
		map2.put("7", "");
		map2.put("8", "");
		map2.put("9", "");
		map2.put("10", "");
		map2.put("11", "");
		map2.put("12", "");
		map2.put("13", "");
		map2.put("14", "");
		map2.put("15", "Level 1");
		map2.put("16", "Level 2");
		map2.put("17", "Level 3");
		xlsConfig.generateHeader(xlsConfig, 1, map2, 17);
		
		xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 0, 15, 17));
		for (int i=0;i<=14;i++){
			xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));
		}
	}
	
	public static void generateCaMfgOrderDetailExcelHead(ExcelConfig xlsConfig, boolean isShowTarget) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "Month");
		map.put("1", "GEO");
		map.put("2", "Region");
		map.put("3", "Product");
		map.put("4", "Commitment");
		map.put("5", "Total Order QTY");
		map.put("6", "Actual Shipment");
		map.put("7", "Commited Backlog");
		map.put("8", "Risk Order");
		map.put("9", "GAP");
		if(isShowTarget) {
			map.put("10", "CA Target");
			map.put("11", "Target Balance");
			xlsConfig.generateHeader(xlsConfig, 0, map, 11);
		}
		else
			xlsConfig.generateHeader(xlsConfig, 0, map, 9);
		
		Map<String, String> map2 = new HashMap<String, String>();
		map2.put("0", "");
		map2.put("1", "");
		map2.put("2", "");
		map2.put("3", "");
		map2.put("4", "");
		map2.put("5", "");
		map2.put("6", "");
		map2.put("7", "");
		map2.put("8", "");
		map2.put("9", "");
		if(isShowTarget) {
			map2.put("10", "");
			map2.put("11", "");
			xlsConfig.generateHeader(xlsConfig, 1, map2, 11);
		}
		else
			xlsConfig.generateHeader(xlsConfig, 1, map2, 9);
	}
	
	public static void generateCommitmentOrderDetailExcelHead(ExcelConfig xlsConfig, boolean isShowTarget) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "Month");
		map.put("1", "GEO");
		map.put("2", "Region");
		map.put("3", "Product");
		map.put("4", "Commitment");
		xlsConfig.generateHeader(xlsConfig, 0, map, 4);
		
		Map<String, String> map2 = new HashMap<String, String>();
		map2.put("0", "");
		map2.put("1", "");
		map2.put("2", "");
		map2.put("3", "");
		map2.put("4", "");
		xlsConfig.generateHeader(xlsConfig, 1, map2, 4);
	}
	
	public static void generateCaSalesOrderDetailExcelHead(ExcelConfig xlsConfig, boolean isShowTarget) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "Month");
		map.put("1", "GEO");
		map.put("2", "Region");
		map.put("3", "Product");
		map.put("4", "Actual Shipment");
		if(isShowTarget) {
			map.put("5", "CA Target");
			map.put("6", "Target Balance");
			xlsConfig.generateHeader(xlsConfig, 0, map, 6);
		}
		else
			xlsConfig.generateHeader(xlsConfig, 0, map, 4);
		
		Map<String, String> map2 = new HashMap<String, String>();
		map2.put("0", "");
		map2.put("1", "");
		map2.put("2", "");
		map2.put("3", "");
		map2.put("4", "");
		if(isShowTarget) {
			map2.put("5", "");
			map2.put("6", "");
			xlsConfig.generateHeader(xlsConfig, 1, map2, 6);
		}
		else
			xlsConfig.generateHeader(xlsConfig, 1, map2, 4);
	}

	public static void generateFlexibilityOrderDetailExcelHead(ExcelConfig xlsConfig,String remarkDimension) {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		xlsConfig.setCellWidth(xlsConfig, 14, 5800, map1, 6000);

		Map<String, String> map = new HashMap<String, String>();
		
		if("Product".equals(remarkDimension)||"Family".equals(remarkDimension)){
			map.put("0", "Family");
			map.put("1", "Product");
			map.put("2", "Shipment");
			map.put("3", "CW Order");
			map.put("4", "CW Commit");
			map.put("5", "60DMD");
			map.put("6", "A");
			map.put("7", "B");
			map.put("8", "C");
			map.put("9", "SF");
			
			xlsConfig.generateHeader(xlsConfig, 0, map, 9);
			
			for (int i=0;i<=9;i++){
				xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));//第0行,第i列和第1行,第i列合并
			}
		}
		
		if("Region".equals(remarkDimension)){
			map.put("0", "Geo");
			map.put("1", "Region");
			map.put("2", "Product");
			map.put("3", "Shipment");
			map.put("4", "CW Order");
			map.put("5", "CW Commit");
			map.put("6", "60DMD");
			map.put("7", "A");
			map.put("8", "B");
			map.put("9", "C");
			map.put("10", "SF");
			xlsConfig.generateHeader(xlsConfig, 0, map, 10);
			for (int i=0;i<=10;i++){
				xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));//第0行,第i列和第1行,第i列合并
			}
		}
		
		if("Geo".equals(remarkDimension)){
			map.put("0", "Geo");
			map.put("1", "Product");
			map.put("2", "Shipment");
			map.put("3", "CW Order");
			map.put("4", "CW Commit");
			map.put("5", "60DMD");
			map.put("6", "A");
			map.put("7", "B");
			map.put("8", "C");
			map.put("9", "SF");
			xlsConfig.generateHeader(xlsConfig, 0, map, 9);
			for (int i=0;i<=9;i++){
				xlsConfig.sheet.addMergedRegion(new CellRangeAddress(0, 1, i, i));//第0行,第i列和第1行,第i列合并
			}
		}
		
//		Map<String, String> map2 = new HashMap<String, String>();
//		map2.put("0", "");
//		map2.put("1", "");
//		map2.put("2", "");
//		map2.put("3", "");
//		map2.put("4", "");
//		map2.put("5", "");
//		map2.put("6", "");
//		map2.put("7", "");
//		map2.put("8", "");
//		
//		xlsConfig.generateHeader(xlsConfig, 1, map2, 8);
	}

}
