package com.lenovo.bi.dto;

public class ProductMinMaxQty {
	private String productKey;
	private int mps;
	private int minQty;
	private int maxQty;
	private float hitRate;
	private float weight;
	
	public String getProductKey() {
		return productKey;
	}
	
	public void setProductKey(Integer productKey) {
		this.productKey = Integer.toString(productKey);
	}
	
	public int getMps() {
		return mps;
	}
	public void setMps(int mps) {
		this.mps = mps;
	}
	public int getMinQty() {
		return minQty;
	}
	public void setMinQty(int minQty) {
		this.minQty = minQty;
	}
	public int getMaxQty() {
		return maxQty;
	}
	public void setMaxQty(int maxQty) {
		this.maxQty = maxQty;
	}
	public float getHitRate() {
		return hitRate;
	}
	public void setHitRate(float hitRate) {
		this.hitRate = hitRate;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
}
