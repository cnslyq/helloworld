package com.lenovo.bi.dto;

public class GeoData {
	
	private Integer geographyKey;
	private String geographyName;
	private String geographyType;
	private String parentGeo;
	
	public Integer getGeographyKey() {
		return geographyKey;
	}
	public void setGeographyKey(Integer geographyKey) {
		this.geographyKey = geographyKey;
	}
	public String getGeographyName() {
		return geographyName;
	}
	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}
	public String getGeographyType() {
		return geographyType;
	}
	public void setGeographyType(String geographyType) {
		this.geographyType = geographyType;
	}
	public String getParentGeo() {
		return parentGeo;
	}
	public void setParentGeo(String parentGeo) {
		this.parentGeo = parentGeo;
	}
	
}
