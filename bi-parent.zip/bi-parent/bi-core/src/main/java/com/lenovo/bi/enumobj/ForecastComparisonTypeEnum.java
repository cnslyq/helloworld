package com.lenovo.bi.enumobj;

public enum ForecastComparisonTypeEnum {
	DOWNSIDE, UPSIDE, OFFSET;
	
	public static ForecastComparisonTypeEnum fromValue(String value){
		return ForecastComparisonTypeEnum.valueOf(value.toUpperCase());
	}
}
