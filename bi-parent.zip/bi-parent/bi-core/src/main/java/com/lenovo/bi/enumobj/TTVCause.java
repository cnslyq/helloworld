package com.lenovo.bi.enumobj;
/**
 * 
 * 
 * @author henry_lian
 *
 */
public enum TTVCause {
	
	order_offset("Order Offset", "pcs"),
	order_upside("Order Upside", "pcs"),
	forecast_offset("Forecast Offset","pcs"),
	forecast_upside("Forecast Upside","pcs"),
	tooling("Tooling Shortage", "pcs"),
	odm("ODM Shortage", "pcs"),
	supply("Supply Shortage", "pcs");
	
	private String cause;
	private String unit;
	
	TTVCause(String cause, String unit){
		this.cause = cause;
		this.unit = unit;
	}

	public String getCause() {
		return cause;
	}

	public void setCause(String cause) {
		this.cause = cause;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}
	
}
