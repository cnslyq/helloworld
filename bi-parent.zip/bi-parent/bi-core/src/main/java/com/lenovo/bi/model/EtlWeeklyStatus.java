package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BI_ETLWeeklyStatus")
public class EtlWeeklyStatus {
	@Id
	@GeneratedValue
	private int etlWeeklyStatusId;
	
	@Column
	private Date versionDate;
	
	@Column
	private Date processDate;
	
	@Column 
	private boolean complete;

	public int getEtlWeeklyStatusId() {
		return etlWeeklyStatusId;
	}

	public void setEtlWeeklyStatusId(int etlWeeklyStatusId) {
		this.etlWeeklyStatusId = etlWeeklyStatusId;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Date getProcessDate() {
		return processDate;
	}

	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}

	public boolean getComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}
	
	
}
