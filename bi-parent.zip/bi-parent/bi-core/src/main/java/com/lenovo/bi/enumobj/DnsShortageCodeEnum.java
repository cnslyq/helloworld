package com.lenovo.bi.enumobj;

import java.util.HashMap;
import java.util.Map;

public enum DnsShortageCodeEnum {
	NO_SHORTAGE("No Shortage"),
	SHORTAGE("Shortage"),
	TIMING_ISSUE("Timing Issue");
	
	private String value;
	
	private static Map<String, DnsShortageCodeEnum> valueToEnumMap = new HashMap<String, DnsShortageCodeEnum>();
	
	static {
		for (DnsShortageCodeEnum code : DnsShortageCodeEnum.values()) {
			valueToEnumMap.put(code.getValue(), code);
		}
	}
	
	private DnsShortageCodeEnum(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	
	public static DnsShortageCodeEnum getEnumFromValue(String value) {
		return valueToEnumMap.get(value);
	}
}
