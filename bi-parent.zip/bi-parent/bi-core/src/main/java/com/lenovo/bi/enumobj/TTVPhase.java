package com.lenovo.bi.enumobj;
/**
 * 
 * 
 * @author henry_lian
 *
 */
public enum TTVPhase {
	sga,sle
}
