package com.lenovo.bi.enumobj;

public enum CapacityCausesEnum {

	ODM_Capacity("0000ff"),//橙黄
	Supply_Capacity("0000ff"),//橙黄
	Tooling_Capacity("0000ff"),//橙黄
	Offset_Order("cc99ff"),//紫色
	Upside_Order("ff6633"),//桔黄
	Offset_Forecast("0066cc"),//浅蓝
	Upside_Forecast("cccccc");//灰色
	
	private String color;
	
	CapacityCausesEnum(){
		
	}
	
	CapacityCausesEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		if(name().equals("MFG_Quality") || name().equals("NEW_Working"))
			return name().replaceAll("_", "/");
		else
			return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}
}
