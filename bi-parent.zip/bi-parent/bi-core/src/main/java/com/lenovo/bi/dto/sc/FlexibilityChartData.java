package com.lenovo.bi.dto.sc;

import java.math.MathContext;
import java.math.RoundingMode;

public class FlexibilityChartData {
	private int productKey;
	
	private int orderNum;
	private int orderQuantity;
	private int dimensionKey;
	private String dimensionName;
	
	private Integer commitQty;
	private Integer shipmentQty;
	private Integer orderQty;
	private Integer stockForecastQty;// 60DMD
	
	private Float flexibility;
	private Integer subDimensionKey;
	private String subDimesnionName;
	
	MathContext mc = new MathContext(2, RoundingMode.HALF_UP);
	
	public int getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}
	
	public int getDimensionKey() {
		return dimensionKey;
	}
	public void setDimensionKey(int dimensionKey) {
		this.dimensionKey = dimensionKey;
	}
	public String getDimensionName() {
		return dimensionName;
	}
	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}
	public int getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	public Integer getCommitQty() {
		return commitQty;
	}
	public void setCommitQty(Integer commitQty) {
		this.commitQty = commitQty;
	}
	public Integer getShipmentQty() {
		return shipmentQty;
	}
	public void setShipmentQty(Integer shipmentQty) {
		this.shipmentQty = shipmentQty;
	}
	public Integer getOrderQty() {
		return orderQty;
	}
	public void setOrderQty(Integer orderQty) {
		this.orderQty = orderQty;
	}
	public Integer getStockForecastQty() {
		return stockForecastQty;
	}
	public void setStockForecastQty(Integer stockForecastQty) {
		this.stockForecastQty = stockForecastQty;
	}
	public Float getFlexibility() {
		return flexibility;
	}
	public void setFlexibility(Float flexibilityByDimesion) {
		this.flexibility = flexibilityByDimesion;
	}
	public Integer getSubDimensionKey() {
		return subDimensionKey;
	}
	public void setSubDimensionKey(Integer subDimensionKey) {
		this.subDimensionKey = subDimensionKey;
	}
	public String getSubDimesnionName() {
		return subDimesnionName;
	}
	public void setSubDimesnionName(String subDimesnionName) {
		this.subDimesnionName = subDimesnionName;
	}
	public int getProductKey() {
		return productKey;
	}
	public void setProductKey(int productKey) {
		this.productKey = productKey;
	}
	
	
}
