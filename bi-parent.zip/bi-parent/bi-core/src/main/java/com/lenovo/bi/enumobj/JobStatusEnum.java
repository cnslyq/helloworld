package com.lenovo.bi.enumobj;

public enum JobStatusEnum {
	COMPLETE, RUNNING, FAILED;
}
