package com.lenovo.bi.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BI_NPIFilterDetail")
public class NPIFilterDetail {
	@Id
	@GeneratedValue
	@Column(name="Id")
	private Integer id;
	@Column(name="ParentId")
	private String parentId;
	@Column(name="NpiWaveId")
	private Integer npiWaveId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public Integer getNpiWaveId() {
		return npiWaveId;
	}
	public void setNpiWaveId(Integer npiWaveId) {
		this.npiWaveId = npiWaveId;
	}
}
