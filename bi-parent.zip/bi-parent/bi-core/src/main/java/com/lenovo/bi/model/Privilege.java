package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;

import com.lenovo.bi.dto.privilege.PrivilegeTree;

@Entity
@Table(name = "BI_Privilege")
public class Privilege {

	@Id
	@Column(name = "id")
	private int id;
	@Column(name = "Code")
	private String resourceKey;
	@Column(name = "Name")
	private String name;
	@Column(name = "Type")
	private String type;
	@Column(name = "Description")
	private String description;
	@Column(name = "url")
	private String suburl;
	@Column(name = "ParentId")
	private int pId;
	@Column(name = "location")
	private int location;
	@Column(name = "layer")
	private int layer;
	@Column(name = "isModule")
	private int isModule;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getResourceKey() {
		return resourceKey;
	}
	public void setResourceKey(String resourceKey) {
		this.resourceKey = resourceKey;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSuburl() {
		return suburl;
	}
	public void setSuburl(String suburl) {
		this.suburl = suburl;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public int getLocation() {
		return location;
	}
	public void setLocation(int location) {
		this.location = location;
	}
	public int getLayer() {
		return layer;
	}
	public void setLayer(int layer) {
		this.layer = layer;
	}
	public int getIsModule() {
		return isModule;
	}
	public void setIsModule(int isModule) {
		this.isModule = isModule;
	}

}
