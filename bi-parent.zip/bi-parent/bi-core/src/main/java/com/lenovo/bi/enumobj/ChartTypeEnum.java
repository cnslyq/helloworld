package com.lenovo.bi.enumobj;

public enum ChartTypeEnum {

	OverView("OverView"),
	Dashboard("Dashboard"),
	CrossMonth("CrossMonth"),
	OverRall("OverRall"),
	Component("Component")
	;
	
	private String typeName;
	
	private ChartTypeEnum(String typeName) {
		this.typeName = typeName;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
}
