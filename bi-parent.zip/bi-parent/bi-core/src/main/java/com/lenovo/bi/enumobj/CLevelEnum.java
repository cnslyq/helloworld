package com.lenovo.bi.enumobj;

public enum CLevelEnum {

	CPU("cccccc"),//灰色
	MEM("0000ff"),//橙黄
	VGA("cc99ff"),//紫色
	HD("ff6633");//桔黄
	
	private String color;
	
	CLevelEnum(){
		
	}
	
	CLevelEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		if(name().equals("MFG_Quality") || name().equals("NEW_Working"))
			return name().replaceAll("_", "/");
		else
			return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}
}
