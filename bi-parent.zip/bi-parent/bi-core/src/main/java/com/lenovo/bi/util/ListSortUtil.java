package com.lenovo.bi.util;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ListSortUtil {
	@SuppressWarnings({ "unchecked", "rawtypes" })  
    public static void sort(List targetList, final String sortField, final String sortMode) {  
      
        Collections.sort(targetList, new Comparator() {  
            public int compare(Object obj1, Object obj2) {   
                int retVal = 0;  
                try {  
                    String newStr=sortField.substring(0, 1).toUpperCase()+sortField.replaceFirst("\\w","");   
                    String methodStr="get"+newStr;  
                      
                    Method method1 = (obj1).getClass().getMethod(methodStr, null);  
                    Method method2 = (obj2).getClass().getMethod(methodStr, null);
                    Object value1;
                    Object value2;
                    if (sortMode != null && "desc".equalsIgnoreCase(sortMode)){
                		value1 = method2.invoke((obj2), null);
                		value2 = method1.invoke((obj1), null);
                	}else{
                		value1 = method1.invoke((obj1), null);
                		value2 = method2.invoke((obj2), null);
                	}
                    if(method2.invoke(( obj2), null) != null && method1.invoke(( obj1), null) != null){
                    	if(value1 instanceof Date){
                    		retVal = ((Date) value1).compareTo((Date)value2);
                    	}else{
                    		Pattern pattern = Pattern.compile("-?[0-9]+.?[0-9]*"); 
                    		Matcher isValue1Num = pattern.matcher(value1.toString());
                    		Matcher isValue2Num = pattern.matcher(value2.toString());
                    		if(isValue1Num.matches() && isValue2Num.matches()){
                    			retVal = new BigDecimal(value1.toString()).compareTo(new BigDecimal(value2.toString()));
                    		}else{
                    			retVal = value1.toString().compareTo(value2.toString());
                    		}
                    	}
                    }else if(value1 == null){
                    	return -1;
                    }else if(value2 == null){
                    	return 1;
                    }else{
                    	return 0;
                    }
                } catch (Exception e) {  
                    return 0;
                }  
                return retVal;  
            }  
        });  
    }  
}
