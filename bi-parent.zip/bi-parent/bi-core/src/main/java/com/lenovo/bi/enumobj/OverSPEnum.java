package com.lenovo.bi.enumobj;

public enum OverSPEnum {

	Over_EOL_LTB_L("0066cc"),
	Over_forecast("ff6633"),
	No_forecast("cccccc");
	
	private String color;
	
	OverSPEnum(){
		
	}
	
	OverSPEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		if(name().equals("Over_EOL_LTB_L"))
			return name().replaceAll("_", " ").replace("EOL ", "EOL/");
		else
			return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}
}
