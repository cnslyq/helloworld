package com.lenovo.bi.util;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

public class CollectionUtil {
	@SuppressWarnings("unchecked")
	public static <T> List<T> copyList(List<T> originals) {
		List<T> copies = new ArrayList<T>();
		for (T original : originals) {
			try {
				copies.add((T)BeanUtils.cloneBean(original));
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
		
		return copies;
	}
}
