package com.lenovo.bi.dto;

public class MpsWeightedFa {
	private int mps;
	private float weightedFa;
	public int getMps() {
		return mps;
	}
	public void setMps(int mps) {
		this.mps = mps;
	}
	public float getWeightedFa() {
		return weightedFa;
	}
	public void setWeightedFa(float weightedFa) {
		this.weightedFa = weightedFa;
	}
}
