package com.lenovo.bi.model;
@Deprecated
public enum TTMStatusEnum {

	InProgress_All("inProgress",1l,"All"),
	InProgress_Risk("inProgress",2l,"Risk"),
	InProgress_NoRisk("inProgress",3l,"No Risk"),
	
	Success_All("success",1l,"All"),
	Success_OnSchedule("success",2l,"On Schedule"),
	Success_DelayLessThan5Days("success",3l,"Delay Less than 5 Days"),
	Success_DelayGreaterThan5Days("success",4l,"Delay Greater than 5 Days"),
	
	Fail_All("fail",1l,"All"),
	Fail_DOINotReady("fail",2l,"DOI Not Ready"),
	Fail_OpenDefects("fail",3l,"Open Defects"),
	Fail_BothAndOther("fail",4l,"Both and Other");
	
	private Long index;
	private String typeName;
	private String name;
	
	private TTMStatusEnum(String typeName,Long index,String name) {
		this.name = name;
		this.index = index;
		this.typeName = typeName;
	}

	/*public static String getName(int type) {  
        for (InProgressStatusEnum ipsEnum : InProgressStatusEnum.values()) {  
            if (ipsEnum.getType() == type) {  
                return ipsEnum.name;  
            }  
        }  
        return null;  
    }  */
	
	

	public String getTypeName() {
		return typeName;
	}

	public Long getIndex() {
		return index;
	}

	public void setIndex(Long index) {
		this.index = index;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
