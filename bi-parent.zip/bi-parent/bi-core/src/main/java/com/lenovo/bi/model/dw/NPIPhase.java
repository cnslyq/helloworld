package com.lenovo.bi.model.dw;

import java.util.Date;

public class NPIPhase {
	private String phaseName;
	private String builtinCode;
	private Integer pmsWave;
	private Date planDate;

	public String getPhaseName() {
		return phaseName;
	}

	public void setPhaseName(String phaseName) {
		this.phaseName = phaseName;
	}

	public String getBuiltinCode() {
		return builtinCode;
	}

	public void setBuiltinCode(String builtinCode) {
		this.builtinCode = builtinCode;
	}

	public Integer getPmsWave() {
		return pmsWave;
	}

	public void setPmsWave(Integer pmsWave) {
		this.pmsWave = pmsWave;
	}

	public Date getPlanDate() {
		return planDate;
	}

	public void setPlanDate(Date planDate) {
		this.planDate = planDate;
	}

}
