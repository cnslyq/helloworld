package com.lenovo.bi.dto;

/**
 * 
 * @author coris_zhao
 *
 */
public class ProductDataForPopup {
	private int npiWaveId;
	private String productName = "";
	private String waveName = "";
	private String displayName = "";//npiName
	private String family;
	
	public int getNpiWaveId() {
		return npiWaveId;
	}
	public void setNpiWaveId(int npiWaveId) {
		this.npiWaveId = npiWaveId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getWaveName() {
		return waveName;
	}
	public void setWaveName(String waveName) {
		this.waveName = waveName;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getFamily() {
		return family;
	}
	public void setFamily(String family) {
		this.family = family;
	}
}
