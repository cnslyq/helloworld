package com.lenovo.bi.enumobj;

public enum TTVGridColumns {
	
	Product("ProductName"),
	Status("TTV_Status"),
	Risk("TTVRisk"),
	TTMSignoffDate("TTMSignOffDate"),
	TTVTargetDate("TTVTargetDate"),
	TTVSignOffDate("TTVSignOffDate"),
	TTVTarget("TTVTarget"),
	EstimatedTTV("EstimatedTTV"),
	ActualTTV("ActualTTV"),
	CurrentPhase("CurrentPhase"),
	PM("pm"),
	StartDate("StartDate"),
	TTMTargetDate("TTMTargetDate"),
	TTMSignOffDate("TTMSignOffDate"),
	SgaStatus("SGA_TTV_Status"),
	SgaRisk("SGA_TTVRisk"),
	SgaTTVTargetDate("SGA_ttvTargetDate"),
	SgaTTVSignOffDate("SGA_ttvSignOffDate"),
	SgaTTVTarget("SGA_TTVTarget"),
	SgaEstimatedTTV("SGA_EstimatedTTV"),
	SgaActualTTV("SGA_ActualTTV"),
	NaType("naType"),
	SgaNaType("sgaNaType"),
	;
	
	private String dbColumnName;

	TTVGridColumns(String dbColumnName){
		this.dbColumnName = dbColumnName;
	}

	public String getDbColumnName() {
		return dbColumnName;
	}

	public void setDbColumnName(String dbColumnName) {
		this.dbColumnName = dbColumnName;
	}
	
}
