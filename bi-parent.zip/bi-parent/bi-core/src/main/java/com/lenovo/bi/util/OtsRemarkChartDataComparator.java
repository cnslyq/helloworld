package com.lenovo.bi.util;

import java.math.BigDecimal;
import java.util.Comparator;

import com.lenovo.bi.dto.sc.OtsRemarkChartData;

public class OtsRemarkChartDataComparator implements Comparator {

	@Override
	public int compare(Object obj1, Object obj2) {
		OtsRemarkChartData otsRemarkChartData1 = (OtsRemarkChartData) obj1;
		OtsRemarkChartData otsRemarkChartData2 = (OtsRemarkChartData) obj2;

		int failRate = new BigDecimal(otsRemarkChartData2.getFailRate()).compareTo(new BigDecimal(otsRemarkChartData1.getFailRate()));
		if(failRate!=0)
            return failRate;
		int toBeFail = new BigDecimal(otsRemarkChartData2.getToBeFailRate()).compareTo(new BigDecimal(otsRemarkChartData1.getToBeFailRate()));
		return toBeFail;
	}

}
