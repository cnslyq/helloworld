package com.lenovo.bi.dto.sc;


public class GeoFA {

	private String Geo; 
	private float FAValue;
	private float FARate;
	
	public String getGeo() {
		return Geo;
	}
	public void setGeo(String geo) {
		Geo = geo;
	}
	public float getFAValue() {
		return FAValue;
	}
	public void setFAValue(float fAValue) {
		FAValue = fAValue;
	}
	public float getFARate() {
		return FARate;
	}
	public void setFARate(float fARate) {
		FARate = fARate;
	}
	
}
