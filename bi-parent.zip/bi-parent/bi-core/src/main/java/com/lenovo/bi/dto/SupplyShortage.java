package com.lenovo.bi.dto;

import java.util.Date;

public class SupplyShortage {
	private Date targetDate;
	private Integer shortage;
	private Integer demand;
	private Integer commitment;
	private String globalCVKey;
	private String bomNumber;
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	public Integer getShortage() {
		return shortage;
	}
	public void setShortage(Integer shortage) {
		this.shortage = shortage;
	}
	public Integer getDemand() {
		return demand;
	}
	public void setDemand(Integer demand) {
		this.demand = demand;
	}
	public Integer getCommitment() {
		return commitment;
	}
	public void setCommitment(Integer commitment) {
		this.commitment = commitment;
	}
	public String getGlobalCVKey() {
		return globalCVKey;
	}
	public void setGlobalCVKey(String globalCVKey) {
		this.globalCVKey = globalCVKey;
	}
	public String getBomNumber() {
		return bomNumber;
	}
	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}
}
