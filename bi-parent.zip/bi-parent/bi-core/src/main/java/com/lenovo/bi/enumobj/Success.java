package com.lenovo.bi.enumobj;

public enum Success {

	All,
	Delay_Greater_than_NUM_Days("DC143C","red"),
	Delay_Less_than_NUM_Days("ffd700","Gold"),
	On_Schedule("32CD32","Green");
	
	private String color;
	private String labelColor;
	
	Success(){
		
	}
	
	Success(String color, String labelColor){
		this.color = color;
		this.labelColor = labelColor;
	}
	
	@Override
	public String toString() {
		return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}

	public String getLabelColor() {
		return labelColor;
	}
	
}
