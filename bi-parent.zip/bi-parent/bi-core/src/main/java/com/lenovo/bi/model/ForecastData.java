package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.lenovo.bi.dto.CtoCvConfig;
import com.lenovo.bi.enumobj.ForecastComparisonTypeEnum;

@Entity
@Table(name="BI_WeeklyComponentCommitmentOnForecast")
public class ForecastData {
	@Id
	@GeneratedValue
	@Column
	private int forecastDataId;
	
	@Column
	private String pmsWaveId;
	
	@Column
	private String bomNumber;
	
	@Column
	private int quantity;
	
	@Column
	private int normalQuantity;
	
	@Column
	private int abnormalQuantity;
		
	@Enumerated(EnumType.STRING)
	@Column
	private ForecastComparisonTypeEnum orderLabel;
	
	@Column
	private int materialShortage;
	
	@Column
	private int materialCommit;
	
	@Column
	private int coverAShortage;
	
	@Column
	private int coverACommit;
	
	@Column
	private int coverBShortage;
	
	@Column
	private int coverBCommit;
	
	@Column
	private int coverCShortage;
	
	@Column
	private int coverCCommit;
	
	@Column
	private int coverDShortage;
	
	@Column
	private int coverDCommit;
	
	@Column
	private int odmShortage;
	
	@Column
	private int odmCommit;
	
	@Column
	private int tdmsOdmShortage;
	
	@Column
	private int tdmsOdmCommit;
	
	@Column
	private String geographyName;
	
	@Column
	private String odmName;
	
	@Column
	private String productKey;
	
	@Column
	private boolean forNpi;
	
	@Column
	private boolean ctoForecast;
	
	@Column
	private Date versionDate;
	
	@Column
	private Date targetDate;
	
	@Column
	private Date createdDate;
	
	@Column
	private Date lastModifiedDate;
	
	@Column
	private String ttvPhase;
	
	@Transient
	private CtoCvConfig ctoCvConfig;

	public int getForecastDataId() {
		return forecastDataId;
	}

	public void setForecastDataId(int forecastDataId) {
		this.forecastDataId = forecastDataId;
	}

	public String getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(String pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public String getBomNumber() {
		return bomNumber;
	}

	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getMaterialShortage() {
		return materialShortage;
	}

	public void setMaterialShortage(int materialShortage) {
		this.materialShortage = materialShortage;
	}

	public int getMaterialCommit() {
		return materialCommit;
	}

	public void setMaterialCommit(int materialCommit) {
		this.materialCommit = materialCommit;
	}

	public int getNormalQuantity() {
		return normalQuantity;
	}

	public void setNormalQuantity(int normalQuantity) {
		this.normalQuantity = normalQuantity;
	}

	public int getAbnormalQuantity() {
		return abnormalQuantity;
	}

	public void setAbnormalQuantity(int abnormalQuantity) {
		this.abnormalQuantity = abnormalQuantity;
	}

	public ForecastComparisonTypeEnum getOrderLabel() {
		return orderLabel;
	}

	public void setOrderLabel(ForecastComparisonTypeEnum orderLabel) {
		this.orderLabel = orderLabel;
	}

	public int getCoverAShortage() {
		return coverAShortage;
	}

	public void setCoverAShortage(int coverAShortage) {
		this.coverAShortage = coverAShortage;
	}

	public int getCoverACommit() {
		return coverACommit;
	}

	public void setCoverACommit(int coverACommit) {
		this.coverACommit = coverACommit;
	}

	public int getCoverBShortage() {
		return coverBShortage;
	}

	public void setCoverBShortage(int coverBShortage) {
		this.coverBShortage = coverBShortage;
	}

	public int getCoverBCommit() {
		return coverBCommit;
	}

	public void setCoverBCommit(int coverBCommit) {
		this.coverBCommit = coverBCommit;
	}

	public int getCoverCShortage() {
		return coverCShortage;
	}

	public void setCoverCShortage(int coverCShortage) {
		this.coverCShortage = coverCShortage;
	}

	public int getCoverCCommit() {
		return coverCCommit;
	}

	public void setCoverCCommit(int coverCCommit) {
		this.coverCCommit = coverCCommit;
	}

	public int getCoverDShortage() {
		return coverDShortage;
	}

	public void setCoverDShortage(int coverDShortage) {
		this.coverDShortage = coverDShortage;
	}

	public int getCoverDCommit() {
		return coverDCommit;
	}

	public void setCoverDCommit(int coverDCommit) {
		this.coverDCommit = coverDCommit;
	}

	public int getOdmShortage() {
		return odmShortage;
	}

	public void setOdmShortage(int odmShortage) {
		this.odmShortage = odmShortage;
	}

	public int getOdmCommit() {
		return odmCommit;
	}

	public void setOdmCommit(int odmCommit) {
		this.odmCommit = odmCommit;
	}
	
	public int getTdmsOdmShortage() {
		return tdmsOdmShortage;
	}

	public void setTdmsOdmShortage(int tdmsOdmShortage) {
		this.tdmsOdmShortage = tdmsOdmShortage;
	}

	public int getTdmsOdmCommit() {
		return tdmsOdmCommit;
	}

	public void setTdmsOdmCommit(int tdmsOdmCommit) {
		this.tdmsOdmCommit = tdmsOdmCommit;
	}
	
	public String getGeographyName() {
		return geographyName;
	}

	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}

	public String getOdmName() {
		return odmName;
	}

	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}

	public boolean getForNpi() {
		return forNpi;
	}

	public void setForNpi(boolean forNpi) {
		this.forNpi = forNpi;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	public String getProductKey() {
		return productKey;
	}
	
	public void setProductKey(Integer productKey) {
		this.productKey = Integer.toString(productKey);
	}

	public CtoCvConfig getCtoCvConfig() {
		return ctoCvConfig;
	}

	public void setCtoCvConfig(CtoCvConfig ctoCvConfig) {
		this.ctoCvConfig = ctoCvConfig;
	}
	
	public boolean getCtoForecast() {
		return ctoForecast;
	}
	
	public void setCtoForecast(boolean ctoForecast) {
		this.ctoForecast = ctoForecast;
	}
	
	public String getTtvPhase() {
		return ttvPhase;
	}

	public void setTtvPhase(String ttvPhase) {
		this.ttvPhase = ttvPhase;
	}

	@Override
	public String toString() {
		return "ForecastData [forecastDataId=" + forecastDataId
				+ ", pmsWaveId=" + pmsWaveId + ", bomNumber=" + bomNumber
				+ ", quantity=" + quantity + ", normalQuantity="
				+ normalQuantity + ", abnormalQuantity=" + abnormalQuantity
				+ ", orderLabel=" + orderLabel + ", materialShortage="
				+ materialShortage + ", materialCommit=" + materialCommit
				+ ", coverAShortage=" + coverAShortage + ", coverACommit="
				+ coverACommit + ", coverBShortage=" + coverBShortage
				+ ", coverBCommit=" + coverBCommit + ", coverCShortage="
				+ coverCShortage + ", coverCCommit=" + coverCCommit
				+ ", coverDShortage=" + coverDShortage + ", coverDCommit="
				+ coverDCommit + ", odmShortage=" + odmShortage
				+ ", odmCommit=" + odmCommit + ", tdmsOdmShortage="
				+ tdmsOdmShortage + ", tdmsOdmCommit=" + tdmsOdmCommit
				+ ", geographyName=" + geographyName + ", odmName=" + odmName
				+ ", forNpi=" + forNpi + ", versionDate=" + versionDate
				+ ", targetDate=" + targetDate + ", createdDate=" + createdDate
				+ ", lastModifiedDate=" + lastModifiedDate + ", productKey="
				+ productKey + "]";
	}

	public String getUniqueIdentifier() {
		return bomNumber;
	}
	
	
}
