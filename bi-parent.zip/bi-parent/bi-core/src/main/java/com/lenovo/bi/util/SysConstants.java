package com.lenovo.bi.util;

import java.text.SimpleDateFormat;

public class SysConstants {
	public static String LOG_WEEKLY_BATCH_CATALOG = "WEEKLYBATCH";
	
	public static String LOG_ENAGINE_BATCH_CATALOG = "ENAGINEWEEKLYBATCH";
	
	public static SimpleDateFormat MONTH_DATE_FORMAT = new SimpleDateFormat("yyyy-MM");
	
	// HTTP methods
	public static String HTTP_GET = "GET";
}
