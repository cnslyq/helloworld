package com.lenovo.bi.model;

import java.text.ParseException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.lenovo.bi.util.CalendarUtil;

@Entity
@Table(name = "BI_NPIOrder")
public class NpiOrder {
	@Id
	@GeneratedValue
	@Column(name = "NPIOrderKey")
	private Integer npiOrderKey;

	@Column(name = "PMSWaveID")
	private Integer pmsWaveId;

	@Column(name = "BomNumber")
	private String mtm;

	@Column(name = "Quantity")
	private Integer quantity;

	@Column(name = "RsdDate")
	private Date rsdDate;

	@Column(name = "ExcludedOn")
	private Date excludedOn;

	@Column(name = "LastModifiedDate")
	private Date lastModifiedDate;
	
	@Column(name = "CreatedDate")
	private Date createDate;

	@Column(name = "ExcludedBy")
	private String excludedBy;

	@Column(name = "PONumber")
	private String poNumber;

	@Column(name = "POItem")
	private String poItem;

	@Column(name = "ShipDate")
	private Date shipDate;

	@Column(name = "IsShipped")
	private Boolean isShipped;

	@Column(name = "TTVPhase")
	private String ttvPhase;

	@Column(name = "OrderDate")
	private Date orderDate;

	@Column(name = "Region")
	private String region;
	
	public String getOrderUniqueIdentifier() {
		try {
			return poNumber + "|" + poItem + "|" + mtm + "|" + CalendarUtil.date2String(orderDate) + "|" + CalendarUtil.date2String(rsdDate) + "|"
					+ String.valueOf(quantity) + "|" + region;
		} catch (ParseException e) {
		}
		return null;
	}

	public Integer getNpiOrderKey() {
		return npiOrderKey;
	}

	public void setNpiOrderKey(Integer npiOrderKey) {
		this.npiOrderKey = npiOrderKey;
	}

	public Integer getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(Integer pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public String getMtm() {
		return mtm;
	}

	public void setMtm(String mtm) {
		this.mtm = mtm;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Date getRsdDate() {
		return rsdDate;
	}

	public void setRsdDate(Date rsdDate) {
		this.rsdDate = rsdDate;
	}

	public Date getExcludedOn() {
		return excludedOn;
	}

	public void setExcludedOn(Date excludedOn) {
		this.excludedOn = excludedOn;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getExcludedBy() {
		return excludedBy;
	}

	public void setExcludedBy(String excludedBy) {
		this.excludedBy = excludedBy;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoItem() {
		return poItem;
	}

	public void setPoItem(String poItem) {
		this.poItem = poItem;
	}

	public Date getShipDate() {
		return shipDate;
	}

	public void setShipDate(Date shipDate) {
		this.shipDate = shipDate;
	}

	public Boolean getIsShipped() {
		return isShipped;
	}

	public void setIsShipped(Boolean isShipped) {
		this.isShipped = isShipped;
	}

	public String getTtvPhase() {
		return ttvPhase;
	}

	public void setTtvPhase(String ttvPhase) {
		this.ttvPhase = ttvPhase;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	
}
