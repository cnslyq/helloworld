package com.lenovo.bi.enumobj;

public enum TTMSnapshotType {
	target("TTM Target Date Snapshot"), signed("TTM Signed-Off Date Snapshot");
	
	private String pageTitle;
	
	TTMSnapshotType(String pageTitle){
		this.pageTitle = pageTitle;
	}

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	
}
