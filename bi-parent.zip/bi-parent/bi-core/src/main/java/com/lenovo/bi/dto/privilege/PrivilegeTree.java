package com.lenovo.bi.dto.privilege;



public class PrivilegeTree extends Tree {

	private static final long serialVersionUID = -7702921606829567312L;


	public String type;// type
	public String suburl;// url
	public String resourceKey;// code
	public String description;
	
	private String roleId;
	private String groupId;
	private int location;
	private int layer;
	private int isModule;
	private String context;
	
	public String infomation;

	public enum TYPE {
		Department(1), ProjectRole(2);
		public int value;

		private TYPE(int value) {
			this.value = value;
		}

		public static TYPE toEnum(int val) {
			for (TYPE t : TYPE.values()) {
				if (t.value == val) {
					return t;
				}
			}
			return Department;
		}
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSuburl() {
		return suburl;
	}

	public void setSuburl(String suburl) {
		this.suburl = suburl;
	}

	public String getResourceKey() {
		return resourceKey;
	}

	public void setResourceKey(String resourceKey) {
		this.resourceKey = resourceKey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	

	public String getInfomation() {
		return infomation;
	}

	public void setInfomation(String infomation) {
		this.infomation = infomation;
	}

	@Override
	public String toString() {
		return "PrivilegeTree [id=" + id + ", name=" + name + ", pId=" + pId
				+ ", checked=" + checked + ", suburl=" + suburl
				+ ", resourceKey=" + resourceKey + ", type=" + type + "]";
	}
	public int getLocation() {
		return location;
	}

	public void setLocation(int location) {
		this.location = location;
	}

	public int getLayer() {
		return layer;
	}

	public void setLayer(int layer) {
		this.layer = layer;
	}

	public int getIsModule() {
		return isModule;
	}

	public void setIsModule(int isModule) {
		this.isModule = isModule;
	}

	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	
	
}

