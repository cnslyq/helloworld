package com.lenovo.bi.dto;


public class DimMtm {
	private Integer mtmKey;
	private String bomNumberAlternateKey;
	private String mtmEnglishName;
	private String mtmEnglishDescription;
	private Integer productKey;
	private Boolean isCTO;
	private String mtmChineseName;
	private String mtmChineseDescription;
	public Integer getMtmKey() {
		return mtmKey;
	}
	public void setMtmKey(Integer mtmKey) {
		this.mtmKey = mtmKey;
	}
	public String getBomNumberAlternateKey() {
		return bomNumberAlternateKey;
	}
	public void setBomNumberAlternateKey(String bomNumberAlternateKey) {
		this.bomNumberAlternateKey = bomNumberAlternateKey;
	}
	public String getMtmEnglishName() {
		return mtmEnglishName;
	}
	public void setMtmEnglishName(String mtmEnglishName) {
		this.mtmEnglishName = mtmEnglishName;
	}
	public String getMtmEnglishDescription() {
		return mtmEnglishDescription;
	}
	public void setMtmEnglishDescription(String mtmEnglishDescription) {
		this.mtmEnglishDescription = mtmEnglishDescription;
	}
	public Integer getProductKey() {
		return productKey;
	}
	public void setProductKey(Integer productKey) {
		this.productKey = productKey;
	}
	public Boolean getIsCTO() {
		return isCTO;
	}
	public void setIsCTO(Boolean isCTO) {
		this.isCTO = isCTO;
	}
	public String getMtmChineseName() {
		return mtmChineseName;
	}
	public void setMtmChineseName(String mtmChineseName) {
		this.mtmChineseName = mtmChineseName;
	}
	public String getMtmChineseDescription() {
		return mtmChineseDescription;
	}
	public void setMtmChineseDescription(String mtmChineseDescription) {
		this.mtmChineseDescription = mtmChineseDescription;
	}
}
