package com.lenovo.bi.dto;

import java.util.Date;

/**
 * detail ODM capacity plan
 * 
 * @author henry_lian
 *
 */
public class OdmCapacityPlanDetail extends OdmCapacityPlan {

	private String odmName;
	private String line;
	private String crew;
	private Date targetDate;
	public String getOdmName() {
		return odmName;
	}
	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getCrew() {
		return crew;
	}
	public void setCrew(String crew) {
		this.crew = crew;
	}
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
}
