package com.lenovo.bi.dto;

import java.util.Date;

public class EolForecast extends Forecast {
	private Date eolDate;
	
	public EolForecast() {
		super();
	}

	public EolForecast(Forecast original, Date eolDate) {
		super();
		this.forecastId = original.forecastId;
		this.bomNumber = original.bomNumber;
		this.pmsWaveId = original.pmsWaveId;
		this.productKey = original.productKey;
		this.geographyName = original.geographyName;
		this.odmName = original.odmName;
		this.quantity = original.quantity;
		this.targetDate = original.targetDate;
		this.versionDate = original.versionDate;
		this.forecastType = original.forecastType;
		this.productName = original.productName;
		this.geo = original.geo;
		this.region = original.region;
		this.description = original.description;
		this.ctoCvConfig = original.ctoCvConfig;
		this.eolDate = eolDate;
	}
	
	public Date getEolDate() {
		return eolDate;
	}

	public void setEolDate(Date eolDate) {
		this.eolDate = eolDate;
	}

}
