package com.lenovo.bi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BI_WeeklyComponentCommitmentOnProduct")
public class NpiWeeklyComponentCommitmentOnProduct  {
	@Id
	@Column(name = "id")
	@GeneratedValue
	private Integer id;
	@Column
	private Integer globalCVKey;
	@Column
	private Long commitment;
	@Column
	private Integer productKey;
	@Column
	private Integer targetDate;
	@Column
	private Integer versionDate;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getGlobalCVKey() {
		return globalCVKey;
	}

	public void setGlobalCVKey(Integer globalCVKey) {
		this.globalCVKey = globalCVKey;
	}



	public Long getCommitment() {
		return commitment;
	}

	public void setCommitment(Long commitment) {
		this.commitment = commitment;
	}

	public Integer getProductKey() {
		return productKey;
	}

	public void setProductKey(Integer productKey) {
		this.productKey = productKey;
	}

	public Integer getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Integer targetDate) {
		this.targetDate = targetDate;
	}

	public Integer getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Integer versionDate) {
		this.versionDate = versionDate;
	}

	@Override
	public String toString() {
		return "NpiWeeklyComponentCommitmentOnProduct [id=" + id
				+ ", globalCVKey=" + globalCVKey + ", commitment=" + commitment
				+ ", productKey=" + productKey + ", targetDate=" + targetDate
				+ ", versionDate=" + versionDate + "]";
	}


}
