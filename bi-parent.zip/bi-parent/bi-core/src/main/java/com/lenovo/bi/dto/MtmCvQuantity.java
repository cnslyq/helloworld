package com.lenovo.bi.dto;

public class MtmCvQuantity {
	private String bomNumber;
	private int cvKey;
	private int quantity;
	public String getBomNumber() {
		return bomNumber;
	}
	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}
	public int getCvKey() {
		return cvKey;
	}
	public void setCvKey(int cvKey) {
		this.cvKey = cvKey;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
