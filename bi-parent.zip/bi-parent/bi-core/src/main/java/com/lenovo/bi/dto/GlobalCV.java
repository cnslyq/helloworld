package com.lenovo.bi.dto;

public class GlobalCV {
	private String globalCVKey;
	private String c;
	private String v;
	public String getGlobalCVKey() {
		return globalCVKey;
	}
	public void setGlobalCVKey(String globalCVKey) {
		this.globalCVKey = globalCVKey;
	}
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	public String getV() {
		return v;
	}
	public void setV(String v) {
		this.v = v;
	}
	
	public boolean equals(Object o){
		if(!(o instanceof GlobalCV)){
			return false;
		}
		GlobalCV cv = (GlobalCV)o;
		return cv.getC().equals(c) && cv.getV().equals(v);
	}
	public int hashCode(){
		return c.hashCode() + v.hashCode();
	}
}
