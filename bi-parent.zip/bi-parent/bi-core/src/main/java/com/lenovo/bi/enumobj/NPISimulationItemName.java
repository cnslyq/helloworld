package com.lenovo.bi.enumobj;

public enum NPISimulationItemName {
	Supply,UPH,FPY,RPY,IsRPYinclude,Hours_Per_Day,Days_Per_Week,Tooling,Rampcommit,Defect,Target_Resolve_Date,Target_FPY_Impact;
	@Override
	public String toString() {
		return name().replaceAll("_", " ");
	}
}
