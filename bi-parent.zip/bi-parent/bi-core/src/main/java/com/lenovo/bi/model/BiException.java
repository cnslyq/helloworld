package com.lenovo.bi.model;

public class BiException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BiException() {
		super();
	}

	public BiException(String message, Throwable cause) {
		super(message, cause);
	}

	public BiException(String message) {
		super(message);
	}

	public BiException(Throwable cause) {
		super(cause);
	}

	
}
