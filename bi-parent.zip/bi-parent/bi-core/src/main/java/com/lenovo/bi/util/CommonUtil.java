package com.lenovo.bi.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.lenovo.bi.enumobj.Success;

public class CommonUtil {

	public static String SuccessStatusReplace(Success success, int num){
		return success.toString().replace("NUM", String.valueOf(num));
	}
	
	public static Success getSuccessFromNumber(String s, int num){
		s = s.replaceAll(String.valueOf(num), "NUM").replaceAll(" ", "_");
		return Success.valueOf(s);
	}
	
	public static String npiNameString(List<String> list){
		StringBuilder sb = new StringBuilder();
		boolean isFirst = true;
		for(String name:list){
			if (!isFirst){
				sb.append(",");
			} else{
				isFirst = false;
			}
			sb.append(name);
		}
		return sb.toString();
	}
	
	public static List<Integer> getListIntegerIdsFromString(String ids){
		if(StringUtils.isBlank(ids)){
			return new ArrayList<Integer>();
		}
		String[] waveIds = ids.split(",");
		List<Integer> list = new ArrayList<Integer>();
		for(String id:waveIds){
			list.add(Integer.parseInt(id));
		}
		return list;
	}
	
}
