package com.lenovo.bi.dto;

import java.util.Date;

public class Product {
	private int productKey;
	private Date eolDate; // Final lock date
	public int getProductKey() {
		return productKey;
	}
	public void setProductKey(int productKey) {
		this.productKey = productKey;
	}
	public Date getEolDate() {
		return eolDate;
	}
	public void setEolDate(Date eolDate) {
		this.eolDate = eolDate;
	}
	
	
}
