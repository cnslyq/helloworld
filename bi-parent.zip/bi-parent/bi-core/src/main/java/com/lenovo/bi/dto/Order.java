package com.lenovo.bi.dto;

import java.text.ParseException;
import java.util.Date;

import com.lenovo.bi.enumobj.ForecastComparisonTypeEnum;
import com.lenovo.bi.util.CalendarUtil;

public class Order {

	private String bomNumber;
	private String mtmDesc;
	private String poNumber;
	private String poItem;
	private String pmsWaveId;
	private Integer productKey;
	private String geographyName;
	private String parentGeoName;
	private String odmName;
	private Integer quantity;
	private Date rsd;
	private Date orderDate;
	private Date targetDate;
	private Date shipDate;
	private Date fgDate;
	private Date versionDate;
	private ForecastComparisonTypeEnum forecastComparison = ForecastComparisonTypeEnum.DOWNSIDE;

	public Date getShipDate() {
		return shipDate;
	}

	public void setShipDate(Date shipDate) {
		this.shipDate = shipDate;
	}

	public String getMtmDesc() {
		return mtmDesc;
	}

	public void setMtmDesc(String mtmDesc) {
		this.mtmDesc = mtmDesc;
	}

	public String getOrderId() {
		try {
			return poNumber + "|" + poItem + "|" + bomNumber + "|" + CalendarUtil.date2String(orderDate) + "|" + CalendarUtil.date2String(rsd) + "|"
					+ String.valueOf(quantity) + "|" + geographyName;
		} catch (ParseException e) {
		}
		return null;
	}

	public String getBomNumber() {
		return bomNumber;
	}

	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}

	public String getPoItem() {
		return poItem;
	}

	public void setPoItem(String poItem) {
		this.poItem = poItem;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(String pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public Integer getProductKey() {
		return productKey;
	}

	public void setProductKey(Integer productKey) {
		this.productKey = productKey;
	}

	public String getGeographyName() {
		return geographyName;
	}

	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}

	public String getOdmName() {
		return odmName;
	}

	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Date getRsd() {
		return rsd;
	}

	public void setRsd(Date rsd) {
		this.rsd = rsd;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public ForecastComparisonTypeEnum getForecastComparison() {
		return forecastComparison;
	}

	public void setForecastComparison(ForecastComparisonTypeEnum forecastComparison) {
		this.forecastComparison = forecastComparison;
	}

	public Date getFgDate() {
		return fgDate;
	}

	public void setFgDate(Date fgDate) {
		this.fgDate = fgDate;
	}

	public String getParentGeoName() {
		return parentGeoName;
	}

	public void setParentGeoName(String parentGeoName) {
		this.parentGeoName = parentGeoName;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}
	
}
