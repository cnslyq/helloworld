package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BI_NPIFilter")
public class NPIFilter {
	@Id
	@Column(name="Id", updatable = false)
	private String id;
	@Column(name="FilterName", updatable = false)
	private String filterName;
	@Column(name="UserID", updatable = false)
	private String userID;
	@Column(name="Scope", updatable = false)
	private String Scope;
	@Column(name="phase", updatable = false)
	private String Phase;
	@Column(name="DurationFrom")
	private Date durationFrom;
	@Column(name="DurationTo")
	private Date durationTo;
	@Column(name="CreateDate", updatable = false)
	private Date createDate;
	@Column(name="LastModifiedDate")
	private Date lastModifiedDate;
	@Column(name="LastUsedFilter", updatable = false)
	private Boolean isLastUsedFilter;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getScope() {
		return Scope;
	}
	public void setScope(String scope) {
		Scope = scope;
	}
	public String getPhase() {
		return Phase;
	}
	public void setPhase(String phase) {
		Phase = phase;
	}
	public Date getDurationFrom() {
		return durationFrom;
	}
	public void setDurationFrom(Date durationFrom) {
		this.durationFrom = durationFrom;
	}
	public Date getDurationTo() {
		return durationTo;
	}
	public void setDurationTo(Date durationTo) {
		this.durationTo = durationTo;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public Boolean getIsLastUsedFilter() {
		return isLastUsedFilter;
	}
	public void setIsLastUsedFilter(Boolean isLastUsedFilter) {
		this.isLastUsedFilter = isLastUsedFilter;
	}
	
}
