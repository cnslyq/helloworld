package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BI_TTVDailyDetail")
public class TtvDailyDetail {	
	@Id
	@GeneratedValue
	@Column(name="TTVDailyDetailId")
	private int ttvDailyDetailId;
	
	@Column(name="VersionDate")
	private Date versionDate;	
	
	@Column(name="PMSWaveID")
	private int pmsWaveId;
	
	@Column(name="TargetDate")
	private Date targetDate;
	
	@Column(name="FutureDemandQuantity")
	private int futureDemandQuantity;
	
	@Column(name="OrderQuantity")
	private int orderQuantity;
	
	@Column(name="ShipQuantity")
	private int shipQuantity;
	
	@Column(name="ODMCommit")
	private int odmCommit;
	
	@Column(name="SupplyCommit")
	private Integer supplyCommit;
	
	@Column(name="CoverA")
	private Integer coverA;
	
	@Column(name="CoverB")
	private Integer coverB;
	
	@Column(name="CoverC")
	private Integer coverC;
	
	@Column(name="CoverD")
	private Integer coverD;
	
	@Column(name="ODMFPYCapacity")
	private Integer odmFpyCapacity;
	
	@Column(name="ODMRPYCapacity")
	private Integer odmRpyCapacity;
	
	@Column(name="TDMSFPYCapacity")
	private Integer tdmsFpyCapacity;
	
	@Column(name="TDMSRPYCapacity")
	private Integer tdmsRpyCapacity;
	
	@Column(name="TDMSFPY")
	private float tdmsFpy;
	
	public int getTtvDailyDetailId() {
		return ttvDailyDetailId;
	}

	public void setTtvDailyDetailId(int ttvDailyDetailId) {
		this.ttvDailyDetailId = ttvDailyDetailId;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public int getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(int pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public int getFutureDemandQuantity() {
		return futureDemandQuantity;
	}

	public void setFutureDemandQuantity(int futureDemandQuantity) {
		this.futureDemandQuantity = futureDemandQuantity;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public int getShipQuantity() {
		return shipQuantity;
	}

	public void setShipQuantity(int shipQuantity) {
		this.shipQuantity = shipQuantity;
	}

	public int getOdmCommit() {
		return odmCommit;
	}

	public void setOdmCommit(int odmCommit) {
		this.odmCommit = odmCommit;
	}

	public int getSupplyCommit() {
		if (supplyCommit == null) {
			return -1;
		}
		return supplyCommit;
	}

	public void setSupplyCommit(int supplyCommit) {
		this.supplyCommit = supplyCommit;
	}

	public int getCoverA() {
		if (coverA == null) {
			return -1;
		}
		return coverA;
	}

	public void setCoverA(int coverA) {
		this.coverA = coverA;
	}

	public int getCoverB() {
		if (coverB == null) {
			return -1;
		}
		return coverB;
	}

	public void setCoverB(int coverB) {
		this.coverB = coverB;
	}

	public int getCoverC() {
		if (coverC == null) {
			return -1;
		}
		return coverC;
	}

	public void setCoverC(int coverC) {
		this.coverC = coverC;
	}

	public int getCoverD() {
		if (coverD == null) {
			return -1;
		}
		return coverD;
	}

	public void setCoverD(int coverD) {
		this.coverD = coverD;
	}

	public int getOdmFpyCapacity() {
		if (odmFpyCapacity == null) {
			return -1;
		}
		return odmFpyCapacity;
	}

	public void setOdmFpyCapacity(int odmFpyCapacity) {
		this.odmFpyCapacity = odmFpyCapacity;
	}

	public int getOdmRpyCapacity() {
		if (odmRpyCapacity == null) {
			return -1;
		}
		return odmRpyCapacity;
	}

	public void setOdmRpyCapacity(int odmRpyCapacity) {
		this.odmRpyCapacity = odmRpyCapacity;
	}

	public int getTdmsFpyCapacity() {
		if (tdmsFpyCapacity == null) {
			return -1;
		}
		return tdmsFpyCapacity;
	}

	public void setTdmsFpyCapacity(int tdmsFpyCapacity) {
		this.tdmsFpyCapacity = tdmsFpyCapacity;
	}
	
	public int getTdmsRpyCapacity() {
		if (tdmsRpyCapacity == null) {
			return -1;
		}
		return tdmsRpyCapacity;
	}

	public void setTdmsRpyCapacity(int tdmsRpyCapacity) {
		this.tdmsRpyCapacity = tdmsRpyCapacity;
	}

	public float getTdmsFpy() {
		return tdmsFpy;
	}

	public void setTdmsFpy(float tdmsFpy) {
		this.tdmsFpy = tdmsFpy;
	}	
	
	@Override
	public String toString() {
		return "TtvDailyDetail [ttvDailyDetailId=" + ttvDailyDetailId
				+ ", versionDate=" + versionDate + ", pmsWaveId=" + pmsWaveId
				+ ", targetDate=" + targetDate + ", futureDemandQuantity="
				+ futureDemandQuantity + ", orderQuantity=" + orderQuantity
				+ ", shipQuantity=" + shipQuantity + ", odmCommit=" + odmCommit
				+ ", supplyCommit=" + supplyCommit + ", coverA=" + coverA
				+ ", coverB=" + coverB + ", coverC=" + coverC + ", coverD="
				+ coverD + ", odmFpyCapacity=" + odmFpyCapacity
				+ ", odmRpyCapacity=" + odmRpyCapacity + ", tdmsFpyCapacity="
				+ tdmsFpyCapacity + ", tdmsFpy=" + tdmsFpy + "]";
	}

}
