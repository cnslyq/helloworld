package com.lenovo.bi.dto.sc;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

public class OtsRemarkChartData {

	private int make;
	private int fail;
	private int toBeMake;
	private int toBeFail;
	private int total;//for each product or region or odm or detractor code
	
	private int orderNum;
	private int statusKey;
	private String statusName;
	private int dimensionKey;
	private String dimensionName;
	private double failRate;
	private double toBeFailRate;
	
	MathContext mc = new MathContext(2, RoundingMode.HALF_UP);
	
	public int getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}
	public int getStatusKey() {
		return statusKey;
	}
	public void setStatusKey(int statusKey) {
		this.statusKey = statusKey;
	}
	public int getDimensionKey() {
		return dimensionKey;
	}
	public void setDimensionKey(int dimensionKey) {
		this.dimensionKey = dimensionKey;
	}
	public String getDimensionName() {
		return dimensionName;
	}
	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public double getFailRate() {
		return Math.round(new BigDecimal(fail).divide(
				new BigDecimal(make).add(new BigDecimal(fail))
				.add(new BigDecimal(toBeMake)).add(new BigDecimal(toBeFail))
				,mc
			    )
				.multiply(new BigDecimal(100)).doubleValue());
	}
	public void setFailRate(float failRate) {
		this.failRate = failRate;
	}
	public double getToBeFailRate() {
		return  Math.round(new BigDecimal(toBeFail).divide(
				new BigDecimal(make).add(new BigDecimal(fail))
				.add(new BigDecimal(toBeMake)).add(new BigDecimal(toBeFail))
				,mc
			    )
				.multiply(new BigDecimal(100)).doubleValue());
	}
	public void setToBeFailRate(float toBeFailRate) {
		this.toBeFailRate = toBeFailRate;
	}
	public int getMake() {
		return make;
	}
	public void setMake(int make) {
		this.make = make;
	}
	public int getFail() {
		return fail;
	}
	public void setFail(int fail) {
		this.fail = fail;
	}
	public int getToBeMake() {
		return toBeMake;
	}
	public void setToBeMake(int toBeMake) {
		this.toBeMake = toBeMake;
	}
	public int getToBeFail() {
		return toBeFail;
	}
	public void setToBeFail(int toBeFail) {
		this.toBeFail = toBeFail;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
	
}
