package com.lenovo.bi.enumobj;

public enum FutureEnum {
	
	Future_order("008080"),
	Future_order_L("0066cc"),
	Late_RSD_L("ff6633"),
	Late_order_L("cccccc");
	
	private String color;
	
	FutureEnum(){
		
	}
	
	FutureEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}
}
