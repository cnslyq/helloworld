package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.lenovo.bi.enumobj.JobStatusEnum;

@Entity
@Table(name="BI_BIWeeklyProcessStatus")
public class BiWeeklyProcessStatus {
	@Id
	@GeneratedValue
	private int biWeeklyProcessStatusId;
	
	@Column
	private Date versionDate;
	
	@Column
	private Date processDate;
	
	@Enumerated(EnumType.STRING)
	@Column 
	private JobStatusEnum jobStatus;
	
	@Column
	private String stacktrace;
	
	@Column
	private Date lastModifiedDate;

	public int getBiWeeklyStatusId() {
		return biWeeklyProcessStatusId;
	}

	public void setBiWeeklyStatusId(int biWeeklyStatusId) {
		this.biWeeklyProcessStatusId = biWeeklyStatusId;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Date getProcessDate() {
		return processDate;
	}

	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}

	public JobStatusEnum getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(JobStatusEnum jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getStacktrace() {
		return stacktrace;
	}

	public void setStacktrace(String stacktrace) {
		this.stacktrace = stacktrace;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
}
