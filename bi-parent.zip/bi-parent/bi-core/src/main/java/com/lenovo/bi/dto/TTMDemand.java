package com.lenovo.bi.dto;
/**
 * 
 * 
 * @author henry_lian
 *
 */
public class TTMDemand {
	
	private Integer pmsWaveId;
	private String bomNumber;
	private Integer cvKey;
	private Integer demand;
	public Integer getPmsWaveId() {
		return pmsWaveId;
	}
	public void setPmsWaveId(Integer pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}
	public String getBomNumber() {
		return bomNumber;
	}
	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}
	public Integer getCvKey() {
		return cvKey;
	}
	public void setCvKey(Integer cvKey) {
		this.cvKey = cvKey;
	}
	public Integer getDemand() {
		return demand;
	}
	public void setDemand(Integer demand) {
		this.demand = demand;
	}
	
}
