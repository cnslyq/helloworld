package com.lenovo.bi.enumobj;

public enum PhaseEnum {
	NPI, SC;
}
