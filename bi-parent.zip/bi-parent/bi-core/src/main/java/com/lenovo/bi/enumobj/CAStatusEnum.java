package com.lenovo.bi.enumobj;

public enum CAStatusEnum {

	//if MFG CA: Commitment,Risk order,Commited order,Shipment
	//if Sales CA: Outlook,Risk order,Commited order,shipment
	Shipment("Shipment",1),
	RiskOrder("Risk order",2),
	CommitedOrder("Committed Backlog",3),
	FUTURE("Future order",4),
	Commitment("Commitment",5),
	Outlook("Outlook",6),
	Total("Total",7),
	BOH("BOH",8),
	CATarget("CATarget",9),
	CTP("CTP",10),
	UNKNOWN("Unknown",11),
	
	;
	
	private String typeName;
	private int value;
	
	private CAStatusEnum(String typeName,int value) {
		this.typeName = typeName;
		this.value = value;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
}
