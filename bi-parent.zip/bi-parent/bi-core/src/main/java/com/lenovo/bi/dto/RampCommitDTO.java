package com.lenovo.bi.dto;

import java.util.Date;

/**
 * ramp commit dto
 * 
 * @author henry_lian
 *
 */
public class RampCommitDTO {

	private Integer value;
	
	private Date targetDate;

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	
}
