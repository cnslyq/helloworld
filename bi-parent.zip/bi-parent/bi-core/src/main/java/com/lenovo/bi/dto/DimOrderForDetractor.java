package com.lenovo.bi.dto;

public class DimOrderForDetractor {

	private int orderKey;

	public int getOrderKey() {
		return orderKey;
	}

	public void setOrderKey(int orderKey) {
		this.orderKey = orderKey;
	}
	
	
}
