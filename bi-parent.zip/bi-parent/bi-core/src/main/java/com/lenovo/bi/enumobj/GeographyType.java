package com.lenovo.bi.enumobj;
/**
 * 
 * 
 * @author henry_lian
 *
 */
public enum GeographyType {
	Geo,Region,Country
}
