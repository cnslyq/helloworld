package com.lenovo.bi.dto;

import java.util.Date;

/**
 * 
 * 
 * @author henry_lian, han_ying
 * 
 */
public class TTVOutlookChartData {
	/**
	 * calculated(estimated) TTV
	 * 
	 * SLE ttv
	 * 
	 */
	private Float ttv;

	/**
	 * calculated SGA TTV
	 * 
	 */
	private Float sgaTTV;
	/**
	 * Start date
	 * 
	 * For weekly view, it would be Monday
	 * 
	 */
	private Date date;

	/**
	 * odm commitment
	 * 
	 */
	private Integer odmCommit;

	/**
	 * Order quantity for future
	 */
	private Integer futureOrder;

	/**
	 * Forecast quantity for future
	 */
	private Integer futureForecast;

	/**
	 * future capacity
	 * 
	 */
	private Integer capacity = -1;
	/**
	 * shipment(history capacity)
	 * 
	 */
	private Integer shipment = -1;
	/**
	 * history demand
	 * 
	 */
	private Integer order = -1;
	/**
	 * gap of the day/week, >= 0
	 * 
	 */
	private Integer gap;
	/**
	 * total gap
	 * 
	 */
	private Integer totalGap;

	/**
	 * odm capacity of the week
	 */
	private Integer odm;

	/**
	 * tooling capacity of the week
	 * 
	 */
	private Integer tooling;

	/**
	 * supply of the week
	 * 
	 */
	private Integer supply;

	private Integer demandRolling;

	private Integer rampCommit;
	private Integer estimatedCapacity;
	private Integer forecast;
	private Float sgaEstimatedTTV;
	private Float ttvTarget;
	/**
	 * accumulated demand
	 * 
	 */
	private Integer demand;
	private Date versionDate;
	public Integer getOdm() {
		return odm;
	}

	public void setOdm(Integer odm) {
		this.odm = odm;
	}

	public Integer getTooling() {
		return tooling;
	}

	public void setTooling(Integer tooling) {
		this.tooling = tooling;
	}

	public Integer getSupply() {
		return supply;
	}

	public void setSupply(Integer supply) {
		this.supply = supply;
	}

	public Integer getCapacity() {
		return capacity;
	}

	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}

	public Integer getShipment() {
		return shipment;
	}

	public void setShipment(Integer shipment) {
		this.shipment = shipment;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	public float getTtv() {
		return ttv;
	}

	public void setTtv(float ttv) {
		this.ttv = ttv;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Integer getTotalGap() {
		return totalGap;
	}

	public void setTotalGap(Integer totalGap) {
		this.totalGap = totalGap;
	}

	public Integer getOdmCommit() {
		return odmCommit;
	}

	public void setOdmCommit(Integer odmCommit) {
		this.odmCommit = odmCommit;
	}

	public Integer getFutureOrder() {
		return futureOrder;
	}

	public void setFutureOrder(Integer futureOrder) {
		this.futureOrder = futureOrder;
	}

	public Integer getFutureForecast() {
		return futureForecast;
	}

	public void setFutureForecast(Integer futureForecast) {
		this.futureForecast = futureForecast;
	}

	public Integer getGap() {
		return gap;
	}

	public void setGap(Integer gap) {
		this.gap = gap;
	}

	public Integer getDemandRolling() {
		return demandRolling;
	}

	public void setDemandRolling(Integer demandRolling) {
		this.demandRolling = demandRolling;
	}

	public Float getSgaTTV() {
		return sgaTTV;
	}

	public void setSgaTTV(Float sgaTTV) {
		this.sgaTTV = sgaTTV;
	}

	public Integer getRampCommit() {
		return rampCommit;
	}

	public void setRampCommit(Integer rampCommit) {
		this.rampCommit = rampCommit;
	}

	public Integer getEstimatedCapacity() {
		return estimatedCapacity;
	}

	public void setEstimatedCapacity(Integer estimatedCapacity) {
		this.estimatedCapacity = estimatedCapacity;
	}

	public Integer getForecast() {
		return forecast;
	}

	public void setForecast(Integer forecast) {
		this.forecast = forecast;
	}

	public Float getSgaEstimatedTTV() {
		return sgaEstimatedTTV;
	}

	public void setSgaEstimatedTTV(Float sgaEstimatedTTV) {
		this.sgaEstimatedTTV = sgaEstimatedTTV;
	}

	public Float getTtvTarget() {
		return ttvTarget;
	}

	public void setTtvTarget(Float ttvTarget) {
		this.ttvTarget = ttvTarget;
	}

	public void setTtv(Float ttv) {
		this.ttv = ttv;
	}

	public Integer getDemand() {
		return demand;
	}

	public void setDemand(Integer demand) {
		this.demand = demand;
	}
	
	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	@Override
	public String toString() {
		return "TTVOutlookChartData [ttv=" + ttv + ", sgaTTV=" + sgaTTV
				+ ", date=" + date + ", odmCommit=" + odmCommit
				+ ", futureOrder=" + futureOrder + ", futureForecast="
				+ futureForecast + ", capacity=" + capacity + ", shipment="
				+ shipment + ", order=" + order + ", gap=" + gap
				+ ", totalGap=" + totalGap + ", odm=" + odm + ", tooling="
				+ tooling + ", supply=" + supply + ", demandRolling="
				+ demandRolling + ", rampCommit=" + rampCommit
				+ ", estimatedCapacity=" + estimatedCapacity + ", forecast="
				+ forecast + ", sgaEstimatedTTV=" + sgaEstimatedTTV
				+ ", ttvTarget=" + ttvTarget + ", demand=" + demand + "]";
	}
}
