package com.lenovo.bi.enumobj;

public enum LtfcTypeEnum {
	Ltfc("Ltfc"),
	Mps("Mps"),
	Outlook("Outlook"),
	Order("Order"),
	ToolingWaste("ToolingWaste")
	;
	
	private String typeName;
	
	private LtfcTypeEnum(String typeName) {
		this.typeName = typeName;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
}
