package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BI_TTVWeeklyDetail")
public class TtvWeeklyDetail {
	@Id
	@GeneratedValue
	@Column(name = "TTVWeeklyDetailId")
	private Integer ttvWeeklyDetailId;

	@Column(name = "VersionDate")
	private Date versionDate;

	@Column(name = "PMSWaveID")
	private Integer pmsWaveId;

	@Column(name = "TargetDate")
	private Date targetDate;

	@Column(name = "FutureOrderQuantity")
	private Integer futureOrderQuantity;

	@Column
	private Integer futureForecastQuantity;

	@Column
	private Integer backOrderQuantity;

	@Column(name = "OrderQuantity", updatable = false)
	private Integer orderQuantity;

	@Column(name = "ShipQuantity", updatable = false)
	private Integer shipQuantity;

	@Column(name = "ODMCommit")
	private Integer odmCommit;

	@Column(name = "SupplyCommit")
	private Integer supplyCommit;

	@Column(name = "CoverA")
	private Integer coverA;

	@Column(name = "CoverB")
	private Integer coverB;

	@Column(name = "CoverC")
	private Integer coverC;

	@Column(name = "CoverD")
	private Integer coverD;

	@Column(name = "ODMFPYCapacity")
	private Integer odmFpyCapacity;

	@Column(name = "ODMRPYCapacity")
	private Integer odmRpyCapacity;

	@Column(name = "TDMSFPYCapacity")
	private Integer tdmsFpyCapacity;

	@Column(name = "TDMSRPYCapacity")
	private Integer tdmsRpyCapacity;

	@Column(name = "TDMSFPY")
	private Float tdmsFpy;

	@Column
	private Date createdDate;

	@Column
	private Date lastModifiedDate;

	@Column(name = "FGQuantity", updatable = false)
	private Integer fgQuantity;

	public Integer getTtvWeeklyDetailId() {
		return ttvWeeklyDetailId;
	}

	public void setTtvWeeklyDetailId(Integer ttvWeeklyDetailId) {
		this.ttvWeeklyDetailId = ttvWeeklyDetailId;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Integer getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(Integer pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public Integer getFutureOrderQuantity() {
		return futureOrderQuantity;
	}

	public void setFutureOrderQuantity(Integer futureOrderQuantity) {
		this.futureOrderQuantity = futureOrderQuantity;
	}

	public Integer getFutureForecastQuantity() {
		return futureForecastQuantity;
	}

	public void setFutureForecastQuantity(Integer futureForecastQuantity) {
		this.futureForecastQuantity = futureForecastQuantity;
	}

	public Integer getBackOrderQuantity() {
		return backOrderQuantity;
	}

	public void setBackOrderQuantity(Integer backOrderQuantity) {
		this.backOrderQuantity = backOrderQuantity;
	}

	public Integer getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(Integer orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public Integer getShipQuantity() {
		return shipQuantity;
	}

	public void setShipQuantity(Integer shipQuantity) {
		this.shipQuantity = shipQuantity;
	}

	public Integer getOdmCommit() {
		return odmCommit;
	}

	public void setOdmCommit(Integer odmCommit) {
		this.odmCommit = odmCommit;
	}

	public Integer getSupplyCommit() {
		if (supplyCommit == null) {
			return -1;
		}
		return supplyCommit;
	}

	public void setSupplyCommit(Integer supplyCommit) {
		this.supplyCommit = supplyCommit;
	}

	public Integer getCoverA() {
		if (coverA == null) {
			return -1;
		}
		return coverA;
	}

	public void setCoverA(Integer coverA) {
		this.coverA = coverA;
	}

	public Integer getCoverB() {
		if (coverB == null) {
			return -1;
		}
		return coverB;
	}

	public void setCoverB(Integer coverB) {
		this.coverB = coverB;
	}

	public Integer getCoverC() {
		if (coverC == null) {
			return -1;
		}
		return coverC;
	}

	public void setCoverC(Integer coverC) {
		this.coverC = coverC;
	}

	public Integer getCoverD() {
		if (coverD == null) {
			return -1;
		}
		return coverD;
	}

	public void setCoverD(Integer coverD) {
		this.coverD = coverD;
	}

	public Integer getOdmFpyCapacity() {
		if (odmFpyCapacity == null) {
			return -1;
		}
		return odmFpyCapacity;
	}

	public void setOdmFpyCapacity(Integer odmFpyCapacity) {
		this.odmFpyCapacity = odmFpyCapacity;
	}

	public Integer getOdmRpyCapacity() {
		if (odmRpyCapacity == null) {
			return -1;
		}
		return odmRpyCapacity;
	}

	public void setOdmRpyCapacity(Integer odmRpyCapacity) {
		this.odmRpyCapacity = odmRpyCapacity;
	}

	public Integer getTdmsFpyCapacity() {
		if (tdmsFpyCapacity == null) {
			return -1;
		}
		return tdmsFpyCapacity;
	}

	public void setTdmsFpyCapacity(Integer tdmsFpyCapacity) {
		this.tdmsFpyCapacity = tdmsFpyCapacity;
	}

	public Integer getTdmsRpyCapacity() {
		if (tdmsRpyCapacity == null) {
			return -1;
		}
		return tdmsRpyCapacity;
	}

	public void setTdmsRpyCapacity(Integer tdmsRpyCapacity) {
		this.tdmsRpyCapacity = tdmsRpyCapacity;
	}

	public Float getTdmsFpy() {
		return tdmsFpy;
	}

	public void setTdmsFpy(Float tdmsFpy) {
		this.tdmsFpy = tdmsFpy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Integer getFgQuantity() {
		if (fgQuantity == null) {
			return -1;
		}
		return fgQuantity;
	}

	public void setFgQuantity(Integer fgQuantity) {
		this.fgQuantity = fgQuantity;
	}

	@Override
	public String toString() {
		return "TtvWeeklyDetail [ttvWeeklyDetailId=" + ttvWeeklyDetailId + ", versionDate=" + versionDate + ", pmsWaveId=" + pmsWaveId + ", targetDate="
				+ targetDate + ", futureDemandQuantity=" + futureOrderQuantity + ", orderQuantity=" + orderQuantity + ", shipQuantity=" + shipQuantity
				+ ", odmCommit=" + odmCommit + ", supplyCommit=" + supplyCommit + ", coverA=" + coverA + ", coverB=" + coverB + ", coverC=" + coverC
				+ ", coverD=" + coverD + ", odmFpyCapacity=" + odmFpyCapacity + ", odmRpyCapacity=" + odmRpyCapacity + ", tdmsFpyCapacity=" + tdmsFpyCapacity
				+ ", tdmsFpy=" + tdmsFpy + ", fgQuantity=" + fgQuantity + "]";
	}

}
