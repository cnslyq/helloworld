package com.lenovo.bi.enumobj;

public enum Risk {

	All,
	Risk("DC143C", true, "red"),
	No_Risk("32CD32",false,"green");
	
	private String color;
	private String labelColor;
	private boolean isRisk;
	
	Risk(){
		
	}
	
	Risk(String color, boolean isRisk, String labelColor){
		this.color = color;
		this.isRisk = isRisk;
		this.labelColor = labelColor;
	}
	
	@Override
	public String toString() {
		return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}

	public String getLabelColor() {
		return labelColor;
	}

	public boolean isRisk() {
		return isRisk;
	}

	public static Risk fromBoolean(Boolean isRisk){
		if (isRisk){
			return Risk;
		} else{
			return No_Risk;
		}
		
	}
	
}
