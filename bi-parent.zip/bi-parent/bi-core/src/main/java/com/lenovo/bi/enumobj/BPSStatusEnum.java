package com.lenovo.bi.enumobj;

public enum BPSStatusEnum {
	
	
	
	BPS("BPS",1),
	Unshipped("Unshipped",2);
	
	private String typeName;
	private int value;
	
	private BPSStatusEnum(String typeName,int value) {
		this.typeName = typeName;
		this.value = value;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
}
