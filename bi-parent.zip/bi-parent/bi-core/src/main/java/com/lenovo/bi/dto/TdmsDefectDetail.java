package com.lenovo.bi.dto;

import java.util.Date;

public class TdmsDefectDetail extends TdmsDefect{
	private String defectNo; 
	private String category; 
	private String description;
	private String status; // DefectStatus
	private String owner; // DefectOwner
	private Date beginDate;
	
	public String getDefectNo() {
		return defectNo;
	}
	public void setDefectNo(String defectNo) {
		this.defectNo = defectNo;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public Date getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}
}
