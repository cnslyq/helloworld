package com.lenovo.bi.dto;

import java.util.Date;

public class TdmsDefect {
	private int tdmsDefectId; //modified by Nicolas on July 14 2014
	private Float fpyImpact;
	private Float failRate;
	private Date targetDate;
	public int getTdmsDefectId() {
		return tdmsDefectId;
	}
	public void setTdmsDefectId(int tdmsDefectId) {
		this.tdmsDefectId = tdmsDefectId;
	}
	public Float getFpyImpact() {
		return fpyImpact;
	}
	public void setFpyImpact(Float fpyImpact) {
		this.fpyImpact = fpyImpact;
	}
	public Float getFailRate() {
		return failRate;
	}
	public void setFailRate(Float failRate) {
		this.failRate = failRate;
	}
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	
}
