package com.lenovo.bi.enumobj;

public enum ToGoCaEnum {

	To_Go_CA("666666");
	
	private String color;
	
	ToGoCaEnum(){
		
	}
	
	ToGoCaEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		return name();
	}
	
	public String getName(){
		return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}
}
