package com.lenovo.bi.dto;

import java.util.Date;


/**
 * 
 * 
 * @author Henry_Lian
 *
 */
public class NPIWaveInfo {

	private int pmsWaveId;
	private int pmsProjectId;
	private Date startDate;
	private Date endDate;
	private String productName;
	private String waveName;
	private Date ttmTargetDate;
	private Date ttmSignOffDate;
	private Date ttvTargetDate;//old: from SGA; new: from SLE
	private Date sgaTtvTargetDate;//sga date
	private Date sgaTtvSignOffDate;
	private Date ttvSignOffDate;
	private Float ttvTarget;
	private Float sgaTtvTarget;
	private String family;
	private String pm;
	private Date svtPlanDate;
	private Date sovpPlanDate;
	private Float obeTarget ;
	private Integer phaseNumber;
	private String currentPhase;
	private Float fpyTarget;
	
	public Integer getPhaseNumber() {
		return phaseNumber;
	}
	public void setPhaseNumber(Integer phaseNumber) {
		this.phaseNumber = phaseNumber;
	}
	public int getPmsWaveId() {
		return pmsWaveId;
	}
	public void setPmsWaveId(int pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}
	public int getPmsProjectId() {
		return pmsProjectId;
	}
	public void setPmsProjectId(int pmsProjectId) {
		this.pmsProjectId = pmsProjectId;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getWaveName() {
		return waveName;
	}
	public void setWaveName(String waveName) {
		this.waveName = waveName;
	}
	public Date getTtmTargetDate() {
		return ttmTargetDate;
	}
	public void setTtmTargetDate(Date ttmTargetDate) {
		this.ttmTargetDate = ttmTargetDate;
	}
	public Date getTtmSignOffDate() {
		return ttmSignOffDate;
	}
	public void setTtmSignOffDate(Date ttmSignOffDate) {
		this.ttmSignOffDate = ttmSignOffDate;
	}
	public Date getTtvTargetDate() {
		return ttvTargetDate;
	}
	public void setTtvTargetDate(Date ttvTargetDate) {
		this.ttvTargetDate = ttvTargetDate;
	}
	public Date getTtvSignOffDate() {
		return ttvSignOffDate;
	}
	public void setTtvSignOffDate(Date ttvSignOffDate) {
		this.ttvSignOffDate = ttvSignOffDate;
	}
	public Float getTtvTarget() {
		return ttvTarget;
	}
	public void setTtvTarget(Float ttvTarget) {
		this.ttvTarget = ttvTarget;
	}
	public String getFamily() {
		return family;
	}
	public void setFamily(String family) {
		this.family = family;
	}
	public String getPm() {
		return pm;
	}
	public void setPm(String pm) {
		this.pm = pm;
	}
	public Date getSvtPlanDate() {
		return svtPlanDate;
	}
	public void setSvtPlanDate(Date svtPlanDate) {
		this.svtPlanDate = svtPlanDate;
	}
	public Date getSovpPlanDate() {
		return sovpPlanDate;
	}
	public void setSovpPlanDate(Date sovpPlanDate) {
		this.sovpPlanDate = sovpPlanDate;
	}
	public Float getObeTarget() {
		return obeTarget;
	}
	public void setObeTarget(Float obeTarget) {
		this.obeTarget = obeTarget;
	}
	public String getCurrentPhase() {
		return currentPhase;
	}
	public void setCurrentPhase(String currentPhase) {
		this.currentPhase = currentPhase;
	}
	public Date getSgaTtvTargetDate() {
		return sgaTtvTargetDate;
	}
	public void setSgaTtvTargetDate(Date sgaTtvTargetDate) {
		this.sgaTtvTargetDate = sgaTtvTargetDate;
	}
	public Date getSgaTtvSignOffDate() {
		return sgaTtvSignOffDate;
	}
	public void setSgaTtvSignOffDate(Date sgaTtvSignOffDate) {
		this.sgaTtvSignOffDate = sgaTtvSignOffDate;
	}
	public Float getSgaTtvTarget() {
		return sgaTtvTarget;
	}
	public void setSgaTtvTarget(Float sgaTtvTarget) {
		this.sgaTtvTarget = sgaTtvTarget;
	}
	public Float getFpyTarget() {
		return fpyTarget;
	}
	public void setFpyTarget(Float fpyTarget) {
		this.fpyTarget = fpyTarget;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
}
