package com.lenovo.bi.dto.sc;

public class LTFCRemarkChartData {
	private String scStatusName;
	private int failRate;
	private int orderNum;
	private String subDimensionName;
	private int subDimensionValue;
	private Integer subDimensionKey;
	private float ltfcRate;
	private Integer minQTY;
	private Integer maxQTY;
		
	private float faRateDashboardChart;
	private float faRate;
	
	public float getRate() {
		return ltfcRate;
	}

	public void setRate(float rate) {
		this.ltfcRate = rate;
	}

	public int getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}

	public String getSubDimensionName() {
		return subDimensionName;
	}

	public void setSubDimensionName(String subDimensionName) {
		this.subDimensionName = subDimensionName;
	}

	public int getSubDimensionValue() {
		return subDimensionValue;
	}

	public void setSubDimensionValue(int subDimensionValue) {
		this.subDimensionValue = subDimensionValue;
	}

	public String getScStatusName() {
		return scStatusName;
	}

	public void setScStatusName(String fpsdStatusName) {
		this.scStatusName = fpsdStatusName;
	}

	public int getFailRate() {
		return failRate;
	}

	public void setFailRate(int failRate) {
		this.failRate = failRate;
	}
	
	public float getFaRateDashboardChart() {
		return faRateDashboardChart;
	}

	public void setFaRateDashboardChart(float faRateDashboardChart) {
		this.faRateDashboardChart = faRateDashboardChart;
	}

	public float getFaRate() {
		return faRate;
	}

	public void setFaRate(float faRate) {
		this.faRate = faRate;
	}

	public Integer getSubDimensionKey() {
		return subDimensionKey;
	}

	public void setSubDimensionKey(Integer subDimensionKey) {
		this.subDimensionKey = subDimensionKey;
	}

	public float getLtfcRate() {
		return ltfcRate;
	}

	public void setLtfcRate(float ltfcRate) {
		this.ltfcRate = ltfcRate;
	}

	public Integer getMinQTY() {
		return minQTY;
	}

	public void setMinQTY(Integer minQTY) {
		this.minQTY = minQTY;
	}

	public Integer getMaxQTY() {
		return maxQTY;
	}

	public void setMaxQTY(Integer maxQTY) {
		this.maxQTY = maxQTY;
	}
	
	
	
}
