package com.lenovo.bi.enumobj;

public enum SupplyEnum {

	BS_parts_shortage("0066cc"),
	ODM_buy_parts_shortage("ff6633"),
	Assign_parts_shortage("cc99cc"),
	Tie_order_L("cccccc"),
	Tie_order_O("0000ff");
	
	private String color;
	
	SupplyEnum(){
		
	}
	
	SupplyEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		if(name().equals("BS_parts_shortage"))
			return name().replaceAll("_", " ").replace("B", "B/");
		else
			return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}
}
