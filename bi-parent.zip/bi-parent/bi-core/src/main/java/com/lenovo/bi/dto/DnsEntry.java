package com.lenovo.bi.dto;

import com.lenovo.bi.enumobj.DnsShortageCodeEnum;

public class DnsEntry {
	private int cvKey;
	private DnsShortageCodeEnum shortageCode;
	private int demand;
	private int supply;
	private int delta;
	private int normalQuantity;
	private int upsideQuantity;
	private int totalDemand;
	private int bizMonth;
	private int bizWeek;
	private int bizYear;
	private int versionDateKey;
	private int targetDateKey;
	private int monthno;
	public int getCvKey() {
		return cvKey;
	}
	public void setCvKey(int cvKey) {
		this.cvKey = cvKey;
	}
	public DnsShortageCodeEnum getShortageCode() {
		return shortageCode;
	}
	public void setShortageCode(DnsShortageCodeEnum shortageCode) {
		this.shortageCode = shortageCode;
	}
	public int getDemand() {
		return demand;
	}
	public void setDemand(int demand) {
		this.demand = demand;
	}
	public int getSupply() {
		return supply;
	}
	public void setSupply(int supply) {
		this.supply = supply;
	}
	public int getDelta() {
		return delta;
	}
	public void setDelta(int delta) {
		this.delta = delta;
	}
	public int getNormalQuantity() {
		return normalQuantity;
	}
	public void setNormalQuantity(int normalQuantity) {
		this.normalQuantity = normalQuantity;
	}
	public int getUpsideQuantity() {
		return upsideQuantity;
	}
	public void setUpsideQuantity(int upsideQuantity) {
		this.upsideQuantity = upsideQuantity;
	}
	public int getTotalDemand() {
		return totalDemand;
	}
	public void setTotalDemand(int totalDemand) {
		this.totalDemand = totalDemand;
	}
	public int getBizMonth() {
		return bizMonth;
	}
	public void setBizMonth(int bizMonth) {
		this.bizMonth = bizMonth;
	}
	public int getBizWeek() {
		return bizWeek;
	}
	public void setBizWeek(int bizWeek) {
		this.bizWeek = bizWeek;
	}
	public int getBizYear() {
		return bizYear;
	}
	public void setBizYear(int bizYear) {
		this.bizYear = bizYear;
	}
	public int getVersionDateKey() {
		return versionDateKey;
	}
	public void setVersionDateKey(int versionDateKey) {
		this.versionDateKey = versionDateKey;
	}
	public int getTargetDateKey() {
		return targetDateKey;
	}
	public void setTargetDateKey(int targetDateKey) {
		this.targetDateKey = targetDateKey;
	}
	public int getMonthno() {
		return monthno;
	}
	public void setMonthno(int monthno) {
		this.monthno = monthno;
	}



}
