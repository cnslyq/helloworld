package com.lenovo.bi.enumobj;

public enum DBEnum {

	Delivery_block_L("cccccc"),
	Delivery_block("dda0dd");
	
	private String color;
	
	DBEnum(){
		
	}
	
	DBEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}
}
