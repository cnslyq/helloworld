package com.lenovo.bi.model.system;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * 
 * @author henry_lian
 *
 */
@Entity
@Table(name="BI_Configurables")
public class Configurables {
	
	@Id
	@GeneratedValue
	private Integer id;
	@Column(name="Name")
	private String name;
	@Column(name="Value")
	private Float value;
	@Column(name="Description")
	private String description;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Float getValue() {
		return value;
	}
	public void setValue(Float value) {
		this.value = value;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
