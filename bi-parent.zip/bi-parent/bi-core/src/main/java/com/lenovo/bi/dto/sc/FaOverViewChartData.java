package com.lenovo.bi.dto.sc;

import org.hibernate.type.FloatType;
import org.hibernate.type.IntegerType;

public class FaOverViewChartData {

	private String faType; //Mps,GrossForecast,outlook
	private String typeName; 
	private float typeValue;
	private float mpsValue;
	private float grossValue;
	private float OrderQty;
	private String rowName; 
	private int value;
	private float faRateDashboardChart;
	
	private int FAValue;
	private float FARate;

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public float getTypeValue() {
		return typeValue;
	}

	public void setTypeValue(float typeValue) {
		this.typeValue = typeValue;
	}

	public String getFaType() {
		return faType;
	}

	public void setFaType(String faType) {
		this.faType = faType;
	}

	public String getRowName() {
		return rowName;
	}

	public void setRowName(String rowName) {
		this.rowName = rowName;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public float getMpsValue() {
		return mpsValue;
	}

	public void setMpsValue(float mpsValue) {
		this.mpsValue = mpsValue;
	}

	public float getGrossValue() {
		return grossValue;
	}

	public void setGrossValue(float grossValue) {
		this.grossValue = grossValue;
	}

	public float getFaRateDashboardChart() {
		return faRateDashboardChart;
	}

	public void setFaRateDashboardChart(float faRateDashboardChart) {
		this.faRateDashboardChart = faRateDashboardChart;
	}

	public int getFAValue() {
		return FAValue;
	}

	public void setFAValue(int fAValue) {
		FAValue = fAValue;
	}

	public float getFARate() {
		return FARate;
	}

	public void setFARate(float fARate) {
		FARate = fARate;
	}

	public float getOrderQty() {
		return OrderQty;
	}

	public void setOrderQty(float orderQty) {
		OrderQty = orderQty;
	}
	

}
