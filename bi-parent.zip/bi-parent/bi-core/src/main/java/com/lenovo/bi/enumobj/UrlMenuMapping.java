package com.lenovo.bi.enumobj;

public enum UrlMenuMapping {

	_NPI_TTM_ALL_OVERVIEW("NPI"),
	_NPI_TTM_ALL_INPROGRESS("NPI"),
	_NPI_TTM_ALL_SUCCESS("NPI"),
	_NPI_TTM_ALL_FAIL("NPI"),
	_NPI_TTM_ALL_NA("NPI"),
	_NPI_TTM_MY_OVERVIEW("NPI"),
	_NPI_TTM_MY_INPROGRESS("NPI"),
	_NPI_TTM_MY_SUCCESS("NPI"),
	_NPI_TTM_MY_FAIL("NPI"),
	_NPI_TTM_MY_NA("NPI"),
	_NPI_TTM_DOI("NPI"),
	_NPI_TTV_ALL_OVERVIEW("NPI"),
	_NPI_TTV_ALL_INPROGRESS("NPI"),
	_NPI_TTV_ALL_SUCCESS("NPI"),
	_NPI_TTV_ALL_FAIL("NPI"),
	_NPI_TTV_ALL_NA("NPI"),
	_NPI_TTV_MY_OVERVIEW("NPI"),
	_NPI_TTV_MY_INPROGRESS("NPI"),
	_NPI_TTV_MY_SUCCESS("NPI"),
	_NPI_TTV_MY_FAIL("NPI"),
	_NPI_TTV_MY_NA("NPI");
	
	
	private String topLevelMenu;
	
	UrlMenuMapping(String topLevelMenu){
		this.topLevelMenu = topLevelMenu;
	}

	public String getTopLevelMenu() {
		return topLevelMenu;
	}

	public void setTopLevelMenu(String topLevelMenu) {
		this.topLevelMenu = topLevelMenu;
	}
	
	
}
