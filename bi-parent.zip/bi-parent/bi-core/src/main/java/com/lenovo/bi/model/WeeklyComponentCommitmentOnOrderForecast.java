package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BI_WeeklyComponentCommitmentOnOrderForecast")
public class WeeklyComponentCommitmentOnOrderForecast {
	@Id
	@GeneratedValue
	@Column
	private int weeklyComponentCommitmentOnOrderForecastId;
	
	@Column
	private String poNumber;
	
	@Column
	private String poItem;
	
	@Column
	private int globalCvKey;
	
	@Column
	private int demand;
	
	@Column
	private int commitment;
	
	@Column
	private int delta;
	
	@Column
	private String productKey;
	
	@Column
	private String bomNumber;
	
	@Column
	private boolean forNpi;
	
	@Column
	private Date targetDate;
	
	@Column
	private Date versionDate;
	
	@Column
	private Date createdDate;
	
	@Column
	private Date lastModifiedDate;
	
	@Column
	private String ttvPhase;
	
	@Column
	private Date orderDate;
	
	@Column
	private Date rsdDate;
	
	@Column
	private String region;
	
	@Column
	private Integer orderQuantity;
	
	public String getTtvPhase() {
		return ttvPhase;
	}

	public void setTtvPhase(String ttvPhase) {
		this.ttvPhase = ttvPhase;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Date getRsdDate() {
		return rsdDate;
	}

	public void setRsdDate(Date rsdDate) {
		this.rsdDate = rsdDate;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public Integer getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(Integer orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public void setProductKey(String productKey) {
		this.productKey = productKey;
	}

	public int getWeeklyComponentCommitmentOnOrderForecastId() {
		return weeklyComponentCommitmentOnOrderForecastId;
	}

	public void setWeeklyComponentCommitmentOnOrderForecastId(
			int weeklyComponentCommitmentOnOrderForecastId) {
		this.weeklyComponentCommitmentOnOrderForecastId = weeklyComponentCommitmentOnOrderForecastId;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoItem() {
		return poItem;
	}

	public void setPoItem(String poItem) {
		this.poItem = poItem;
	}

	public int getGlobalCvKey() {
		return globalCvKey;
	}

	public void setGlobalCvKey(int globalCvKey) {
		this.globalCvKey = globalCvKey;
	}

	public int getDemand() {
		return demand;
	}

	public void setDemand(int demand) {
		this.demand = demand;
	}

	public int getCommitment() {
		return commitment;
	}

	public void setCommitment(int commitment) {
		this.commitment = commitment;
	}

	public int getDelta() {
		return delta;
	}

	public void setDelta(int delta) {
		this.delta = delta;
	}

	public String getProductKey() {
		return productKey;
	}

	public void setProductKey(Integer productKey) {
		this.productKey = Integer.toString(productKey);
	}

	public String getBomNumber() {
		return bomNumber;
	}

	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}

	public boolean getForNpi() {
		return forNpi;
	}

	public void setForNpi(boolean forNpi) {
		this.forNpi = forNpi;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String toString() {
		return "WeeklyComponentCommitmentOnOrderForecast [weeklyComponentCommitmentOnOrderForecastId="
				+ weeklyComponentCommitmentOnOrderForecastId
				+ ", poNumber="
				+ poNumber
				+ ", poItem="
				+ poItem
				+ ", globalCvKey="
				+ globalCvKey
				+ ", demand="
				+ demand
				+ ", commitment="
				+ commitment
				+ ", delta="
				+ delta
				+ ", productKey="
				+ productKey
				+ ", bomNumber="
				+ bomNumber
				+ ", forNpi="
				+ forNpi
				+ ", targetDate="
				+ targetDate
				+ ", versionDate="
				+ versionDate
				+ ", createdDate="
				+ createdDate
				+ ", lastModifiedDate="
				+ lastModifiedDate + "]";
	}
	
}
