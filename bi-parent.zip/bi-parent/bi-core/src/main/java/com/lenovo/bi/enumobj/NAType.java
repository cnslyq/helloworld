package com.lenovo.bi.enumobj;

public enum NAType {
	All,
	No_Project_Plan,
	No_TTV_Target_Date;
	
	@Override
	public String toString() {
		return name().replaceAll("_", " ");
	}
	
}
