package com.lenovo.bi.enumobj;

public enum VLevelEnum {

	Intel_i5("0000ff"),//橙黄
	Intel_i6("cc99ff"),//紫色
	Intel_i7("ff6633");//桔黄
	
	private String color;
	
	VLevelEnum(){
		
	}
	
	VLevelEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		if(name().equals("MFG_Quality") || name().equals("NEW_Working"))
			return name().replaceAll("_", "/");
		else
			return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}
}
