package com.lenovo.bi.dto;

public class CvQuantity {
	private int cvKey;
	private int quantity;
	public int getCvKey() {
		return cvKey;
	}
	public void setCvKey(int cvKey) {
		this.cvKey = cvKey;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
