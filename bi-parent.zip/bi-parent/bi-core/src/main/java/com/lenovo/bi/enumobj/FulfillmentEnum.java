package com.lenovo.bi.enumobj;

public enum FulfillmentEnum {

	Holiday_Cycle_Count("666666");
	
	private String color;
	
	FulfillmentEnum(){
		
	}
	
	FulfillmentEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		return name().replaceAll("_", " ").replace("Holiday ", "Holiday/");
	}
	
	public String getColor(){
		return color;
	}
}
