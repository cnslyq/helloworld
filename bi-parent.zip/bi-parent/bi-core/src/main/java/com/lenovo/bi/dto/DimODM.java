package com.lenovo.bi.dto;

public class DimODM {
	private Integer odmKey;
	private String odmEnglishName;
	private String odmChineseName;

	public Integer getOdmKey() {
		return odmKey;
	}

	public void setOdmKey(Integer odmKey) {
		this.odmKey = odmKey;
	}

	public String getOdmEnglishName() {
		return odmEnglishName;
	}

	public void setOdmEnglishName(String odmEnglishName) {
		this.odmEnglishName = odmEnglishName;
	}

	public String getOdmChineseName() {
		return odmChineseName;
	}

	public void setOdmChineseName(String odmChineseName) {
		this.odmChineseName = odmChineseName;
	}

}
