package com.lenovo.bi.enumobj;

public enum SortType {
	Asc,Desc
}
