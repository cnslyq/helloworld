package com.lenovo.bi.dto;

public class KeyNameObject {

	private Integer objKey;
	private String objName;
	private String type;//Product,Odm,Region,Detractor
	

	public Integer getObjKey() {
		return objKey;
	}

	public void setObjKey(Integer objKey) {
		this.objKey = objKey;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
