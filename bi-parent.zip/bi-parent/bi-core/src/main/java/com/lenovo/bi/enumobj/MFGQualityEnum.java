package com.lenovo.bi.enumobj;

public enum MFGQualityEnum {

	Engineer_issue_L("0066cc"),
	Engineer_issue_O("ff6633"),
	Quality_issue_L("cccccc"),
	Quality_issue_O("0000ff"),
	
	Output_delay("0066cc"),
	Npi_issue_L("669933"),
	Npi_issue_O("ffcc33"),
	Capacity_constraint_L("cc3366"),
	Capacity_constraint_O("666666");
	
	private String color;
	
	MFGQualityEnum(){
		
	}
	
	MFGQualityEnum(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		return name().replaceAll("_", " ");
	}
	
	public String getName(){
		return name().replaceAll("_", " ").replaceAll(" O", "(O)").replaceAll(" L", "(L)");
	}
	
	public String getColor(){
		return color;
	}
}
