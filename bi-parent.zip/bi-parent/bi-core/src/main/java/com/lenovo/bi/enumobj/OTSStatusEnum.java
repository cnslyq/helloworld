package com.lenovo.bi.enumobj;

public enum OTSStatusEnum {

	ALL("all",-1),
	MAKE("Make",1),
	FAIL("Fail",2),
	ToBeMake("To-be Make",3),
	ToBeFail("To-be Fail",4)
	;
	
	private String typeName;
	private int value;
	
	private OTSStatusEnum(String typeName,int value) {
		this.typeName = typeName;
		this.value = value;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

}
