package com.lenovo.bi.dto;

import java.util.Date;

public class FactDailySummaryOfBpsDto {
	
	private int versionDateKey;
	private int targetDateKey;
	private int orderKey;
	private int mtmKey;
	private int productKey;
	private int odmKey;
	private int regionKey;
	private int detractorKey;
	private int orderTypeKey;
	private int orderQuantity;
	private int year;
	private int month;
	private int day;
	private Date createdDate;
	private Date lastModifiedDate;
	private String isBpsOrder;
	private int daysOfOverDue;
	private int id;
	public int getVersionDateKey() {
		return versionDateKey;
	}
	public void setVersionDateKey(int versionDateKey) {
		this.versionDateKey = versionDateKey;
	}
	public int getTargetDateKey() {
		return targetDateKey;
	}
	public void setTargetDateKey(int targetDateKey) {
		this.targetDateKey = targetDateKey;
	}
	public int getOrderKey() {
		return orderKey;
	}
	public void setOrderKey(int orderKey) {
		this.orderKey = orderKey;
	}
	public int getMtmKey() {
		return mtmKey;
	}
	public void setMtmKey(int mtmKey) {
		this.mtmKey = mtmKey;
	}
	public int getProductKey() {
		return productKey;
	}
	public void setProductKey(int productKey) {
		this.productKey = productKey;
	}
	public int getOdmKey() {
		return odmKey;
	}
	public void setOdmKey(int odmKey) {
		this.odmKey = odmKey;
	}
	public int getRegionKey() {
		return regionKey;
	}
	public void setRegionKey(int regionKey) {
		this.regionKey = regionKey;
	}
	public int getDetractorKey() {
		return detractorKey;
	}
	public void setDetractorKey(int detractorKey) {
		this.detractorKey = detractorKey;
	}
	public int getOrderTypeKey() {
		return orderTypeKey;
	}
	public void setOrderTypeKey(int orderTypeKey) {
		this.orderTypeKey = orderTypeKey;
	}
	public int getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getIsBpsOrder() {
		return isBpsOrder;
	}
	public void setIsBpsOrder(String isBpsOrder) {
		this.isBpsOrder = isBpsOrder;
	}
	public int getDaysOfOverDue() {
		return daysOfOverDue;
	}
	public void setDaysOfOverDue(int daysOfOverDue) {
		this.daysOfOverDue = daysOfOverDue;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
