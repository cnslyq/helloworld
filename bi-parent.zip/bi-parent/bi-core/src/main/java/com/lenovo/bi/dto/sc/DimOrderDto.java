package com.lenovo.bi.dto.sc;

import java.util.Date;

public class DimOrderDto {
	
	private		int   		orderKey;		 
	private		String		poNumber;		 
	private		String		poItem;		         
	private		int   		mtmKey;			 
	private		int   		geographyKey;		 
	private		int   		customerKey;		 
	private		int   		quantity;		 
	private		Date  		createdDate;		 
	private		Date  		lastModifiedDate;	 
	private		String		isCurrent;		 
	private		int   		orderDateKey;		 
	private		int   		rsdDateKey;		 
	private		String		orderNumber;		 
	private		String		nineZeroZeroNumber;		 
	private		int   		odmKey;		         
	private		int   		shipDateKey;		 
	private		String		isShipped;		 
	private		int   		fpsdDateKey;		 
	private		String		mot;			 
	private		String		route;			 
	private		int   		detractorKey;		 
	private		String		lateReasonTwo;		 
	private		String		isSplit;			
	private		int   		shipQuantity;		 
	private		int   		fgReadyDateKey;		 
	private		int   		fgReadyQuantity;
	public int getOrderKey() {
		return orderKey;
	}
	public void setOrderKey(int orderKey) {
		this.orderKey = orderKey;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getPoItem() {
		return poItem;
	}
	public void setPoItem(String poItem) {
		this.poItem = poItem;
	}
	public int getMtmKey() {
		return mtmKey;
	}
	public void setMtmKey(int mtmKey) {
		this.mtmKey = mtmKey;
	}
	public int getGeographyKey() {
		return geographyKey;
	}
	public void setGeographyKey(int geographyKey) {
		this.geographyKey = geographyKey;
	}
	public int getCustomerKey() {
		return customerKey;
	}
	public void setCustomerKey(int customerKey) {
		this.customerKey = customerKey;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getIsCurrent() {
		return isCurrent;
	}
	public void setIsCurrent(String isCurrent) {
		this.isCurrent = isCurrent;
	}
	public int getOrderDateKey() {
		return orderDateKey;
	}
	public void setOrderDateKey(int orderDateKey) {
		this.orderDateKey = orderDateKey;
	}
	public int getRsdDateKey() {
		return rsdDateKey;
	}
	public void setRsdDateKey(int rsdDateKey) {
		this.rsdDateKey = rsdDateKey;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getNineZeroZeroNumber() {
		return nineZeroZeroNumber;
	}
	public void setNineZeroZeroNumber(String nineZeroZeroNumber) {
		this.nineZeroZeroNumber = nineZeroZeroNumber;
	}
	public int getOdmKey() {
		return odmKey;
	}
	public void setOdmKey(int odmKey) {
		this.odmKey = odmKey;
	}
	public int getShipDateKey() {
		return shipDateKey;
	}
	public void setShipDateKey(int shipDateKey) {
		this.shipDateKey = shipDateKey;
	}
	public String getIsShipped() {
		return isShipped;
	}
	public void setIsShipped(String isShipped) {
		this.isShipped = isShipped;
	}
	public int getFpsdDateKey() {
		return fpsdDateKey;
	}
	public void setFpsdDateKey(int fpsdDateKey) {
		this.fpsdDateKey = fpsdDateKey;
	}
	public String getMot() {
		return mot;
	}
	public void setMot(String mot) {
		this.mot = mot;
	}
	public String getRoute() {
		return route;
	}
	public void setRoute(String route) {
		this.route = route;
	}
	public int getDetractorKey() {
		return detractorKey;
	}
	public void setDetractorKey(int detractorKey) {
		this.detractorKey = detractorKey;
	}
	public String getLateReasonTwo() {
		return lateReasonTwo;
	}
	public void setLateReasonTwo(String lateReasonTwo) {
		this.lateReasonTwo = lateReasonTwo;
	}
	public String getIsSplit() {
		return isSplit;
	}
	public void setIsSplit(String isSplit) {
		this.isSplit = isSplit;
	}
	public int getShipQuantity() {
		return shipQuantity;
	}
	public void setShipQuantity(int shipQuantity) {
		this.shipQuantity = shipQuantity;
	}
	public int getFgReadyDateKey() {
		return fgReadyDateKey;
	}
	public void setFgReadyDateKey(int fgReadyDateKey) {
		this.fgReadyDateKey = fgReadyDateKey;
	}
	public int getFgReadyQuantity() {
		return fgReadyQuantity;
	}
	public void setFgReadyQuantity(int fgReadyQuantity) {
		this.fgReadyQuantity = fgReadyQuantity;
	}	 
		                                                 
	

}
