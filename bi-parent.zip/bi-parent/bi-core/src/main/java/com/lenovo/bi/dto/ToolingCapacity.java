package com.lenovo.bi.dto;

import java.util.Date;

import com.lenovo.bi.enumobj.CoverEnum;

public class ToolingCapacity {
	private String pmsWaveId;
	private Date targetDate;
	private String cover; //parts
	private int capacity; //capacity
	private Integer boh;

	public String getPmsWaveId() {
		return pmsWaveId;
	}
	public void setPmsWaveId(int pmsWaveId) {
		this.pmsWaveId = String.valueOf(pmsWaveId);
	}
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	public CoverEnum getCover() {
		return CoverEnum.getEnumFromName(this.cover);
	}
	public void setCover(String cover) {
		this.cover = cover;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public Integer getBoh() {
		return boh == null?0:boh;
	}
	public void setBoh(Integer boh) {
		this.boh = boh;
	}

	@Override
	public String toString() {
		return "ToolingCapacity [pmsWaveId=" + pmsWaveId + ", cover=" + cover
				+ ", capacity=" + capacity + ", boh=" + boh + "]";
	}
	
	
}
