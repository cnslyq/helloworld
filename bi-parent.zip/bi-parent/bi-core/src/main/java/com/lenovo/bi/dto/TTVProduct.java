package com.lenovo.bi.dto;

import java.util.Date;

/**
 * 
 * 
 * @author Henry_Lian
 *
 */
public class TTVProduct {
	
	private int waveId;
	private String productName;
	private String waveName;
	private String ttvStatus;
	
	private boolean isProjectPlanned;
	
	private String npi;
	
	private Date ttmTargetDate;
	
	private Date ttmSignOffDate;
	
	private Date ttvTargetDate;
	
	private Date ttvSignOffDate;
	
	private Float ttvTarget;
	
	private Boolean isRisk;
	
	private Float estimatedTTV;
	
	private Float actualTTV;
	
	private int projectId;
	
	private String currentPhase;
	private String pm;
	private Date startDate;
	
	private String sgaTtvStatus;
	
    private Date sgaTtvTargetDate;
	
	private Date sgaTtvSignOffDate;
	
	private Float sgaTtvTarget;
	
	private Float sgaEstimatedTTV;
	
	private Float sgaActualTTV;
	
	private Boolean isSgaTtvRisk;
	
	private String naType;
	
	private String sgaNaType;
	
	public boolean isProjectPlanned() {
		return isProjectPlanned;
	}
	public void setProjectPlanned(boolean isProjectPlanned) {
		this.isProjectPlanned = isProjectPlanned;
	}
	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public Date getTtmTargetDate() {
		return ttmTargetDate;
	}
	public void setTtmTargetDate(Date ttmTargetDate) {
		this.ttmTargetDate = ttmTargetDate;
	}
	public int getWaveId() {
		return waveId;
	}
	public void setWaveId(int waveId) {
		this.waveId = waveId;
	}
	public Boolean getIsRisk() {
		return isRisk;
	}
	public void setIsRisk(Boolean isRisk) {
		this.isRisk = isRisk;
	}
	public String getCurrentPhase() {
		return currentPhase;
	}
	public void setCurrentPhase(String currentPhase) {
		this.currentPhase = currentPhase;
	}
	public String getPm() {
		return pm;
	}
	public void setPm(String pm) {
		this.pm = pm;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public Float getEstimatedTTV() {
		return estimatedTTV;
	}
	public void setEstimatedTTV(Float estimatedTTV) {
		this.estimatedTTV = estimatedTTV;
	}
	public Float getActualTTV() {
		return actualTTV;
	}
	public void setActualTTV(Float actualTTV) {
		this.actualTTV = actualTTV;
	}
	public Boolean isRisk() {
		return isRisk;
	}
	public void setRisk(Boolean isRisk) {
		this.isRisk = isRisk;
	}
	public Date getTtmSignOffDate() {
		return ttmSignOffDate;
	}
	public void setTtmSignOffDate(Date ttmSignOffDate) {
		this.ttmSignOffDate = ttmSignOffDate;
	}
	public int getNpiWaveId() {
		return waveId;
	}
	public void setNpiWaveId(int npiWaveId) {
		this.waveId = npiWaveId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getWaveName() {
		return waveName;
	}
	public void setWaveName(String waveName) {
		this.waveName = waveName;
	}
	public Date getTtvTargetDate() {
		return ttvTargetDate;
	}
	public void setTtvTargetDate(Date ttvTargetDate) {
		this.ttvTargetDate = ttvTargetDate;
	}
	public Date getTtvSignOffDate() {
		return ttvSignOffDate;
	}
	public void setTtvSignOffDate(Date ttvSignOffDate) {
		this.ttvSignOffDate = ttvSignOffDate;
	}
	public Float getTtvTarget() {
		return ttvTarget;
	}
	public void setTtvTarget(Float ttvTarget) {
		this.ttvTarget = ttvTarget;
	}
	public String getTtvStatus() {
		return ttvStatus;
	}
	public void setTtvStatus(String ttvStatus) {
		this.ttvStatus = ttvStatus;
	}
	public String getSgaTtvStatus() {
		return sgaTtvStatus;
	}
	public void setSgaTtvStatus(String sgaTtvStatus) {
		this.sgaTtvStatus = sgaTtvStatus;
	}
	public Date getSgaTtvTargetDate() {
		return sgaTtvTargetDate;
	}
	public void setSgaTtvTargetDate(Date sgaTtvTargetDate) {
		this.sgaTtvTargetDate = sgaTtvTargetDate;
	}
	public Date getSgaTtvSignOffDate() {
		return sgaTtvSignOffDate;
	}
	public void setSgaTtvSignOffDate(Date sgaTtvSignOffDate) {
		this.sgaTtvSignOffDate = sgaTtvSignOffDate;
	}
	public Float getSgaTtvTarget() {
		return sgaTtvTarget;
	}
	public void setSgaTtvTarget(Float sgaTtvTarget) {
		this.sgaTtvTarget = sgaTtvTarget;
	}
	public Float getSgaEstimatedTTV() {
		return sgaEstimatedTTV;
	}
	public void setSgaEstimatedTTV(Float sgaEstimatedTTV) {
		this.sgaEstimatedTTV = sgaEstimatedTTV;
	}
	public Float getSgaActualTTV() {
		return sgaActualTTV;
	}
	public void setSgaActualTTV(Float sgaActualTTV) {
		this.sgaActualTTV = sgaActualTTV;
	}
	
	public Boolean getIsSgaTtvRisk() {
		return isSgaTtvRisk;
	}
	public void setIsSgaTtvRisk(Boolean isSgaTtvRisk) {
		this.isSgaTtvRisk = isSgaTtvRisk;
	}
	
	public String getNaType() {
		return naType;
	}
	public void setNaType(String naType) {
		this.naType = naType;
	}
	public String getSgaNaType() {
		return sgaNaType;
	}
	public void setSgaNaType(String sgaNaType) {
		this.sgaNaType = sgaNaType;
	}
	public TTVProduct(int waveId, String productName, String waveName,
			String ttvStatus, Date ttmSignOffDate, Date ttvTargetDate,
			Date ttvSignOffDate, Float ttvTarget, Boolean isRisk,
			Float estimatedTTV, Float actualTTV,
			int projectId, String currentPhase, String pm, Date startDate,Date ttmTargetDate,boolean isProjectPlanned) {
		super();
		this.waveId = waveId;
		this.productName = productName;
		this.waveName = waveName;
		this.ttvStatus = ttvStatus;
		this.ttmSignOffDate = ttmSignOffDate;
		this.ttvTargetDate = ttvTargetDate;
		this.ttvSignOffDate = ttvSignOffDate;
		this.ttvTarget = ttvTarget;
		this.isRisk = isRisk;
		this.estimatedTTV = estimatedTTV;
		this.actualTTV = actualTTV;
		this.projectId = projectId;
		this.currentPhase = currentPhase;
		this.pm = pm;
		this.startDate = startDate;
		this.ttmTargetDate = ttmTargetDate;
		this.isProjectPlanned = isProjectPlanned;
	}
	
	public TTVProduct(int waveId, String productName, String waveName,
			String ttvStatus, Date ttmSignOffDate, Date ttvTargetDate,
			Date ttvSignOffDate, Float ttvTarget, Boolean isRisk,
			Float estimatedTTV, Float actualTTV,
			int projectId, String currentPhase, String pm, Date startDate,Date ttmTargetDate,boolean isProjectPlanned,
			String sgaTtvStatus,Date sgaTtvTargetDate,Date sgaTtvSignOffDate, Float sgaTtvTarget,Float sgaEstimatedTTV, 
			Float sgaActualTTV,Boolean isSgaTtvRisk) {
		super();
		this.waveId = waveId;
		this.productName = productName;
		this.waveName = waveName;
		this.ttvStatus = ttvStatus;
		this.ttmSignOffDate = ttmSignOffDate;
		this.ttvTargetDate = ttvTargetDate;
		this.ttvSignOffDate = ttvSignOffDate;
		this.ttvTarget = ttvTarget;
		this.isRisk = isRisk;
		this.estimatedTTV = estimatedTTV;
		this.actualTTV = actualTTV;
		this.projectId = projectId;
		this.currentPhase = currentPhase;
		this.pm = pm;
		this.startDate = startDate;
		this.ttmTargetDate = ttmTargetDate;
		this.isProjectPlanned = isProjectPlanned;
		this.sgaActualTTV = sgaActualTTV;
		this.sgaEstimatedTTV = sgaEstimatedTTV;
		this.sgaTtvSignOffDate = sgaTtvSignOffDate;
		this.sgaTtvStatus = sgaTtvStatus;
		this.sgaTtvTarget = sgaTtvTarget;
		this.sgaTtvTargetDate = sgaTtvTargetDate;
		this.isSgaTtvRisk = isSgaTtvRisk;
	}
	public TTVProduct(int waveId, String productName, String waveName,
			String ttvStatus, Date ttmSignOffDate, Date ttvTargetDate,
			Date ttvSignOffDate, Float ttvTarget, Boolean isRisk,
			Float estimatedTTV, Float actualTTV,
			int projectId, String currentPhase, String pm, Date startDate,Date ttmTargetDate,boolean isProjectPlanned,
			String sgaTtvStatus,Date sgaTtvTargetDate,Date sgaTtvSignOffDate, Float sgaTtvTarget,Float sgaEstimatedTTV, 
			Float sgaActualTTV,Boolean isSgaTtvRisk, String naType, String sgaNaType) {
		super();
		this.waveId = waveId;
		this.productName = productName;
		this.waveName = waveName;
		this.ttvStatus = ttvStatus;
		this.ttmSignOffDate = ttmSignOffDate;
		this.ttvTargetDate = ttvTargetDate;
		this.ttvSignOffDate = ttvSignOffDate;
		this.ttvTarget = ttvTarget;
		this.isRisk = isRisk;
		this.estimatedTTV = estimatedTTV;
		this.actualTTV = actualTTV;
		this.projectId = projectId;
		this.currentPhase = currentPhase;
		this.pm = pm;
		this.startDate = startDate;
		this.ttmTargetDate = ttmTargetDate;
		this.isProjectPlanned = isProjectPlanned;
		this.sgaActualTTV = sgaActualTTV;
		this.sgaEstimatedTTV = sgaEstimatedTTV;
		this.sgaTtvSignOffDate = sgaTtvSignOffDate;
		this.sgaTtvStatus = sgaTtvStatus;
		this.sgaTtvTargetDate = sgaTtvTargetDate;
		this.sgaTtvTarget = sgaTtvTarget;
		this.isSgaTtvRisk = isSgaTtvRisk;
		this.naType = naType;
		this.sgaNaType = sgaNaType;
	}
	
}
