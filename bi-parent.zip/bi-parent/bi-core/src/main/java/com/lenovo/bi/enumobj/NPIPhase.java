package com.lenovo.bi.enumobj;

public enum NPIPhase {
	ttm,ttv,sgaTtv
}
