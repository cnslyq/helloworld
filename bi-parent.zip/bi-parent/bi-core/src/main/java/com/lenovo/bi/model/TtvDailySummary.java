package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BI_TTVDailySummary")
public class TtvDailySummary {
	@Id
	@GeneratedValue
	@Column
	private int ttvDailySummaryId;
	
	@Column
	private int pmsWaveId;
	
	@Column
	private float ttvOdm;
	
	@Column
	private float ttvTdms;
	
	@Column
	private int accumulatedDemand;
	
	@Column
	private int dailyCapacityOdm;
	
	@Column
	private int dailyCapacityTdms;
	
	@Column
	private int accumulatedCapacityOdm;
	
	@Column
	private int accumulatedCapacityTdms;
	
	@Column
	private int dailyGapOdm;
	
	@Column
	private int dailyGapTdms;
	
	@Column
	private int totalDailyGapOdm;
	
	@Column
	private int totalDailyGapTdms;
	
	@Column
	private Date targetDate;
	
	@Column
	private Date createdDate;
	
	@Column
	private Date lastModifiedDate;

	public int getTtvDailySummaryId() {
		return ttvDailySummaryId;
	}

	public void setTtvDailySummaryId(int ttvDailySummaryId) {
		this.ttvDailySummaryId = ttvDailySummaryId;
	}

	public int getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(int pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public float getTtvOdm() {
		return ttvOdm;
	}

	public void setTtvOdm(float ttvOdm) {
		this.ttvOdm = ttvOdm;
	}

	public float getTtvTdms() {
		return ttvTdms;
	}

	public void setTtvTdms(float ttvTdms) {
		this.ttvTdms = ttvTdms;
	}

	public int getAccumulatedDemand() {
		return accumulatedDemand;
	}

	public void setAccumulatedDemand(int accumulatedDemand) {
		this.accumulatedDemand = accumulatedDemand;
	}	

	public int getDailyCapacityOdm() {
		return dailyCapacityOdm;
	}

	public void setDailyCapacityOdm(int dailyCapacityOdm) {
		this.dailyCapacityOdm = dailyCapacityOdm;
	}

	public int getDailyCapacityTdms() {
		return dailyCapacityTdms;
	}

	public void setDailyCapacityTdms(int dailyCapacityTdms) {
		this.dailyCapacityTdms = dailyCapacityTdms;
	}

	public int getAccumulatedCapacityOdm() {
		return accumulatedCapacityOdm;
	}

	public void setAccumulatedCapacityOdm(int accumulatedCapacityOdm) {
		this.accumulatedCapacityOdm = accumulatedCapacityOdm;
	}

	public int getAccumulatedCapacityTdms() {
		return accumulatedCapacityTdms;
	}

	public void setAccumulatedCapacityTdms(int accumulatedCapacityTdms) {
		this.accumulatedCapacityTdms = accumulatedCapacityTdms;
	}

	public int getDailyGapOdm() {
		return dailyGapOdm;
	}

	public void setDailyGapOdm(int dailyGapOdm) {
		this.dailyGapOdm = dailyGapOdm;
	}

	public int getDailyGapTdms() {
		return dailyGapTdms;
	}

	public void setDailyGapTdms(int dailyGapTdms) {
		this.dailyGapTdms = dailyGapTdms;
	}

	public int getTotalDailyGapOdm() {
		return totalDailyGapOdm;
	}

	public void setTotalDailyGapOdm(int totalDailyGapOdm) {
		this.totalDailyGapOdm = totalDailyGapOdm;
	}

	public int getTotalDailyGapTdms() {
		return totalDailyGapTdms;
	}

	public void setTotalDailyGapTdms(int totalDailyGapTdms) {
		this.totalDailyGapTdms = totalDailyGapTdms;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String toString() {
		return "TtvDailySummary [ttvDailySummaryId=" + ttvDailySummaryId
				+ ", pmsWaveId=" + pmsWaveId + ", ttvOdm=" + ttvOdm
				+ ", ttvTdms=" + ttvTdms + ", accumulatedDemand="
				+ accumulatedDemand + ", dailyCapacityOdm="
				+ dailyCapacityOdm + ", dailyCapacityTdms="
				+ dailyCapacityTdms + ", accumulatedCapacityOdm="
				+ accumulatedCapacityOdm + ", accumulatedCapacityTdms="
				+ accumulatedCapacityTdms + ", dailyGapOdm=" + dailyGapOdm
				+ ", dailyGapTdms=" + dailyGapTdms + ", totalDailyGapOdm="
				+ totalDailyGapOdm + ", totalDailyGapTdms="
				+ totalDailyGapTdms + ", targetDate=" + targetDate
				+ ", createdDate=" + createdDate + ", lastModifiedDate="
				+ lastModifiedDate + "]";
	}
		
	
}
