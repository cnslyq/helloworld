package com.lenovo.bi.dto;

import java.util.Date;


public class OdmCommitDto {
	private int productKey;
	private int pmsWaveId;
	private int odmCommit;
	private Date targetDate;
	
	public int getProductKey() {
		return productKey;
	}
	public void setProductKey(int productKey) {
		this.productKey = productKey;
	}
	public int getPmsWaveId() {
		return pmsWaveId;
	}
	public void setPmsWaveId(int pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}
	public int getOdmCommit() {
		return odmCommit;
	}
	public void setOdmCommit(int odmCommit) {
		this.odmCommit = odmCommit;
	}
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	
}
