package com.lenovo.bi.enumobj;

import java.util.HashMap;
import java.util.Map;

public enum CoverEnum {
	A("A COVER"), B("B COVER"), C("C COVER"), D("D COVER");
	
	String value;
	
	CoverEnum(String value){
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	private static Map<String, CoverEnum> nameToEnumMap = new HashMap<String, CoverEnum>();
	
	static {
		for (CoverEnum cover : CoverEnum.values()) {
			nameToEnumMap.put(cover.getValue(), cover);
		}
	}

	public static CoverEnum getEnumFromName(String name) {
		return nameToEnumMap.get(name);
	}
}
