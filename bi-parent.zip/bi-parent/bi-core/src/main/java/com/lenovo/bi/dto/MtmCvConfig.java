package com.lenovo.bi.dto;

import java.util.Set;

public class MtmCvConfig {
	protected String bomNumber;  // BOM number can be null, depending on the usage
	protected SingleUnitCvConfig singleUnitCvConfig;
	
	protected int numberOfUnits;
	
	public MtmCvConfig(SingleUnitCvConfig singleUnitCvConfig,
			int unitQuantity) {
		super();
		this.singleUnitCvConfig = singleUnitCvConfig;
		this.numberOfUnits = unitQuantity;
	}
	
	public String getBomNumber() {
		return bomNumber;
	}

	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}

	public int getNumberOfUnits() {
		return numberOfUnits;
	}

	public int getQuantity(int cvKey) {
		return singleUnitCvConfig.getQuantity(cvKey) * numberOfUnits;
	}
	
	public int getSingleUnitQuantity(int cvKey) {
		return singleUnitCvConfig.getQuantity(cvKey);
	}
	
	public Set<Integer> getAllCvs() {
		if(singleUnitCvConfig != null)
			return singleUnitCvConfig.getAllCvs();
		else
			return new SingleUnitCvConfig().getAllCvs();
	}
}
