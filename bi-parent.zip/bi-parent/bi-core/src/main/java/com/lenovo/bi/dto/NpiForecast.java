package com.lenovo.bi.dto;

public class NpiForecast {
private Integer versionDateKey;

private Integer TargetDateKey;

private Integer productKey;

private Integer globalCvKey;

private Integer quantity;

public Integer getVersionDateKey() {
	return versionDateKey;
}

public void setVersionDateKey(Integer versionDateKey) {
	this.versionDateKey = versionDateKey;
}

public Integer getTargetDateKey() {
	return TargetDateKey;
}

public void setTargetDateKey(Integer targetDateKey) {
	TargetDateKey = targetDateKey;
}



public Integer getProductKey() {
	return productKey;
}

public void setProductKey(Integer productKey) {
	this.productKey = productKey;
}

public Integer getGlobalCvKey() {
	return globalCvKey;
}

public void setGlobalCvKey(Integer globalCvKey) {
	this.globalCvKey = globalCvKey;
}

public Integer getQuantity() {
	return quantity;
}

public void setQuantity(Integer quantity) {
	this.quantity = quantity;
}

@Override
public String toString() {
	return "NpiForecast [versionDateKey=" + versionDateKey + ", TargetDateKey="
			+ TargetDateKey + ", ProductKey=" + productKey + ", globalCvKey="
			+ globalCvKey + ", quantity=" + quantity + "]";
}


}
