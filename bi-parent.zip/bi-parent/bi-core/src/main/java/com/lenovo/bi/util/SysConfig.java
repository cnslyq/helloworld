package com.lenovo.bi.util;

import java.io.IOException;
import java.util.Properties;

/**
 * The parameters readed from sys_config.properties
 * 
 * @author Kevin_Wang02
 * 
 */
public class SysConfig {
	private static final Properties SYS_CONFIG = new Properties();
	static {
		try {
			SYS_CONFIG.load(SysConfig.class.getResourceAsStream("/sys_config.properties"));
		} catch (IOException e) {
		}
	}

	private SysConfig() {
	}

	/**
	 * Get system config properties
	 * 
	 * @return
	 */
	public static Properties getSysConfigProperties() {
		return SYS_CONFIG;
	}

	/**
	 * The static server url, like http://localhost:8080/pms,not end with '/'
	 */
	public static final String HOME_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("bi.static.home.url"));
	public static final String STATIC_SERVER_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("bi.static.server.url"));

	public static final String DYNAMIC_SERVER_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("bi.dynamic.server.url"));

	public static final String CAS_SERVER_HOST_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("bi.cas.server.host.url"));
	
	public static final String CAS_SERVER_HOST_URL_APPEND = getUrlWithoutSlash(SYS_CONFIG.getProperty("bi.cas.server.host.url.append"));

	public static final String PMS_LOGOUT_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("bi.logout.url"));

	public static String CURRENT_MODULE;

	public static String THIS_MODULE;

	// Integration
	// Passport
	public static final String PMS_PASSPORT_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("passport.url"));
	// SPMS
	public static final String SPMS_STATUS = SYS_CONFIG.getProperty("spms.status");
	public static final String SPMS_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("spms.url"));
	public static final String SPMS_ROOTDELIVERABLE_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("spms.rootdeliverable.url"));
	public static final String SPMS_SWLIST_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("spms.swlist.url"));

	// TDMS
	public static final String TDMS_STATUS = SYS_CONFIG.getProperty("tdms.status");
	public static final String TDMS_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("tdms.url"));
	public static final String TDMS_BUG_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("tdms.bug.url"));
	public static final String TDMS_TESTPLAN_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("tdms.testplan.url"));
	public static final String TDMS_URL_TESTPLAN = SYS_CONFIG.getProperty("tdms.url.testPlan");
	public static final String TDMS_URL_ALLOPENDEFECT = SYS_CONFIG.getProperty("tdms.url.allOpenDefect");
	public static final String TDMS_URL_ALLDEFECT = SYS_CONFIG.getProperty("tdms.url.allDefect");
	public static final String TDMS_URL_DEFECT = SYS_CONFIG.getProperty("tdms.url.defect");

	// KMS
	public static final String KMS_STATUS = SYS_CONFIG.getProperty("kms.status");
	public static final String KMS_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("kms.url"));
	public static final String KMS_COMMON_CHECKSHEET = SYS_CONFIG.getProperty("kms.common.checkSheet");

	// PMS
	public static final String PMS_URL = getUrlWithoutSlash(SYS_CONFIG.getProperty("pms.url"));

	// Dashboard
	public static final String DASHBOARD_FLASH = SYS_CONFIG.getProperty("pms.dashboard.draw.useFlash");
	public static final String DASHBOARD_URL = SYS_CONFIG.getProperty("pms.dashboard.path");
	public static final String DASHBOARDFORMONTH_URL = SYS_CONFIG.getProperty("pms.dashboardForEachMonth.path");
	public static final String DASHBOARDFORWEEK_URL = SYS_CONFIG.getProperty("pms.dashboardForEachWeek.path");
	// public static final String DASHBOARDDOWNLOAD_URL =
	// SYS_CONFIG.getProperty("pms.serverForDashboard.path");
	public static final String JUSTCLOSED_PROJECT_WORKINGDAY_DIFF = SYS_CONFIG.getProperty("pms.dashboard.justClosedProjectWorkingDayDiff");
	public static final String NEXT_HIGHCRITICALISSUE_WORKINGDAYDIFF_WORKINGDAY_DIFF = SYS_CONFIG
			.getProperty("pms.dashboard.nextHighCriticalIssueWorkingDayDiff");
	public static final String PMS_RELATION_TDMS_DASHBOARD = SYS_CONFIG.getProperty("pms.dashboardRelation.tdms");
	public static final String PMS_WORKSPACE_CALENDAR = SYS_CONFIG.getProperty("pms.workspace.calendar");
	public static final String PMS_FAVORITE_PROJECT = SYS_CONFIG.getProperty("pms.favorite.project");
	// Group Dashboard Email List
	// for document
	public static final String PMS_SELECT_PATH = SYS_CONFIG.getProperty("pms.slected.path");
	public static final String PMS_DOC_PATH = SYS_CONFIG.getProperty("pms.doc.path");
	public static final String PMS_DOC_TEMP_PATH = SYS_CONFIG.getProperty("pms.doc.tempFile");
	public static final String PMS_DOC_REMOTE_FOLD = SYS_CONFIG.getProperty("pms.remote.shareFold");

	// SWOD
	public static final String SWOD_STATUS = SYS_CONFIG.getProperty("swod.status");

	// Admin account
	public static final String PMS_ADMIN = SYS_CONFIG.getProperty("pms.admin");

	public static final String PMS_RESOURCE_CALENDAR_WEBSERVICE = SYS_CONFIG.getProperty("resource.calendar.webservice.url");

	public static final String PMS_VER_INFO = SYS_CONFIG.getProperty("pms.versioninfo", "");
	// need modify in future by steve on April 01
	public static final String uploadFilePath = SYS_CONFIG.getProperty("uploadFilePath");
	public static final String indexFilePath = SYS_CONFIG.getProperty("indexFilePath");

	// pms upload file max size
	public static final String PMS_UPLOAD_FILE_MAX_SIZE = SYS_CONFIG.getProperty("pms.upload.file.size");
	// constant
	public static final String CONSTANT_NONE = SYS_CONFIG.getProperty("constant.none");

	public static final String MAX_SEND_MAIL_TO = SYS_CONFIG.getProperty("mail.send.to");

	// predefined FTP folder
	public static final String PMS_FTP_PATH = SYS_CONFIG.getProperty("pms.ftp.path");
	public static final String PMS_FTP_PORT = SYS_CONFIG.getProperty("pms.ftp.port");
	public static final String PMS_FTP_FOLDER = SYS_CONFIG.getProperty("pms.ftp.folder");
	public static final String PMS_FTP_USER = SYS_CONFIG.getProperty("pms.ftp.username");
	public static final String PMS_FTP_PWD = SYS_CONFIG.getProperty("pms.ftp.password");
	public static final String PMS_DESIGNREVIEW_DAYS_REMINDER_DESIGN_CHAMPION_LEAD = SYS_CONFIG
			.getProperty("pms.designreview.daysBeforeDueDateReminderChampionLead");
	public static final String PMS_DESIGNREVIEW_DAYS_REMINDER_REVIEWVER = SYS_CONFIG.getProperty("pms.designreview.daysBeforeDueDateReminderReviewer");
	public static final String ENTITY_STATUS_LOG = SYS_CONFIG.getProperty("pms.entityStatusLog");
	public static final String PMS_SHOW_MULTI_VENDOR = SYS_CONFIG.getProperty("pms.showMultiVendor");

	// remove space and last slash, all urls need invoke this method
	private static final String getUrlWithoutSlash(String url) {
		if (url == null) {
			return "";
		}
		String newUrl = url.replace(" ", "");
		if (newUrl.lastIndexOf("/") == (newUrl.length() - 1) && newUrl.length() > 0) {
			newUrl = newUrl.substring(0, newUrl.length() - 1);
		}
		return newUrl;
	}

	// predefined pie chart information
	public static final String PIE_CHART_BASEFONTSIZE = SYS_CONFIG.getProperty("pie.chart.basefontsize");
	public static final String PIE_CHART_STARTINGANGLE = SYS_CONFIG.getProperty("pie.chart.startingAngle");
	public static final String PIE_CHART_USE3DLIGHTING = SYS_CONFIG.getProperty("pie.chart.use3DLighting");
	public static final String PIE_CHART_PIEYSCALE = SYS_CONFIG.getProperty("pie.chart.pieYScale");
	public static final String PIE_CHART_PIERADIUS = SYS_CONFIG.getProperty("pie.chart.pieRadius");
	public static final String PIE_CHART_PIESLICEDEPTH = SYS_CONFIG.getProperty("pie.chart.pieSliceDepth");
	public static final String PIE_CHART_ENABLESMARTLABELS = SYS_CONFIG.getProperty("pie.chart.enableSmartLabels");
	public static final String PIE_CHART_SHOWPERCENTVALUES = SYS_CONFIG.getProperty("pie.chart.showPercentValues");
	public static final String PIE_CHART_SHOWLABELS = SYS_CONFIG.getProperty("pie.chart.showLabels");
	public static final String PIE_CHART_LABELDISTANCE = SYS_CONFIG.getProperty("pie.chart.labelDistance");
	public static final String PIE_CHART_SHOWLEGEND = SYS_CONFIG.getProperty("pie.chart.showLegend");
	public static final String PIE_CHART_LEGENDPOSITION = SYS_CONFIG.getProperty("pie.chart.legendPosition");
	public static final String PIE_CHART_REVERSELEGEND = SYS_CONFIG.getProperty("pie.chart.reverseLegend");
	public static final String PIE_CHART_INTERACTIVELEGEND = SYS_CONFIG.getProperty("pie.chart.interactiveLegend");
	public static final String PIE_CHART_LEGENDICONSCALE = SYS_CONFIG.getProperty("pie.chart.legendIconScale");
	public static final String PIE_CHART_SLICINGDISTANCE = SYS_CONFIG.getProperty("pie.chart.slicingDistance");
	public static final String PIE_CHART_MANAGELABELOVERFLOW = SYS_CONFIG.getProperty("pie.chart.manageLabelOverflow");

	// predefined column chart information
	public static final String COLUMN_CHART_SHOWVALUES = SYS_CONFIG.getProperty("column.chart.showValues");
	public static final String COLUMN_CHART_SNUMBERSUFFIX = SYS_CONFIG.getProperty("column.chart.snumberSuffix");
	public static final String COLUMN_CHART_DECIMALS = SYS_CONFIG.getProperty("column.chart.decimals");
	public static final String COLUMN_CHART_SETADAPTIVEYMIN = SYS_CONFIG.getProperty("column.chart.setAdaptiveYmin");
	public static final String COLUMN_CHART_SETADAPTIVESYMIN = SYS_CONFIG.getProperty("column.chart.setAdaptiveSYmin");
	public static final String COLUMN_CHART_LINETHICKNESS = SYS_CONFIG.getProperty("column.chart.lineThickness");
	public static final String COLUMN_CHART_PLOTSPACEPERCENT = SYS_CONFIG.getProperty("column.chart.plotSpacePercent");
	public static final String COLUMN_CHART_NUMDIVLINES = SYS_CONFIG.getProperty("column.chart.numdivlines");
	public static final String COLUMN_CHART_YAXISMINVALUE = SYS_CONFIG.getProperty("column.chart.yAxisMinValue");
	public static final String COLUMN_CHART_YAXISMAXVALUE = SYS_CONFIG.getProperty("column.chart.yAxisMaxValue");
	public static final String COLUMN_CHART_SYAXISMAXVALUE = SYS_CONFIG.getProperty("column.chart.syAxisMaxValue");
	public static final String COLUMN_CHART_SYAXISMINVALUE = SYS_CONFIG.getProperty("column.chart.syAxisMinValue");
	public static final String COLUMN_CHART_FORMATNUMBER = SYS_CONFIG.getProperty("column.chart.formatNumber");
	public static final String COLUMN_CHART_FORMATNUMBERSCALE = SYS_CONFIG.getProperty("column.chart.formatNumberScale");
	public static final String COLUMN_CHART_LEGENDICONSCALE = SYS_CONFIG.getProperty("column.chart.legendIconScale");
	public static final String COLUMN_CHART_SHOWBORDER = SYS_CONFIG.getProperty("column.chart.showBorder");
	public static final String COLUMN_CHART_CANVASBORDERTHICKNESS = SYS_CONFIG.getProperty("column.chart.canvasBorderThickness");
	public static final String COLUMN_CHART_SHOWZEROPLANEVALUE = SYS_CONFIG.getProperty("column.chart.showZeroPlaneValue");
	public static final String COLUMN_CHART_CANVASBORDERALPHA = SYS_CONFIG.getProperty("column.chart.canvasBorderAlpha");
	public static final String COLUMN_CHART_BGALPHA = SYS_CONFIG.getProperty("column.chart.bgalpha");
	public static final String COLUMN_CHART_PLOTGRADIENTCOLOR = SYS_CONFIG.getProperty("column.chart.plotgradientcolor");
	public static final String COLUMN_CHART_LEGENDPOSITION = SYS_CONFIG.getProperty("column.chart.legendposition");
	public static final String COLUMN_CHART_SHOWPLOTBORDER = SYS_CONFIG.getProperty("column.chart.showplotborder");
	public static final String COLUMN_CHART_NUMBERSUFFIX = SYS_CONFIG.getProperty("column.chart.numbersuffix");
	public static final String COLUMN_CHART_ALTERNATEVGRIDALPHA = SYS_CONFIG.getProperty("column.chart.alternatevgridalpha");
	public static final String COLUMN_CHART_SHOWSUM = SYS_CONFIG.getProperty("column.chart.showsum");
	public static final String COLUMN_CHART_FORCEDECIMALS = SYS_CONFIG.getProperty("column.chart.forceDecimals");

	// Vline
	public static final String VLINE_VLINE = SYS_CONFIG.getProperty("vline.chart.vline");
	public static final String VLINE_LABEL = SYS_CONFIG.getProperty("vline.chart.label");
	public static final String VLINE_DASHED = SYS_CONFIG.getProperty("vline.chart.dashed");
	public static final String VLINE_LINEPOSITION = SYS_CONFIG.getProperty("vline.chart.lineposition");
	public static final String VLINE_LABELPOSITION = SYS_CONFIG.getProperty("vline.chart.labelposition");
	public static final String VLINE_SHOWLABELBORDER = SYS_CONFIG.getProperty("vline.chart.showlabelborder");
	public static final String VLINE_LABELHALIGN = SYS_CONFIG.getProperty("vline.chart.labelhalign");
	public static final String VLINE_LABELVALIGN = SYS_CONFIG.getProperty("vline.chart.labelvalign");
	public static final String VLINE_DASHLEN = SYS_CONFIG.getProperty("vline.chart.dashlen");

	/**
	 * ttv outlook
	 * 
	 */
	public static final String TTV_OUTLOOK_TTV = SYS_CONFIG.getProperty("ttv.outlook.ttv");
	public static final String TTV_OUTLOOK_TTV_COLOR = SYS_CONFIG.getProperty("ttv.outlook.ttv.color");
	public static final String TTV_OUTLOOK_TTV_TARGET = SYS_CONFIG.getProperty("ttv.outlook.ttvTarget");
	public static final String TTV_OUTLOOK_TTV_TARGET_COLOR = SYS_CONFIG.getProperty("ttv.outlook.ttvTarget.color");
	public static final String TTV_OUTLOOK_DEMAND = SYS_CONFIG.getProperty("ttv.outlook.demand");
	public static final String TTV_OUTLOOK_DEMAND_COLOR = SYS_CONFIG.getProperty("ttv.outlook.demand.color");
	public static final String TTV_OUTLOOK_SHIPMENT = SYS_CONFIG.getProperty("ttv.outlook.shipment");
	public static final String TTV_OUTLOOK_SHIPMENT_COLOR = SYS_CONFIG.getProperty("ttv.outlook.shipment.color");
	public static final String TTV_OUTLOOK_ODM = SYS_CONFIG.getProperty("ttv.outlook.odm");
	public static final String TTV_OUTLOOK_ODM_COLOR = SYS_CONFIG.getProperty("ttv.outlook.odm.color");
	public static final String TTV_OUTLOOK_ODMCOMMITMENT = SYS_CONFIG.getProperty("ttv.outlook.odmCommitment");
	public static final String TTV_OUTLOOK_ODMCOMMITMENT_COLOR = SYS_CONFIG.getProperty("ttv.outlook.odmCommitment.color");
	public static final String TTV_OUTLOOK_CAPACITY = SYS_CONFIG.getProperty("ttv.outlook.capacity");
	public static final String TTV_OUTLOOK_CAPACITY_COLOR = SYS_CONFIG.getProperty("ttv.outlook.capacity.color");
	public static final String TTV_OUTLOOK_GAP = SYS_CONFIG.getProperty("ttv.outlook.gap");
	public static final String TTV_OUTLOOK_GAP_COLOR = SYS_CONFIG.getProperty("ttv.outlook.gap.color");
	public static final String TTV_OUTLOOK_TTV_GAP = SYS_CONFIG.getProperty("ttv.outlook.ttvgap");
	public static final String TTV_OUTLOOK_TTV_GAP_COLOR = SYS_CONFIG.getProperty("ttv.outlook.ttvgap.color");

	public static final String TTV_OUTLOOK_SLETTV = SYS_CONFIG.getProperty("ttv.outlook.sleTtv");
	public static final String TTV_OUTLOOK_ACTUALSLETTV = SYS_CONFIG.getProperty("ttv.outlook.actualSleTtv");
	public static final String TTV_OUTLOOK_SLETTV_COLOR = SYS_CONFIG.getProperty("ttv.outlook.sleTtv.color");
	public static final String TTV_OUTLOOK_SLETTV_TARGET = SYS_CONFIG.getProperty("ttv.outlook.sleTtvTarget");
	public static final String TTV_OUTLOOK_SLETTV_TARGET_COLOR = SYS_CONFIG.getProperty("ttv.outlook.sleTtvTarget.color");
	public static final String TTV_OUTLOOK_SGAGAP = SYS_CONFIG.getProperty("ttv.outlook.sgaGap");
	public static final String TTV_OUTLOOK_SGAGAP_COLOR = SYS_CONFIG.getProperty("ttv.outlook.sgaGap.color");
	public static final String TTV_OUTLOOK_SGARAMPCOMMIT = SYS_CONFIG.getProperty("ttv.outlook.sgaRampCommit");
	public static final String TTV_OUTLOOK_SGARAMPCOMMIT_COLOR = SYS_CONFIG.getProperty("ttv.outlook.sgaRampCommit.color");
	public static final String TTV_OUTLOOK_SGATTV = SYS_CONFIG.getProperty("ttv.outlook.sgaTtv");
	public static final String TTV_OUTLOOK_SGATTV_COLOR = SYS_CONFIG.getProperty("ttv.outlook.sgaTtv.color");
	
	public static final String TTV_OUTLOOK_ACTUALSGATTV = SYS_CONFIG.getProperty("ttv.outlook.actualSgaTtv");
	public static final String TTV_OUTLOOK_ACTUALSGATTV_COLOR = SYS_CONFIG.getProperty("ttv.outlook.actualSgaTtv.color");
	
	public static final String TTV_OUTLOOK_SGATTV_TARGET = SYS_CONFIG.getProperty("ttv.outlook.sgaTtvTarget");
	public static final String TTV_OUTLOOK_SGATTV_TARGET_COLOR = SYS_CONFIG.getProperty("ttv.outlook.sgaTtvTarget.color");
	public static final String TTV_OUTLOOK_FORECAST = SYS_CONFIG.getProperty("ttv.outlook.forecast");
	public static final String TTV_OUTLOOK_FORECAST_COLOR = SYS_CONFIG.getProperty("ttv.outlook.forecast.color");
	public static final String TTV_OUTLOOK_ORDER = SYS_CONFIG.getProperty("ttv.outlook.order");
	public static final String TTV_OUTLOOK_ORDER_COLOR = SYS_CONFIG.getProperty("ttv.outlook.order.color");
	
	public static final String TTV_SUMMARY_SLETTV = SYS_CONFIG.getProperty("ttv.summary.sleTtv");
	public static final String TTV_SUMMARY_SLETTV_COLOR = SYS_CONFIG.getProperty("ttv.summary.sleTtv.color");
	public static final String TTV_SUMMARY_SGATTV = SYS_CONFIG.getProperty("ttv.summary.sgaTtv");
	public static final String TTV_SUMMARY_SGATTV_COLOR = SYS_CONFIG.getProperty("ttv.summary.sgaTtv.color");
	
	public static final String TTV_OUTLOOK_DEMANDORDER = SYS_CONFIG.getProperty("ttv.outlook.demandOrder");
	public static final String TTV_OUTLOOK_DEMANDORDER_COLOR = SYS_CONFIG.getProperty("ttv.outlook.demandOrder.color");
	public static final String TTV_OUTLOOK_DEMANDROLLING = SYS_CONFIG.getProperty("ttv.outlook.demandRolling");
	public static final String TTV_OUTLOOK_DEMANDROLLING_COLOR = SYS_CONFIG.getProperty("ttv.outlook.demandRolling.color");
	public static final String TTV_OUTLOOK_DEMANDFORCAST = SYS_CONFIG.getProperty("ttv.outlook.demandForcast");
	public static final String TTV_OUTLOOK_DEMANDFORCAST_COLOR = SYS_CONFIG.getProperty("ttv.outlook.demandForcast.color");

	public static final String SYSTEM_TAB_ROLE = SYS_CONFIG.getProperty("system.tab.role");
	public static final String SYSTEM_TAB_GROUP = SYS_CONFIG.getProperty("system.tab.group");
	public static final String SYSTEM_TAB_PRIVILEGE = SYS_CONFIG.getProperty("system.tab.privilege");

	public static final String TTV_ORDER_HIT_RATE_WEEKS = SYS_CONFIG.getProperty("ttv.order.hit.rate.weeks");

	// Number of future weeks
	public static final int NUMBER_OF_FUTURE_WEEKS = 13; // TODO-Ying, review
															// the number
	// Number of two weeks
	public static final int NUMBER_OF_FUTURE_WEEKS1 = 14;

	public static final int NUMBER_OF_MONTHS = 12;

	public static final int NUMBER_OF_ROW_COUNT = 10;

	// monitor: pathname for execute package
	public static final String MONITOR_RESTARTJOB_DW_PATH = SYS_CONFIG.getProperty("monitor.restartjob.dw.path");
	public static final String MONITOR_RESTARTJOB_STAGING_PATH = SYS_CONFIG.getProperty("monitor.restartjob.staging.path");
	public static final Integer TTM_NOTIFICATION_PREDAYS = SYS_CONFIG.getProperty("ttm.notification.predays") == null ? 0 : Integer.parseInt(SYS_CONFIG
			.getProperty("ttm.notification.predays"));

	// system.engine.refresh.rate
	public static final String CONSOLE_ENGINE_REFRESH_RATE = SYS_CONFIG.getProperty("system.engine.refresh.rate");

	public static final int EXCLUDE_ORDER_BATCH_OPERATE_SIZE = Integer.valueOf(SYS_CONFIG.getProperty("exclude.order.batch.operate.size"));
	
	public static final String SYSTEM_ENGINE_RUNTIME=SYS_CONFIG.getProperty("system.engine.runtime");
}
