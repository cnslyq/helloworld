package com.lenovo.bi.dto;

public class TTVOutlookDetractorCode {
	private String detractorCodeKey; //TODO: may use enum

	public String getDetractorCodeKey() {
		return detractorCodeKey;
	}

	public void setDetractorCodeKey(String detractorCodeKey) {
		this.detractorCodeKey = detractorCodeKey;
	}
	
	
}
