package com.lenovo.bi.dto;

import java.util.Date;

public class OdmCapacityPlan {
	private String odmCapacityPlanId;
	private int unitsPerHour;
	private int hoursPerDay;
	private int daysPerWeek;	
	private float fpy;
	private Float rpy;
	private boolean useRpy;
	
	/**
	 * Calculated value
	 */
	private int output;
	
	private Date targetDate;

	public String getOdmNpiCapacityPlanId() {
		return odmCapacityPlanId;
	}

	public void setOdmNpiCapacityPlanId(String odmNpiCapacityPlanId) {
		this.odmCapacityPlanId = odmNpiCapacityPlanId;
	}

	public int getUnitsPerHour() {
		return unitsPerHour;
	}

	public void setUnitsPerHour(int unitsPerHour) {
		this.unitsPerHour = unitsPerHour;
	}

	public int getHoursPerDay() {
		return hoursPerDay;
	}

	public void setHoursPerDay(int hoursPerDay) {
		this.hoursPerDay = hoursPerDay;
	}

	public int getDaysPerWeek() {
		return daysPerWeek;
	}

	public void setDaysPerWeek(int daysPerWeek) {
		this.daysPerWeek = daysPerWeek;
	}

	public float getFpy() {
		return fpy;
	}

	public void setFpy(float fpy) {
		this.fpy = fpy;
	}

	public Float getRpy() {
		if(rpy == null){
			return 0f;
		}
		return rpy;
	}

	public void setRpy(Float rpy) {
		this.rpy = rpy;
	}

	public int getOutput() {
		return output;
	}

	public void setOutput(int output) {
		this.output = output;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public boolean isUseRpy() {
		return useRpy;
	}

	public void setUseRpy(boolean useRpy) {
		this.useRpy = useRpy;
	}
	
	
}
