package com.lenovo.bi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * 
 * @author henry_lian
 *
 */
@Entity
@Table(name="V_PMS_Role")
public class PMSRole {
	
	@Id
	@Column(name="Id")
	private int id;
	@Column(name="Name")
	private String name;
	@Column(name="BuildInRoleCode")
	private String buildinRoleCode;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBuildinRoleCode() {
		return buildinRoleCode;
	}
	public void setBuildinRoleCode(String buildinRoleCode) {
		this.buildinRoleCode = buildinRoleCode;
	}
	
}
