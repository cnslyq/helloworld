package com.lenovo.bi.dto;

import java.util.Date;

public class BoxLevelCommit {
	private String bomNumber;
	private int quantity;
	private Date targetDate;
	private Date versionDate;
	public String getBomNumber() {
		return bomNumber;
	}
	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	public Date getVersionDate() {
		return versionDate;
	}
	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}
	@Override
	public String toString() {
		return "BoxLevelCommit [bomNumber=" + bomNumber + ", quantity="
				+ quantity + ", targetDate=" + targetDate + ", versionDate="
				+ versionDate + "]";
	}
	
	
}
