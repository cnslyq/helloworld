package com.lenovo.bi.dto.privilege;

import com.lenovo.bi.util.SysConfig;

public class Tree extends BasicDTO {

	private static final long serialVersionUID = -7712921606829567312L;

	public int id;// id

	public String name;// name

	public int pId;// +parent_id

	public boolean checked = false;// ----
	
	public static final String BASEURL=SysConfig.STATIC_SERVER_URL+"/img/";


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}


	@Override
	public String toString() {
		return "Tree [id=" + id + ", name=" + name + ", pId=" + pId
				+ ", checked=" + checked + "]";
	}

}
