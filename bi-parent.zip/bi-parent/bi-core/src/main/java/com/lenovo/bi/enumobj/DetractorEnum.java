package com.lenovo.bi.enumobj;

public enum DetractorEnum {

	Future("0000ff"), // 橙黄
	DB("cc99ff"), // 紫色
	Over_SP("ff6633"), // 桔黄
	Supply("0066cc"), // 浅蓝
	Fulfillment("cccccc"), // 灰色
	MFG_Quality("cc99cc"), // 浅紫色
	NEW_Working("cc9999"), // 浅紫色
	To_Go_CA("cc9966"), // 浅紫色
	LATE_ORDER("cc9933"), Unknown("ffcc33");// 深蓝

	private String color;

	DetractorEnum() {

	}

	DetractorEnum(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		if (name().equalsIgnoreCase("MFG_Quality") || name().equalsIgnoreCase("NEW_Working"))
			return name().replaceAll("_", "/");
		else
			return name().replaceAll("_", " ");
	}

	public String toUpperCase() {
		return this.toString().toUpperCase();
	}

	public String getColor() {
		return color;
	}
}
