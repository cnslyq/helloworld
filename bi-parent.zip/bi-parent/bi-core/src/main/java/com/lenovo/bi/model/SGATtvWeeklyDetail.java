package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BI_SGATTVWeeklyDetail")
public class SGATtvWeeklyDetail {
	@Id
	@GeneratedValue
	@Column(name = "TTVWeeklyDetailId")
	private Integer ttvWeeklyDetailId;

	@Column(name = "VersionDate")
	private Date versionDate;

	@Column(name = "PMSWaveID")
	private Integer pmsWaveId;

	@Column(name = "TargetDate")
	private Date targetDate;

	@Column(name = "OrderQuantity", updatable = false)
	private Integer orderQuantity;

	@Column(name = "ShipQuantity")
	private Integer shipQuantity;

	@Column(name = "FGQuantity", updatable = false)
	private Integer fgQuantity;

	@Column(name = "ODMCommit")
	private Integer odmCommit;

	@Column(name = "SupplyCommit")
	private Integer supplyCommit;

	@Column(name = "CoverA")
	private Integer coverA;

	@Column(name = "CoverB")
	private Integer coverB;

	@Column(name = "CoverC")
	private Integer coverC;

	@Column(name = "CoverD")
	private Integer coverD;

	@Column(name = "ODMFPYCapacity")
	private Integer odmFpyCapacity;

	@Column(name = "ODMRPYCapacity")
	private Integer odmRpyCapacity;

	@Column(name = "TDMSFPYCapacity")
	private Integer tdmsFpyCapacity;

	@Column(name = "TDMSRPYCapacity")
	private Integer tdmsRpyCapacity;

	@Column(name = "RampCommit")
	private Integer rampCommit;

	@Column(name = "ToGoForecast")
	private Integer toGoForecast;

	@Column(name = "Forecast")
	private Integer forecast;

	@Column(name = "ToGoOrder")
	private Integer toGoOrder;

	@Column(name = "Output")
	private Integer output;
	
	@Column(name = "TDMSOutput")
	private Integer tdmsOutput;

	@Column
	private Date createdDate;

	@Column
	private Date lastModifiedDate;

	@Column(name = "FutureOrderQuantity")
	private Integer futureOrderQuantity;

	@Column(name = "FutureForecastQuantity")
	private Integer futureForecastQuantity;
	
	@Column(name = "TDMSToGoForecast")
	private Integer tdmsToGoForecast;
	
	@Column(name = "TDMSToGoOrder")
	private Integer tdmsToGoOrder;
	
	public Integer getTdmsToGoForecast() {
		return tdmsToGoForecast;
	}

	public void setTdmsToGoForecast(Integer tdmsToGoForecast) {
		this.tdmsToGoForecast = tdmsToGoForecast;
	}

	public Integer getTdmsToGoOrder() {
		return tdmsToGoOrder;
	}

	public void setTdmsToGoOrder(Integer tdmsToGoOrder) {
		this.tdmsToGoOrder = tdmsToGoOrder;
	}

	public Integer getTtvWeeklyDetailId() {
		return ttvWeeklyDetailId;
	}

	public void setTtvWeeklyDetailId(Integer ttvWeeklyDetailId) {
		this.ttvWeeklyDetailId = ttvWeeklyDetailId;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Integer getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(Integer pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public Integer getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(Integer orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public Integer getShipQuantity() {
		return shipQuantity;
	}

	public void setShipQuantity(Integer shipQuantity) {
		this.shipQuantity = shipQuantity;
	}

	public Integer getOdmCommit() {
		return odmCommit;
	}

	public void setOdmCommit(Integer odmCommit) {
		this.odmCommit = odmCommit;
	}

	public Integer getSupplyCommit() {
		if (supplyCommit == null) {
			return -1;
		}
		return supplyCommit;
	}

	public void setSupplyCommit(Integer supplyCommit) {
		this.supplyCommit = supplyCommit;
	}

	public Integer getCoverA() {
		if (coverA == null) {
			return -1;
		}
		return coverA;
	}

	public void setCoverA(Integer coverA) {
		this.coverA = coverA;
	}

	public Integer getCoverB() {
		if (coverB == null) {
			return -1;
		}
		return coverB;
	}

	public void setCoverB(Integer coverB) {
		this.coverB = coverB;
	}

	public Integer getCoverC() {
		if (coverC == null) {
			return -1;
		}
		return coverC;
	}

	public void setCoverC(Integer coverC) {
		this.coverC = coverC;
	}

	public Integer getCoverD() {
		if (coverD == null) {
			return -1;
		}
		return coverD;
	}

	public void setCoverD(Integer coverD) {
		this.coverD = coverD;
	}

	public Integer getOdmFpyCapacity() {
		if (odmFpyCapacity == null) {
			return -1;
		}
		return odmFpyCapacity;
	}

	public void setOdmFpyCapacity(Integer odmFpyCapacity) {
		this.odmFpyCapacity = odmFpyCapacity;
	}

	public Integer getOdmRpyCapacity() {
		if (odmRpyCapacity == null) {
			return -1;
		}
		return odmRpyCapacity;
	}

	public void setOdmRpyCapacity(Integer odmRpyCapacity) {
		this.odmRpyCapacity = odmRpyCapacity;
	}

	public Integer getTdmsFpyCapacity() {
		if (tdmsFpyCapacity == null) {
			return -1;
		}
		return tdmsFpyCapacity;
	}

	public void setTdmsFpyCapacity(Integer tdmsFpyCapacity) {
		this.tdmsFpyCapacity = tdmsFpyCapacity;
	}

	public Integer getTdmsRpyCapacity() {
		if (tdmsRpyCapacity == null) {
			return -1;
		}
		return tdmsRpyCapacity;
	}

	public void setTdmsRpyCapacity(Integer tdmsRpyCapacity) {
		this.tdmsRpyCapacity = tdmsRpyCapacity;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Integer getFgQuantity() {
		if (fgQuantity == null) {
			return -1;
		}
		return fgQuantity;
	}

	public void setFgQuantity(Integer fgQuantity) {
		this.fgQuantity = fgQuantity;
	}

	public Integer getRampCommit() {
		return rampCommit;
	}

	public void setRampCommit(Integer rampCommit) {
		this.rampCommit = rampCommit;
	}

	public Integer getToGoForecast() {
		return toGoForecast;
	}

	public void setToGoForecast(Integer toGoForecast) {
		this.toGoForecast = toGoForecast;
	}

	public Integer getToGoOrder() {
		return toGoOrder;
	}

	public void setToGoOrder(Integer toGoOrder) {
		this.toGoOrder = toGoOrder;
	}

	public Integer getOutput() {
		return output;
	}

	public void setOutput(Integer output) {
		this.output = output;
	}

	
	public Integer getTdmsOutput() {
		return tdmsOutput;
	}

	public void setTdmsOutput(Integer tdmsOutput) {
		this.tdmsOutput = tdmsOutput;
	}

	public Integer getFutureOrderQuantity() {
		if(futureOrderQuantity == null){
			return -1;
		}
		return futureOrderQuantity;
	}

	public void setFutureOrderQuantity(Integer futureOrderQuantity) {
		this.futureOrderQuantity = futureOrderQuantity;
	}

	public Integer getFutureForecastQuantity() {
		if(futureForecastQuantity == null){
			return -1;
		}
		return futureForecastQuantity;
	}

	public void setFutureForecastQuantity(Integer futureForecastQuantity) {
		this.futureForecastQuantity = futureForecastQuantity;
	}

	public Integer getForecast() {
		return forecast;
	}

	public void setForecast(Integer forecast) {
		this.forecast = forecast;
	}

	@Override
	public String toString() {
		return "SGATtvWeeklyDetail [ttvWeeklyDetailId=" + ttvWeeklyDetailId + ", versionDate=" + versionDate + ", pmsWaveId=" + pmsWaveId + ", targetDate="
				+ targetDate + ", orderQuantity=" + orderQuantity + ", shipQuantity=" + shipQuantity + ", fgQuantity=" + fgQuantity + ", odmCommit="
				+ odmCommit + ", supplyCommit=" + supplyCommit + ", coverA=" + coverA + ", coverB=" + coverB + ", coverC=" + coverC + ", coverD=" + coverD
				+ ", odmFpyCapacity=" + odmFpyCapacity + ", odmRpyCapacity=" + odmRpyCapacity + ", tdmsFpyCapacity=" + tdmsFpyCapacity + ", tdmsRpyCapacity="
				+ tdmsRpyCapacity + ", rampCommit=" + rampCommit + ", toGoForecast=" + toGoForecast + ", toGoOrder=" + toGoOrder + ", output=" + output
				+ ", createdDate=" + createdDate + ", lastModifiedDate=" + lastModifiedDate + ", futureOrderQuantity=" + futureOrderQuantity
				+ ", futureForecastQuantity=" + futureForecastQuantity + "]";
	}

}
