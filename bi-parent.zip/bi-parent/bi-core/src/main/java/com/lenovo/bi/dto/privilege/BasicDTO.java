package com.lenovo.bi.dto.privilege;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;


public class BasicDTO implements Serializable{

	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		Method[] srcMethods 	=this.getClass().getMethods();
		Method[] destMethods    =obj.getClass().getMethods();
		Object obj_ = null;
		for(int i=0;i<destMethods.length;i++){
			Method method=destMethods[i];
			if(StringUtils.endsWithIgnoreCase(method.getName(),"ID") && StringUtils.startsWith(method.getName(),"get")){
				try {
					obj_ = method.invoke(obj);
					if( obj_ == srcMethods[i].invoke(this) ||(obj_ != null && obj_.equals(srcMethods[i].invoke(this)))){
						return true;
					}
					obj_ = null;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
				break;
			}
		}
		return false;
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		Method[] methods  =this.getClass().getMethods();
		for(int i=0;i<methods.length;i++){
			Method method=methods[i];
			if(StringUtils.endsWithIgnoreCase(method.getName(),"ID") && StringUtils.startsWith(method.getName(),"get")){
				try {
					result = prime * result
					+ ((method.invoke(this) == null) ? 0 : method.invoke(this).hashCode());
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
				break;
			}
		}
		return result;
	}
}
