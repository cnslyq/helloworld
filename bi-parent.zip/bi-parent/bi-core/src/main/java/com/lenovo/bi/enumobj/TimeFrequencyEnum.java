package com.lenovo.bi.enumobj;

public enum TimeFrequencyEnum {
	DAILY, WEEKLY;
	
	public static TimeFrequencyEnum fromValue(String value){
		return TimeFrequencyEnum.valueOf(value.toUpperCase());
	}
}
