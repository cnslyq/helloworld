package com.lenovo.bi.dto;

public class NPI {

	private int pmsWaveId;
	private String userId;
	private String userMail;

	public int getPmsWaveId() {
		return pmsWaveId;
	}

	public void setPmsWaveId(int pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserMail() {
		return userMail;
	}

	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}

}
