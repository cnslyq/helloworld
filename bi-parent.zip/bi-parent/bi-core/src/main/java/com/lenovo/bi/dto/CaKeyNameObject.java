package com.lenovo.bi.dto;

public class CaKeyNameObject{
	private Integer odmCommitment;
	private Integer ctp;
	private Integer caTarget;
	private Integer boh;
	private String objKey;
	private String objName;
	private String type;//Product,Odm,Region,Detractor
	

	public String getObjKey() {
		return objKey;
	}

	public void setObjKey(String objKey) {
		this.objKey = objKey;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	public Integer getOdmCommitment() {
		return odmCommitment;
	}

	public void setOdmCommitment(Integer odmCommitment) {
		this.odmCommitment = odmCommitment;
	}

	public Integer getCtp() {
		return ctp;
	}

	public void setCtp(Integer ctp) {
		this.ctp = ctp;
	}

	public Integer getCaTarget() {
		return caTarget;
	}

	public void setCaTarget(Integer caTarget) {
		this.caTarget = caTarget;
	}

	public Integer getBoh() {
		return boh;
	}

	public void setBoh(Integer boh) {
		this.boh = boh;
	}

}
