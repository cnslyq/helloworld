package com.lenovo.bi.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BI_NPISimulationDetail")
public class NPISimulationDetail {
	@Id
	@GeneratedValue
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name = "SimulationId", referencedColumnName="id")  
	private NPISimulationSummary nPISimulationSummary;
	
	@Column(name = "TargetDate")
	private Date targetDate;
	
	@Column(name = "OriginalData")
	private String originalData;
	
	@Column(name = "ModifiedData")
	private String modifiedData;
	
	@Column(name = "ItemName")
	private String itemName;
	
	@Column(name = "Indicator1")
	private String indicator1;
	
	@Column(name = "Indicator2")
	private String indicator2;
	
	@Column(name = "Indicator3")
	private String indicator3;
	
	@Column(name = "Indicator4")
	private String indicator4;
	
	@Column(name = "ModifiedDate")
	private Timestamp modifiedDate;
	
	@Column(name = "CategoryCode")
	private String categoryCode;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public NPISimulationSummary getnPISimulationSummary() {
		return nPISimulationSummary;
	}

	public void setnPISimulationSummary(NPISimulationSummary nPISimulationSummary) {
		this.nPISimulationSummary = nPISimulationSummary;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public String getOriginalData() {
		return originalData;
	}

	public void setOriginalData(String originalData) {
		this.originalData = originalData;
	}

	public String getModifiedData() {
		return modifiedData;
	}

	public void setModifiedData(String modifiedData) {
		this.modifiedData = modifiedData;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getIndicator1() {
		return indicator1;
	}

	public void setIndicator1(String indicator1) {
		this.indicator1 = indicator1;
	}

	public String getIndicator2() {
		return indicator2;
	}

	public void setIndicator2(String indicator2) {
		this.indicator2 = indicator2;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getIndicator3() {
		return indicator3;
	}

	public void setIndicator3(String indicator3) {
		this.indicator3 = indicator3;
	}

	public String getIndicator4() {
		return indicator4;
	}

	public void setIndicator4(String indicator4) {
		this.indicator4 = indicator4;
	}
	
}
