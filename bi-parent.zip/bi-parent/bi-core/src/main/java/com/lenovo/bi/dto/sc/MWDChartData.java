package com.lenovo.bi.dto.sc;

public class MWDChartData {
	private int year;
	private int month;
	private String odm;
	private Float price;
	private String purchaseType;
	private Integer mwd;
	private int dimensionKey;
	private String dimensionName;
	private Integer subDimensionKey;
	private String subDimesnionName;
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public String getOdm() {
		return odm;
	}
	public void setOdm(String odm) {
		this.odm = odm;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public String getPurchaseType() {
		return purchaseType;
	}
	public void setPurchaseType(String purchaseType) {
		this.purchaseType = purchaseType;
	}
	public Integer getMwd() {
		return mwd;
	}
	public void setMwd(Integer mwd) {
		this.mwd = mwd;
	}
	public int getDimensionKey() {
		return dimensionKey;
	}
	public void setDimensionKey(int dimensionKey) {
		this.dimensionKey = dimensionKey;
	}
	public String getDimensionName() {
		return dimensionName;
	}
	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}
	public Integer getSubDimensionKey() {
		return subDimensionKey;
	}
	public void setSubDimensionKey(Integer subDimensionKey) {
		this.subDimensionKey = subDimensionKey;
	}
	public String getSubDimesnionName() {
		return subDimesnionName;
	}
	public void setSubDimesnionName(String subDimesnionName) {
		this.subDimesnionName = subDimesnionName;
	}
	
}
