package com.lenovo.bi.dto;

import com.lenovo.bi.enumobj.DnsShortageCodeEnum;

public class NpiDnsEntry {
	private int cvKey;
	private DnsShortageCodeEnum shortageCode;
	private long demand;
	private long supply;
	private long delta;
	private int normalQuantity;
	private int upsideQuantity;
	private int totalDemand;
	private int bizMonth;
	private int bizWeek;
	private int bizYear;
	private int versionDateKey;
	private int targetDateKey;
	private int monthno;
	public int getCvKey() {
		return cvKey;
	}
	public void setCvKey(int cvKey) {
		this.cvKey = cvKey;
	}
	public DnsShortageCodeEnum getShortageCode() {
		return shortageCode;
	}
	public void setShortageCode(DnsShortageCodeEnum shortageCode) {
		this.shortageCode = shortageCode;
	}
	public long getDemand() {
		return demand;
	}
	public void setDemand(long demand) {
		this.demand = demand;
	}
	public long getSupply() {
		return supply;
	}
	public void setSupply(long supply) {
		this.supply = supply;
	}
	public long getDelta() {
		return delta;
	}
	public void setDelta(long delta) {
		this.delta = delta;
	}
	public int getNormalQuantity() {
		return normalQuantity;
	}
	public void setNormalQuantity(int normalQuantity) {
		this.normalQuantity = normalQuantity;
	}
	public int getUpsideQuantity() {
		return upsideQuantity;
	}
	public void setUpsideQuantity(int upsideQuantity) {
		this.upsideQuantity = upsideQuantity;
	}
	public int getTotalDemand() {
		return totalDemand;
	}
	public void setTotalDemand(int totalDemand) {
		this.totalDemand = totalDemand;
	}
	public int getBizMonth() {
		return bizMonth;
	}
	public void setBizMonth(int bizMonth) {
		this.bizMonth = bizMonth;
	}
	public int getBizWeek() {
		return bizWeek;
	}
	public void setBizWeek(int bizWeek) {
		this.bizWeek = bizWeek;
	}
	public int getBizYear() {
		return bizYear;
	}
	public void setBizYear(int bizYear) {
		this.bizYear = bizYear;
	}
	public int getVersionDateKey() {
		return versionDateKey;
	}
	public void setVersionDateKey(int versionDateKey) {
		this.versionDateKey = versionDateKey;
	}
	public int getTargetDateKey() {
		return targetDateKey;
	}
	public void setTargetDateKey(int targetDateKey) {
		this.targetDateKey = targetDateKey;
	}
	public int getMonthno() {
		return monthno;
	}
	public void setMonthno(int monthno) {
		this.monthno = monthno;
	}
	@Override
	public String toString() {
		return "NpiDnsEntry [cvKey=" + cvKey + ", shortageCode=" + shortageCode
				+ ", demand=" + demand + ", supply=" + supply + ", delta="
				+ delta + ", normalQuantity=" + normalQuantity
				+ ", upsideQuantity=" + upsideQuantity + ", totalDemand="
				+ totalDemand + ", bizMonth=" + bizMonth + ", bizWeek="
				+ bizWeek + ", bizYear=" + bizYear + ", versionDateKey="
				+ versionDateKey + ", targetDateKey=" + targetDateKey
				+ ", monthno=" + monthno + "]";
	}



}
