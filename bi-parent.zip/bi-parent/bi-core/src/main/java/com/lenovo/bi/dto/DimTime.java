package com.lenovo.bi.dto;

public class DimTime {
	private int timeKey;
	public int getTimeKey() {
		return timeKey;
	}
	public void setTimeKey(int timeKey) {
		this.timeKey = timeKey;
	}
	private int dayNumberofWeek;
	private int dayNumberofMonth;
	private int dayNumberofYear;
	public int getDayNumberofWeek() {
		return dayNumberofWeek;
	}
	public void setDayNumberofWeek(int dayNumberofWeek) {
		this.dayNumberofWeek = dayNumberofWeek;
	}
	public int getDayNumberofMonth() {
		return dayNumberofMonth;
	}
	public void setDayNumberofMonth(int dayNumberofMonth) {
		this.dayNumberofMonth = dayNumberofMonth;
	}
	public int getDayNumberofYear() {
		return dayNumberofYear;
	}
	public void setDayNumberofYear(int dayNumberofYear) {
		this.dayNumberofYear = dayNumberofYear;
	}
	@Override
	public String toString() {
		return "DimTime [timeKey=" + timeKey + ", dayNumberofWeek="
				+ dayNumberofWeek + ", dayNumberofMonth=" + dayNumberofMonth
				+ ", dayNumberofYear=" + dayNumberofYear + "]";
	}
}
