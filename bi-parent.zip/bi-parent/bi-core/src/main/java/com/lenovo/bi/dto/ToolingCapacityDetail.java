package com.lenovo.bi.dto;

import java.util.Date;
/**
 * 
 * @author henry_lian
 *
 */
public class ToolingCapacityDetail extends ToolingCapacity {

	private String supply; //supplyer
	private Date signOff;
	private String tech; //v
	private String tooling; //tooling
	private Date  targetDate;
	
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	public String getSupply() {
		return supply;
	}
	public void setSupply(String supply) {
		this.supply = supply;
	}
	public Date getSignOff() {
		return signOff;
	}
	public void setSignOff(Date signOff) {
		this.signOff = signOff;
	}
	public String getTech() {
		return tech;
	}
	public void setTech(String tech) {
		this.tech = tech;
	}
	public String getTooling() {
		return tooling;
	}
	public void setTooling(String tooling) {
		this.tooling = tooling;
	}
}
