package com.lenovo.bi.dto;

import java.util.Date;

import com.lenovo.bi.enumobj.ForecastCommitTypeEnum;
/**
 * 
 * 
 * @author ying_han, henry_lian
 *
 */
public class Forecast {
	protected String forecastId;
	protected String bomNumber;//mtm
	protected String mtmDesc;
	protected String pmsWaveId;
	protected String productKey;
	protected String geographyName;
	protected String odmName;
	protected int quantity;
	protected Date targetDate;
	protected Date versionDate;
	protected ForecastCommitTypeEnum forecastType;
	protected String productName;
	protected String geo;
	protected String region;
	protected String description;
	
	public String getMtmDesc() {
		return mtmDesc;
	}
	public void setMtmDesc(String mtmDesc) {
		this.mtmDesc = mtmDesc;
	}

	protected CtoCvConfig ctoCvConfig;
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getGeo() {
		return geo;
	}
	public void setGeo(String geo) {
		this.geo = geo;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getForecastId() {
		return forecastId;
	}
	public void setForecastId(String forecastId) {
		this.forecastId = forecastId;
	}
	public String getBomNumber() {
		return bomNumber;
	}
	public void setBomNumber(String bomNumber) {
		this.bomNumber = bomNumber;
	}
	
	public String getPmsWaveId() {
		return pmsWaveId;
	}
	public void setPmsWaveId(String pmsWaveId) {
		this.pmsWaveId = pmsWaveId;
	}
	
	public String getProductKey() {
		return productKey;
	}
	
	public void setProductKey(Integer productKey) {
		if(productKey != null) //add by Nicolas on July 28 2014
			this.productKey = Integer.toString(productKey);
	}
	public String getGeographyName() {
		return geographyName;
	}
	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}
	
	public String getOdmName() {
		return odmName;
	}
	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	public Date getVersionDate() {
		return versionDate;
	}
	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}
	public ForecastCommitTypeEnum getForecastType() {
		return forecastType;
	}
	public void setForecastType(String forecastValue) {
		this.forecastType = ForecastCommitTypeEnum.getEnumFromValue(forecastValue);
	}	
	
	public CtoCvConfig getCtoCvConfig() {
		return ctoCvConfig;
	}
	public void setCtoCvConfig(CtoCvConfig ctoCvConfig) {
		this.ctoCvConfig = ctoCvConfig;
	}
	
	@Override
	public String toString() {
		return "Forecast [forecastId=" + forecastId + ", bomNumber="
				+ bomNumber + ", pmsWaveId=" + pmsWaveId + ", productKey="
				+ productKey + ", geographyName=" + geographyName
				+ ", odmName=" + odmName + ", quantity=" + quantity
				+ ", targetDate=" + targetDate + ", versionDate=" + versionDate
				+ ", forecastType=" + forecastType + ", productName="
				+ productName + ", geo=" + geo + ", region=" + region
				+ ", description=" + description + "]";
	}
	
	
}
