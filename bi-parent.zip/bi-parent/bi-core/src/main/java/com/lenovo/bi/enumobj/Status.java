package com.lenovo.bi.enumobj;


public enum Status {
	All,
	In_Progress("4169E1", "inprogress.action","Blue"),
	Fail("DC143C","fail.action","Red"),
	Success("32CD32","success.action","Green"),
	NA("808080","na.action","Gray");
	
	private String color;
	private String url;
	private String labelColor;
	
	public String getLabelColor() {
		return labelColor;
	}
	public String getUrl() {
		return url;
	}
	Status(String color, String url, String labelColor){
		this.color = color;
		this.url = url;
		this.labelColor = labelColor;
	}
	Status(){
		
	}
	
	@Override
	public String toString() {
		return name().replaceAll("_", " ");
	}
	
	public String getColor(){
		return color;
	}
	
}
