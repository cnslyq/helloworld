package com.lenovo.bi.enumobj;

public enum KPILights {

	RED("Red"),
	YELLOW("Yellow"),
	GREEN("Green"),
	GRAY("Gray")
	;
	
	private String color;
	
	KPILights(String color){
		this.color = color;
	}
	
	@Override
	public String toString() {
		return name();
	}
	
	public String getColor(){
		return color;
	}
}
