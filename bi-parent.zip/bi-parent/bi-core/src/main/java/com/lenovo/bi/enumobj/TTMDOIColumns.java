package com.lenovo.bi.enumobj;

public enum TTMDOIColumns {

	Product("ProductName"),
	C(""),
	Type(""),
	SuppleTargetDate("");
	
	private String dbColumnName;

	TTMDOIColumns(String dbColumnName){
		this.dbColumnName = dbColumnName;
	}

	public String getDbColumnName() {
		return dbColumnName;
	}

	public void setDbColumnName(String dbColumnName) {
		this.dbColumnName = dbColumnName;
	}
	
}
