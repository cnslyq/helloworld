package com.lenovo.bi.enumobj;

public enum NPISimulationCategoryCode {
	Supply,ODM,RampCommit,Defect,Tooling
}
