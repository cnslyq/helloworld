package com.lenovo.bi.enumobj;

public enum FPSDStatusEnum {

	OK("OK",1),
	Early("Early",2),
	Late("Late",3),
	ToBeOk("To-be OK",4),
	ToBeEarly("To-be Early",5),
	ToBeLate("To-be Late",6)
	;
	
	private String typeName;
	private int value;
	
	private FPSDStatusEnum(String typeName,int value) {
		this.typeName = typeName;
		this.value = value;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

}
