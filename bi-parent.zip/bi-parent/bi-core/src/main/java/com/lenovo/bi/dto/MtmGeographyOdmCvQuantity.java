package com.lenovo.bi.dto;

public class MtmGeographyOdmCvQuantity extends MtmCvQuantity{
	private String geographyName;
	private String odmName;
	public String getGeographyName() {
		return geographyName;
	}
	public void setGeographyName(String geographyName) {
		this.geographyName = geographyName;
	}
	public String getOdmName() {
		return odmName;
	}
	public void setOdmName(String odmName) {
		this.odmName = odmName;
	}
	
	
}
