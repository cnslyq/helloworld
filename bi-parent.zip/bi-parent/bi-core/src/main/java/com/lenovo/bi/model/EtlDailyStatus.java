package com.lenovo.bi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BI_ETLDailyStatus")
public class EtlDailyStatus {
	@Id
	@GeneratedValue
	private int etlDailyStatusId;
	
	@Column
	private Date versionDate;
	
	@Column 
	private boolean complete;

	public int getEtlDailyStatusId() {
		return etlDailyStatusId;
	}

	public void setEtlDailyStatusId(int etlDailyStatusId) {
		this.etlDailyStatusId = etlDailyStatusId;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public boolean getComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}
	
	
}
