package com.lenovo.bi.dto;

import java.util.Date;

public class DimOrderForNPIExclude {
	private String flag;
	private String poNumber;
	private String poItem;
	private String orderNo;
	private Integer mtmKey;
	private Integer productKey;
	private Integer quantity;
	private Integer odmKey;
	private Integer regionKey;
	private Date orderDate;
	private Date rsdDate;
	private Date fpsdDate;
	private Date fgDate;
	private Date shipDate;
	private Boolean isShipped;
	private String mot;
	private Integer detractorKey;
	private String lateReason2;
	private String shortageDescription;
	private String bomNumberAlternateKey;
	private String mtmEnglishDescription;
	private String region;
	private String geo;
	private String odmEnglishName;
	
	
	public String getBomNumberAlternateKey() {
		return bomNumberAlternateKey;
	}
	public void setBomNumberAlternateKey(String bomNumberAlternateKey) {
		this.bomNumberAlternateKey = bomNumberAlternateKey;
	}
	public String getMtmEnglishDescription() {
		return mtmEnglishDescription;
	}
	public void setMtmEnglishDescription(String mtmEnglishDescription) {
		this.mtmEnglishDescription = mtmEnglishDescription;
	}
	public String getOdmEnglishName() {
		return odmEnglishName;
	}
	public void setOdmEnglishName(String odmEnglishName) {
		this.odmEnglishName = odmEnglishName;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getGeo() {
		return geo;
	}
	public void setGeo(String geo) {
		this.geo = geo;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getPoItem() {
		return poItem;
	}
	public void setPoItem(String poItem) {
		this.poItem = poItem;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public Integer getMtmKey() {
		return mtmKey;
	}
	public void setMtmKey(Integer mtmKey) {
		this.mtmKey = mtmKey;
	}
	public Integer getProductKey() {
		return productKey;
	}
	public void setProductKey(Integer productKey) {
		this.productKey = productKey;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Integer getOdmKey() {
		return odmKey;
	}
	public void setOdmKey(Integer odmKey) {
		this.odmKey = odmKey;
	}
	public Integer getRegionKey() {
		return regionKey;
	}
	public void setRegionKey(Integer regionKey) {
		this.regionKey = regionKey;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Date getRsdDate() {
		return rsdDate;
	}
	public void setRsdDate(Date rsdDate) {
		this.rsdDate = rsdDate;
	}
	public Date getFpsdDate() {
		return fpsdDate;
	}
	public void setFpsdDate(Date fpsdDate) {
		this.fpsdDate = fpsdDate;
	}
	public Date getFgDate() {
		return fgDate;
	}
	public void setFgDate(Date fgDate) {
		this.fgDate = fgDate;
	}
	public Date getShipDate() {
		return shipDate;
	}
	public void setShipDate(Date shipDate) {
		this.shipDate = shipDate;
	}
	public Boolean getIsShipped() {
		return isShipped;
	}
	public void setIsShipped(Boolean isShipped) {
		this.isShipped = isShipped;
	}
	public String getMot() {
		return mot;
	}
	public void setMot(String mot) {
		this.mot = mot;
	}
	public Integer getDetractorKey() {
		return detractorKey;
	}
	public void setDetractorKey(Integer detractorKey) {
		this.detractorKey = detractorKey;
	}
	public String getLateReason2() {
		return lateReason2;
	}
	public void setLateReason2(String lateReason2) {
		this.lateReason2 = lateReason2;
	}
	public String getShortageDescription() {
		return shortageDescription;
	}
	public void setShortageDescription(String shortageDescription) {
		this.shortageDescription = shortageDescription;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	@Override
	public String toString() {
		return "DimOrderForSgaExclude [poNumber=" + poNumber + ", poItem="
				+ poItem + ", orderNo=" + orderNo + ", mtmKey=" + mtmKey
				+ ", productKey=" + productKey + ", quantity=" + quantity
				+ ", odmKey=" + odmKey + ", regionKey=" + regionKey
				+ ", orderDate=" + orderDate + ", rsdDate=" + rsdDate
				+ ", fpsdDate=" + fpsdDate + ", fgDate=" + fgDate
				+ ", shipDate=" + shipDate + ", isShipped=" + isShipped
				+ ", mot=" + mot + ", detractorKey=" + detractorKey
				+ ", lateReason2=" + lateReason2 + ", shortageDescription="
				+ shortageDescription + "]";
	}
}
