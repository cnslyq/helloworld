package com.lenovo.bi.util;

import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CalendarUtilTest {
	@Before
	public void setDefaultLocale() {
		// In order for Monday to be the first day of the week
		Locale.setDefault(Locale.UK);
	}
	
	@Test
	public void testIsSameWeek() throws ParseException {		
		// Same year
		Date date1 = CalendarUtil.stringT2Date("2014-03-10");
		Date date2 = CalendarUtil.stringT2Date("2014-03-12");
		
		Assert.assertTrue(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2014-03-09");
		date2 = CalendarUtil.stringT2Date("2014-03-12");
		
		Assert.assertFalse(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2014-03-08");
		date2 = CalendarUtil.stringT2Date("2014-03-12");
		
		Assert.assertFalse(CalendarUtil.isSameWeek(date1, date2));
				
		// Year end
		date1 = CalendarUtil.stringT2Date("2013-01-01");
		date2 = CalendarUtil.stringT2Date("2014-01-02");
		
		Assert.assertFalse(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2013-12-30");
		date2 = CalendarUtil.stringT2Date("2014-01-02");
		
		Assert.assertTrue(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2013-12-29");
		date2 = CalendarUtil.stringT2Date("2014-01-02");
		
		Assert.assertFalse(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2013-12-28");
		date2 = CalendarUtil.stringT2Date("2014-01-02");
		
		Assert.assertFalse(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2013-12-30");
		date2 = CalendarUtil.stringT2Date("2014-01-06");
		
		Assert.assertFalse(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2013-12-30");
		date2 = CalendarUtil.stringT2Date("2014-01-05");
		
		Assert.assertTrue(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2007-01-01");
		date2 = CalendarUtil.stringT2Date("2007-01-05");
		
		Assert.assertTrue(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2007-01-04");
		date2 = CalendarUtil.stringT2Date("2007-01-08");
		
		Assert.assertFalse(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2006-12-27");
		date2 = CalendarUtil.stringT2Date("2006-12-31");
		
		Assert.assertTrue(CalendarUtil.isSameWeek(date1, date2));
		
		date1 = CalendarUtil.stringT2Date("2006-12-31");
		date2 = CalendarUtil.stringT2Date("2007-01-01");
		
		Assert.assertFalse(CalendarUtil.isSameWeek(date1, date2));				
	}
	
	@Test 
	public void testIsSunday() throws ParseException {
		Date date1 = CalendarUtil.stringT2Date("2014-03-16");
		Date date2 = CalendarUtil.stringT2Date("2014-03-18");
		
		Assert.assertTrue(CalendarUtil.isSunday(date1));
		Assert.assertFalse(CalendarUtil.isSunday(date2));
	}
}
