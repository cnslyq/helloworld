package com.lenovo.bi.service.npi.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.npi.NPIProductSummaryDao;
import com.lenovo.bi.dao.npi.NpiOrderDaoBi;
import com.lenovo.bi.dao.npi.NpiOrderDaoDw;
import com.lenovo.bi.dto.DimOrderForNPIExclude;
import com.lenovo.bi.dto.GeoData;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.form.npi.ttv.SearchExcludeOrderForm;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.model.SGATtvWeeklyDetail;
import com.lenovo.bi.model.SGATtvWeeklySummary;
import com.lenovo.bi.model.TtvWeeklyDetail;
import com.lenovo.bi.model.TtvWeeklySummary;
import com.lenovo.bi.service.npi.TTVOutlookExcludeOrderService;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.ListSortUtil;
import com.lenovo.bi.view.npi.ttv.ExcludeOrderView;
import com.lenovo.bi.view.npi.ttv.OrderUniqueIdentifie;
import com.lenovo.common.model.PagerInformation;

@Service
public class TTVOutlookExcludeOrderServiceImpl implements TTVOutlookExcludeOrderService {

	private NpiOrderDaoBi npiOrderDaoBi;

	private NpiOrderDaoDw npiOrderDaoDw;

	@Inject
	private NPIProductSummaryDao nPIProductSummaryDao;
	@Autowired
	private TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper;
	@Autowired
	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;

	@Override
	public List<ExcludeOrderView> getExcludeOrdersByConditions(Integer waveId, SearchExcludeOrderForm searchExcludeOrderForm) {

		List<ExcludeOrderView> excludeOrderViewList = new ArrayList<ExcludeOrderView>();
		List<Integer> waveIds = new ArrayList<Integer>();
		waveIds.add(waveId);
		List<ProjectSummary> projectList = nPIProductSummaryDao.getProductInfoByWaveId(waveIds, searchExcludeOrderForm.getVersionDate());
		if (CollectionUtils.isEmpty(projectList)) {
			if(searchExcludeOrderForm.getVersionDate() != null){
				projectList = nPIProductSummaryDao.getProductInfoByWaveId(waveIds, null);
			}
			if(CollectionUtils.isEmpty(projectList)){
				return null;
			}
		}
		Date ttvTargetDate;
		if(TTVPhase.sle == searchExcludeOrderForm.getTtvPhase()){
			ttvTargetDate = projectList.get(0).getTtvTargetDate();
		}else{
			ttvTargetDate = projectList.get(0).getSgaTtvTargetDate();
		}
		
		List<NpiOrder> npiOrders = npiOrderDaoBi.getNpiOrderByWaveId(waveId, searchExcludeOrderForm.getVersionDate(),searchExcludeOrderForm.getTtvPhase());
		if(!searchExcludeOrderForm.isPopup()&&(npiOrders == null || npiOrders.isEmpty())){
			return excludeOrderViewList;
		}
		
		List<DimOrderForNPIExclude> dimOrders = null;

		if(searchExcludeOrderForm.getTtvPhase() == TTVPhase.sga && projectList.get(0).getSgaTtvTargetDate() != null){
			dimOrders = npiOrderDaoDw.getDimOrderByWaveId(waveId, CalendarUtil.getMonday(),projectList.get(0).getSgaTtvTargetDate());
		}else if(searchExcludeOrderForm.getTtvPhase() == TTVPhase.sle){
			dimOrders = npiOrderDaoDw.getSleDimOrderByWaveId(waveId, CalendarUtil.getMonday(),projectList.get(0).getSgaTtvTargetDate());
		}

		convertDataForExcludeOrderView(excludeOrderViewList, npiOrders, dimOrders, ttvTargetDate, searchExcludeOrderForm.isShowExcludedOrderOnly());
		
		return excludeOrderViewList;
	}
	/**
	 * scope:>:1; =:0; <:-1
	 * orderType:Late:1; Offset:2; UpSide:3
	 * @throws ParseException 
	 */
	@Override
	public List<ExcludeOrderView> filterExcudeOrderByQueryCondition(List<ExcludeOrderView> excludeOrderViewList,SearchExcludeOrderForm form){
		List<ExcludeOrderView> newExcludeOrder = new ArrayList<ExcludeOrderView>();
		if(CollectionUtils.isNotEmpty(excludeOrderViewList)){
			boolean isQualified;
			for(ExcludeOrderView order : excludeOrderViewList){
				isQualified = true;
				if(StringUtils.isNotBlank(form.getMtm()) && !form.getMtm().contains(order.getMtm())){
					isQualified = false;
				}
				if(StringUtils.isNotBlank(form.getRegionName()) && !form.getRegionName().equals(order.getRegion())){
					isQualified = false;
				}
				if(StringUtils.isNotBlank(form.getGeoName()) && !form.getGeoName().equals(order.getGeo())){
					isQualified = false;
				}
				if(form.getQuantityScope() != null && StringUtils.isNotBlank(form.getQuantityValue())){
					Integer quantity = Integer.parseInt(form.getQuantityValue());
					if(order.getQuantity() == null){
						isQualified = false;
					}else{
						if(order.getQuantity().compareTo(quantity) !=  form.getQuantityScope()){
							isQualified = false;
						}
					}
				}
				if(form.getRsdScope() != null && form.getRsdValueDate() != null){
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
					Date rsdDate;
					try {
						rsdDate = df.parse(order.getRsd());
					} catch (ParseException e) {
						rsdDate = null;
					}
					if(rsdDate == null){
						isQualified = false;
					}else{
						if(rsdDate.compareTo(form.getRsdValueDate()) !=  form.getRsdScope()){
							isQualified = false;
						}
					}
				}
				

				if(form.getFgScope() != null && form.getFGValueDate() != null){
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
					Date fgDate;
					try {
						if (null != order.getFgDate()) {
							fgDate = df.parse(order.getFgDate());
						}
						else {
							fgDate = null;
						}
					} catch (ParseException e) {
						fgDate = null;
					}
					if(fgDate == null){
						isQualified = false;
					}else{
						if(fgDate.compareTo(form.getFGValueDate()) !=  form.getFgScope()){
							isQualified = false;
						}
					}
				}
				
				if(form.getOrderType() != null){
					if(form.getOrderType().equals("1")){
						if(!"Y".equals(order.getLateOrder())){
							isQualified = false;
						}
					}
					else if(form.getOrderType().equals("2")){
						if(!"Y".equals(order.getOffsetOrder())){
							isQualified = false;
						}				
					}
					else if(form.getOrderType().equals("3")){
						if(!"Y".equals(order.getUpsideOrder())){
							isQualified = false;
						}
					}
				}
				if(isQualified){
					newExcludeOrder.add(order);
				}
			}
		}

		return newExcludeOrder;
	}
	@SuppressWarnings("unchecked")
	private void convertDataForExcludeOrderView(List<ExcludeOrderView> excludeOrderViewList, List<NpiOrder> npiOrders, List<DimOrderForNPIExclude> dimOrders,
			Date ttvTargetDate, boolean showExcludedOrderOnly) {

		Map<OrderUniqueIdentifie, ExcludeOrderView> orderViews = new HashMap<OrderUniqueIdentifie, ExcludeOrderView>();

		if (npiOrders != null) {
			for (NpiOrder npiOrder : npiOrders) {
				OrderUniqueIdentifie po = new OrderUniqueIdentifie();
				po.setPoNumber(npiOrder.getPoNumber());
				po.setPoItem(npiOrder.getPoItem());
				po.setMtm(npiOrder.getMtm());
				po.setOrderDate(npiOrder.getOrderDate());
				po.setRsdDate(npiOrder.getRsdDate());
				po.setQuantity(npiOrder.getQuantity());
				po.setRegion(npiOrder.getRegion());
				ExcludeOrderView view = new ExcludeOrderView();
				view.setIsExcluded("Y");
				orderViews.put(po, view);
			}
		}
		if (dimOrders != null) {
			for (DimOrderForNPIExclude dim : dimOrders) {
				
				OrderUniqueIdentifie po = new OrderUniqueIdentifie();
				po.setPoNumber(dim.getPoNumber());
				po.setPoItem(String.valueOf(dim.getPoItem()));
				po.setMtm(dim.getBomNumberAlternateKey());
				po.setOrderDate(dim.getOrderDate());
				po.setRsdDate(dim.getRsdDate());
				po.setQuantity(dim.getQuantity());
				po.setRegion(dim.getRegion());

				ExcludeOrderView view = orderViews.get(po);
				if (view == null) {
					if (showExcludedOrderOnly) {
						continue;
					}
					view = new ExcludeOrderView();
					view.setIsExcluded("N");
				}

				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				StringBuffer excludedOrderId = new StringBuffer()
				.append(dim.getPoNumber())
				.append("_").append(po.getPoItem())
				.append("_").append(po.getRegion())
				.append("_").append(po.getMtm())
				.append("_").append(po.getOrderDate() != null ? df.format(po.getOrderDate()):"")
				.append("_").append(po.getRsdDate() != null ? df.format(po.getRsdDate()):"")
				.append("_").append(po.getQuantity())
				.append("_").append(dim.getShipDate() != null ? df.format(dim.getShipDate()):"");
				view.setExcludedOrderId(excludedOrderId.toString());
				
				view.setOdm(dim.getOdmEnglishName());

				view.setRegion(dim.getRegion());
				view.setRegionKey(dim.getRegionKey());
				view.setGeo(dim.getGeo());
//						view.setGeoKey(geo.getGeographyKey());

				view.setCountry("");
				view.setMtmKey(dim.getMtmKey());
				view.setMtm(dim.getBomNumberAlternateKey());
				view.setDescription(dim.getMtmEnglishDescription() != null ? dim.getMtmEnglishDescription() : "");

				try {
					view.setOrderDate(CalendarUtil.date2String(dim.getOrderDate()));
					if (ttvTargetDate != null) {
						view.setTtvTargetDate(CalendarUtil.date2String(ttvTargetDate));
					}
				} catch (ParseException e1) {

				}
				view.setOrderNumber(dim.getPoNumber());
				view.setOrderItem(String.valueOf(dim.getPoItem()));
				view.setQuantity(dim.getQuantity());

				view.setShipStatus(dim.getIsShipped() ? "Y" : "N");
				
				if("upside".equals(dim.getFlag())){
					view.setUpsideOrder("Y");
				}else if("offset".equals(dim.getFlag())){
					view.setOffsetOrder("Y");
				}

				try {
					if (dim.getRsdDate() != null) {
						view.setRsd(CalendarUtil.date2String(dim.getRsdDate()));
					}
					if (dim.getShipDate() != null) {
						view.setShipDate(CalendarUtil.date2String(dim.getShipDate()));
					}
					if (dim.getFpsdDate() != null) {
						view.setFpsd(CalendarUtil.date2String(dim.getFpsdDate()));
					}
					if (dim.getFgDate() != null) {
						view.setFgrd(CalendarUtil.date2String(dim.getFgDate()));
					}
					if (dim.getFgDate() != null) {
						view.setFgDate(CalendarUtil.date2String(dim.getFgDate()));
					}
					
				} catch (ParseException e) {
				}
				excludeOrderViewList.add(view);
			}
		}
		
		List tempExcludeList = new ArrayList(new HashSet(excludeOrderViewList));
		
		excludeOrderViewList.clear();
		excludeOrderViewList.addAll(tempExcludeList);
	}

	@Override
	public List<NpiOrder> getExcludedOrder(int waveId) {
		return npiOrderDaoBi.getTTVExcludedOrder(waveId, TTVPhase.sle, CalendarUtil.getTodayWithoutMins());
	}

	@Override
	@Transactional("bi")
	public void updateExcludeOrderBySelectedOrders(List<NpiOrder> orders, Integer waveId, TTVPhase ttvPhase){
		/*if(ttvOutlookServiceBiHelper.getBiWeeklyProcessStatus() == JobStatusEnum.RUNNING){
			
		}*/
		npiOrderDaoBi.updateExcludeOrder(orders, waveId, CalendarUtil.getTodayWithoutMins(),ttvPhase);
		/*List<NpiOrder> negativeExistOrders = npiOrderDaoBi.getNegativeNpiOrderByWaveId(waveId,CalendarUtil.getTodayWithoutMins(),ttvPhase);
		if(CollectionUtils.isNotEmpty(negativeExistOrders)){
			if(orders != null){
				orders.addAll(negativeExistOrders);
			}else{
				orders = new ArrayList<NpiOrder>();
				orders.addAll(negativeExistOrders);
			}
		}*/
		if(ttvPhase == TTVPhase.sga){
			// get all excluded orders for this wave
			List<SGATtvWeeklyDetail> npiWeeklyDetails = ttvOutlookServiceBiHelper.getSgaNpiWeeklyDetail(waveId, null, null, CalendarUtil.getMonday());
			List<SGATtvWeeklySummary> weeklySummaries = new ArrayList<SGATtvWeeklySummary>();
			//List<NpiOrder> excludeOrders = ttvOutlookServiceBiHelper.getTTVExcludedOrder(waveId, TTVPhase.sga, CalendarUtil.getTodayWithoutMins());
			ttvOutlookServiceBiHelper.excludeOrders(npiWeeklyDetails, orders);
			ttvOutlookServiceBiHelper.setToGoOrder(npiWeeklyDetails);

			List<SGATtvWeeklySummary> ttvWeeklySummaries = ttvOutlookServiceDwHelper.calculateSGATtvWeeklySummary(waveId, npiWeeklyDetails);
			if (CollectionUtils.isNotEmpty(ttvWeeklySummaries)) {
				weeklySummaries.addAll(ttvWeeklySummaries);
			}
			if(CollectionUtils.isNotEmpty(npiWeeklyDetails)){
				ttvOutlookServiceBiHelper.updateSGANpiWeeklyDetail(npiWeeklyDetails);
			}
			if(CollectionUtils.isNotEmpty(weeklySummaries)){
				ttvOutlookServiceBiHelper.deleteSgaTtvWeeklySummaryByWaveId(waveId, CalendarUtil.getMonday());
				ttvOutlookServiceBiHelper.addSGANpiWeeklySummary(weeklySummaries);
			}
		}else{
			List<TtvWeeklyDetail> npiWeeklyDetails = ttvOutlookServiceBiHelper.getNpiWeeklyDetail(waveId, null, null, CalendarUtil.getMonday());
			//List<NpiOrder> excludedOrders = ttvOutlookServiceBiHelper.getTTVExcludedOrder(waveId, TTVPhase.sle, CalendarUtil.getTodayWithoutMins());
			List<TtvWeeklySummary> summaries = ttvOutlookServiceBiHelper.calculateSLETTVWeeklySummary(CalendarUtil.getMonday(), npiWeeklyDetails, orders);
			if(CollectionUtils.isNotEmpty(summaries)){
				ttvOutlookServiceBiHelper.deleteTtvWeeklySummaryByWaveId(waveId, CalendarUtil.getMonday());
				ttvOutlookServiceBiHelper.PersistTtvWeeklySummary(summaries);
			}
		}
	}

	@Override
	public List<GeoData> getGeoIdAndName() {
		List<GeoData> geos = npiOrderDaoDw.getGeoIdAndName();
		if (null == geos) {
			return new ArrayList<GeoData>();
		}
		return geos;
	}

	@Override
	public List<GeoData> getRegionIdAndName(Integer geoId) {

		List<GeoData> regions = npiOrderDaoDw.getRegionIdAndName(geoId);
		if (null == regions) {
			return new ArrayList<GeoData>();
		}
		return regions;

	}

	@Override
	public List<ExcludeOrderView> getExcludeOrdersGrid(Integer waveId , TTVPhase ttvPhase) {

		SearchExcludeOrderForm searchExcludeOrderForm = new SearchExcludeOrderForm();
		searchExcludeOrderForm.setShowExcludedOrderOnly(true);
		searchExcludeOrderForm.setTtvPhase(ttvPhase);

		return getExcludeOrdersByConditions(waveId, searchExcludeOrderForm);
	}
	
	@Override
	public List<ExcludeOrderView> getExcludeOrdersGrid(Integer waveId , TTVPhase ttvPhase, Date versionDate) {

		SearchExcludeOrderForm searchExcludeOrderForm = new SearchExcludeOrderForm();
		searchExcludeOrderForm.setShowExcludedOrderOnly(true);
		searchExcludeOrderForm.setTtvPhase(ttvPhase);
		searchExcludeOrderForm.setVersionDate(versionDate);

		return getExcludeOrdersByConditions(waveId, searchExcludeOrderForm);
	}

	@Inject
	public void setNpiOrderDaoBi(NpiOrderDaoBi npiOrderDaoBi) {
		this.npiOrderDaoBi = npiOrderDaoBi;
	}

	@Inject
	public void setNpiOrderDaoDw(NpiOrderDaoDw npiOrderDaoDw) {
		this.npiOrderDaoDw = npiOrderDaoDw;
	}

	public NpiOrderDaoBi getNpiOrderDaoBi() {
		return npiOrderDaoBi;
	}

	public NpiOrderDaoDw getNpiOrderDaoDw() {
		return npiOrderDaoDw;
	}
	@Override
	public List<NpiOrder> getNegativeExcludedOrder(Integer waveId,
			TTVPhase ttvPhase, Date versionDate) {
		return npiOrderDaoBi.getNegativeNpiOrderByWaveId(waveId, versionDate, ttvPhase);
	}
	@Override
	public List<ExcludeOrderView> filterExcudeOrderByPagination(
			List<ExcludeOrderView> newExcludeOrder,
			SearchExcludeOrderForm form, int pageSize) {
		
		if(newExcludeOrder == null || newExcludeOrder.isEmpty()){
			return null;
		}
		
		ListSortUtil.sort(newExcludeOrder, form.getColumnName(), form.getSortType().name());
		
		PagerInformation info = new PagerInformation();
		info.setPageSize(pageSize);
		info.setCurrentPage(form.getCurrentPage());
		info.setRecordCount(newExcludeOrder.size());
		if(info.getStartRow() + info.getPageSize() > newExcludeOrder.size()){
			return newExcludeOrder.subList(info.getStartRow(), newExcludeOrder.size());
		} else{
			return newExcludeOrder.subList(info.getStartRow(), info.getStartRow() + info.getPageSize());
		}
	}

}
