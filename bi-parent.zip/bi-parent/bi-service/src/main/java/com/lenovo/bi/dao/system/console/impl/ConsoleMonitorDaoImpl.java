package com.lenovo.bi.dao.system.console.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplSsis;
import com.lenovo.bi.dao.system.console.ConsoleMonitorDao;
import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.view.system.console.FailedJobDetailView;
import com.lenovo.common.model.PagerInformation;

@Repository
public class ConsoleMonitorDaoImpl extends HibernateBaseDaoImplSsis implements ConsoleMonitorDao  {


	@Override
	public List<FailedJobDetailView> listFailedJobs(DictSearchForm form,
			PagerInformation pagerInfo) {
		
		SQLQuery sqlQuery = (SQLQuery)getSession().createSQLQuery("{call GetStatusAfter(?)}")
										.setResultTransformer(Transformers.aliasToBean(FailedJobDetailView.class));
		sqlQuery.setString(0, form.getSearchBy());
		//sqlQuery.setMaxResults(pagerInfo.getPageSize());
		//sqlQuery.setFirstResult(pagerInfo.getStartRow());
		
    	return sqlQuery.list();
	}
	
	@Override
	public int getFailedJobDetailCountByConditions(DictSearchForm form) {
		SQLQuery sqlQuery = (SQLQuery)getSession().createSQLQuery("{call GetStatusAfter(?)}")
				.setResultTransformer(Transformers.aliasToBean(FailedJobDetailView.class));
		
		sqlQuery.setString(0, form.getSearchBy());

	
		return sqlQuery.list().size(); 
	}

	@Override
	public List<FailedJobDetailView> listFailedJobs(String startDate) {
		
		SQLQuery sqlQuery = (SQLQuery)getSession().createSQLQuery("{call GetStatusAfter(?)}")
										.setResultTransformer(Transformers.aliasToBean(FailedJobDetailView.class));
		sqlQuery.setString(0, startDate);
		
    	return sqlQuery.list();
	}
}
