package com.lenovo.bi.engine;

import org.apache.commons.lang.StringUtils;

public class BomNumberGeographyOdmKey {
	private String bomNumber;
	private String geographyName;
	private String odmName;
	
	public BomNumberGeographyOdmKey(String bomNumber, String geographyName, String odmName) {
		super();
		
		if (StringUtils.isEmpty(bomNumber) || StringUtils.isEmpty(geographyName) || StringUtils.isEmpty(odmName)) {
			throw new IllegalArgumentException("Bom number, geography name, or ODM name is empty.");
		}

		this.bomNumber = bomNumber;
		this.geographyName = geographyName;
		this.odmName = odmName;
	}
	public String getBomNumber() {
		return bomNumber;
	}

	public String getGeographyName() {
		return geographyName;
	}	

	public String getOdmName() {
		return odmName;
	}
	@Override
	public String toString() {
		return "BomNumberGeographyOdmKey [bomNumber=" + bomNumber
				+ ", geographyName=" + geographyName + ", odmName=" + odmName
				+ "]";
	}
	@Override
	public int hashCode() {
		return 97 * bomNumber.hashCode() + 89 * geographyName.hashCode() + 83 * odmName.hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof BomNumberGeographyOdmKey) {
			BomNumberGeographyOdmKey key = (BomNumberGeographyOdmKey) obj;
			return this.bomNumber.equals(key.getBomNumber()) && this.geographyName.equals(key.getGeographyName())
					&& this.getOdmName().equals(key.getOdmName());			
		}
		else {
			return false;
		}
	}
	
	
}
