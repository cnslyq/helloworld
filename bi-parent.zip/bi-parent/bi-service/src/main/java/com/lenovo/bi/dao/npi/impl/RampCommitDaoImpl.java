package com.lenovo.bi.dao.npi.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.RampCommitDTO;
import com.lenovo.bi.model.dw.RampCommit;

@Repository
public class RampCommitDaoImpl extends HibernateBaseDaoImplDw<RampCommit> {

	public Integer getRampCommit(Date targetDate, Integer pmsWaveId) {
		String sql = "select rc.Quantity from FactRampCommit rc, DimNPIWave nw, DimTime dt where rc.NPIWaveKey = nw.NPIWaveKey and dt.TimeKey = rc.TargetDateKey and nw.IsCurrent = 1 and dt.FullDateAlternateKey = ?  and nw.PMSWaveIDAlternateKey = ? ";

		Query query = getSession().createSQLQuery(sql);
		query.setParameter(0, targetDate);
		query.setParameter(1, pmsWaveId);
		return (Integer) query.uniqueResult();
	}
	
	@SuppressWarnings("unchecked")
	public List<RampCommitDTO> getRampCommitByWaveId(Integer pmsWaveId){
		StringBuffer sb = new StringBuffer();
		sb.append("select rc.Quantity as value, dt.FullDateAlternateKey as targetDate from FactRampCommit rc, DimNPIWave nw, DimTime dt where rc.NPIWaveKey = nw.NPIWaveKey and dt.TimeKey = rc.TargetDateKey and nw.IsCurrent = 1 and nw.PMSWaveIDAlternateKey = ? ");
		Query query = getSession().createSQLQuery(sb.toString()).setResultTransformer(Transformers.aliasToBean(RampCommitDTO.class));
		query.setParameter(0, pmsWaveId);
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<RampCommitDTO> getRampCommitByWaveIdAndTargetDate(String waveId,
			String startDate, String endDate){
		StringBuffer sb = new StringBuffer();
		sb.append("select                                           ")
		.append(" rc.Quantity as value,                            ")
		.append(" dt.FullDateAlternateKey as targetDate            ")
		.append(" from FactRampCommit rc,                          ")
		.append(" DimNPIWave nw,                                   ")
		.append(" DimTime dt                                       ")
		.append(" where rc.NPIWaveKey = nw.NPIWaveKey              ")
		.append(" and dt.TimeKey = rc.TargetDateKey                ")
		.append(" and nw.IsCurrent = 1                             ")
		.append(" and nw.PMSWaveIDAlternateKey = :waveId               ")
		.append(" and FullDateAlternateKey<= :endDate            ")
		.append(" and FullDateAlternateKey>= :startDate            ");
		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("value", IntegerType.INSTANCE)
				.addScalar("targetDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(RampCommitDTO.class));
		
//		query.setParameter("waveId", "210");
//		query.setParameter("startDate", "2014-01-01");
//		query.setParameter("endDate", "2015-01-01");
		query.setParameter("waveId", waveId);
		query.setParameter("startDate", startDate);
		query.setParameter("endDate", endDate);
		return query.list();
	}

}
