package com.lenovo.bi.service.sc.impl;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.sc.FaComponentDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FaOverViewChartData;
import com.lenovo.bi.dto.sc.GeoFA;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.FaTypeEnum;
import com.lenovo.bi.enumobj.OrderTypeEnum;
import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.service.common.CommonService;
import com.lenovo.bi.service.sc.ComponentFAService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.DataSetLine;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.chart.pie.PieSlice;
import com.lenovo.bi.view.sc.fa.FADetailView;

@Service
@Transactional("dw")
public class ComponentFAServiceImpl implements ComponentFAService{
	
	@Inject
	FaComponentDao faComponentDao;
	
	@Inject
	CommonService commonService;
	
	@Override
	public ColumnChartView getOverviewChart(SearchFaForm form) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();
		setOverviewChartInfomation(columnChartView);
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) || form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
			String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
			
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
				if (form.getEndDate()!=null && yearMonth.compareTo(form.getEndDate()) > 0)
					break;
				Category category = new Category();
				category.setName(yearMonth);
				categoryList.add(category);
			}
		}
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();
		
		DataSetColumn DataSetColumnMps = null;
		DataSetColumn DataSetColumnGrossForecast = null;
		DataSetColumn orderDataSetColumn = null;
		
		//List<ColumnData> grossForecastCloumnDataList = null;
		List<ColumnData> orderCloumnDataList = null;
		
		DataSetLine mpsDataSetline = null;
		DataSetLine grossForecastDataSetline = null;
		DataSetLine targetLineSet = null;
		
		List<ColumnData> mpsLineCloumnDataList = null;
		List<ColumnData> grossForecastLineCloumnDataList = null;
		mpsLineCloumnDataList = new ArrayList<ColumnData>();
		grossForecastLineCloumnDataList = new ArrayList<ColumnData>();
		
		
		targetLineSet = new DataSetLine();
		targetLineSet.setSeriesName("Target");
		targetLineSet.setColor("CC9933");
		targetLineSet.setRenderas("Line");
		targetLineSet.setParentYaxis("S");
		
		DataSetColumnMps = new DataSetColumn();
		DataSetColumnMps.setSeriesName("Mps");
		DataSetColumnMps.setColor("CC99FF");
		List<ColumnData> dbCloumnDataListMps = new ArrayList<ColumnData>();
		
		DataSetColumnGrossForecast = new DataSetColumn();
		DataSetColumnGrossForecast.setSeriesName("GrossForecast");
		DataSetColumnGrossForecast.setColor("CC99FF");
		List<ColumnData> dbCloumnDataListGrossForecast = new ArrayList<ColumnData>();
		
		orderDataSetColumn = new DataSetColumn();
		orderDataSetColumn.setSeriesName("Order");
		orderDataSetColumn.setColor("888888");
		orderCloumnDataList = new ArrayList<ColumnData>();		
		
		mpsDataSetline = new DataSetLine();
		mpsDataSetline.setParentYaxis("S");
		mpsDataSetline.setSeriesName("FA vs. MPS");
		mpsDataSetline.setRenderas("Line");
		mpsDataSetline.setColor("0000FF");
		
		grossForecastDataSetline = new DataSetLine();
		grossForecastDataSetline.setParentYaxis("S");
		grossForecastDataSetline.setSeriesName("FA vs. GrossForecast");
		grossForecastDataSetline.setRenderas("Line");
		grossForecastDataSetline.setColor("0000FF");
		
		ColumnData mpsLineCloumnData = null;
		ColumnData grossForecastLineCloumnData = null;
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		
		//fill data into column chart view
		LinkedHashMap<Object,List<FaOverViewChartData>> faComponentOverviewMap = null;
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())) 
			faComponentOverviewMap = fetchFaComponentOverViewChartData(form);
		if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) 
			faComponentOverviewMap = fetchFaComponentCrossMonthOverviewChartData(form);
		
		int i=0;
		
		for(Map.Entry<Object, List<FaOverViewChartData>> entry : faComponentOverviewMap.entrySet()) {
			String name = ((KeyNameObject)entry.getKey()).getObjName();
			int key = -1;
			if(((KeyNameObject)entry.getKey()).getObjKey() != null)
				key = ((KeyNameObject)entry.getKey()).getObjKey();
			List<FaOverViewChartData> chartDataList = entry.getValue();
			
			ColumnData componentfa = new ColumnData();
			componentfa.setValue(0);
			
			if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
				mpsLineCloumnData = new ColumnData();
				mpsLineCloumnDataList.add(mpsLineCloumnData);
			}
			else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
				grossForecastLineCloumnData = new ColumnData();
				grossForecastLineCloumnDataList.add(grossForecastLineCloumnData);
			}
			
			ColumnData mps = new ColumnData();
			setCompFaOverviewColumnLink(mps,name,key);
			
			ColumnData grossForecast = new ColumnData();
			setCompFaOverviewColumnLink(grossForecast,name,key);
			
			ColumnData order = new ColumnData();
			
			double faRate = 1.0;
			
			StringBuffer valueBuffer = new StringBuffer("[{");
			Category category = (Category)(categoryList.get(i));
			
			for(FaOverViewChartData faOverViewChartData : chartDataList) {
				if(FaTypeEnum.Mps.getTypeName().equals(faOverViewChartData.getTypeName())) {
					setCompFaOverviewColumnLink(mps,name,key);
					mpsLineCloumnData.setValue(faOverViewChartData.getFARate()*100.0);
					mps.setValue(faOverViewChartData.getFAValue());
					order.setValue(faOverViewChartData.getOrderQty());
					faRate = faOverViewChartData.getFARate()*100.0;
					
					valueBuffer.append("mps:");
					valueBuffer.append(faOverViewChartData.getFARate()).append(",");
					dbCloumnDataListMps.add(mps);
					orderCloumnDataList.add(order);
				}
				if(FaTypeEnum.GrossForecast.getTypeName().equalsIgnoreCase(faOverViewChartData.getTypeName())) {
					setCompFaOverviewColumnLink(grossForecast,name,key);
					
					grossForecastLineCloumnData.setValue(faOverViewChartData.getFARate()*100.0);
					grossForecast.setValue(faOverViewChartData.getFAValue());
					order.setValue(faOverViewChartData.getOrderQty());
					faRate = faOverViewChartData.getFARate()*100.0;
					
					valueBuffer.append("grossForecast:");
					valueBuffer.append(faOverViewChartData.getFARate()).append(",");
					dbCloumnDataListGrossForecast.add(grossForecast);
					orderCloumnDataList.add(order);
				}
			}
			valueBuffer.append("fa:");
			valueBuffer.append(getFaRate(faRate)).append(",");
			
			String lightColor = commonService.getKPILightColor(OrderTypeEnum.COMPONENTFA.getType(),(float)faRate);
			valueBuffer.append("lightColor:");
			valueBuffer.append("'" + lightColor + "'");
			valueBuffer.append("}").append("]");
			//System.out.println("----------KPI:" + valueBuffer.toString());
			
			
			category.setValues(valueBuffer.toString());
			ColumnData target = new ColumnData();
			target.setValue(70);
			targetCloumnDataList.add(target);
			i++;
		}
		
		targetLineSet.setDataList(targetCloumnDataList);
		dataSetList.add(targetLineSet);
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			DataSetColumnMps.setDataList(dbCloumnDataListMps);
			orderDataSetColumn.setDataList(orderCloumnDataList);
			dataSetList.add(DataSetColumnMps);
			dataSetList.add(orderDataSetColumn);
			mpsDataSetline.setDataList(mpsLineCloumnDataList);
			dataSetList.add(mpsDataSetline);
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			DataSetColumnGrossForecast.setDataList(dbCloumnDataListGrossForecast);
			orderDataSetColumn.setDataList(orderCloumnDataList);
			dataSetList.add(DataSetColumnGrossForecast);
			dataSetList.add(orderDataSetColumn);
			grossForecastDataSetline.setDataList(grossForecastLineCloumnDataList);
			dataSetList.add(grossForecastDataSetline);
		}
		columnChartView.setDataSetList(dataSetList);
		return columnChartView;
	}
	
	public double getFaRate(double faRate) {
		BigDecimal b = new BigDecimal(faRate); 
		 //保留2位小数
		double f1 = b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue(); 
		return f1;
	}

	@Override
	public ColumnChartView getDashboardChart(SearchFaForm form) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();
		setOverviewChartInfomation(columnChartView);
		
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		LinkedHashMap<Object,List<FaOverViewChartData>> faComponentDashboardMap = null;
		faComponentDashboardMap = fetchFaDashboardOverViewChartData(form);
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();
		
		DataSetColumn DataSetColumnMps = new DataSetColumn();
		DataSetColumnMps.setSeriesName("Mps");
		DataSetColumnMps.setColor("CC99FF");
		List<ColumnData> dbCloumnDataListMps = new ArrayList<ColumnData>();
		
		DataSetColumn DataSetColumnGrossForecast = new DataSetColumn();
		DataSetColumnGrossForecast.setSeriesName("GrossForecast");
		DataSetColumnGrossForecast.setColor("CC99FF");
		List<ColumnData> dbCloumnDataListGrossForecast = new ArrayList<ColumnData>();
		
		DataSetColumn orderDataSetColumn = new DataSetColumn();
		orderDataSetColumn.setSeriesName("Order");
		orderDataSetColumn.setColor("888888");
		List<ColumnData> orderCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetLine mpsDataSetline = null;
		DataSetLine grossForecastDataSetline = null;
		DataSetLine targetLineSet = null;
		
		List<ColumnData> mpsLineCloumnDataList = null;
		List<ColumnData> grossForecastLineCloumnDataList = null;
		mpsLineCloumnDataList = new ArrayList<ColumnData>();
		grossForecastLineCloumnDataList = new ArrayList<ColumnData>();
		
		mpsDataSetline = new DataSetLine();
		mpsDataSetline.setParentYaxis("S");
		mpsDataSetline.setSeriesName("FA vs. MPS");
		mpsDataSetline.setRenderas("Line");
		mpsDataSetline.setColor("0000FF");
		
		grossForecastDataSetline = new DataSetLine();
		grossForecastDataSetline.setParentYaxis("S");
		grossForecastDataSetline.setSeriesName("FA vs. GrossForecast");
		grossForecastDataSetline.setRenderas("Line");
		grossForecastDataSetline.setColor("0000FF");
		
		ColumnData mpsLineCloumnData = null;
		ColumnData grossForecastLineCloumnData = null;
		
		//List<ColumnData> grossForecastCloumnDataList = null;
		
		targetLineSet = new DataSetLine();
		targetLineSet.setSeriesName("Target");
		targetLineSet.setColor("CC9933");
		targetLineSet.setRenderas("Line");
		targetLineSet.setParentYaxis("S");
		
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		
		int i = 0;
		for(Map.Entry<Object, List<FaOverViewChartData>> entry : faComponentDashboardMap.entrySet()) {
			String name = ((KeyNameObject)entry.getKey()).getObjName();
			Category category = new Category();
			category.setName(name);
			categoryList.add(category);
			
			int key = -1;
			if(((KeyNameObject)entry.getKey()).getObjKey() != null)
				key = ((KeyNameObject)entry.getKey()).getObjKey();
			
			List<FaOverViewChartData> chartDataList = entry.getValue();
			

			if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
				mpsLineCloumnData = new ColumnData();
				mpsLineCloumnDataList.add(mpsLineCloumnData);
			}
			else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
				grossForecastLineCloumnData = new ColumnData();
				grossForecastLineCloumnDataList.add(grossForecastLineCloumnData);
			}
			
			ColumnData mps = new ColumnData();
			ColumnData grossForecast = new ColumnData();
			ColumnData order = new ColumnData();
			
			setCompFaOverviewColumnLink(mps,name,key);
			setCompFaOverviewColumnLink(grossForecast,name,key);
			
			ColumnData componentfa = new ColumnData();
			componentfa.setValue(0);
			float faRate = (float) 0.0;
			StringBuffer valueBuffer = new StringBuffer("[{");
			category = (Category)(categoryList.get(i));
			for(FaOverViewChartData faOverViewChartData : chartDataList) {
				if(FaTypeEnum.Mps.getTypeName().equalsIgnoreCase(faOverViewChartData.getTypeName())) {
					setCompFaOverviewColumnLink(mps,name,key);
					mpsLineCloumnData.setValue(faOverViewChartData.getFARate()*100.0);
					mps.setValue(faOverViewChartData.getFAValue());
					order.setValue(faOverViewChartData.getOrderQty());
					faRate = faOverViewChartData.getFARate()*100;
					componentfa.setValue(faOverViewChartData.getFARate()*100.0);
					dbCloumnDataListMps.add(mps);
					orderCloumnDataList.add(order);
					valueBuffer.append("mps:");
					valueBuffer.append(faOverViewChartData.getFARate()).append(",");
				}
				else if(FaTypeEnum.GrossForecast.getTypeName().equalsIgnoreCase(faOverViewChartData.getTypeName())) {
					setCompFaOverviewColumnLink(grossForecast,name,key);
					grossForecastLineCloumnData.setValue(faOverViewChartData.getFARate()*100.0);
					grossForecast.setValue(faOverViewChartData.getFAValue());
					order.setValue(faOverViewChartData.getOrderQty());
					faRate = faOverViewChartData.getFARate()*100;
					componentfa.setValue(faOverViewChartData.getFARate()*100.0);
					dbCloumnDataListGrossForecast.add(grossForecast);
					orderCloumnDataList.add(order);
					valueBuffer.append("grossForecast:");
					valueBuffer.append(faOverViewChartData.getTypeValue()).append(",");
				}
			}
			
			valueBuffer.append("fa:");
			valueBuffer.append((float)(Math.round(faRate*100.00))/100.00).append(",");
			valueBuffer.append("subDimensionName:");
			valueBuffer.append("'" + name + "'").append(",");
			
			String lightColor = commonService.getKPILightColor(OrderTypeEnum.COMPONENTFA.getType(),(float)faRate);
			valueBuffer.append("lightColor:");
			valueBuffer.append("'" + lightColor + "'");
			valueBuffer.append("}").append("]");
			//System.out.println("----------DashboardKPI:" + valueBuffer.toString());
			category.setValues(valueBuffer.toString());
			
			ColumnData target = new ColumnData();
			target.setValue(70);
			targetCloumnDataList.add(target);
			i++;
		}
		
		targetLineSet.setDataList(targetCloumnDataList);
		dataSetList.add(targetLineSet);
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {	
			DataSetColumnMps.setDataList(dbCloumnDataListMps);
			orderDataSetColumn.setDataList(orderCloumnDataList);
			dataSetList.add(DataSetColumnMps);
			dataSetList.add(orderDataSetColumn);
			mpsDataSetline.setDataList(mpsLineCloumnDataList);
			dataSetList.add(mpsDataSetline);
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			DataSetColumnGrossForecast.setDataList(dbCloumnDataListGrossForecast);
			orderDataSetColumn.setDataList(orderCloumnDataList);
			dataSetList.add(DataSetColumnGrossForecast);
			dataSetList.add(orderDataSetColumn);
			grossForecastDataSetline.setDataList(grossForecastLineCloumnDataList);
			dataSetList.add(grossForecastDataSetline);
		}
		columnChartView.setDataSetList(dataSetList);
		return columnChartView;
	}
	
	public void setCompFaOverviewColumnLink(ColumnData cloumnData,String name, int key) {
		cloumnData.setLink("j-refreshRemark-" + name + "," + key);
	}

	public LinkedHashMap<Object,List<FaOverViewChartData>> fetchFaComponentOverViewChartData(SearchFaForm form) throws ParseException {
		LinkedHashMap<Object,List<FaOverViewChartData>> faComponentOverviewMap = new LinkedHashMap<Object,List<FaOverViewChartData>>();
		
		for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
			String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
			if (date.compareTo(form.getEndDate()) > 0) 
				break;
			KeyNameObject keyNameObject = new KeyNameObject();
			keyNameObject.setObjName(date);
			int year = Integer.parseInt(date.substring(0,4));
			int month = Integer.parseInt(date.substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			faComponentOverviewMap.put(keyNameObject, faComponentDao.fetchFaComponentOverViewChartData(form));
		}
		
		return faComponentOverviewMap;
	}
	
	public LinkedHashMap<Object,List<FaOverViewChartData>> fetchFaComponentCrossMonthOverviewChartData(SearchFaForm form) throws ParseException {
		LinkedHashMap<Object,List<FaOverViewChartData>> faOverviewMap = new LinkedHashMap<Object,List<FaOverViewChartData>>();
		
		for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
			String date = CalendarUtil.getYearMonthByMonths(form.getDurationFrom(), i);
			if (date.compareTo(form.getDurationTo()) > 0)
				break;
			KeyNameObject keyNameObject = new KeyNameObject();
			keyNameObject.setObjName(date);
			int year = Integer.parseInt(date.substring(0,4));
			int month = Integer.parseInt(date.substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			faOverviewMap.put(keyNameObject, faComponentDao.fetchFaCrossMonthOverviewChartData(form));
		}
		
		return faOverviewMap;
	}
	
	public LinkedHashMap<Object,List<FaOverViewChartData>> fetchFaDashboardOverViewChartData(SearchFaForm form) throws ParseException {
		LinkedHashMap<Object,List<FaOverViewChartData>> faDashboardOverviewMap = new LinkedHashMap<Object,List<FaOverViewChartData>>();
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		List<KeyNameObject> dimensionList = faComponentDao.fetchDimensions(form);
		for(KeyNameObject keyNameObject : dimensionList) {
			form.setSubDimensionKey(keyNameObject.getObjKey());
			form.setSubDimension(keyNameObject.getObjName());
			faDashboardOverviewMap.put(keyNameObject, faComponentDao.fetchFaDashboardOverViewChartData(form));
		}
		
		return faDashboardOverviewMap;
	}
	
	
	@Override
	public ColumnChartView getRemarkChart(SearchFaForm form) throws ParseException {
		
		ColumnChartView columnChartView = setRemarkChartInfomation();
		List<DataSetParent> faDimensionDataSetList = new ArrayList<DataSetParent>();
		DataSetColumn faDataSetColumn = new DataSetColumn();
		
		if("Odm".equals(form.getDimension()))
			faDataSetColumn.setSeriesName("FA by ODM");
		else if("Region".equals(form.getDimension()))
			faDataSetColumn.setSeriesName("FA by Region");
		else if("Product".equals(form.getDimension()))
			faDataSetColumn.setSeriesName("FA by Product");
		else if("Component".equals(form.getDimension()))
			faDataSetColumn.setSeriesName("FA by Component");
		
		faDataSetColumn.setColor("ff3300");
		List<ColumnData> faCloumnDataList = new ArrayList<ColumnData>();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		List<ScRemarkChartData> faRemarkList = fetchFaRemarkChartData(form);
		
		for(ScRemarkChartData scRemarkChartData : faRemarkList) {
			Category category = new Category();
			category.setName(scRemarkChartData.getSubDimensionName());
			category.setValue(scRemarkChartData.getSubDimensionValue());
			category.setValue(scRemarkChartData.getSubDimensionKey());
			categoryList.add(category);
			
			ColumnData fa = new ColumnData();
			setRemarkColumnLink(1,fa);
			fa.setValue(scRemarkChartData.getFaRate()*100.0);
			
			//faDetail
			String params = null;
			params = form.getDimension() + "," + scRemarkChartData.getSubDimensionName() + "," + scRemarkChartData.getSubDimensionValue();
//			fa.setLink("j-showComponentFaDetail-" + params);
			fa.setTooltext(faDataSetColumn.getSeriesName()+", "+ scRemarkChartData.getSubDimensionName() + ", "+scRemarkChartData.getFaRate()*100+"%");
			if(ChartTypeEnum.CrossMonth.getTypeName().equals(form.getChartType())){
				fa.setLink( "j-showComponentFaDetail-"+params );
			}else if(ChartTypeEnum.Dashboard.getTypeName().equals(form.getChartType())){
				fa.setLink( "j-showComponentFaDashboardDetail-"+params );
			}else{
				fa.setLink( "j-showComponentFaDetail-"+params );
			}
			faCloumnDataList.add(fa);
		}
		Categories categories = new Categories();
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		faDataSetColumn.setDataList(faCloumnDataList);
		faDimensionDataSetList.add(faDataSetColumn);
		columnChartView.setDataSetList(faDimensionDataSetList);
		return columnChartView;
	}

	
	public List<ScRemarkChartData> fetchFaRemarkChartData(SearchFaForm form) throws ParseException {
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		
		List<ScRemarkChartData> remarkChartDataList = new ArrayList<ScRemarkChartData>();
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()))
			remarkChartDataList = faComponentDao.fetchFaComponentRemarkChartData(form);
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName()))
			remarkChartDataList = faComponentDao.fetchFaComponentCrossMonthRemarkChartData(form);
		else if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName()))
			remarkChartDataList = faComponentDao.fetchFaComponentDashboardRemarkChartData(form);
		return remarkChartDataList;
	}
	
	@Override
	public PieChartView getOverviewPieChart(SearchFaForm form) throws ParseException {
		
		PieChartView pView = new PieChartView();
		pView.getChartInfo().setPieRadius("80");
		pView.getChartInfo().setLegendPosition("bottom");
		pView.getChartInfo().setManageLabelOverflow("1");
//		pView.getChartInfo().setEnableSmartLabels("0");
		pView.getChartInfo().setUseEllipsesWhenOverflow("0");
		pView.getChartInfo().setDecimals("1");
//		pView.getChartInfo().setShowPercentInToolTip("0");
//		pView.getChartInfo().setShowPercentValues("0");
		pView.getChartInfo().setNumbersuffix("%");
		pView.getChartInfo().setSkipOverlapLabels("0");
		
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		
		List<FaOverViewChartData> faList =  new ArrayList<FaOverViewChartData>();
		if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())){
			faList = faComponentDao.getcomponentFaDashboardPieChart(form);
		}else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			faList = faComponentDao.getcomponentFaCrossmonthPieChart(form);
		}else{
			faList = faComponentDao.getcomponentFaPieChart(form);
		}
		
		List<PieSlice> pieList = new ArrayList<PieSlice>();
		PieSlice p = null;
		for(FaOverViewChartData fa : faList){
			p = new PieSlice();
			p.setLabel(fa.getRowName());
			p.setValue(String.valueOf(fa.getValue()));
			
			form.setSubDimension(fa.getRowName());
			
			String functionName = null;
			String params = null;
			functionName = "showFaPieOrderDetail";
			if("overview".equalsIgnoreCase(form.getChartType())){
				params = "1,";
			}else if("crossmonth".equalsIgnoreCase(form.getChartType())){
				params = "2,";
			}else if("dashboard".equalsIgnoreCase(form.getChartType())){
				params = "3,";
			}
			params = params + form.getSubDimension() + "," +fa.getValue();
			p.setLink("j-"+functionName+"-" + params);
			pieList.add(p);
		}
		pView.setElements(pieList);
		return pView;
	}
	
	public float calFaRate(int totalFa, int subFa) {
		BigDecimal faRate = new BigDecimal(0);
		MathContext mc = new MathContext(1, RoundingMode.HALF_DOWN);
		
		try{
			faRate = new BigDecimal(subFa).divide(new BigDecimal(totalFa),mc).multiply(new BigDecimal(100));
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return faRate.floatValue();
	}
	
	public void setRemarkColumnLink(int regionId,ColumnData cloumnData) {
		
		cloumnData.setLink( "j-showOrderDetail-"+regionId );
	
	}
	
	private ColumnChartView setRemarkChartInfomation() {
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		columnChartView.getChartInfo().setFormatNumber("%");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setShowBorder("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setShowValues("0");
//		columnChartView.getChartInfo().setSnumberSuffix("%");
		columnChartView.getChartInfo().setNumbersuffix("%");
//		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");
		
		return columnChartView;
	}
	
	private void setOverviewChartInfomation(ColumnChartView mSColumnChartView) {
		mSColumnChartView.getChartInfo().setCaption("");
		mSColumnChartView.getChartInfo().setNumdivlines("9");
		mSColumnChartView.getChartInfo().setyAxisMinValue("0");
		mSColumnChartView.getChartInfo().setyAxisMaxValue("160");
		mSColumnChartView.getChartInfo().setsYAxisMinValue("0");
		mSColumnChartView.getChartInfo().setsYAxisMaxValue("100");
		mSColumnChartView.getChartInfo().setFormatNumberScale("0");
		mSColumnChartView.getChartInfo().setLegendIconScale("1");
		mSColumnChartView.getChartInfo().setShowBorder("1");
		mSColumnChartView.getChartInfo().setCanvasBorderThickness("1");
		mSColumnChartView.getChartInfo().setShowZeroPlaneValue("1");
		mSColumnChartView.getChartInfo().setCanvasBorderAlpha("60");
		mSColumnChartView.getChartInfo().setPlotSpacePercent("70");
		mSColumnChartView.getChartInfo().setBgalpha("0,0");
		mSColumnChartView.getChartInfo().setLegendPosition("");
		mSColumnChartView.getChartInfo().setShowBorder("0");
		mSColumnChartView.getChartInfo().setShowPlotBorder("0");
		mSColumnChartView.getChartInfo().setShowValues("0");
	}
	
	@Override
	public String getLackProduct(SearchFaForm form) throws ParseException {
		int target=70;
		List<String>products = faComponentDao.getLackProduct(form,target);
		return products.toString();
	}
	
	@Override
	public String getLackRegion(SearchFaForm form) throws ParseException {
		int target=70;
		List<String>products = faComponentDao.getLackRegion(form,target);
		return products.toString();
	}
	
	@Override
	public String getGeo(SearchFaForm form) throws ParseException {
		List<GeoFA> geoInfo = faComponentDao.getGeoFa(form);
		StringBuffer valueBuffer = new StringBuffer("");
		float faRate = (float)0.0;
		for(GeoFA geoinfo : geoInfo){
			faRate = geoinfo.getFARate();
			valueBuffer.append(geoinfo.getGeo());
			valueBuffer.append(":").append(getFaRate(faRate*100) + "%").append(",");
		}
		String geo = valueBuffer.toString();
		return geo;
	}
	
	@Override
	public List<FADetailView> getComponentFaDetail(SearchFaForm form) {
		return faComponentDao.getComponentFaDetail(form);
	}
	
	@Override
	public List<FADetailView> getComponentFaGEODetail(SearchFaForm form) {
		return faComponentDao.getComponentFaGEODetail(form);
	}
	
	@Override
	public List<FADetailView> getComponentFaPieDetail(SearchFaForm form) {
		return faComponentDao.getComponentFaPieDetail(form);
	}
	
	@Override
	public long getComponentFaDetailCount(SearchFaForm form) {
		long count = 0;
		if(!StringUtil.isEmpty(form.getGEO())){
			count = faComponentDao.getComponentFaGEODetailCount(form);
		}else{
			count =  faComponentDao.getComponentFaDetailCount(form);
		}
		return count;
	}
	
	@Override
	public long getComponentFaDashboardDetailCount(SearchFaForm form) {
		return faComponentDao.getComponentFaDashboardDetailCount(form);
	}
	
	@Override
	public Map<String,Object> getComponentFADetailExprot(SearchFaForm form) {
		List<FADetailView> grid = new ArrayList<FADetailView>();
		long totalCount = 0;
		if(!StringUtil.isEmpty(form.getGEO())){
			totalCount = faComponentDao.getComponentFaGEODetailCount(form);
		}else{
			totalCount = faComponentDao.getComponentFaDetailCount(form);
		}
		
		form.setRowCount(totalCount);
		form.setEndRow((int) totalCount);
		
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			if(!StringUtil.isEmpty(form.getGEO())){
				grid = faComponentDao.getComponentFAGEODetailExport(form);
			}else{
				grid = faComponentDao.getComponentFADetailExport(form);
			}
			
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	
}
