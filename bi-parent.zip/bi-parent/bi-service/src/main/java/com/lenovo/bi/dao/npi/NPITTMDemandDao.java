package com.lenovo.bi.dao.npi;

import java.util.List;

import com.lenovo.bi.dto.TTMDemand;
import com.lenovo.bi.dto.TTMDemandDetail;

public interface NPITTMDemandDao {

	public Integer getTTMTargetDemandByWaveId(int pmsWaveId);
	
	public List<TTMDemand> getTTMDemandListByWaveId(int pmsWaveId);
	
	public List<TTMDemandDetail> getTTMDemandDetailListById(int pmsWaveId);
}
