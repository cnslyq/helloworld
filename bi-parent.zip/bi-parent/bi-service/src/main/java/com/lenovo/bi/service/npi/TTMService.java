package com.lenovo.bi.service.npi;


import java.util.Date;
import java.util.List;

import com.lenovo.bi.form.npi.SearchProductsFormForPopUp;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
import com.lenovo.bi.form.npi.ttm.SearchSearchProductGridProductsForm;
import com.lenovo.bi.view.npi.ProductViewForPopUp;
import com.lenovo.bi.view.npi.ProductWave;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.ttm.DoiGrid;
import com.lenovo.bi.view.npi.ttm.TTMProductDetail;
import com.lenovo.bi.view.npi.ttm.TtmGridProduct;
import com.lenovo.common.model.Pager;

/**
 * this service for handler ttm model event
 * @author coris_zhao
 *
 */
public interface TTMService {
	/**
	 *  this method for ttm/my products grid use, include overview/in progress/fail/na/success pages's grid
	 * @param form
	 * @return
	 */
	public Pager<TtmGridProduct> getProductsByConditions(OverviewSearchForm form);
	/**
	 * this method for search products grid use
	 * @param form
	 * @param privilegeLevel
	 * @return
	 */
	public Pager<TtmGridProduct> getSearchProductsByConditions(SearchSearchProductGridProductsForm form);
	/**
	 * this method for ttm/my products pie chart use
	 * @param form
	 * @return
	 */
	public PieChartView getChartDataByConditions(OverviewSearchForm form);
	/**
	 * this method for DOI material shortage pie chart use
	 * @param form
	 * @return
	 */
	public PieChartView getDoiPieChartData(Integer pmsWaveId, String category);
	/**
	 * this method for project detail
	 * @param proWave
	 * @return
	 */
	public TTMProductDetail getProjectDetail(ProductWave proWave);
	
	public TTMProductDetail getSnapshotDetailByDate(ProductWave proWave, Date targetDate);
	
	/**
	 * this method for pop up div search product.
	 * @param form
	 * @param object
	 * @return
	 */
	public ProductViewForPopUp getPopUpGridProducts(SearchProductsFormForPopUp form);
	public ProductViewForPopUp getPopUpGridProductsForDoi(SearchProductsFormForPopUp searchProductForm);
	
	public List<DoiGrid> getDoiProductsByConditions(Integer pmsWaveId);
}
