package com.lenovo.bi.service.sc.impl;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.common.ExcludeOrderDao;
import com.lenovo.bi.dao.npi.NpiOrderDaoDw;
import com.lenovo.bi.dao.sc.OTSDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.dto.sc.OtsRemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.OTSStatusEnum;
import com.lenovo.bi.enumobj.OrderTypeEnum;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.service.common.CommonService;
import com.lenovo.bi.service.common.MasterDataService;
import com.lenovo.bi.service.sc.BPSService;
import com.lenovo.bi.service.sc.FPSDService;
import com.lenovo.bi.service.sc.ONSService;
import com.lenovo.bi.service.sc.OTSService;
import com.lenovo.bi.service.sc.ScCommonService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.OtsRemarkChartDataComparator;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.LineSet;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSet;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;

@Service
public class OTSServiceImpl implements OTSService {

	@Inject
	OTSDao otsDao;
	
	@Inject
	CommonService commonService;
	
	@Inject
	NpiOrderDaoDw npiOrderDaoDw;
	
	@Inject
	ScCommonService scCommonService;
	
	@Inject
	FPSDService fpsdService;
	
	@Inject
	ONSService onsService;
	
	@Inject
	BPSService bpsService;
	
	@Inject
	ExcludeOrderDao excludeOrderDao;
	
	@Inject
	private MasterDataService masterDataService;
	
	@Override
	public MSColumnChartView getOverviewChart(SearchOtsForm form) throws ParseException {
		MSColumnChartView columnChartView = new MSColumnChartView();
		setOverviewChartInfomation(columnChartView);
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
				|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
			String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
			
			if(!form.isShowQuarterOverview()) {
				for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
					String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
					if (form.getEndDate()!=null && yearMonth.compareTo(form.getEndDate()) > 0) 
						break;
					Category category = new Category();
					category.setName(yearMonth);
					categoryList.add(category);
				}
			}
			else {
				String date = "";
				if(form.getStartDate().substring(5).compareTo("04") < 0)
					date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
				else
					date = form.getStartDate().substring(0, 5) + "04";
				for(int i=0; i<4; i++) {
					Category category = new Category();
					category.setName("Q"+ (i+1));
					String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
					String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
					category.setQuarterValue(quarterFrom + "||" + quarterTo);
					categoryList.add(category);
				}
			}
			
		}
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		//dataset list and lineset list
		List<DataSet> dataSetList = new ArrayList<DataSet>();
		List<LineSet> lineSetList = new ArrayList<LineSet>();
		
		//dataset
		DataSet otsOrderDataSet = new DataSet();
		
		LineSet makeRateLineSet = new LineSet();
		makeRateLineSet.setSeriesName("Make Rate");
		makeRateLineSet.setColor("009966");
		makeRateLineSet.setShowValues("0");
		makeRateLineSet.setLineThickness("2");
		
		LineSet targetLineSet = new LineSet();
		targetLineSet.setSeriesName("Target");
		targetLineSet.setColor("FF0099");
		targetLineSet.setShowValues("0");
		targetLineSet.setLineThickness("2");
		
		//dataset:seriesName
		List<DataSetParent> otsOrderDataSetList = new ArrayList<DataSetParent>();
		
		DataSetColumn makeDataSetColumn = new DataSetColumn();
		makeDataSetColumn.setSeriesName(OTSStatusEnum.MAKE.getTypeName());
		makeDataSetColumn.setColor("00CC00");//00CC00;CCFF99;66FF33;999999
		List<ColumnData> makeCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn failDataSetColumn = new DataSetColumn();
		failDataSetColumn.setSeriesName(OTSStatusEnum.FAIL.getTypeName());
		failDataSetColumn.setColor("FF0000");//FF0000;CCFF99;FFCC00;CCCCCC
		List<ColumnData> failCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn toBeMakeDataSetColumn = new DataSetColumn();
		toBeMakeDataSetColumn.setSeriesName(OTSStatusEnum.ToBeMake.getTypeName());
		toBeMakeDataSetColumn.setColor("66FF99");//FFCC00;CCFFCC;66FFCC;AAAAAA
		List<ColumnData> toBeMakeCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn toBeFailDataSetColumn = new DataSetColumn();
		toBeFailDataSetColumn.setSeriesName(OTSStatusEnum.ToBeFail.getTypeName());
		toBeFailDataSetColumn.setColor("FF99FF");//999999;FFCCFF;FFCCCC;EEEEEE
		List<ColumnData> toBeFailCloumnDataList = new ArrayList<ColumnData>();
		
		List<ColumnData> makeRateColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		
		LinkedHashMap<Object,List<ScOverViewChartData>> otsOverviewMap = null;
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())) 
			otsOverviewMap = fetchOtsOverViewChartData(form);
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName()))
			otsOverviewMap = fetchOtsCrossMonthOverviewChartData(form);
		else
			otsOverviewMap = fetchOtsDashboardOverViewChartData(form);
		int i=0;
		for(Map.Entry<Object, List<ScOverViewChartData>> entry : otsOverviewMap.entrySet()) {
			String name = ((KeyNameObject)entry.getKey()).getObjName();
			int key = -1;
			if(((KeyNameObject)entry.getKey()).getObjKey() != null)
				key = ((KeyNameObject)entry.getKey()).getObjKey();
			List<ScOverViewChartData> chartDataList = entry.getValue();
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				Category category = new Category();
				category.setName(name);
				categoryList.add(category);
			}
			
			ColumnData make = new ColumnData();
			setOTSOverviewColumnLink(make,name,key);
			make.setValue(0);
			
			ColumnData fail = new ColumnData();
			setOTSOverviewColumnLink(fail,name,key);
			fail.setValue(0);
			
			ColumnData toBeMake = new ColumnData();
			setOTSOverviewColumnLink(toBeMake,name,key);
			toBeMake.setValue(0);
			
			ColumnData toBeFail = new ColumnData();
			setOTSOverviewColumnLink(toBeFail,name,key);
			toBeFail.setValue(0);
			
			ColumnData makeRate = new ColumnData();
			makeRate.setValue(0);
			ColumnData onsNum = new ColumnData();
			onsNum.setValue(0);
			ColumnData fpsdRate = new ColumnData();
			fpsdRate.setValue(0);
			ColumnData bpsRate = new ColumnData();
			bpsRate.setValue(0);
			
			Map<String,Integer> dataMap = new HashMap<String,Integer>();
			
			StringBuffer valueBuffer = new StringBuffer("[{");
			Category category = (Category)(categoryList.get(i));
			for(ScOverViewChartData otsOverViewChartData : chartDataList) {
				if(otsOverViewChartData.getScStatusName().equals(OTSStatusEnum.MAKE.getTypeName())) {
					setOTSOverviewColumnLink(make,name,key);
					make.setValue(otsOverViewChartData.getOrderNum());
					valueBuffer.append("make:");
					dataMap.put(OTSStatusEnum.MAKE.getTypeName(), otsOverViewChartData.getOrderNum());
				}
				else if(otsOverViewChartData.getScStatusName().equals(OTSStatusEnum.FAIL.getTypeName())) {
					setOTSOverviewColumnLink(fail,name,key);
					fail.setValue(otsOverViewChartData.getOrderNum());
					valueBuffer.append("fail:");
					dataMap.put(OTSStatusEnum.FAIL.getTypeName(), otsOverViewChartData.getOrderNum());
				}
				else if(otsOverViewChartData.getScStatusName().equals(OTSStatusEnum.ToBeMake.getTypeName())) {
					setOTSOverviewColumnLink(toBeMake,name,key);
					toBeMake.setValue(otsOverViewChartData.getOrderNum());
					valueBuffer.append("toBeMake:");
					dataMap.put(OTSStatusEnum.ToBeMake.getTypeName(), otsOverViewChartData.getOrderNum());
				}
				else if(otsOverViewChartData.getScStatusName().equals(OTSStatusEnum.ToBeFail.getTypeName())) {
					setOTSOverviewColumnLink(toBeFail,name,key);
					toBeFail.setValue(otsOverViewChartData.getOrderNum());
					valueBuffer.append("toBeFail:");
					dataMap.put(OTSStatusEnum.ToBeFail.getTypeName(), otsOverViewChartData.getOrderNum());
				}
				valueBuffer.append(otsOverViewChartData.getOrderNum()).append(",");
			}
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				valueBuffer.append("subDimensionName:");
				valueBuffer.append("'" + name + "'").append(",");
			}
			
			float makeRateValue = 0;
			float onsNumValue = 0;
			float fpsdRateValue = 0;
			float bpsRateValue = 0;
			
			//ots:makeRateValue
			if(!form.isShowQuarterOverview()) {
				if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())) {
					//fpsd:fpsdRateValue
					fpsdRateValue = fpsdService.calFpsdRate(category.getName(), form);
					//ons:onsNum
					onsNumValue = onsService.calOnsNum(category.getName(), form);
					//bps:bpsRateValue
					bpsRateValue = bpsService.calOverViewBpsRateByMonth(category.getName());
					
					makeRateValue = commonService.calculateOtsMakeRate(category.getName(), dataMap);
				}
				else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName()))
					makeRateValue = commonService.calculateOtsMakeRate(category.getName(), dataMap);
				else
					makeRateValue = commonService.calculateOtsMakeRate(form.getSelectMonth(), dataMap);
			}
			else {
				makeRateValue = commonService.calculateOtsMakeRateForQuarter(form, category.getQuarterValue(), dataMap);
			}

			makeRate.setValue(makeRateValue);
			onsNum.setValue(onsNumValue);
			fpsdRate.setValue(fpsdRateValue);
			bpsRate.setValue(bpsRateValue);
			makeRateColumnDataList.add(makeRate);
			/*makeRateColumnDataList.add(onsNum);
			makeRateColumnDataList.add(fpsdRate);
			makeRateColumnDataList.add(bpsRate);*/
			
			valueBuffer.append("makeRate:");
			valueBuffer.append(makeRateValue).append(",");
			valueBuffer.append("onsNum:");
			valueBuffer.append(onsNumValue).append(",");
			valueBuffer.append("fpsdRate:");
			valueBuffer.append(fpsdRateValue).append(",");
			valueBuffer.append("bpsRate:");
			valueBuffer.append(bpsRateValue).append(",");
			
			String lightColor = commonService.getKPILightColor(form.getOrderTypeName(),makeRateValue);
			valueBuffer.append("lightColor:");
			valueBuffer.append("'" + lightColor + "',");
			String onsLightColor = commonService.getOnsKPILightColor(onsNumValue);
			valueBuffer.append("onsLightColor:");
			valueBuffer.append("'" + onsLightColor + "',");
			String fpsdLightColor = commonService.getKPILightColor(OrderTypeEnum.FPSD.getType(),makeRateValue);
			valueBuffer.append("fpsdLightColor:");
			valueBuffer.append("'" + fpsdLightColor + "',");
			String bpsLightColor = commonService.getKPILightColor(OrderTypeEnum.BPS.getType(),bpsRateValue);
			valueBuffer.append("bpsLightColor:");
			valueBuffer.append("'" + bpsLightColor + "'");
			
			valueBuffer.append("}").append("]");
			//System.out.println("----------KPI:" + valueBuffer.toString());
			
			category.setValues(valueBuffer.toString());
			makeCloumnDataList.add(make);
			failCloumnDataList.add(fail);
			toBeMakeCloumnDataList.add(toBeMake);
			toBeFailCloumnDataList.add(toBeFail);
			
			//Target
			ColumnData target = new ColumnData();
			float targetValue = 0;
			Float thresholdValue = masterDataService.getThresholdByName(Threshold.SC_OTS_OTS_TARGET.name());
			if(thresholdValue != null)
				targetValue = thresholdValue.floatValue();
			target.setValue(targetValue);
			targetCloumnDataList.add(target);
			i++;
		}
		
		makeDataSetColumn.setDataList(makeCloumnDataList);
		otsOrderDataSetList.add(makeDataSetColumn);
		
		failDataSetColumn.setDataList(failCloumnDataList);
		otsOrderDataSetList.add(failDataSetColumn);
		
		toBeMakeDataSetColumn.setDataList(toBeMakeCloumnDataList);
		otsOrderDataSetList.add(toBeMakeDataSetColumn);
		
		toBeFailDataSetColumn.setDataList(toBeFailCloumnDataList);
		otsOrderDataSetList.add(toBeFailDataSetColumn);
		
		otsOrderDataSet.setDataSetList(otsOrderDataSetList);
		makeRateLineSet.setDataList(makeRateColumnDataList);
		targetLineSet.setDataList(targetCloumnDataList);
		
		dataSetList.add(otsOrderDataSet);
		lineSetList.add(makeRateLineSet);
		lineSetList.add(targetLineSet);
		
		columnChartView.setDataSetList(dataSetList);
		columnChartView.setLineSetList(lineSetList);
		
		return columnChartView;
	}

	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchOtsOverViewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> otsOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		if(!form.isShowQuarterOverview()) {
			String yearMonth = "";
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
				otsOverviewMap.put(keyNameObject, otsDao.fetchOtsOverViewChartData(form));
			}
		}
		else {
			String date = "";
			if(form.getStartDate().substring(5).compareTo("04") < 0)
				date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
			else
				date = form.getStartDate().substring(0, 5) + "04";
			for(int i=0; i<4; i++) {
				KeyNameObject keyNameObject = new KeyNameObject();
				String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
				String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
				form.setQuarterFrom(quarterFrom.replace("-0", "-"));
				form.setQuarterTo(quarterTo.replace("-0", "-"));
				keyNameObject.setObjName(quarterFrom + "||" + quarterTo);
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , quarterFrom.replace("-", "") , quarterTo.replace("-", "")));
				otsOverviewMap.put(keyNameObject, otsDao.fetchOtsOverViewChartData(form));
			}
		}
		
		return otsOverviewMap;
	}
	
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchOtsCrossMonthOverviewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> otsOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
		if(!form.isShowQuarterOverview()) {
			String yearMonth = "";
			for(int i=0; i<12; i++) {
				String date = CalendarUtil.getYearMonthByMonths(startDate, i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
				otsOverviewMap.put(keyNameObject, otsDao.fetchOtsCrossMonthOverviewChartData(form));
			}
		}
		else {
			String date = "";
			if(form.getStartDate().substring(5).compareTo("04") < 0)
				date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
			else
				date = form.getStartDate().substring(0, 5) + "04"; 
			for(int i=0; i<4; i++) {
				KeyNameObject keyNameObject = new KeyNameObject();
				String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
				String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
				form.setQuarterFrom(quarterFrom);
				form.setQuarterTo(quarterTo);
				keyNameObject.setObjName(quarterFrom + "||" + quarterTo);
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , quarterFrom.replace("-", "") , quarterTo.replace("-", "")));
				otsOverviewMap.put(keyNameObject, otsDao.fetchOtsCrossMonthOverviewChartData(form));
			}
		}
		
		return otsOverviewMap;
	}
	
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchOtsDashboardOverViewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> otsDashboardOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		
		List<KeyNameObject> dimensionList = null;
		String yearMonth = month < 10 ? year + "-0" + month : year + "-" + month;
		form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
		if(form.isShowGeoOverview()) {
			dimensionList = otsDao.fetchGeoDimensions(form);
			for(KeyNameObject keyNameObject : dimensionList) {
				form.setGeoKey(keyNameObject.getObjKey());
				otsDashboardOverviewMap.put(keyNameObject, otsDao.fetchOtsGeoDashboardOverViewChartData(form));
			}
		}
		else {
			dimensionList = otsDao.fetchDimensions(form);
			for(KeyNameObject keyNameObject : dimensionList) {
				form.setSubDimensionKey(keyNameObject.getObjKey());
				otsDashboardOverviewMap.put(keyNameObject, otsDao.fetchOtsDashboardOverViewChartData(form));
			}
		}
		
		return otsDashboardOverviewMap;
	}
	
	public void setOTSOverviewColumnLink(ColumnData cloumnData,String name, int key) {
		/*cloumnData.setLink("j-showDetractorMainPieAndData-"
				+ weekNo + "," 
				+ trackingCausesMonday + "|" 
				+trackingCausesSunday);*/
		cloumnData.setLink("j-refreshRemark-" + name + "," + key);
	}
	
	@Override
	public ColumnChartView getRemarkChart(SearchOtsForm form) throws ParseException {
		ColumnChartView columnChartView = setOtsRemarkChartInfomation();
		
		//dataset:seriesName
		List<DataSetParent> otsDimensionDataSetList = new ArrayList<DataSetParent>();
		
		//Fail Rate; To-be Fail Rate;
		DataSetColumn failDataSetColumn = new DataSetColumn();
		failDataSetColumn.setSeriesName("Fail");
		failDataSetColumn.setColor("FF0000");
		List<ColumnData> failCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn toBeFailDataSetColumn = new DataSetColumn();
		toBeFailDataSetColumn.setSeriesName("To-be Fail");
		toBeFailDataSetColumn.setColor("FF99FF");
		List<ColumnData> toBeFailCloumnDataList = new ArrayList<ColumnData>();
		
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		List<OtsRemarkChartData> otsRemarkChartDataList  = fetchOtsRemarkChartData(form);
		
		for(int i=0; i<otsRemarkChartDataList.size(); i++) {
			if(i == 15) break;
			OtsRemarkChartData otsRemarkChartData = otsRemarkChartDataList.get(i);
			String name = otsRemarkChartData.getDimensionName();
			int value = otsRemarkChartData.getDimensionKey();
			
			Category category = new Category();
			category.setName(name);
			category.setValue(value);
			categoryList.add(category);
			
			String dimensionInfo = "";
			if(ChartTypeEnum.OverView.getTypeName().equals(form.getChartType()))
				dimensionInfo = form.getDimension()+ "," + name;
			else
				dimensionInfo = form.getDimension()+ "," + name + "~" + value;
			ColumnData fail = new ColumnData();
			setRemarkColumnLink(dimensionInfo,fail,form);
			fail.setValue(0);
			
			ColumnData toBeFail = new ColumnData();
			setRemarkColumnLink(dimensionInfo,toBeFail,form);
			toBeFail.setValue(0);
			
			setRemarkColumnLink(dimensionInfo+","+ OTSStatusEnum.FAIL.getTypeName(),fail,form);
			fail.setValue(otsRemarkChartData.getFailRate());
			fail.setTooltext(OTSStatusEnum.FAIL.getTypeName() +", " + name + ", "+ otsRemarkChartData.getFailRate() + "%");
		
			setRemarkColumnLink(dimensionInfo+","+ OTSStatusEnum.ToBeFail.getTypeName(),toBeFail,form);
			toBeFail.setValue(otsRemarkChartData.getToBeFailRate());
			toBeFail.setTooltext(OTSStatusEnum.ToBeFail.getTypeName() +", " + name + ", "+ otsRemarkChartData.getToBeFailRate() + "%");
			
			if(fail.getValue().intValue() != 0) 
				failCloumnDataList.add(fail);
			else
				failCloumnDataList.add(null);
			
			if(toBeFail.getValue().intValue() != 0) 
				toBeFailCloumnDataList.add(toBeFail);
			else
				toBeFailCloumnDataList.add(null);
		}
		Categories categories = new Categories();
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		failDataSetColumn.setDataList(failCloumnDataList);
		otsDimensionDataSetList.add(failDataSetColumn);
		
		
		toBeFailDataSetColumn.setDataList(toBeFailCloumnDataList);
		otsDimensionDataSetList.add(toBeFailDataSetColumn);
		
		columnChartView.setDataSetList(otsDimensionDataSetList);
		
		return columnChartView;
	}

	
	public List<OtsRemarkChartData> fetchOtsRemarkChartData(SearchOtsForm form) throws ParseException {
		if(form.getStartDate().equalsIgnoreCase(form.getEndDate())){
			String yearMonth = form.getStartDate();
			String yearStr = yearMonth.substring(0,4);
			String monthStr = yearMonth.substring(5,7);
			int year = Integer.parseInt(yearStr);
			int month = Integer.parseInt(monthStr);
			form.setYear(year);
			form.setMonth(month);
			String yearMonthTmp =  monthStr.length() < 2 ? yearStr + "-0" + monthStr : yearStr + "-" + monthStr;
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonthTmp , "" , ""));
		}else{
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		}
		
		List<OtsRemarkChartData> otsRemarkChartDataList = new ArrayList<OtsRemarkChartData>();
		otsRemarkChartDataList = otsDao.fetchDimensionRemarkDataList(form);
		
		//filter for the small quantity order for product
		if("Product".equals(form.getDimension())) {
			int totalProductOrderQty = 0;
			int totalProductNum = otsRemarkChartDataList.size();
			if(totalProductNum != 0) {
				for(OtsRemarkChartData otsRemarkChartData : otsRemarkChartDataList) {
					totalProductOrderQty += otsRemarkChartData.getTotal();
				}
				MathContext mc = new MathContext(5, RoundingMode.HALF_UP);
				BigDecimal averProductOrderQty = new BigDecimal(totalProductOrderQty)
											.divide(new BigDecimal(totalProductNum),mc)
											.multiply(new BigDecimal(0.1));
				
				for(int i=0; i<otsRemarkChartDataList.size(); i++) {
					OtsRemarkChartData otsRemarkChartData = otsRemarkChartDataList.get(i);
					if(new BigDecimal(otsRemarkChartData.getTotal()).compareTo(averProductOrderQty) == -1) {
						otsRemarkChartDataList.remove(otsRemarkChartData);
						--i;
					}
				}
			}
		}
		
		OtsRemarkChartDataComparator otsRemarkChartDataComparator = new OtsRemarkChartDataComparator();
		Collections.sort(otsRemarkChartDataList, otsRemarkChartDataComparator);
		
		return otsRemarkChartDataList;
	}
	
	public float calFaRate(int totalFa, int subFa) {
		BigDecimal faRate = new BigDecimal(0);
		MathContext mc = new MathContext(1, RoundingMode.HALF_DOWN);
		
		try{
			faRate = new BigDecimal(subFa).divide(new BigDecimal(totalFa),mc).multiply(new BigDecimal(100));
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return faRate.floatValue();
	}
	
	public float calFailRate(int totalFail, int subFail) {
		BigDecimal faRate = new BigDecimal(0);
		MathContext mc = new MathContext(1, RoundingMode.HALF_DOWN);
		
		try{
			faRate = new BigDecimal(subFail).divide(new BigDecimal(totalFail),mc).multiply(new BigDecimal(100));
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return faRate.floatValue();
	}
	
	public void setColumnLink(int weekNo,ColumnData cloumnData) {
		
		cloumnData.setLink("j-refreshRemark-");
	
	}
	
	public void setRemarkColumnLink(String dimensionInfo,ColumnData cloumnData,SearchOtsForm form) {
		
		if(ChartTypeEnum.CrossMonth.getTypeName().equals(form.getChartType()))
			cloumnData.setLink( "j-otsCrossMonthOrderDetailShow-"+dimensionInfo );
		else if(ChartTypeEnum.Dashboard.getTypeName().equals(form.getChartType()))
			cloumnData.setLink( "j-otsDashboardOrderDetailShow-"+dimensionInfo );
		else
			cloumnData.setLink( "j-showOTSOrderDetail-"+dimensionInfo );
		
	}
	
	private ColumnChartView setRemarkChartInfomation() {
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		columnChartView.getChartInfo().setFormatNumber("%");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setShowBorder("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setShowValues("0");
//		columnChartView.getChartInfo().setSnumberSuffix("%");
		columnChartView.getChartInfo().setNumbersuffix("%");
//		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");
		
		return columnChartView;
	}
	
	private ColumnChartView setOtsRemarkChartInfomation() {
		
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumbersuffix("%");
		columnChartView.getChartInfo().setNumdivlines("10");
		columnChartView.getChartInfo().setShowValues("1");
		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setShowBorder("0");
		
		/*columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		columnChartView.getChartInfo().setFormatNumber("%");*/
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		//columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");
		columnChartView.getChartInfo().setUseroundedges("0");
		
		return columnChartView;
	}
	
	private void setOverviewChartInfomation(MSColumnChartView mSColumnChartView) {
		mSColumnChartView.getChartInfo().setCaption("");
		mSColumnChartView.getChartInfo().setNumdivlines("9");
		mSColumnChartView.getChartInfo().setyAxisMinValue("0");
		mSColumnChartView.getChartInfo().setyAxisMaxValue("160");
		mSColumnChartView.getChartInfo().setsYAxisMinValue("0");
		mSColumnChartView.getChartInfo().setsYAxisMaxValue("100");
		mSColumnChartView.getChartInfo().setFormatNumberScale("0");
		mSColumnChartView.getChartInfo().setLegendIconScale("1");
		mSColumnChartView.getChartInfo().setShowBorder("1");
		mSColumnChartView.getChartInfo().setCanvasBorderThickness("1");
		mSColumnChartView.getChartInfo().setShowZeroPlaneValue("1");
		mSColumnChartView.getChartInfo().setCanvasBorderAlpha("60");
		mSColumnChartView.getChartInfo().setPlotSpacePercent("70");
		mSColumnChartView.getChartInfo().setBgalpha("0,0");
		mSColumnChartView.getChartInfo().setLegendPosition("");
		mSColumnChartView.getChartInfo().setShowBorder("0");
		mSColumnChartView.getChartInfo().setShowPlotBorder("0");
		mSColumnChartView.getChartInfo().setShowValues("0");
		mSColumnChartView.getChartInfo().setUseroundedges("0");
	}

	@Override
	public List<ScOverViewChartData> getOverviewOverall(SearchOtsForm form) {
		if(form.getStartDate().equalsIgnoreCase(form.getEndDate())){
			String yearMonth = form.getStartDate();
			String yearStr = yearMonth.substring(0,4);
			String monthStr = yearMonth.substring(5,7);
			int year = Integer.parseInt(yearStr);
			int month = Integer.parseInt(monthStr);
			form.setYear(year);
			form.setMonth(month);
			String yearMonthTmp =  monthStr.length() < 2 ? yearStr + "-0" + monthStr : yearStr + "-" + monthStr;
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonthTmp , "" , ""));
		}else{
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		}
		return otsDao.getOverviewOverall(form);
	}

	@Override
	public Map<String,Object> getOverviewOrderDetail(SearchOtsForm form) throws ParseException {
		//List<String> orderKeys; 
		/*if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			this.fetchOtsOverViewOrderDetailData(form);
		}
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			this.fetchOtsCrossMonthOrderDetailData(form);
		}
		else{
			this.fetchOtsDashboardOrderDetailData(form);
		}*/
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		}
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			totalCount = otsDao.getOverviewOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				grid = otsDao.getOverviewOrderDetail(form);
			}
		}
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			totalCount = otsDao.getCrossMonthOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				grid = otsDao.getCrossMonthOrderDetail(form);
			}
		}
		else{
			totalCount = otsDao.getDashboardOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				grid = otsDao.getDashboardOrderDetail(form);
			}
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	
	@Override
	public Map<String,Object> getOtsRemarkOrderDetail(
			SearchOtsForm form) throws ParseException {
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		}
		
		
		
		if(!StringUtil.isEmpty(form.getScStatus()) && "all".equalsIgnoreCase(form.getScStatus())){
			form.setShowAllRemarkOrder(true);
			form.setShowUnknownOrder(false);
			List<OtsRemarkChartData> otsRemarkChartDataList = new ArrayList<OtsRemarkChartData>();
			otsRemarkChartDataList = otsDao.fetchDimensionRemarkDataList(form);
			String scStatusKey ="";
			boolean hasFail =false;
			boolean hasToBeFail =false;
			for(OtsRemarkChartData otsRemarkChartData : otsRemarkChartDataList){
				if(!hasFail && otsRemarkChartData.getFail() > 0){
					scStatusKey = scStatusKey + "2," ;
					hasFail =true;
				}
				if(!hasToBeFail && otsRemarkChartData.getToBeFail() > 0){
					scStatusKey = scStatusKey + "4," ;
					hasToBeFail =true;
				}
				
				if(hasFail && hasToBeFail){
					break;
				}
				
			}
			form.setScStatus(scStatusKey.substring(0, scStatusKey.length() - 1));
		}
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		int unkownTotalCount = 0;
		if(form.isShowDashBoradCrossMonth()){
			totalCount = otsDao.getDashCrossRemarkOrderDetailCount(form);
		}else{
			totalCount = otsDao.getRemarkOrderDetailCount(form);
		}
		
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			if("Detractor".equalsIgnoreCase(form.getDimension()) && form.isShowAllRemarkOrder()){
				String subDimensionTmp = form.getSubDimension();
				form.setSubDimension("UNKNOWN");
				form.setShowUnknownOrder(true);
				unkownTotalCount = otsDao.getRemarkOrderDetailCount(form);
				totalCount = totalCount + unkownTotalCount ;
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				form.setSubDimension(subDimensionTmp);
				form.setOrderNumber(unkownTotalCount);
				form.setShowUnknownOrder(false);
			}
			if(form.isShowDashBoradCrossMonth()){
				grid = otsDao.getDashCrossRemarkOrderDetail(form);
			}else{
				grid = otsDao.getRemarkOrderDetail(form);
			}
			
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		map.put("unkownTotalCount", unkownTotalCount);
		return map;
	}
	
	private List<String> fetchOtsOverViewOrderDetailData(SearchOtsForm form) throws ParseException {
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		return otsDao.fetchOtsOverViewOrderDetailData(form);
	}
	
	private List<String> fetchOtsOverVieRemarkwOrderDetailData(SearchOtsForm form) throws ParseException {
		if(!form.isShowQuarterOverview()) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		return otsDao.fetchOtsOverViewRemarkOrderDetailData(form);
	}
	private List<String> fetchOtsCrossMonthOrderDetailData(SearchOtsForm form) throws ParseException {
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		return otsDao.fetchOtsCrossMonthOrderDetailData(form);
	}
	
	private List<String> fetchOtsDashboardOrderDetailData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> otsDashboardOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		int year = Integer.parseInt(form.getStartDate().substring(0,4));
		int month = Integer.parseInt(form.getStartDate().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		List<KeyNameObject> dimensionList = otsDao.fetchDimensions(form);
		for(KeyNameObject keyNameObject : dimensionList) {
			form.setSubDimensionKey(keyNameObject.getObjKey());
			otsDashboardOverviewMap.put(keyNameObject, otsDao.fetchOtsDashboardOverViewChartData(form));
		}
		
		return otsDao.fetchOtsDashboardOrderDetailData(form);
	}
	
	@Override
	public Map<String,Object> getOtsRemarkDetractorTableDetail(
			SearchOtsForm form) throws ParseException {
		/*List<String> orderKeys = otsDao.fetchOtsOrderKeysByDims(form);
		return scCommonService.getOrderDetail(orderKeys, form);*/
		
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		totalCount = otsDao.getDetractorOrderDetailCount(form);
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			grid = otsDao.getDetractorOrderDetail(form);
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	@Override
	public PieChartView getOtsDetractorMainPieChart(SearchOtsForm form) {
		form.setLevel(1);
		form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(form.getStartDate() + "-" +form.getEndDate() , "" , ""));
		List<PieDivider> detractorDividerList = otsDao.getDetractorMainDivider(form);
		Map<String, String> detractorMap = new HashMap<String, String>();

		for (PieDivider detractorDivider : detractorDividerList) {
			detractorMap.put(detractorDivider.getLevel1Name(), detractorDivider.getLevel1Num() + "");
		}

		String linkName = "showOtsDetractorSubPieAndData";
		
		return scCommonService.getDetractorMainPieChart(detractorMap, linkName);
	}

	@Override
	public PieChartView getOtsDetractorSubPieChart(SearchOtsForm form) {
		String parentType = form.getLevel1Detractor();
		form.setLevel(2);
		form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(form.getStartDate() + "-" +form.getEndDate() , "" , ""));
		List<PieDivider> detractorDividerList = otsDao.getDetractorMainDivider(form);
		
		Map<String, String> detractorMap = new HashMap<String, String>();

		for (PieDivider detractorDivider : detractorDividerList) {
			detractorMap.put(detractorDivider.getLevel2Name(), detractorDivider.getLevel2Num() + "");
		}
		String linkName = "showOtsDetractorTableBylevel2";
		return scCommonService.getDetractorSubPieChart(detractorMap, linkName, parentType);
	}

	@Override
	public List<TtvGridDetractorCodeView> getTtvGridDetractorCodeView(
			SearchOtsForm form) throws ParseException {
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		}
		
		if(!StringUtil.isEmpty(form.getScStatus()) && "all".equalsIgnoreCase(form.getScStatus())){
			form.setShowAllRemarkOrder(true);
			form.setShowUnknownOrder(false);
			List<OtsRemarkChartData> otsRemarkChartDataList = new ArrayList<OtsRemarkChartData>();
			otsRemarkChartDataList = otsDao.fetchDimensionRemarkDataList(form);
			String scStatusKey ="";
			boolean hasFail =false;
			boolean hasToBeFail =false;
			StringBuffer remarkDimensionKey = new StringBuffer();
			StringBuffer remarkSubDimension = new StringBuffer();
			for(OtsRemarkChartData otsRemarkChartData : otsRemarkChartDataList){
				remarkDimensionKey.append(otsRemarkChartData.getDimensionKey()).append(',');
				remarkSubDimension.append("'").append(otsRemarkChartData.getDimensionName()).append("'").append(',');
				if(!hasFail && otsRemarkChartData.getFail() > 0){
					scStatusKey = scStatusKey + "2," ;
					hasFail =true;
				}
				if(!hasToBeFail && otsRemarkChartData.getToBeFail() > 0){
					scStatusKey = scStatusKey + "4," ;
					hasToBeFail =true;
				}
				
			}
			form.setScStatus(scStatusKey.substring(0, scStatusKey.length() - 1));
			String remarkSubDimensionKeys = remarkDimensionKey.toString();
			String remarkSubDimensions = remarkSubDimension.toString();
			form.setRemarkSubDimensionKeys(remarkSubDimensionKeys.substring(0, remarkSubDimensionKeys.length() - 1));
			form.setRemarkSubDimensions(remarkSubDimensions.substring(0, remarkSubDimensions.length() - 1));
		}
		return otsDao.getAllOrderDetail(form);
	}

	@Override
	public List<TtvGridDetractorCodeView> getDetractorOrderDetail (	SearchOtsForm form) throws ParseException{
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		
		return otsDao.getAllDetractorOrder(form);
	}

}
