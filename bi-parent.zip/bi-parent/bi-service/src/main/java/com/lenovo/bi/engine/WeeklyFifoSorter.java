package com.lenovo.bi.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.CtoCvConfig;
import com.lenovo.bi.dto.Forecast;
import com.lenovo.bi.dto.MtmCvConfig;
import com.lenovo.bi.dto.MtmGeographyOdmCvConfig;
import com.lenovo.bi.dto.Order;
import com.lenovo.bi.dto.SingleUnitCvConfig;
import com.lenovo.bi.enumobj.ForecastComparisonTypeEnum;
import com.lenovo.bi.enumobj.PhaseEnum;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.ForecastData;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.model.OrderData;
import com.lenovo.bi.model.WeeklyComponentCommitmentOnOrderForecast;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.StringUtil;

abstract public class WeeklyFifoSorter {
	protected PhaseEnum phase;
	protected Date versionDate;
	protected Date targetDate;
	protected boolean includeBackOrder;

	protected ComponentQuota mtmComponentQuota;
	protected ComponentQuota ctoComponentQuota;

	protected MtmCvConfigMap mtmCvConfigMap;
	protected ProductKeyPmsWaveIdMap productKeyPmsWaveIdMap;

	protected TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	protected TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper;

	protected List<OrderData> orderDataList = new ArrayList<OrderData>();
	protected List<ForecastData> forecastDataList = new ArrayList<ForecastData>();
	
	private TTVPhase tTVPhase;;

	public WeeklyFifoSorter(PhaseEnum phase, Date targetDate, Date versionDate, boolean includeBacklog, ComponentQuota mtmComponentQuota,
			ComponentQuota ctoComponentQuota, TTVPhase tTVPhase) {
		this.phase = phase;
		this.versionDate = versionDate;
		this.targetDate = targetDate;
		this.includeBackOrder = includeBacklog;

		this.mtmComponentQuota = mtmComponentQuota;
		this.ctoComponentQuota = ctoComponentQuota;
		this.tTVPhase = tTVPhase;
	}

	public void run() {
		// Get orders in this week
		List<Order> allOrdersInWeek = getAllOrdersInWeek();
		List<NpiOrder> excludedOrdersInWeek = getExcludedOrdersInWeek();

		// Only NPI calculation exclude orders
		if (phase == PhaseEnum.NPI) {
			excludeOrders(allOrdersInWeek, excludedOrdersInWeek);
		}

		// Get back orders
		List<Order> backOrders = new ArrayList<Order>();
		List<OrderData> backOrderData = new ArrayList<OrderData>();

		if (includeBackOrder) {
			backOrders = getUnshippedOrdersBeforeWeek();
			List<NpiOrder> allExcludedOrders = getAllExcludedOrders();

			// Only NPI calculation exclude orders
			if (phase == PhaseEnum.NPI) {
				excludeOrders(backOrders, allExcludedOrders);
			}

			backOrderData = mapFromOrderToOrderData(backOrders);
		}

		// Query already sorts the results by order date and quantity
		// sortOrdersByOrderDateAndQuantity(allOrdersInWeek);

		// Back orders do not participate in labeling and demand analysis.
		labelOrdersAccordingToForecasts(allOrdersInWeek);
		deductOrdersFromForecasts();

		// Add all back orders to the beginning of orderDataList if needed.
		if (includeBackOrder) {
			orderDataList.addAll(0, backOrderData);
		}

		sortOrdersAndForecastsForFifo();
	}
	
	void labelOrdersAccordingToForecasts(List<Order> allOrdersInWeek) {
		// Label against week -8
		Map<BomNumberGeographyOdmKey, Forecast> forecastMap = retrieveMtmForecastsInWeek(-8);
		Map<ProductKeyGeographyOdmKey, CtoCvConfig> ctoForecastMap = retrieveCtoForecastsInWeek(-8);

		Date now = new Date();

		for (Order order : allOrdersInWeek) {
			boolean done = false;

			OrderData orderData = new OrderData();
			orderData.setRsdDate(order.getRsd());
			orderData.setFgDate(order.getFgDate());
			orderData.setShipDate(order.getShipDate());
			orderData.setBomNumber(order.getBomNumber());
			orderData.setPoNumber(order.getPoNumber());
			orderData.setPoItem(order.getPoItem());
			orderData.setPmsWaveId(order.getPmsWaveId());
			orderData.setProductKey(Integer.valueOf(order.getProductKey()));
			orderData.setQuantity(order.getQuantity());
			orderData.setAbnormalQuantity(order.getQuantity());
			orderData.setGeographyName(order.getGeographyName());
			orderData.setOdmName(order.getOdmName());
			orderData.setVersionDate(versionDate);
			orderData.setCreatedDate(now);
			orderData.setLastModifiedDate(now);
			orderData.setOrderDate(order.getOrderDate());
			orderData.setForNpi(phase == PhaseEnum.NPI);
			orderData.setTtvPhase(tTVPhase.name());

			// MTM forecast
			BomNumberGeographyOdmKey mtmKey = new BomNumberGeographyOdmKey(order.getBomNumber(), order.getGeographyName(), order.getOdmName());
			Forecast mtmForecast = forecastMap.get(mtmKey);

			// CTO forecast
			ProductKeyGeographyOdmKey ctoKey = new ProductKeyGeographyOdmKey(order.getProductKey(), order.getGeographyName(), order.getOdmName());
			CtoCvConfig ctoForecast = ctoForecastMap.get(ctoKey);

			if (mtmForecast == null) {
				// Set the order data to OFFSET for now
				orderData.setOrderLabel(ForecastComparisonTypeEnum.OFFSET);
				orderData.setNormalQuantity(0);
				orderData.setAbnormalQuantity(orderData.getQuantity());
			} else {
				int forecastQuantity = mtmForecast.getQuantity();
				if (forecastQuantity >= order.getQuantity()) {
					orderData.setOrderLabel(ForecastComparisonTypeEnum.DOWNSIDE);
					mtmForecast.setQuantity(forecastQuantity - order.getQuantity());
					forecastMap.put(mtmKey, mtmForecast);
					orderData.setNormalQuantity(orderData.getQuantity());
					orderData.setAbnormalQuantity(0);

					done = true;
				} else {
					// Set the order data to UPSIDE for now
					orderData.setOrderLabel(ForecastComparisonTypeEnum.UPSIDE);
					mtmForecast.setQuantity(0);
					forecastMap.put(mtmKey, mtmForecast);
					orderData.setNormalQuantity(forecastQuantity);
					orderData.setAbnormalQuantity(orderData.getQuantity() - forecastQuantity);
				}
			}

			if (!done) {
				if (ctoForecast == null) {
					// Do nothing
				} else {
					SingleUnitCvConfig singleUnitCvConfig = mtmCvConfigMap.getSingleUnitCvConfigOfMtm(order.getBomNumber());

					int abnormalQuantity = orderData.getAbnormalQuantity();
					MtmCvConfig mtmCvConfig = new MtmCvConfig(singleUnitCvConfig, abnormalQuantity);

					int maxMtmNumberOfUnits = ctoForecast.calculateMaxMtmNumberOfUnits(mtmCvConfig);

					if (maxMtmNumberOfUnits == 0) {
						// Do nothing
					} else {
						if (maxMtmNumberOfUnits >= abnormalQuantity) {
							orderData.setOrderLabel(ForecastComparisonTypeEnum.DOWNSIDE);
							orderData.setNormalQuantity(orderData.getQuantity());
							orderData.setAbnormalQuantity(0);
						} else {
							orderData.setOrderLabel(ForecastComparisonTypeEnum.UPSIDE);
							orderData.setNormalQuantity(orderData.getNormalQuantity() + maxMtmNumberOfUnits);
							orderData.setAbnormalQuantity(abnormalQuantity - maxMtmNumberOfUnits);
						}

						// Deduct the maxMtmNumberOfUnits and the corresponding
						// CVs from ctoForecast
						ctoForecast.deductMtmUnits(singleUnitCvConfig, maxMtmNumberOfUnits);
					}

				}
			}

			orderDataList.add(orderData);
		}
	}

	abstract void deductOrdersFromForecasts();

	abstract List<NpiOrder> getExcludedOrdersInWeek();

	abstract List<NpiOrder> getAllExcludedOrders();
	
	abstract List<Order> getAllOrdersInWeek();
	
	abstract List<Order> getUnshippedOrdersBeforeWeek();

	private List<OrderData> mapFromOrderToOrderData(List<Order> allOrdersInWeek) {
		List<OrderData> list = new ArrayList<OrderData>();
		Date now = new Date();

		for (Order order : allOrdersInWeek) {
			OrderData orderData = new OrderData();
			orderData.setBomNumber(order.getBomNumber());
			orderData.setPoNumber(order.getPoNumber());
			orderData.setPoItem(order.getPoItem());
			orderData.setOrderDate(order.getOrderDate());
			orderData.setRsdDate(order.getRsd());
			orderData.setFgDate(order.getFgDate());
			orderData.setShipDate(order.getShipDate());
			orderData.setPmsWaveId(order.getPmsWaveId());
			orderData.setProductKey(Integer.valueOf(order.getProductKey()));
			orderData.setOrderLabel(order.getForecastComparison());
			orderData.setQuantity(order.getQuantity());
			orderData.setGeographyName(order.getGeographyName());
			orderData.setOdmName(order.getOdmName());
			orderData.setForNpi(phase == PhaseEnum.NPI);
			orderData.setVersionDate(versionDate);
			orderData.setCreatedDate(now);
			orderData.setLastModifiedDate(now);
			orderData.setOrderDate(order.getOrderDate());
			orderData.setGeographyName(order.getGeographyName());
			orderData.setTtvPhase(tTVPhase.name());
			list.add(orderData);
		}

		return list;
	}

	private Map<BomNumberGeographyOdmKey, Forecast> retrieveMtmForecastsInWeek(int weekNumber) {
		Map<BomNumberGeographyOdmKey, Forecast> forecastMap = new HashMap<BomNumberGeographyOdmKey, Forecast>();

		List<Forecast> forecastsInWeek = retrieveMtmForecastListInWeek(weekNumber);

		for (Forecast forecast : forecastsInWeek) {
			// modified by Nicolas on July 28 2014
			if (!StringUtil.isEmpty(forecast.getBomNumber()) && !StringUtil.isEmpty(forecast.getGeographyName()) && !StringUtil.isEmpty(forecast.getOdmName())) {
				BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(forecast.getBomNumber(), forecast.getGeographyName(), forecast.getOdmName());
				forecastMap.put(key, forecast);
			}
		}

		return forecastMap;
	}

	private Map<ProductKeyGeographyOdmKey, CtoCvConfig> retrieveCtoForecastsInWeek(int weekNumber) {
		Map<ProductKeyGeographyOdmKey, CtoCvConfig> forecastMap = new HashMap<ProductKeyGeographyOdmKey, CtoCvConfig>();

		List<CtoCvConfig> forecastsInWeek = retrieveCtoForecastListInWeek(weekNumber);

		for (CtoCvConfig forecast : forecastsInWeek) {
			ProductKeyGeographyOdmKey key = new ProductKeyGeographyOdmKey(forecast.getProductKey(), forecast.getGeographyName(), forecast.getOdmName());
			forecastMap.put(key, forecast);
		}

		return forecastMap;
	}

	private List<Forecast> retrieveMtmForecastListInWeek(int weekNumber) {
		List<Forecast> forecasts = ttvOutlookServiceDwHelper.getAllMtmForecastsInWeekForVersionWeek(targetDate, versionDate, weekNumber);
		for (Forecast forecast : forecasts) {
			if (productKeyPmsWaveIdMap.getPmsWaveIdFromProductKey(forecast.getProductKey()) != null)// add
																									// by
																									// Nicolas
																									// on
																									// Jul
																									// 2,2014
				forecast.setPmsWaveId(productKeyPmsWaveIdMap.getPmsWaveIdFromProductKey(forecast.getProductKey()));
		}

		return forecasts;
	}

	private List<CtoCvConfig> retrieveCtoForecastListInWeek(int weekNumber) {
		return ttvOutlookServiceDwHelper.getAllCtoForecastsInWeekForVersionDate(targetDate, versionDate, weekNumber);
	}

	private void sortOrdersAndForecastsForFifo() {
		// Sort orders
		// First sort by order date and quantity
		Collections.sort(orderDataList, new OrderDataOrderDateQuantityComparator());

		// Pick out orders that have box-level commit, upside orders, and offset
		// orders
		List<OrderData> boxCommittedOrderDataList = new ArrayList<OrderData>();
		List<OrderData> regularOrderDataList = new ArrayList<OrderData>();
		List<OrderData> upsideOrderDataList = new ArrayList<OrderData>();
		List<OrderData> offsetOrderDataList = new ArrayList<OrderData>();

		for (OrderData orderData : orderDataList) {
			if (hasBoxLevelCommit(orderData)) {
				boxCommittedOrderDataList.add(orderData);
			} else {
				switch (orderData.getOrderLabel()) {
				case UPSIDE:
					upsideOrderDataList.add(orderData);
					break;
				case OFFSET:
					offsetOrderDataList.add(orderData);
					break;
				default:
					regularOrderDataList.add(orderData);
					break;
				}
			}
		}

		// Recreate the list with new ordering
		orderDataList = new ArrayList<OrderData>();
		orderDataList.addAll(boxCommittedOrderDataList);
		orderDataList.addAll(regularOrderDataList);
		orderDataList.addAll(upsideOrderDataList);
		orderDataList.addAll(offsetOrderDataList);

		// Sort forecasts
		// First sort by target date and quantity
		Collections.sort(forecastDataList, new ForecastDataDateQuantityComparator());

		// Pick out forecasts that have box-level commits
		List<ForecastData> boxCommittedForecastDataList = new ArrayList<ForecastData>();
		List<ForecastData> regularForecastDataList = new ArrayList<ForecastData>();
		List<ForecastData> upsideForecastDataList = new ArrayList<ForecastData>();
		List<ForecastData> offsetForecastDataList = new ArrayList<ForecastData>();

		for (ForecastData forecastData : forecastDataList) {
			if (hasBoxLevelCommit(forecastData)) {
				boxCommittedForecastDataList.add(forecastData);
			} else {
				switch (forecastData.getOrderLabel()) {
				case UPSIDE:
					upsideForecastDataList.add(forecastData);
					break;
				case OFFSET:
					offsetForecastDataList.add(forecastData);
					break;
				default:
					regularForecastDataList.add(forecastData);
					break;
				}
			}
		}

		// Recreate the list with new ordering
		forecastDataList = new ArrayList<ForecastData>();
		forecastDataList.addAll(boxCommittedForecastDataList);
		forecastDataList.addAll(regularForecastDataList);
		forecastDataList.addAll(upsideForecastDataList);
		forecastDataList.addAll(offsetForecastDataList);
	}

	/**
	 * Return true if the full quantity required by the order is available as
	 * box-level commit. This method has side-effect when there is box-level
	 * commit, i.e., the CVs are deducted from quota.
	 * 
	 * @param orderData
	 * @return
	 */
	private boolean hasBoxLevelCommit(OrderData orderData) {
		int orderQuantity = orderData.getQuantity();

		MtmGeographyOdmCvConfig mtmCvConfig = new MtmGeographyOdmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(orderData.getBomNumber()), orderQuantity,
				orderData.getGeographyName(), orderData.getOdmName());
		int commitQuantity = mtmComponentQuota.calculateMaxMtmNumberOfUnits(mtmCvConfig);

		if (commitQuantity >= orderQuantity) { // Fully fulfilled
			orderData.setMaterialCommit(orderQuantity);
			orderData.setMaterialShortage(0);
			mtmComponentQuota.deductMtmUnits(mtmCvConfig);

			// Record all materials that are fulfilled
			Date now = new Date();

			MtmCvConfig config = new MtmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(orderData.getBomNumber()), orderQuantity);
			List<WeeklyComponentCommitmentOnOrderForecast> commitments = new ArrayList<WeeklyComponentCommitmentOnOrderForecast>();
			for (Integer cvKey : config.getAllCvs()) {
				WeeklyComponentCommitmentOnOrderForecast commitment = new WeeklyComponentCommitmentOnOrderForecast();
				commitment.setPoNumber(orderData.getPoNumber());
				commitment.setPoItem(orderData.getPoItem());
				commitment.setGlobalCvKey(cvKey);
				commitment.setDemand(config.getQuantity(cvKey));
				commitment.setCommitment(config.getQuantity(cvKey));
				commitment.setDelta(0);
				commitment.setProductKey(Integer.valueOf(orderData.getProductKey()));
				commitment.setBomNumber(orderData.getBomNumber());
				commitment.setForNpi(phase == PhaseEnum.NPI);
				commitment.setTargetDate(targetDate);
				commitment.setVersionDate(versionDate);
				commitment.setCreatedDate(now);
				commitment.setLastModifiedDate(now);
				commitment.setTtvPhase(tTVPhase.name());
				commitment.setOrderDate(orderData.getOrderDate());
				commitment.setOrderQuantity(orderData.getQuantity());
				commitment.setRegion(orderData.getGeographyName());
				commitment.setRsdDate(orderData.getRsdDate());

				commitments.add(commitment);
			}

			//ttvOutlookServiceBiHelper.addWeeklyComponentCommitmentOnOrderForecast(commitments);

			return true;
		} else { // Not fully fulfilled
			return false;
		}
	}

	/**
	 * Return true if the full quantity required by the forecast is available as
	 * box-level commit. This method has side-effect when there is box-level
	 * commit, i.e., the CVs are deducted from quota.
	 * 
	 * @param forecastData
	 * @return
	 */
	private boolean hasBoxLevelCommit(ForecastData forecastData) {
		Date now = new Date();

		if (!forecastData.getCtoForecast()) { // MTM
			int forecastQuantity = forecastData.getQuantity();

			MtmGeographyOdmCvConfig mtmCvConfig = new MtmGeographyOdmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(forecastData.getBomNumber()),
					forecastQuantity, forecastData.getGeographyName(), forecastData.getOdmName());
			int commitQuantity = mtmComponentQuota.calculateMaxMtmNumberOfUnits(mtmCvConfig);

			if (commitQuantity >= forecastQuantity) { // Fully fulfilled
				forecastData.setMaterialCommit(forecastQuantity);
				forecastData.setMaterialShortage(0);
				mtmComponentQuota.deductMtmUnits(mtmCvConfig);

				// Record all materials that are fulfilled
				MtmCvConfig config = new MtmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(forecastData.getBomNumber()), forecastQuantity);
				List<WeeklyComponentCommitmentOnOrderForecast> commitments = new ArrayList<WeeklyComponentCommitmentOnOrderForecast>();
				for (Integer cvKey : config.getAllCvs()) {
					WeeklyComponentCommitmentOnOrderForecast commitment = new WeeklyComponentCommitmentOnOrderForecast();
					commitment.setGlobalCvKey(cvKey);
					commitment.setDemand(config.getQuantity(cvKey));
					commitment.setCommitment(config.getQuantity(cvKey));
					commitment.setDelta(0);
					commitment.setProductKey(Integer.valueOf(forecastData.getProductKey()));
					commitment.setBomNumber(forecastData.getBomNumber());
					commitment.setForNpi(phase == PhaseEnum.NPI);
					commitment.setTargetDate(targetDate);
					commitment.setVersionDate(versionDate);
					commitment.setCreatedDate(now);
					commitment.setLastModifiedDate(now);
					commitment.setTtvPhase(tTVPhase.name());

					commitments.add(commitment);
				}

				//ttvOutlookServiceBiHelper.addWeeklyComponentCommitmentOnOrderForecast(commitments);

				return true;
			} else { // Not fully fulfilled
				return false;
			}
		} else { // CTO
			CtoCvConfig ctoCvConfig = forecastData.getCtoCvConfig();

			if (ctoComponentQuota.canFullfillCto(ctoCvConfig)) { // Fully
																	// fulfilled
				forecastData.setMaterialCommit(ctoCvConfig.getNumberOfUnits());
				forecastData.setMaterialShortage(0);
				ctoComponentQuota.deductWholeCto(ctoCvConfig);

				// Record all materials that are fulfilled
				List<WeeklyComponentCommitmentOnOrderForecast> commitments = new ArrayList<WeeklyComponentCommitmentOnOrderForecast>();

				for (Integer cvKey : ctoCvConfig.getAllCvs()) {
					WeeklyComponentCommitmentOnOrderForecast commitment = new WeeklyComponentCommitmentOnOrderForecast();
					commitment.setGlobalCvKey(cvKey);
					commitment.setDemand(ctoCvConfig.getQuantity(cvKey));
					commitment.setCommitment(ctoCvConfig.getQuantity(cvKey));
					commitment.setDelta(0);
					commitment.setProductKey(Integer.valueOf(forecastData.getProductKey()));
					commitment.setBomNumber(forecastData.getBomNumber());
					commitment.setForNpi(phase == PhaseEnum.NPI);
					commitment.setTargetDate(targetDate);
					commitment.setVersionDate(versionDate);
					commitment.setCreatedDate(now);
					commitment.setLastModifiedDate(now);

					commitments.add(commitment);
				}

				//ttvOutlookServiceBiHelper.addWeeklyComponentCommitmentOnOrderForecast(commitments);

				return true;
			} else { // Not fully fulfilled
				return false;
			}
		}
	}

	protected Map<BomNumberGeographyOdmKey, ForecastData> labelMtmForecastsAccordingToForecasts() {
		int week = 0;
		List<Forecast> forecastListInWeek0 = retrieveMtmForecastListInWeek(week);
		if(forecastListInWeek0 == null || forecastListInWeek0.isEmpty()){
			week = week - 1;
			forecastListInWeek0 = retrieveMtmForecastListInWeek(week);
		}

		// MTM forecasts compare with only MTM forecasts
		Map<BomNumberGeographyOdmKey, Forecast> forecastMapInWeekMinus8 = retrieveMtmForecastsInWeek(week-8);
		Map<BomNumberGeographyOdmKey, Forecast> forecastMapInWeekMinus1 = retrieveMtmForecastsInWeek(week-1);

		Map<BomNumberGeographyOdmKey, ForecastData> forecastDataMap = new HashMap<BomNumberGeographyOdmKey, ForecastData>();

		Date now = new Date();

		for (Forecast forecast : forecastListInWeek0) {
			ForecastData forecastData = new ForecastData();

			if (forecast.getPmsWaveId() != null) {// add by Nicolas on July
													// 2,2014
				forecastData.setPmsWaveId(forecast.getPmsWaveId());
				forecastData.setProductKey(Integer.valueOf(forecast.getProductKey()));
				forecastData.setBomNumber(forecast.getBomNumber());
				forecastData.setQuantity(forecast.getQuantity());
				forecastData.setGeographyName(forecast.getGeographyName());
				forecastData.setOdmName(forecast.getOdmName());
				forecastData.setForNpi(phase == PhaseEnum.NPI);
				forecastData.setCtoForecast(false);
				forecastData.setVersionDate(versionDate);
				forecastData.setTargetDate(targetDate);
				forecastData.setCreatedDate(now);
				forecastData.setLastModifiedDate(now);
				forecastData.setTtvPhase(tTVPhase.name());
				
				BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(forecast.getBomNumber(), forecast.getGeographyName(), forecast.getOdmName());

				if (forecastMapInWeekMinus1.get(key) == null) {
					// Offset compares with -1 version
					forecastData.setOrderLabel(ForecastComparisonTypeEnum.OFFSET);
					forecastData.setNormalQuantity(0);
					forecastData.setAbnormalQuantity(forecast.getQuantity());
				} else {
					// Up/downside compares with -8 version
					Forecast forecastMinus8 = forecastMapInWeekMinus8.get(key);
					if (forecastMinus8 != null) {
						if (forecastMinus8.getQuantity() >= forecast.getQuantity()) {
							forecastData.setOrderLabel(ForecastComparisonTypeEnum.DOWNSIDE);
							forecastData.setNormalQuantity(forecast.getQuantity());
							forecastData.setAbnormalQuantity(0);
						} else {
							forecastData.setOrderLabel(ForecastComparisonTypeEnum.UPSIDE);
							forecastData.setNormalQuantity(forecastMinus8.getQuantity());
							forecastData.setAbnormalQuantity(forecast.getQuantity() - forecastMinus8.getQuantity());
						}
					} else {
						// It is still offset
						forecastData.setOrderLabel(ForecastComparisonTypeEnum.OFFSET);
						forecastData.setNormalQuantity(0);
						forecastData.setAbnormalQuantity(forecast.getQuantity());
					}
				}

				forecastDataMap.put(key, forecastData);
			}
		}

		return forecastDataMap;
	}

	protected Map<ProductKeyGeographyOdmKey, ForecastData> labelCtoForecastsAccordingToForecasts() {
		List<CtoCvConfig> ctoForecastListInWeek0 = retrieveCtoForecastListInWeek(0);

		// CTO forecasts only compare with CTO forecasts
		Map<ProductKeyGeographyOdmKey, CtoCvConfig> ctoForecastsInWeekMinus8 = retrieveCtoForecastsInWeek(-8);
		Map<ProductKeyGeographyOdmKey, CtoCvConfig> ctoForecastsInWeekMinus1 = retrieveCtoForecastsInWeek(-1);

		Map<ProductKeyGeographyOdmKey, ForecastData> ctoForecastDataMap = new HashMap<ProductKeyGeographyOdmKey, ForecastData>();

		Date now = new Date();

		for (CtoCvConfig ctoCvConfig : ctoForecastListInWeek0) {
			ForecastData forecastData = new ForecastData();
			if (productKeyPmsWaveIdMap.getPmsWaveIdFromProductKey(ctoCvConfig.getProductKey()) != null) {// add
																											// by
																											// Nicolas
																											// on
																											// Jul
																											// 2,2014
				forecastData.setCtoCvConfig(ctoCvConfig);
				forecastData.setPmsWaveId(productKeyPmsWaveIdMap.getPmsWaveIdFromProductKey(ctoCvConfig.getProductKey()));
				forecastData.setProductKey(Integer.valueOf(ctoCvConfig.getProductKey()));
				forecastData.setBomNumber(ctoCvConfig.getBomNumber());
				forecastData.setQuantity(ctoCvConfig.getNumberOfUnits());
				forecastData.setGeographyName(ctoCvConfig.getGeographyName());
				forecastData.setOdmName(ctoCvConfig.getOdmName());
				forecastData.setForNpi(phase == PhaseEnum.NPI);
				forecastData.setCtoForecast(true);
				forecastData.setVersionDate(versionDate);
				forecastData.setTargetDate(targetDate);
				forecastData.setCreatedDate(now);
				forecastData.setLastModifiedDate(now);
				forecastData.setTtvPhase(tTVPhase.name());
				
				ProductKeyGeographyOdmKey key = new ProductKeyGeographyOdmKey(ctoCvConfig.getProductKey(), ctoCvConfig.getGeographyName(),
						ctoCvConfig.getOdmName());

				if (ctoForecastsInWeekMinus1.get(key) == null) {
					// Offset compares with -1 version
					forecastData.setOrderLabel(ForecastComparisonTypeEnum.OFFSET);
					forecastData.setNormalQuantity(0);
					forecastData.setAbnormalQuantity(ctoCvConfig.getNumberOfUnits());
				} else {
					// Up/downside compares with -8 version
					CtoCvConfig forecastMinus8 = ctoForecastsInWeekMinus8.get(key);
					if (forecastMinus8 != null) {
						if (forecastMinus8.getNumberOfUnits() >= ctoCvConfig.getNumberOfUnits()) {
							forecastData.setOrderLabel(ForecastComparisonTypeEnum.DOWNSIDE);
							forecastData.setNormalQuantity(ctoCvConfig.getNumberOfUnits());
							forecastData.setAbnormalQuantity(0);
						} else {
							forecastData.setOrderLabel(ForecastComparisonTypeEnum.UPSIDE);
							forecastData.setNormalQuantity(forecastMinus8.getNumberOfUnits());
							forecastData.setAbnormalQuantity(ctoCvConfig.getNumberOfUnits() - forecastMinus8.getNumberOfUnits());
						}
					} else {
						// It is still offset
						forecastData.setOrderLabel(ForecastComparisonTypeEnum.OFFSET);
						forecastData.setNormalQuantity(0);
						forecastData.setAbnormalQuantity(ctoCvConfig.getNumberOfUnits());
					}
				}

				ctoForecastDataMap.put(key, forecastData);
			}

		}

		return ctoForecastDataMap;
	}

	private List<Order> excludeOrders(List<Order> inputOrders, List<NpiOrder> excludedOrders) {
		Map<String, String> excludedOrderMap = new HashMap<String, String>();

		for (NpiOrder excludedOrder : excludedOrders) {
			String identifier = excludedOrder.getOrderUniqueIdentifier();
			excludedOrderMap.put(identifier, identifier);
		}

		Iterator<Order> iterator = inputOrders.iterator();

		while (iterator.hasNext()) {
			Order order = iterator.next();

			if (excludedOrderMap.get(order.getOrderId()) != null) {
				iterator.remove();
			}
		}

		return inputOrders;
	}

	public TTVOutlookServiceDwHelper getTtvOutlookServiceDwHelper() {
		return ttvOutlookServiceDwHelper;
	}

	public void setTtvOutlookServiceDwHelper(TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper) {
		this.ttvOutlookServiceDwHelper = ttvOutlookServiceDwHelper;
	}

	public void setMtmCvConfigMap(MtmCvConfigMap mtmCvConfigMap) {
		this.mtmCvConfigMap = mtmCvConfigMap;
	}

	public void setProductKeyPmsWaveIdMap(ProductKeyPmsWaveIdMap productKeyPmsWaveIdMap) {
		this.productKeyPmsWaveIdMap = productKeyPmsWaveIdMap;
	}

	public TTVOutlookServiceBiHelper getTtvOutlookServiceBiHelper() {
		return ttvOutlookServiceBiHelper;
	}

	public void setTtvOutlookServiceBiHelper(TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper) {
		this.ttvOutlookServiceBiHelper = ttvOutlookServiceBiHelper;
	}

	public List<OrderData> getOrderDataList() {
		return orderDataList;
	}

	public List<ForecastData> getForecastDataList() {
		return forecastDataList;
	}

}
