package com.lenovo.bi.dao.common.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BooleanType;
import org.hibernate.type.DateType;
import org.hibernate.type.FloatType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.common.OdmCapacityDao;
import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.OdmCapacityPlan;
import com.lenovo.bi.dto.OdmCapacityPlanDetail;
import com.lenovo.bi.dto.OdmCommitDto;
import com.lenovo.bi.dto.TdmsDefect;
import com.lenovo.bi.dto.TdmsDefectDetail;

@Repository
@Transactional("dw")
public class OdmCapacityDaoImpl extends HibernateBaseDaoImplDw<Object> implements OdmCapacityDao {
	/**
	 * 
	 * @param pmsWaveId
	 * @param processDate Target date
	 * @return
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<OdmCapacityPlan> getOdmNpiCapacityPlanForTargetDate(int pmsWaveId, Date targetDate, Date versionDate) {
		// ENGINE
		StringBuffer sql = new StringBuffer("select c.UPH as unitsPerHour, c.HrsPerDay as hoursPerDay, c.DaysPerWeek as daysPerWeek, ")
			.append("c.FPY as fpy, c.RPY as rpy, c.isRpyIncluded as useRpy,  t1.FullDateAlternateKey as targetDate, ")
			.append("(p.LineName + '|' + p.CrewName) as odmCapacityPlanId ")
			.append("from FactWeeklySummaryofODMCapacity c, DimNPICapacityPlan p, DimNPIWave w, DimTime t1, DimTime t2 ")
			.append("where c.NPICapacityPlanKey = p.NPICapacityPlanKey ")
			.append("and p.NPIWaveKey = w.NPIWaveKey ")			
			.append("and c.TargetDateKey = t1.TimeKey ")
			.append("and c.VersionDateKey = t2.TimeKey ")
			.append("and w.PMSWaveIDAlternateKey = ? ")
			.append("and datediff(day, t1.FullDateAlternateKey, ?) = 0 ")
			.append("and datediff(day, t2.FullDateAlternateKey, ?) = 0 ");
		
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(OdmCapacityPlan.class));
		query.setParameter(0, pmsWaveId);
		query.setParameter(1, targetDate);
		query.setParameter(2, versionDate);
		List<OdmCapacityPlan> list = query.list();
		return list;
	}
	
	/**
	 * 
	 * @param pmsWaveId
	 * @param processDate Target date
	 * @return All open defects and limitations that are not OOB
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<TdmsDefect> getTdmsDefectsForTargetDate(int pmsWaveId, Date targetDate, Date versionDate) {
		// ENGINE
		StringBuffer sql = new StringBuffer("select d.FPYImpact as fpyImpact, d.FailRate as failRate, dd.TDMSDefectIDAlternateKey as tdmsDefectId, ")
			.append("t1.FullDateAlternateKey as targetDate ")
			.append("from FactWeeklySummaryofDefect d, DimDefect dd, DimNPIWave w, DimNPIProject p, DimTime t1, DimTime t2 ")
			.append("where d.ProductKey = p.ProductKey ")
			.append("and p.NPIProjectKey = w.NPIProjectKey ")
			.append("and d.DefectKey = dd.DefectKey ")
			.append("and d.TargetDateKey = t1.TimeKey ")
			.append("and d.VersionDateKey = t2.TimeKey ")
			.append("and d.IsOOBDefect = 0 ")
			.append("and w.PMSWaveIDAlternateKey = ? ")
			.append("and datediff(day, t1.FullDateAlternateKey, ?) = 0 ")
			.append("and datediff(day, t2.FullDateAlternateKey, ?) = 0 ");
		
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(TdmsDefect.class));
		query.setParameter(0, pmsWaveId);
		query.setParameter(1, targetDate);
		query.setParameter(2, versionDate);
		List<TdmsDefect> list = query.list();
		return list;
	}

	@Override
	public List<OdmCapacityPlanDetail> getDetailCapacityPlanByTargetDate(
			int pmsWaveId, Date targetDate, Date versionDate) {
		StringBuffer sql = new StringBuffer(
				"select c.UPH as unitsPerHour, c.HrsPerDay as hoursPerDay, c.DaysPerWeek as daysPerWeek, ")
				.append("c.FPY as fpy, c.RPY as rpy, c.isRpyIncluded as useRpy,  t1.FullDateAlternateKey as targetDate, ")
				.append("(p.LineName + '|' + p.CrewName) as odmNpiCapacityPlanId, o.ODMEnglishName as odmName, p.LineName as line, p.CrewName as crew ")
				.append("from FactWeeklySummaryofODMCapacity c, DimNPICapacityPlan p, DimNPIWave w, DimTime t1, DimTime t2, DimODM o ")
				.append("where c.NPICapacityPlanKey = p.NPICapacityPlanKey ")
				.append("and p.NPIWaveKey = w.NPIWaveKey ")
				.append("and o.ODMKey = p.ODMKey ")
				.append("and w.PMSWaveIDAlternateKey = :waveId ")
				.append("and c.TargetDateKey = t1.TimeKey ")
				.append("and c.VersionDateKey = t2.TimeKey ")
				.append("and datediff(day, t1.FullDateAlternateKey, :targetDate) = 0 ")
				.append("and datediff(day, t2.FullDateAlternateKey, :versionDate) = 0 ");

		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("unitsPerHour", IntegerType.INSTANCE)
				.addScalar("hoursPerDay", IntegerType.INSTANCE)
				.addScalar("daysPerWeek", IntegerType.INSTANCE)
				.addScalar("fpy", FloatType.INSTANCE)
				.addScalar("rpy", FloatType.INSTANCE)
				.addScalar("useRpy", BooleanType.INSTANCE)
				.addScalar("targetDate", DateType.INSTANCE)
				.addScalar("odmNpiCapacityPlanId", StringType.INSTANCE)
				.addScalar("odmName", StringType.INSTANCE)
				.addScalar("line", StringType.INSTANCE)
				.addScalar("crew", StringType.INSTANCE)
				.setResultTransformer(
						Transformers.aliasToBean(OdmCapacityPlanDetail.class));
		query.setInteger("waveId", pmsWaveId);
		query.setDate("targetDate", targetDate);
		query.setDate("versionDate", versionDate);
		@SuppressWarnings("unchecked")
		List<OdmCapacityPlanDetail> list = query.list();
		return list;
	}

	@Override
	public List<OdmCapacityPlanDetail> getOdmItems(int pmsWaveId,
			String versionDate, String startDate, String endDate) {
		StringBuffer sql = new StringBuffer(
				"select c.UPH as unitsPerHour, c.HrsPerDay as hoursPerDay, c.DaysPerWeek as daysPerWeek, ")
				.append("c.FPY as fpy, c.RPY as rpy, c.isRpyIncluded as useRpy,  t1.FullDateAlternateKey as targetDate, ")
				.append("(p.LineName + '|' + p.CrewName) as odmNpiCapacityPlanId, o.ODMEnglishName as odmName, p.LineName as line, p.CrewName as crew ")
				.append("from FactWeeklySummaryofODMCapacity c, DimNPICapacityPlan p, DimNPIWave w, DimTime t1, DimTime t2, DimODM o ")
				.append("where c.NPICapacityPlanKey = p.NPICapacityPlanKey ")
				.append("and p.NPIWaveKey = w.NPIWaveKey ")
				.append("and o.ODMKey = p.ODMKey ")
				//.append("and w.PMSWaveIDAlternateKey = :waveId ")
				.append("and c.TargetDateKey = t1.TimeKey ")
				.append("and c.VersionDateKey = t2.TimeKey ")
				.append("and ( datediff(day, t1.FullDateAlternateKey, :startDate ) <= 0 and datediff(day, t1.FullDateAlternateKey, :endDate )>=0 ) ")
				.append("and datediff(day, t2.FullDateAlternateKey, :versionDate ) = 0 ");

		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("unitsPerHour", IntegerType.INSTANCE)
				.addScalar("hoursPerDay", IntegerType.INSTANCE)
				.addScalar("daysPerWeek", IntegerType.INSTANCE)
				.addScalar("fpy", FloatType.INSTANCE)
				.addScalar("rpy", FloatType.INSTANCE)
				.addScalar("useRpy", BooleanType.INSTANCE)
				.addScalar("targetDate", DateType.INSTANCE)
				.addScalar("odmNpiCapacityPlanId", StringType.INSTANCE)
				.addScalar("odmName", StringType.INSTANCE)
				.addScalar("line", StringType.INSTANCE)
				.addScalar("crew", StringType.INSTANCE)
				.setResultTransformer(
						Transformers.aliasToBean(OdmCapacityPlanDetail.class));
		//query.setInteger("waveId", pmsWaveId);
		query.setString("startDate", startDate);
		query.setString("endDate",  endDate);
		query.setString("versionDate", versionDate);
		@SuppressWarnings("unchecked")
		List<OdmCapacityPlanDetail> list = query.list();
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TdmsDefectDetail> getDefectItems(String pmsWaveId,
			Date versionDate) {
		StringBuffer sb = new StringBuffer("select * from( select ")
		.append(" ROW_NUMBER()OVER(partition by dd.TDMSDefectIDAlternateKey Order by fd.TargetDateKey DESC)as rn,")
		.append("dd.TDMSDefectIDAlternateKey as tdmsDefectId,")
		.append("dd.TDMSDefectIDAlternateKey as defectNo,")
		.append("dd.category as category,")
		.append("dd.DefectSubject as description,")
		.append("isnull(fd.FailRate*100,null) as failRate,")
		.append("isnull(fd.FPYImpact*100,null) as fpyImpact,")
		.append("dd.DefectOwner as owner,")
		.append("t2.FullDateAlternateKey as targetDate,")
		.append("t.FullDateAlternateKey as beginDate,")
		.append("'Open' as status ")
		.append("from FactWeeklySummaryofDefect fd ")
		.append("inner join DimDefect dd on fd.DefectKey = dd.DefectKey ")
		.append("inner join DimTime t on fd.TargetDateKey = t.TimeKey ")
		.append("left join DimTime t2 on t2.TimeKey = dd.EstimatedResolveDateKey ")
		.append("inner join DimProduct pd on pd.ProductKey = fd.ProductKey ")
		.append("inner join DimNPIProject p on p.ProductKey = pd.ProductKey ")
		.append("inner join DimNPIWave w on w.NPIProjectKey = p.NPIProjectKey ")
		.append("inner join DimTime dt on fd.VersionDateKey = dt.TimeKey ")
		.append("where  ")
		.append("dd.IsCurrent = 1 ")
		.append("and p.IsCurrent = 1 ")
		.append("and w.IsCurrent = 1 ")
		.append("and dd.IsOpen = 1 ")
		.append("and w.PMSWaveIDAlternateKey = :waveId ")
		.append("and datediff(day, dt.FullDateAlternateKey, :versionDate) = 0 )t ")
		.append("where rn=1");
		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("tdmsDefectId", IntegerType.INSTANCE)
				.addScalar("defectNo", StringType.INSTANCE)
				.addScalar("category", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("failRate", FloatType.INSTANCE)
				.addScalar("fpyImpact", FloatType.INSTANCE)
				.addScalar("owner", StringType.INSTANCE)
				.addScalar("targetDate", DateType.INSTANCE)
				.addScalar("beginDate", DateType.INSTANCE)
				.addScalar("status", StringType.INSTANCE)
				.setResultTransformer(
						Transformers.aliasToBean(TdmsDefectDetail.class));
		
		query.setParameter("waveId", pmsWaveId);
		query.setParameter("versionDate", versionDate);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	//public List<OdmCommitDto> getOdmCommit(Date versionDate, Date targetDate, Date dnsVersionDate) {
	public List<OdmCommitDto> getOdmCommit(Date versionDate, Integer pmsWaveId, Date dnsVersionDate) {
		StringBuffer sql = new StringBuffer();
		sql.append(" SELECT pmw.ProductKey as productKey, nw.PMSWaveIDAlternateKey as pmsWaveId, oc.date as targetDate, sum(cmt) as odmCommit ");
		sql.append(" FROM FactODMCommit oc, FactProductMTMWave pmw, DimNPIWave nw ");
		sql.append(" WHERE 1=1 ");
		sql.append(" and pmw.NPIWaveKey = nw.NPIWaveKey ");
		sql.append(" and oc.MTMKey = pmw.MTMKey ");
		sql.append(" and nw.PMSWaveIDAlternateKey = :pmsWaveId ");
		sql.append(" and oc.versiondate = DATEADD(DAY, 4, :dnsVersionDate) ");
		//sql.append(" and oc.date = :targetDate ");
		sql.append(" and pmw.dateVersion = (select max(dateVersion) from FactProductMTMWave t where oc.MTMKey = t.MTMKey and t.dateVersion <= :versionDate) ");
		sql.append(" group by pmw.ProductKey, nw.PMSWaveIDAlternateKey, oc.date ");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("productKey", IntegerType.INSTANCE)
				.addScalar("pmsWaveId", IntegerType.INSTANCE)
				.addScalar("targetDate", DateType.INSTANCE)
				.addScalar("odmCommit", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(OdmCommitDto.class));
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		query.setParameter("pmsWaveId", pmsWaveId);
		query.setParameter("dnsVersionDate", dnsVersionDate);
		query.setParameter("versionDate", sdf.format(versionDate));
		//query.setParameter("targetDate", targetDate);
		return query.list();
	}
}
