package com.lenovo.bi.view.npi.ttv.outlook.detractor;

import java.util.List;

import com.lenovo.bi.view.npi.chart.pie.PieChartView;

public class TtvDetractorCodeView {
	List<TtvGridDetractorCodeView> grid;
	PieChartView chart;
	public List<TtvGridDetractorCodeView> getGrid() {
		return grid;
	}
	public void setGrid(List<TtvGridDetractorCodeView> grid) {
		this.grid = grid;
	}
	public PieChartView getChart() {
		return chart;
	}
	public void setChart(PieChartView chart) {
		this.chart = chart;
	}
}
