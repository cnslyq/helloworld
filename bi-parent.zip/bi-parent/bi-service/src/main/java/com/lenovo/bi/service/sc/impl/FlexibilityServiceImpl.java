package com.lenovo.bi.service.sc.impl;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.sc.FlexibilityDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FlexibilityChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.service.common.CommonService;
import com.lenovo.bi.service.sc.FlexibilityService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.DataSetLine;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView2DLine;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.sc.flexibility.FlexibilityDetailGridView;

@Service
public class FlexibilityServiceImpl implements FlexibilityService {
 
	@Inject
	FlexibilityDao flexibilityDao;
	
	@Inject
	CommonService commonService;
	
	@Override
	public MSColumnChartView2DLine getOverviewChart(SearchOtsForm form) throws ParseException {
		MSColumnChartView2DLine columnChartView = new MSColumnChartView2DLine();
		setOverviewChartInfomation(columnChartView);
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
				|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
			String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
			
			if(!form.isShowQuarterOverview()) {
				for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
					String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
					if (form.getEndDate()!=null && yearMonth.compareTo(form.getEndDate()) > 0) 
						break;
					Category category = new Category();
					category.setName(yearMonth);
					categoryList.add(category);
				}
			}
			else {
				String date = "";
				if(form.getStartDate().substring(5).compareTo("04") < 0)
					date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
				else
					date = form.getStartDate().substring(0, 5) + "04";
				for(int i=0; i<4; i++) {
					Category category = new Category();
					category.setName("Q"+ (i+1));
					String quarterFrom = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i*3);
					String quarterTo = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i*3+2);
					category.setQuarterValue(quarterFrom + "||" + quarterTo);
					categoryList.add(category);
				}
			}
		}
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		List dataSet = new ArrayList();
		//dataset list and lineset list
		List flexibilityOrderDataSetList = new ArrayList();
		List<DataSetLine> targetLineDataSetList = new ArrayList<DataSetLine>();
		
		//dataset:seriesName
		DataSetColumn flexibilityDataSetColumn = new DataSetColumn();
		flexibilityDataSetColumn.setSeriesName("FLEXIBILITY");
		flexibilityDataSetColumn.setColor("6699ff");
		
		DataSetLine targetDataSetLine = new DataSetLine();
		targetDataSetLine.setSeriesName("Target");
		targetDataSetLine.setRenderas("Line");
		targetDataSetLine.setColor("ffcc33");
		
		List<ColumnData> flexibilityCloumnDataList = new ArrayList<ColumnData>();;
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		
		LinkedHashMap<Object,List<FlexibilityChartData>> flexibilityOverviewMap = null;
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())) 
			flexibilityOverviewMap = fetchFlexibilityOverViewChartData(form);
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName()))
			flexibilityOverviewMap = fetchFlexibilityCrossMonthOverviewChartData(form);
		else if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName()))
			flexibilityOverviewMap = fetchFlexibilityDashboardOverViewChartData(form);
		int i=0;
		//根据Category个数来的
		for(Map.Entry<Object, List<FlexibilityChartData>> entry : flexibilityOverviewMap.entrySet()) {
			String name = ((KeyNameObject)entry.getKey()).getObjName();
			int key = -1;
			if(((KeyNameObject)entry.getKey()).getObjKey() != null)
				key = ((KeyNameObject)entry.getKey()).getObjKey();
			List<FlexibilityChartData> chartDataList = entry.getValue();
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				Category category = new Category();
				category.setName(name);
				categoryList.add(category);
			}
			
			ColumnData flexibility = new ColumnData();
			setFlexibilityOverviewColumnLink(flexibility,name,key);
			
			Map<String,Integer> dataMap = new HashMap<String,Integer>();
			StringBuffer valueBuffer = new StringBuffer("[{");
			Category category = (Category)(categoryList.get(i));
			int qualifiedProduct=0;
			Float flexibilityByMonth=0f;
			for(FlexibilityChartData flexibilityOverViewChartData : chartDataList) {
				setFlexibilityOverviewColumnLink(flexibility,name,key);
				flexibilityByMonth = calFlexibility(flexibilityOverViewChartData);
				if(flexibilityByMonth>=30){
					qualifiedProduct++;
				}
				flexibilityByMonth=new BigDecimal(flexibilityByMonth).add(new BigDecimal(0), new MathContext(3,RoundingMode.HALF_DOWN)).floatValue();
				flexibility.setValue(flexibilityByMonth);
				valueBuffer.append("flexibility:");
				dataMap.put("FLEXIBILITY", flexibilityByMonth.intValue());
				valueBuffer.append(flexibilityByMonth).append(",");
			}
			
			float qualifiedRate=0f;
			
			if(!"Product".equals(form.getDimension())){
				if(chartDataList!=null&&chartDataList.size()>0){
					qualifiedRate=new BigDecimal(qualifiedProduct).multiply(new BigDecimal(100)).divide(new BigDecimal(chartDataList.size()), new MathContext(3,RoundingMode.HALF_DOWN)).floatValue();
					flexibility.setValue(qualifiedRate);
				}
			}
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				valueBuffer.append("subDimensionName:");
				valueBuffer.append("'" + name + "'").append(",");
			}
			
			//TODO MakeRate
			/*float makeRateValue = dataMap.get("FLEXIBILITY");
			
			if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
					|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
				makeRateValue = commonService.calculateMakeRate(category.getName(), dataMap);
			}
			else
				makeRateValue = commonService.calculateMakeRate(form.getSelectMonth(), dataMap);*/
			
			valueBuffer.append("qualifiedRate:");
			
			valueBuffer.append(qualifiedRate).append(",");
			
			String lightColor;
			
			float targetValue = 0f;
			
			if("Product".equals(form.getDimension())){
				lightColor = commonService.getFlexibilityKPILightColor(form.getDimension(),flexibilityByMonth);
				targetValue=30f;
			}else{
				lightColor = commonService.getFlexibilityKPILightColor(form.getDimension(),qualifiedRate);
				targetValue=65f;
			}
			
			flexibilityCloumnDataList.add(flexibility);//这里要Add Rate();
			
			/*Float thresholdValue = masterDataService.getThresholdByName(Threshold.SC_OTS_ONS_TARGET.name());
			if(thresholdValue != null)
				targetValue = thresholdValue.floatValue();*/
			//Target
			ColumnData target = new ColumnData();
			target.setValue(targetValue);
			targetCloumnDataList.add(target);
			
			valueBuffer.append("target:");
			valueBuffer.append(targetValue).append(",");
			valueBuffer.append("lightColor:");
			valueBuffer.append("'" + lightColor + "'");
			valueBuffer.append("}").append("]");
			//System.out.println("----------KPI:" + valueBuffer.toString());
			
			category.setValues(valueBuffer.toString());
			i++;
		}
		
		flexibilityDataSetColumn.setDataList(flexibilityCloumnDataList);
		flexibilityOrderDataSetList.add(flexibilityDataSetColumn);
		
		targetDataSetLine.setDataList(targetCloumnDataList);
		flexibilityOrderDataSetList.add(targetDataSetLine);
		
		columnChartView.setDataSet(flexibilityOrderDataSetList);
		
		return columnChartView;
	}

	public LinkedHashMap<Object,List<FlexibilityChartData>> fetchFlexibilityOverViewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<FlexibilityChartData>> flexibilityOverviewMap = new LinkedHashMap<Object,List<FlexibilityChartData>>();
		if(!form.isShowQuarterOverview()) {
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				flexibilityOverviewMap.put(keyNameObject, flexibilityDao.fetchFlexibilityOverViewChartData(form));
			}
		}
		else {
			String date = "";
			if(form.getStartDate().substring(5).compareTo("04") < 0)
				date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
			else
				date = form.getStartDate().substring(0, 5) + "04";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			for(int i=0; i<4; i++) {
				KeyNameObject keyNameObject = new KeyNameObject();
				String quarterFrom = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i*3);
				String quarterTo = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i*3+2);
				if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0)
					form.setQuarterTo(currentDate.replace("-0", "-"));
				else
					form.setQuarterTo(quarterTo.replace("-0", "-"));
				form.setQuarterFrom(quarterFrom.replace("-0", "-"));
				keyNameObject.setObjName(quarterFrom + "||" + quarterTo);
				flexibilityOverviewMap.put(keyNameObject, flexibilityDao.fetchFlexibilityOverViewChartData(form));
			}
		}
		
		return flexibilityOverviewMap;
	}
	
	public LinkedHashMap<Object,List<FlexibilityChartData>> fetchFlexibilityCrossMonthOverviewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<FlexibilityChartData>> flexibilityOverviewMap = new LinkedHashMap<Object,List<FlexibilityChartData>>();
		String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
		if(!form.isShowQuarterOverview()) {
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(startDate, i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				//form.setSelectMonth(date);
				flexibilityOverviewMap.put(keyNameObject, flexibilityDao.fetchFlexibilityCrossMonthOverviewChartData(form));
			}
		}
		else {
			String date = "";
			if(form.getStartDate().substring(5).compareTo("04") < 0)
				date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
			else
				date = form.getStartDate().substring(0, 5) + "04";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			for(int i=0; i<4; i++) {
				KeyNameObject keyNameObject = new KeyNameObject();
				String quarterFrom = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i*3);
				String quarterTo = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i*3+2);
				if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0)
					form.setQuarterTo(currentDate.replace("-0", "-"));
				else
					form.setQuarterTo(quarterTo.replace("-0", "-"));
				form.setQuarterFrom(quarterFrom.replace("-0", "-"));
				
				keyNameObject.setObjName(quarterFrom + "||" + quarterTo);
				flexibilityOverviewMap.put(keyNameObject, flexibilityDao.fetchFlexibilityCrossMonthOverviewChartData(form));
			}
		}
		
		return flexibilityOverviewMap;
	}

	public LinkedHashMap<Object,List<FlexibilityChartData>> fetchFlexibilityDashboardOverViewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<FlexibilityChartData>> flexibilityDashboardOverviewMap = new LinkedHashMap<Object,List<FlexibilityChartData>>();
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		
		List<KeyNameObject> dimensionList = flexibilityDao.fetchDimensions(form);
		for(KeyNameObject keyNameObject : dimensionList) {
			form.setSubDimensionKey(keyNameObject.getObjKey());
			form.setSubDimension(keyNameObject.getObjName());
			flexibilityDashboardOverviewMap.put(keyNameObject, flexibilityDao.fetchFlexibilityDashboardOverViewChartData(form));
		}
		
		return flexibilityDashboardOverviewMap;
	}
	
	public LinkedHashMap<Object,List<FlexibilityChartData>> fetchFlexibilityComponentOverViewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<FlexibilityChartData>> flexibilityDashboardOverviewMap = new LinkedHashMap<Object,List<FlexibilityChartData>>();
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		List<KeyNameObject> componentList = flexibilityDao.fetchComponents(form);
		for(KeyNameObject keyNameObject : componentList) {
			form.setSubDimensionKey(keyNameObject.getObjKey());
			flexibilityDashboardOverviewMap.put(keyNameObject, flexibilityDao.fetchComponentOverViewChartData(form));
		}
		
		return flexibilityDashboardOverviewMap;
	}
	
	public void setFlexibilityOverviewColumnLink(ColumnData cloumnData,String name, int key) {
		/*cloumnData.setLink("j-showDetractorMainPieAndData-"
				+ weekNo + "," 
				+ trackingCausesMonday + "|" 
				+trackingCausesSunday);*/
		cloumnData.setLink("j-refreshRemark-" + name + "," + key);
	}
	
	@Override
	public ColumnChartView getRemarkChart(SearchOtsForm form) throws ParseException {
		List<String> dates = CalendarUtil.getDatesByString(form.getSelectMonth());
		if(CollectionUtils.isNotEmpty(dates)){
			if(dates.size() < 2){
				form.setStartDate(dates.get(0));
				form.setEndDate(dates.get(0));
			}
			else{
				form.setStartDate(dates.get(0));
				form.setEndDate(dates.get(1));
			}
		}
		else{
			//return null;
		}
		ColumnChartView columnChartView = setRemarkChartInfomation();
		
		//dataset:seriesName
		List<DataSetParent> flexibilityDimensionDataSetList = new ArrayList<DataSetParent>();
		
		DataSetColumn flexibilityDataSetColumn = new DataSetColumn();
		if("Region".equals(form.getDimension()))
			flexibilityDataSetColumn.setSeriesName("Flexibility by Region");
		else if("Family".equals(form.getDimension()))
			flexibilityDataSetColumn.setSeriesName("Flexibility by Family");
		else if("Product".equals(form.getDimension()))
			flexibilityDataSetColumn.setSeriesName("Flexibility by Product");
		else if("Geo".equals(form.getDimension()))
			flexibilityDataSetColumn.setSeriesName("Flexibility by Geo");
		flexibilityDataSetColumn.setColor("ff3300");
		List<ColumnData> flexibilityCloumnDataList = new ArrayList<ColumnData>();
		
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		List<FlexibilityChartData> flexibilityRemarkList = fetchFlexibilityRemarkChartData(form);
		
		//现在要根据dimensionName来进行Map 
		Map<String,List<FlexibilityChartData>>dimensionMap=convertToMap(flexibilityRemarkList);
		// Y, List<ChartData> 不同productKey的数据
		
		Map<String,Float>catAndData=null;
		//getFlexibilityForProduct
		if("Product".equals(form.getDimension())){
			catAndData=getFlexibilityForProduct(dimensionMap);
		}else{
			catAndData=getQualifiedRate(dimensionMap);
		}
		
		// Y, Family的Key ,Flexibility,加权计算
		//Map<String,Float>catAndData=getChartCategoryAndData(dimensionMap);
		
		List<Entry<String,Float>>list=new ArrayList<Entry<String,Float>>(catAndData.entrySet());
		Collections.sort(list, new Comparator<Entry<String,Float>>(){
			@Override
			public int compare(Entry<String,Float> o1, Entry<String,Float> o2) {
				if(o2.getValue()-o1.getValue() == 0){
					return 0;
				}else{
					return o2.getValue()-o1.getValue()>0?1:-1;
				}
			}
		});
		
		//flexibilityRemarkList 
		for(int i=0; i<list.size(); i++) {
			if(i == 15) break;
//			FlexibilityChartData flexibilityRemarkChartData = flexibilityRemarkList.get(i);
//			String name = flexibilityRemarkChartData.getDimensionName();
//			int value = flexibilityRemarkChartData.getDimensionKey();
			Entry<String,Float>entry=list.get(i);
			//Family的名字
			String name=entry.getKey();
			int value=dimensionMap.get(name).get(0).getDimensionKey();
			//是key int value=
			Category category = new Category();
			category.setName(name);
			category.setValue(value);
			categoryList.add(category);
			
			ColumnData flexibility = new ColumnData();
			setRemarkColumnLink(form,category,flexibility);
			Float flexibilityByDimsion = entry.getValue();
			flexibility.setValue(flexibilityByDimsion);
			flexibility.setTooltext("Flexibility, "+name+", "+flexibilityByDimsion);
			flexibilityCloumnDataList.add(flexibility);
		}
		Categories categories = new Categories();
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		flexibilityDataSetColumn.setDataList(flexibilityCloumnDataList);
		flexibilityDimensionDataSetList.add(flexibilityDataSetColumn);
		
		columnChartView.setDataSetList(flexibilityDimensionDataSetList);
		
		return columnChartView;
	}

	
	public List<FlexibilityChartData> fetchFlexibilityRemarkChartData(SearchOtsForm form) throws ParseException {
		if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			if(!form.isShowQuarterOverview()) {
				String yearStr = form.getSelectMonth().substring(0,4);
				String monthStr = form.getSelectMonth().substring(5,7);
				int year = Integer.parseInt(yearStr);
				int month = Integer.parseInt(monthStr);
				form.setYear(year);
				form.setMonth(month);
			}
		}
		
		List<FlexibilityChartData> flexibilityRemarkChartDataList = flexibilityDao.fetchDimensionRemarkDataList(form);
		for(FlexibilityChartData flexibilityRemarkChartData : flexibilityRemarkChartDataList) {
			Float flexibilityByDimesion = calFlexibility(flexibilityRemarkChartData);
			flexibilityRemarkChartData.setFlexibility(flexibilityByDimesion);
		}
		return flexibilityRemarkChartDataList;
	}
	
	
	public void setColumnLink(int weekNo,ColumnData cloumnData) {
		
		cloumnData.setLink("j-refreshRemark-");
	
	}
	
	public void setRemarkColumnLink(SearchOtsForm form,Category category,ColumnData cloumnData) {
		StringBuffer sb = new StringBuffer();
		String durationFrom = form.getQuarterFrom() != null ? form.getQuarterFrom() : form.getStartDate();
		String durationTo = form.getQuarterTo() != null ? form.getQuarterTo() : form.getEndDate();
		if(StringUtils.isBlank(durationTo)){
			durationTo = durationFrom;
		}
		//这里放入json
		sb.append("{");
		sb.append("durationFrom:")
			.append("\"").append(durationFrom).append("\"").append(",");
		sb.append("durationTo:")
			.append("\"").append(durationTo).append("\"").append(",");
		//放入dimensionName和dimensionKey
		sb.append("dimension:")
			.append("\"").append(form.getDimension()).append("\"").append(",");
		//这里是根据region geo来判断是否放入name,还是value
		if("Geo".equals(form.getDimension())||"Region".equals(form.getDimension())){//ChartTypeEnum.OverView.getTypeName().equalsIgnoreCase(form.getChartType())
			sb.append("dimensionKey:")
			.append("\"").append(category.getName()).append("\"")
			.append("}");
		}else{
			sb.append("dimensionKey:")
				.append("\"").append(category.getValue()).append("\"")
				.append("}");
		}
		cloumnData.setLink( "j-showFlexibilityDetail-"+sb.toString() );
	}
	
	private ColumnChartView setRemarkChartInfomation() {
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		columnChartView.getChartInfo().setFormatNumber("%");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setShowBorder("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setShowValues("0");
//		columnChartView.getChartInfo().setSnumberSuffix("%");
		columnChartView.getChartInfo().setNumbersuffix("%");
//		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");
		columnChartView.getChartInfo().setChartRightMargin("50");
		
		return columnChartView;
	}
	
	private void setOverviewChartInfomation(MSColumnChartView2DLine mSColumnChartView) {
		mSColumnChartView.getChartInfo().setCaption("");
		mSColumnChartView.getChartInfo().setNumdivlines("8");
		mSColumnChartView.getChartInfo().setNumbersuffix("%");
		mSColumnChartView.getChartInfo().setyAxisMinValue("0");
		mSColumnChartView.getChartInfo().setyAxisMaxValue("100");
		mSColumnChartView.getChartInfo().setFormatNumberScale("0");
		mSColumnChartView.getChartInfo().setLegendIconScale("1");
		mSColumnChartView.getChartInfo().setShowBorder("1");
		mSColumnChartView.getChartInfo().setCanvasBorderThickness("1");
		mSColumnChartView.getChartInfo().setShowZeroPlaneValue("1");
		mSColumnChartView.getChartInfo().setCanvasBorderAlpha("60");
		mSColumnChartView.getChartInfo().setPlotSpacePercent("70");
		mSColumnChartView.getChartInfo().setBgalpha("0,0");
		mSColumnChartView.getChartInfo().setLegendPosition("");
		mSColumnChartView.getChartInfo().setShowBorder("0");
		mSColumnChartView.getChartInfo().setShowPlotBorder("0");
		mSColumnChartView.getChartInfo().setShowValues("0");
	}

	@Override
	public List<FlexibilityDetailGridView> getRemarkFlexibilityDetails(SearchOtsForm form) {
		List<FlexibilityDetailGridView> list=this.getFlexibilityDetails(form);
		int startRow=(form.getCurrentPage()-1)*SysConfig.NUMBER_OF_ROW_COUNT;
		int pageSize=SysConfig.NUMBER_OF_ROW_COUNT;
		int maxResult=list.size()-startRow>pageSize?pageSize:list.size()-startRow;
		return new ArrayList<FlexibilityDetailGridView>(list.subList(startRow, startRow+maxResult));
	}
	
	private List<FlexibilityDetailGridView> getFlexibilityDetails(SearchOtsForm form){
		List<FlexibilityDetailGridView> flexibilityDetails = flexibilityDao.fetchFlexibilityDetail(form);
		if(CollectionUtils.isNotEmpty(flexibilityDetails)){
			for(FlexibilityDetailGridView detail : flexibilityDetails){
				FlexibilityChartData flexibilityChartData = new FlexibilityChartData();
				flexibilityChartData.setShipmentQty(detail.getShipment());
				flexibilityChartData.setStockForecastQty(detail.getStockForecastQty());
				flexibilityChartData.setCommitQty(detail.getCwCommit());
				flexibilityChartData.setOrderQty(detail.getCwOrder());
				Float flexibility = calFlexibility(flexibilityChartData);
				detail.setFlexibility(flexibility == null ? 0 : flexibility);
				Integer commitQty = flexibilityChartData.getCommitQty() == null ? 0 : flexibilityChartData.getCommitQty();
				Integer shipmentQty = flexibilityChartData.getShipmentQty() == null ? 0 : flexibilityChartData.getShipmentQty();
				Integer orderQty = flexibilityChartData.getOrderQty() == null ? 0 : flexibilityChartData.getOrderQty();
				Integer stockForecastQty = flexibilityChartData.getStockForecastQty() == null ? 0 : flexibilityChartData.getStockForecastQty();// 60DMD
				Integer A=commitQty>shipmentQty?commitQty:shipmentQty;
				detail.setA(String.valueOf(A));
				BigDecimal bValue = new BigDecimal(0);
				BigDecimal cValue = new BigDecimal(0);
				float B = 0;
				float C = 0;
					
				try{
					bValue = new BigDecimal(A).subtract(new BigDecimal(stockForecastQty))
												.divide(new BigDecimal(stockForecastQty),4,BigDecimal.ROUND_HALF_UP)
												.multiply(new BigDecimal(100));
					B = bValue.floatValue();
					
				}
				catch(ArithmeticException e) {
					B = 0;
				}
				
				try{
					cValue = new BigDecimal(A).subtract(new BigDecimal(orderQty))
												.divide(new BigDecimal(orderQty),4,BigDecimal.ROUND_HALF_UP)
												.multiply(new BigDecimal(100));
					C = cValue.floatValue();
				}
				catch(ArithmeticException e) {
					C = 0;
				}
					
				detail.setB(String.valueOf(B));
				detail.setC(String.valueOf(C));
				
			}
		}
		sortOrderDetail(flexibilityDetails,form);
		return flexibilityDetails;
	}
	
	@Override
	public List<FlexibilityDetailGridView> getFlexibilityDetailsForExcel(SearchOtsForm form){
		List<FlexibilityDetailGridView> flexibilityDetails = flexibilityDao.fetchFlexibilityDetailForExcel(form);
		if(CollectionUtils.isNotEmpty(flexibilityDetails)){
			for(FlexibilityDetailGridView detail : flexibilityDetails){
				FlexibilityChartData flexibilityChartData = new FlexibilityChartData();
				flexibilityChartData.setShipmentQty(detail.getShipment());
				flexibilityChartData.setStockForecastQty(detail.getStockForecastQty());
				flexibilityChartData.setCommitQty(detail.getCwCommit());
				flexibilityChartData.setOrderQty(detail.getCwOrder());
				Float flexibility = calFlexibilityForExcel(flexibilityChartData);
				detail.setFlexibility(flexibility == null ? 0 : flexibility);
				Integer commitQty = flexibilityChartData.getCommitQty() == null ? 0 : flexibilityChartData.getCommitQty();
				Integer shipmentQty = flexibilityChartData.getShipmentQty() == null ? 0 : flexibilityChartData.getShipmentQty();
				Integer orderQty = flexibilityChartData.getOrderQty() == null ? 0 : flexibilityChartData.getOrderQty();
				Integer stockForecastQty = flexibilityChartData.getStockForecastQty() == null ? 0 : flexibilityChartData.getStockForecastQty();// 60DMD
				Integer A=commitQty>shipmentQty?commitQty:shipmentQty;
				detail.setA(String.valueOf(A));
				BigDecimal bValue = new BigDecimal(0);
				BigDecimal cValue = new BigDecimal(0);
				float B = 0;
				float C = 0;
				try{
					bValue = new BigDecimal(A).subtract(new BigDecimal(stockForecastQty))
												.divide(new BigDecimal(stockForecastQty),4,BigDecimal.ROUND_HALF_UP);
												//.multiply(new BigDecimal(100));
					B = bValue.floatValue();
					
				}
				catch(ArithmeticException e) {
					B = 0;
				}
				
				try{
					cValue = new BigDecimal(A).subtract(new BigDecimal(orderQty))
												.divide(new BigDecimal(orderQty),4,BigDecimal.ROUND_HALF_UP);
												//.multiply(new BigDecimal(100));
					C = cValue.floatValue();
				}
				catch(ArithmeticException e) {
					C = 0;
				}
				detail.setB(String.valueOf(B));
				detail.setC(String.valueOf(C));
				
			}
		}
		return flexibilityDetails;
	}
	
	
	public Float calFlexibility(FlexibilityChartData flexibilityChartData) {
		Float flexibility = 0f;
		
		Integer commitQty = flexibilityChartData.getCommitQty() == null ? 0 : flexibilityChartData.getCommitQty();
		Integer shipmentQty = flexibilityChartData.getShipmentQty() == null ? 0 : flexibilityChartData.getShipmentQty();
		Integer orderQty = flexibilityChartData.getOrderQty() == null ? 0 : flexibilityChartData.getOrderQty();
		Integer stockForecastQty = flexibilityChartData.getStockForecastQty() == null ? 0 : flexibilityChartData.getStockForecastQty();// 60DMD
		
		int[] array = new int[] {commitQty,shipmentQty,orderQty,stockForecastQty};
		Arrays.sort(array);
		
		Integer A = commitQty > shipmentQty ? commitQty : shipmentQty;
		float B = 0;
		float C = 0;
		Integer D = array[array.length-1];
		
		BigDecimal bValue = new BigDecimal(0);
		BigDecimal cValue = new BigDecimal(0);
		
		//TODO 
		MathContext mc = new MathContext(5, RoundingMode.HALF_DOWN);
		//B = (A – stockForecastQty)/stockForecastQty
		try{
			bValue = new BigDecimal(A).subtract(new BigDecimal(stockForecastQty))
										.divide(new BigDecimal(stockForecastQty),4,BigDecimal.ROUND_HALF_UP)
										.multiply(new BigDecimal(100));
			B = bValue.floatValue();
			
		}
		catch(ArithmeticException e) {
			B = 0;
		}
		
		try{
			cValue = new BigDecimal(A).subtract(new BigDecimal(orderQty))
										.divide(new BigDecimal(orderQty),4,BigDecimal.ROUND_HALF_UP)
										.multiply(new BigDecimal(100));
			C = cValue.floatValue();
		}
		catch(ArithmeticException e) {
			C = 0;
		}
		
		
		if(stockForecastQty == 0) {
			if(A == 0)
				flexibility = 0f;
			else if(A > 0)
				flexibility = 30f;
		}else if(A <= stockForecastQty) {
			if(C >= 100)
				flexibility = 100f;
			else if(C <= 0)
				flexibility = 0f;
			else
				flexibility = C;
		}else{
			if(B >= 100)
				flexibility = 100f;
			else 
				flexibility = B;
		}
		
		
		
		return flexibility;
	}
	
	public Float calFlexibilityForExcel(FlexibilityChartData flexibilityChartData) {
		Float flexibility = 0f;
		
		Integer commitQty = flexibilityChartData.getCommitQty() == null ? 0 : flexibilityChartData.getCommitQty();
		Integer shipmentQty = flexibilityChartData.getShipmentQty() == null ? 0 : flexibilityChartData.getShipmentQty();
		Integer orderQty = flexibilityChartData.getOrderQty() == null ? 0 : flexibilityChartData.getOrderQty();
		Integer stockForecastQty = flexibilityChartData.getStockForecastQty() == null ? 0 : flexibilityChartData.getStockForecastQty();// 60DMD
		
		int[] array = new int[] {commitQty,shipmentQty,orderQty,stockForecastQty};
		Arrays.sort(array);
		
		Integer A = commitQty > shipmentQty ? commitQty : shipmentQty;
		float B = 0;
		float C = 0;
		Integer D = array[array.length-1];
		
		BigDecimal bValue = new BigDecimal(0);
		BigDecimal cValue = new BigDecimal(0);
		
		//TODO 
		MathContext mc = new MathContext(5, RoundingMode.HALF_DOWN);
		//B = (A – stockForecastQty)/stockForecastQty
		try{
			bValue = new BigDecimal(A).subtract(new BigDecimal(stockForecastQty))
										.divide(new BigDecimal(stockForecastQty),4,BigDecimal.ROUND_HALF_UP);
			B = bValue.floatValue();
			
		}
		catch(ArithmeticException e) {
			B = 0;
		}
		
		try{
			cValue = new BigDecimal(A).subtract(new BigDecimal(orderQty))
										.divide(new BigDecimal(orderQty),4,BigDecimal.ROUND_HALF_UP);
			C = cValue.floatValue();
		}
		catch(ArithmeticException e) {
			C = 0;
		}
		
		
		if(stockForecastQty == 0) {
			if(A == 0)
				flexibility = 0f;
			else if(A > 0)
				flexibility = 0.3f;
		}else if(A <= stockForecastQty) {
			if(C >= 1)
				flexibility = 1f;
			else if(C <= 0)
				flexibility = 0f;
			else
				flexibility = C;
		}else{
			if(B >= 1)
				flexibility = 1f;
			else 
				flexibility = B;
		}
		
		return flexibility;
	}
	
	public void setFormDimParam(SearchOtsForm form, String dim, String dimKeys){
		if("Family".equals(dim)){
			if(StringUtils.isBlank(form.getFamilyIds())){
				form.setFamilyIds(dimKeys);
			}else{
				form.setFamilyIds(form.getFamilyIds()+","+dimKeys);
			}
		}
		else if("Product".equals(dim)){
			if(StringUtils.isBlank(form.getProductIds())){
				form.setProductIds(dimKeys);
			}else{
				form.setProductIds(form.getProductIds()+","+dimKeys);
			}
		}
		else if("Region".equals(dim)){
			if(StringUtils.isBlank(form.getGeoIds())){
				form.setGeoIds(dimKeys);
			}else{
				form.setGeoIds(form.getGeoIds()+","+dimKeys);
			}
		}
	}

	private Map<String,List<FlexibilityChartData>> convertToMap(List<FlexibilityChartData> dimensionMap){
		Map<String,List<FlexibilityChartData>> map=new HashMap<String,List<FlexibilityChartData>>();
		for(FlexibilityChartData data:dimensionMap){
			String dimensionName=data.getDimensionName();
			if(map.get(dimensionName)==null){
				List<FlexibilityChartData>list=new ArrayList<FlexibilityChartData>();
				list.add(data);
				map.put(dimensionName, list);
			}else{
				map.get(dimensionName).add(data);
			}
		}
		return map;
	}
	
	private Map<String,Float> getChartCategoryAndData(Map<String,List<FlexibilityChartData>>dimensionMap){
		Map<String,Float>categoryAndData=new HashMap<String,Float>();
		for(Entry<String, List<FlexibilityChartData>> entry:dimensionMap.entrySet()){
			String dimensionKey=entry.getKey();
			List<FlexibilityChartData>dataList=entry.getValue();
			int total=getTotalFcst(dataList);
			BigDecimal upTotal=new BigDecimal(0);
			//total
			for(FlexibilityChartData data:dataList){
				Float flexibility=data.getFlexibility();
				//flexibility*fcst/total
				if(data.getStockForecastQty()!=null){
					upTotal=new BigDecimal(flexibility).multiply(new BigDecimal(data.getStockForecastQty())).add(upTotal);
				}else if((data.getCommitQty()!=null&&data.getShipmentQty()!=null)){
					upTotal=new BigDecimal(flexibility).multiply(new BigDecimal(data.getCommitQty()>data.getShipmentQty()?data.getCommitQty():data.getShipmentQty())).add(upTotal);
				}
			}
			Float rate=null;
			try {
			  rate=upTotal.divide(new BigDecimal(total), new MathContext(3, RoundingMode.HALF_DOWN)).floatValue();
			} catch (Exception e) {
				rate=0f;
			}
			categoryAndData.put(dimensionKey, rate);
		}
		
		return categoryAndData;
		
	}
	
	private Map<String,Float> getFlexibilityForProduct(Map<String,List<FlexibilityChartData>>dimensionMap){
		Map<String,Float>categoryAndData=new HashMap<String,Float>();
		for(Entry<String, List<FlexibilityChartData>> entry:dimensionMap.entrySet()){
			String dimensionKey=entry.getKey();//YOGA 13
			List<FlexibilityChartData>dataList=entry.getValue();
			categoryAndData.put(dimensionKey, dataList.get(0).getFlexibility());
		}
		return categoryAndData;
	}
	
	private Map<String,Float> getQualifiedRate(Map<String,List<FlexibilityChartData>>dimensionMap){
		Map<String,Float>categoryAndData=new HashMap<String,Float>();
		for(Entry<String, List<FlexibilityChartData>> entry:dimensionMap.entrySet()){
			int qualifiedProduct=0;
			String dimensionKey=entry.getKey();//YOGA 13
			List<FlexibilityChartData>dataList=entry.getValue();
			if(CollectionUtils.isNotEmpty(dataList)){
				for(FlexibilityChartData chart:dataList){
					if(chart.getFlexibility()>=30){
						qualifiedProduct++;
					}
				}
				float qualifiedRate=new BigDecimal(qualifiedProduct).multiply(new BigDecimal(100)).divide(new BigDecimal(dataList.size()), new MathContext(3,RoundingMode.HALF_DOWN)).floatValue();
				categoryAndData.put(dimensionKey, qualifiedRate);
			}
			
		}
		return categoryAndData;
	}
	
	private int getTotalFcst(List<FlexibilityChartData>dataList){
		int total=0;
		//拿出所有的data
		for(FlexibilityChartData data:dataList){
			if(data.getStockForecastQty()!=null){
				total+=data.getStockForecastQty();
			}else if(data.getCommitQty()!=null&&data.getShipmentQty()!=null){
				total+=data.getCommitQty()>data.getShipmentQty()?data.getCommitQty():data.getShipmentQty();
			}
		}
		return total;
	}

	@Override
	public int getTotalPageForRemarkFlexibilityDetails(SearchOtsForm form) {
		return flexibilityDao.fetchFlexibilityDetailCount(form);
	}

	private void sortOrderDetail(List<FlexibilityDetailGridView>grid,SearchOtsForm form){
		if(StringUtils.isBlank(form.getSortColumn())){
			return ;
		}
		if(form.getSortColumn().equals("Flexibility")){
			if(form.getSortType().equalsIgnoreCase("asc")){
				Collections.sort(grid, new Comparator<FlexibilityDetailGridView>() {
					@Override
					public int compare(FlexibilityDetailGridView o1,
							FlexibilityDetailGridView o2) {
						return o1.getFlexibility()-o2.getFlexibility()>0?1:-1;
					}
				});
			}else{
				Collections.sort(grid, new Comparator<FlexibilityDetailGridView>() {
					@Override
					public int compare(FlexibilityDetailGridView o1,
							FlexibilityDetailGridView o2) {
						return (o1.getFlexibility()-o2.getFlexibility()>0?1:-1)*-1;
					}
				});
			}
			
		}
		
		if(form.getSortColumn().equals("A")){
			if(form.getSortType().equalsIgnoreCase("asc")){
				Collections.sort(grid, new Comparator<FlexibilityDetailGridView>() {
					@Override
					public int compare(FlexibilityDetailGridView o1,
							FlexibilityDetailGridView o2) {
						return new BigDecimal(o1.getA()).compareTo(new BigDecimal(o2.getA()));
					}
				});
			}else{
				Collections.sort(grid, new Comparator<FlexibilityDetailGridView>() {
					@Override
					public int compare(FlexibilityDetailGridView o1,
							FlexibilityDetailGridView o2) {
						return (new BigDecimal(o1.getA()).compareTo(new BigDecimal(o2.getA())))*-1;
					}
				});
			}
			
		}
		
		if(form.getSortColumn().equals("B")){
			if(form.getSortType().equalsIgnoreCase("asc")){
				Collections.sort(grid, new Comparator<FlexibilityDetailGridView>() {
					@Override
					public int compare(FlexibilityDetailGridView o1,
							FlexibilityDetailGridView o2) {
						return new BigDecimal(o1.getB()).compareTo(new BigDecimal(o2.getB()));
					}
				});
			}else{
				Collections.sort(grid, new Comparator<FlexibilityDetailGridView>() {
					@Override
					public int compare(FlexibilityDetailGridView o1,
							FlexibilityDetailGridView o2) {
						return (new BigDecimal(o1.getB()).compareTo(new BigDecimal(o2.getB())))*-1;
					}
				});
			}
			
		}
		
		if(form.getSortColumn().equals("C")){
			if(form.getSortType().equalsIgnoreCase("asc")){
				Collections.sort(grid, new Comparator<FlexibilityDetailGridView>() {
					@Override
					public int compare(FlexibilityDetailGridView o1,
							FlexibilityDetailGridView o2) {
						return new BigDecimal(o1.getC()).compareTo(new BigDecimal(o2.getC()));
					}
				});
			}else{
				Collections.sort(grid, new Comparator<FlexibilityDetailGridView>() {
					@Override
					public int compare(FlexibilityDetailGridView o1,
							FlexibilityDetailGridView o2) {
						return (new BigDecimal(o1.getC()).compareTo(new BigDecimal(o2.getC())))*-1;
					}
				});
			}
		}
		
	}
}


