package com.lenovo.bi.dao.npi.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.impl.HibernateQueryBaseBi;
import com.lenovo.bi.dao.npi.NPIProductSummaryDao;
import com.lenovo.bi.dto.NPI;
import com.lenovo.bi.enumobj.NPIPhase;
import com.lenovo.bi.enumobj.PermissionScope;
import com.lenovo.bi.enumobj.Risk;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.enumobj.Success;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.model.User;

/**
 * 
 * 
 * @author Henry_Lian
 * 
 */
@Repository
@SuppressWarnings("unchecked")
@Transactional("bi")
public class NPIProductSummaryDaoImpl extends HibernateQueryBaseBi implements NPIProductSummaryDao {

	@Override
	public List<ProjectSummary> getProductInfoByWaveId(List<Integer> waveId, Date versionDate) {
		StringBuffer hql = new StringBuffer();
		hql.append("select new ProjectSummary(ps.pmsWaveId, ps.doi,").append("ps.defects, ps.fpy, ps.odm, ps.tooling,")
				.append("ps.isTTMRisk, ps.ttmDelays, ps.isTTVRisk,").append("ps.pmsProjectId, ps.startDate, ps.productName,")
				.append("ps.waveName, ps.ttmStatus, ps.ttvStatus,").append("ps.ttmTargetDate, ps.ttmSignOffDate, ps.ttvTargetDate,")
				.append("ps.ttvSignOffDate, ps.ttvTarget, ps.estimatedTTV,").append("ps.actualTTV, ps.family, ps.obe,")
				.append("ps.pm, ps.versionDate, ps.svtPlanDate, ps.sovpPlanDate, ps.isProjectPlanned, ps.obeTarget, ps.ttmTargetDateDemand,ps.currentPhase, ")
				.append("ps.sgaTtvTargetDate,ps.sgaTtvStatus,isnull(ps.isSgaTtvRisk,0),ps.sgaTtvSignOffDate,ps.sgaTtvTarget,ps.sgaEstimatedTTV,ps.sgaActualTTV) ")
				.append("from ProjectSummary ps where ps.pmsWaveId in (:ids) ");
		if(versionDate != null){
			hql.append(" and ps.versionDate = :versionDate ");
		}else{
			hql.append(" and not exists(select 1 from ProjectSummary  where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,versionDate,ps.versionDate)<0 ) ");
		}
		Query q = getSession().createQuery(hql.toString());
		q.setParameterList("ids", waveId);
		if(versionDate != null){
			q.setDate("versionDate", versionDate);
		}
		return q.list();
	}

	@Override
	public List<ProjectSummary> getProductInfoByProjectId(int projectId,int waveId, Date versionDate) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select new ProjectSummary(ps.pmsWaveId, ps.doi,").append("ps.defects, ps.fpy, ps.odm, ps.tooling,")
				.append("isnull(ps.isTTMRisk,0), ps.ttmDelays, isnull(ps.isTTVRisk,0),").append("ps.pmsProjectId, ps.startDate, ps.productName,")
				.append("ps.waveName, ps.ttmStatus, ps.ttvStatus,").append("ps.ttmTargetDate, ps.ttmSignOffDate, ps.ttvTargetDate,")
				.append("ps.ttvSignOffDate, ps.ttvTarget, ps.estimatedTTV,").append("ps.actualTTV, ps.family, ps.obe,")
				.append("ps.pm, ps.versionDate, ps.svtPlanDate, ps.sovpPlanDate, ps.isProjectPlanned, ps.obeTarget, ps.ttmTargetDateDemand, ps.currentPhase, ")
				.append("ps.sgaTtvTargetDate,ps.sgaTtvStatus,isnull(ps.isSgaTtvRisk,0),ps.sgaTtvSignOffDate,ps.sgaTtvTarget,ps.sgaEstimatedTTV,ps.sgaActualTTV, ps.fpyTarget) ")
				.append("from ProjectSummary ps where ps.pmsProjectId = :id ")
			//	.append( "and ps.pmsWaveId = :wid")
				;
		if(versionDate != null){
			sBuffer.append(" and ps.versionDate = :versionDate ");
		}else{
			sBuffer.append(" and not exists(select 1 from ProjectSummary  where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,versionDate,ps.versionDate)<0 ) ");
		}
		Query q = getSession().createQuery(sBuffer.toString());
		q.setInteger("id", projectId);
		//q.setInteger("wid", waveId);
		if(versionDate != null){
			q.setDate("versionDate", versionDate);
		}
		
		return q.list();
	}
	@Override
	public Date getOldestVersionDateByWaveIdAndTTMStatus(int waveId, String ttmStatus){
		StringBuffer sb = new StringBuffer();
		sb.append("select min(versiondate) from BI_ProjectSummary where pmsWaveId = :pmsWaveId  and ttm_status = :ttmStatus");
		SQLQuery q = getSession().createSQLQuery(sb.toString());
		q.setInteger("pmsWaveId", waveId);
		q.setString("ttmStatus", ttmStatus);
		List<Date> versionDates = q.list();
		if(CollectionUtils.isNotEmpty(versionDates)){
			return versionDates.get(0);
		}else{
			return null;
		}
	}
	public User getUser(String userId) {
		if (userId == null) {
			return null;
		}
		String hql = "from User where userId = :userId";
		Query q = getSession().createQuery(hql);
		q.setString("userId", userId);
		List<User> users = q.list();
		if (users == null || users.isEmpty()) {
			return null;
		}
		return users.get(0);
	}

	public Map<Integer, List<NPI>> getNPIByWaveIds(Integer[] waveIds) {
		if (waveIds == null) {
			return null;
		}
		// distinct is a hack, but there's no harm doing it.
		String hql = "select distinct ps.pmsWaveId, pr.UserId as userId, pu.EmailAddress as userMail from BI_ProjectSummary ps inner join V_PMS_Project_Role_User pr on pr.projectId = ps.pmsProjectId inner join V_PMS_Role po on po.id = pr.roleId inner join PASSPORT_User pu on pu.UserId = pr.UserId where po.buildinRoleCode = 'NPI' and ps.pmsWaveId in (:ids)";
		SQLQuery q = getSession().createSQLQuery(hql);
		q.setResultTransformer(Transformers.aliasToBean(NPI.class));
		q.addScalar("userId", StandardBasicTypes.STRING);
		q.addScalar("pmsWaveId", StandardBasicTypes.INTEGER);
		q.addScalar("userMail", StandardBasicTypes.STRING);
		q.setParameterList("ids", waveIds);
		List<NPI> raw = q.list();
		Map<Integer, List<NPI>> map = new HashMap<Integer, List<NPI>>();

		for (NPI npi : raw) {
			if (map.get(npi.getPmsWaveId()) == null) {
				List<NPI> l = new ArrayList<NPI>();
				l.add(npi);
				map.put(npi.getPmsWaveId(), l);
			} else {
				map.get(npi.getPmsWaveId()).add(npi);
			}
		}
		return map;
	}

	@Override
	public Map<Integer, List<String>> getNPIByWaveIds(List<Integer> waveIds) {

		Map<Integer, List<NPI>> npiMap = getNPIByWaveIds((Integer[]) waveIds.toArray(new Integer[] {}));

		if (npiMap == null) {
			return null;
		}

		Map<Integer, List<String>> map = new HashMap<Integer, List<String>>();

		Iterator<Integer> it = npiMap.keySet().iterator();
		while (it.hasNext()) {
			Integer waveId = it.next();
			List<NPI> npis = npiMap.get(waveId);
			if (npis != null && !npis.isEmpty()) {
				List<String> userIds = new ArrayList<String>();
				for (NPI npi : npis) {
					userIds.add(npi.getUserId());
				}
				if (map.get(waveId) == null) {
					List<String> l = new ArrayList<String>();
					l.addAll(userIds);
					map.put(waveId, l);
				} else {
					map.get(waveId).addAll(userIds);
				}
			}

		}

		return map;
	}

	@Override
	public List<String> getNPIByConditions(OverviewSearchForm form, NPIPhase phase) {
		StringBuilder hql = new StringBuilder(
				"select distinct pr.UserId from V_PMS_Project_Role_User pr inner join BI_ProjectSummary ps on pr.projectId = ps.PMSProjectId inner join V_PMS_Role po on po.id = pr.roleId where  po.buildinRoleCode = 'NPI' ");
		hql.append(" and ((ps.startDate >= :start and ps.startDate <= :end) or (ps.endDate >= :start and ps.endDate <= :end)) ");

		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			hql.append(" and ps.pmsWaveId in (:ids)");
		}

		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			hql.append(" and ps.pmsProjectId in (select distinct projectId from V_PMS_Project_Role_User where userId = :userId)");
		}

		if (NPIPhase.ttm == phase) {
			if (null != form.getGridType() && form.getGridType() != Status.All) {
				hql.append(" and ps.TTM_Status = :status");
			}

			if (null != form.getRisk() && form.getRisk() != Risk.All) {
				hql.append(" and ps.TTMRisk = :risk");
			}

			if (null != form.getSuccess() && form.getSuccess() != Success.All && form.getSuccessDelay() != null) {
				if (form.getSuccess() == Success.On_Schedule) {
					hql.append(" and ps.TTMSuccessDelay = 0");
				} else if (form.getSuccess() == Success.Delay_Greater_than_NUM_Days) {
					hql.append(" and ps.TTMSuccessDelay > ");
					hql.append(form.getSuccessDelay());
				} else {
					hql.append(" and ps.TTMSuccessDelay <= ");
					hql.append(form.getSuccessDelay());
				}
			}
		} else if(NPIPhase.sgaTtv == phase){
			if (null != form.getSgaGridType() && form.getSgaGridType() != Status.All) {
				hql.append(" and ps.SGA_TTV_Status = :sgaStatus");
			}

			if (null != form.getSgaRisk() && form.getSgaRisk() != Risk.All) {
				hql.append(" and ps.SGA_TTVRisk = :sgaRisk");
			}
		} else {
			if (null != form.getGridType() && form.getGridType() != Status.All) {
				hql.append(" and ps.TTV_Status = :status");
			}

			if (null != form.getRisk() && form.getRisk() != Risk.All) {
				hql.append(" and ps.TTVRisk = :risk");
			}
		}

		SQLQuery q = getSession().createSQLQuery(hql.toString());
		q.addScalar("UserId", StandardBasicTypes.STRING);
		q.setDate("start", form.getDurationFrom());
		q.setDate("end", form.getDurationTo());
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			q.setParameterList("ids", form.getWaveIds().toArray());
		}
		if(NPIPhase.sgaTtv == phase){
			if (null != form.getSgaGridType() && form.getSgaGridType() != Status.All) {
				q.setString("sgaStatus", form.getSgaGridType().name());
			}
			if (null != form.getSgaRisk() && form.getSgaRisk() != Risk.All) {
				q.setBoolean("sgaRisk", form.getSgaRisk().isRisk());
			}
		}else{
			if (null != form.getGridType() && form.getGridType() != Status.All) {
				q.setString("status", form.getGridType().name());
			}
			if (null != form.getRisk() && form.getRisk() != Risk.All) {
				q.setBoolean("risk", form.getRisk().isRisk());
			}
		}
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			q.setString("userId", form.getCurrentUserId());
		}
		List<String> raw = q.list();
		return raw;
	}

	@Override
	public void saveProductSummary(List<ProjectSummary> projectSummaries) {
		for (ProjectSummary ps : projectSummaries) {
			getSession().save(ps);
		}
	}

	@Override
	public void deleteProductSummaryByVersionDate(Date versionDate) {
		StringBuilder sql = new StringBuilder("delete from BI_ProjectSummary where VersionDate = :versionDate");
		SQLQuery q = getSession().createSQLQuery(sql.toString());
		q.setDate("versionDate", versionDate);
		q.executeUpdate();
	}

	@Override
	public ProjectSummary getProductInfoByWaveId(Integer pmsWaveId, Date versionDate) {
		StringBuffer hql = new StringBuffer();
		hql.append("select new ProjectSummary(ps.pmsWaveId, ps.doi,").append("ps.defects, ps.fpy, ps.odm, ps.tooling,")
				.append("ps.isTTMRisk, ps.ttmDelays, ps.isTTVRisk,").append("ps.pmsProjectId, ps.startDate, ps.productName,")
				.append("ps.waveName, ps.ttmStatus, ps.ttvStatus,").append("ps.ttmTargetDate, ps.ttmSignOffDate, ps.ttvTargetDate,")
				.append("ps.ttvSignOffDate, ps.ttvTarget, ps.estimatedTTV,").append("ps.actualTTV, ps.family, ps.obe,")
				.append("ps.pm, ps.versionDate, ps.svtPlanDate, ps.sovpPlanDate, ps.isProjectPlanned, ps.obeTarget, ps.ttmTargetDateDemand,ps.currentPhase, ")
				.append("ps.sgaTtvTargetDate, ps.sgaTtvStatus,ps.isSgaTtvRisk,ps.sgaTtvSignOffDate,ps.sgaTtvTarget,ps.sgaEstimatedTTV,ps.sgaActualTTV,ps.fpyTarget)")
				.append(" from ProjectSummary ps where ps.pmsWaveId = :waveId");
		if(versionDate != null){
			hql.append(" and ps.versionDate = :versionDate");
		}else{
			hql.append(" and not exists(select 1 from ProjectSummary  where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,versionDate,ps.versionDate)<0 )");
		}
		Query q = getSession().createQuery(hql.toString());
		q.setInteger("waveId", pmsWaveId);
		if(versionDate != null){
			q.setDate("versionDate", versionDate);
		}
		return q.list().size() > 0 ? (ProjectSummary) q.list().get(0) : null;
	}

	@Deprecated
	@Override
	public List<ProjectSummary> getProductByStatus(List<String> status, Date versionDate) {
		StringBuffer sql = new StringBuffer();
		sql.append("select ps.pmsWaveId, ps.doi,").append("ps.GatingDefects as defects, ps.fpy, ps.ODM as odm, ps.tooling,")
				.append("ps.TTMRisk as isTTMRisk, ps.TTMSuccessDelay as ttmDelays, ps.TTVRisk as isTTVRisk,")
				.append("ps.pmsProjectId, ps.startDate, ps.productName,").append("ps.waveName, ps.TTM_Status as ttmStatus, ps.TTV_Status as ttvStatus,")
				.append("ps.ttmTargetDate, ps.ttmSignOffDate, ps.ttvTargetDate,").append("ps.ttvSignOffDate, ps.ttvTarget, ps.estimatedTTV,")
				.append("ps.actualTTV, ps.family, ps.obe,")
				.append("ps.pm, ps.versionDate, ps.svtPlanDate, ps.sovpPlanDate, ps.isProjectPlanned, ps.obeTarget, ps.ttmTargetDateDemand, ")
				.append("ps.SGA_TTV_Status as sgaTtvStatus, ps.SGA_TTVRisk as isSgaTtvRisk, ps.SGA_ttvTargetDate as sgaTtvTargetDate, ")
				.append("ps.SGA_ttvSignOffDate as sgaTtvSignOffDate, ps.SGA_TTVTarget as sgaTtvTarget, ps.SGA_EstimatedTTV as sgaEstimatedTTV, ps.SGA_ActualTTV as sgaActualTTV ")
				.append("from BI_ProjectSummary ps where ps.TTM_Status in (:statusList) and ps.versionDate = :versionDate").append(" union (")
				.append("select ps.pmsWaveId, ps.doi,").append("ps.GatingDefects as defects, ps.FPY, ps.ODM as odm, ps.Tooling,")
				.append("ps.TTMRisk as isTTMRisk, ps.TTMSuccessDelay as ttmDelays, ps.TTVRisk as isTTVRisk,")
				.append("ps.PMSProjectId, ps.startDate, ps.productName,").append("ps.waveName, ps.TTM_Status as ttmStatus, ps.TTV_Status as ttvStatus,")
				.append("ps.ttmTargetDate, ps.ttmSignOffDate, ps.ttvTargetDate,").append("ps.ttvSignOffDate, ps.ttvTarget, ps.estimatedTTV,")
				.append("ps.actualTTV, ps.family, ps.obe,")
				.append("ps.pm, ps.versionDate, ps.svtPlanDate, ps.sovpPlanDate, ps.isProjectPlanned, ps.obeTarget, ps.ttmTargetDateDemand, ")
				.append("ps.SGA_TTV_Status as sgaTtvStatus, ps.SGA_TTVRisk as isSgaTtvRisk, ps.SGA_ttvTargetDate as sgaTtvTargetDate, ")
				.append("ps.SGA_ttvSignOffDate as sgaTtvSignOffDate, ps.SGA_TTVTarget as sgaTtvTarget, ps.SGA_EstimatedTTV as sgaEstimatedTTV, ps.SGA_ActualTTV as sgaActualTTV ")
				.append("from BI_ProjectSummary ps where ps.TTV_Status in (:statusList) and ps.versionDate = :versionDate )");
		sql.append(" union (")
		.append("select ps.pmsWaveId, ps.doi,").append("ps.GatingDefects as defects, ps.FPY, ps.ODM as odm, ps.Tooling,")
		.append("ps.TTMRisk as isTTMRisk, ps.TTMSuccessDelay as ttmDelays, ps.TTVRisk as isTTVRisk,")
		.append("ps.PMSProjectId, ps.startDate, ps.productName,").append("ps.waveName, ps.TTM_Status as ttmStatus, ps.TTV_Status as ttvStatus,")
		.append("ps.ttmTargetDate, ps.ttmSignOffDate, ps.ttvTargetDate,").append("ps.ttvSignOffDate, ps.ttvTarget, ps.estimatedTTV,")
		.append("ps.actualTTV, ps.family, ps.obe,")
		.append("ps.pm, ps.versionDate, ps.svtPlanDate, ps.sovpPlanDate, ps.isProjectPlanned, ps.obeTarget, ps.ttmTargetDateDemand, ")
		.append("ps.SGA_TTV_Status as sgaTtvStatus, ps.SGA_TTVRisk as isSgaTtvRisk, ps.SGA_ttvTargetDate as sgaTtvTargetDate, ")
		.append("ps.SGA_ttvSignOffDate as sgaTtvSignOffDate, ps.SGA_TTVTarget as sgaTtvTarget, ps.SGA_EstimatedTTV as sgaEstimatedTTV, ps.SGA_ActualTTV as sgaActualTTV ")
		.append("from BI_ProjectSummary ps where ps.SGA_TTV_Status in (:statusList) and ps.versionDate = :versionDate )");
		Query q = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(ProjectSummary.class));

		q.setParameterList("statusList", status);
		q.setDate("versionDate", versionDate);
		return q.list();
	}

	@Override
	public List<ProjectSummary> getPrevSummary(Date versionDate) {
		
		StringBuffer sql = new StringBuffer();
		sql.append("select ps.pmsWaveId, ps.doi,").append("ps.GatingDefects as defects, ps.FPY as fpy, ps.ODM as odm, ps.Tooling,")
		.append("ps.TTMRisk as isTTMRisk, ps.TTMSuccessDelay as ttmDelays, ps.TTVRisk as isTTVRisk,")
		.append("ps.PMSProjectId as pmsProjectId, ps.startDate, ps.productName,").append("ps.waveName, ps.TTM_Status as ttmStatus, ps.TTV_Status as ttvStatus,")
		.append("ps.ttmTargetDate, ps.ttmSignOffDate, ps.ttvTargetDate,").append("ps.ttvSignOffDate, ps.ttvTarget, ps.estimatedTTV,")
		.append("ps.actualTTV, ps.family, ps.obe,")
		.append("ps.pm, ps.versionDate, ps.svtPlanDate, ps.sovpPlanDate, ps.isProjectPlanned, ps.obeTarget, ps.ttmTargetDateDemand, ")
		.append("ps.SGA_TTV_Status as sgaTtvStatus, ps.SGA_TTVRisk as isSgaTtvRisk, ps.SGA_ttvTargetDate as sgaTtvTargetDate, ")
		.append("ps.SGA_ttvSignOffDate as sgaTtvSignOffDate, ps.SGA_TTVTarget as sgaTtvTarget, ps.SGA_EstimatedTTV as sgaEstimatedTTV, ps.SGA_ActualTTV as sgaActualTTV ")
		.append("from BI_ProjectSummary ps, (select MAX(VersionDate) as versiondate from BI_ProjectSummary ps where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(DAY, VersionDate, :versionDate) > 0) d")
		.append(" where ps.VersionDate = d.versiondate ");
		Query q = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(ProjectSummary.class));

		q.setDate("versionDate", versionDate);
		return q.list();
	}
	@Override
	public boolean isTheProductNpi(String userId, String pmsProductId) {
		StringBuffer sb = new StringBuffer("select count(projectId) from V_PMS_Project_Role_User where userId = '")
		.append(userId).append("' and projectId=").append(pmsProductId);
		Query q = getSession().createSQLQuery(sb.toString());
		Integer count = (Integer) q.uniqueResult();
		if(count != null && count.compareTo(0) > 0){
			return true;
		}else{
			return false;
		}
	}
}
