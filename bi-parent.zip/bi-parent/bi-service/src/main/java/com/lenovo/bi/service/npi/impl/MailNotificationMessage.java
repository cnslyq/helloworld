package com.lenovo.bi.service.npi.impl;

import com.lenovo.common.email.NotificationMessage;

public class MailNotificationMessage extends NotificationMessage {

	@Override
	public String getTemplateId() {
		return "notification_default";
	}

}
