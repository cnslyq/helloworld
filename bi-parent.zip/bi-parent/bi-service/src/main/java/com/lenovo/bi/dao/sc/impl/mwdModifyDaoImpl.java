package com.lenovo.bi.dao.sc.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.formula.functions.T;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.dao.sc.MWDModifyDao;
import com.lenovo.bi.form.sc.mwd.SearchMWDForm;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.sc.mwd.MWDModifyDetailView;

@Repository
public class mwdModifyDaoImpl extends HibernateBaseDaoImplBi<T> implements MWDModifyDao {

	@Override
	public List<MWDModifyDetailView> getMWDModifyDetail(SearchMWDForm form) {
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append(" select odm,UIKey,commodity,commodityValue,purchaseType,odmMWD,lenovoMWD,manualMWD ");
		sBuffer.append(" from BI_WeeklyMWD mwd where 1=1 ");
		
		if(!"-1".equals(form.getPurchaseType())){
			sBuffer.append(" and mwd.purchaseType= '"+form.getPurchaseType()+"'");
		}
		
		if(StringUtils.isNotBlank(form.getComponents())){
			sBuffer.append(" and mwd.commodity in ("+getComponents(form.getComponents())+")");
		}
		
		if(StringUtils.isNotBlank(form.getComponentsValue())){
			sBuffer.append(" and mwd.commodityValue in (:valueList)");
		}
		
		if(form.getMwdTypeKey()==1){
			sBuffer.append(" and isnull(mwd.odmMWD,0) > isnull(lenovoMWD,0) ");
		}
		
		if(form.getMwdTypeKey()==2){
			sBuffer.append(" and isnull(mwd.odmMWD,0) <= isnull(lenovoMWD,0) ");
		}
		
		Query q=getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE)
					.addScalar("UIKey", IntegerType.INSTANCE)
					.addScalar("commodity", StringType.INSTANCE)
					.addScalar("commodityValue", StringType.INSTANCE)
					.addScalar("purchaseType", StringType.INSTANCE)
					.addScalar("odmMWD", IntegerType.INSTANCE)
					.addScalar("lenovoMWD", IntegerType.INSTANCE)
					.addScalar("manualMWD", IntegerType.INSTANCE)
					.setResultTransformer(Transformers.aliasToBean(MWDModifyDetailView.class));
		q.setFirstResult((form.getCurrentPage()-1)*SysConfig.NUMBER_OF_ROW_COUNT);//SysConfig.NUMBER_OF_ROW_COUNT
		q.setMaxResults(SysConfig.NUMBER_OF_ROW_COUNT);
		if(StringUtils.isNotBlank(form.getComponentsValue())){
			q.setParameterList("valueList", form.getComponentsValue().split(","));
		}
		return q.list();
	}

	@Override
	public int getMWDModifyDetailCount(SearchMWDForm form) {
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append(" select count(*) ");
		sBuffer.append(" from BI_WeeklyMWD mwd where 1=1 ");
			
		if(!"-1".equals(form.getPurchaseType())){
			sBuffer.append(" and mwd.purchaseType= '"+form.getPurchaseType()+"'");
		}
		
		if(StringUtils.isNotBlank(form.getComponents())){
			sBuffer.append(" and mwd.commodity in ("+getComponents(form.getComponents())+")");
		}
		
		if(StringUtils.isNotBlank(form.getComponentsValue())){
			sBuffer.append(" and mwd.commodityValue in (:valueList)");
		}
		
		if(form.getMwdTypeKey()==1){
			sBuffer.append(" and isnull(mwd.odmMWD,0) > isnull(lenovoMWD,0) ");
		}
		
		if(form.getMwdTypeKey()==2){
			sBuffer.append(" and isnull(mwd.odmMWD,0) <= isnull(lenovoMWD,0) ");
		}
		
		Query q=getSession().createSQLQuery(sBuffer.toString());
		if(StringUtils.isNotBlank(form.getComponentsValue())){
			q.setParameterList("valueList", form.getComponentsValue().split(","));
		}
		return (Integer) q.uniqueResult();
	}

	@Override
	public void updateMWD(Map<String, Object> map) {
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append(" update BI_WeeklyMWD set manualMWD=:mwd where UIKey=:key ");
		for(Entry<String,Object>entry:map.entrySet()){
			Query q=getSession().createSQLQuery(sBuffer.toString());
			q.setParameter("key", Integer.parseInt(entry.getKey()));
			String mwd=(String)entry.getValue();
			if(StringUtils.isNotBlank(mwd)){
				q.setParameter("mwd", Integer.parseInt(mwd));
			}else{
				q.setParameter("mwd", null);
			}
			
			q.executeUpdate();
		}
		getSession().flush();
	}
	
	public static String getComponents(String str){
		String[]arr=str.split(",");
		for(int i=0;i<arr.length;i++){
			arr[i]="'"+arr[i]+"'";
		}
		List<String>list=Arrays.asList(arr);
		String con=list.toString();
		return con.substring(1, con.length()-1);
	}
	
}

