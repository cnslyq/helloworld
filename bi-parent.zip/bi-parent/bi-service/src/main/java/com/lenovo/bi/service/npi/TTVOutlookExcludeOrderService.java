package com.lenovo.bi.service.npi;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.GeoData;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.form.npi.ttv.SearchExcludeOrderForm;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.view.npi.ttv.ExcludeOrderView;

public interface TTVOutlookExcludeOrderService {
	/**
	 * this method for pop up exclude order search
	 * @return
	 */
	public List<ExcludeOrderView> getExcludeOrdersByConditions(Integer waveId,SearchExcludeOrderForm searchExcludeOrderForm);
	
	/**
	 * this method for outlook grid
	 * @return
	 */
	public List<ExcludeOrderView> getExcludeOrdersGrid(Integer waveId, TTVPhase ttvPhase);
	
	public List<ExcludeOrderView> getExcludeOrdersGrid(Integer waveId, TTVPhase ttvPhase, Date versionDate);
	
	public List<NpiOrder> getNegativeExcludedOrder(Integer waveId, TTVPhase ttvPhase, Date versionDate);
	/**
	 * this method for update exclude orders base on user selected exclude orders
	 * @param selectedExcludeOrderIds
	 * @throws Exception 
	 */
	public void updateExcludeOrderBySelectedOrders(List<NpiOrder> orders, Integer waveId, TTVPhase ttvPhase);
	
//	public void updateExcludeOrderBySelectedOrders(List<NpiOrder> orders, Integer waveId);
	
	public List<NpiOrder> getExcludedOrder(int waveId);
	
	public List<GeoData> getGeoIdAndName();
	
	public List<GeoData> getRegionIdAndName(Integer geoId);

	public List<ExcludeOrderView> filterExcudeOrderByQueryCondition(
			List<ExcludeOrderView> excludeGrid,
			SearchExcludeOrderForm excludeForm);

	public List<ExcludeOrderView> filterExcudeOrderByPagination(
		List<ExcludeOrderView> excludeGrid,
		SearchExcludeOrderForm excludeForm,int pageSize);
	}
