package com.lenovo.bi.form.sc.ots;

import org.apache.commons.lang.StringUtils;

import com.lenovo.common.model.PagerInformation;

public class SearchOtsForm {

	private String currentRolMonth;
	private String startDate;
	private String endDate;
	private int orderTypeId;
	private int orderSubTypeId;
	private String orderTypeName;
	private String geoIds;
	private String regionIds;
	private String odmIds;
	private String productIds;
	private String familyIds;
	private String portfolioIds;
	private String detractorIds;
	private String level1Detractor;
	private String level2Detractor;
	private String selectMonth;

	private String dashboardType;
	private int dashboardTypeKey = -1;
	private String crossMonthType;
	private int crossMonthTypeKey = -1;

	private String ltfcType;
	private boolean isShowToolingWaste;
	
	private String faType;
	

	private String dimension;
	private int dimensionKey = -1;
	private String subDimension;
	private int subDimensionKey = -1;
	
	private String overViewDimension;
	private String overViewSubDimension;
	private int overViewSubDimensionKey = -1;
	private String remarkDimension;
	private String remarkSubDimension;
	private int remarkSubDimensionKey = -1;
	private String remarkSubDimensionKeys ;
	private String remarkSubDimensions ;

	private int geoKey = -1;//switch dashboard chart between geo and region
	
	private String durationFrom;
	private String durationTo;

	private String selectQuarter;
	private String quarterFrom;
	private String quarterTo;

	private int year;
	private int month;

	private boolean showGeoOverview;// or region overview
	private boolean showQuarterOverview;// or month overview
	private boolean showSalesOverview;// or MFG overview
	
	private boolean showCaTarget; //CA Overview
	private boolean showCaAchievement; //CA Overview
	private boolean showCtp; //CA Overview
	private boolean showCtpAchievement; //CA Overview
	private boolean showCommitment; //CA Overview
	
	private boolean showAllRemarkOrder ;
	private boolean showUnknownOrder ;
	private boolean showOverall ;

	private String chartType;// overview,dashboard,crossmonth
	private PagerInformation pagerInfo;
	
	private String scStatus;
	private int rowCount;
	private int endRow;
	
	private int orderNumber;
	
	private String poNumberItemOrderNo;
	private boolean showDashBoradCrossMonth ;
	
	private int currentPage;
	
	public boolean isShowDashBoradCrossMonth() {
		return showDashBoradCrossMonth;
	}

	public void setShowDashBoradCrossMonth(boolean showDashBoradCrossMonth) {
		this.showDashBoradCrossMonth = showDashBoradCrossMonth;
	}

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getFaType() {
		return faType;
	}

	public void setFaType(String faType) {
		this.faType = faType;
	}

	
	private int level;
	
	private String sortColumn;
	private String sortType;
	
	public int getOrderSubTypeId() {
		return orderSubTypeId;
	}

	public int getGeoKey() {
		return geoKey;
	}

	public void setGeoKey(int geoKey) {
		this.geoKey = geoKey;
	}

	public void setOrderSubTypeId(int orderSubTypeId) {
		this.orderSubTypeId = orderSubTypeId;
	}

	public boolean isShowSalesOverview() {
		return showSalesOverview;
	}

	public void setShowSalesOverview(boolean showSalesOverview) {
		this.showSalesOverview = showSalesOverview;
	}

	public boolean isShowToolingWaste() {
		return isShowToolingWaste;
	}

	public void setShowToolingWaste(boolean isShowToolingWaste) {
		this.isShowToolingWaste = isShowToolingWaste;
	}

	public String getLtfcType() {
		return ltfcType;
	}

	public void setLtfcType(String ltfcType) {
		this.ltfcType = ltfcType;
	}

	public String getFamilyIds() {
		return familyIds;
	}

	public void setFamilyIds(String familyIds) {
		this.familyIds = familyIds;
	}

	public String getSelectQuarter() {
		return selectQuarter;
	}

	public void setSelectQuarter(String selectQuarter) {
		this.selectQuarter = selectQuarter;
	}

	public String getDurationFrom() {
		return durationFrom;
	}

	public void setDurationFrom(String durationFrom) {
		this.durationFrom = durationFrom;
	}

	public String getDurationTo() {
		return durationTo;
	}

	public String getPortfolioIds() {
		return portfolioIds;
	}

	public void setPortfolioIds(String portfolioIds) {
		this.portfolioIds = portfolioIds;
	}

	public void setDurationTo(String durationTo) {
		this.durationTo = durationTo;
	}

	public String getQuarterFrom() {
		return quarterFrom;
	}

	public void setQuarterFrom(String quarterFrom) {
		this.quarterFrom = quarterFrom;
	}

	public String getQuarterTo() {
		return quarterTo;
	}

	public void setQuarterTo(String quarterTo) {
		this.quarterTo = quarterTo;
	}

	public boolean isShowGeoOverview() {
		return showGeoOverview;
	}

	public void setShowGeoOverview(boolean showGeoOverview) {
		this.showGeoOverview = showGeoOverview;
	}

	public int getDimensionKey() {
		return dimensionKey;
	}

	public boolean isShowQuarterOverview() {
		return showQuarterOverview;
	}

	public void setShowQuarterOverview(boolean showQuarterOverview) {
		this.showQuarterOverview = showQuarterOverview;
	}

	public void setDimensionKey(int dimensionKey) {
		this.dimensionKey = dimensionKey;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public String getChartType() {
		return chartType;
	}

	public void setChartType(String chartType) {
		this.chartType = chartType;
	}

	public PagerInformation getPagerInfo() {
		return pagerInfo;
	}

	public void setPagerInfo(PagerInformation pagerInfo) {
		this.pagerInfo = pagerInfo;
	}

	public int getSubDimensionKey() {
		return subDimensionKey;
	}

	public void setSubDimensionKey(int subDimensionKey) {
		this.subDimensionKey = subDimensionKey;
	}

	public String getDimension() {
		return dimension;
	}

	public void setDimension(String dimension) {
		this.dimension = dimension;
	}

	public String getSubDimension() {
		return subDimension;
	}

	public void setSubDimension(String subDimension) {
		this.subDimension = subDimension;
	}

	public String getOverViewSubDimension() {
		return overViewSubDimension;
	}

	public void setOverViewSubDimension(String overViewSubDimension) {
		this.overViewSubDimension = overViewSubDimension;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public int getOrderTypeId() {
		return orderTypeId;
	}

	public void setOrderTypeId(int orderTypeId) {
		this.orderTypeId = orderTypeId;
	}

	public String getGeoIds() {
		return geoIds;
	}

	public void setGeoIds(String geoIds) {
		this.geoIds = geoIds;
	}

	public String getRegionIds() {
		return regionIds;
	}

	public void setRegionIds(String regionIds) {
		this.regionIds = regionIds;
	}

	public String getOdmIds() {
		return odmIds;
	}

	public void setOdmIds(String odmIds) {
		this.odmIds = odmIds;
	}

	public String getProductIds() {
		return productIds;
	}

	public void setProductIds(String productIds) {
		this.productIds = productIds;
	}

	public String getSelectMonth() {
		return selectMonth;
	}

	public void setSelectMonth(String selectMonth) {
		this.selectMonth = selectMonth;
	}

	public String getDashboardType() {
		return dashboardType;
	}

	public void setDashboardType(String dashboardType) {
		this.dashboardType = dashboardType;
	}

	public int getDashboardTypeKey() {
		return dashboardTypeKey;
	}

	public void setDashboardTypeKey(int dashboardTypeKey) {
		this.dashboardTypeKey = dashboardTypeKey;
	}

	public String getCrossMonthType() {
		return crossMonthType;
	}

	public void setCrossMonthType(String crossMonthType) {
		this.crossMonthType = crossMonthType;
	}

	public int getCrossMonthTypeKey() {
		return crossMonthTypeKey;
	}

	public void setCrossMonthTypeKey(int crossMonthTypeKey) {
		this.crossMonthTypeKey = crossMonthTypeKey;
	}

	public String getOrderTypeName() {
		return orderTypeName;
	}

	public void setOrderTypeName(String orderTypeName) {
		this.orderTypeName = orderTypeName;
	}

	public String getScStatus() {
		return scStatus;
	}

	public void setScStatus(String scStatus) {
		this.scStatus = scStatus;
	}

	public String getDetractorIds() {
		return detractorIds;
	}

	public void setDetractorIds(String detractorIds) {
		this.detractorIds = detractorIds;
	}

	public String getLevel1Detractor() {
		return level1Detractor;
	}

	public void setLevel1Detractor(String level1Detractor) {
		this.level1Detractor = level1Detractor;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getLevel2Detractor() {
		return level2Detractor;
	}

	public void setLevel2Detractor(String level2Detractor) {
		this.level2Detractor = level2Detractor;
	}

	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getSortType() {
		if(StringUtils.isBlank(this.sortType)){
			this.setSortType("asc");
		}
		return sortType;
	}
	
	public String getReversalSortType() {
		if(StringUtils.isNotBlank(this.sortType)){
			if("asc".equals(this.sortType.toLowerCase())){
				return "desc";
			}else{
				return "asc";
			}
		}else{
			return "desc";
		}
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}
	

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getEndRow() {
		return endRow;
	}

	public void setEndRow(int endRow) {
		this.endRow = endRow;
	}
	
	public boolean isShowAllRemarkOrder() {
		return showAllRemarkOrder;
	}

	public void setShowAllRemarkOrder(boolean showAllRemarkOrder) {
		this.showAllRemarkOrder = showAllRemarkOrder;
	}
	
	public String getPoNumberItemOrderNo() {
		return poNumberItemOrderNo;
	}

	public void setPoNumberItemOrderNo(String poNumberItemOrderNo) {
		this.poNumberItemOrderNo = poNumberItemOrderNo;
	}
	
	public boolean isShowUnknownOrder() {
		return showUnknownOrder;
	}

	public void setShowUnknownOrder(boolean showUnknownOrder) {
		this.showUnknownOrder = showUnknownOrder;
	}

	public String getOverViewDimension() {
		return overViewDimension;
	}

	public void setOverViewDimension(String overViewDimension) {
		this.overViewDimension = overViewDimension;
	}

	public int getOverViewSubDimensionKey() {
		return overViewSubDimensionKey;
	}

	public void setOverViewSubDimensionKey(int overViewSubDimensionKey) {
		this.overViewSubDimensionKey = overViewSubDimensionKey;
	}

	public String getRemarkDimension() {
		return remarkDimension;
	}

	public void setRemarkDimension(String remarkDimension) {
		this.remarkDimension = remarkDimension;
	}

	public int getRemarkSubDimensionKey() {
		return remarkSubDimensionKey;
	}

	public void setRemarkSubDimensionKey(int remarkSubDimensionKey) {
		this.remarkSubDimensionKey = remarkSubDimensionKey;
	}

	public String getRemarkSubDimension() {
		return remarkSubDimension;
	}

	public void setRemarkSubDimension(String remarkSubDimension) {
		this.remarkSubDimension = remarkSubDimension;
	}
	
	public String getRemarkSubDimensionKeys() {
		return remarkSubDimensionKeys;
	}

	public void setRemarkSubDimensionKeys(String remarkSubDimensionKeys) {
		this.remarkSubDimensionKeys = remarkSubDimensionKeys;
	}
	
	public String getRemarkSubDimensions() {
		return remarkSubDimensions;
	}

	public void setRemarkSubDimensions(String remarkSubDimensions) {
		this.remarkSubDimensions = remarkSubDimensions;
	}
	
	public boolean isShowOverall() {
		return showOverall;
	}

	public void setShowOverall(boolean showOverall) {
		this.showOverall = showOverall;
	}

	public boolean isShowCtp() {
		return showCtp;
	}

	public void setShowCtp(boolean showCtp) {
		this.showCtp = showCtp;
	}

	public boolean isShowCtpAchievement() {
		return showCtpAchievement;
	}

	public void setShowCtpAchievement(boolean showCtpAchievement) {
		this.showCtpAchievement = showCtpAchievement;
	}

	public boolean isShowCommitment() {
		return showCommitment;
	}

	public void setShowCommitment(boolean showCommitment) {
		this.showCommitment = showCommitment;
	}

	public boolean isShowCaTarget() {
		return showCaTarget;
	}

	public void setShowCaTarget(boolean showCaTarget) {
		this.showCaTarget = showCaTarget;
	}

	public boolean isShowCaAchievement() {
		return showCaAchievement;
	}

	public void setShowCaAchievement(boolean showCaAchievement) {
		this.showCaAchievement = showCaAchievement;
	}

	public String getCurrentRolMonth() {
		return currentRolMonth;
	}

	public void setCurrentRolMonth(String currentRolMonth) {
		this.currentRolMonth = currentRolMonth;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	
}