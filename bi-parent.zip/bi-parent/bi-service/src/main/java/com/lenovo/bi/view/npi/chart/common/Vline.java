package com.lenovo.bi.view.npi.chart.common;

import com.lenovo.bi.util.SysConfig;


public class Vline extends CategoryParent {

	private String vline;
	private String label;
	private String dashed;//'0/1'(是否使用虚线)
	private String linePosition;//'0/1'(line的位置)
	private String labelPosition;//'0/1'(label的位置)
	private String showLabelBorder;//'0/1'(是否显示label的边框)
	private String labelHAlign;//'left/center/right'(水平线label的位置)
	private String labelVAlign;//'top/middle/bottom'(垂直线label的位置)
	private String dashLen;//'Number'(虚线的长度)
	private String thickness;

	
	public Vline() {
		this.vline = SysConfig.VLINE_VLINE;
		this.label = SysConfig.VLINE_LABEL;
		this.dashed = SysConfig.VLINE_DASHED;
		this.linePosition = SysConfig.VLINE_LINEPOSITION;
		this.labelPosition = SysConfig.VLINE_LABELPOSITION;
		this.showLabelBorder = SysConfig.VLINE_SHOWLABELBORDER;
		this.labelHAlign = SysConfig.VLINE_LABELHALIGN;
		this.labelVAlign = SysConfig.VLINE_LABELVALIGN;
		this.dashLen = SysConfig.VLINE_DASHLEN;
	}
	
	public String getThickness() {
		return thickness;
	}



	public void setThickness(String thickness) {
		this.thickness = thickness;
	}



	public String getVline() {
		return vline;
	}

	public void setVline(String vline) {
		this.vline = vline;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getLabelPosition() {
		return labelPosition;
	}

	public void setLabelPosition(String labelPosition) {
		this.labelPosition = labelPosition;
	}

	public String getDashed() {
		return dashed;
	}

	public void setDashed(String dashed) {
		this.dashed = dashed;
	}

	public String getLinePosition() {
		return linePosition;
	}

	public String getDashLen() {
		return dashLen;
	}

	public void setDashLen(String dashLen) {
		this.dashLen = dashLen;
	}

	public void setLinePosition(String linePosition) {
		this.linePosition = linePosition;
	}

	public String getShowLabelBorder() {
		return showLabelBorder;
	}

	public void setShowLabelBorder(String showLabelBorder) {
		this.showLabelBorder = showLabelBorder;
	}

	public String getLabelHAlign() {
		return labelHAlign;
	}

	public void setLabelHAlign(String labelHAlign) {
		this.labelHAlign = labelHAlign;
	}

	public String getLabelVAlign() {
		return labelVAlign;
	}

	public void setLabelVAlign(String labelVAlign) {
		this.labelVAlign = labelVAlign;
	}

}
