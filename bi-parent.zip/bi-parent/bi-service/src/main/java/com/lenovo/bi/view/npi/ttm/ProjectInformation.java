package com.lenovo.bi.view.npi.ttm;


public class ProjectInformation {
	private Integer productId;
	private String pmName;
	private String productName;
	private String npiNames;
	
	public String getNpiNames() {
		return npiNames;
	}
	public void setNpiNames(String npiNames) {
		this.npiNames = npiNames;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getPmName() {
		return pmName;
	}
	public void setPmName(String pmName) {
		this.pmName = pmName;
	}
}
