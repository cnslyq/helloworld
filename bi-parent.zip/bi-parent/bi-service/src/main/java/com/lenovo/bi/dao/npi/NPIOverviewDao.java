package com.lenovo.bi.dao.npi;

import java.util.List;

import com.lenovo.bi.dto.ProductDataForPopup;
import com.lenovo.bi.dto.TTMProduct;
import com.lenovo.bi.dto.TTVProduct;
import com.lenovo.bi.enumobj.NPIPhase;
import com.lenovo.bi.form.npi.SearchProductsFormForPopUp;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
import com.lenovo.common.model.NameValuePair;
import com.lenovo.common.model.PagerInformation;

public interface NPIOverviewDao {

	public List<NameValuePair> getProjectStatusByPhase(NPIPhase phase, OverviewSearchForm form);

	public List<NameValuePair> getRiskStatusByPhase(NPIPhase phase, OverviewSearchForm form);

	public List<Integer> getSuccessDelays(OverviewSearchForm form);

	public List<TTMProduct> getTTMProductsByConditions(OverviewSearchForm form, PagerInformation pageInfo);

	public int getTTMProductCountByConditions(OverviewSearchForm form);

	public List<ProductDataForPopup> getPopupGridDataByConditions(SearchProductsFormForPopUp form);

	public List<TTVProduct> getTTVProductsByConditions(OverviewSearchForm form, PagerInformation pagerInfo);

	public List<TTMProduct> getTTMProductsByConditions(OverviewSearchForm form);

	public List<TTMProduct> getRedTTMProductsByConditions(OverviewSearchForm form);

	public int getTTVProductCountByConditions(OverviewSearchForm form);

	public List<ProductDataForPopup> getPopupGridDataForDoi(SearchProductsFormForPopUp searchProductForm);
	
	public String getPmsProjectIdByPmsWaveId(String waveId);

}
