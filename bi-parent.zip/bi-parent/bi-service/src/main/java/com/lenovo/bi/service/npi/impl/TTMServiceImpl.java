package com.lenovo.bi.service.npi.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.common.OdmCapacityDao;
import com.lenovo.bi.dao.common.ToolingCapacityDao;
import com.lenovo.bi.dao.npi.NPIOverviewDao;
import com.lenovo.bi.dao.npi.NPIProductSummaryDao;
import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.dto.OdmCapacityPlanDetail;
import com.lenovo.bi.dto.ProductDataForPopup;
import com.lenovo.bi.dto.TTMDemandDetail;
import com.lenovo.bi.dto.TTMProduct;
import com.lenovo.bi.dto.ToolingCapacityDetail;
import com.lenovo.bi.dto.WeeklyComponentCommitment;
import com.lenovo.bi.engine.OdmCapacityCalculator;
import com.lenovo.bi.enumobj.NPIPhase;
import com.lenovo.bi.enumobj.Risk;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.enumobj.Success;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.form.npi.SearchProductsFormForPopUp;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
import com.lenovo.bi.form.npi.ttm.SearchSearchProductGridProductsForm;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.service.common.MasterDataService;
import com.lenovo.bi.service.npi.NPIDefectService;
import com.lenovo.bi.service.npi.TTMService;
import com.lenovo.bi.service.npi.helper.NPIDOIHelper;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.CommonUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.npi.ProductViewForPopUp;
import com.lenovo.bi.view.npi.ProductWave;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.chart.pie.PieSlice;
import com.lenovo.bi.view.npi.ttm.DefectView;
import com.lenovo.bi.view.npi.ttm.DoiGrid;
import com.lenovo.bi.view.npi.ttm.OdmCapacity;
import com.lenovo.bi.view.npi.ttm.OdmCapacityGrid;
import com.lenovo.bi.view.npi.ttm.ProjectInformation;
import com.lenovo.bi.view.npi.ttm.TTMProductDetail;
import com.lenovo.bi.view.npi.ttm.ToolingCapacityGrid;
import com.lenovo.bi.view.npi.ttm.ToolingCovers;
import com.lenovo.bi.view.npi.ttm.ToolingStatus;
import com.lenovo.bi.view.npi.ttm.TtmGridProduct;
import com.lenovo.common.model.NameValuePair;
import com.lenovo.common.model.Pager;
import com.lenovo.common.model.PagerInformation;

@Service("tTMService")
public class TTMServiceImpl implements TTMService {
	@Inject
	private NPIOverviewDao nPIOverviewDao;
	@Inject
	public NPIProductSummaryDao nPIProductSummaryDao;
	@Inject
	private NPIDefectService npiDefectService;
	@Inject
	private OdmCapacityDao odmCapacityDao;
	@Inject
	private ToolingCapacityDao toolingCapacityDao;
	@Inject
	private MasterDataService masterDataService;
	@Inject
	private NPIDOIHelper npidoiHelper;

	@Inject
	private OdmCapacityCalculator odmCapacityCalculator;

	@Override
	public Pager<TtmGridProduct> getProductsByConditions(OverviewSearchForm form) {

		Pager<TtmGridProduct> pager = new Pager<TtmGridProduct>();
		PagerInformation info = new PagerInformation();
		pager.setPagerInfo(info);
		info.setCurrentPage(form.getCurrentPage());
		info.setPageSize(masterDataService.getThresholdByName(
				Threshold.PAGE_SIZE.name()).intValue());

		List<TTMProduct> rawList = nPIOverviewDao.getTTMProductsByConditions(
				form, pager.getPagerInfo());

		List<TtmGridProduct> list = convert2Pojo(rawList);

		pager.setDatas(list);

		int recordCount = nPIOverviewDao.getTTMProductCountByConditions(form);
		info.setRecordCount(recordCount);

		return pager;
	}

	private List<TtmGridProduct> convert2Pojo(List<TTMProduct> rawList) {

		List<TtmGridProduct> list = new ArrayList<TtmGridProduct>();
		List<Integer> waveIds = new ArrayList<Integer>();

		for (TTMProduct ttmProduct : rawList) {
			TtmGridProduct tp = new TtmGridProduct();
			waveIds.add(ttmProduct.getNpiWaveId());
			tp.setWaveId(ttmProduct.getNpiWaveId());
			tp.setProductId(ttmProduct.getProjectId());
			tp.setWaveName(ttmProduct.getWaveName());
			tp.setProductName(ttmProduct.getProductName());
			tp.setDoiLight(ttmProduct.getDoi());
			tp.setGatingDefectsLight(ttmProduct.getDefects());
			tp.setOdmLight(ttmProduct.getOdm());
			tp.setFpyLight(ttmProduct.getFpy());
			tp.setToolingLight(ttmProduct.getTooling());
			tp.setCurrentPhase(ttmProduct.getCurrentPhase());
			tp.setPmOwner(ttmProduct.getPm());
			try {
				tp.setStartDate(CalendarUtil.date2String(ttmProduct
						.getStartDate()));
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Status s = null;
			if (ttmProduct.getTtmStatus() != null) {
				s = Status.valueOf(ttmProduct.getTtmStatus());
				tp.setStatusColor(s.getLabelColor());
				tp.setStatus(s.toString());
				if (s == Status.In_Progress) {
					if (ttmProduct.isRisk()) {
						tp.setRisk(Risk.Risk.toString());
						tp.setRiskColor(Risk.Risk.getLabelColor());
					} else {
						tp.setRisk(Risk.No_Risk.toString());
						tp.setRiskColor(Risk.No_Risk.getLabelColor());
					}
				}
			}
			if (s == Status.Success) {
				int delay = masterDataService.getThresholdByName(
						Threshold.TTM_SUCCESS_THRESHOLD.name()).intValue();
				if (ttmProduct.getSuccessDelays() <= 0) {
					tp.setSuccessStatus(Success.On_Schedule.toString());
					tp.setSuccessColor(Success.On_Schedule.getLabelColor());
				} else if (ttmProduct.getSuccessDelays() > delay) {
					tp.setSuccessStatus(CommonUtil.SuccessStatusReplace(
							Success.Delay_Greater_than_NUM_Days, delay));
					tp.setSuccessColor(Success.Delay_Greater_than_NUM_Days
							.getLabelColor());
				} else {
					tp.setSuccessStatus(CommonUtil.SuccessStatusReplace(
							Success.Delay_Less_than_NUM_Days, delay));
					tp.setSuccessColor(Success.Delay_Less_than_NUM_Days
							.getLabelColor());
				}
			}

			try {
				if (ttmProduct.getTtmTargetDate() != null) {
					tp.setTtmTargetDate(CalendarUtil.date2String(ttmProduct
							.getTtmTargetDate()));
				}

				if (ttmProduct.getTtmSignOffDate() != null) {
					tp.setTtmSignOffDate(CalendarUtil.date2String(ttmProduct
							.getTtmSignOffDate()));
				}

				// if(ttmProduct.getTtmTargetDate() != null &&
				// ttmProduct.getTtmSignOffDate() != null) {
				// if
				// (ttmProduct.getTtmTargetDate().before(ttmProduct.getTtmSignOffDate())
				// || CalendarUtil.isSameDay(ttmProduct.getTtmTargetDate(),
				// ttmProduct.getTtmSignOffDate())){
				// tp.setTargetDatePassed(true);
				// }
				//
				// if(!CalendarUtil.isSameDay(ttmProduct.getTtmTargetDate(),
				// ttmProduct.getTtmSignOffDate())){
				// tp.setShowSignedSnapshot(true);
				// }
				// }
				//
				Date now = new Date();
				if (ttmProduct.getTtmTargetDate() != null
						&& !"".equals(ttmProduct.getTtmTargetDate())) {
					if (ttmProduct.getTtmTargetDate().before(now)
							&& CalendarUtil.getDateByString(
									masterDataService.getThresholdByName(
											Threshold.NPI_LOAD_DATE.name())
											.intValue()
											+ "").getTime() < ttmProduct
									.getTtmTargetDate().getTime()) {
						tp.setTargetDatePassed(true);
					}
				}

				if (ttmProduct.getTtmSignOffDate() != null
						&& !"".equals(ttmProduct.getTtmSignOffDate())) {
					if (ttmProduct.getTtmSignOffDate().before(now)
							&& CalendarUtil.getDateByString(
									masterDataService.getThresholdByName(
											Threshold.NPI_LOAD_DATE.name())
											.intValue()
											+ "").getTime() < ttmProduct
									.getTtmSignOffDate().getTime()) {
						tp.setShowSignedSnapshot(true);
					}
				}

			} catch (ParseException e) {
				e.printStackTrace();
			}
			list.add(tp);
		}
		if (!waveIds.isEmpty()) {
			Map<Integer, List<String>> npis = nPIProductSummaryDao
					.getNPIByWaveIds(waveIds);

			for (TtmGridProduct t : list) {
				if (npis.get(t.getWaveId()) != null) {
					t.setNpiOwner(CommonUtil.npiNameString(npis.get(t
							.getWaveId())));
				}

			}
		}

		return list;
	}

	@Override
	public Pager<TtmGridProduct> getSearchProductsByConditions(
			SearchSearchProductGridProductsForm form) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PieChartView getChartDataByConditions(OverviewSearchForm form) {

		if (form.getGridType() == Status.All) {
			List<NameValuePair> list = nPIOverviewDao.getProjectStatusByPhase(
					NPIPhase.ttm, form);

			PieChartView pView = new PieChartView();
			List<PieSlice> pieList = new ArrayList<PieSlice>();
			for (NameValuePair nv : list) {
				Status s = Status.valueOf(nv.getName());
				PieSlice p = new PieSlice();
				p.setLink(s.getUrl() + "?tp=" + new Date());
				p.setColor(s.getColor());
				p.setLabel(s.toString() + "(" + nv.getValue() + ")");
				p.setValue(nv.getValue());
				pieList.add(p);
			}
			pView.setElements(pieList);
			return pView;
		}

		if (form.getGridType() == Status.In_Progress) {
			List<NameValuePair> list = nPIOverviewDao.getRiskStatusByPhase(
					NPIPhase.ttm, form);
			PieChartView pView = new PieChartView();
			List<PieSlice> pieList = new ArrayList<PieSlice>();
			for (NameValuePair nv : list) {
				Risk s = Risk.valueOf(nv.getName());
				PieSlice p = new PieSlice();
				p.setColor(s.getColor());
				p.setLabel(s.toString() + "(" + nv.getValue() + ")");
				p.setValue(nv.getValue());
				pieList.add(p);
			}
			pView.setElements(pieList);
			return pView;
		}

		if (form.getGridType() == Status.Success) {
			List<Integer> list = nPIOverviewDao.getSuccessDelays(form);
			int threshold = masterDataService.getThresholdByName(
					Threshold.TTM_SUCCESS_THRESHOLD.name()).intValue();
			Map<Success, Integer> map = new HashMap<Success, Integer>();
			for (Integer integer : list) {
				if (integer <= 0) {
					if (null == map.get(Success.On_Schedule)) {
						map.put(Success.On_Schedule, 1);
					} else {
						map.put(Success.On_Schedule,
								map.get(Success.On_Schedule) + 1);
					}
				} else if (integer <= threshold) {
					if (null == map.get(Success.Delay_Less_than_NUM_Days)) {
						map.put(Success.Delay_Less_than_NUM_Days, 1);
					} else {
						map.put(Success.Delay_Less_than_NUM_Days,
								map.get(Success.Delay_Less_than_NUM_Days) + 1);
					}
				} else {
					if (null == map.get(Success.Delay_Greater_than_NUM_Days)) {
						map.put(Success.Delay_Greater_than_NUM_Days, 1);
					} else {
						map.put(Success.Delay_Greater_than_NUM_Days,
								map.get(Success.Delay_Greater_than_NUM_Days) + 1);
					}
				}
			}

			PieChartView pView = new PieChartView();
			List<PieSlice> pieList = new ArrayList<PieSlice>();
			for (Map.Entry<Success, Integer> entry : map.entrySet()) {
				PieSlice p = new PieSlice();
				p.setColor(entry.getKey().getColor());
				p.setLabel(CommonUtil.SuccessStatusReplace(entry.getKey(),
						threshold)
						+ "("
						+ String.valueOf(entry.getValue())
						+ ")");
				p.setValue(String.valueOf(entry.getValue()));
				pieList.add(p);
			}
			pView.setElements(pieList);
			return pView;
		}

		return null;
	}

	@Override
	public PieChartView getDoiPieChartData(Integer pmsWaveId, String category) {

		Date versionDate = CalendarUtil.getTodayWithoutMins();
		ProjectSummary ps = nPIProductSummaryDao.getProductInfoByWaveId(
				pmsWaveId, null);
		if (ps == null) {
			return null;
		}
		List<DoiGrid> list = getDoiById(pmsWaveId, ps.getTtmTargetDate(),
				versionDate);

		PieChartView pView = new PieChartView();

		List<PieSlice> elements = new ArrayList<PieSlice>();

		for (DoiGrid doi : list) {
			if (doi.getcValue().equalsIgnoreCase(category)) {
				PieSlice p = new PieSlice();
				p.setLabel(doi.getvValue());
				p.setValue(String.valueOf(doi.getShortage()));
				elements.add(p);
			}
		}

		pView.setElements(elements);
		return pView;
	}

	private TTMProductDetail getProjectDetail(ProductWave proWave,
			Date versionDate) {

		TTMProductDetail pdView = new TTMProductDetail();

		pdView.setCurrentWave(proWave);

		Date targetDate = null;

		List<ProjectSummary> projectSummaryList = nPIProductSummaryDao
				.getProductInfoByProjectId(proWave.getProjectId(),
						proWave.getWaveId(), versionDate);

		List<Integer> waveIdList = new ArrayList<Integer>();
		waveIdList.add(proWave.getWaveId());
		Map<Integer, List<String>> waveNpiMap = nPIProductSummaryDao
				.getNPIByWaveIds(waveIdList);

		String npiName = null;
		if (waveNpiMap.containsKey(proWave.getWaveId())) {
			npiName = CommonUtil.npiNameString(waveNpiMap.get(proWave
					.getWaveId()));
		}

		List<ProductWave> pws = new ArrayList<ProductWave>();
		pdView.setProductWaves(pws);

		for (ProjectSummary projectSummary : projectSummaryList) {
			if (proWave.getWaveId().intValue() == projectSummary.getPmsWaveId()
					.intValue()) {
				proWave.setWaveName(projectSummary.getWaveName());
				proWave.setProductName(projectSummary.getProductName());
				targetDate = versionDate == null ? projectSummary
						.getTtmTargetDate() : versionDate;
				try {
					if (projectSummary.getTtmTargetDate() != null) {
						proWave.setTtmTargetDate(CalendarUtil
								.date2String(projectSummary.getTtmTargetDate()));
					}
					if (projectSummary.getTtmSignOffDate() != null) {
						proWave.setTtmSignOffDate(CalendarUtil
								.date2String(projectSummary.getTtmSignOffDate()));
					}
				} catch (ParseException e) {
					e.printStackTrace();
				}
				proWave.setDoiLight(projectSummary.getDoi());
				proWave.setGatingDefectsLight(projectSummary.getDefects());
				proWave.setOdmLight(projectSummary.getOdm());
				proWave.setToolingLight(projectSummary.getTooling());
				proWave.setFpyLight(projectSummary.getFpy());
				proWave.setObeLight(projectSummary.getObe());
				proWave.setNpiName(npiName);
				proWave.setPm(projectSummary.getPm());
				proWave.setTtmTargetDateDemand(projectSummary
						.getTtmTargetDateDemand());
				pdView.setFypTarget(StringUtil.float2String((projectSummary
						.getFpyTarget() / 100)));
				pdView.setObeTarget(StringUtil.float2String(projectSummary
						.getObeTarget() / 100));
				if (versionDate == null) {
					// if(!Status.Success.name().equals(projectSummary.getTtmStatus())){
					versionDate = projectSummary.getVersionDate();
					// }else{
					// versionDate =
					// nPIProductSummaryDao.getOldestVersionDateByWaveIdAndTTMStatus(proWave.getWaveId().intValue(),
					// projectSummary.getTtmStatus());
					// }

				}
			}
			ProductWave productWave = new ProductWave();
			productWave.setWaveName(projectSummary.getWaveName());
			productWave.setWaveId(projectSummary.getPmsWaveId());
			productWave.setProjectId(projectSummary.getPmsProjectId());
			pws.add(productWave);
		}
		ProjectInformation info = new ProjectInformation();
		info.setProductId(proWave.getProjectId());
		info.setPmName(proWave.getPm());
		pdView.setInfo(info);

		if (targetDate != null) {
			targetDate = CalendarUtil.getMondayDateByDate(targetDate);
			Date querytargetDate = CalendarUtil.getMondayDateByWeeks(
					targetDate, 0);
			if (versionDate == null) {
				versionDate = CalendarUtil.getMonday();
			}

			// gating defects
			List<Defect> gating = npiDefectService
					.getGatingDefectsByProductWave(proWave.getWaveId(),
							versionDate, versionDate);

			pdView.setGatingDefects(convert2POJO(gating));
			// non oob defects
			// Date queryOOBOrNoOOBDate;
			// if(targetDate.after(CalendarUtil.getMonday())){
			// queryOOBOrNoOOBDate = CalendarUtil.getMonday();
			// }else{
			// queryOOBOrNoOOBDate = targetDate;
			// }
			List<Defect> nonOOB = null;
			// =
			// npiDefectService.getNonOOBDefectsByProductWave(proWave.getWaveId(),
			// queryOOBOrNoOOBDate, versionDate);
			// //hack to deal with the old projects
			// if(nonOOB == null || nonOOB.isEmpty()){
			nonOOB = npiDefectService.getNonOOBDefectsByProductWave(
					proWave.getWaveId(), versionDate, versionDate);
			// }

			pdView.setNonOOB(convert2POJO(nonOOB));
			if (nonOOB != null && !nonOOB.isEmpty()) {
				float actualFpy = odmCapacityCalculator.calculateFpy(nonOOB);
				pdView.setFypActual(StringUtil.float2String(actualFpy));
			}
			// oob defects
			List<Defect> oob;
			// npiDefectService.getOOBDefectsByProductWave(proWave.getWaveId(),
			// queryOOBOrNoOOBDate, versionDate);
			// hack to deal with the old projects
			// if(oob == null || oob.isEmpty()){
			oob = npiDefectService.getOOBDefectsByProductWave(
					proWave.getWaveId(), versionDate, versionDate);
			// }

			pdView.setObes(convert2POJO(oob));
			if (oob != null && !oob.isEmpty()) {
				float actualObe = odmCapacityCalculator.calculateFpy(oob);
				pdView.setObeActual(StringUtil.float2String(actualObe));
			}
			// get odm capacity
			List<OdmCapacityPlanDetail> odmPlanDetails = odmCapacityDao
					.getDetailCapacityPlanByTargetDate(proWave.getWaveId(),
							querytargetDate, versionDate);

			if (odmPlanDetails != null && !odmPlanDetails.isEmpty()) {
				pdView.setOdmPlanDetails(convert2OdmPojo(odmPlanDetails,
						proWave.getTtmTargetDateDemand(), targetDate));
				// pdView.setOdmPlanDetails(convert2OdmPojo(odmPlanDetails,
				// proWave.getTtmTargetDateDemand(),versionDate));
			}
			// get tooling capacity
			List<ToolingCapacityDetail> toolingCapDetails = toolingCapacityDao
					.getDetailToolingCapacityByTargetDate(proWave.getWaveId(),
							querytargetDate, versionDate);
			if (toolingCapDetails != null && !toolingCapDetails.isEmpty()) {
				pdView.setTooling(convert2ToolingPojo(toolingCapDetails,
						proWave.getTtmTargetDateDemand(), targetDate));
				// pdView.setTooling(convert2ToolingPojo(toolingCapDetails,
				// proWave.getTtmTargetDateDemand(),versionDate));
			}
			// get doi
			// pdView.setDoiViews(getDoiById(proWave.getWaveId(), targetDate,
			// versionDate));
			pdView.setDoiViews(getDoiById(proWave.getWaveId(), targetDate,
					versionDate));
		}

		return pdView;
	}

	private List<DefectView> convert2POJO(List<Defect> defect) {
		List<DefectView> defectsView = new ArrayList<DefectView>();
		for (Defect d : defect) {
			DefectView dv = new DefectView();
			dv.setDefectNo(d.getDefectNo());
			dv.setCategory(d.getCategory());
			dv.setDefectTitle(d.getDefectTitle());
			if (d.getFailRate() != null) {
				dv.setFailRate(StringUtil.float2String(d.getFailRate()));
			}
			if (d.getImpactFPY() != null) {
				dv.setImpactFPY(StringUtil.float2String(d.getImpactFPY()));
			}
			dv.setTargetDate(d.getTargetDate());
			dv.setCreateDate(d.getCreateDate());
			dv.setAuthor(d.getAuthor());
			dv.setIsOpen(d.getIsOpen());
			dv.setIsLimitation(d.getIsLimitation());
			dv.setoBEDefect(d.getOBEDefect());
			dv.setGatingDefect(d.getGatingDefect());
			dv.setOwner(d.getOwner());
			defectsView.add(dv);
		}
		return defectsView;
	}

	private List<DoiGrid> getDoiById(Integer pmsWaveId, Date targetDate,
			Date versionDate) {
		List<TTMDemandDetail> ttmDemand = npidoiHelper
				.getTTMDemandDetailListById(pmsWaveId);
		if (ttmDemand != null && !ttmDemand.isEmpty()) {

			List<DoiGrid> doiList = new ArrayList<DoiGrid>();
			List<WeeklyComponentCommitment> componentCommit = npidoiHelper
					.getCommitmentByTargetDate(targetDate, versionDate,
							pmsWaveId);

			Map<String, Integer> componentCommitMap = new HashMap<String, Integer>();

			for (WeeklyComponentCommitment wc : componentCommit) {
				componentCommitMap.put(String.valueOf(wc.getCvkey()),
						wc.getCommitment());
			}

			for (TTMDemandDetail td : ttmDemand) {
				if (0 == td.getDemand()) {
					continue;
				}
				String mapKey = String.valueOf(td.getCvKey());
				DoiGrid doi = new DoiGrid();
				doiList.add(doi);
				doi.setcValue(td.getC());
				doi.setvValue(td.getV());
				doi.setPurchaseType(td.getPurchaseType());
				doi.setRequiredQty(td.getDemand());
				if (componentCommitMap.get(mapKey) == null) {
					doi.setShortage(td.getDemand());
				} else if (componentCommitMap.get(mapKey) < td.getDemand()) {
					doi.setShortage(td.getDemand()
							- componentCommitMap.get(mapKey));
				}
			}
			return doiList;
		}
		return null;
	}

	private ToolingCapacityGrid convert2ToolingPojo(
			List<ToolingCapacityDetail> toolingCapDetails, Integer demand,
			Date target) {
		ToolingCapacityGrid tcg = new ToolingCapacityGrid();
		try {
			tcg.setWeekDate(CalendarUtil.date2String(target));
		} catch (ParseException e1) {
		}
		Map<String, ToolingCovers> covers = new HashMap<String, ToolingCovers>();

		for (ToolingCapacityDetail tc : toolingCapDetails) {
			ToolingCovers tcs = covers.get(tc.getCover().name());
			if (tcs == null) {
				tcs = new ToolingCovers();
				covers.put(tc.getCover().name(), tcs);
			}
			ToolingStatus ts = new ToolingStatus();
			tcs.getTooling().add(ts);
			ts.setCover(tc.getCover().name());
			ts.setSupply(tc.getSupply());
			ts.setTech(tc.getTech());
			ts.setCapacity(String.valueOf(tc.getCapacity()));
			try {
				ts.setSignOffDate(CalendarUtil.date2String(tc.getSignOff()));

			} catch (ParseException e) {
			}
			ts.setBoh(String.valueOf(tc.getBoh()));
			tcs.setTotalCapacity(tcs.getTotalCapacity() + tc.getBoh()
					+ tc.getCapacity());
		}

		for (Map.Entry<String, ToolingCovers> entry : covers.entrySet()) {
			ToolingCovers tc = entry.getValue();
			if (tc != null) {
				if (demand != null) {
					tc.setDemand(demand);
					int gap = demand - tc.getTotalCapacity();
					if (gap > 0) {
						tc.setGap(gap);
					}
				}
				tcg.getCovers().add(tc);
			}
		}
		return tcg;
	}

	private OdmCapacityGrid convert2OdmPojo(
			List<OdmCapacityPlanDetail> odmPlanDetails, Integer demand,
			Date target) {
		OdmCapacityGrid ocg = new OdmCapacityGrid();
		List<OdmCapacity> list = new ArrayList<OdmCapacity>();
		int totalCapacity = 0;
		for (OdmCapacityPlanDetail oc : odmPlanDetails) {
			OdmCapacity occ = new OdmCapacity();
			list.add(occ);
			occ.setOdm(oc.getOdmName());
			occ.setLine(oc.getLine());
			occ.setCrew(oc.getCrew());
			occ.setDaysPerWeek(oc.getDaysPerWeek());
			occ.setHoursPerDay(oc.getHoursPerDay());
			occ.setUph(oc.getUnitsPerHour());
			if (oc.isUseRpy()) {
				occ.setUseRpy("Y");
			} else {
				occ.setUseRpy("N");
			}
			float py = 0;
			if (oc.isUseRpy()) {
				py = oc.getFpy() + (100 - oc.getFpy()) * oc.getRpy() / 100;
			} else {
				py = oc.getFpy();
			}
			occ.setOutput((int) (oc.getUnitsPerHour() * oc.getHoursPerDay()
					* oc.getDaysPerWeek() * (py / 100)));
			totalCapacity += occ.getOutput();
		}
		ocg.setOdmCapacity(list);
		ocg.setTotalCapacity(totalCapacity);
		try {
			ocg.setWeekDate(CalendarUtil.date2String(target));
		} catch (ParseException e) {
		}
		if (demand != null) {
			ocg.setDemand(demand);

			int gap = demand - totalCapacity;
			if (gap > 0) {
				ocg.setGap(gap);
			}
		}
		return ocg;
	}

	@Override
	public ProductViewForPopUp getPopUpGridProducts(
			SearchProductsFormForPopUp form) {
		List<ProductDataForPopup> basePopUpViews = nPIOverviewDao
				.getPopupGridDataByConditions(form);
		return getIntegratedData(form, basePopUpViews);
	}

	/**
	 * 需要根据输入的 npi 内容，进行数据过滤
	 * 
	 * @param form
	 * @param basePopUpViews
	 * @return
	 */
	private ProductViewForPopUp getIntegratedData(
			SearchProductsFormForPopUp form,
			List<ProductDataForPopup> basePopUpViews) {

		ProductViewForPopUp productViewForPopUp = new ProductViewForPopUp();
		List<ProductDataForPopup> putRemoveObj = new ArrayList<ProductDataForPopup>();
		if (null != basePopUpViews && basePopUpViews.size() > 0) {
			List<Integer> waveIds = new ArrayList<Integer>();
			for (ProductDataForPopup pro : basePopUpViews) {
				waveIds.add(pro.getNpiWaveId());

			}
			// 查出所有的waveId对应的npi name的组合
			Map<Integer, List<String>> waveIdNpiNames = nPIProductSummaryDao
					.getNPIByWaveIds(waveIds);

			if (StringUtils.isNotBlank(form.getNpiName())) {
				// 如果search的时候条件中有npi name
				for (ProductDataForPopup pro : basePopUpViews) {
					// 取到一个wave id 对应的names
					List<String> listNpiNames = waveIdNpiNames.get(pro
							.getNpiWaveId());
					if (null != listNpiNames && listNpiNames.size() > 0) {

						String npiNamesSub = CommonUtil
								.npiNameString(listNpiNames);

						if (npiNamesSub.toLowerCase().indexOf(
								(form.getNpiName().toLowerCase())) >= 0) {
							pro.setDisplayName(npiNamesSub);
						} else {
							putRemoveObj.add(pro);
						}
					} else {
						putRemoveObj.add(pro);
					}
					if (pro.getFamily() == null) {
						pro.setFamily("");
					}
				}

			} else {
				// 把npi name集成到ProductDataForPopup
				for (ProductDataForPopup pro : basePopUpViews) {
					// 取到一个wave id 对应的names
					List<String> listNpiNames = waveIdNpiNames.get(pro
							.getNpiWaveId());

					if (null != listNpiNames && listNpiNames.size() > 0) {

						pro.setDisplayName(CommonUtil
								.npiNameString(listNpiNames));

					}

					if (pro.getFamily() == null) {
						pro.setFamily("");
					}
				}
			}

		}
		if (CollectionUtils.isNotEmpty(putRemoveObj)) {
			basePopUpViews.removeAll(putRemoveObj);
		}
		productViewForPopUp.setPopUpViews(basePopUpViews);
		String productWavesPage = "";
		String waveIdsPage = "";
		if (CollectionUtils.isNotEmpty(basePopUpViews)) {
			for (ProductDataForPopup productDataForPopup : basePopUpViews) {
				productWavesPage += productDataForPopup.getProductName() + "("
						+ productDataForPopup.getWaveName() + ");";
				waveIdsPage += productDataForPopup.getNpiWaveId() + ",";
			}
		}

		productViewForPopUp.setProductWaves(productWavesPage);
		productViewForPopUp.setWaveIds(waveIdsPage);

		return productViewForPopUp;
	}

	@Override
	public ProductViewForPopUp getPopUpGridProductsForDoi(
			SearchProductsFormForPopUp searchProductForm) {
		List<ProductDataForPopup> basePopUpViews = nPIOverviewDao
				.getPopupGridDataForDoi(searchProductForm);

		return getIntegratedData(searchProductForm, basePopUpViews);
	}

	@Override
	public List<DoiGrid> getDoiProductsByConditions(Integer pmsWaveId) {
		Date versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil
				.getTodayWithoutMins());
		ProjectSummary ps = nPIProductSummaryDao.getProductInfoByWaveId(
				pmsWaveId, null);
		if (ps == null) {
			return null;
		}
		return getDoiById(pmsWaveId, ps.getTtmTargetDate(), versionDate);
	}

	@Override
	public TTMProductDetail getProjectDetail(ProductWave proWave) {
		return getProjectDetail(proWave, null);
	}

	@Override
	public TTMProductDetail getSnapshotDetailByDate(ProductWave proWave,
			Date targetDate) {
		return getProjectDetail(proWave, targetDate);
	}

}
