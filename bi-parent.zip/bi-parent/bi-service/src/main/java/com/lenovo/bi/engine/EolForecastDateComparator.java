package com.lenovo.bi.engine;

import java.util.Comparator;

import com.lenovo.bi.dto.EolForecast;

public class EolForecastDateComparator implements Comparator<EolForecast> {

	@Override
	public int compare(EolForecast o1, EolForecast o2) {
		if (o1.getEolDate().before(o2.getEolDate())) {
			return -1;
		}
		else if (o2.getEolDate().before(o1.getEolDate())) {
			return 1;
		}
		else {
			return 0;
		}
	}

}
