package com.lenovo.bi.engine;

import java.util.Map;

import com.lenovo.bi.dto.CtoCvConfig;
import com.lenovo.bi.dto.MtmGeographyOdmCvConfig;

public class ComponentQuota {
	private Map<BomNumberGeographyOdmCvKeyKey, Integer> componentQuantity;
	
	public ComponentQuota(Map<BomNumberGeographyOdmCvKeyKey, Integer> componentQuantity) {
		super();
		this.componentQuantity = componentQuantity;
	}

	/**
	 * Calculate the max number of units this component quota can support. The max number
	 * does not exceed the number of units passed in.
	 * @param mtmCvConfig MTM configuration
	 * @return
	 */
	public int calculateMaxMtmNumberOfUnits(MtmGeographyOdmCvConfig mtmCvConfig) {
		int min = mtmCvConfig.getNumberOfUnits();
		
		for (Integer cvKey : mtmCvConfig.getAllCvs()) {
			BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(mtmCvConfig.getBomNumber(), mtmCvConfig.getGeographyName(), 
					mtmCvConfig.getOdmName(), cvKey);
			if(getSupplyQuantity(key) != -1){
				int available = getSupplyQuantity(key) / mtmCvConfig.getSingleUnitQuantity(cvKey);
				min = Math.min(min, available);
			}
		}
		
		return min;
	}
	
	/**
	 * Return true iff the component quota can fulfill the whole CTO
	 * @param ctoCvConfig
	 * @return
	 */
	public boolean canFullfillCto(CtoCvConfig ctoCvConfig) {
		for (Integer cvKey : ctoCvConfig.getAllCvs()) {
			int requiredQuantity = ctoCvConfig.getQuantity(cvKey);
			
			BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(ctoCvConfig.getBomNumber(), ctoCvConfig.getGeographyName(),
					ctoCvConfig.getOdmName(), cvKey);
			
			int available = getSupplyQuantity(key);
			
			if (available < requiredQuantity) {
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Deduct CVs from this component quota for this MTM configuration. The max number of units that can
	 * be passed in should be calculated by <CODE>calculateMaxMtmNumberOfUnits()</CODE>. 
	 * @param mtmCvConfig
	 * @exception IllegalArgumentException Thrown if the component quota cannot meet the quantity requirement. 
	 */
	public void deductMtmUnits(MtmGeographyOdmCvConfig mtmCvConfig) {
		if (mtmCvConfig.getNumberOfUnits() > calculateMaxMtmNumberOfUnits(mtmCvConfig)) {
			throw new IllegalArgumentException("The number of MTM units cannot be covered by current component quota");
		}
		
		for (Integer cvKey : mtmCvConfig.getAllCvs()) {
			BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(mtmCvConfig.getBomNumber(), mtmCvConfig.getGeographyName(), 
					mtmCvConfig.getOdmName(), cvKey);
			reduceCvQuantity(key, mtmCvConfig.getQuantity(cvKey));
		}
	}	
	
	/**
	 * Deduct CVs from this component quota for this CTO configuration.
	 * @param ctoCvConfig
	 * @exception IllegalArgumentException Thrown if the component quota cannot meet the quantity requirement.
	 */
	public void deductWholeCto(CtoCvConfig ctoCvConfig) {
		if (!canFullfillCto(ctoCvConfig)) {
			throw new IllegalArgumentException("The whole CTO cannot be covered by current component quota");
		}
		
		for (Integer cvKey : ctoCvConfig.getAllCvs()) {
			BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(ctoCvConfig.getBomNumber(), ctoCvConfig.getGeographyName(), 
					ctoCvConfig.getOdmName(), cvKey);
			reduceCvQuantity(key, ctoCvConfig.getQuantity(cvKey));
		}
	}
	
	private void reduceCvQuantity(BomNumberGeographyOdmCvKeyKey key, int quantity) {
		Integer available = componentQuantity.get(key);
				
		if (available  != null) {
			int finalQuantity = available >= quantity ? available - quantity : 0;
			componentQuantity.put(key, finalQuantity); 
		}		
	}

	private int getSupplyQuantity(BomNumberGeographyOdmCvKeyKey key) {
		Integer quantity = componentQuantity.get(key);
		if (quantity  == null) {
			return -1;
		}
		else {
			return quantity;
		}		
	}
}
