package com.lenovo.bi.view.npi;

import java.util.Date;
/**
 * 
 * 
 * @author henry_lian
 *
 */
@Deprecated
public class Forecast {

	private String productName;
	private String productId;
	private String mtm;
	private int forecast;
	private Date forecastTargetDate;
	private Date forcastversion;
	private String geo;
	private String region;
	private String description;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getMtm() {
		return mtm;
	}
	public void setMtm(String mtm) {
		this.mtm = mtm;
	}
	public int getForecast() {
		return forecast;
	}
	public void setForecast(int forecast) {
		this.forecast = forecast;
	}
	public Date getForcastversion() {
		return forcastversion;
	}
	public void setForcastversion(Date forcastversion) {
		this.forcastversion = forcastversion;
	}
	public String getGeo() {
		return geo;
	}
	public void setGeo(String geo) {
		this.geo = geo;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getForecastTargetDate() {
		return forecastTargetDate;
	}
	public void setForecastTargetDate(Date forecastTargetDate) {
		this.forecastTargetDate = forecastTargetDate;
	}
	
}
