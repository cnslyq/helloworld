package com.lenovo.bi.service.system.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lenovo.bi.service.system.NavigationService;
import com.lenovo.bi.view.BINavigation;
import com.lenovo.bi.view.BINavigationView;

@Service
public class NavigationServiceImpl implements NavigationService {

	@Override
	public BINavigationView getBINavigationView() {
		
		BINavigationView biNavigationView = new BINavigationView();
		
		BINavigation npiBINavigation = new BINavigation();
		npiBINavigation.setNavigationName("NPI");
		npiBINavigation.setUrl("/npi/ttm/my/overview.action");
		
		BINavigation scBINavigation = new BINavigation();
		scBINavigation.setNavigationName("SC");
		scBINavigation.setUrl("/sc/overview.action");
		
		BINavigation systemBINavigation = new BINavigation();
		systemBINavigation.setNavigationName("System");
		systemBINavigation.setUrl("/system/access/viewGroupPrivilege.action");
		
//		BINavigation simulationBINavigation = new BINavigation();
//		simulationBINavigation.setNavigationName("Simulation");
//		simulationBINavigation.setUrl("/simulation/npi/my/overview.action");

		List<BINavigation> biNavigatonList= new ArrayList<BINavigation>();
		biNavigatonList.add(npiBINavigation);
		biNavigatonList.add(scBINavigation);
		biNavigatonList.add(systemBINavigation);
//		biNavigatonList.add(simulationBINavigation);
		
		biNavigationView.setBiNavigations(biNavigatonList);
		
		return biNavigationView;
	}
	
}
