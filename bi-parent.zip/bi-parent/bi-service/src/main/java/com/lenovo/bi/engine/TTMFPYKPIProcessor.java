package com.lenovo.bi.engine;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.enumobj.KPILights;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.service.common.MasterDataService;
import com.lenovo.bi.service.npi.NPIDefectService;
import com.lenovo.bi.util.CalendarUtil;
@Component
@Order(2)
public class TTMFPYKPIProcessor implements TTMKPIProcessor {

	@Inject
	private OdmCapacityCalculator odmCapacityCalculator;
	
	@Inject
	private NPIDefectService nPIDefectService;
	
	@Inject
	private MasterDataService masterDataService;
	
	@Override
	public void process(ProjectSummary ps, Date versionDate) {
		if(ps.getTtmStatus().equals(Status.NA.name())){
			return;
		}
		
		List<Defect> list = nPIDefectService.getNonOOBDefectsByProductWave(ps.getPmsWaveId(), versionDate, versionDate);
		
		KPILights kpi = KPILights.GREEN;
		if(list != null && !list.isEmpty()){
			float fpyTarget = ps.getFpyTarget() != null?ps.getFpyTarget()/100f:masterDataService.getThresholdByName(Threshold.NPI_FPY_TARGET.name());
			/*
			float fpy = odmCapacityCalculator.calculateFpy(list);
			if(fpy < fpyTarget){
				kpi = KPILights.RED;
				Date targetDate = ps.getTtmTargetDate();
				if(targetDate != null){
					targetDate = CalendarUtil.getMondayDateByDate(targetDate);
				}
				List<Defect> sslist = nPIDefectService.getNonOOBDefectsByProductWave(ps.getPmsWaveId(),targetDate, versionDate);
				float ssFpy = 1f;
				if(targetDate.after(versionDate)){
					if(sslist !=null && !sslist.isEmpty()){
						ssFpy = odmCapacityCalculator.calculateFpy(sslist);
					}
					if(ssFpy >= fpyTarget){
						kpi = KPILights.YELLOW;
					}
				} else{
					if(sslist !=null && !sslist.isEmpty()){
						ssFpy = odmCapacityCalculator.calculateFpy(sslist);
						if(ssFpy >= fpyTarget){
							kpi = KPILights.YELLOW;
						}
					}
				}
			}
			*/
			Date ttmTargetDate = ps.getTtmTargetDate();
			if(ttmTargetDate != null){
				ttmTargetDate = CalendarUtil.getMondayDateByDate(ttmTargetDate);
			}
			Map<String, Float> fpyMap = odmCapacityCalculator.calculateFpy(list, ttmTargetDate);
			float fpy = fpyMap.get("fpy");
			float fpy2 = fpyMap.get("fpy2");
			if(fpy >= fpyTarget){
				kpi = KPILights.GREEN;
			}else{
				if(fpy2 >= fpyTarget){
					kpi = KPILights.YELLOW;
				}else{
					kpi = KPILights.RED;
				}
			}
		}
		ps.setFpy(kpi.name());
	}

}
