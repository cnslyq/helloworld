package com.lenovo.bi.view.npi.ttm;

import java.util.Date;

/**
 * defect VO
 * 
 * @author henry_lian
 *
 */
public class DefectView {

	private String defectNo; // TDMSDefectIDAlternateKey
	private String category; // DefectName?
	private String defectTitle; // DefectDescription
	private String failRate; // DefectFailRate
	private String impactFPY; // FPYImpact
	private Date targetDate; //
	private Date createDate;
	private String author;
	private Boolean isOpen; // DefectStatus
	private String owner; // DefectOwner
	private Boolean isLimitation; //

	private Boolean oBEDefect;

	private Boolean gatingDefect;

	public String getDefectNo() {
		return defectNo;
	}

	public void setDefectNo(String defectNo) {
		this.defectNo = defectNo;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDefectTitle() {
		return defectTitle;
	}

	public void setDefectTitle(String defectTitle) {
		this.defectTitle = defectTitle;
	}

	public String getFailRate() {
		return failRate;
	}

	public void setFailRate(String failRate) {
		this.failRate = failRate;
	}

	public String getImpactFPY() {
		return impactFPY;
	}

	public void setImpactFPY(String impactFPY) {
		this.impactFPY = impactFPY;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Boolean getIsOpen() {
		return isOpen;
	}

	public void setIsOpen(Boolean isOpen) {
		this.isOpen = isOpen;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public Boolean getIsLimitation() {
		return isLimitation;
	}

	public void setIsLimitation(Boolean isLimitation) {
		this.isLimitation = isLimitation;
	}

	public Boolean getoBEDefect() {
		return oBEDefect;
	}

	public void setoBEDefect(Boolean oBEDefect) {
		this.oBEDefect = oBEDefect;
	}

	public Boolean getGatingDefect() {
		return gatingDefect;
	}

	public void setGatingDefect(Boolean gatingDefect) {
		this.gatingDefect = gatingDefect;
	}
	
}
