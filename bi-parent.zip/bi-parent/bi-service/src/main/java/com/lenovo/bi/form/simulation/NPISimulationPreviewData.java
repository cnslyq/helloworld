package com.lenovo.bi.form.simulation;

import java.util.ArrayList;


public class NPISimulationPreviewData {
	private String targetDate;
	private int odmOutPut = -1;
	private int coverA = -1;
	private int coverB = -1;
	private int coverC = -1;
	private int coverD = -1;
	private int supplyCommit = 0;
	private int rampCommit = -1;
	private ArrayList<CVSupply> supplys;
	public String getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(String targetDate) {
		this.targetDate = targetDate;
	}
	public int getOdmOutPut() {
		return odmOutPut;
	}
	public void setOdmOutPut(int odmOutPut) {
		this.odmOutPut = odmOutPut;
	}
	public int getCoverA() {
		return coverA;
	}
	public void setCoverA(int coverA) {
		this.coverA = coverA;
	}
	public int getCoverB() {
		return coverB;
	}
	public void setCoverB(int coverB) {
		this.coverB = coverB;
	}
	public int getCoverC() {
		return coverC;
	}
	public void setCoverC(int coverC) {
		this.coverC = coverC;
	}
	public int getCoverD() {
		return coverD;
	}
	public void setCoverD(int coverD) {
		this.coverD = coverD;
	}
	public int getSupplyCommit() {
		return supplyCommit;
	}
	public void setSupplyCommit(int supplyCommit) {
		this.supplyCommit = supplyCommit;
	}
	public int getRampCommit() {
		return rampCommit;
	}
	public void setRampCommit(int rampCommit) {
		this.rampCommit = rampCommit;
	}
	public ArrayList<CVSupply> getSupplys() {
		return supplys;
	}
	public void setSupplys(ArrayList<CVSupply> supplys) {
		this.supplys = supplys;
	}
}
