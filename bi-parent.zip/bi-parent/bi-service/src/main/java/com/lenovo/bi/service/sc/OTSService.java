package com.lenovo.bi.service.sc;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;


public interface OTSService {
	public MSColumnChartView getOverviewChart(SearchOtsForm form) throws ParseException;
	
	public List<ScOverViewChartData> getOverviewOverall(SearchOtsForm form);
	
	public ColumnChartView getRemarkChart(SearchOtsForm form) throws ParseException;
	
	public Map<String,Object> getOverviewOrderDetail(SearchOtsForm form) throws ParseException;
	public Map<String,Object> getOtsRemarkOrderDetail(SearchOtsForm form) throws ParseException;
	
	public Map<String,Object> getOtsRemarkDetractorTableDetail(SearchOtsForm form) throws ParseException;
	public PieChartView getOtsDetractorMainPieChart(SearchOtsForm form);
	public PieChartView getOtsDetractorSubPieChart(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getTtvGridDetractorCodeView(SearchOtsForm form) throws ParseException;
	
	public List<TtvGridDetractorCodeView> getDetractorOrderDetail(SearchOtsForm form) throws ParseException;
}
