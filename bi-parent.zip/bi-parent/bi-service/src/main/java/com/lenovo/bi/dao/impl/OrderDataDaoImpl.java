package com.lenovo.bi.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.enumobj.ForecastComparisonTypeEnum;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.model.OrderData;
import com.lenovo.bi.util.CalendarUtil;

@Repository
@SuppressWarnings("unchecked")
public class OrderDataDaoImpl extends HibernateBaseDaoImplBi<OrderData> {
	public void deleteOrderDataForVersionDate(Date versionDate) {
		deleteDataForVersionDate("OrderData", versionDate);
	}

	public List<OrderData> getOrderData(List<String> orders) {
		List<OrderData> orderData = new ArrayList<OrderData>();
		if (orders != null && orders.size() > 0) {

			StringBuffer hql = new StringBuffer(
					"from OrderData where poItem+poNumber in (:orders)");

			Query query = getSession().createQuery(hql.toString());

			Integer size = orders.size();
			Integer n = size / 2000;
			Integer m = size % 2000;
			for (int i = 0; i < n; i++) {
				query.setParameterList("orders",
						orders.subList(i * 2000, (i + 1) * 2000 - 1));
				orderData.addAll(query.list());
			}
			if (m > 0) {
				query.setParameterList("orders",
						orders.subList(n * 2000, n * 2000 + m - 1));
				orderData.addAll(query.list());
			}

		}
		return orderData;

	}

	/**
	 * tip: pass in null to get all types of orderdata
	 * 
	 * @param productKey
	 * @param versionDate
	 * @param type
	 * @return
	 */
	public List<NpiWeeklyComponentCommitmentOnOrder> getCausedOrderByProduct(
			String pmsWaveId, Date versionDate, ForecastComparisonTypeEnum type) {
		StringBuffer hql = new StringBuffer(
				"from NpiWeeklyComponentCommitmentOnOrder o where o.pmsWaveId = :pmsWaveId and o.versionDate = :versionDate "
						+ "and o.orderLabel = :type");
		Query query = getSession()
				.createQuery(hql.toString())
				.setResultTransformer(
						Transformers
								.aliasToBean(NpiWeeklyComponentCommitmentOnOrder.class));
		query.setParameter("pmsWaveId", Integer.valueOf(pmsWaveId));
		query.setParameter("versionDate", versionDate);
		query.setParameter("type", type);
		return query.list();
	}

	public List<NpiWeeklyComponentCommitmentOnOrder> getOrderByProduct(
			String pmsWaveId, Date versionDate, Date targetDate,
			TTVPhase ttvPhase) {
		Date startDate = null;
		Date endDate = CalendarUtil.getSundayDateByDate(targetDate);
		if (targetDate.compareTo(versionDate) != 0) {
			startDate = targetDate;
		}
		StringBuffer hql = new StringBuffer(
				"from NpiWeeklyComponentCommitmentOnOrder o where o.pmsWaveId = :pmsWaveId and o.versionDate = :versionDate ");
		hql.append(" and o.ttvPhase=:ttvPhase and o.targetDate<=:endDate");
		if (startDate != null) {
			// hql.append(" and o.rsdDate>=:startDate ");
			hql.append(" and o.targetDate>=:startDate ");
		}
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("pmsWaveId",Integer.valueOf(pmsWaveId));
		query.setParameter("versionDate", versionDate);
		query.setParameter("ttvPhase", ttvPhase.name());
		query.setParameter("endDate", endDate);
		if (startDate != null) {
			query.setParameter("startDate", startDate);
		}
		List<NpiWeeklyComponentCommitmentOnOrder> list = query.list();
		return list;
	}
}
