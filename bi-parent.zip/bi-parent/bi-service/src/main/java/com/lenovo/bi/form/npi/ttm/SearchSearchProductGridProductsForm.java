package com.lenovo.bi.form.npi.ttm;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.form.npi.SearchBase;

public class SearchSearchProductGridProductsForm extends SearchBase{

	private Date ttmTargetDateBefore;
	private String productName;
	private List<Integer> npiIds;
	
	public Date getTtmTargetDateBefore() {
		return ttmTargetDateBefore;
	}
	public void setTtmTargetDateBefore(Date ttmTargetDateBefore) {
		this.ttmTargetDateBefore = ttmTargetDateBefore;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public List<Integer> getNpiIds() {
		return npiIds;
	}
	public void setNpiIds(List<Integer> npiIds) {
		this.npiIds = npiIds;
	}
}
