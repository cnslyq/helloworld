package com.lenovo.bi.service.npi.impl;

import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.common.ForecastDao;
import com.lenovo.bi.dao.npi.impl.NPIPhaseDaoImpl;
import com.lenovo.bi.dto.NpiDnsEntry;
import com.lenovo.bi.dto.NpiForecast;
import com.lenovo.bi.model.dw.NPIPhase;
import com.lenovo.bi.service.npi.ForecastService;
import com.lenovo.bi.util.CalendarUtil;
/**
 * 
 * 
 * @author henry_lian
 *
 */
@Service
@Transactional("dw")
public class ForecastServiceImpl implements ForecastService {

	@Autowired
	private NPIPhaseDaoImpl npiPhaseDao;
	
	@Autowired
	private ForecastDao forecastDao;
	
	@Override
	public Map<Date, Integer> getSGATTVForecast(int pmsWaveId) {
		Map<Date, Integer> forecasts = new Hashtable<Date, Integer>();
		
		// get ss planned date, ss actual date, sga date
		
		List<NPIPhase> phases = npiPhaseDao.getNPIPhase(new String[] { "SS", "SGA" }, pmsWaveId);
		if (phases == null || phases.size() != 2) {
			return forecasts;
		}

		Date ssDate = CalendarUtil.getMondayDateByDate(phases.get(0).getPlanDate());
		Date sgaDate = CalendarUtil.getMondayDateByDate(phases.get(1).getPlanDate());
		Date startDate8 = CalendarUtil.getMondayDateByWeeks(ssDate, -8);
		Date startDate7 = CalendarUtil.getMondayDateByWeeks(ssDate, -7);
		Date endDate = CalendarUtil.getMondayDateByWeeks(sgaDate, 2);
		
		//grab forecast based on 59/CTO-SBB
		List forecasts8 = forecastDao.getForecast(pmsWaveId, startDate8);
		List forecasts7 = forecastDao.getForecast(pmsWaveId, startDate7);
		if (forecasts8.isEmpty() && forecasts7.isEmpty()){
			return forecasts;
		} 
		if(!forecasts8.isEmpty()){
			for (int i = 0; i < forecasts8.size(); i++) {
				Object[] forecast = (Object[]) forecasts8.get(i);
				Date targetDate = (Date) forecast[0];
				Integer quantity = (Integer) forecast[1];
				if (forecasts.get(targetDate) == null) {
					forecasts.put(targetDate, quantity);
				}
			}
		}
		else{
		if(!forecasts7.isEmpty()){
			for (int i = 0; i < forecasts7.size(); i++) {
				Object[] forecast = (Object[]) forecasts7.get(i);
				Date targetDate = (Date) forecast[0];
				Integer quantity = (Integer) forecast[1];
				if (forecasts.get(targetDate) == null) {
					forecasts.put(targetDate, quantity);
				}
			}
		}
		}

		for (Date d = startDate8; d.compareTo(endDate) <= 0;) {
			if (forecasts.get(d) == null) {
				forecasts.put(d, 0);
			}
			d = CalendarUtil.getMondayDateByWeeks(d, 1);
		}
		
		return forecasts;
	}

	@Override
	public List<NpiForecast> getNpiForecastByTargetDate(Integer cvKey,
			Integer versionDateKey, Integer targetDateKey, Integer i) {
		// TODO Auto-generated method stub
		List<NpiForecast> list=	forecastDao.getNpiForecastByTargetDate( cvKey,
				 versionDateKey,  targetDateKey,  i);
		return list;
	}
@Override
	public List<NpiForecast> getForecastRateMonthone(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2, NpiDnsEntry dns,Integer forecastDate,Integer dnsversion) {
		// TODO Auto-generated method stub
		return forecastDao.getForecastRateMonthone( month_1,
				 month_2,  year_1,  year_2,  dns,forecastDate,dnsversion);
	}
@Override
	public List<NpiForecast> getForecastRateMonthtwo(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2,
			String shortegeCode_1, NpiDnsEntry dns,Integer forecastDate,Integer dnsversion) {
		// TODO Auto-generated method stub
		return forecastDao.getForecastRateMonthtwo( month_1,
				 month_2,  year_1,  year_2,
				 shortegeCode_1,  dns,forecastDate,dnsversion);
	}
@Override
	public List<NpiForecast> getForecastRateMonththree(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2,
			String shortegeCode_1, String shortegeCode_2, NpiDnsEntry dns,Integer forecastDate,Integer dnsversion) {
		// TODO Auto-generated method stub
		return forecastDao.getForecastRateMonththree( month_1,
				 month_2,  year_1,  year_2,
				 shortegeCode_1,  shortegeCode_2,  dns,forecastDate,dnsversion);
	}

@Override
public Integer get2MonthsAgoMondayOfMonthkDate(int targetDateKey) {
	// TODO Auto-generated method stub
	return forecastDao.get2MonthsAgoMondayOfMonthkDate(targetDateKey);
}

@Override
public Integer get3MonthsAgo4WeeksMondayOfMonthkDate(int targetDateKey) {
	// TODO Auto-generated method stub
	return forecastDao.get3MonthsAgo4WeeksMondayOfMonthkDate(targetDateKey);
}

@Override
public List getForecastByVersionDate(Integer forecastDate) {
	// TODO Auto-generated method stub
	return forecastDao.getForecastByVersionDate(forecastDate);
}

}
