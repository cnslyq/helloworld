package com.lenovo.bi.dao.sc;


import java.util.List;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FlexibilityChartData;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.view.sc.flexibility.FlexibilityDetailGridView;

public interface FlexibilityDao {

	public List<FlexibilityChartData> fetchFlexibilityOverViewChartData(SearchOtsForm form);
	
	public List<FlexibilityChartData> fetchDimensionRemarkDataList(SearchOtsForm form);
	
	public List<KeyNameObject> fetchDimensions(SearchOtsForm form);
	
	public List<FlexibilityChartData> fetchFlexibilityRemarkChartData(SearchOtsForm form);
	
	public List<FlexibilityChartData> fetchFlexibilityDashboardOverViewChartData(SearchOtsForm form);

	public List<FlexibilityChartData> fetchFlexibilityCrossMonthOverviewChartData(SearchOtsForm form);
	
	public List<FlexibilityDetailGridView> fetchFlexibilityDetail(SearchOtsForm form);
	
	public List<FlexibilityDetailGridView> fetchFlexibilityDetailForExcel(SearchOtsForm form);
	
	public int fetchFlexibilityDetailCount(SearchOtsForm form);
	
	public List<KeyNameObject> fetchComponents(SearchOtsForm form);
	
	public List<FlexibilityChartData> fetchComponentRemarkChartData(SearchOtsForm form);
	
	public List<FlexibilityChartData> fetchComponentOverViewChartData(SearchOtsForm form);
}
