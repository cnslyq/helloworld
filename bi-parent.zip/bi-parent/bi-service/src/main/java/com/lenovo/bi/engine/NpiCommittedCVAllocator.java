package com.lenovo.bi.engine;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dto.ForecastDetailDto;
import com.lenovo.bi.dto.OrderDetailDto;
import com.lenovo.bi.dto.WeeklyComponentCommitmentOnProductDto;
import com.lenovo.bi.enumobj.ForecastComparisonTypeEnum;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.service.npi.helper.NpiCommittedCVAllocatorBiHelper;
import com.lenovo.bi.service.npi.helper.NpiCommittedCVAllocatorDwHelper;
import com.lenovo.bi.util.CalendarUtil;

@Service
public class NpiCommittedCVAllocator {

	private Date versionDate;
	private Date dnsVersionDate;
	private Date initDate = new Date();
	private Date financeEndDate;
	@Autowired
	private NpiCommittedCVAllocatorBiHelper biHelper;
	@Autowired
	private NpiCommittedCVAllocatorDwHelper dwHelper;
	
	private Map<Integer, WeeklyComponentCommitmentOnProductDto> commitOnProductMap;
	private Map<Integer, Map<Integer, Integer>> mtmCvMap = new HashMap<Integer, Map<Integer, Integer>>();

	private List<NpiWeeklyComponentCommitmentOnOrder> commitOnOrderList;
	private List<NpiWeeklyComponentCommitmentOnForecast> commitOnForecastList;
	private Map<Integer, Long> thisWeekCommittedCvMap;
	private List<ForecastDetailDto> forecastList;
	
	private Map<Date, Map<BomNumberGeographyOdmKey, ForecastDetailDto>> forecastMapInWeek1 = 
			new HashMap<Date, Map<BomNumberGeographyOdmKey, ForecastDetailDto>>();
	private Map<Date, Map<BomNumberGeographyOdmKey, ForecastDetailDto>> forecastMapInWeek8 = 
			new HashMap<Date, Map<BomNumberGeographyOdmKey, ForecastDetailDto>>();
	
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	
	public NpiCommittedCVAllocator(){
		super();
	}
	
	public NpiCommittedCVAllocator(Date versionDate, Date dnsVersionDate){
		super();
		this.versionDate = versionDate;
		this.dnsVersionDate = dnsVersionDate;
	}
	
	/**
	 * Main allocation logic
	 * @throws ParseException
	 */
	public void run() throws ParseException{
		//clean data
		cleanDataByVersionDate();
		//get finance end date
		financeEndDate = getFinanceEndDate();
		//get target date list
		List<Integer> targetDateList = getTargetDateList();
		//get the mapping between product and CVs 
		commitOnProductMap = getCommitmentOnProductMap();
		
		//loop all the product
		for(int productKey : commitOnProductMap.keySet()){
			commitOnOrderList = new ArrayList<NpiWeeklyComponentCommitmentOnOrder>();
			commitOnForecastList = new ArrayList<NpiWeeklyComponentCommitmentOnForecast>();
			
			//get commitment on product
			WeeklyComponentCommitmentOnProductDto commitOnProductDto = commitOnProductMap.get(productKey);
			
			//init order index
			int sleOrderIndex = 0;
			int sgaOrderIndex = 0;
			//get order data
			List<OrderDetailDto> sleOrderList = getSLEOrderList(productKey);
			List<OrderDetailDto> sgaOrderList = getSGAOrderList(productKey);
			
			//get target date list
			//List<Integer> targetDateList = commitOnProductDto.getTargetDateList();
			//get target date & CV mapping
			Map<Integer, Map<Integer, Long>> targetDateCvMap = commitOnProductDto.getTargetDateCvMap();
			
			//last week remaining CV
			Map<Integer, Long> lastWeekRemainCvMap4SLE = new HashMap<Integer, Long>();
			Map<Integer, Long> lastWeekRemainCvMap4SGA = new HashMap<Integer, Long>();
			
			//loop the week list
			for(Integer targetDateKey : targetDateList){
				Date targetDate = sdf.parse(targetDateKey + "");
				//get forecast data 
				forecastList = getForecastList(targetDate, productKey);
				//get current week CV
				if(null == targetDateCvMap.get(targetDateKey)){
					thisWeekCommittedCvMap = new HashMap<Integer, Long>();
				}else{
					thisWeekCommittedCvMap = targetDateCvMap.get(targetDateKey);
				}
				
				//allocation for SLE
				sleOrderIndex = allocation(lastWeekRemainCvMap4SLE, sleOrderList, sleOrderIndex, 
						targetDate, TTVPhase.sle.name());
				
				//allocation for SGA
				sgaOrderIndex = allocation(lastWeekRemainCvMap4SGA, sgaOrderList, sgaOrderIndex, 
						targetDate, TTVPhase.sga.name());
				
			}
			
			//save allocation results
			saveAllocationResult();
		}
		
		commitOnOrderList = new ArrayList<NpiWeeklyComponentCommitmentOnOrder>();
		commitOnForecastList = new ArrayList<NpiWeeklyComponentCommitmentOnForecast>();
		
		//if order's product does not exist in the committed CV, set it as fulfilled
		List<OrderDetailDto> uncommittedSLEOrderList = setUncommittedSLEOrderList();
		List<OrderDetailDto> uncommittedSGAOrderList = setUncommittedSGAOrderList();
		
		//set date order map for removing order from forecast
		Map<String, Map<BomNumberGeographyOdmKey, Integer>> dateOrderMap = new HashMap<String, Map<BomNumberGeographyOdmKey, Integer>>();
		setDateOrderMap(dateOrderMap, uncommittedSLEOrderList, TTVPhase.sle.name());
		setDateOrderMap(dateOrderMap, uncommittedSGAOrderList, TTVPhase.sga.name());
		
		//if forecast's product does not exist in the committed CV, set it as fulfilled
		setUncommittedForecastList(dateOrderMap);
		
		//save allocation results
		saveAllocationResult();
	}
	
	/**
	 * clean old data
	 */
	private void cleanDataByVersionDate(){
		biHelper.cleanDataByVersionDate(versionDate);
	}
	
	/**
	 * get target date list
	 * @return
	 */
	private List<Integer> getTargetDateList(){
		List<Integer> targetDateList = new ArrayList<Integer>();
		//Date targetDate = CalendarUtil.getMondayDateByDate(initDate);
		//Date targetDate = CalendarUtil.getMondayDateByDate(versionDate);
		Date targetDate = CalendarUtil.getMondayDateByDate(dnsVersionDate);
		while(targetDate.compareTo(financeEndDate) <= 0){
			targetDateList.add(Integer.parseInt(sdf.format(targetDate)));
			targetDate = CalendarUtil.getMondayDateByWeeks(targetDate, 1);
		}
		return targetDateList;
	}
	
	/**
	 * FIFO allocation for each week
	 * @param lastWeekRemainCvMap
	 * @param orderList
	 * @param orderIndex
	 * @param targetDate
	 * @param ttvPhase
	 * @return
	 */
	private int allocation(Map<Integer, Long> lastWeekRemainCvMap, 
			List<OrderDetailDto> orderList, int orderIndex, Date targetDate, String ttvPhase){
		//init order map for removing order from forecast
		Map<BomNumberGeographyOdmKey, Integer> orderMap = new HashMap<BomNumberGeographyOdmKey, Integer>();
		//remain CV = this week committed CV + last week remaining CV
		Map<Integer, Long> remainCvMap = mergeCvMap(lastWeekRemainCvMap);
		//allocate to order
		orderIndex = allocateToOrder(orderList, orderIndex, targetDate, remainCvMap, orderMap, ttvPhase);
		//allocate to forecast
		allocateToForecast(orderMap, remainCvMap, ttvPhase);
		//set last week remain CV
		lastWeekRemainCvMap.clear();
		lastWeekRemainCvMap.putAll(remainCvMap);
		
		return orderIndex;
	}
	
	
	/**
	 * Allocate to order
	 * @param orderList
	 * @param orderIndex
	 * @param targetDate
	 * @param remainCvMap
	 * @param orderMap
	 * @param ttvPhase
	 * @return
	 */
	private int allocateToOrder(List<OrderDetailDto> orderList, int orderIndex, 
			Date targetDate, Map<Integer, Long> remainCvMap, Map<BomNumberGeographyOdmKey, Integer> orderMap, String ttvPhase){
		
		boolean fulfill = true;
		//loop the order list
		for(int i=orderIndex;i<orderList.size();i++){
			//get order detail object
			OrderDetailDto orderDetail = orderList.get(i);
			//filter the orders after this week
			if(targetDate.compareTo(orderDetail.getTargetDate()) >= 0){
				if(fulfill){
					//compare remaining CV and required CV
					fulfill = isFulfilled(remainCvMap, orderDetail.getMtmKey(), orderDetail.getQuantity());
					//if fulfilled, order index + 1
					if(fulfill){
						orderIndex++;
						setOrderMap(orderMap, orderDetail);
					}
				}
				
				//save order allocation results
				orderDetail.setTargetDate(targetDate);
				commitOnOrderList.add(setCommitmentOnOrder(orderDetail, fulfill, ttvPhase));
				
			}else{
				break;
			}
		}
		
		return orderIndex;
	}
	
	/**
	 * Allocate to forecast
	 * @param orderMap
	 * @param remainCvMap
	 * @param ttvPhase
	 */
	private void allocateToForecast(Map<BomNumberGeographyOdmKey, Integer> orderMap, 
			Map<Integer, Long> remainCvMap, String ttvPhase){
		
		boolean fulfill = true;
		//loop the forecast list
		for(ForecastDetailDto forecastDetail : forecastList){
			int quantity = forecastDetail.getQuantity();
			if(fulfill){
				//remove order from forecast
				BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(forecastDetail.getBomNumber(), 
						forecastDetail.getGeographyName(), forecastDetail.getOdmName());
				if(orderMap.get(key) != null){
					quantity -= orderMap.get(key);
					if(quantity < 0)
						quantity = 0;
				}
				
				//compare remaining CV and required CV
				fulfill = isFulfilled(remainCvMap, forecastDetail.getMtmKey(), quantity);
			}
			
			//save forecast allocation results
			commitOnForecastList.add(setCommitmentOnForecast(forecastDetail, quantity, fulfill, ttvPhase));
		}
		
	}
	
	/**
	 * If remaining CV >= required CV, return true
	 * else return false
	 * @param remainCvMap
	 * @param mtmKey
	 * @param mtmQuantity
	 * @return
	 */
	private boolean isFulfilled(Map<Integer, Long> remainCvMap, int mtmKey, int mtmQuantity){
		Map<Integer, Long> tempCvMap = new HashMap<Integer, Long>();
		
		//get CV mapping for MTM
		if(null == mtmCvMap.get(mtmKey)){
			mtmCvMap.put(mtmKey, getCvMapping4Mtm(mtmKey));
		}
		Map<Integer, Integer> cvMap4Mtm = mtmCvMap.get(mtmKey);
		
		//loop the CVs mapping
		for(int cvKey : cvMap4Mtm.keySet()){
			//if CV does not exist in the committed CV, CV quantity = MAX
			if(remainCvMap.get(cvKey) != null){
				//get remaining CV quantity
				long remainQuantity = remainCvMap.get(cvKey);
				//get required CV quantity
				long requiredQuantity = cvMap4Mtm.get(cvKey) * mtmQuantity;
				//if CV quantity cannot be satisfied
				if(requiredQuantity > remainQuantity){
					//return false as the fulfilled flag
					return false;
				}else{
					//add the remaining CV number to the temp map
					tempCvMap.put(cvKey, remainQuantity - requiredQuantity);
				}
			}
		}
		
		//if all the CV can be fulfilled, set the remaining CV
		remainCvMap.putAll(tempCvMap);
		return true;
	}
	
	/**
	 * save allocation results
	 */
	private void saveAllocationResult(){
		//save order and forecast data
		saveCommitmentOnOrder();
		saveCommitmentOnForecast();
		
		//update supplyCommit into BI_TTVWeeklyDetail and BI_SGATTVWeeklyDetail
		updateTtvWeeklyDetail();
		updateSGATtvWeeklyDetail();
	}
	
	/**
	 * Merge last week remaining CV to this week CV
	 * @param lastWeekRemainCvMap
	 * @return
	 */
	private Map<Integer, Long> mergeCvMap(Map<Integer, Long> lastWeekRemainCvMap){
		Map<Integer, Long> remainCvMap = new HashMap<Integer, Long>();
		remainCvMap.putAll(thisWeekCommittedCvMap);
		
		for(int cvKey : thisWeekCommittedCvMap.keySet()){
			if(null != lastWeekRemainCvMap.get(cvKey)){
				remainCvMap.put(cvKey, thisWeekCommittedCvMap.get(cvKey) + lastWeekRemainCvMap.get(cvKey));
			}
		}
		return remainCvMap;
	}
	
	/**
	 * set order map for removing order from forecast
	 * @param orderMap
	 * @param orderDetail
	 */
	private void setOrderMap(Map<BomNumberGeographyOdmKey, Integer> orderMap, OrderDetailDto orderDetail){
		BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(orderDetail.getBomNumber(), 
				orderDetail.getGeographyName(), orderDetail.getOdmName());
		
		if(null == orderMap.get(key)){
			orderMap.put(key, orderDetail.getQuantity());
		}else{
			orderMap.put(key, orderMap.get(key) + orderDetail.getQuantity());
		}
	}
	
	/**
	 * set date order map for removing order from forecast
	 * @param dateOrderMap
	 * @param orderList
	 * @param ttvPhase
	 */
	private void setDateOrderMap(Map<String, Map<BomNumberGeographyOdmKey, Integer>> dateOrderMap, 
			List<OrderDetailDto> orderList, String ttvPhase){
		
		for(OrderDetailDto orderDetail : orderList){
			Date targetDate = orderDetail.getTargetDate();
			String key = sdf.format(targetDate) + ttvPhase;
			if(null == dateOrderMap.get(key)){
				dateOrderMap.put(key, new HashMap<BomNumberGeographyOdmKey, Integer>());
			}
			Map<BomNumberGeographyOdmKey, Integer> orderMap = dateOrderMap.get(key);
			setOrderMap(orderMap, orderDetail);
		}
	}
	
	/**
	 * get forecast week version
	 * @param week
	 * @param targetDate
	 * @return
	 */
	private Map<BomNumberGeographyOdmKey, ForecastDetailDto> getForecastInWeek(int week, Date targetDate){
		Map<BomNumberGeographyOdmKey, ForecastDetailDto> forecastMapInWeek = new HashMap<BomNumberGeographyOdmKey, ForecastDetailDto>();
		//Date versionMonday = CalendarUtil.getMondayDateByWeeks(versionDate, week);
		//List<ForecastDetailDto> forecastListInWeek = dwHelper.getForecastList(versionMonday, targetDate, null, null, -1, null);
		Date versionMonday = CalendarUtil.getMondayDateByWeeks(dnsVersionDate, week);
		List<ForecastDetailDto> forecastListInWeek = dwHelper.getForecastList(versionMonday, targetDate, versionMonday, null, null, -1, null);
		for(ForecastDetailDto forecastDetail : forecastListInWeek){
			BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(forecastDetail.getBomNumber(), 
					forecastDetail.getGeographyName(), forecastDetail.getOdmName());
			forecastMapInWeek.put(key, forecastDetail);
		}
		return forecastMapInWeek;
	}
	
	/**
	 * Set order allocation result object
	 * @param orderDetail
	 * @param fulfill
	 * @param ttvPhase
	 * @return
	 */
	private NpiWeeklyComponentCommitmentOnOrder setCommitmentOnOrder(OrderDetailDto orderDetail, 
			boolean fulfill, String ttvPhase){
		
		NpiWeeklyComponentCommitmentOnOrder commitOnOrder = new NpiWeeklyComponentCommitmentOnOrder();
		commitOnOrder.setProductKey(orderDetail.getProductKey());
		commitOnOrder.setPmsWaveId(orderDetail.getWaveKey());
		commitOnOrder.setMtmKey(orderDetail.getMtmKey());
		commitOnOrder.setBomNumber(orderDetail.getBomNumber());
		commitOnOrder.setGeographyKey(orderDetail.getRegionKey());
		commitOnOrder.setGeographyName(orderDetail.getGeographyName());
		commitOnOrder.setOdmKey(orderDetail.getOdmKey());
		commitOnOrder.setOdmName(orderDetail.getOdmName());
		commitOnOrder.setQuantity(orderDetail.getQuantity());
		commitOnOrder.setMaterialShortage(fulfill ? 0 : 1);
		commitOnOrder.setVersionDate(versionDate);
		commitOnOrder.setTargetDate(orderDetail.getTargetDate());
		commitOnOrder.setTtvPhase(ttvPhase);
		commitOnOrder.setPoItem(orderDetail.getPoItem());
		commitOnOrder.setPoNumber(orderDetail.getPoNumber());
		setOrderLabelAndAbnormalQuantity(orderDetail, commitOnOrder);
		return commitOnOrder;
	}
	
	/**
	 * Set forecast allocation result object
	 * @param forecastDetail
	 * @param quantity
	 * @param fulfill
	 * @param ttvPhase
	 * @return
	 */
	private NpiWeeklyComponentCommitmentOnForecast setCommitmentOnForecast(ForecastDetailDto forecastDetail, 
			int quantity, boolean fulfill, String ttvPhase){
		
		NpiWeeklyComponentCommitmentOnForecast commitOnForecast = new NpiWeeklyComponentCommitmentOnForecast();
		commitOnForecast.setProductKey(forecastDetail.getProductKey());
		commitOnForecast.setPmsWaveId(forecastDetail.getWaveKey());
		commitOnForecast.setMtmKey(forecastDetail.getMtmKey());
		commitOnForecast.setBomNumber(forecastDetail.getBomNumber());
		commitOnForecast.setGeographyKey(forecastDetail.getGeographyKey());
		commitOnForecast.setGeographyName(forecastDetail.getGeographyName());
		commitOnForecast.setOdmKey(forecastDetail.getOdmKey());
		commitOnForecast.setOdmName(forecastDetail.getOdmName());
		commitOnForecast.setQuantity(quantity);
		commitOnForecast.setMaterialShortage(fulfill ? 0 : 1);
		commitOnForecast.setVersionDate(versionDate);
		commitOnForecast.setTargetDate(forecastDetail.getTargetDate());
		commitOnForecast.setTtvPhase(ttvPhase);
		setForecastLabelAndAbnormalQuantity(forecastDetail, commitOnForecast);
		return commitOnForecast;
	}
	
	/**
	 * set order label and abnormal quantity
	 * @param orderDetail
	 * @param commitOnOrder
	 */
	private void setOrderLabelAndAbnormalQuantity(OrderDetailDto orderDetail, NpiWeeklyComponentCommitmentOnOrder commitOnOrder){
		/*
		//set week -8 forecast
		Date targetDate = orderDetail.getTargetDate();
		if(null == forecastMapInWeek8.get(targetDate)){
			forecastMapInWeek8.put(targetDate, getForecastInWeek(-8, targetDate));
		}
		Map<BomNumberGeographyOdmKey, ForecastDetailDto> forecastInWeek8 = forecastMapInWeek8.get(targetDate);
		//set order label and abnormal quantity
		BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(orderDetail.getBomNumber(), 
				orderDetail.getGeographyName(), orderDetail.getOdmName());
		if(null == forecastInWeek8.get(key)){
			commitOnOrder.setOrderLabel(ForecastComparisonTypeEnum.OFFSET.name());
			//commitOnOrder.setAbnormalQuantity(0);
			commitOnOrder.setAbnormalQuantity(orderDetail.getQuantity());
		}else{
			if(forecastInWeek8.get(key).getQuantity() >= orderDetail.getQuantity()){
				commitOnOrder.setOrderLabel(ForecastComparisonTypeEnum.DOWNSIDE.name());
			}else{
				commitOnOrder.setOrderLabel(ForecastComparisonTypeEnum.UPSIDE.name());
			}
			commitOnOrder.setAbnormalQuantity(orderDetail.getQuantity() - forecastInWeek8.get(key).getQuantity());
		}
		*/
		//set week -8 forecast
		Date targetDate = orderDetail.getTargetDate();
		if(null == forecastMapInWeek1.get(targetDate)){
			forecastMapInWeek1.put(targetDate, getForecastInWeek(-1, targetDate));
		}
		if(null == forecastMapInWeek8.get(targetDate)){
			forecastMapInWeek8.put(targetDate, getForecastInWeek(-8, targetDate));
		}
		Map<BomNumberGeographyOdmKey, ForecastDetailDto> forecastInWeek1 = forecastMapInWeek1.get(targetDate);
		Map<BomNumberGeographyOdmKey, ForecastDetailDto> forecastInWeek8 = forecastMapInWeek8.get(targetDate);
		//set order label and abnormal quantity
		BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(orderDetail.getBomNumber(), 
				orderDetail.getGeographyName(), orderDetail.getOdmName());
		if(null == forecastInWeek1.get(key)){
			commitOnOrder.setOrderLabel(ForecastComparisonTypeEnum.OFFSET.name());
			commitOnOrder.setAbnormalQuantity(orderDetail.getQuantity());
		}else{
			if(null == forecastInWeek8.get(key)){
				commitOnOrder.setOrderLabel(ForecastComparisonTypeEnum.DOWNSIDE.name());
				//commitOnOrder.setAbnormalQuantity(0);
				commitOnOrder.setAbnormalQuantity(orderDetail.getQuantity());
			}else{
				if(forecastInWeek8.get(key).getQuantity() >= orderDetail.getQuantity()){
					commitOnOrder.setOrderLabel(ForecastComparisonTypeEnum.DOWNSIDE.name());
				}else{
					commitOnOrder.setOrderLabel(ForecastComparisonTypeEnum.UPSIDE.name());
				}
				commitOnOrder.setAbnormalQuantity(orderDetail.getQuantity() - forecastInWeek8.get(key).getQuantity());
			}
		}
	}
	
	/**
	 * set forecast label and abnormal quantity
	 * @param forecastDetail
	 * @param commitOnForecast
	 */
	private void setForecastLabelAndAbnormalQuantity(ForecastDetailDto forecastDetail, NpiWeeklyComponentCommitmentOnForecast commitOnForecast){
		//set week -1 & -8 forecast
		Date targetDate = forecastDetail.getTargetDate();
		if(null == forecastMapInWeek1.get(targetDate)){
			forecastMapInWeek1.put(targetDate, getForecastInWeek(-1, targetDate));
		}
		if(null == forecastMapInWeek8.get(targetDate)){
			forecastMapInWeek8.put(targetDate, getForecastInWeek(-8, targetDate));
		}
		Map<BomNumberGeographyOdmKey, ForecastDetailDto> forecastInWeek1 = forecastMapInWeek1.get(targetDate);
		Map<BomNumberGeographyOdmKey, ForecastDetailDto> forecastInWeek8 = forecastMapInWeek8.get(targetDate);
		//set forecast label and abnormal quantity
		BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(forecastDetail.getBomNumber(), 
				forecastDetail.getGeographyName(), forecastDetail.getOdmName());
		if(null == forecastInWeek1.get(key)){
			commitOnForecast.setForecastLabel(ForecastComparisonTypeEnum.OFFSET.name());
			//commitOnForecast.setAbnormalQuantity(0);
			commitOnForecast.setAbnormalQuantity(forecastDetail.getQuantity());
		}else{
			if(null == forecastInWeek8.get(key)){
				//commitOnForecast.setForecastLabel(ForecastComparisonTypeEnum.OFFSET.name());
				//commitOnForecast.setAbnormalQuantity(0);
				commitOnForecast.setForecastLabel(ForecastComparisonTypeEnum.DOWNSIDE.name());
				commitOnForecast.setAbnormalQuantity(forecastDetail.getQuantity());				
			}else{
				if(forecastInWeek8.get(key).getQuantity() >= forecastDetail.getQuantity()){
					commitOnForecast.setForecastLabel(ForecastComparisonTypeEnum.DOWNSIDE.name());
				}else{
					commitOnForecast.setForecastLabel(ForecastComparisonTypeEnum.UPSIDE.name());
				}
				commitOnForecast.setAbnormalQuantity(forecastDetail.getQuantity() - forecastInWeek8.get(key).getQuantity());
			}
		}
	}
	
	
	/**
	 * Get all the product and CVs from BI_WeeklyComponentCommitmentOnProduct
	 * @return
	 */
	private Map<Integer, WeeklyComponentCommitmentOnProductDto> getCommitmentOnProductMap(){
		//return biHelper.getCommitmentOnProductMap(versionDate, initDate, financeEndDate);
		//return biHelper.getCommitmentOnProductMap(versionDate, versionDate, financeEndDate);
		return biHelper.getCommitmentOnProductMap(versionDate, dnsVersionDate, financeEndDate);
	}
	
	/**
	 * Get the SLE order to be fulfilled for the product
	 * @param productKey
	 * @return
	 */
	private List<OrderDetailDto> getSLEOrderList(int productKey){
		return dwHelper.getSLEOrderList(versionDate, financeEndDate, productKey, null);
	}
	
	/**
	 * Get the SGA order to be fulfilled for the product
	 * @param productKey
	 * @return
	 */
	private List<OrderDetailDto> getSGAOrderList(int productKey){
		return dwHelper.getSGAOrderList(versionDate, financeEndDate, productKey, null);
	}
	
	/**
	 * Get the forecast to be fulfilled for the product
	 * @param targetDate
	 * @param productKey
	 * @return
	 */
	private List<ForecastDetailDto> getForecastList(Date targetDate, int productKey){
		//return dwHelper.getForecastList(versionDate, targetDate, null, null, productKey, null);
		return dwHelper.getForecastList(versionDate, targetDate, dnsVersionDate, null, null, productKey, null);
	}
	
	/**
	 * add the sle orders which product does not exist in BI_WeeklyComponentCommitmentOnProduct
	 * @return
	 */
	private List<OrderDetailDto> setUncommittedSLEOrderList(){
		List<OrderDetailDto> orderList = dwHelper.getSLEOrderList(versionDate, financeEndDate, -1, commitOnProductMap.keySet());
		for(OrderDetailDto orderDetail : orderList){
			/*
			if(versionDate.compareTo(orderDetail.getTargetDate()) > 0){
				orderDetail.setTargetDate(versionDate);
			}
			*/
			if(dnsVersionDate.compareTo(orderDetail.getTargetDate()) > 0){
				orderDetail.setTargetDate(dnsVersionDate);
			}
			commitOnOrderList.add(setCommitmentOnOrder(orderDetail, true, TTVPhase.sle.name()));
		}
		return orderList;
	}
	
	/**
	 * add the sga orders which product does not exist in BI_WeeklyComponentCommitmentOnProduct
	 * @return
	 */
	private List<OrderDetailDto> setUncommittedSGAOrderList(){
		List<OrderDetailDto> orderList = dwHelper.getSGAOrderList(versionDate, financeEndDate, -1, commitOnProductMap.keySet());
		for(OrderDetailDto orderDetail : orderList){
			/*
			if(versionDate.compareTo(orderDetail.getTargetDate()) > 0){
				orderDetail.setTargetDate(versionDate);
			}
			*/
			if(dnsVersionDate.compareTo(orderDetail.getTargetDate()) > 0){
				orderDetail.setTargetDate(dnsVersionDate);
			}
			commitOnOrderList.add(setCommitmentOnOrder(orderDetail, true, TTVPhase.sga.name()));
		}
		return orderList;
	}
	
	/**
	 * add the forecasts which product does not exist in BI_WeeklyComponentCommitmentOnProduct
	 * @param dateOrderMap
	 */
	private void setUncommittedForecastList(Map<String, Map<BomNumberGeographyOdmKey, Integer>> dateOrderMap){
		//List<ForecastDetailDto> forecastList = dwHelper.getForecastList(versionDate, null, initDate, financeEndDate, -1, commitOnProductMap.keySet());
		//List<ForecastDetailDto> forecastList = dwHelper.getForecastList(versionDate, null, versionDate, financeEndDate, -1, commitOnProductMap.keySet());
		List<ForecastDetailDto> forecastList = dwHelper.getForecastList(versionDate, null, dnsVersionDate, dnsVersionDate, financeEndDate, -1, commitOnProductMap.keySet());
		setUncommittedForecast(forecastList, dateOrderMap, TTVPhase.sle.name());
		setUncommittedForecast(forecastList, dateOrderMap, TTVPhase.sga.name());
	}
	
	/**
	 * add uncommitted products' forecast to the allocation result
	 * @param forecastList
	 * @param dateOrderMap
	 * @param ttvPhase
	 */
	private void setUncommittedForecast(List<ForecastDetailDto> forecastList, Map<String, Map<BomNumberGeographyOdmKey, Integer>> dateOrderMap, String ttvPhase){
		for(ForecastDetailDto forecastDetail : forecastList){
			Date targetDate = forecastDetail.getTargetDate();
			String orderMapKey = sdf.format(targetDate) + ttvPhase;
			Map<BomNumberGeographyOdmKey, Integer> orderMap = dateOrderMap.get(orderMapKey);
			
			int quantity = forecastDetail.getQuantity();
			if(orderMap != null){
				BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(forecastDetail.getBomNumber(), 
						forecastDetail.getGeographyName(), forecastDetail.getOdmName());
				if(orderMap.get(key) != null){
					quantity -= orderMap.get(key);
					if(quantity < 0)
						quantity = 0;
				}
			}
			
			commitOnForecastList.add(setCommitmentOnForecast(forecastDetail, quantity, true, ttvPhase));
		}
	}
	
	
	/**
	 * Get the CVs mapping for MTM from FactProductMTMCV
	 * @param mtmKey
	 * @return
	 */
	private Map<Integer, Integer> getCvMapping4Mtm(int mtmKey){
		return dwHelper.getCvMapping4Mtm(mtmKey);
	}
	
	/**
	 * Insert into BI_WeeklyComponentCommitmentOnOrder
	 */
	private void saveCommitmentOnOrder(){
		biHelper.saveCommitmentOnOrder(commitOnOrderList);
	}
	
	/**
	 * Insert into BI_WeeklyComponentCommitmentOnForecast
	 */
	private void saveCommitmentOnForecast(){
		biHelper.saveCommitmentOnForecast(commitOnForecastList);
	}
	
	/**
	 * Get finance end date
	 * @return
	 */
	private Date getFinanceEndDate(){
		return dwHelper.getFinanceEndDate(initDate);
	}
	
	/**
	 * Update supplyCommit in BI_TTVWeeklyDetail
	 */
	private void updateTtvWeeklyDetail(){
		//biHelper.updateTtvWeeklyDetail(versionDate);
		biHelper.updateTtvWeeklyDetail(versionDate, commitOnOrderList, commitOnForecastList, TTVPhase.sle.name());
	}
	
	/**
	 * Update supplyCommit in BI_SGATTVWeeklyDetail
	 */
	private void updateSGATtvWeeklyDetail(){
		//biHelper.updateSGATtvWeeklyDetail(versionDate);
		biHelper.updateTtvWeeklyDetail(versionDate, commitOnOrderList, commitOnForecastList, TTVPhase.sga.name());
	}
	
	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Date getDnsVersionDate() {
		return dnsVersionDate;
	}

	public void setDnsVersionDate(Date dnsVersionDate) {
		this.dnsVersionDate = dnsVersionDate;
	}

	public Date getInitDate() {
		return initDate;
	}

	public void setInitDate(Date initDate) {
		this.initDate = initDate;
	}

	public NpiCommittedCVAllocatorBiHelper getBiHelper() {
		return biHelper;
	}

	public void setBiHelper(NpiCommittedCVAllocatorBiHelper biHelper) {
		this.biHelper = biHelper;
	}

	public NpiCommittedCVAllocatorDwHelper getDwHelper() {
		return dwHelper;
	}

	public void setDwHelper(NpiCommittedCVAllocatorDwHelper dwHelper) {
		this.dwHelper = dwHelper;
	}
}
