package com.lenovo.bi.dao.simulation;

import java.util.List;

import com.lenovo.bi.form.simulation.SearchNPISimulationForm;
import com.lenovo.bi.form.simulation.SearchNPISimulationHistoryForm;
import com.lenovo.bi.model.NPISimulationDetail;
import com.lenovo.bi.model.NPISimulationSummary;
import com.lenovo.bi.view.simulation.NPISimulationSummaryView;
import com.lenovo.common.model.Pager;

public interface NPISimulationDao {
		//query npi simulation summary
		public List<NPISimulationSummary> getNPISimulationSummaryByCondition(SearchNPISimulationForm form,Pager<NPISimulationSummaryView>pager);
		//query lastest npi simulation detail
		public List<NPISimulationDetail> getLastestNPISimulationDetailByCondition(int simulationId);
		//query history npi simulation detail
		public List<NPISimulationDetail> getHistoricalNPISimulationDetailByCondition(SearchNPISimulationHistoryForm form);
		//batch delete npi simulation summary
		public void batchDeleteNPISimulationSummary(List<NPISimulationSummary> simulationSummaryList);
		public void batchDeleteNPISimulationSummary(Integer[]ids);
		//update npi simulation summary
		public void updateNPISimulationSummary(NPISimulationSummary simulationSummary);
		//batch update npi simulation detail
		public void batchUpdateNPISimulationDetail(List<NPISimulationDetail> simulationDetailList);
		//add npi simulation summary
		public NPISimulationSummary addNPISimulationSummary(NPISimulationSummary simulationSummary);
		//batch add npi simulation detail
		public void batchAddNPISimulationDetail(List<NPISimulationDetail> simulationDetailList);
		//for split page
		public int getTotalCountNPISimulationSummaryByCondition(SearchNPISimulationForm form);
		
		public NPISimulationSummary getNPISimulationSummaryById(String id);
		//get createdBy select
		public List<String> getCreatedBy();
		
		public List<NPISimulationDetail> getSimulationDetailBySimulationId(Integer id);
		
}
