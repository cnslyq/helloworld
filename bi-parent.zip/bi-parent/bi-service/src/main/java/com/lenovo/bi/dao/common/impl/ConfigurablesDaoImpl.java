package com.lenovo.bi.dao.common.impl;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.common.ConfigurablesDao;
import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.model.system.Configurables;
/**
 * 
 * 
 * @author henry_lian
 *
 */
@Repository
@Transactional("bi")
public class ConfigurablesDaoImpl extends HibernateBaseDaoImplBi<Configurables> implements
		ConfigurablesDao {

	@Override
	public void saveConfiguable(Configurables configurables) {
		update(configurables);
	}

	@Override
	public List<Configurables> getConfiguables() {
		return list("from Configurables");
	}

}
