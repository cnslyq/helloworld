package com.lenovo.bi.dao.npi;

import java.util.List;

import com.lenovo.bi.model.NPIFilter;
import com.lenovo.bi.model.NPIFilterDetail;

public interface NPIFilterDao {
	public List<NPIFilter> getNPIFilter(String userId, String phase, String scope, String filterId);
	public String getLastUsedFilterID(String userId, String phase, String scope);
	public List<Integer> getNPIFilterWaveIdsByFilterId(String filterId);
	public List<NPIFilterDetail> getNPIFilterDetailByFilterId(String filterId);
	public int deleteFilterByFilterId(String filterId);
	public int deleteFilterDetailByParentId(String parentId);
	public void saveFilter(NPIFilter npiFilter);
	public void updateFilter(NPIFilter npiFilter);
	public void saveFilterDetail(NPIFilterDetail npiFilterDetail);
}
