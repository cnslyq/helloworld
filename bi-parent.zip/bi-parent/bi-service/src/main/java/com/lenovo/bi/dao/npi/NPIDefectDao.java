package com.lenovo.bi.dao.npi;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.Defect;
/**
 * NPI Defect Dao
 * 
 * @author henry_lian
 *
 */
public interface NPIDefectDao {
	
	public List<Defect> getGatingDefectsByProductWave(int waveId, Date targetDate, Date versionDate);
	
	public List<Defect> getOOBDefectsByProductWave(int waveId, Date targetDate, Date versionDate);
	
	public List<Defect> getNonOOBDefectsByProductWave(int waveId, Date targetDate, Date versionDate);
	
	public List<Defect> getGatingDefectsByProductWave(int waveId, Date targetDate);
	
	public List<Defect> getOOBDefectsByProductWave(int waveId, Date targetDate);
	
	public List<Defect> getNonOOBDefectsByProductWave(int waveId, Date targetDate);
}
