package com.lenovo.bi.service.npi.helper;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.npi.NPIProductSummaryDao;
import com.lenovo.bi.dao.npi.NPIProjectWaveDao;
import com.lenovo.bi.dto.NPIWaveInfo;
import com.lenovo.bi.model.ProjectSummary;

@Service
public class NPIWaveSummaryHelper {

	@Inject
	private NPIProductSummaryDao npiProductSummaryDao;
	
	@Inject
	private NPIProjectWaveDao npiProjectWaveDao;
	
	@Transactional("dw")
	public List<NPIWaveInfo> getProjectSummaryByDate(Date versionDate){
		
		return npiProjectWaveDao.getProjectDetail(versionDate);
	}
	
	@Transactional("bi")
	public List<ProjectSummary> getProductByStatus(List<String> status, Date versionDate){
		
		return npiProductSummaryDao.getProductByStatus(status, versionDate);
	}
	
	@Transactional("bi")
	public void saveProjectSummaries(List<ProjectSummary> projectSummaries, Date versionDate){
		npiProductSummaryDao.deleteProductSummaryByVersionDate(versionDate);
		npiProductSummaryDao.saveProductSummary(projectSummaries);
	}
	
	@Transactional("bi")
	public ProjectSummary getProductInfoByWaveId(Integer pmsWaveId, Date versionDate){
		return npiProductSummaryDao.getProductInfoByWaveId(pmsWaveId, versionDate);
	}
	
	@Transactional("bi")
	public List<ProjectSummary> getPrevSummary(Date versionDate) {
		return npiProductSummaryDao.getPrevSummary(versionDate);
	}
}
