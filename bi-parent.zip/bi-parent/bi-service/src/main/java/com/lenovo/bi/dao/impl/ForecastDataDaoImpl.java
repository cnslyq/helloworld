package com.lenovo.bi.dao.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.enumobj.ForecastComparisonTypeEnum;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.ForecastData;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;

@Repository
@SuppressWarnings("unchecked")
public class ForecastDataDaoImpl extends HibernateBaseDaoImplBi<ForecastData> {
	public void deleteForecastDataForVersionDate(Date versionDate) {
		deleteDataForVersionDate("ForecastData", versionDate);
	}

	public List<NpiWeeklyComponentCommitmentOnForecast> getForecastDataByProduct(
			String pmsWaveId, Date targetDate, Date versionDate,
			TTVPhase ttvPhase) {
		StringBuffer hql = new StringBuffer(
				"from NpiWeeklyComponentCommitmentOnForecast od where od.pmsWaveId = :pmsWaveId and od.targetDate = :targetDate and od.versionDate = :versionDate ");
		hql.append(" and od.ttvPhase = :ttvPhase ");
		Query query = getSession().createQuery(hql.toString());
		query.setInteger("pmsWaveId", Integer.parseInt(pmsWaveId));
		query.setDate("targetDate", targetDate);
		query.setDate("versionDate", versionDate);
		query.setString("ttvPhase", ttvPhase.name());
		return query.list();
	}

	/**
	 * * tip: pass in null to get all types of forecast data
	 * 
	 * @param productKey
	 * @param targetDate
	 * @param versionDate
	 * @param type
	 * @return
	 */
	public List<NpiWeeklyComponentCommitmentOnForecast> getCausedForecastDataByProduct(
			String pmsWaveId, Date targetDate, Date versionDate,
			ForecastComparisonTypeEnum type) {
		StringBuffer hql = new StringBuffer(
				"from NpiWeeklyComponentCommitmentOnForecast  o where o.PMSWaveID = :pmsWaveId and o.versionDate = :versionDate "
						+ "and o.orderLabel = :type ");
		Query query = getSession()
				.createQuery(hql.toString())
				.setResultTransformer(
						Transformers
								.aliasToBean(NpiWeeklyComponentCommitmentOnForecast.class));
		query.setParameter("pmsWaveId", Integer.parseInt(pmsWaveId));
		query.setParameter("versionDate", versionDate);
		query.setParameter("targetDate", targetDate);
		query.setParameter("type", type);
		return query.list();
	}
}
