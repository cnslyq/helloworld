package com.lenovo.bi.view.npi.ttv;


import java.util.Date;

import org.apache.commons.lang.StringUtils;

public class OrderUniqueIdentifie {
	private String poNumber;
	private String poItem;
	private String mtm;
	private Date orderDate;
	private Date rsdDate;
	private Integer quantity;
	private String region;
	
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getPoItem() {
		return poItem;
	}
	public void setPoItem(String poItem) {
		this.poItem = poItem;
	}
	public String getMtm() {
		return mtm;
	}
	public void setMtm(String mtm) {
		this.mtm = mtm;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Date getRsdDate() {
		return rsdDate;
	}
	public void setRsdDate(Date rsdDate) {
		this.rsdDate = rsdDate;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	@Override
	public int hashCode() {
		return poNumber.hashCode()*poItem.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		OrderUniqueIdentifie other =  (OrderUniqueIdentifie)obj;
		return  this.isStringEquals(poItem, other.getPoItem())
				&& this.isStringEquals(poNumber, other.getPoNumber())
				&&this.isStringEquals(mtm, other.getMtm())
				&&this.isStringEquals(region, other.getRegion())
				&&this.isDateEquals(orderDate, other.getOrderDate())
				&&this.isDateEquals(rsdDate, other.getRsdDate())
				&&this.isIntegerEquals(quantity, other.getQuantity());
	}
	private boolean isStringEquals(String str1, String str2){
		if(StringUtils.isNotBlank(str1)){
			return str1.equals(str2);
		}else{
			if(StringUtils.isBlank(str2)){
				return true;
			}else{
				return false;
			}
		}
	}
	private boolean isIntegerEquals(Integer i1,Integer i2){
		if(i1 != null && i2 != null){
			if(i1.compareTo(i2)==0){
				return true;
			}else{
				return false;
			}
		}else if(i1 == null && i2 == null){
			return true;
		}else{
			return false;
		}
	}
	private boolean isDateEquals(Date d1, Date d2){
		if(d1 != null && d2 != null){
			if(d1.compareTo(d2) == 0){
				return true;
			}else{
				return false;
			}
		}else if(d1 == null && d2 == null){
			return true;
		}else{
			return false;
		}
	}
}
