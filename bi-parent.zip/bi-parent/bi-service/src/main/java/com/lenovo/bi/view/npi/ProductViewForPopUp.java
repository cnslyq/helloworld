package com.lenovo.bi.view.npi;

import java.util.List;

import com.lenovo.bi.dto.ProductDataForPopup;

public class ProductViewForPopUp {
	private String durationFrom;
	private String durationTo;
	private List<ProductDataForPopup> popUpViews;
	
	private String productWaves;
	private String waveIds;
	
	public String getDurationFrom() {
		return durationFrom;
	}
	public void setDurationFrom(String durationFrom) {
		this.durationFrom = durationFrom;
	}
	public String getDurationTo() {
		return durationTo;
	}
	public void setDurationTo(String durationTo) {
		this.durationTo = durationTo;
	}
	public List<ProductDataForPopup> getPopUpViews() {
		return popUpViews;
	}
	public void setPopUpViews(List<ProductDataForPopup> popUpViews) {
		this.popUpViews = popUpViews;
	}
	public String getProductWaves() {
		return productWaves;
	}
	public void setProductWaves(String productWaves) {
		this.productWaves = productWaves;
	}
	public String getWaveIds() {
		return waveIds;
	}
	public void setWaveIds(String waveIds) {
		this.waveIds = waveIds;
	}

}
