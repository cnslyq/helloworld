package com.lenovo.bi.service.common;

import com.lenovo.bi.model.User;
/**
 * 
 * 
 * @author Henry_Lian
 *
 */
public interface UserService {
	public User getUserById(String userId);
}
