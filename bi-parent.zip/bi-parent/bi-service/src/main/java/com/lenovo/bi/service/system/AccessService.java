package com.lenovo.bi.service.system;

import java.util.List;

import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.system.GroupPrivilege;
import com.lenovo.bi.model.system.RolePrivilege;
import com.lenovo.bi.view.system.access.GroupPrivilegeDetailView;
import com.lenovo.bi.view.system.access.RolesDetailView;
import com.lenovo.bi.view.system.dictionary.GroupDetailView;
import com.lenovo.bi.view.system.dictionary.PrivilegeDetailView;
import com.lenovo.common.model.Pager;

public interface AccessService {

	public String getRoleTreeJson(String roleId);
	
	public Pager<RolesDetailView> listRoles(DictSearchForm form);
	
	public List<RolesDetailView> listRoles();
	
	public Pager<PrivilegeDetailView> listPrivileges(DictSearchForm form);
	
	public List<PrivilegeDetailView> listPrivilegesForRole();
	
	public void saveRolePrivilege(RolePrivilege[] rolePrivilegeArr);
	
	public void savePrivilegesForRole(String privilegeId,String roleIds);
	
	public List<RolePrivilege> listRolePrivilege(Integer roleId);
	
	public List<RolePrivilege> listRolePrivileges();
	
	public void deleteRolePrivilegeByRole(Integer roleId);
	
	public void deleteRolePrivilegeByPrivilege(Integer roleId);
	
	public List<RolesDetailView> listRolesForPrivilege(Integer privilegeId);
	
	
	public List<GroupDetailView> listGroups();
	
	public List<String> listGroupsForExcel();
	
	public List<PrivilegeDetailView> listPrivilegesForGroup();
	
	public List<GroupPrivilegeDetailView> listGroupPrivilegesForExcel(DictSearchForm form);
	
	public List<GroupPrivilege> listGroupPrivileges();
	
	public String getGroupTreeJson(String groupId);
	
	public void saveGroupPrivilege(GroupPrivilege[] groupPrivilegeArr,String groupId);
	
	public List<GroupDetailView> listGroupsForPrivilege(Integer privilegeId);
	
	public void savePrivilegesForGroup(String privilegeId,String groupIds);
	
}
