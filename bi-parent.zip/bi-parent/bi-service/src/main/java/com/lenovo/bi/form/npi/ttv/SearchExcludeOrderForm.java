package com.lenovo.bi.form.npi.ttv;

import java.text.ParseException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.lenovo.bi.enumobj.SortType;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.util.CalendarUtil;


public class SearchExcludeOrderForm {
	private Integer geoId;
	private Integer regionId;
	private String mtm;
	
	private Integer quantityScope;//there are three scope: <, >, =
	private String quantityValue;
	private String orderType;//there are three type:Late, Offset, Upside
	private Integer rsdScope;//there are three scope: <, >, =
	private String rsdValue;
	private Integer fgScope;//there are three scope: <, >, =
	private String fgValue;
	private boolean showExcludedOrderOnly; 
	private TTVPhase ttvPhase;
	private Date versionDate;
	private int currentPage;
	private SortType sortType;
	private String columnName;
	private boolean isPopup;
	private String geoName;
	private String regionName;
	
	public boolean isPopup() {
		return isPopup;
	}
	public void setPopup(boolean isPopup) {
		this.isPopup = isPopup;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public SortType getSortType() {
		return sortType;
	}
	public void setSortType(SortType sortType) {
		this.sortType = sortType;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public Integer getGeoId() {
		return geoId;
	}
	public void setGeoId(Integer geoId) {
		this.geoId = geoId;
	}
	public Integer getRegionId() {
		return regionId;
	}
	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}
	public String getQuantityValue() {
		return quantityValue;
	}
	public void setQuantityValue(String quantityValue) {
		this.quantityValue = quantityValue;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public boolean isShowExcludedOrderOnly() {
		return showExcludedOrderOnly;
	}
	public void setShowExcludedOrderOnly(boolean showExcludedOrderOnly) {
		this.showExcludedOrderOnly = showExcludedOrderOnly;
	}
	public Integer getQuantityScope() {
		return quantityScope;
	}
	public void setQuantityScope(Integer quantityScope) {
		this.quantityScope = quantityScope;
	}
	public Integer getRsdScope() {
		return rsdScope;
	}
	public void setRsdScope(Integer rsdScope) {
		this.rsdScope = rsdScope;
	}
	public String getMtm() {
		return mtm;
	}
	public void setMtm(String mtm) {
		this.mtm = mtm;
	}
	public String getRsdValue() {
		return rsdValue;
	}
	public void setRsdValue(String rsdValue) {
		this.rsdValue = rsdValue;
	}

	public Integer getFgScope() {
		return fgScope;
	}
	public void setFgScope(Integer fgScope) {
		this.fgScope = fgScope;
	}
	public String getFgValue() {
		return fgValue;
	}
	public void setFgValue(String fgValue) {
		this.fgValue = fgValue;
	}
	
	public Date getFGValueDate() {
		Date fgDate = null;
		try {
			fgDate =  CalendarUtil.stringT2Date(fgValue);
		} catch (ParseException e) {
			e.printStackTrace();
		};
		return fgDate;
	}
	
	public Date getRsdValueDate() {
		Date rsdDate = null;
		try {
			rsdDate =  CalendarUtil.stringT2Date(rsdValue);
		} catch (ParseException e) {
			e.printStackTrace();
		};
		return rsdDate;
	}
	public TTVPhase getTtvPhase() {
		return ttvPhase;
	}
	public void setTtvPhase(TTVPhase ttvPhase) {
		this.ttvPhase = ttvPhase;
	}
	public Date getVersionDate() {
		return versionDate;
	}
	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}
	public List<String> getListMtm(){
		List<String> listMtms = new ArrayList<String>();
		if( null != mtm && !mtm.equals("")){
			
			if (mtm.indexOf(";") != -1) {
				listMtms = Arrays.asList(mtm.split(";"));
			} else {
				listMtms = Arrays.asList(mtm.split("\r\n"));
			}
		}
		
		return listMtms;
	}
	public String getGeoName() {
		return geoName;
	}
	public void setGeoName(String geoName) {
		this.geoName = geoName;
	}
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
}
