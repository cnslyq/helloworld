package com.lenovo.bi.service.common;

import java.util.Set;

public interface MasterDataService {

	public Set<String> getGeos();
	
	public Set<String> getRegions();
	
	public Set<String> getRegionsByGeos(String geo);
	
	public Set<String> getOrderTypes();
	
	public Float getThresholdByName(String name);
	
	public void refreshMaps();
}
