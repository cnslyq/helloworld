package com.lenovo.bi.service.npi;

import java.util.List;
import java.util.Map;

import com.lenovo.bi.enumobj.NPIPhase;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
/**
 * 
 * 
 * @author Henry_Lian
 *
 */
public interface NPIRoleNpiService {
	
	public Map<Integer, List<String>> getNPIByWaveIds(List<Integer> waveIds);
	
	public List<String> getNPIByConditions(OverviewSearchForm form, NPIPhase phase);

}
