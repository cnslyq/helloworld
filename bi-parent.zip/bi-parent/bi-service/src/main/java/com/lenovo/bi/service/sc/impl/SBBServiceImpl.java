package com.lenovo.bi.service.sc.impl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.sc.SBBDao;
import com.lenovo.bi.form.sc.sbb.SearchSBBForm;
import com.lenovo.bi.service.sc.SBBService;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.sc.sbb.SBBDetailView;

@Service
@Transactional(value = "dw", propagation = Propagation.REQUIRES_NEW)
public class SBBServiceImpl  implements SBBService {
	
	@Inject
	SBBDao sbbDao;
	
	@Override
	public List<SBBDetailView> getSBBDetail(SearchSBBForm form) {
		List<SBBDetailView> list = sbbDao.getSBBDetail(form);
		return list;
	}

	@Override
	public int getSBBDetailCount(SearchSBBForm form) {
		return sbbDao.getSBBDetailCount(form);
	}

	@Override
	public void updateSBB(Map<String, Object> map) {
		sbbDao.updateSBB(map);
	}

	@Override
	public Map<String, Object> getSBBDetailExport(SearchSBBForm form) {
		List<SBBDetailView> grid = new ArrayList<SBBDetailView>();
		long totalCount = sbbDao.getSBBDetailCount(form);
		
		form.setRowCount(totalCount);
		form.setEndRow((int) totalCount);
		
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			grid = sbbDao.getSBBDetailExport(form);
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	
}
