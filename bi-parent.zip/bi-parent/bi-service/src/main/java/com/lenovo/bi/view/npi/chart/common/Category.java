package com.lenovo.bi.view.npi.chart.common;


public class Category extends CategoryParent {

	private String name;
	
	private int value;
	
	private String quarterValue;
	
	private String values;

	public String getValues() {
		return values;
	}

	public void setValues(String values) {
		this.values = values;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String getQuarterValue() {
		return quarterValue;
	}

	public void setQuarterValue(String quarterValue) {
		this.quarterValue = quarterValue;
	}
	
}
