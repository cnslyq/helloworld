package com.lenovo.bi.service.sc;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;


public interface SCService {
	public MSColumnChartView getSCOtsOverviewChart(SearchOtsForm form) throws ParseException;
	
	//public MSColumnChartView getSCCaOverviewChart(SearchOtsForm form) throws ParseException;
}
