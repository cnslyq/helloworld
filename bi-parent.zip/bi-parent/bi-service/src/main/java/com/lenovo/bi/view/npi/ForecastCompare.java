package com.lenovo.bi.view.npi;

public class ForecastCompare {

	private String geo;
	private String region;
	private String mtm;
	private String desc;
	private String description;
	private String cause;
	private int fcst;
	private int comparedFcst;
	private int upside;
	private int downside;
	private int offset;
	
	public String getCause() {
		return cause;
	}
	public void setCause(String cause) {
		this.cause = cause;
	}
	public String getGeo() {
		return geo;
	}
	public void setGeo(String geo) {
		this.geo = geo;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getMtm() {
		return mtm;
	}
	public void setMtm(String mtm) {
		this.mtm = mtm;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getFcst() {
		return fcst;
	}
	public void setFcst(int fcst) {
		this.fcst = fcst;
	}
	public int getComparedFcst() {
		return comparedFcst;
	}
	public void setComparedFcst(int comparedFcst) {
		this.comparedFcst = comparedFcst;
	}
	public int getUpside() {
		return upside;
	}
	public void setUpside(int upside) {
		this.upside = upside;
	}
	public int getDownside() {
		return downside;
	}
	public void setDownside(int downside) {
		this.downside = downside;
	}
	public int getOffset() {
		return offset;
	}
	public void setOffset(int offset) {
		this.offset = offset;
	}
	
}
