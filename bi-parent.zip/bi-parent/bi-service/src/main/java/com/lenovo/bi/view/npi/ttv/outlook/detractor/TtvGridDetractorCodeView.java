package com.lenovo.bi.view.npi.ttv.outlook.detractor;

import java.util.Date;

public class TtvGridDetractorCodeView {
	private String odm;
	private String geo;
	private String region;
	private String country;
	private String product;
	private String pn;// 59 P/N
	private String itemDesc;// item_description
	private String orderNo;
	private String itemNo;
	private String qty;// QTY
	private Date orderDate;
	private Date rsd;
	private String fpsd;
	private Date targetDate;
	private String ttvTargetDate;
	private Date shippedDate;
	//fgDate
	private Date fgDate;
	private String shipped;
	private String level1;
	private String level2;
	private String level3;
	private String levelC;
	private DetractorCode detractorCode;// Level 1,Level 2,C,Level 3
	private String poNumber;
	private String poItem;
	
	public String getOdm() {
		return odm;
	}

	public void setOdm(String odm) {
		this.odm = odm;
	}

	public String getGeo() {
		return geo;
	}

	public void setGeo(String geo) {
		this.geo = geo;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getPn() {
		return pn;
	}

	public void setPn(String pn) {
		this.pn = pn;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getItemNo() {
		return itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public String getQty() {
		return qty;
	}

	public void setQty(String qty) {
		this.qty = qty;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Date getRsd() {
		return rsd;
	}

	public void setRsd(Date rsd) {
		this.rsd = rsd;
	}

	public String getFpsd() {
		return fpsd;
	}

	public void setFpsd(String fpsd) {
		this.fpsd = fpsd;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public Date getShippedDate() {
		return shippedDate;
	}

	public void setShippedDate(Date shippedDate) {
		this.shippedDate = shippedDate;
	}

	public String getShipped() {
		return shipped;
	}

	public void setShipped(String shipped) {
		this.shipped = shipped;
	}

	public String getLevel1() {
		return level1;
	}

	public void setLevel1(String level1) {
		this.level1 = level1;
	}

	public String getLevel2() {
		return level2;
	}

	public void setLevel2(String level2) {
		this.level2 = level2;
	}

	public String getLevel3() {
		return level3;
	}

	public void setLevel3(String level3) {
		this.level3 = level3;
	}

	public String getLevelC() {
		return levelC;
	}

	public void setLevelC(String levelC) {
		this.levelC = levelC;
	}

	public DetractorCode getDetractorCode() {
		return detractorCode;
	}

	public void setDetractorCode(DetractorCode detractorCode) {
		this.detractorCode = detractorCode;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	
	public String getPoItem() {
		return poItem;
	}

	public void setPoItem(String poItem) {
		this.poItem = poItem;
	}

	public String getTtvTargetDate() {
		return ttvTargetDate;
	}

	public void setTtvTargetDate(String ttvTargetDate) {
		this.ttvTargetDate = ttvTargetDate;
	}

	public Date getFgDate() {
		return fgDate;
	}

	public void setFgDate(Date fgDate) {
		this.fgDate = fgDate;
	}
	
}
