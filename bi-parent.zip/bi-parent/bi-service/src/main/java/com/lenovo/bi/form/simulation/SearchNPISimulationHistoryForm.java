package com.lenovo.bi.form.simulation;
//for query simulation history
public class SearchNPISimulationHistoryForm {
	
	private Integer simulationId;
	
	private String fromDate;
	
	private String toDate;
	
	private String item;
	
	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public Integer getSimulationId() {
		return simulationId;
	}

	public void setSimulationId(Integer simulationId) {
		this.simulationId = simulationId;
	}
	
	
}
