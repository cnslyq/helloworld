package com.lenovo.bi.view.npi.ttm;
/**
 * 
 * ttm detail odm pojo
 * 
 * @author henry_lian
 *
 */
public class OdmCapacity {

	private String odm;
	private String line;
	private String crew;
	private int uph;
	private int hoursPerDay;
	private int daysPerWeek;
	private int output;
	private String useRpy;
	
	public String getUseRpy() {
		return useRpy;
	}
	public void setUseRpy(String useRpy) {
		this.useRpy = useRpy;
	}
	public String getOdm() {
		return odm;
	}
	public void setOdm(String odm) {
		this.odm = odm;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getCrew() {
		return crew;
	}
	public void setCrew(String crew) {
		this.crew = crew;
	}
	public int getUph() {
		return uph;
	}
	public void setUph(int uph) {
		this.uph = uph;
	}
	public int getHoursPerDay() {
		return hoursPerDay;
	}
	public void setHoursPerDay(int hoursPerDay) {
		this.hoursPerDay = hoursPerDay;
	}
	public int getDaysPerWeek() {
		return daysPerWeek;
	}
	public void setDaysPerWeek(int daysPerWeek) {
		this.daysPerWeek = daysPerWeek;
	}
	public int getOutput() {
		return output;
	}
	public void setOutput(int output) {
		this.output = output;
	}
}
