package com.lenovo.bi.service.npi.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.common.OdmCapacityDao;
import com.lenovo.bi.dao.npi.NPIOverviewDao;
import com.lenovo.bi.dao.npi.NPIProductSummaryDao;
import com.lenovo.bi.dao.npi.NpiOrderDaoBi;
import com.lenovo.bi.dao.npi.NpiOrderDaoDw;
import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.dto.DimMtm;
import com.lenovo.bi.dto.DimODM;
import com.lenovo.bi.dto.DimOrderForNPIExclude;
import com.lenovo.bi.dto.GeoData;
import com.lenovo.bi.dto.OdmCapacityPlanDetail;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.dto.TTVOutlookChartData;
import com.lenovo.bi.dto.TTVProduct;
import com.lenovo.bi.engine.ProductKeyPmsWaveIdMap;
import com.lenovo.bi.enumobj.CLevelEnum;
import com.lenovo.bi.enumobj.CapacityCausesEnum;
import com.lenovo.bi.enumobj.CausesCategory;
import com.lenovo.bi.enumobj.DBEnum;
import com.lenovo.bi.enumobj.DetractorEnum;
import com.lenovo.bi.enumobj.ForecastComparisonTypeEnum;
import com.lenovo.bi.enumobj.FulfillmentEnum;
import com.lenovo.bi.enumobj.FutureEnum;
import com.lenovo.bi.enumobj.LateOrderEnum;
import com.lenovo.bi.enumobj.MFGQualityEnum;
import com.lenovo.bi.enumobj.NAType;
import com.lenovo.bi.enumobj.NPIPhase;
import com.lenovo.bi.enumobj.NewWorkingEnum;
import com.lenovo.bi.enumobj.OverSPEnum;
import com.lenovo.bi.enumobj.Risk;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.enumobj.SupplyEnum;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.enumobj.TimeFrequencyEnum;
import com.lenovo.bi.enumobj.ToGoCaEnum;
import com.lenovo.bi.enumobj.VLevelEnum;
import com.lenovo.bi.exception.BusinessException;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
import com.lenovo.bi.form.npi.ttv.SearchOutlookDataForm;
import com.lenovo.bi.form.simulation.NPISimulationPreviewData;
import com.lenovo.bi.model.DimDetractor;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.service.common.MasterDataService;
import com.lenovo.bi.service.npi.RampCommitService;
import com.lenovo.bi.service.npi.TTVOutlookService;
import com.lenovo.bi.service.npi.TTVService;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.CommonUtil;
import com.lenovo.bi.util.ListSortUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.ProductWave;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.DataSetLine;
import com.lenovo.bi.view.npi.chart.column.LineSet;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSet;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.npi.chart.common.LabelCategory;
import com.lenovo.bi.view.npi.chart.common.Vline;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.chart.pie.PieSlice;
import com.lenovo.bi.view.npi.ttm.ProjectInformation;
import com.lenovo.bi.view.npi.ttv.ProjectOutLookView;
import com.lenovo.bi.view.npi.ttv.TtvGridProduct;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvDetractorCodeView;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.CausesByForecast;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.CausesByOrder;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.ForecastRelative;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.OrderRelative;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.TtvGridTrackingCauses;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.odm.TtvGridCapacityCausesView;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.odm.TtvGridOdmDetailsView;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.supply.TtvGridSupplyDetailsView;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.tooling.TtvGridToolingDetailsView;
import com.lenovo.common.model.NameValuePair;
import com.lenovo.common.model.Pager;
import com.lenovo.common.model.PagerInformation;

@Service
public class TTVServiceImpl implements TTVService {

	// private static Logger LOGGER = LoggerFactory.getLogger("TTVServiceImpl");

	private TTVOutlookService tTVOutlookService;

	@Inject
	private TTVOutlookServiceBiHelper tTVOutlookServiceBiHelper;

	@Inject
	private TTVOutlookServiceDwHelper tTVOutlookServiceDwHelper;

	@Inject
	private NPIOverviewDao nPIOverviewDao;

	@Inject
	private NPIProductSummaryDao nPIProductSummaryDao;

	@Inject
	private NpiOrderDaoDw npiOrderDaoDw;

	@Inject
	private NpiOrderDaoBi npiOrderDaoBi;

	@Inject
	private OdmCapacityDao odmCapacityDao;
	@Inject
	private MasterDataService masterDataService;

	@Inject
	private ProductKeyPmsWaveIdMap productKeyPmsWaveIdMap;

	@Autowired
	private RampCommitService rampCommitService;

	@Inject
	public void settTVOutlookService(TTVOutlookService tTVOutlookService) {
		this.tTVOutlookService = tTVOutlookService;
	}

	public TTVOutlookService gettTVOutlookService() {
		return tTVOutlookService;
	}

	public NPIOverviewDao getnPIOverviewDao() {
		return nPIOverviewDao;
	}

	@Inject
	public void setnPIOverviewDao(NPIOverviewDao nPIOverviewDao) {
		this.nPIOverviewDao = nPIOverviewDao;
	}

	public NpiOrderDaoBi getNpiOrderDaoBi() {
		return npiOrderDaoBi;
	}

	@Inject
	public void setNpiOrderDaoBi(NpiOrderDaoBi npiOrderDaoBi) {
		this.npiOrderDaoBi = npiOrderDaoBi;
	}

	@Override
	public PieChartView getChartDataByConditions(OverviewSearchForm form) {
		if (form.getGridType() == Status.In_Progress
				|| form.getSgaGridType() == Status.In_Progress) {
			List<NameValuePair> list = nPIOverviewDao.getRiskStatusByPhase(
					form.getPhase(), form);
			PieChartView pView = new PieChartView();
			List<PieSlice> pieList = new ArrayList<PieSlice>();
			for (NameValuePair nv : list) {
				Risk s = Risk.valueOf(nv.getName());
				PieSlice p = new PieSlice();
				p.setColor(s.getColor());
				p.setLabel(s.toString() + "(" + nv.getValue() + ")");
				p.setValue(nv.getValue());
				pieList.add(p);
			}
			pView.setElements(pieList);
			return pView;
		}
		if (form.getGridType() == Status.All
				|| form.getSgaGridType() == Status.All) {
			List<NameValuePair> list = nPIOverviewDao.getProjectStatusByPhase(
					form.getPhase(), form);
			PieChartView pView = new PieChartView();
			List<PieSlice> pieList = new ArrayList<PieSlice>();
			for (NameValuePair nv : list) {
				Status s = Status.valueOf(nv.getName());
				PieSlice p = new PieSlice();
				if (form.getPhase() == NPIPhase.sgaTtv) {
					p.setLink(form.getPhase() + s.getUrl() + "?tp="
							+ new Date());
				} else {
					p.setLink(s.getUrl() + "?tp=" + new Date());
				}
				p.setColor(s.getColor());
				p.setLabel(s.toString() + "(" + nv.getValue() + ")");
				p.setValue(nv.getValue());
				pieList.add(p);
			}
			pView.setElements(pieList);
			return pView;
		}
		return null;
	}

	private PieChartView getDetractorMainPieChart(
			Map<String, String> detractorMap) {
		if (detractorMap == null) {
			return null;
		}

		List<PieSlice> list = new ArrayList<PieSlice>();
		Set<String> detractorSet = detractorMap.keySet();
		int listNum = 0;
		for (Iterator<String> it = detractorSet.iterator(); it.hasNext();) {
			String key = (String) it.next();
			String value = detractorMap.get(key);
			PieSlice ps = new PieSlice();
			ps.setLink("j-showDetractorSubPieAndData-" + key + "-" + listNum++);
			ps.setLabel(key);
			// ps.setColor(DetractorEnum.Future.getColor());
			ps.setValue(value);
			list.add(ps);
		}
		/*
		 * String number = detractorMap.get(DetractorEnum.Future.toUpperCase());
		 * if (!StringUtils.isBlank(number)) { PieSlice ps = new PieSlice();
		 * ps.setLink("j-showDetractorSubPieAndData-Future");
		 * ps.setLabel(DetractorEnum.Future.toString());
		 * ps.setColor(DetractorEnum.Future.getColor()); ps.setValue(number);
		 * list.add(ps); }
		 * 
		 * number = detractorMap.get(DetractorEnum.DB.toUpperCase()); if
		 * (!StringUtils.isBlank(number)) { PieSlice ps = new PieSlice();
		 * ps.setLink("j-showDetractorSubPieAndData-DB");
		 * ps.setLabel(DetractorEnum.DB.toString());
		 * ps.setColor(DetractorEnum.DB.getColor()); ps.setValue(number);
		 * list.add(ps); }
		 * 
		 * number = detractorMap.get(DetractorEnum.Over_SP.toUpperCase()); if
		 * (!StringUtils.isBlank(number)) { PieSlice ps = new PieSlice();
		 * ps.setLink("j-showDetractorSubPieAndData-Over SP");
		 * ps.setLabel(DetractorEnum.Over_SP.toString());
		 * ps.setColor(DetractorEnum.Over_SP.getColor()); ps.setValue(number);
		 * list.add(ps); }
		 * 
		 * number = detractorMap.get(DetractorEnum.Supply.toUpperCase()); if
		 * (!StringUtils.isBlank(number)) { PieSlice ps = new PieSlice();
		 * ps.setLink("j-showDetractorSubPieAndData-Supply");
		 * ps.setLabel(DetractorEnum.Supply.toString());
		 * ps.setColor(DetractorEnum.Supply.getColor()); ps.setValue(number);
		 * list.add(ps); }
		 * 
		 * number = detractorMap.get(DetractorEnum.Fulfillment.toUpperCase());
		 * if (!StringUtils.isBlank(number)) { PieSlice ps = new PieSlice();
		 * ps.setLink("j-showDetractorSubPieAndData-Fulfillment");
		 * ps.setLabel(DetractorEnum.Fulfillment.toString());
		 * ps.setColor(DetractorEnum.Fulfillment.getColor());
		 * ps.setValue(number); list.add(ps); }
		 * 
		 * number = detractorMap.get(DetractorEnum.MFG_Quality.toUpperCase());
		 * if (!StringUtils.isBlank(number)) { PieSlice ps = new PieSlice();
		 * ps.setLink("j-showDetractorSubPieAndData-MFG/Quality");
		 * ps.setLabel(DetractorEnum.MFG_Quality.toString());
		 * ps.setColor(DetractorEnum.MFG_Quality.getColor());
		 * ps.setValue(number); list.add(ps); }
		 * 
		 * number = detractorMap.get(DetractorEnum.NEW_Working.toUpperCase());
		 * if (!StringUtils.isBlank(number)) { PieSlice ps = new PieSlice();
		 * ps.setLink("j-showDetractorSubPieAndData-NEW/Working");
		 * ps.setLabel(DetractorEnum.NEW_Working.toString());
		 * ps.setColor(DetractorEnum.NEW_Working.getColor());
		 * ps.setValue(number); list.add(ps); }
		 * 
		 * number = detractorMap.get(DetractorEnum.To_Go_CA.toUpperCase()); if
		 * (!StringUtils.isBlank(number)) { PieSlice ps = new PieSlice();
		 * ps.setLink("j-showDetractorSubPieAndData-To Go CA");
		 * ps.setLabel(DetractorEnum.To_Go_CA.toString());
		 * ps.setColor(DetractorEnum.To_Go_CA.getColor()); ps.setValue(number);
		 * list.add(ps); }
		 * 
		 * number = detractorMap.get(DetractorEnum.LATE_ORDER.toUpperCase()); if
		 * (!StringUtils.isBlank(number)) { PieSlice ps = new PieSlice();
		 * ps.setLink("j-showDetractorSubPieAndData-LATE ORDER");
		 * ps.setLabel(DetractorEnum.LATE_ORDER.toString());
		 * ps.setColor(DetractorEnum.LATE_ORDER.getColor());
		 * ps.setValue(number); list.add(ps); }
		 * 
		 * number = detractorMap.get(DetractorEnum.Unknown.toUpperCase()); if
		 * (!StringUtils.isBlank(number)) { PieSlice ps = new PieSlice();
		 * ps.setLink("j-showDetractorSubPieAndData-Unknown");
		 * ps.setLabel(DetractorEnum.Unknown.toString());
		 * ps.setColor(DetractorEnum.Unknown.getColor()); ps.setValue(number);
		 * list.add(ps); }
		 */
		PieChartView pView = new PieChartView();
		pView.setElements(list);
		return pView;
	}

	private PieChartView getDetractorSubPieChart(
			Map<String, String> detractorMap, String parentType) {
		if (detractorMap == null) {
			return null;
		}
		List<PieSlice> list = new ArrayList<PieSlice>();
		Set<String> detractorSet = detractorMap.keySet();
		int listNum = 0;
		for (Iterator<String> it = detractorSet.iterator(); it.hasNext();) {
			String key = (String) it.next();
			String value = detractorMap.get(key);
			PieSlice ps = new PieSlice();
			ps.setLink("j-fetchDetractorData-all," + key + "-" + listNum++);
			ps.setLabel(key);
			// ps.setColor(DetractorEnum.Future.getColor());
			ps.setValue(value);
			list.add(ps);
		}
		/*
		 * if (DetractorEnum.Supply.toString().equalsIgnoreCase(parentType)) {
		 * list = getSupplyPieChart(detractorMap); } else if
		 * (DetractorEnum.Over_SP.toString().equalsIgnoreCase(parentType)) {
		 * list = getOverSPPieChart(detractorMap); } else if
		 * (DetractorEnum.Fulfillment.toString().equalsIgnoreCase(parentType)) {
		 * list = getFulfillmentPieChart(detractorMap); } else if
		 * (DetractorEnum.MFG_Quality.toString().equalsIgnoreCase(parentType)) {
		 * list = getMFGQualityPieChart(detractorMap); } else if
		 * (DetractorEnum.Future.toString().equalsIgnoreCase(parentType)) { list
		 * = getFuturePieChart(detractorMap); } else if
		 * (DetractorEnum.DB.toString().equalsIgnoreCase(parentType)) { list =
		 * getDBPieChart(detractorMap); } else if
		 * (DetractorEnum.NEW_Working.toString().equalsIgnoreCase(parentType)) {
		 * list = getNewWorkingPieChart(detractorMap); } else if
		 * (DetractorEnum.To_Go_CA.toString().equalsIgnoreCase(parentType)) {
		 * list = getToGoCAPieChart(detractorMap); } else if
		 * (DetractorEnum.Unknown.toString().equalsIgnoreCase(parentType)) { //
		 * list = getUnknownPieChart(detractorMap); } else if
		 * (DetractorEnum.LATE_ORDER.toString().equalsIgnoreCase(parentType)) {
		 * list = getLateOrderPieChart(detractorMap); }
		 */

		PieChartView pView = new PieChartView();

		pView.setElements(list);
		return pView;
	}

	public List<PieSlice> getLateOrderPieChart(Map<String, String> detractorMap) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-fetchDetractorData-LATE ORDER L,"
				+ LateOrderEnum.LATE_ORDER_L.toString());
		p1.setLabel(LateOrderEnum.LATE_ORDER_L.toString());
		p1.setColor(LateOrderEnum.LATE_ORDER_L.getColor());
		p1.setValue(detractorMap.get(LateOrderEnum.LATE_ORDER_L.toString()
				.toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);

		return list;
	}

	public List<PieSlice> getToGoCAPieChart(Map<String, String> detractorMap) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-fetchDetractorData-To Go CA,"
				+ ToGoCaEnum.To_Go_CA.toString());
		p1.setLabel(ToGoCaEnum.To_Go_CA.toString());
		p1.setColor(ToGoCaEnum.To_Go_CA.getColor());
		p1.setValue(detractorMap.get(ToGoCaEnum.To_Go_CA.toString()
				.toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);

		return list;
	}

	public List<PieSlice> getNewWorkingPieChart(Map<String, String> detractorMap) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-fetchDetractorData-NEW Working,"
				+ NewWorkingEnum.Working.toString());
		p1.setLabel(NewWorkingEnum.Working.toString());
		p1.setColor(NewWorkingEnum.Working.getColor());
		p1.setValue(detractorMap.get(NewWorkingEnum.Working.toString()
				.toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);

		return list;
	}

	public List<PieSlice> getDBPieChart(Map<String, String> detractorMap) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-fetchDetractorData-DB,"
				+ DBEnum.Delivery_block_L.toString());
		p1.setLabel(DBEnum.Delivery_block_L.toString());
		p1.setColor(DBEnum.Delivery_block_L.getColor());
		p1.setValue(detractorMap.get(DBEnum.Delivery_block_L.toString()
				.toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);

		return list;
	}

	public List<PieSlice> getFulfillmentPieChart(
			Map<String, String> detractorMap) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-fetchDetractorData-Fullfillment,"
				+ FulfillmentEnum.Holiday_Cycle_Count.toString());
		p1.setLabel(FulfillmentEnum.Holiday_Cycle_Count.toString());
		p1.setColor(FulfillmentEnum.Holiday_Cycle_Count.getColor());
		p1.setValue(detractorMap.get(FulfillmentEnum.Holiday_Cycle_Count
				.toString().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);

		return list;
	}

	public List<PieSlice> getSupplyPieChart(Map<String, String> detractorMap) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-fetchDetractorData-Supply,"
				+ SupplyEnum.BS_parts_shortage.toString());
		p1.setLabel(SupplyEnum.BS_parts_shortage.toString());
		p1.setColor(SupplyEnum.BS_parts_shortage.getColor());
		p1.setValue(detractorMap.get(SupplyEnum.BS_parts_shortage.toString()
				.toUpperCase()));

		PieSlice p2 = new PieSlice();
		p2.setLink("j-fetchDetractorData-Supply,"
				+ SupplyEnum.ODM_buy_parts_shortage.toString());
		p2.setLabel(SupplyEnum.ODM_buy_parts_shortage.toString());
		p2.setColor(SupplyEnum.ODM_buy_parts_shortage.getColor());
		p2.setValue(detractorMap.get(SupplyEnum.ODM_buy_parts_shortage
				.toString().toUpperCase()));

		PieSlice p3 = new PieSlice();
		p3.setLink("j-fetchDetractorData-Supply,"
				+ SupplyEnum.Tie_order_L.toString());
		p3.setLabel(SupplyEnum.Tie_order_L.toString());
		p3.setColor(SupplyEnum.Tie_order_L.getColor());
		p3.setValue(detractorMap.get(SupplyEnum.Tie_order_L.toString()
				.toUpperCase().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);

		return list;
	}

	public List<PieSlice> getOverSPPieChart(Map<String, String> detractorMap) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-fetchDetractorData-Over SP,"
				+ OverSPEnum.Over_EOL_LTB_L.toString());
		p1.setLabel(OverSPEnum.Over_EOL_LTB_L.toString());
		p1.setColor(OverSPEnum.Over_EOL_LTB_L.getColor());
		p1.setValue(detractorMap.get(OverSPEnum.Over_EOL_LTB_L.toString()
				.toUpperCase()));

		PieSlice p2 = new PieSlice();
		p2.setLink("j-fetchDetractorData-Over SP,"
				+ OverSPEnum.Over_forecast.toString());
		p2.setLabel(OverSPEnum.Over_forecast.toString());
		p2.setColor(OverSPEnum.Over_forecast.getColor());
		p2.setValue(detractorMap.get(OverSPEnum.Over_forecast.toString()
				.toUpperCase()));

		PieSlice p3 = new PieSlice();
		p3.setLink("j-fetchDetractorData-Over SP,"
				+ OverSPEnum.No_forecast.toString());
		p3.setLabel(OverSPEnum.No_forecast.toString());
		p3.setColor(OverSPEnum.No_forecast.getColor());
		p3.setValue(detractorMap.get(OverSPEnum.No_forecast.toString()
				.toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);

		return list;
	}

	public List<PieSlice> getMFGQualityPieChart(Map<String, String> detractorMap) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-fetchDetractorData-MFG Quality,"
				+ MFGQualityEnum.Npi_issue_O.toString());
		p1.setLabel(MFGQualityEnum.Npi_issue_O.toString());
		p1.setColor(MFGQualityEnum.Npi_issue_O.getColor());
		p1.setValue(detractorMap.get(MFGQualityEnum.Npi_issue_O.toString()
				.toUpperCase()));

		PieSlice p2 = new PieSlice();
		p2.setLink("j-fetchDetractorData-MFG Quality,"
				+ MFGQualityEnum.Npi_issue_L.toString());
		p2.setLabel(MFGQualityEnum.Npi_issue_L.toString());
		p2.setColor(MFGQualityEnum.Npi_issue_L.getColor());
		p2.setValue(detractorMap.get(MFGQualityEnum.Npi_issue_L.toString()
				.toUpperCase()));

		PieSlice p3 = new PieSlice();
		p3.setLink("j-fetchDetractorData-MFG Quality,"
				+ MFGQualityEnum.Output_delay.toString());
		p3.setLabel(MFGQualityEnum.Output_delay.toString());
		p3.setColor(MFGQualityEnum.Output_delay.getColor());
		p3.setValue(detractorMap.get(MFGQualityEnum.Output_delay.toString()
				.toUpperCase()));

		PieSlice p4 = new PieSlice();
		p4.setLink("j-fetchDetractorData-MFG Quality,"
				+ MFGQualityEnum.Quality_issue_O.toString());
		p4.setLabel(MFGQualityEnum.Quality_issue_O.toString());
		p4.setColor(MFGQualityEnum.Quality_issue_O.getColor());
		p4.setValue(detractorMap.get(MFGQualityEnum.Quality_issue_O.toString()
				.toUpperCase()));

		PieSlice p5 = new PieSlice();
		p5.setLink("j-fetchDetractorData-MFG Quality,"
				+ MFGQualityEnum.Quality_issue_L.toString());
		p5.setLabel(MFGQualityEnum.Quality_issue_L.toString());
		p5.setColor(MFGQualityEnum.Quality_issue_L.getColor());
		p5.setValue(detractorMap.get(MFGQualityEnum.Quality_issue_L.toString()
				.toUpperCase()));

		PieSlice p6 = new PieSlice();
		p6.setLink("j-fetchDetractorData-MFG Quality,"
				+ MFGQualityEnum.Engineer_issue_O.toString());
		p6.setLabel(MFGQualityEnum.Engineer_issue_O.toString());
		p6.setColor(MFGQualityEnum.Engineer_issue_O.getColor());
		p6.setValue(detractorMap.get(MFGQualityEnum.Engineer_issue_O.toString()
				.toUpperCase()));

		PieSlice p7 = new PieSlice();
		p7.setLink("j-fetchDetractorData-MFG Quality,"
				+ MFGQualityEnum.Engineer_issue_L.toString());
		p7.setLabel(MFGQualityEnum.Engineer_issue_L.toString());
		p7.setColor(MFGQualityEnum.Engineer_issue_L.getColor());
		p7.setValue(detractorMap.get(MFGQualityEnum.Engineer_issue_L.toString()
				.toUpperCase()));

		PieSlice p8 = new PieSlice();
		p8.setLink("j-fetchDetractorData-MFG Quality,"
				+ MFGQualityEnum.Capacity_constraint_O.toString());
		p8.setLabel(MFGQualityEnum.Capacity_constraint_O.toString());
		p8.setColor(MFGQualityEnum.Capacity_constraint_O.getColor());
		p8.setValue(detractorMap.get(MFGQualityEnum.Capacity_constraint_O
				.toString().toUpperCase()));

		PieSlice p9 = new PieSlice();
		p9.setLink("j-fetchDetractorData-MFG Quality,"
				+ MFGQualityEnum.Capacity_constraint_L.toString());
		p9.setLabel(MFGQualityEnum.Capacity_constraint_L.toString());
		p9.setColor(MFGQualityEnum.Capacity_constraint_L.getColor());
		p9.setValue(detractorMap.get(MFGQualityEnum.Capacity_constraint_L
				.toString().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		list.add(p5);
		list.add(p6);
		list.add(p7);
		list.add(p8);
		list.add(p9);

		return list;
	}

	public List<PieSlice> getFuturePieChart(Map<String, String> detractorMap) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-fetchDetractorData-Future,"
				+ FutureEnum.Future_order_L.toString());
		p1.setLabel(FutureEnum.Future_order_L.toString());
		p1.setColor(FutureEnum.Future_order_L.getColor());
		p1.setValue(detractorMap.get(FutureEnum.Future_order_L.toString()
				.toUpperCase()));

		PieSlice p2 = new PieSlice();
		p2.setLink("j-fetchDetractorData-Future,"
				+ FutureEnum.Late_RSD_L.toString());
		p2.setLabel(FutureEnum.Late_RSD_L.toString());
		p2.setColor(FutureEnum.Late_RSD_L.getColor());
		p2.setValue(detractorMap.get(FutureEnum.Late_RSD_L.toString()
				.toUpperCase()));

		PieSlice p3 = new PieSlice();
		p3.setLink("j-fetchDetractorData-Future,"
				+ FutureEnum.Late_order_L.toString());
		p3.setLabel(FutureEnum.Late_order_L.toString());
		p3.setColor(FutureEnum.Late_order_L.getColor());
		p3.setValue(detractorMap.get(FutureEnum.Late_order_L.toString()
				.toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);

		return list;
	}

	@Override
	public Pager<TtvGridProduct> getProductsByConditions(OverviewSearchForm form) {
		Pager<TtvGridProduct> pager = new Pager<TtvGridProduct>();
		PagerInformation info = new PagerInformation();
		pager.setPagerInfo(info);
		info.setCurrentPage(form.getCurrentPage());
		info.setPageSize(masterDataService.getThresholdByName(
				Threshold.PAGE_SIZE.name()).intValue());

		List<TTVProduct> rawList = nPIOverviewDao.getTTVProductsByConditions(
				form, pager.getPagerInfo());

		// String naType = form.getNaType() != null ? form.getNaType().name() :
		// "";

		Map<Integer, List<String>> waveNpiMap = null;
		if (form.getWaveIds() != null && form.getWaveIds().size() > 0)
			waveNpiMap = nPIProductSummaryDao
					.getNPIByWaveIds(form.getWaveIds());
		if (waveNpiMap == null)
			waveNpiMap = new HashMap<Integer, List<String>>();
		List<TtvGridProduct> list = convert2Pojo(rawList, waveNpiMap);

		pager.setDatas(list);

		int recordCount = nPIOverviewDao.getTTVProductCountByConditions(form);
		info.setRecordCount(recordCount);
		return pager;
	}

	private List<TtvGridProduct> convert2Pojo(List<TTVProduct> rawList,
			Map<Integer, List<String>> waveNpiMap) {

		List<TtvGridProduct> list = new ArrayList<TtvGridProduct>();
		List<Integer> waveIds = new ArrayList<Integer>();

		for (TTVProduct ttvProduct : rawList) {
			TtvGridProduct tp = new TtvGridProduct();
			// System.out.println(ttvProduct.isProjectPlanned());
			if (!ttvProduct.isProjectPlanned())
				tp.setNaType(NAType.No_Project_Plan.name());
			else if (ttvProduct.getTtvTargetDate() == null)
				tp.setNaType(NAType.No_TTV_Target_Date.name());
			tp.setSgaNaType(ttvProduct.getSgaNaType());
			String npiOwner = null;
			if (waveNpiMap.containsKey(ttvProduct.getWaveId())) {
				npiOwner = CommonUtil.npiNameString(waveNpiMap.get(ttvProduct
						.getWaveId()));
			}
			tp.setNpiOwner(npiOwner);
			waveIds.add(ttvProduct.getNpiWaveId());
			tp.setWaveId(ttvProduct.getNpiWaveId());
			tp.setProductId(ttvProduct.getProjectId());
			if (!StringUtil.isEmpty(ttvProduct.getWaveName())) {
				tp.setWaveName(ttvProduct.getWaveName());
			} else {
				tp.setWaveName("...");
			}
			tp.setProductName(ttvProduct.getProductName());
			if (ttvProduct.getTtvTarget() != null) {
				tp.setTtvTarget(String.valueOf(ttvProduct.getTtvTarget()));
			}
			if (ttvProduct.getEstimatedTTV() != null) {
				tp.setEstimatedTTV(String.valueOf(Math.round(ttvProduct
						.getEstimatedTTV() * 10) / 10.0));
			}
			if (ttvProduct.getActualTTV() != null) {
				tp.setActualTTV(String.valueOf(Math.round(ttvProduct
						.getActualTTV() * 10) / 10.0));
			}
			if (ttvProduct.getTtvSignOffDate() != null) {
				tp.setTTVSignOff(true);
			} else {
				tp.setTTVSignOff(false);
			}
			if (ttvProduct.getTtvStatus() != null) {
				Status s = Status.valueOf(ttvProduct.getTtvStatus());
				tp.setStatusColor(s.getLabelColor());
				tp.setStatus(s.toString());
				if (s == Status.In_Progress) {
					if (ttvProduct.isRisk()) {
						tp.setRisk(Risk.Risk.toString());
						tp.setRiskColor(Risk.Risk.getLabelColor());
					} else {
						tp.setRisk(Risk.No_Risk.toString());
						tp.setRiskColor(Risk.No_Risk.getLabelColor());
					}
				}
			}

			if (ttvProduct.getSgaTtvTarget() != null) {
				tp.setSgaTtvTarget(String.valueOf(ttvProduct.getSgaTtvTarget()));
			}
			if (ttvProduct.getSgaEstimatedTTV() != null) {
				tp.setSgaEstimatedTTV(String.valueOf(Math.round(ttvProduct
						.getSgaEstimatedTTV() * 10) / 10.0));
			}
			if (ttvProduct.getSgaActualTTV() != null) {
				tp.setSgaActualTTV(String.valueOf(Math.round(ttvProduct
						.getSgaActualTTV() * 10) / 10.0));
			}
			if (ttvProduct.getSgaTtvSignOffDate() != null) {
				tp.setSgaTTVSignOff(true);
			} else {
				tp.setSgaTTVSignOff(false);
			}

			if (ttvProduct.getSgaTtvStatus() != null) {
				Status s = Status.valueOf(ttvProduct.getSgaTtvStatus());
				tp.setSgaStatusColor(s.getLabelColor());
				tp.setSgaStatus(s.toString());
				if (s == Status.In_Progress) {
					if (ttvProduct.getIsSgaTtvRisk()) {
						tp.setSgaRisk(Risk.Risk.toString());
						tp.setSgaRiskColor(Risk.Risk.getLabelColor());
					} else {
						tp.setSgaRisk(Risk.No_Risk.toString());
						tp.setSgaRiskColor(Risk.No_Risk.getLabelColor());
					}
				}
			}

			tp.setCurrentPhase(ttvProduct.getCurrentPhase());
			tp.setPmOwner(ttvProduct.getPm());
			try {
				tp.setStartDate(CalendarUtil.date2String(ttvProduct
						.getStartDate()));
			} catch (ParseException e1) {
			}

			try {
				if (ttvProduct.getTtmSignOffDate() != null) {
					tp.setTtmSignOffDate(CalendarUtil.date2String(ttvProduct
							.getTtmSignOffDate()));
				}

				if (ttvProduct.getTtvTargetDate() != null) {
					tp.setTtvTargetDate(CalendarUtil.date2String(ttvProduct
							.getTtvTargetDate()));
				}

				if (ttvProduct.getTtvSignOffDate() != null) {
					tp.setTtvSignOffDate(CalendarUtil.date2String(ttvProduct
							.getTtvSignOffDate()));
				}

				// if (ttvProduct.getTtvTargetDate() != null
				// && ttvProduct.getTtvSignOffDate() != null) {
				// if (ttvProduct.getTtvTargetDate().before(
				// ttvProduct.getTtvSignOffDate())
				// || CalendarUtil.isSameDay(
				// ttvProduct.getTtvTargetDate(),
				// ttvProduct.getTtvSignOffDate())) {
				// tp.setTargetDatePassed(true);
				// }
				//
				// if (!CalendarUtil.isSameDay(ttvProduct.getTtvTargetDate(),
				// ttvProduct.getTtvSignOffDate())) {
				// tp.setShowSignedSnapshot(true);
				// }
				// }
				Date now = new Date();
				if (ttvProduct.getTtvTargetDate() != null
						&& !"".equals(ttvProduct.getTtvTargetDate())) {
					if (ttvProduct.getTtvTargetDate().before(now)
							&& CalendarUtil.getDateByString(
									masterDataService.getThresholdByName(
											Threshold.NPI_LOAD_DATE.name())
											.intValue()
											+ "").getTime() < ttvProduct
									.getTtvTargetDate().getTime()) {
						tp.setTargetDatePassed(true);
					}
				}

				if (ttvProduct.getTtvSignOffDate() != null
						&& !"".equals(ttvProduct.getTtvSignOffDate())) {
					if (ttvProduct.getTtvSignOffDate().before(now)
							&& CalendarUtil.getDateByString(
									masterDataService.getThresholdByName(
											Threshold.NPI_LOAD_DATE.name())
											.intValue()
											+ "").getTime() < ttvProduct
									.getTtvSignOffDate().getTime()) {
						tp.setShowSignedSnapshot(true);
					}
				}

				if (ttvProduct.getSgaTtvTargetDate() != null) {
					tp.setSgaTtvTargetDate(CalendarUtil.date2String(ttvProduct
							.getSgaTtvTargetDate()));
				}

				if (ttvProduct.getSgaTtvSignOffDate() != null) {
					tp.setSgaTtvSignOffDate(CalendarUtil.date2String(ttvProduct
							.getSgaTtvSignOffDate()));
				}

				// if (ttvProduct.getSgaTtvTargetDate() != null &&
				// ttvProduct.getSgaTtvSignOffDate() != null) {
				// if
				// (ttvProduct.getSgaTtvTargetDate().before(ttvProduct.getSgaTtvSignOffDate())
				// || CalendarUtil.isSameDay(ttvProduct.getSgaTtvTargetDate(),
				// ttvProduct.getSgaTtvSignOffDate())) {
				// tp.setSgaTargetDatePassed(true);
				// }
				//
				// if (!CalendarUtil.isSameDay(ttvProduct.getSgaTtvTargetDate(),
				// ttvProduct.getSgaTtvSignOffDate())) {
				// tp.setSgaShowSignedSnapshot(true);
				// }
				// }

				if (ttvProduct.getSgaTtvTargetDate() != null
						&& !"".equals(ttvProduct.getSgaTtvTargetDate())) {
					if (ttvProduct.getSgaTtvTargetDate().before(now)
							&& CalendarUtil.getDateByString(
									masterDataService.getThresholdByName(
											Threshold.NPI_LOAD_DATE.name())
											.intValue()
											+ "").getTime() < ttvProduct
									.getSgaTtvTargetDate().getTime()) {
						tp.setSgaTargetDatePassed(true);
					}
				}

				if (ttvProduct.getSgaTtvSignOffDate() != null
						&& !"".equals(ttvProduct.getSgaTtvSignOffDate())) {
					if (ttvProduct.getSgaTtvSignOffDate().before(now)
							&& CalendarUtil.getDateByString(
									masterDataService.getThresholdByName(
											Threshold.NPI_LOAD_DATE.name())
											.intValue()
											+ "").getTime() < ttvProduct
									.getSgaTtvSignOffDate().getTime()) {
						tp.setSgaShowSignedSnapshot(true);
					}
				}

				if (ttvProduct.getTtmTargetDate() != null) {
					tp.setTtmTargetDate(CalendarUtil.date2String(ttvProduct
							.getTtmTargetDate()));
				}

			} catch (ParseException e) {
				e.printStackTrace();
			}
			list.add(tp);
		}
		if (!waveIds.isEmpty()) {
			Map<Integer, List<String>> npis = nPIProductSummaryDao
					.getNPIByWaveIds(waveIds);

			for (TtvGridProduct t : list) {
				if (npis.get(t.getWaveId()) != null) {
					t.setNpiOwner(CommonUtil.npiNameString(npis.get(t
							.getWaveId())));
				}

			}
		}

		return list;
	}

	public MSColumnChartView getOutlookJsonChartDataByWeekly(
			SearchOutlookDataForm form, Boolean isPreview,
			List<NpiOrder> orders, boolean isSnapshot,
			Map<String, NPISimulationPreviewData> previewDataMap)
			throws ParseException {

		boolean actualSleFlag = true;
		// fetch wave info
		ProjectSummary ps = nPIProductSummaryDao.getProductInfoByWaveId(
				form.getWaveId(), form.getVersionDate());
		// process start date and end date
		if (form.getStartDate() == null) {
			if (ps.getTtvTargetDate() == null) {
				return null;
			}
			Float startNum = masterDataService
					.getThresholdByName(Threshold.TTV_OUTLOOK_STARTDATE.name());
			Float endNum = masterDataService
					.getThresholdByName(Threshold.TTV_OUTLOOK_ENDDATE.name());

			form.setStartDate(CalendarUtil.getMondayDateByWeeks(
					ps.getTtvTargetDate(), startNum.intValue()));
			form.setEndDate(CalendarUtil.getMondayDateByWeeks(
					ps.getTtvTargetDate(), endNum.intValue()));
		} else {
			Float durationNum = masterDataService
					.getThresholdByName(Threshold.TTV_OUTLOOK_DURATION.name());
			form.setEndDate(CalendarUtil.getMondayDateByWeeks(
					form.getStartDate(), durationNum.intValue()));
		}
		if (form.getVersionDate() == null) {
			Date versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil
					.getTodayWithoutMins());
			form.setVersionDate(versionDate);
		}

		boolean odmFpy = "ODM".equals(form.getFpy()) ? true : false;

		List<TTVOutlookChartData> tTVOutlookChartDataList;
		if (previewDataMap != null) {
			tTVOutlookChartDataList = tTVOutlookService.simulationSLEPreview(
					form.getWaveId(), odmFpy, form.getVersionDate(),
					form.getStartDate(), form.getEndDate(),
					form.isShowSgaOrSle(), previewDataMap);
		} else {
			if (!isPreview) {
				tTVOutlookChartDataList = tTVOutlookService.getChartData(
						form.getWaveId(), form.getStartDate(),
						form.getEndDate(), TimeFrequencyEnum.WEEKLY, odmFpy,
						form.getVersionDate(), form.isShowSgaOrSle(),
						isSnapshot);
			} else {
				tTVOutlookChartDataList = tTVOutlookService
						.excludeOrderPreview(form.getWaveId(),
								form.getStartDate(), form.getEndDate(),
								TimeFrequencyEnum.WEEKLY, odmFpy,
								form.getVersionDate(), form.isShowSgaOrSle(),
								orders);
			}
		}
		Map<String, TTVOutlookChartData> ttvOutlookListMap = new HashMap<String, TTVOutlookChartData>();
		if (CollectionUtils.isNotEmpty(tTVOutlookChartDataList)) {
			for (TTVOutlookChartData data : tTVOutlookChartDataList) {
				ttvOutlookListMap.put(CalendarUtil.date2String(CalendarUtil
						.getMondayDateByDate(data.getDate())), data);
			}
		}
		MSColumnChartView columnChartView = new MSColumnChartView();
		columnChartView.getChartInfo().setShowAlternateHGridColor("0");
		columnChartView.getChartInfo().setPyaxisname("Unit");
		columnChartView.getChartInfo().setSyaxisname("TTV Percentage %");
		columnChartView.getChartInfo().setNumbersuffix("(pcs)");

		// category
		// String currentModay =
		// CalendarUtil.date2String(CalendarUtil.getMondayDateByDate(Calendar.getInstance().getTime()));
		String currentModay = CalendarUtil.date2String(form.getVersionDate());
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		// dataset list and lineset list
		List<DataSet> dataSetList = new ArrayList<DataSet>();
		List<LineSet> lineSetList = new ArrayList<LineSet>();

		// dataset
		DataSet demandDataSet = new DataSet();
		DataSet odmDataSet = new DataSet();
		DataSet shipmentDataSet = new DataSet();
		DataSet EstimatedCapacityDataSet = new DataSet();
		DataSet gapDataSet = new DataSet();

		LineSet ttvLineSet = new LineSet();
		ttvLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_ACTUALSLETTV);
		ttvLineSet.setColor(SysConfig.TTV_OUTLOOK_TTV_COLOR);
		ttvLineSet.setShowValues("0");
		ttvLineSet.setLineThickness("2");

		LineSet targetLineSet = new LineSet();
		targetLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_TTV_TARGET);
		targetLineSet.setColor(SysConfig.TTV_OUTLOOK_TTV_TARGET_COLOR);
		targetLineSet.setShowValues("0");
		targetLineSet.setLineThickness("2");

		LineSet sgaTtvLineSet = new LineSet();
		sgaTtvLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_ACTUALSGATTV);
		sgaTtvLineSet.setColor(SysConfig.TTV_OUTLOOK_ACTUALSGATTV_COLOR);
		sgaTtvLineSet.setShowValues("0");
		sgaTtvLineSet.setLineThickness("2");

		LineSet sgaTargetLineSet = new LineSet();
		sgaTargetLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_SGATTV_TARGET);
		sgaTargetLineSet.setColor(SysConfig.TTV_OUTLOOK_SGATTV_TARGET_COLOR);
		sgaTargetLineSet.setShowValues("0");
		sgaTargetLineSet.setLineThickness("2");

		// dataset:seriesName
		List<DataSetParent> demandDataSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> odmDataSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> shipmentSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> EstimatedCapacitySetList = new ArrayList<DataSetParent>();
		List<DataSetParent> gapSetList = new ArrayList<DataSetParent>();

		// demand
		DataSetColumn demandDataSetColumn = new DataSetColumn();
		demandDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_DEMAND);
		demandDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_DEMAND_COLOR);
		List<ColumnData> demandCloumnDataList = new ArrayList<ColumnData>();

		// ODM Commitment
		DataSetColumn odmDataSetColumn = new DataSetColumn();
		odmDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_ODMCOMMITMENT);
		odmDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_ODMCOMMITMENT_COLOR);
		List<ColumnData> odmCloumnDataList = new ArrayList<ColumnData>();

		// Shipment or Estimated Capacity
		DataSetColumn shipDataSetColumn = new DataSetColumn();
		shipDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_SHIPMENT);
		shipDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_SHIPMENT_COLOR);
		List<ColumnData> shipmentCloumnDataList = new ArrayList<ColumnData>();

		DataSetColumn capacityDataSetColumn = new DataSetColumn();
		capacityDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_CAPACITY);
		shipDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_CAPACITY_COLOR);
		List<ColumnData> capacityCloumnDataList = new ArrayList<ColumnData>();

		// TTL Gap
		DataSetColumn ttlGapDataSetColumn = new DataSetColumn();
		ttlGapDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_GAP);
		ttlGapDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_GAP_COLOR);
		List<ColumnData> ttlGapCloumnDataList = new ArrayList<ColumnData>();

		List<ColumnData> ttvColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> sgaTtvColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> sgaTargetCloumnDataList = new ArrayList<ColumnData>();

		int currentWeekCount = 0;
		boolean flag = false;
		int count = masterDataService.getThresholdByName(
				Threshold.TTV_OUTLOOK_DURATION.name()).intValue();
		for (int i = 0; i <= count; i++) {
			String thisMonday = CalendarUtil.date2String(CalendarUtil
					.getMondayDateByWeeks(form.getStartDate(), i));
			String lastModay = CalendarUtil.date2String(CalendarUtil
					.getMondayDateByWeeks(form.getVersionDate(), -1));
			LabelCategory category = new LabelCategory();
			if (ps != null) {
				if (ps.getTtmTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getTtmTargetDate())))) {
					category.setName(thisMonday + "(SS)");
				} else if (ps.getTtvTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getTtvTargetDate())))) {
					category.setName(thisMonday + "(SLE)");
				} else if (ps.getSvtPlanDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSvtPlanDate())))) {
					category.setName(thisMonday + "(SVT)");
				} else if (ps.getSovpPlanDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSovpPlanDate())))) {
					category.setName(thisMonday + "(SOVP)");
				} else if (ps.getSgaTtvTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSgaTtvTargetDate())))) {
					category.setName(thisMonday + "(SGA)");
				} else
					category.setName(thisMonday);
			}
			categoryList.add(category);

			TTVOutlookChartData tTVOutlookChartData = ttvOutlookListMap
					.get(thisMonday);
			String trackingCausesMonday = null;
			String trackingCausesSunday = null;
			trackingCausesMonday = CalendarUtil.getDateByDays(
					form.getStartDate(), 7 * i);
			trackingCausesSunday = CalendarUtil.getDateByDays(
					CalendarUtil.stringT2Date(trackingCausesMonday), 6);

			// Demand Order or Demand Rolling or Demand Forecast

			if (tTVOutlookChartData != null) {
				int futureDemand = (tTVOutlookChartData.getFutureForecast() != null ? tTVOutlookChartData
						.getFutureForecast() : 0)
						+ (tTVOutlookChartData.getFutureOrder() != null ? tTVOutlookChartData
								.getFutureOrder() : 0);
				int odm = tTVOutlookChartData.getOdm() != null ? tTVOutlookChartData
						.getOdm() : 0;
				int tooling = tTVOutlookChartData.getTooling() != null ? tTVOutlookChartData
						.getTooling() : 0;
				int supply = tTVOutlookChartData.getSupply() != null ? tTVOutlookChartData
						.getSupply() : 0;
				if (supply < 0 || supply >= futureDemand) {
					supply = 0;
				}
				if (odm < 0 || odm >= futureDemand) {
					odm = 0;
				}
				if (tooling < 0 || tooling >= futureDemand) {
					tooling = 0;
				}
				// TTL Gap
				ColumnData tTLGap = new ColumnData();
				/*
				 * boolean isGapExist = tTVOutlookChartData.getTotalGap() == 0 ?
				 * false : true;
				 */
				boolean isGapExist = true;
				tTLGap.setValue(-tTVOutlookChartData.getTotalGap().floatValue());
				if (previewDataMap != null) {
					if (thisMonday.compareTo(currentModay) >= 0) {
						tTLGap.setLink("j-previewTrackingCause-"
								+ trackingCausesMonday + "|" + futureDemand
								+ "|" + odm + "|" + tooling + "|" + supply);
					}
				} else {
					setOutlookWeeklyColumnLink(tTLGap, thisMonday,
							currentModay, trackingCausesMonday,
							trackingCausesSunday);
				}
				ttlGapCloumnDataList.add(tTLGap);
				// ODM Commitment
				ColumnData oDMCommitment = new ColumnData();
				if (isGapExist) {
					if (previewDataMap != null) {
						if (thisMonday.compareTo(currentModay) >= 0) {
							oDMCommitment.setLink("j-previewTrackingCause-"
									+ trackingCausesMonday + "|" + futureDemand
									+ "|" + odm + "|" + tooling + "|" + supply);
						}
					} else {
						setOutlookWeeklyColumnLink(oDMCommitment, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}

				}
				oDMCommitment.setValue(tTVOutlookChartData.getOdmCommit());
				odmCloumnDataList.add(oDMCommitment);

				// Shipment or Estimated Capacity
				ColumnData estimatedCapacity = new ColumnData();
				ColumnData shipment = new ColumnData();
				// demand
				ColumnData demand = new ColumnData();
				if (isGapExist) {
					if (previewDataMap != null) {
						if (thisMonday.compareTo(currentModay) >= 0) {
							demand.setLink("j-previewTrackingCause-"
									+ trackingCausesMonday + "|" + futureDemand
									+ "|" + odm + "|" + tooling + "|" + supply);
							estimatedCapacity.setLink("j-previewTrackingCause-"
									+ trackingCausesMonday + "|" + futureDemand
									+ "|" + odm + "|" + tooling + "|" + supply);
							shipment.setLink("j-previewTrackingCause-"
									+ trackingCausesMonday + "|" + futureDemand
									+ "|" + odm + "|" + tooling + "|" + supply);
						}
					} else {
						setOutlookWeeklyColumnLink(demand, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
						setOutlookWeeklyColumnLink(estimatedCapacity,
								thisMonday, currentModay, trackingCausesMonday,
								trackingCausesSunday);
						setOutlookWeeklyColumnLink(shipment, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
				}
				if (thisMonday.compareTo(currentModay) > 0) {
					demand.setValue(tTVOutlookChartData.getFutureForecast()
							+ tTVOutlookChartData.getFutureOrder().floatValue());
					demand.setDashed("1");
					estimatedCapacity.setValue(tTVOutlookChartData
							.getCapacity() < 0 ? 0 : tTVOutlookChartData
							.getCapacity());
					estimatedCapacity.setDashed("1");
					tTLGap.setDashed("1");
					oDMCommitment.setDashed("1");
					// shipment.setValue(0);

				} else if (thisMonday.compareTo(currentModay) == 0) {
					demand.setValue(tTVOutlookChartData.getDemand().intValue());
					demand.setDashed("1");
					estimatedCapacity.setValue(tTVOutlookChartData
							.getCapacity() < 0 ? 0 : tTVOutlookChartData
							.getCapacity());
					estimatedCapacity.setDashed("1");
					tTLGap.setDashed("1");
					oDMCommitment.setDashed("1");
					// shipment.setValue(0);
				} else {
					demand.setValue(tTVOutlookChartData.getOrder() != null ? tTVOutlookChartData
							.getOrder() : 0);
					shipment.setValue(tTVOutlookChartData.getShipment() < 0 ? 0
							: tTVOutlookChartData.getShipment());
					// estimatedCapacity.setValue(0);
				}
				if (demand.getValue() != null
						&& demand.getValue().intValue() < 0) {
					demand.setValue(0);
				}
				demandCloumnDataList.add(demand);
				capacityCloumnDataList.add(estimatedCapacity);
				shipmentCloumnDataList.add(shipment);
				// Actual TTV or Estimated TTV
				ColumnData ttv = new ColumnData();
				ttv.setValue(tTVOutlookChartData.getTtv());
				ttvColumnDataList.add(ttv);
				// LOGGER.info(i+"##############Integer.valueOf(trackingCausesMonday.replace(\"-\", \"\"))##############"+Integer.valueOf(trackingCausesMonday.replace("-",
				// "")));
				// System.out.println(i+"##############Integer.valueOf(trackingCausesMonday.replace(\"-\", \"\"))##############"+Integer.valueOf(trackingCausesMonday.replace("-",
				// "")));
				// LOGGER.info(i+"##############Integer.valueOf(currentModay.replace(\"-\",\"\"))##############"+Integer.valueOf(currentModay.replace("-",
				// "")));
				// System.out.println(i+"##############Integer.valueOf(currentModay.replace(\"-\",\"\"))##############"+Integer.valueOf(currentModay.replace("-",
				// "")));
				// LOGGER.info("#############tTVOutlookChartData.getTtv()#########"+tTVOutlookChartData.getTtv());

				if (Integer.valueOf(trackingCausesMonday.replace("-", "")) >= Integer
						.valueOf(currentModay.replace("-", ""))) {
					actualSleFlag = false;
				}
				// System.out.println(i+"##############actualSgaFlag:"+actualSgaFlag);
				// LOGGER.info(i+"##############actualSgaFlag:"+actualSgaFlag);
				// sga starts at ss , ends at sga
				ColumnData sgaTtv = new ColumnData();
				if (null != ps.getTtmTargetDate()
						&& null != ps.getSgaTtvTargetDate()) {
					if (thisMonday.compareTo(CalendarUtil
							.date2String(CalendarUtil.getMondayDateByDate(ps
									.getTtmTargetDate()))) >= 0
							&& thisMonday.compareTo(CalendarUtil
									.date2String(CalendarUtil
											.getMondayDateByDate(ps
													.getSgaTtvTargetDate()))) <= 0) {
						sgaTtv.setValue(tTVOutlookChartData.getSgaTTV() != null ? tTVOutlookChartData
								.getSgaTTV() : 0);
					}
				}
				// LOGGER.info(i+"##############sgaTtv:"+sgaTtv.getValue().floatValue());
				sgaTtvColumnDataList.add(sgaTtv);

				if (thisMonday.compareTo(lastModay) >= 0) {
					ttv.setDashed("1");
					sgaTtv.setDashed("1");
				}

				Vline vline = new Vline();
				categoryList.add(vline);
				if (lastModay.equalsIgnoreCase(thisMonday)) {
					flag = true;
				}
				if (flag) {
					currentWeekCount++;
				}
				if (currentWeekCount == 1) {
					vline.setLabel("Current Week");
					vline.setLabelHAlign("left");
				}
				if (flag) {
					vline.setDashed("0");
					vline.setThickness("2");
				}
				vline.setVline("true");
				if (currentWeekCount == 2) {
					flag = false;
				}

				// k++;
				// break;
			} else {
				// ColumnData order = new ColumnData();
				// order.setValue(0);
				// orderCloumnDataList.add(order);
				ColumnData demand = new ColumnData();
				// demand.setValue(0);
				demandCloumnDataList.add(demand);
				// ColumnData forecast = new ColumnData();
				// forecast.setValue(0);
				// forecastCloumnDataList.add(forecast);
				ColumnData oDMCommitment = new ColumnData();
				// .setValue(0);
				odmCloumnDataList.add(oDMCommitment);
				ColumnData estimatedCapacity = new ColumnData();

				// estimatedCapacity.setValue(0);
				shipmentCloumnDataList.add(estimatedCapacity);
				ColumnData shipment = new ColumnData();

				// shipment.setValue(0);
				capacityCloumnDataList.add(shipment);
				ColumnData tTLGap = new ColumnData();
				// tTLGap.setValue(0);

				ttlGapCloumnDataList.add(tTLGap);

				// Actual TTV or Estimated TTV
				ColumnData ttv = new ColumnData();
				// ttv.setValue(0);
				ttvColumnDataList.add(ttv);

				ColumnData sgaTtv = new ColumnData();
				// sgaTtv.setValue(0);
				sgaTtvColumnDataList.add(sgaTtv);

				if (flag || lastModay.equalsIgnoreCase(thisMonday)) {
					Vline vline = new Vline();
					categoryList.add(vline);
					if (lastModay.equalsIgnoreCase(thisMonday)) {
						flag = true;
					}
					if (flag) {
						currentWeekCount++;
					}
					if (currentWeekCount == 1) {
						vline.setLabel("Current Week");
						vline.setLabelHAlign("left");
					}
					if (flag) {
						vline.setDashed("0");
						vline.setThickness("2");
					}
					vline.setVline("true");
					if (currentWeekCount == 2) {
						flag = false;
					}
				}

			}
			// Target
			ColumnData target = new ColumnData();
			target.setValue(ps != null && ps.getTtvTarget() != null ? ps
					.getTtvTarget() : 0);
			targetCloumnDataList.add(target);

			ColumnData sgaTarget = new ColumnData();
			sgaTarget.setValue(ps != null && ps.getSgaTtvTarget() != null ? ps
					.getSgaTtvTarget() : 0);
			sgaTargetCloumnDataList.add(sgaTarget);
		}
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		demandDataSetColumn.setDataList(demandCloumnDataList);
		demandDataSetList.add(demandDataSetColumn);

		odmDataSetColumn.setDataList(odmCloumnDataList);
		odmDataSetList.add(odmDataSetColumn);

		shipDataSetColumn.setDataList(shipmentCloumnDataList);
		shipmentSetList.add(shipDataSetColumn);
		capacityDataSetColumn.setDataList(capacityCloumnDataList);
		EstimatedCapacitySetList.add(capacityDataSetColumn);

		ttlGapDataSetColumn.setDataList(ttlGapCloumnDataList);
		gapSetList.add(ttlGapDataSetColumn);

		demandDataSet.setDataSetList(demandDataSetList);
		odmDataSet.setDataSetList(odmDataSetList);
		shipmentDataSet.setDataSetList(shipmentSetList);
		EstimatedCapacityDataSet.setDataSetList(EstimatedCapacitySetList);
		gapDataSet.setDataSetList(gapSetList);

		if (!actualSleFlag) {
			ttvLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_SLETTV);
		}
		sgaTtvLineSet.setDataList(sgaTtvColumnDataList);

		sgaTargetLineSet.setDataList(sgaTargetCloumnDataList);

		ttvLineSet.setDataList(ttvColumnDataList);
		targetLineSet.setDataList(targetCloumnDataList);

		dataSetList.add(odmDataSet);
		dataSetList.add(EstimatedCapacityDataSet);
		dataSetList.add(demandDataSet);
		dataSetList.add(shipmentDataSet);
		dataSetList.add(gapDataSet);

		lineSetList.add(ttvLineSet);
		lineSetList.add(targetLineSet);
		if (form.isShowSgaOrSle()) {
			lineSetList.add(sgaTtvLineSet);
			lineSetList.add(sgaTargetLineSet);
		}

		columnChartView.setDataSetList(dataSetList);
		columnChartView.setLineSetList(lineSetList);

		return columnChartView;

	}

	public MSColumnChartView getSgaOutlookJsonChartDataByWeekly(
			SearchOutlookDataForm form, Boolean isPreview,
			List<NpiOrder> orders, boolean isSnapshot) throws ParseException,
			BusinessException {
		return this.getSgaOutlookJsonChartDataByWeekly(form, isPreview, orders,
				isSnapshot, null);
	}

	public ColumnChartView getOutlookJsonChartDataByDaily(
			SearchOutlookDataForm form, String isPreview,
			String selectedExcludeOrderIds) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();
		Date startDate = form.getStartDate();
		Date endDate = form.getEndDate();
		boolean odmFpy = "ODM".equals(form.getFpy()) ? true : false;
		int waveId = form.getWaveId();
		Date versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil
				.getTodayWithoutMins());
		/*
		 * if("true".equals(isPreview)){ List<NpiOrder> excludedOrders = new
		 * ArrayList<NpiOrder>();
		 * 
		 * NpiOrder npiOrder = new NpiOrder();
		 * 
		 * List<TTVOutlookChartData> tTVOutlookChartDataList =
		 * tTVOutlookService.previewChartData(waveId, startDate, endDate,
		 * TimeFrequencyEnum.DAILY, odmFpy, excludedOrders); }else{
		 * 
		 * //fetch data by calling tTVOutlookService interface
		 * List<TTVOutlookChartData> tTVOutlookChartDataList =
		 * tTVOutlookService.getChartData(waveId, startDate, endDate,
		 * TimeFrequencyEnum.DAILY, odmFpy); }
		 */

		// fetch data by calling tTVOutlookService interface
		List<TTVOutlookChartData> tTVOutlookChartDataList = tTVOutlookService
				.getChartData(waveId, startDate, endDate,
						TimeFrequencyEnum.DAILY, odmFpy, versionDate, false,
						false);

		// categories
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		String currentDate = CalendarUtil.date2String(Calendar.getInstance()
				.getTime());
		int count = 0;
		for (int i = 0; i < count; i++) {
			String dailyStartDate = CalendarUtil.getDateByDays(startDate, i);
			if (currentDate.equals(dailyStartDate)) {
				Vline vline = new Vline();
				vline.setLabel("Current Day");
				vline.setVline("true");
				vline.setLabelPosition("0");
				categoryList.add(i, vline);
			}
			LabelCategory category = new LabelCategory();
			category.setName(dailyStartDate);
			categoryList.add(category);
		}

		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		// dataset
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();
		// Order or Demand
		DataSetColumn orderDataSet = new DataSetColumn();
		orderDataSet.setSeriesName("Order");
		List<ColumnData> orderCloumnDataList = new ArrayList<ColumnData>();
		DataSetColumn demandDataSet = new DataSetColumn();
		demandDataSet.setSeriesName("Demand");
		List<ColumnData> demandCloumnDataList = new ArrayList<ColumnData>();

		// ODM Commitment
		DataSetColumn odmCommitmentDataSet = new DataSetColumn();
		odmCommitmentDataSet.setSeriesName("ODM Commitment");
		List<ColumnData> odmCommitmentCloumnDataList = new ArrayList<ColumnData>();

		// Shipment or Estimated Capacity
		DataSetColumn shipmentDataSet = new DataSetColumn();
		shipmentDataSet.setSeriesName("Shipment");
		List<ColumnData> shipmentCloumnDataList = new ArrayList<ColumnData>();
		DataSetColumn capacityDataSet = new DataSetColumn();
		capacityDataSet.setSeriesName("Estimated Capacity");
		List<ColumnData> capacityCloumnDataList = new ArrayList<ColumnData>();

		// TTL Gap
		DataSetColumn ttlGapDataSet = new DataSetColumn();
		ttlGapDataSet.setSeriesName("TTL Gap");
		List<ColumnData> ttlGapCloumnDataList = new ArrayList<ColumnData>();

		// Actual TTV or Estimated TTV
		DataSetLine ttvDataSet = new DataSetLine();
		ttvDataSet.setSeriesName("TTV");
		ttvDataSet.setParentYaxis("S");
		ttvDataSet.setRenderas("Line");
		ttvDataSet.setColor("FF0000");// Ã§ÂºÂ¢Ã¨â€°Â²
		List<ColumnData> ttvDataList = new ArrayList<ColumnData>();

		// Target
		DataSetLine targetDataSet = new DataSetLine();
		targetDataSet.setSeriesName("TTV Target");
		targetDataSet.setParentYaxis("S");
		targetDataSet.setRenderas("Line");
		targetDataSet.setColor("black");// Ã©Â»â€˜Ã¨â€°Â²
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		for (int i = 0; i < tTVOutlookChartDataList.size(); i++) {
			TTVOutlookChartData tTVOutlookChartData = tTVOutlookChartDataList
					.get(i);

			String trackingCausesDate = null;
			String dailyStartDate = null;
			trackingCausesDate = CalendarUtil.getDateByDays(startDate, i);
			dailyStartDate = CalendarUtil.getDateByDays(startDate, i);
			currentDate = CalendarUtil.date2String(Calendar.getInstance()
					.getTime());

			// Order or Demand
			if (dailyStartDate.compareTo(currentDate) < 0) {
				ColumnData order = new ColumnData();
				setDailyColumnLink(order, dailyStartDate, currentDate,
						trackingCausesDate);
				order.setValue(tTVOutlookChartData.getOrder());
				order.setColor("6699ff");// Ã¨â€œÂ�Ã¨â€°Â²
				orderCloumnDataList.add(order);
				demandCloumnDataList.add(i, null);
			} else {
				ColumnData demand = new ColumnData();
				setDailyColumnLink(demand, dailyStartDate, currentDate,
						trackingCausesDate);
				demand.setValue(tTVOutlookChartData.getFutureOrder());
				demand.setColor("006699");// Ã¨â€œÂ�Ã¨â€°Â²
				demandCloumnDataList.add(demand);
				// orderCloumnDataList.add(i,null);
			}

			// ODM Commitment
			ColumnData oDMCommitment = new ColumnData();
			setDailyColumnLink(oDMCommitment, dailyStartDate, currentDate,
					trackingCausesDate);
			oDMCommitment.setValue(tTVOutlookChartData.getOdmCommit());
			oDMCommitment.setColor("#CDCDCD");// Ã§Â�Â°Ã¨â€°Â²
			odmCommitmentCloumnDataList.add(oDMCommitment);

			// Shipment or Estimated Capacity
			if (dailyStartDate.compareTo(currentDate) < 0) {
				ColumnData shipmentCapacity = new ColumnData();
				setDailyColumnLink(shipmentCapacity, dailyStartDate,
						currentDate, trackingCausesDate);
				shipmentCapacity.setValue(tTVOutlookChartData.getShipment());
				shipmentCapacity.setColor("66cc66");// Ã§Â»Â¿Ã¨â€°Â²
				shipmentCloumnDataList.add(i, shipmentCapacity);
				capacityCloumnDataList.add(i, null);
			} else {
				ColumnData estimatedCapacity = new ColumnData();
				setDailyColumnLink(estimatedCapacity, dailyStartDate,
						currentDate, trackingCausesDate);
				estimatedCapacity.setValue(tTVOutlookChartData.getCapacity());
				estimatedCapacity.setColor("ffcc66");// Ã©Â»â€žÃ¨â€°Â²
				capacityCloumnDataList.add(i, estimatedCapacity);
			}

			// TTL Gap
			ColumnData tTLGap = new ColumnData();
			tTLGap.setValue(tTVOutlookChartData.getTotalGap());
			tTLGap.setColor("FF0000");
			setDailyColumnLink(tTLGap, dailyStartDate, currentDate,
					trackingCausesDate);
			ttlGapCloumnDataList.add(tTLGap);

			// Actual TTV or Estimated TTV
			ColumnData tTV = new ColumnData();
			tTV.setValue(tTVOutlookChartData.getTtv());
			tTV.setColor("");
			ttvDataList.add(tTV);

			// Target
			ColumnData target = new ColumnData();
			target.setValue(92);
			targetCloumnDataList.add(target);
		}
		orderDataSet.setDataList(orderCloumnDataList);
		dataSetList.add(orderDataSet);
		demandDataSet.setDataList(demandCloumnDataList);
		dataSetList.add(demandDataSet);

		odmCommitmentDataSet.setDataList(odmCommitmentCloumnDataList);
		dataSetList.add(odmCommitmentDataSet);

		shipmentDataSet.setDataList(shipmentCloumnDataList);
		capacityDataSet.setDataList(capacityCloumnDataList);
		dataSetList.add(shipmentDataSet);
		dataSetList.add(capacityDataSet);

		ttlGapDataSet.setDataList(ttlGapCloumnDataList);
		dataSetList.add(ttlGapDataSet);

		ttvDataSet.setDataList(ttvDataList);
		dataSetList.add(ttvDataSet);

		targetDataSet.setDataList(targetCloumnDataList);
		dataSetList.add(targetDataSet);

		columnChartView.setDataSetList(dataSetList);

		return columnChartView;
	}

	public void setOutlookWeeklyColumnLink(ColumnData cloumnData,
			String thisMonday, String currentModay,
			String trackingCausesMonday, String trackingCausesSunday) {
		if (thisMonday.compareTo(currentModay) < 0) {
			cloumnData.setLink("j-showDetractorMainPieAndData-" + ","
					+ trackingCausesMonday + "|" + trackingCausesSunday);
		} else {
			cloumnData.setLink("j-listTrackingCause-" + ","
					+ trackingCausesMonday + "|" + trackingCausesSunday);
		}
		// cloumnData.setLink("j-listTrackingCause-" + "," +
		// trackingCausesMonday + "|" + trackingCausesSunday);
	}

	public void setCapacityWeeklyColumnLink(ColumnData cloumnData,
			String thisMonday, String currentModay,
			String trackingCausesMonday, String trackingCausesSunday, String fpy) {
		if (thisMonday.compareTo(currentModay) < 0) {
			cloumnData.setLink("j-showDetractorMainPieAndData-" + fpy + ","
					+ trackingCausesMonday + "|" + trackingCausesSunday);
		} else {
			cloumnData.setLink("j-showCausesAnalysisPieAndData-" + fpy + ","
					+ trackingCausesMonday + "|" + trackingCausesSunday);
		}
	}

	public void setDailyColumnLink(ColumnData cloumnData,
			String dailyStartDate, String currentDate, String trackingCausesDate) {
		if (dailyStartDate.compareTo(currentDate) < 0) {
			cloumnData.setLink("j-showDetractorMainPieAndData-" + ","
					+ trackingCausesDate);
		} else {
			cloumnData.setLink("j-listTrackingCause-" + ","
					+ trackingCausesDate);
		}
	}

	public ColumnChartView getShortBarJsonChartDataByConditions(
			SearchOutlookDataForm form) {
		ColumnChartView columnChartView = new ColumnChartView();
		// categories
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		for (int i = 0; i < 2; i++) {
			LabelCategory category = new LabelCategory();
			if (i == 0) {
				if (form.getStartDate() != null) {
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
					category.setName(df.format(form.getStartDate()));
				}
			} else {
				category.setName("");
			}
			categoryList.add(category);
		}

		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		// List<Capacity> capacityList = new ArrayList<Capacity>();
		Date versionDate = form.getVersionDate();
		List<TTVOutlookChartData> tTVOutlookChartDataList = null;
		boolean odmFpy = "odm".equalsIgnoreCase(form.getFpy());
		if ("Sga".equals(form.getSgaOrSle())) {
			try {
				tTVOutlookChartDataList = tTVOutlookService.getSgaChartData(
						form.getWaveId(), form.getStartDate(),
						form.getStartDate(), form.getFrequency(), odmFpy,
						versionDate, false, false);
			} catch (BusinessException e) {
				e.printStackTrace();
			}
		} else {
			tTVOutlookChartDataList = tTVOutlookService.getChartData(
					form.getWaveId(), form.getStartDate(), form.getStartDate(),
					form.getFrequency(), odmFpy, versionDate, false, false);
		}

		// if(!tTVOutlookChartDataList.isEmpty()){
		// capacityList = transFormCapacityData(tTVOutlookChartDataList);
		// }

		// dataset
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();
		// Don't show [ODM Capacity], [Tooling Capacity] or [Supply Capacity]
		// columns if they are not shortage (>=Demand)
		// Demand
		/*
		 * DataSetLine demandDataSet = new DataSetLine();
		 * demandDataSet.setSeriesName("Demand");
		 * demandDataSet.setParentYaxis("S"); demandDataSet.setRenderas("Line");
		 * demandDataSet.setColor("#CDCDCD"); List<CloumnData>
		 * demandCloumnDataList = new ArrayList<CloumnData>(); for(int i=0; i<4;
		 * i++) { CloumnData demandCloumnData = new CloumnData();
		 * demandCloumnData.setValue(50);
		 * demandCloumnDataList.add(demandCloumnData); }
		 * demandDataSet.setDataList(demandCloumnDataList);
		 * dataSetList.add(demandDataSet);
		 */
		Integer odmCapacity = 0, toolingCapacity = 0, supplyCapacity = 0, demand = 0;
		if (tTVOutlookChartDataList != null
				&& !tTVOutlookChartDataList.isEmpty()) {
			for (TTVOutlookChartData tTVOutlookChartData : tTVOutlookChartDataList) {
				odmCapacity = tTVOutlookChartData.getOdm() != null ? tTVOutlookChartData
						.getOdm() : 0;
				toolingCapacity = tTVOutlookChartData.getTooling() != null ? tTVOutlookChartData
						.getTooling() : 0;
				supplyCapacity = tTVOutlookChartData.getSupply() != null ? tTVOutlookChartData
						.getSupply() : 0;
				if ("Sga".equals(form.getSgaOrSle())) {
					int rampCommit = rampCommitService.getRampCommitQty(
							form.getWaveId(), form.getStartDate());
					if (rampCommit > 0) {
						demand = Math.min(tTVOutlookChartData.getForecast(),
								rampCommit);
					} else {
						demand = tTVOutlookChartData.getForecast();
					}
				} else {
					demand = (tTVOutlookChartData.getFutureForecast() == null ? 0
							: tTVOutlookChartData.getFutureForecast()) // change
																		// forecast
																		// to
																		// futureForecast
							+ (tTVOutlookChartData.getFutureOrder() == null ? 0
									: tTVOutlookChartData.getFutureOrder());
				}

			}
		}
		// capacity.setCauses(TTVCause.odm.getCause());
		// capacity.setCausesCategory(CausesCategory.ODM_CAPACITY.getCause());
		if (demand < 0) {
			demand = 0;
		}
		if (odmCapacity >= demand || odmCapacity < 0) {
			odmCapacity = 0;
		}
		if (toolingCapacity >= demand || toolingCapacity < 0) {
			toolingCapacity = 0;
		}
		if (supplyCapacity >= demand || supplyCapacity < 0) {
			supplyCapacity = 0;
		}
		DataSetColumn demandDataSet = new DataSetColumn();
		demandDataSet.setSeriesName(CausesCategory.DEMAND.getCause());
		List<ColumnData> demandCloumnDataList = new ArrayList<ColumnData>();
		ColumnData demandCloumnData = new ColumnData();
		demandCloumnData.setValue(demand);
		demandCloumnDataList.add(demandCloumnData);
		demandDataSet.setDataList(demandCloumnDataList);
		dataSetList.add(demandDataSet);

		// ODM
		DataSetColumn odmDataSet = new DataSetColumn();
		odmDataSet.setSeriesName((CausesCategory.ODM_CAPACITY.getCause()
				.split(" "))[0]);
		List<ColumnData> odmCloumnDataList = new ArrayList<ColumnData>();
		ColumnData odmCloumnData = new ColumnData();
		odmCloumnData.setValue(odmCapacity);
		odmCloumnDataList.add(odmCloumnData);
		odmDataSet.setDataList(odmCloumnDataList);
		dataSetList.add(odmDataSet);

		// Tooling
		DataSetColumn toolingDataSet = new DataSetColumn();
		toolingDataSet.setSeriesName((CausesCategory.TOOLING_CAPACITY
				.getCause().split(" "))[0]);
		List<ColumnData> toolingCloumnDataList = new ArrayList<ColumnData>();
		ColumnData toolingCloumnData = new ColumnData();
		toolingCloumnData.setValue(toolingCapacity);
		toolingCloumnDataList.add(toolingCloumnData);
		toolingDataSet.setDataList(toolingCloumnDataList);
		dataSetList.add(toolingDataSet);

		// Supply
		DataSetColumn supplyDataSet = new DataSetColumn();
		supplyDataSet.setSeriesName((CausesCategory.SUPPLY_CAPACITY.getCause()
				.split(" "))[0]);
		List<ColumnData> supplyCloumnDataList = new ArrayList<ColumnData>();
		ColumnData supplyCloumnData = new ColumnData();
		supplyCloumnData.setValue(supplyCapacity);
		supplyCloumnDataList.add(supplyCloumnData);
		supplyDataSet.setDataList(supplyCloumnDataList);
		dataSetList.add(supplyDataSet);
		columnChartView.setDataSetList(dataSetList);

		return columnChartView;
	}

	public TtvGridTrackingCauses getTrackingCausesByWeek(
			SearchOutlookDataForm form) {
		boolean odmFpy = "ODM".equals(form.getFpy()) ? true : false;
		return tTVOutlookService.getCause(form.getWaveId(),
				form.getStartDate(), form.getFrequency(), odmFpy,
				form.getVersionDate());
	}

	@Override
	public TtvGridTrackingCauses getSgaTrackingCausesByWeek(
			SearchOutlookDataForm form) {
		boolean odmFpy = "ODM".equals(form.getFpy()) ? true : false;
		return tTVOutlookService.getSGACause(form.getWaveId(),
				form.getStartDate(), form.getFrequency(), odmFpy,
				form.getVersionDate());
	}

	@Override
	public ProjectOutLookView getProjecteView(ProductWave proWave,
			Date versionDate) throws ParseException {
		ProjectOutLookView outlookView = new ProjectOutLookView();
		List<ProductWave> waveList = new ArrayList<ProductWave>();
		outlookView.setCurrentWave(proWave);

		List<ProjectSummary> projectSummaryList = nPIProductSummaryDao
				.getProductInfoByProjectId(proWave.getProjectId(),
						proWave.getWaveId(), versionDate);

		List<Integer> waveIdList = new ArrayList<Integer>();
		waveIdList.add(proWave.getWaveId());
		Map<Integer, List<String>> waveNpiMap = nPIProductSummaryDao
				.getNPIByWaveIds(waveIdList);

		String npiName = null;
		if (waveNpiMap.containsKey(proWave.getWaveId())) {
			npiName = CommonUtil.npiNameString(waveNpiMap.get(proWave
					.getWaveId()));
		}

		for (ProjectSummary projectSummary : projectSummaryList) {
			if (proWave.getWaveId().intValue() == (projectSummary
					.getPmsWaveId().intValue())) {
				proWave.setWaveName(projectSummary.getWaveName());
				proWave.setProductName(projectSummary.getProductName());
				proWave.setNpiName(npiName);
				proWave.setPm(projectSummary.getPm());

				proWave.setActualTTV(String.valueOf(Math.floor(projectSummary
						.getActualTTV() * 10) / 10.0));
				proWave.setEstimatedTTV(String.valueOf(Math
						.floor(projectSummary.getEstimatedTTV() * 10) / 10.0));
				if (projectSummary.getTtvSignOffDate() != null) {
					proWave.setTTVSignOff(true);
					proWave.setTtvSignOffDate(CalendarUtil
							.date2String(projectSummary.getTtvSignOffDate()));
				} else {
					proWave.setTTVSignOff(false);
				}
				proWave.setTtvStatus(projectSummary.getTtvStatus());
				proWave.setTtvTarget(String.valueOf(projectSummary
						.getTtvTarget()));
				if (projectSummary.getTtvTargetDate() != null) {
					proWave.setTtvTargetDate(CalendarUtil
							.date2String(projectSummary.getTtvTargetDate()));
				}
				Float num = masterDataService
						.getThresholdByName(Threshold.TTV_OUTLOOK_STARTDATE
								.name());
				if (projectSummary.getTtvTargetDate() != null) {
					proWave.setStartDate(CalendarUtil.date2String(CalendarUtil
							.getMondayDateByWeeks(
									projectSummary.getTtvTargetDate(),
									num.intValue())));
				}

				proWave.setSgaActualTTV(String.valueOf(Math
						.floor(projectSummary.getSgaActualTTV() * 10) / 10.0));
				proWave.setSgaEstimatedTTV(String.valueOf(Math
						.floor(projectSummary.getSgaEstimatedTTV() * 10) / 10.0));
				proWave.setSgaTtvStatus(projectSummary.getSgaTtvStatus());
				proWave.setSgaTtvTarget(projectSummary.getSgaTtvTarget() == null ? ""
						: String.valueOf(projectSummary.getSgaTtvTarget()));
				if (projectSummary.getSgaTtvSignOffDate() != null) {
					proWave.setSgaTTVSignOff(true);
					proWave.setSgaTtvSignOffDate(CalendarUtil
							.date2String(projectSummary.getSgaTtvSignOffDate()));
				} else {
					proWave.setSgaTTVSignOff(false);
				}
				if (projectSummary.getSgaTtvTargetDate() != null) {
					proWave.setSgaTtvTargetDate(CalendarUtil
							.date2String(projectSummary.getSgaTtvTargetDate()));
					Float beforeWeeks = masterDataService
							.getThresholdByName(Threshold.SGA_TTV_OUTLOOK_STARTDATE
									.name());
					String sStartDate = CalendarUtil.date2String(CalendarUtil
							.getMondayDateByWeeks(
									projectSummary.getSgaTtvTargetDate(),
									beforeWeeks.intValue()));
					proWave.setSgaStartDate(sStartDate);
				}
			}

			ProductWave productWave = new ProductWave();
			productWave.setWaveName(projectSummary.getWaveName());
			productWave.setWaveId(projectSummary.getPmsWaveId());
			waveList.add(productWave);
		}
		outlookView.setProductWaves(waveList);

		ProjectInformation info = new ProjectInformation();

		info.setProductName(proWave.getProductName());
		info.setProductId(proWave.getProjectId());
		info.setPmName(proWave.getPm());
		outlookView.setInfo(info);
		return outlookView;
	}

	public ProjectOutLookView getProjecteView(ProductWave proWave)
			throws ParseException {
		Date versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil
				.getTodayWithoutMins());
		return getProjecteView(proWave, versionDate);
	}

	@Override
	public ProjectOutLookView getProjectOutLook(ProductWave proWave)
			throws ParseException {
		return getProjecteView(proWave, null);
	}

	@Override
	public ProjectOutLookView getProjectSummary(ProductWave proWave)
			throws ParseException {
		return getProjecteView(proWave, null);
	}

	@Override
	public MSColumnChartView getSgaSummaryJsonChartData(Integer waveId,
			boolean showSle, boolean isOdmFpy) throws ParseException,
			BusinessException {
		MSColumnChartView columnChartView = new MSColumnChartView();
		columnChartView.getChartInfo().setShowAlternateHGridColor("0");
		columnChartView.getChartInfo().setPyaxisname("Unit");
		columnChartView.getChartInfo().setSyaxisname("TTV Percentage %");
		columnChartView.getChartInfo().setNumbersuffix("(pcs)");
		// fetch wave info
		ProjectSummary ps = nPIProductSummaryDao.getProductInfoByWaveId(waveId,
				null);
		if (ps == null) {
			return null;
		}
		Date endDate = ps.getSgaTtvSignOffDate() == null ? CalendarUtil
				.getTodayWithoutMins() : ps.getSgaTtvSignOffDate();
		int count = masterDataService.getThresholdByName(
				Threshold.SGA_TTV_OUTLOOK_DURATION.name()).intValue();
		Date startDate = CalendarUtil.getMondayDateByWeeks(endDate, -count);
		Date versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil
				.getTodayWithoutMins());

		// fetch data by calling tTVOutlookService interface
		List<TTVOutlookChartData> tTVOutlookChartDataList = tTVOutlookService
				.getSgaChartData(waveId, startDate, endDate,
						TimeFrequencyEnum.WEEKLY, isOdmFpy, versionDate,
						showSle, false);
		Map<String, TTVOutlookChartData> ttvOutlookListMap = new HashMap<String, TTVOutlookChartData>();

		if (tTVOutlookChartDataList != null) {
			for (TTVOutlookChartData data : tTVOutlookChartDataList) {
				ttvOutlookListMap.put(CalendarUtil.date2String(CalendarUtil
						.getMondayDateByDate(data.getDate())), data);
			}
		}

		// categories
		// boolean flag = false;
		String currentModay = CalendarUtil.date2String(CalendarUtil
				.getMondayDateByDate(Calendar.getInstance().getTime()));
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		// dataset list and lineset list
		List<DataSet> dataSetList = new ArrayList<DataSet>();
		List<LineSet> lineSetList = new ArrayList<LineSet>();

		// dataset
		DataSet rampCommitDataSet = new DataSet();
		// DataSet capacityDataSet = new DataSet();
		DataSet gapDataSet = new DataSet();
		DataSet shipmentDataSet = new DataSet();
		DataSet demandDataSet = new DataSet();
		DataSet forecastDataSet = new DataSet();

		LineSet ttvLineSet = new LineSet();
		ttvLineSet.setSeriesName(SysConfig.TTV_SUMMARY_SLETTV);
		ttvLineSet.setColor(SysConfig.TTV_SUMMARY_SLETTV_COLOR);
		ttvLineSet.setShowValues("0");
		ttvLineSet.setLineThickness("2");

		LineSet targetLineSet = new LineSet();
		targetLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_SLETTV_TARGET);
		targetLineSet.setColor(SysConfig.TTV_OUTLOOK_SLETTV_TARGET_COLOR);
		targetLineSet.setShowValues("0");
		targetLineSet.setLineThickness("2");

		LineSet sgaTtvLineSet = new LineSet();
		sgaTtvLineSet.setSeriesName(SysConfig.TTV_SUMMARY_SGATTV);
		sgaTtvLineSet.setColor(SysConfig.TTV_SUMMARY_SGATTV_COLOR);
		sgaTtvLineSet.setShowValues("0");
		sgaTtvLineSet.setLineThickness("2");

		LineSet sgaTargetLineSet = new LineSet();
		sgaTargetLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_SGATTV_TARGET);
		sgaTargetLineSet.setColor(SysConfig.TTV_OUTLOOK_SGATTV_TARGET_COLOR);
		sgaTargetLineSet.setShowValues("0");
		sgaTargetLineSet.setLineThickness("2");

		// dataset:seriesName
		List<DataSetParent> rampCommitDataSetList = new ArrayList<DataSetParent>();
		// List<DataSetParent> capacitySetList = new ArrayList<DataSetParent>();
		List<DataSetParent> gapSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> shipmentSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> demandSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> forecastSetList = new ArrayList<DataSetParent>();

		// Ramp Commit
		DataSetColumn rampCommitDataSetColumn = new DataSetColumn();
		rampCommitDataSetColumn
				.setSeriesName(SysConfig.TTV_OUTLOOK_SGARAMPCOMMIT);
		rampCommitDataSetColumn
				.setColor(SysConfig.TTV_OUTLOOK_SGARAMPCOMMIT_COLOR);

		/*
		 * DataSetColumn capacityDataSetColumn = new DataSetColumn();
		 * capacityDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_CAPACITY);
		 * capacityDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_CAPACITY_COLOR);
		 */

		// TTL Gap
		DataSetColumn gapDataSetColumn = new DataSetColumn();
		gapDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_GAP);
		gapDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_GAP_COLOR);

		DataSetColumn shipmentDataSetColumn = new DataSetColumn();
		shipmentDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_SHIPMENT);
		shipmentDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_SHIPMENT_COLOR);

		DataSetColumn demandDataSetColumn = new DataSetColumn();
		demandDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_ORDER);
		demandDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_ORDER_COLOR);

		DataSetColumn forecastDataSetColumn = new DataSetColumn();
		forecastDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_FORECAST);
		forecastDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_FORECAST_COLOR);

		List<ColumnData> ttvColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> targetColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> sgaTtvColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> sgaTargetColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> rampCommitColumnDataList = new ArrayList<ColumnData>();
		// List<ColumnData> capacityColumnDataList = new
		// ArrayList<ColumnData>();
		List<ColumnData> gapColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> demandColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> forecastColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> shipmentColumnDataList = new ArrayList<ColumnData>();
		Date ssDate = CalendarUtil.getMondayDateByDate(ps.getTtmTargetDate());
		for (int i = 0; i <= count; i++) {
			Date thisMondayDate = CalendarUtil.getMondayDateByWeeks(startDate,
					i);
			String thisMonday = CalendarUtil.date2String(thisMondayDate);
			/*
			 * if (flag) { if (currentModay.compareTo(thisMonday) <= 0) { Vline
			 * vline = new Vline(); vline.setLabel("Current Week");
			 * vline.setVline("true"); categoryList.add(i, vline); } } if
			 * (currentModay.compareTo(thisMonday) > 0) { flag = true; } else {
			 * flag = false; }
			 */
			LabelCategory category = new LabelCategory();
			if (ps != null) {
				if (ps.getTtmTargetDate() != null
						&& thisMonday.equals(CalendarUtil.date2String(ssDate))) {
					category.setName(thisMonday + "(SS)");
				} else if (ps.getTtvTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getTtvTargetDate())))) {
					category.setName(thisMonday + "(SLE)");
				} else if (ps.getSvtPlanDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSvtPlanDate())))) {
					category.setName(thisMonday + "(SVT)");
				} else if (ps.getSovpPlanDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSovpPlanDate())))) {
					category.setName(thisMonday + "(SOVP)");
				} else if (ps.getSgaTtvTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSgaTtvTargetDate())))) {
					category.setName(thisMonday + "(SGA)");
				} else
					category.setName(thisMonday);
				categoryList.add(category);
			}
			TTVOutlookChartData tTVOutlookChartData = ttvOutlookListMap
					.get(thisMonday);
			String trackingCausesMonday = null;
			String trackingCausesSunday = null;
			trackingCausesMonday = CalendarUtil.getDateByDays(startDate, 7 * i);
			trackingCausesSunday = CalendarUtil.getDateByDays(
					CalendarUtil.stringT2Date(trackingCausesMonday), 6);

			// Demand Order or Demand Rolling or Demand Forecast
			if (tTVOutlookChartData != null) {
				// TTL Gap
				ColumnData tTLGap = new ColumnData();
				boolean isGapExist = tTVOutlookChartData.getTotalGap() == 0 ? false
						: true;
				tTLGap.setValue(-tTVOutlookChartData.getTotalGap());
				setOutlookWeeklyColumnLink(tTLGap, thisMonday, currentModay,
						trackingCausesMonday, trackingCausesSunday);
				gapColumnDataList.add(tTLGap);

				// Ramp Commit
				ColumnData rampCommit = new ColumnData();
				if (isGapExist) {
					setOutlookWeeklyColumnLink(rampCommit, thisMonday,
							currentModay, trackingCausesMonday,
							trackingCausesSunday);
				}
				rampCommit
						.setValue(tTVOutlookChartData.getRampCommit() == null ? 0f
								: tTVOutlookChartData.getRampCommit()
										.floatValue());
				rampCommitColumnDataList.add(rampCommit);

				// Capacity
				// ColumnData capacity = new ColumnData();
				ColumnData shipment = new ColumnData();
				if (thisMonday.compareTo(currentModay) >= 0) {
					/*
					 * if (isGapExist) { setOutlookWeeklyColumnLink(capacity,
					 * thisMonday, currentModay, trackingCausesMonday,
					 * trackingCausesSunday); }
					 * capacity.setValue(tTVOutlookChartData.getCapacity() < 0 ?
					 * 0f : tTVOutlookChartData.getCapacity().floatValue());
					 * capacityColumnDataList.add(capacity);
					 */

					shipment.setValue(0);
					shipmentColumnDataList.add(shipment);
				} else {
					/*
					 * capacity.setValue(0f);
					 * capacityColumnDataList.add(capacity);
					 */

					if (isGapExist) {
						setOutlookWeeklyColumnLink(shipment, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
					shipment.setValue(tTVOutlookChartData.getShipment() != null ? tTVOutlookChartData
							.getShipment() : 0);
					shipmentColumnDataList.add(shipment);
				}

				// Actual TTV or Estimated TTV
				ColumnData ttv = new ColumnData();
				ttv.setValue(tTVOutlookChartData.getTtv());
				ttvColumnDataList.add(ttv);

				ColumnData sgaTtv = new ColumnData();
				if (!thisMondayDate.before(ssDate)) {

					if (tTVOutlookChartData.getSgaTTV() == -1) {
						sgaTtv.setValue(100f);
					} else {
						sgaTtv.setValue(tTVOutlookChartData.getSgaTTV());
					}
				}
				sgaTtvColumnDataList.add(sgaTtv);

				ColumnData order = new ColumnData();
				if (tTVOutlookChartData.getOrder() != null
						&& tTVOutlookChartData.getOrder() > 0) {
					order.setValue(tTVOutlookChartData.getOrder());
				}
				demandColumnDataList.add(order);

				ColumnData forecast = new ColumnData();
				if (tTVOutlookChartData.getForecast() != null
						&& tTVOutlookChartData.getForecast() > 0) {
					forecast.setValue(tTVOutlookChartData.getForecast());
				}
				forecastColumnDataList.add(forecast);
				if (isGapExist) {
					setOutlookWeeklyColumnLink(order, thisMonday, currentModay,
							trackingCausesMonday, trackingCausesSunday);
					setOutlookWeeklyColumnLink(forecast, thisMonday,
							currentModay, trackingCausesMonday,
							trackingCausesSunday);
				}
				Vline vline = new Vline();
				categoryList.add(vline);
				vline.setDashed("1");
				vline.setVline("true");
			} else {
				/*
				 * ColumnData capacity = new ColumnData(); capacity.setValue(0);
				 * capacityColumnDataList.add(capacity);
				 */

				ColumnData tTLGap = new ColumnData();
				// tTLGap.setValue(0);
				gapColumnDataList.add(tTLGap);

				ColumnData rampCommit = new ColumnData();
				// rampCommit.setValue(0);
				rampCommitColumnDataList.add(rampCommit);

				// Actual TTV or Estimated TTV
				ColumnData ttv = new ColumnData();
				// ttv.setValue(0);
				ttvColumnDataList.add(ttv);

				ColumnData sgaTtv = new ColumnData();
				// sgaTtv.setValue(0);
				sgaTtvColumnDataList.add(sgaTtv);

				ColumnData shipment = new ColumnData();
				// shipment.setValue(0);
				shipmentColumnDataList.add(shipment);

				ColumnData order = new ColumnData();
				// order.setValue(0);
				demandColumnDataList.add(order);

				ColumnData forecast = new ColumnData();
				forecastColumnDataList.add(forecast);
			}
			// Target
			ColumnData target = new ColumnData();
			target.setValue(ps != null && ps.getTtvTarget() != null ? ps
					.getTtvTarget() : 0);
			targetColumnDataList.add(target);

			ColumnData sgaTarget = new ColumnData();
			sgaTarget.setValue(ps != null && ps.getSgaTtvTarget() != null ? ps
					.getSgaTtvTarget() : 0);
			sgaTargetColumnDataList.add(sgaTarget);
		}
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		rampCommitDataSetColumn.setDataList(rampCommitColumnDataList);
		rampCommitDataSetList.add(rampCommitDataSetColumn);

		/*
		 * capacityDataSetColumn.setDataList(capacityColumnDataList);
		 * capacitySetList.add(capacityDataSetColumn);
		 */

		gapDataSetColumn.setDataList(gapColumnDataList);
		gapSetList.add(gapDataSetColumn);

		demandDataSetColumn.setDataList(demandColumnDataList);
		demandSetList.add(demandDataSetColumn);

		forecastDataSetColumn.setDataList(forecastColumnDataList);
		forecastSetList.add(forecastDataSetColumn);

		shipmentDataSetColumn.setDataList(shipmentColumnDataList);
		shipmentSetList.add(shipmentDataSetColumn);

		rampCommitDataSet.setDataSetList(rampCommitDataSetList);
		// capacityDataSet.setDataSetList(capacitySetList);
		gapDataSet.setDataSetList(gapSetList);
		demandDataSet.setDataSetList(demandSetList);
		forecastDataSet.setDataSetList(forecastSetList);
		shipmentDataSet.setDataSetList(shipmentSetList);

		// dataSetList.add(capacityDataSet);
		dataSetList.add(rampCommitDataSet);
		dataSetList.add(forecastDataSet);
		dataSetList.add(gapDataSet);
		dataSetList.add(demandDataSet);
		dataSetList.add(shipmentDataSet);

		ttvLineSet.setDataList(ttvColumnDataList);
		targetLineSet.setDataList(targetColumnDataList);
		sgaTtvLineSet.setDataList(sgaTtvColumnDataList);
		sgaTargetLineSet.setDataList(sgaTargetColumnDataList);

		lineSetList.add(sgaTtvLineSet);
		lineSetList.add(sgaTargetLineSet);
		if (showSle) {
			lineSetList.add(ttvLineSet);
			lineSetList.add(targetLineSet);
		}
		columnChartView.setDataSetList(dataSetList);
		columnChartView.setLineSetList(lineSetList);

		return columnChartView;
	}

	@Override
	public MSColumnChartView getSummaryJsonChartData(Integer waveId,
			boolean isShowSga, boolean isOdmFpy) throws ParseException {
		MSColumnChartView columnChartView = new MSColumnChartView();
		columnChartView.getChartInfo().setShowAlternateHGridColor("0");
		columnChartView.getChartInfo().setPyaxisname("Unit");
		columnChartView.getChartInfo().setSyaxisname("TTV Percentage %");
		columnChartView.getChartInfo().setNumbersuffix("(pcs)");
		boolean actualSleFlag = true;
		// fetch wave info
		ProjectSummary ps = nPIProductSummaryDao.getProductInfoByWaveId(waveId,
				null);
		if (ps == null) {
			return null;
		}
		Date endDate = ps.getTtvSignOffDate() == null ? CalendarUtil
				.getTodayWithoutMins() : ps.getTtvSignOffDate();
		int count = masterDataService.getThresholdByName(
				Threshold.TTV_OUTLOOK_DURATION.name()).intValue();
		Date startDate = CalendarUtil.getMondayDateByWeeks(endDate, -count);
		Date versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil
				.getTodayWithoutMins());

		// fetch data by calling tTVOutlookService interface
		List<TTVOutlookChartData> tTVOutlookChartDataList = tTVOutlookService
				.getChartData(waveId, startDate, endDate,
						TimeFrequencyEnum.WEEKLY, isOdmFpy, versionDate,
						isShowSga, false);

		Map<String, TTVOutlookChartData> ttvOutlookListMap = new HashMap<String, TTVOutlookChartData>();

		for (TTVOutlookChartData data : tTVOutlookChartDataList) {
			ttvOutlookListMap.put(CalendarUtil.date2String(CalendarUtil
					.getMondayDateByDate(data.getDate())), data);
		}

		// categories
		// boolean flag = false;
		String currentModay = CalendarUtil.date2String(CalendarUtil
				.getMondayDateByDate(Calendar.getInstance().getTime()));
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		// dataset list and lineset list
		List<DataSet> dataSetList = new ArrayList<DataSet>();
		List<LineSet> lineSetList = new ArrayList<LineSet>();

		// dataset
		DataSet demandDataSet = new DataSet();
		DataSet odmDataSet = new DataSet();
		DataSet shipmentDataSet = new DataSet();
		DataSet estimatedCapacityDataSet = new DataSet();
		DataSet gapDataSet = new DataSet();

		LineSet ttvLineSet = new LineSet();
		ttvLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_ACTUALSLETTV);
		ttvLineSet.setColor(SysConfig.TTV_OUTLOOK_SLETTV_COLOR);
		ttvLineSet.setShowValues("0");
		ttvLineSet.setLineThickness("2");

		LineSet targetLineSet = new LineSet();
		targetLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_SLETTV_TARGET);
		targetLineSet.setColor(SysConfig.TTV_OUTLOOK_SLETTV_TARGET_COLOR);
		targetLineSet.setShowValues("0");
		targetLineSet.setLineThickness("2");

		LineSet sgaTtvLineSet = new LineSet();
		sgaTtvLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_SGATTV);
		sgaTtvLineSet.setColor(SysConfig.TTV_OUTLOOK_SGATTV_COLOR);
		sgaTtvLineSet.setShowValues("0");
		sgaTtvLineSet.setLineThickness("2");

		LineSet sgaTargetLineSet = new LineSet();
		sgaTargetLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_SGATTV_TARGET);
		sgaTargetLineSet.setColor(SysConfig.TTV_OUTLOOK_SGATTV_TARGET_COLOR);
		sgaTargetLineSet.setShowValues("0");
		sgaTargetLineSet.setLineThickness("2");

		// dataset:seriesName
		List<DataSetParent> demandDataSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> odmDataSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> shipmentSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> estimatedCapacitySetList = new ArrayList<DataSetParent>();
		List<DataSetParent> gapSetList = new ArrayList<DataSetParent>();

		// Demand Order or Demand Rolling or Demand Forecast
		DataSetColumn demandDataSetColumn = new DataSetColumn();
		demandDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_DEMAND);
		demandDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_DEMAND_COLOR);
		List<ColumnData> demandCloumnDataList = new ArrayList<ColumnData>();

		// Shipment or Estimated Capacity
		DataSetColumn shipDataSetColumn = new DataSetColumn();
		shipDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_SHIPMENT);
		shipDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_SHIPMENT_COLOR);
		List<ColumnData> shipmentCloumnDataList = new ArrayList<ColumnData>();

		DataSetColumn capacityDataSetColumn = new DataSetColumn();
		capacityDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_CAPACITY);
		shipDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_CAPACITY_COLOR);
		List<ColumnData> capacityCloumnDataList = new ArrayList<ColumnData>();

		// ODM Commitment
		DataSetColumn odmDataSetColumn = new DataSetColumn();
		odmDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_ODMCOMMITMENT);
		odmDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_ODMCOMMITMENT_COLOR);
		List<ColumnData> odmCloumnDataList = new ArrayList<ColumnData>();

		// TTL Gap
		DataSetColumn ttlGapDataSetColumn = new DataSetColumn();
		ttlGapDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_GAP);
		ttlGapDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_GAP_COLOR);
		List<ColumnData> ttlGapCloumnDataList = new ArrayList<ColumnData>();

		List<ColumnData> ttvColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> sgaTtvColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> sgaTargetCloumnDataList = new ArrayList<ColumnData>();

		for (int i = 0; i <= count; i++) {
			String thisMonday = CalendarUtil.date2String(CalendarUtil
					.getMondayDateByWeeks(startDate, i));
			// if (flag) {
			// if (currentModay.compareTo(thisMonday) <= 0) {
			// Vline vline = new Vline();
			// vline.setLabel("Current Week");
			// vline.setVline("true");
			// categoryList.add(i, vline);
			// }
			// }
			// if (currentModay.compareTo(thisMonday) > 0) {
			// flag = true;
			// } else
			// flag = false;
			LabelCategory category = new LabelCategory();
			if (ps != null) {
				if (ps.getTtmTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getTtmTargetDate())))) {
					category.setName(thisMonday + "(SS)");
				} else if (ps.getTtvTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getTtvTargetDate())))) {
					category.setName(thisMonday + "(SLE)");
				} else if (ps.getSvtPlanDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSvtPlanDate())))) {
					category.setName(thisMonday + "(SVT)");
				} else if (ps.getSovpPlanDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSovpPlanDate())))) {
					category.setName(thisMonday + "(SOVP)");
				} else if (ps.getSgaTtvTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSgaTtvTargetDate())))) {
					category.setName(thisMonday + "(SGA)");
				} else
					category.setName(thisMonday);
			}
			categoryList.add(category);

			TTVOutlookChartData tTVOutlookChartData = ttvOutlookListMap
					.get(thisMonday);
			String trackingCausesMonday = null;
			String trackingCausesSunday = null;
			trackingCausesMonday = CalendarUtil.getDateByDays(startDate, 7 * i);
			trackingCausesSunday = CalendarUtil.getDateByDays(
					CalendarUtil.stringT2Date(trackingCausesMonday), 6);

			// Demand Order or Demand Rolling or Demand Forecast

			if (tTVOutlookChartData != null) {
				// TTL Gap
				ColumnData tTLGap = new ColumnData();
				boolean isGapExist = tTVOutlookChartData.getTotalGap() == 0 ? false
						: true;
				tTLGap.setValue(-tTVOutlookChartData.getTotalGap());
				setOutlookWeeklyColumnLink(tTLGap, thisMonday, currentModay,
						trackingCausesMonday, trackingCausesSunday);
				ttlGapCloumnDataList.add(tTLGap);

				if (thisMonday.compareTo(currentModay) < 0) {
					ColumnData demand = new ColumnData();
					demand.setValue(tTVOutlookChartData.getOrder() != null ? tTVOutlookChartData
							.getOrder() : 0);
					if (demand.getValue() != null
							&& demand.getValue().intValue() < 0) {
						demand.setValue(0);
					}
					demandCloumnDataList.add(demand);
					if (isGapExist) {
						setOutlookWeeklyColumnLink(demand, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
				} else if (thisMonday.compareTo(currentModay) == 0) {
					ColumnData demand = new ColumnData();
					if (isGapExist) {
						setOutlookWeeklyColumnLink(demand, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
					demand.setValue(tTVOutlookChartData.getDemand() != null ? tTVOutlookChartData
							.getDemand() : 0);
					if (demand.getValue() != null
							&& demand.getValue().intValue() < 0) {
						demand.setValue(0);
					}
					demandCloumnDataList.add(demand);
				} else {
					ColumnData demand = new ColumnData();
					demand.setValue(0);
					demandCloumnDataList.add(demand);
					if (isGapExist) {
						setOutlookWeeklyColumnLink(demand, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
				}

				// ODM Commitment
				ColumnData oDMCommitment = new ColumnData();
				if (isGapExist) {

					setOutlookWeeklyColumnLink(oDMCommitment, thisMonday,
							currentModay, trackingCausesMonday,
							trackingCausesSunday);
				}
				oDMCommitment.setValue(tTVOutlookChartData.getOdmCommit());
				odmCloumnDataList.add(oDMCommitment);

				// Shipment or Estimated Capacity
				ColumnData estimatedCapacity = new ColumnData();
				ColumnData shipment = new ColumnData();
				if (thisMonday.compareTo(currentModay) >= 0) {
					if (isGapExist) {
						setOutlookWeeklyColumnLink(estimatedCapacity,
								thisMonday, currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
					estimatedCapacity.setValue(tTVOutlookChartData
							.getCapacity() < 0 ? 0 : tTVOutlookChartData
							.getCapacity());
					capacityCloumnDataList.add(estimatedCapacity);

					shipment.setValue(0);
					shipmentCloumnDataList.add(shipment);
				} else {
					if (isGapExist) {
						setOutlookWeeklyColumnLink(shipment, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
					shipment.setValue(tTVOutlookChartData.getShipment() < 0 ? 0
							: tTVOutlookChartData.getShipment());
					shipmentCloumnDataList.add(shipment);

					estimatedCapacity.setValue(0);
					capacityCloumnDataList.add(estimatedCapacity);
				}

				if (Integer.valueOf(trackingCausesMonday.replace("-", "")) >= Integer
						.valueOf(currentModay.replace("-", ""))) {
						actualSleFlag = false;
				}

				// Actual TTV or Estimated TTV
				ColumnData ttv = new ColumnData();
				ttv.setValue(tTVOutlookChartData.getTtv());
				ttvColumnDataList.add(ttv);

				// sga starts at ss , ends at sga
				ColumnData sgaTtv = new ColumnData();
				if (null != ps.getTtmTargetDate()
						&& null != ps.getSgaTtvTargetDate()) {
					if (thisMonday.compareTo(CalendarUtil
							.date2String(CalendarUtil.getMondayDateByDate(ps
									.getTtmTargetDate()))) >= 0
							&& thisMonday.compareTo(CalendarUtil
									.date2String(CalendarUtil
											.getMondayDateByDate(ps
													.getSgaTtvTargetDate()))) <= 0) {
						sgaTtv.setValue(tTVOutlookChartData.getSgaTTV() != null ? tTVOutlookChartData
								.getSgaTTV() : 0);
					}
				}

				sgaTtvColumnDataList.add(sgaTtv);

				Vline vline = new Vline();
				categoryList.add(vline);
				vline.setDashed("1");
				vline.setVline("true");

			} else {

				ColumnData demand = new ColumnData();
				demand.setValue(0);
				demandCloumnDataList.add(demand);

				ColumnData oDMCommitment = new ColumnData();
				oDMCommitment.setValue(0);
				odmCloumnDataList.add(oDMCommitment);

				ColumnData shipment = new ColumnData();
				shipment.setValue(0);
				shipmentCloumnDataList.add(shipment);

				ColumnData estimatedCapacity = new ColumnData();
				estimatedCapacity.setValue(0);
				capacityCloumnDataList.add(estimatedCapacity);

				ColumnData tTLGap = new ColumnData();
				tTLGap.setValue(0);
				ttlGapCloumnDataList.add(tTLGap);

				// Actual TTV or Estimated TTV
				ColumnData ttv = new ColumnData();
				ttv.setValue(0);
				ttvColumnDataList.add(ttv);

				ColumnData sgaTtv = new ColumnData();
				sgaTtv.setValue(0);
				sgaTtvColumnDataList.add(sgaTtv);

			}
			// Target
			ColumnData target = new ColumnData();
			target.setValue(ps != null && ps.getTtvTarget() != null ? ps
					.getTtvTarget() : 0);
			targetCloumnDataList.add(target);

			// Target
			ColumnData sgaTarget = new ColumnData();
			sgaTarget.setValue(ps != null && ps.getSgaTtvTarget() != null ? ps
					.getSgaTtvTarget() : 0);
			sgaTargetCloumnDataList.add(sgaTarget);
		}
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		demandDataSetColumn.setDataList(demandCloumnDataList);
		demandDataSetList.add(demandDataSetColumn);

		capacityDataSetColumn.setDataList(capacityCloumnDataList);
		estimatedCapacitySetList.add(capacityDataSetColumn);

		odmDataSetColumn.setDataList(odmCloumnDataList);
		odmDataSetList.add(odmDataSetColumn);

		shipDataSetColumn.setDataList(shipmentCloumnDataList);
		shipmentSetList.add(shipDataSetColumn);

		ttlGapDataSetColumn.setDataList(ttlGapCloumnDataList);
		gapSetList.add(ttlGapDataSetColumn);

		demandDataSet.setDataSetList(demandDataSetList);
		odmDataSet.setDataSetList(odmDataSetList);
		shipmentDataSet.setDataSetList(shipmentSetList);
		estimatedCapacityDataSet.setDataSetList(estimatedCapacitySetList);
		gapDataSet.setDataSetList(gapSetList);

		ttvLineSet.setDataList(ttvColumnDataList);
		targetLineSet.setDataList(targetCloumnDataList);
		sgaTtvLineSet.setDataList(sgaTtvColumnDataList);
		sgaTargetLineSet.setDataList(sgaTargetCloumnDataList);

		dataSetList.add(odmDataSet);
		dataSetList.add(estimatedCapacityDataSet);
		dataSetList.add(demandDataSet);
		dataSetList.add(shipmentDataSet);
		dataSetList.add(gapDataSet);
		if (!actualSleFlag) {
			ttvLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_SLETTV);
		}
		lineSetList.add(ttvLineSet);
		lineSetList.add(targetLineSet);
		if (isShowSga) {
			lineSetList.add(sgaTtvLineSet);
			lineSetList.add(sgaTargetLineSet);
		}
		columnChartView.setDataSetList(dataSetList);
		columnChartView.setLineSetList(lineSetList);

		return columnChartView;
	}

	@Override
	public ProjectOutLookView getOdmCapacity(ProductWave proWave)
			throws ParseException {
		return getProjecteView(proWave);
	}

	public ColumnChartView getOdmDetailColumnDataByWeekly(
			SearchOutlookDataForm form, String isPreview,
			String selectedExcludeOrderIds) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();
		Date startDate = form.getStartDate();

		Date versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil
				.getTodayWithoutMins());
		ProjectSummary ps = nPIProductSummaryDao.getProductInfoByWaveId(
				form.getWaveId(), versionDate);
		if (form.getStartDate() == null) {
			Float startNum = masterDataService
					.getThresholdByName(Threshold.TTV_OUTLOOK_STARTDATE.name());
			Float endNum = masterDataService
					.getThresholdByName(Threshold.TTV_OUTLOOK_ENDDATE.name());

			form.setStartDate(CalendarUtil.getMondayDateByWeeks(
					ps.getTtvTargetDate(), startNum.intValue()));
			form.setEndDate(CalendarUtil.getMondayDateByWeeks(
					ps.getTtvTargetDate(), endNum.intValue()));
		} else {
			Float durationNum = masterDataService
					.getThresholdByName(Threshold.TTV_OUTLOOK_DURATION.name());
			form.setEndDate(CalendarUtil.getMondayDateByWeeks(
					form.getStartDate(), durationNum.intValue()));
		}
		Date endDate = form.getEndDate();
		String currentModay = null;
		boolean odmFpy = "ODM".equals(form.getFpy()) ? true : false;
		int waveId = form.getWaveId();
		/*
		 * if("true".equals(isPreview)){ List<NpiOrder> excludedOrders = new
		 * ArrayList<NpiOrder>();
		 * 
		 * NpiOrder npiOrder = new NpiOrder();
		 * 
		 * tTVOutlookChartDataList = tTVOutlookService.previewChartData(waveId,
		 * startDate, endDate, TimeFrequencyEnum.DAILY, odmFpy, excludedOrders);
		 * }else{ //fetch data by calling tTVOutlookService interface
		 * tTVOutlookChartDataList = tTVOutlookService.getChartData(waveId,
		 * startDate, endDate, TimeFrequencyEnum.WEEKLY, odmFpy); }
		 */

		// fetch data by calling tTVOutlookService interface
		List<TTVOutlookChartData> tTVOutlookChartDataList = tTVOutlookService
				.getChartData(waveId, startDate, endDate,
						TimeFrequencyEnum.WEEKLY, odmFpy, versionDate, false,
						false);

		// categories
		boolean flag = false;
		currentModay = CalendarUtil.date2String(CalendarUtil
				.getMondayDateByDate(Calendar.getInstance().getTime()));
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		int count = masterDataService.getThresholdByName(
				Threshold.TTV_OUTLOOK_DURATION.name()).intValue();

		Map<String, TTVOutlookChartData> ttvOutlookListMap = new HashMap<String, TTVOutlookChartData>();

		for (TTVOutlookChartData data : tTVOutlookChartDataList) {
			ttvOutlookListMap.put(CalendarUtil.date2String(CalendarUtil
					.getMondayDateByDate(data.getDate())), data);
		}

		// dataset
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();

		// Demand
		DataSetColumn demandDataSet = new DataSetColumn();
		demandDataSet.setSeriesName(SysConfig.TTV_OUTLOOK_DEMAND);
		List<ColumnData> demandCloumnDataList = new ArrayList<ColumnData>();

		// Shipment or ODM Capacity
		DataSetColumn shipmentOrCapacityDataSet = new DataSetColumn();
		shipmentOrCapacityDataSet.setSeriesName(SysConfig.TTV_OUTLOOK_SHIPMENT);
		List<ColumnData> shipmentOrCapacityCloumnDataList = new ArrayList<ColumnData>();

		// TTV ODM Gap
		DataSetColumn ttlGapDataSet = new DataSetColumn();
		ttlGapDataSet.setSeriesName(SysConfig.TTV_OUTLOOK_TTV_GAP);
		List<ColumnData> ttlGapCloumnDataList = new ArrayList<ColumnData>();

		// Actual TTV or Estimated TTV
		DataSetLine ttvDataSet = new DataSetLine();
		ttvDataSet.setSeriesName(SysConfig.TTV_OUTLOOK_TTV);
		ttvDataSet.setParentYaxis("S");
		ttvDataSet.setRenderas("Line");
		ttvDataSet.setColor(SysConfig.TTV_OUTLOOK_TTV_COLOR);// Ã§ÂºÂ¢Ã¨â€°Â²
		List<ColumnData> ttvDataList = new ArrayList<ColumnData>();

		// Target
		DataSetLine targetDataSet = new DataSetLine();
		targetDataSet.setSeriesName(SysConfig.TTV_OUTLOOK_TTV_TARGET);
		targetDataSet.setParentYaxis("S");
		targetDataSet.setRenderas("Line");
		targetDataSet.setColor(SysConfig.TTV_OUTLOOK_TTV_TARGET_COLOR);// Ã©Â»â€˜Ã¨â€°Â²
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();

		for (int i = 0; i <= count; i++) {
			String startDateMonday = CalendarUtil.date2String(CalendarUtil
					.getMondayDateByWeeks(form.getStartDate(), i));
			if (flag) {
				if (currentModay.compareTo(startDateMonday) <= 0) {
					Vline vline = new Vline();
					vline.setLabel("Current Week");
					vline.setVline("true");
					vline.setLabelPosition("0");
					categoryList.add(i, vline);
				}
			}
			if (currentModay.compareTo(startDateMonday) > 0) {
				flag = true;
			} else
				flag = false;
			LabelCategory category = new LabelCategory();
			category.setName(startDateMonday);
			categoryList.add(category);

			String trackingCausesMonday = null;
			String trackingCausesSunday = null;
			trackingCausesMonday = CalendarUtil.getDateByDays(
					form.getStartDate(), 7 * i);
			trackingCausesSunday = CalendarUtil.getDateByDays(
					CalendarUtil.stringT2Date(trackingCausesMonday), 6);

			TTVOutlookChartData tTVOutlookChartData = ttvOutlookListMap
					.get(startDateMonday);

			if (tTVOutlookChartData != null) {

				// Demand
				startDateMonday = CalendarUtil.getDateByDays(startDate, 7 * i);

				ColumnData demand = new ColumnData();
				setCapacityWeeklyColumnLink(demand, startDateMonday,
						currentModay, trackingCausesMonday,
						trackingCausesSunday, form.getFpy());
				demand.setValue(tTVOutlookChartData.getFutureOrder());
				// demand.setColor("006699");//Ã¨â€œÂ�Ã¨â€°Â²
				demandCloumnDataList.add(i, demand);

				// Shipment or ODM Capacity
				if (startDateMonday.compareTo(currentModay) < 0) {
					ColumnData shipment = new ColumnData();
					setOutlookWeeklyColumnLink(shipment, startDateMonday,
							currentModay, trackingCausesMonday,
							trackingCausesSunday);
					shipment.setValue(tTVOutlookChartData.getShipment());
					// estimatedCapacity.setColor("66cc66");//Ã§Â»Â¿Ã¨â€°Â²
					shipmentOrCapacityDataSet
							.setSeriesName(SysConfig.TTV_OUTLOOK_SHIPMENT);
					shipmentOrCapacityDataSet
							.setColor(SysConfig.TTV_OUTLOOK_SHIPMENT_COLOR);
					shipmentOrCapacityCloumnDataList.add(i, shipment);
				} else {
					ColumnData estimatedCapacity = new ColumnData();
					setCapacityWeeklyColumnLink(estimatedCapacity,
							startDateMonday, currentModay,
							trackingCausesMonday, trackingCausesSunday,
							form.getFpy());
					estimatedCapacity.setValue(tTVOutlookChartData
							.getCapacity());
					// shipment.setColor("ffcc66");//Ã©Â»â€žÃ¨â€°Â²
					shipmentOrCapacityDataSet
							.setSeriesName(SysConfig.TTV_OUTLOOK_ODM);
					shipmentOrCapacityDataSet
							.setColor(SysConfig.TTV_OUTLOOK_ODM_COLOR);
					shipmentOrCapacityCloumnDataList.add(i, estimatedCapacity);
				}

				// TTV ODM Gap
				ColumnData tTLGap = new ColumnData();
				tTLGap.setValue(-tTVOutlookChartData.getTotalGap());
				tTLGap.setColor("FF0000");// Ã§ÂºÂ¢Ã¨â€°Â²
				setCapacityWeeklyColumnLink(tTLGap, startDateMonday,
						currentModay, trackingCausesMonday,
						trackingCausesSunday, form.getFpy());
				ttlGapCloumnDataList.add(tTLGap);

				// Actual TTV or Estimated TTV
				ColumnData ttv = new ColumnData();
				ttv.setValue(tTVOutlookChartData.getTtv());
				ttv.setColor("");
				ttvDataList.add(ttv);

			} else {
				// Demand
				startDateMonday = CalendarUtil.getDateByDays(startDate, 7 * i);

				ColumnData demand = new ColumnData();
				setCapacityWeeklyColumnLink(demand, startDateMonday,
						currentModay, trackingCausesMonday,
						trackingCausesSunday, form.getFpy());
				demand.setValue(0);
				// demand.setColor("006699");//Ã¨â€œÂ�Ã¨â€°Â²
				demandCloumnDataList.add(i, demand);

				if (startDateMonday.compareTo(currentModay) < 0) {
					ColumnData shipment = new ColumnData();
					setOutlookWeeklyColumnLink(shipment, startDateMonday,
							currentModay, trackingCausesMonday,
							trackingCausesSunday);
					shipment.setValue(0);
					// estimatedCapacity.setColor("66cc66");//Ã§Â»Â¿Ã¨â€°Â²
					shipmentOrCapacityDataSet
							.setSeriesName(SysConfig.TTV_OUTLOOK_SHIPMENT);
					shipmentOrCapacityDataSet
							.setColor(SysConfig.TTV_OUTLOOK_SHIPMENT_COLOR);
					shipmentOrCapacityCloumnDataList.add(i, shipment);
				} else {
					ColumnData estimatedCapacity = new ColumnData();
					setCapacityWeeklyColumnLink(estimatedCapacity,
							startDateMonday, currentModay,
							trackingCausesMonday, trackingCausesSunday,
							form.getFpy());
					estimatedCapacity.setValue(0);
					// shipment.setColor("ffcc66");//Ã©Â»â€žÃ¨â€°Â²
					shipmentOrCapacityDataSet
							.setSeriesName(SysConfig.TTV_OUTLOOK_ODM);
					shipmentOrCapacityDataSet
							.setColor(SysConfig.TTV_OUTLOOK_ODM_COLOR);
					shipmentOrCapacityCloumnDataList.add(i, estimatedCapacity);
				}

				// TTV ODM Gap
				ColumnData tTLGap = new ColumnData();
				tTLGap.setValue(0);
				tTLGap.setColor("FF0000");// Ã§ÂºÂ¢Ã¨â€°Â²
				setCapacityWeeklyColumnLink(tTLGap, startDateMonday,
						currentModay, trackingCausesMonday,
						trackingCausesSunday, form.getFpy());
				ttlGapCloumnDataList.add(tTLGap);

				// Actual TTV or Estimated TTV
				ColumnData ttv = new ColumnData();
				ttv.setValue(0);
				ttv.setColor("");
				ttvDataList.add(ttv);
			}
			// Target
			ColumnData target = new ColumnData();
			target.setValue(ps.getTtvTarget() == null ? 0 : ps.getTtvTarget());//
			targetCloumnDataList.add(target);
		}

		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		demandDataSet.setDataList(demandCloumnDataList);
		dataSetList.add(demandDataSet);

		shipmentOrCapacityDataSet.setDataList(shipmentOrCapacityCloumnDataList);
		dataSetList.add(shipmentOrCapacityDataSet);

		ttlGapDataSet.setDataList(ttlGapCloumnDataList);
		dataSetList.add(ttlGapDataSet);

		ttvDataSet.setDataList(ttvDataList);
		dataSetList.add(ttvDataSet);

		targetDataSet.setDataList(targetCloumnDataList);
		dataSetList.add(targetDataSet);

		columnChartView.setDataSetList(dataSetList);

		return columnChartView;
	}

	public PieChartView getOdmMainPieChart(SearchOutlookDataForm form) {

		List<PieDivider> detractorDividerList = npiOrderDaoDw
				.getDetractorMainDivider(form);
		Map<String, String> odmMap = new HashMap<String, String>();
		String productId = String.valueOf(form.getProductId());
		// List<OdmCapacityPlanDetail> odmCapacityPlanDetailList = new
		// ArrayList<OdmCapacityPlanDetail>();

		int totalQuantityForecastUPSIDE = 0, totalQuantityOrderUPSIDE = 0, totalQuantityOrderOFFSET = 0, totalQuantityForecastOFFSET = 0;
		int waveId = 0;
		Date startDate = form.getStartDate();
		Date endDate = form.getEndDate();
		Date versionDate = null, targetDate = null;
		// String fpy = form.getFpy();
		for (PieDivider detractorDivider : detractorDividerList) {
			odmMap.put(detractorDivider.getLevel1Name(),
					detractorDivider.getLevel1Num() + "");
		}

		try {
			waveId = form.getWaveId();

			// odmCapacityPlanDetailList =
			// odmCapacityDao.getDetailCapacityPlanByTargetDate(form.getWaveId(),
			// CalendarUtil.stringT2Date(form.getTtvTargetDate()),
			// form.getVersionDate());

			targetDate = CalendarUtil.stringT2Date(form.getTtvTargetDate());
			versionDate = form.getVersionDate();

		} catch (ParseException pe) {
			pe.printStackTrace();
		}

		/*
		 * float totalCapacityFloat = 0.0f; float capacityFloat = 0.0f; for
		 * (OdmCapacityPlanDetail odmCapacityPlanDetail :
		 * odmCapacityPlanDetailList) { capacityFloat =
		 * odmCapacityPlanDetail.getUnitsPerHour() *
		 * odmCapacityPlanDetail.getHoursPerDay() *
		 * odmCapacityPlanDetail.getDaysPerWeek()
		 * odmCapacityPlanDetail.getFpy(); totalCapacityFloat += capacityFloat;
		 * }
		 */

		String startMonday = "", startSunday = "";
		try {
			startMonday = CalendarUtil.date2String(form.getStartDate());
			startSunday = CalendarUtil.date2String(form.getEndDate());
		} catch (Exception e) {
			e.printStackTrace();
		}
		PieSlice p1 = new PieSlice();
		p1.setLink("j-showOdmCausesData-ODM Capacity," + startMonday + "|"
				+ startSunday);

		p1.setLabel(CapacityCausesEnum.ODM_Capacity.toString());
		p1.setColor(CapacityCausesEnum.ODM_Capacity.getColor());
		// p1.setValue(odmMap.get(ODMCausesEnum.ODM_Capacity.toString()));
		// p1.setValue(String.valueOf(totalCapacityFloat));

		List<CausesByForecast> odmCausesByForecastOFFSETList = new ArrayList<CausesByForecast>();
		List<NpiWeeklyComponentCommitmentOnForecast> forecastDataList = tTVOutlookServiceBiHelper
				.getCausedForecastDataByProduct(String.valueOf(productId),
						targetDate, versionDate,
						ForecastComparisonTypeEnum.OFFSET);

		odmCausesByForecastOFFSETList = tTVOutlookServiceDwHelper
				.getCauseForecastDetail(targetDate, versionDate,
						forecastDataList);
		for (CausesByForecast causesByForecast : odmCausesByForecastOFFSETList) {
			totalQuantityForecastOFFSET += Integer.parseInt(causesByForecast
					.getQuantity());
		}

		PieSlice p2 = new PieSlice();
		p2.setLink("j-showOdmCausesData-Offset Forecast");
		p2.setLabel(CapacityCausesEnum.Offset_Forecast.toString());
		p2.setColor(CapacityCausesEnum.Offset_Forecast.getColor());
		// p2.setValue(odmMap.get(ODMCausesEnum.Offset_Forecast.toString()));
		p2.setValue(String.valueOf(totalQuantityForecastOFFSET));

		List<CausesByOrder> odmCausesByOrderOFFSETList = new ArrayList<CausesByOrder>();
		List<NpiWeeklyComponentCommitmentOnOrder> orderDataList = tTVOutlookServiceBiHelper
				.getCausedOrderByProduct(String.valueOf(waveId), versionDate,
						ForecastComparisonTypeEnum.OFFSET);
		odmCausesByOrderOFFSETList = tTVOutlookServiceDwHelper
				.getCauseOrderDetail(orderDataList);
		for (CausesByOrder causesByOrder : odmCausesByOrderOFFSETList) {
			totalQuantityOrderOFFSET += Integer.parseInt(causesByOrder
					.getQuantity());
		}

		PieSlice p3 = new PieSlice();
		p3.setLink("j-showOdmCausesData-Offset Order");
		p3.setLabel(CapacityCausesEnum.Offset_Order.toString());
		p3.setColor(CapacityCausesEnum.Offset_Order.getColor());
		// p3.setValue(odmMap.get(ODMCausesEnum.Offset_Order.toString()));
		p3.setValue(String.valueOf(totalQuantityOrderOFFSET));

		List<CausesByForecast> odmCausesByForecastUPSIDEList = new ArrayList<CausesByForecast>();
		forecastDataList = tTVOutlookServiceBiHelper
				.getCausedForecastDataByProduct(String.valueOf(productId),
						targetDate, versionDate,
						ForecastComparisonTypeEnum.UPSIDE);
		odmCausesByForecastUPSIDEList = tTVOutlookServiceDwHelper
				.getCauseForecastDetail(targetDate, versionDate,
						forecastDataList);
		for (CausesByForecast causesByForecast : odmCausesByForecastUPSIDEList) {
			totalQuantityForecastUPSIDE += Integer.parseInt(causesByForecast
					.getQuantity());
		}

		PieSlice p4 = new PieSlice();
		p4.setLink("j-showOdmCausesData-Upside Forecast");
		p4.setLabel(CapacityCausesEnum.Upside_Forecast.toString());
		p4.setColor(CapacityCausesEnum.Upside_Forecast.getColor());
		// p4.setValue(odmMap.get(ODMCausesEnum.Upside_Forecast.toString()));
		p4.setValue(String.valueOf(totalQuantityForecastUPSIDE));

		List<CausesByOrder> odmCausesByOrderUPSIDEList = new ArrayList<CausesByOrder>();
		orderDataList = tTVOutlookServiceBiHelper.getCausedOrderByProduct(
				productId, versionDate, ForecastComparisonTypeEnum.UPSIDE);
		odmCausesByOrderUPSIDEList = tTVOutlookServiceDwHelper
				.getCauseOrderDetail(orderDataList);
		for (CausesByOrder causesByOrder : odmCausesByOrderUPSIDEList) {
			totalQuantityOrderUPSIDE += Integer.parseInt(causesByOrder
					.getQuantity());
		}

		PieSlice p5 = new PieSlice();
		p5.setLink("j-showOdmCausesData-Upside Order");
		p5.setLabel(CapacityCausesEnum.Upside_Order.toString());
		p5.setColor(CapacityCausesEnum.Upside_Order.getColor());
		// p5.setValue(odmMap.get(ODMCausesEnum.Upside_Order.toString()));
		p5.setValue(String.valueOf(totalQuantityOrderUPSIDE));

		List<TTVOutlookChartData> ttvOutlookChartDateList = tTVOutlookService
				.getChartData(waveId, startDate, endDate, form.getFrequency(),
						form.getFpy().equals("ODM") ? true : false,
						versionDate, false, false);
		if (ttvOutlookChartDateList != null
				&& ttvOutlookChartDateList.size() > 0) {
			p1.setValue(String.valueOf(ttvOutlookChartDateList.get(0)
					.getTotalGap()
					- Integer.parseInt(p2.getValue())
					- Integer.parseInt(p3.getValue())
					- Integer.parseInt(p4.getValue())
					- Integer.parseInt(p5.getValue())));
		}

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		list.add(p5);
		PieChartView pView = new PieChartView();
		pView.setElements(list);

		return pView;
	}

	public List<TtvGridOdmDetailsView> getOdmDetailsDataByWeek(
			SearchOutlookDataForm form, String isPreview,
			String selectedExcludeOrderIds) {

		List<TtvGridOdmDetailsView> odmDetailsViewList = new ArrayList<TtvGridOdmDetailsView>();
		// List<TtvGridOdmDetailsView> ttvGridDetractorCodeViewList =
		// npiOrderDaoDw.getDetractorCodeDataGrid(form);
		TtvGridOdmDetailsView ttvGridOdmDetailsView = new TtvGridOdmDetailsView();
		OrderRelative orderRelative = new OrderRelative();
		ForecastRelative forecastRelative = new ForecastRelative();
		List<OdmCapacityPlanDetail> odmCapacityPlanDetailList = new ArrayList<OdmCapacityPlanDetail>();
		// List<OdmCapacityPlan> odmCapacityPlanList = new
		// ArrayList<OdmCapacityPlan>();
		// List<TdmsDefect> tdmsDefectList = new ArrayList<TdmsDefect>();

		try {
			int pmsWaveId = form.getWaveId();
			Date targetDate = CalendarUtil
					.stringT2Date(form.getTtvTargetDate());
			Date versionDate = form.getVersionDate();
			String productId = productKeyPmsWaveIdMap
					.getProductKeyFromPmsWaveId(String.valueOf(pmsWaveId));

			// get odm Detail begin
			odmCapacityPlanDetailList = odmCapacityDao
					.getDetailCapacityPlanByTargetDate(pmsWaveId, targetDate,
							versionDate);
			// get odm Detail end
			float capacityFloat = 0;
			float totalCapacityFloat = 0;
			for (OdmCapacityPlanDetail odmCapacityPlanDetail : odmCapacityPlanDetailList) {

				// make data table begin
				ttvGridOdmDetailsView
						.setOdm(odmCapacityPlanDetail.getOdmName());
				ttvGridOdmDetailsView.setLine(odmCapacityPlanDetail.getLine());
				ttvGridOdmDetailsView.setCrew(odmCapacityPlanDetail.getCrew());
				ttvGridOdmDetailsView.setUph(String
						.valueOf(odmCapacityPlanDetail.getUnitsPerHour()));
				ttvGridOdmDetailsView.setHpd(String
						.valueOf(odmCapacityPlanDetail.getHoursPerDay()));
				ttvGridOdmDetailsView.setDpw(String
						.valueOf(odmCapacityPlanDetail.getDaysPerWeek()));
				ttvGridOdmDetailsView.setFpy(String
						.valueOf(odmCapacityPlanDetail.getFpy()));
				ttvGridOdmDetailsView.setRpyInclude(odmCapacityPlanDetail
						.isUseRpy() == true ? "Y" : "N");
				capacityFloat = odmCapacityPlanDetail.getUnitsPerHour()
						* odmCapacityPlanDetail.getHoursPerDay()
						* odmCapacityPlanDetail.getDaysPerWeek()
						* odmCapacityPlanDetail.getFpy();
				ttvGridOdmDetailsView
						.setCapacity(String.valueOf(capacityFloat));
				totalCapacityFloat += capacityFloat;

				// make data table end
			}

			ttvGridOdmDetailsView.setTotalCapacity(String
					.valueOf(totalCapacityFloat));

			// get order data begin
			List<NpiWeeklyComponentCommitmentOnOrder> orderOffsetDataList = tTVOutlookServiceBiHelper
					.getCausedOrderByProduct(String.valueOf(pmsWaveId),
							versionDate, ForecastComparisonTypeEnum.OFFSET);
			int sumOrderOffsetData = 0;
			for (NpiWeeklyComponentCommitmentOnOrder orderData : orderOffsetDataList) {
				sumOrderOffsetData = orderData.getQuantity();
			}
			orderRelative.setOffset(String.valueOf(sumOrderOffsetData));

			List<NpiWeeklyComponentCommitmentOnOrder> orderUpsideDataList = tTVOutlookServiceBiHelper
					.getCausedOrderByProduct(String.valueOf(pmsWaveId),
							versionDate, ForecastComparisonTypeEnum.UPSIDE);
			int sumOrderUpsideData = 0;
			for (NpiWeeklyComponentCommitmentOnOrder orderData : orderUpsideDataList) {
				sumOrderUpsideData = orderData.getQuantity();
			}
			orderRelative.setUpside(Integer.valueOf(sumOrderUpsideData)
					.toString());

			List<NpiWeeklyComponentCommitmentOnOrder> orderNormalDataList = tTVOutlookServiceBiHelper
					.getCausedOrderByProduct(String.valueOf(pmsWaveId),
							versionDate, ForecastComparisonTypeEnum.DOWNSIDE);
			int sumOrdeNormalData = 0;
			for (NpiWeeklyComponentCommitmentOnOrder orderData : orderNormalDataList) {
				sumOrdeNormalData = orderData.getQuantity();
			}
			orderRelative.setNormal(Integer.valueOf(sumOrdeNormalData)
					.toString());

			ttvGridOdmDetailsView.setOrderRelative(orderRelative);
			// get order data end

			// get forecast data begin
			List<NpiWeeklyComponentCommitmentOnForecast> forecastOffsetDataList = tTVOutlookServiceBiHelper
					.getCausedForecastDataByProduct(String.valueOf(productId),
							targetDate, versionDate,
							ForecastComparisonTypeEnum.OFFSET);
			int sumForecastOffsetData = 0;
			for (NpiWeeklyComponentCommitmentOnForecast forecastData : forecastOffsetDataList) {
				sumForecastOffsetData = forecastData.getQuantity();
			}
			forecastRelative.setOffset(Integer.valueOf(sumForecastOffsetData)
					.toString());

			List<NpiWeeklyComponentCommitmentOnForecast> forecastUpsideDataList = tTVOutlookServiceBiHelper
					.getCausedForecastDataByProduct(String.valueOf(productId),
							targetDate, versionDate,
							ForecastComparisonTypeEnum.UPSIDE);
			int sumForecastUpsideData = 0;
			for (NpiWeeklyComponentCommitmentOnForecast forecastData : forecastUpsideDataList) {
				sumForecastUpsideData = forecastData.getQuantity();
			}
			forecastRelative.setUpside(Integer.valueOf(sumForecastUpsideData)
					.toString());

			List<NpiWeeklyComponentCommitmentOnForecast> forecastNormalDataList = tTVOutlookServiceBiHelper
					.getCausedForecastDataByProduct(String.valueOf(productId),
							targetDate, versionDate,
							ForecastComparisonTypeEnum.DOWNSIDE);
			int sumForecastNormalData = 0;
			for (NpiWeeklyComponentCommitmentOnForecast forecastData : forecastNormalDataList) {
				sumForecastNormalData = forecastData.getQuantity();
			}
			forecastRelative.setNormal(Integer.valueOf(sumForecastNormalData)
					.toString());
			// get forecast data end

			ttvGridOdmDetailsView.setForecastRelative(forecastRelative);

		} catch (Exception e) {
			e.printStackTrace();
		}

		odmDetailsViewList.add(ttvGridOdmDetailsView);
		return odmDetailsViewList;
	}

	public List<Defect> getOdmDefectsByWeek(SearchOutlookDataForm form,
			String isPreview, String selectedExcludeOrderIds)
			throws ParseException {

		List<Defect> defectsList = new ArrayList<Defect>();
		defectsList = npiOrderDaoDw.getDefectsList(form);

		return defectsList;
	}

	public TtvGridCapacityCausesView getOdmCausesByWeek(
			SearchOutlookDataForm form) {
		TtvGridCapacityCausesView ttvGridOdmCausesView = new TtvGridCapacityCausesView();

		// List<TTVOutlookCause> ttvOutlookCauseList =
		// tTVOutlookService.getCause(waveId, startDate, timeFrequency, odmFpy);
		List<CausesByOrder> odmCausesByOrderOFFSETList = new ArrayList<CausesByOrder>();
		List<CausesByOrder> odmCausesByOrderUPSIDEList = new ArrayList<CausesByOrder>();
		List<CausesByForecast> odmCausesByForecastUPSIDEList = new ArrayList<CausesByForecast>();
		List<CausesByForecast> odmCausesByForecastOFFSETList = new ArrayList<CausesByForecast>();

		List<CausesByOrder> odmCausesByOrderList = new ArrayList<CausesByOrder>();
		List<CausesByForecast> odmCausesByForecastList = new ArrayList<CausesByForecast>();
		List<NpiWeeklyComponentCommitmentOnOrder> orderDataOFFSETList = new ArrayList<NpiWeeklyComponentCommitmentOnOrder>();
		List<NpiWeeklyComponentCommitmentOnOrder> orderDataUPSIDEList = new ArrayList<NpiWeeklyComponentCommitmentOnOrder>();
		List<NpiWeeklyComponentCommitmentOnForecast> forecastDataOFFSETList = new ArrayList<NpiWeeklyComponentCommitmentOnForecast>();
		List<NpiWeeklyComponentCommitmentOnForecast> forecastDataUPSIDEList = new ArrayList<NpiWeeklyComponentCommitmentOnForecast>();
		Date versionDate = null;
		Date targetDate = null;
		// get order data begin
		String productId = productKeyPmsWaveIdMap
				.getProductKeyFromPmsWaveId(String.valueOf(form.getWaveId()));
		try {
			versionDate = form.getVersionDate();
			targetDate = CalendarUtil.stringT2Date(form.getTtvTargetDate());
			if (" ".equals(form.getParentType())
					|| form.getParentType().equals("Offset Order")) {
				orderDataOFFSETList = tTVOutlookServiceBiHelper
						.getCausedOrderByProduct(
								String.valueOf(form.getWaveId()),
								form.getVersionDate(),
								ForecastComparisonTypeEnum.OFFSET);
				if (orderDataOFFSETList != null) {
					odmCausesByOrderOFFSETList = tTVOutlookServiceDwHelper
							.getCauseOrderDetail(orderDataOFFSETList);
				}
			}
			if (" ".equals(form.getParentType())
					|| form.getParentType().equals("Upside Order")) {
				orderDataUPSIDEList = tTVOutlookServiceBiHelper
						.getCausedOrderByProduct(
								String.valueOf(form.getWaveId()),
								form.getVersionDate(),
								ForecastComparisonTypeEnum.UPSIDE);
				if (orderDataUPSIDEList != null) {
					odmCausesByOrderUPSIDEList = tTVOutlookServiceDwHelper
							.getCauseOrderDetail(orderDataUPSIDEList);
				}
			}
			odmCausesByOrderList.addAll(odmCausesByOrderUPSIDEList);
			odmCausesByOrderList.addAll(odmCausesByOrderOFFSETList);
			// get order data end

			// get forecast data begin

			if (" ".equals(form.getParentType())
					|| form.getParentType().equals("Offset Forecast")) {
				forecastDataOFFSETList = tTVOutlookServiceBiHelper
						.getCausedForecastDataByProduct(String.valueOf(form
								.getWaveId()), CalendarUtil.stringT2Date(form
								.getTtvTargetDate()), form.getVersionDate(),
								ForecastComparisonTypeEnum.OFFSET);
				if (odmCausesByForecastOFFSETList != null) {
					odmCausesByForecastOFFSETList = tTVOutlookServiceDwHelper
							.getCauseForecastDetail(targetDate, versionDate,
									forecastDataOFFSETList);
				}
			}

			if (" ".equals(form.getParentType())
					|| form.getParentType().equals("Upside Forecast")) {
				forecastDataUPSIDEList = tTVOutlookServiceBiHelper
						.getCausedForecastDataByProduct(
								String.valueOf(form.getWaveId()), targetDate,
								versionDate, ForecastComparisonTypeEnum.UPSIDE);
				if (odmCausesByForecastUPSIDEList != null) {
					odmCausesByForecastUPSIDEList = tTVOutlookServiceDwHelper
							.getCauseForecastDetail(targetDate, versionDate,
									forecastDataUPSIDEList);
				}
			}

			odmCausesByForecastList.addAll(odmCausesByForecastOFFSETList);
			odmCausesByForecastList.addAll(odmCausesByForecastUPSIDEList);

			// get forecast data end
		} catch (Exception e) {
			e.printStackTrace();
		}

		ttvGridOdmCausesView.setOrderList(odmCausesByOrderList);
		ttvGridOdmCausesView.setForecastList(odmCausesByForecastList);

		return ttvGridOdmCausesView;
	}

	@Override
	public ProjectOutLookView getSupplyMaterialShortage(ProductWave proWave)
			throws ParseException {
		return getProjecteView(proWave);
	}

	public ColumnChartView getSupplyDetailColumnDataByWeekly(
			SearchOutlookDataForm form, String isPreview,
			String selectedExcludeOrderIds) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();
		Date startDate = form.getStartDate();
		Date endDate = form.getEndDate();
		String currentModay = null;
		boolean odmFpy = false;
		int waveId = form.getWaveId();
		List<TTVOutlookChartData> tTVOutlookChartDataList = null;
		Date versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil
				.getTodayWithoutMins());
		/*
		 * if("true".equals(isPreview)){ List<NpiOrder> excludedOrders = new
		 * ArrayList<NpiOrder>();
		 * 
		 * NpiOrder npiOrder = new NpiOrder();
		 * 
		 * tTVOutlookChartDataList = tTVOutlookService.previewChartData(waveId,
		 * startDate, endDate, TimeFrequencyEnum.DAILY, odmFpy, excludedOrders);
		 * }else{ //fetch data by calling tTVOutlookService interface
		 * tTVOutlookChartDataList = tTVOutlookService.getChartData(waveId,
		 * startDate, endDate, TimeFrequencyEnum.WEEKLY, odmFpy); }
		 */

		// fetch data by calling tTVOutlookService interface
		tTVOutlookChartDataList = tTVOutlookService.getChartData(waveId,
				startDate, endDate, TimeFrequencyEnum.WEEKLY, odmFpy,
				versionDate, false, false);

		// categories
		boolean flag = false;
		currentModay = CalendarUtil.date2String(CalendarUtil
				.getMondayDateByDate(Calendar.getInstance().getTime()));
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		int count = masterDataService.getThresholdByName(
				Threshold.TTV_OUTLOOK_DURATION.name()).intValue();
		for (int i = 0; i <= count; i++) {
			String startDateMonday = CalendarUtil.date2String(CalendarUtil
					.getMondayDateByWeeks(form.getStartDate(), i));
			if (flag) {
				if (currentModay.compareTo(startDateMonday) <= 0) {
					Vline vline = new Vline();
					vline.setLabel("Current Week");
					vline.setVline("true");
					vline.setLabelPosition("0");
					categoryList.add(i, vline);
				}
			}
			if (currentModay.compareTo(startDateMonday) > 0) {
				flag = true;
			} else
				flag = false;
			LabelCategory category = new LabelCategory();
			category.setName(startDateMonday);
			categoryList.add(category);
		}

		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		// dataset
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();

		// Demand
		DataSetColumn demandDataSet = new DataSetColumn();
		demandDataSet.setSeriesName("Demand");
		List<ColumnData> demandCloumnDataList = new ArrayList<ColumnData>();

		// Shipment or Supply Capacity
		DataSetColumn shipmentDataSet = new DataSetColumn();
		shipmentDataSet.setSeriesName("Shipment");
		List<ColumnData> shipmentCloumnDataList = new ArrayList<ColumnData>();
		DataSetColumn capacityDataSet = new DataSetColumn();
		capacityDataSet.setSeriesName("Supply Capacity");
		List<ColumnData> capacityCloumnDataList = new ArrayList<ColumnData>();

		// TTV Supply Gap
		DataSetColumn ttlGapDataSet = new DataSetColumn();
		ttlGapDataSet.setSeriesName("TTV Supply Gap");
		List<ColumnData> ttlGapCloumnDataList = new ArrayList<ColumnData>();

		// Actual TTV or Estimated TTV
		DataSetLine ttvDataSet = new DataSetLine();
		ttvDataSet.setSeriesName("TTV");
		ttvDataSet.setParentYaxis("S");
		ttvDataSet.setRenderas("Line");
		ttvDataSet.setColor("FF0000");// Ã§ÂºÂ¢Ã¨â€°Â²
		List<ColumnData> ttvDataList = new ArrayList<ColumnData>();

		// Target
		DataSetLine targetDataSet = new DataSetLine();
		targetDataSet.setSeriesName("TTV Target");
		targetDataSet.setParentYaxis("S");
		targetDataSet.setRenderas("Line");
		targetDataSet.setColor("black");// Ã©Â»â€˜Ã¨â€°Â²
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();

		for (int i = 0; i < tTVOutlookChartDataList.size(); i++) {
			TTVOutlookChartData tTVOutlookChartData = tTVOutlookChartDataList
					.get(i);
			String trackingCausesMonday = null;
			String trackingCausesSunday = null;
			trackingCausesMonday = CalendarUtil.getDateByDays(startDate, 7 * i);
			trackingCausesSunday = CalendarUtil.getDateByDays(
					CalendarUtil.stringT2Date(trackingCausesMonday), 6);

			// Demand
			String thisMonday = null;
			thisMonday = CalendarUtil.getDateByDays(startDate, 7 * i);

			ColumnData demand = new ColumnData();
			setCapacityWeeklyColumnLink(demand, thisMonday, currentModay,
					trackingCausesMonday, trackingCausesSunday, form.getFpy());
			demand.setValue(tTVOutlookChartData.getFutureOrder());
			// demand.setColor("006699");//Ã¨â€œÂ�Ã¨â€°Â²
			demandCloumnDataList.add(i, demand);

			// Shipment or ODM Capacity
			if (thisMonday.compareTo(currentModay) < 0) {
				ColumnData shipment = new ColumnData();
				setOutlookWeeklyColumnLink(shipment, thisMonday, currentModay,
						trackingCausesMonday, trackingCausesSunday);
				shipment.setValue(tTVOutlookChartData.getShipment());
				// estimatedCapacity.setColor("66cc66");//Ã§Â»Â¿Ã¨â€°Â²
				shipmentCloumnDataList.add(i, shipment);
				capacityCloumnDataList.add(i, null);
			} else {
				ColumnData estimatedCapacity = new ColumnData();
				setCapacityWeeklyColumnLink(estimatedCapacity, thisMonday,
						currentModay, trackingCausesMonday,
						trackingCausesSunday, form.getFpy());
				estimatedCapacity.setValue(tTVOutlookChartData.getCapacity());
				// shipment.setColor("ffcc66");//Ã©Â»â€žÃ¨â€°Â²
				capacityCloumnDataList.add(i, estimatedCapacity);
			}

			// TTV Supply Gap
			ColumnData tTLGap = new ColumnData();
			tTLGap.setValue(-tTVOutlookChartData.getTotalGap());
			tTLGap.setColor("FF0000");// Ã§ÂºÂ¢Ã¨â€°Â²
			setCapacityWeeklyColumnLink(tTLGap, thisMonday, currentModay,
					trackingCausesMonday, trackingCausesSunday, form.getFpy());
			ttlGapCloumnDataList.add(tTLGap);

			// Actual TTV or Estimated TTV
			ColumnData ttv = new ColumnData();
			ttv.setValue(tTVOutlookChartData.getTtv());
			ttv.setColor("");
			ttvDataList.add(ttv);

			// Target
			ColumnData target = new ColumnData();
			target.setValue(92);
			targetCloumnDataList.add(target);
		}
		demandDataSet.setDataList(demandCloumnDataList);
		dataSetList.add(demandDataSet);

		shipmentDataSet.setDataList(shipmentCloumnDataList);
		capacityDataSet.setDataList(capacityCloumnDataList);
		dataSetList.add(shipmentDataSet);
		dataSetList.add(capacityDataSet);

		ttlGapDataSet.setDataList(ttlGapCloumnDataList);
		dataSetList.add(ttlGapDataSet);

		ttvDataSet.setDataList(ttvDataList);
		dataSetList.add(ttvDataSet);

		targetDataSet.setDataList(targetCloumnDataList);
		dataSetList.add(targetDataSet);

		columnChartView.setDataSetList(dataSetList);

		return columnChartView;
	}

	public PieChartView getSupplyMainPieChart(SearchOutlookDataForm form) {

		List<PieDivider> detractorDividerList = npiOrderDaoDw
				.getDetractorMainDivider(form);
		Map<String, String> odmMap = new HashMap<String, String>();

		for (PieDivider detractorDivider : detractorDividerList) {
			odmMap.put(detractorDivider.getLevel1Name(),
					detractorDivider.getLevel1Num() + "");
		}

		PieSlice p1 = new PieSlice();
		p1.setLink("j-showCLevelAndCausesData-Supply Capacity");
		p1.setLabel(CapacityCausesEnum.Supply_Capacity.toString());
		p1.setColor(CapacityCausesEnum.Supply_Capacity.getColor());
		// p1.setValue(odmMap.get(ODMCausesEnum.ODM_Capacity.toString()));
		p1.setValue("1");

		PieSlice p2 = new PieSlice();
		p2.setLink("j-showCLevelAndCausesData-Offset Forecast");
		p2.setLabel(CapacityCausesEnum.Offset_Forecast.toString());
		p2.setColor(CapacityCausesEnum.Offset_Forecast.getColor());
		// p2.setValue(odmMap.get(ODMCausesEnum.Offset_Forecast.toString()));
		p2.setValue("2");

		PieSlice p3 = new PieSlice();
		p3.setLink("j-showCLevelAndCausesData-Offset Order");
		p3.setLabel(CapacityCausesEnum.Offset_Order.toString());
		p3.setColor(CapacityCausesEnum.Offset_Order.getColor());
		// p3.setValue(odmMap.get(ODMCausesEnum.Offset_Order.toString()));
		p3.setValue("3");

		PieSlice p4 = new PieSlice();
		p4.setLink("j-showCLevelAndCausesData-Upside Forecast");
		p4.setLabel(CapacityCausesEnum.Upside_Forecast.toString());
		p4.setColor(CapacityCausesEnum.Upside_Forecast.getColor());
		// p4.setValue(odmMap.get(ODMCausesEnum.Upside_Forecast.toString()));
		p4.setValue("4");

		PieSlice p5 = new PieSlice();
		p5.setLink("j-showCLevelAndCausesData-Upside Order");
		p5.setLabel(CapacityCausesEnum.Upside_Order.toString());
		p5.setColor(CapacityCausesEnum.Upside_Order.getColor());
		// p5.setValue(odmMap.get(ODMCausesEnum.Upside_Order.toString()));
		p5.setValue("5");

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		list.add(p5);
		PieChartView pView = new PieChartView();
		pView.setElements(list);

		return pView;
	}

	public PieChartView getSupplyCLevelPieChart(SearchOutlookDataForm form) {

		List<PieDivider> detractorDividerList = npiOrderDaoDw
				.getDetractorMainDivider(form);
		Map<String, String> odmMap = new HashMap<String, String>();

		for (PieDivider detractorDivider : detractorDividerList) {
			odmMap.put(detractorDivider.getLevel1Name(),
					detractorDivider.getLevel1Num() + "");
		}

		PieSlice p1 = new PieSlice();
		p1.setLink("j-showVLevelAndCausesData-Supply Capacity");
		p1.setLabel(CLevelEnum.CPU.toString());
		p1.setColor(CLevelEnum.CPU.getColor());
		// p1.setValue(odmMap.get(ODMCausesEnum.ODM_Capacity.toString()));
		p1.setValue("1");

		PieSlice p2 = new PieSlice();
		p2.setLink("j-showVLevelAndCausesData-Offset Forecast");
		p2.setLabel(CLevelEnum.HD.toString());
		p2.setColor(CLevelEnum.HD.getColor());
		// p2.setValue(odmMap.get(ODMCausesEnum.Offset_Forecast.toString()));
		p2.setValue("2");

		PieSlice p3 = new PieSlice();
		p3.setLink("j-showVLevelAndCausesData-Offset Order");
		p3.setLabel(CLevelEnum.MEM.toString());
		p3.setColor(CLevelEnum.MEM.getColor());
		// p3.setValue(odmMap.get(ODMCausesEnum.Offset_Order.toString()));
		p3.setValue("3");

		PieSlice p4 = new PieSlice();
		p4.setLink("j-showVLevelAndCausesData-Upside Forecast");
		p4.setLabel(CLevelEnum.VGA.toString());
		p4.setColor(CLevelEnum.VGA.getColor());
		// p4.setValue(odmMap.get(ODMCausesEnum.Upside_Forecast.toString()));
		p4.setValue("4");

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		PieChartView pView = new PieChartView();
		pView.setElements(list);

		return pView;
	}

	public PieChartView getSupplyVLevelPieChart(SearchOutlookDataForm form) {

		List<PieDivider> detractorDividerList = npiOrderDaoDw
				.getDetractorMainDivider(form);
		Map<String, String> odmMap = new HashMap<String, String>();

		for (PieDivider detractorDivider : detractorDividerList) {
			odmMap.put(detractorDivider.getLevel1Name(),
					detractorDivider.getLevel1Num() + "");
		}

		PieSlice p1 = new PieSlice();
		p1.setLink("j-showCausesDataFromVLevel-Supply Capacity");
		p1.setLabel(VLevelEnum.Intel_i5.toString());
		p1.setColor(VLevelEnum.Intel_i5.getColor());
		// p1.setValue(odmMap.get(ODMCausesEnum.ODM_Capacity.toString()));
		p1.setValue("1");

		PieSlice p2 = new PieSlice();
		p2.setLink("j-showCausesDataFromVLevel-Offset Forecast");
		p2.setLabel(VLevelEnum.Intel_i6.toString());
		p2.setColor(VLevelEnum.Intel_i6.getColor());
		// p2.setValue(odmMap.get(ODMCausesEnum.Offset_Forecast.toString()));
		p2.setValue("2");

		PieSlice p3 = new PieSlice();
		p3.setLink("j-showCausesDataFromVLevel-Offset Order");
		p3.setLabel(VLevelEnum.Intel_i7.toString());
		p3.setColor(VLevelEnum.Intel_i7.getColor());
		// p3.setValue(odmMap.get(ODMCausesEnum.Offset_Order.toString()));
		p3.setValue("3");

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);
		PieChartView pView = new PieChartView();
		pView.setElements(list);

		return pView;
	}

	public List<TtvGridSupplyDetailsView> getSupplyDetailsDataByWeek(
			SearchOutlookDataForm form, String isPreview,
			String selectedExcludeOrderIds) {

		List<TtvGridSupplyDetailsView> supplyDetailsViewList = new ArrayList<TtvGridSupplyDetailsView>();
		// List<TtvGridOdmDetailsView> ttvGridDetractorCodeViewList =
		// npiOrderDaoDw.getDetractorCodeDataGrid(form);

		return supplyDetailsViewList;
	}

	public TtvGridCapacityCausesView getSupplyCausesByWeek(
			SearchOutlookDataForm form) {
		TtvGridCapacityCausesView ttvGridOdmCausesView = new TtvGridCapacityCausesView();

		// List<TTVOutlookCause> ttvOutlookCauseList =
		// tTVOutlookService.getCause(waveId, startDate, timeFrequency, odmFpy);
		List<CausesByOrder> orderList = new ArrayList<CausesByOrder>();
		CausesByOrder odmCausesByOrder = new CausesByOrder();

		orderList.add(odmCausesByOrder);

		List<CausesByForecast> forecastList = new ArrayList<CausesByForecast>();
		CausesByForecast odmCausesByForecast = new CausesByForecast();

		forecastList.add(odmCausesByForecast);

		ttvGridOdmCausesView.setOrderList(orderList);
		ttvGridOdmCausesView.setForecastList(forecastList);

		return ttvGridOdmCausesView;
	}

	@Override
	public ProjectOutLookView getToolingCapacity(ProductWave proWave)
			throws ParseException {
		return getProjecteView(proWave);
	}

	public ColumnChartView getToolingDetailColumnDataByWeekly(
			SearchOutlookDataForm form, String isPreview,
			String selectedExcludeOrderIds) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();
		Date startDate = form.getStartDate();
		Date endDate = form.getEndDate();
		String currentModay = null;
		boolean fpy = false;
		int waveId = form.getWaveId();
		List<TTVOutlookChartData> tTVOutlookChartDataList = null;
		Date versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil
				.getTodayWithoutMins());
		/*
		 * if("true".equals(isPreview)){ List<NpiOrder> excludedOrders = new
		 * ArrayList<NpiOrder>();
		 * 
		 * NpiOrder npiOrder = new NpiOrder();
		 * 
		 * tTVOutlookChartDataList = tTVOutlookService.previewChartData(waveId,
		 * startDate, endDate, TimeFrequencyEnum.DAILY, odmFpy, excludedOrders);
		 * }else{ //fetch data by calling tTVOutlookService interface
		 * tTVOutlookChartDataList = tTVOutlookService.getChartData(waveId,
		 * startDate, endDate, TimeFrequencyEnum.WEEKLY, odmFpy); }
		 */

		// fetch data by calling tTVOutlookService interface
		tTVOutlookChartDataList = tTVOutlookService.getChartData(waveId,
				startDate, endDate, TimeFrequencyEnum.WEEKLY, fpy, versionDate,
				false, false);

		// categories
		boolean flag = false;
		currentModay = CalendarUtil.date2String(CalendarUtil
				.getMondayDateByDate(Calendar.getInstance().getTime()));
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		int count = masterDataService.getThresholdByName(
				Threshold.TTV_OUTLOOK_DURATION.name()).intValue();
		for (int i = 0; i <= count; i++) {
			String startDateMonday = CalendarUtil.date2String(CalendarUtil
					.getMondayDateByWeeks(form.getStartDate(), i));
			if (flag) {
				if (currentModay.compareTo(startDateMonday) <= 0) {
					Vline vline = new Vline();
					vline.setLabel("Current Week");
					vline.setVline("true");
					vline.setLabelPosition("0");
					categoryList.add(i, vline);
				}
			}
			if (currentModay.compareTo(startDateMonday) > 0) {
				flag = true;
			} else
				flag = false;
			LabelCategory category = new LabelCategory();
			category.setName(startDateMonday);
			categoryList.add(category);
		}

		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		// dataset
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();

		// Demand
		DataSetColumn demandDataSet = new DataSetColumn();
		demandDataSet.setSeriesName("Demand");
		List<ColumnData> demandCloumnDataList = new ArrayList<ColumnData>();

		// Shipment or Tooling Capacity
		DataSetColumn shipmentDataSet = new DataSetColumn();
		shipmentDataSet.setSeriesName("Shipment");
		List<ColumnData> shipmentCloumnDataList = new ArrayList<ColumnData>();
		DataSetColumn capacityDataSet = new DataSetColumn();
		capacityDataSet.setSeriesName("Tooling Capacity");
		List<ColumnData> capacityCloumnDataList = new ArrayList<ColumnData>();

		// TTV Tooling Gap
		DataSetColumn ttlGapDataSet = new DataSetColumn();
		ttlGapDataSet.setSeriesName("TTV Tooling Gap");
		List<ColumnData> ttlGapCloumnDataList = new ArrayList<ColumnData>();

		// Actual TTV or Estimated TTV
		DataSetLine ttvDataSet = new DataSetLine();
		ttvDataSet.setSeriesName("TTV");
		ttvDataSet.setParentYaxis("S");
		ttvDataSet.setRenderas("Line");
		ttvDataSet.setColor("FF0000");// Ã§ÂºÂ¢Ã¨â€°Â²
		List<ColumnData> ttvDataList = new ArrayList<ColumnData>();

		// Target
		DataSetLine targetDataSet = new DataSetLine();
		targetDataSet.setSeriesName("TTV Target");
		targetDataSet.setParentYaxis("S");
		targetDataSet.setRenderas("Line");
		targetDataSet.setColor("black");// Ã©Â»â€˜Ã¨â€°Â²
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();

		for (int i = 0; i < tTVOutlookChartDataList.size(); i++) {
			TTVOutlookChartData tTVOutlookChartData = tTVOutlookChartDataList
					.get(i);
			String trackingCausesMonday = null;
			String trackingCausesSunday = null;
			trackingCausesMonday = CalendarUtil.getDateByDays(startDate, 7 * i);
			trackingCausesSunday = CalendarUtil.getDateByDays(
					CalendarUtil.stringT2Date(trackingCausesMonday), 6);

			// Demand
			String thisMonday = null;
			thisMonday = CalendarUtil.getDateByDays(startDate, 7 * i);

			ColumnData demand = new ColumnData();
			setCapacityWeeklyColumnLink(demand, thisMonday, currentModay,
					trackingCausesMonday, trackingCausesSunday, form.getFpy());
			demand.setValue(tTVOutlookChartData.getFutureOrder());
			// demand.setColor("006699");//Ã¨â€œÂ�Ã¨â€°Â²
			demandCloumnDataList.add(i, demand);

			// Shipment or ODM Capacity
			if (thisMonday.compareTo(currentModay) < 0) {
				ColumnData shipment = new ColumnData();
				setOutlookWeeklyColumnLink(shipment, thisMonday, currentModay,
						trackingCausesMonday, trackingCausesSunday);
				shipment.setValue(tTVOutlookChartData.getShipment());
				// estimatedCapacity.setColor("66cc66");//Ã§Â»Â¿Ã¨â€°Â²
				shipmentCloumnDataList.add(i, shipment);
				capacityCloumnDataList.add(i, null);
			} else {
				ColumnData estimatedCapacity = new ColumnData();
				setCapacityWeeklyColumnLink(estimatedCapacity, thisMonday,
						currentModay, trackingCausesMonday,
						trackingCausesSunday, form.getFpy());
				estimatedCapacity.setValue(tTVOutlookChartData.getCapacity());
				// shipment.setColor("ffcc66");//Ã©Â»â€žÃ¨â€°Â²
				capacityCloumnDataList.add(i, estimatedCapacity);
			}

			// TTV Tooling Gap
			ColumnData tTLGap = new ColumnData();
			tTLGap.setValue(-tTVOutlookChartData.getTotalGap());
			tTLGap.setColor("FF0000");// Ã§ÂºÂ¢Ã¨â€°Â²
			setCapacityWeeklyColumnLink(tTLGap, thisMonday, currentModay,
					trackingCausesMonday, trackingCausesSunday, form.getFpy());
			ttlGapCloumnDataList.add(tTLGap);

			// Actual TTV or Estimated TTV
			ColumnData ttv = new ColumnData();
			ttv.setValue(tTVOutlookChartData.getTtv());
			ttv.setColor("");
			ttvDataList.add(ttv);

			// Target
			ColumnData target = new ColumnData();
			target.setValue(92);
			targetCloumnDataList.add(target);
		}
		demandDataSet.setDataList(demandCloumnDataList);
		dataSetList.add(demandDataSet);

		shipmentDataSet.setDataList(shipmentCloumnDataList);
		capacityDataSet.setDataList(capacityCloumnDataList);
		dataSetList.add(shipmentDataSet);
		dataSetList.add(capacityDataSet);

		ttlGapDataSet.setDataList(ttlGapCloumnDataList);
		dataSetList.add(ttlGapDataSet);

		ttvDataSet.setDataList(ttvDataList);
		dataSetList.add(ttvDataSet);

		targetDataSet.setDataList(targetCloumnDataList);
		dataSetList.add(targetDataSet);

		columnChartView.setDataSetList(dataSetList);

		return columnChartView;
	}

	public PieChartView getToolingMainPieChart(SearchOutlookDataForm form) {

		List<PieDivider> detractorDividerList = npiOrderDaoDw
				.getDetractorMainDivider(form);
		Map<String, String> map = new HashMap<String, String>();

		for (PieDivider detractorDivider : detractorDividerList) {
			map.put(detractorDivider.getLevel1Name(),
					detractorDivider.getLevel1Num() + "");
		}

		PieSlice p1 = new PieSlice();
		p1.setLink("j-showToolingCausesData-Tooling Capacity");
		p1.setLabel(CapacityCausesEnum.Tooling_Capacity.toString());
		p1.setColor(CapacityCausesEnum.Tooling_Capacity.getColor());
		// p1.setValue(map.get(ODMCausesEnum.Tooling_Capacity.toString()));
		p1.setValue("1");

		PieSlice p2 = new PieSlice();
		p2.setLink("j-showToolingCausesData-Offset Forecast");
		p2.setLabel(CapacityCausesEnum.Offset_Forecast.toString());
		p2.setColor(CapacityCausesEnum.Offset_Forecast.getColor());
		// p2.setValue(map.get(ODMCausesEnum.Offset_Forecast.toString()));
		p2.setValue("2");

		PieSlice p3 = new PieSlice();
		p3.setLink("j-showToolingCausesData-Offset Order");
		p3.setLabel(CapacityCausesEnum.Offset_Order.toString());
		p3.setColor(CapacityCausesEnum.Offset_Order.getColor());
		// p3.setValue(map.get(ODMCausesEnum.Offset_Order.toString()));
		p3.setValue("3");

		PieSlice p4 = new PieSlice();
		p4.setLink("j-showToolingCausesData-Upside Forecast");
		p4.setLabel(CapacityCausesEnum.Upside_Forecast.toString());
		p4.setColor(CapacityCausesEnum.Upside_Forecast.getColor());
		// p4.setValue(map.get(ODMCausesEnum.Upside_Forecast.toString()));
		p4.setValue("4");

		PieSlice p5 = new PieSlice();
		p5.setLink("j-showToolingCausesData-Upside Order");
		p5.setLabel(CapacityCausesEnum.Upside_Order.toString());
		p5.setColor(CapacityCausesEnum.Upside_Order.getColor());
		// p5.setValue(map.get(ODMCausesEnum.Upside_Order.toString()));
		p5.setValue("5");

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		list.add(p5);
		PieChartView pView = new PieChartView();
		pView.setElements(list);

		return pView;
	}

	public String getCoverName(int i) {
		if (i == 0)
			return "A";
		else if (i == 1)
			return "B";
		else if (i == 2)
			return "C";
		else
			return "D";
	}

	public ColumnChartView getToolingColumnChartByCover(
			SearchOutlookDataForm form) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();
		// Date startDate = form.getStartDate();
		// Date endDate = form.getEndDate();
		// int waveId = form.getWaveId();

		// categories
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		for (int i = 0; i < 4; i++) {
			LabelCategory category = new LabelCategory();
			category.setName(getCoverName(i));
			categoryList.add(category);
		}

		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		// dataset
		// Demand
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();
		DataSetColumn demandDataSet = new DataSetColumn();
		List<ColumnData> demandCloumnDataList = new ArrayList<ColumnData>();
		demandDataSet.setSeriesName("Demand");
		for (int i = 0; i < 4; i++) {
			ColumnData demandCloumnData = new ColumnData();
			demandCloumnData.setValue(5000 + i * 100);
			demandCloumnData.setColor("00CCFF");// Ã¨â€œÂ�Ã¨â€°Â²
			demandCloumnDataList.add(demandCloumnData);
		}
		demandDataSet.setDataList(demandCloumnDataList);
		dataSetList.add(demandDataSet);

		// Capacity
		DataSetColumn capacityDataSet = new DataSetColumn();
		capacityDataSet.setSeriesName("Capacity");
		List<ColumnData> capacityCloumnDataList = new ArrayList<ColumnData>();
		for (int i = 0; i < 4; i++) {
			ColumnData capacityCloumnData = new ColumnData();
			capacityCloumnData.setValue(6000 + i * 100);
			capacityCloumnData.setColor("FFCC66");// Ã¦Â¡â€�Ã©Â»â€ž
			capacityCloumnDataList.add(capacityCloumnData);
		}
		capacityDataSet.setDataList(capacityCloumnDataList);
		dataSetList.add(capacityDataSet);

		// Gap
		DataSetColumn gapDataSet = new DataSetColumn();
		gapDataSet.setSeriesName("Gap");
		List<ColumnData> gapCloumnDataList = new ArrayList<ColumnData>();
		for (int i = 0; i < 4; i++) {
			if (i == 3) {
				ColumnData gapCloumnData = new ColumnData();
				gapCloumnData.setValue(-2000);
				gapCloumnData.setColor("CC0000");// Ã§ÂºÂ¢Ã¨â€°Â²
				gapCloumnDataList.add(gapCloumnData);
			} else
				gapCloumnDataList.add(null);
		}
		gapDataSet.setDataList(gapCloumnDataList);
		dataSetList.add(gapDataSet);

		columnChartView.setDataSetList(dataSetList);

		return columnChartView;
	}

	public List<TtvGridToolingDetailsView> getToolingDetailsDataByWeek(
			SearchOutlookDataForm form, String isPreview,
			String selectedExcludeOrderIds) {

		List<TtvGridToolingDetailsView> detailsViewList = new ArrayList<TtvGridToolingDetailsView>();
		// List<TtvGridToolingDetailsView> ttvGridDetractorCodeViewList =
		// npiOrderDaoDw.getDetractorCodeDataGrid(form);

		return detailsViewList;
	}

	public TtvGridCapacityCausesView getToolingCausesByWeek(
			SearchOutlookDataForm form) {
		TtvGridCapacityCausesView ttvGridToolingCausesView = new TtvGridCapacityCausesView();

		// List<TTVOutlookCause> ttvOutlookCauseList =
		// tTVOutlookService.getCause(waveId, startDate, timeFrequency, fpy);
		List<CausesByOrder> orderList = new ArrayList<CausesByOrder>();
		CausesByOrder causesByOrder = new CausesByOrder();

		orderList.add(causesByOrder);

		List<CausesByForecast> forecastList = new ArrayList<CausesByForecast>();
		CausesByForecast causesByForecast = new CausesByForecast();

		forecastList.add(causesByForecast);

		ttvGridToolingCausesView.setOrderList(orderList);
		ttvGridToolingCausesView.setForecastList(forecastList);

		return ttvGridToolingCausesView;
	}

	@Override
	public ProjectOutLookView getProjectSnapshot(ProductWave proWave,
			Date versionDate) throws ParseException {
		return getProjecteView(proWave,
				CalendarUtil.getMondayDateByDate(versionDate));
	}

	@Override
	public TtvDetractorCodeView getDetractorCodeView(SearchOutlookDataForm form) {
		TtvDetractorCodeView view = new TtvDetractorCodeView();
		List<DimOrderForNPIExclude> dimOrders = null;
		List<Integer> waveIds = new ArrayList<Integer>();
		waveIds.add(form.getWaveId());
		List<ProjectSummary> projectList = nPIProductSummaryDao
				.getProductInfoByWaveId(waveIds, null);
		// ProjectSummary project = null;
		if (CollectionUtils.isEmpty(projectList)) {
			return null;
		} else {
			// project = projectList.get(0);
		}
		Date targetDate;
		if ("sga".equalsIgnoreCase(form.getSgaOrSle())) {
			targetDate = projectList.get(0).getSgaTtvTargetDate();
			dimOrders = npiOrderDaoDw.getSgaDimOrderByWaveIdInWeek(
					form.getWaveId(), form.getStartDate(), targetDate);
		} else {
			targetDate = projectList.get(0).getTtvTargetDate();
			dimOrders = npiOrderDaoDw.getSleDimOrderByWaveIdInWeek(
					form.getWaveId(), form.getStartDate(), null);
		}
		List<TtvGridDetractorCodeView> ttvGridDetractorCodeViewList = null;
		Map<String, String> detractorMap = new HashMap<String, String>();
		if (CollectionUtils.isNotEmpty(dimOrders)) {
			ttvGridDetractorCodeViewList = new ArrayList<TtvGridDetractorCodeView>();
			TtvGridDetractorCodeView detractorCode;
			for (DimOrderForNPIExclude order : dimOrders) {
				String level1 = null;
				String level2 = null;
				DimDetractor detracor = null;
				if (order.getDetractorKey() != null) {
					detracor = npiOrderDaoDw.getDetractorById(order
							.getDetractorKey());
				}
				if (detracor != null) {
					level1 = detracor.getLevel1();
					level2 = detracor.getLevel2();
				}
				boolean isValidated = true;

				if (StringUtils.isNotBlank(form.getChildType())
						&& !"all".equalsIgnoreCase(form.getChildType())) {
					if (!form.getChildType().equalsIgnoreCase(level2)) {
						isValidated = false;
					}
				} else {
					if (StringUtils.isNotBlank(form.getParentType())
							&& !"all".equalsIgnoreCase(form.getParentType())
							&& !form.getParentType().equalsIgnoreCase(level1)) {
						isValidated = false;
					}
				}
				if (isValidated) {
					detractorCode = new TtvGridDetractorCodeView();
					detractorCode.setLevel3(order.getLateReason2());
					DimODM odm = npiOrderDaoDw.getODMById(order.getOdmKey());
					if (odm != null) {
						detractorCode.setOdm(odm.getOdmEnglishName());
					}
					detractorCode.setOrderDate(order.getOrderDate());
					detractorCode.setOrderNo(order.getOrderNo());
					detractorCode.setPoItem(order.getPoItem());
					detractorCode.setPoNumber(order.getPoNumber());
					detractorCode.setProduct(projectList.get(0)
							.getProductName());
					detractorCode.setQty(order.getQuantity() != null ? String
							.valueOf(order.getQuantity()) : null);
					detractorCode.setRsd(order.getRsdDate());
					/*
					 * detractorCode.setShippedDate(order.getShipDate());
					 * detractorCode.setShipped(order.getShipDate() == null ?
					 * "N" : "Y");
					 */
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
					detractorCode.setFpsd(order.getFpsdDate() != null ? df
							.format(order.getFpsdDate()) : null);
					detractorCode.setTargetDate(targetDate);
					// defect no : 12358
					detractorCode.setFgDate(order.getFgDate());
					if (targetDate != null) {
						detractorCode.setTtvTargetDate(df.format(targetDate));
					}
					GeoData region = npiOrderDaoDw.getRegionById(order
							.getRegionKey());
					if (region != null) {
						detractorCode.setRegion(region.getGeographyName());
						GeoData geo = npiOrderDaoDw.getRegionById(Integer
								.parseInt(region.getParentGeo()));
						if (geo != null) {
							detractorCode.setGeo(geo.getGeographyName());
						}
					}
					DimMtm mtm = npiOrderDaoDw.getMtmById(order.getMtmKey());
					if (mtm != null) {
						detractorCode.setItemDesc(mtm
								.getMtmEnglishDescription());
						detractorCode.setItemNo(mtm.getMtmEnglishName());
						detractorCode.setPn(mtm.getBomNumberAlternateKey());
					}

					detractorCode
							.setLevel1(StringUtils.isBlank(level1) ? DetractorEnum.Unknown
									.toUpperCase() : level1);
					detractorCode
							.setLevel2(StringUtils.isBlank(level2) ? DetractorEnum.Unknown
									.toUpperCase() : level2);

					// detractorCode.setDetractorCode(null);
					detractorCode.setLevelC(null);
					detractorCode.setCountry(null);

					ttvGridDetractorCodeViewList.add(detractorCode);
					if ("mainPie".equals(form.getDetractorCodeType())
							|| "subPie".equals(form.getDetractorCodeType())) {
						String level = null;
						if ("mainPie".equals(form.getDetractorCodeType())) {
							level = detractorCode.getLevel1();
						} else {
							level = detractorCode.getLevel2();
						}

						if (detractorMap.get(level) == null) {
							detractorMap.put(level, "1");
						}
						int num = Integer.parseInt(detractorMap.get(level));
						detractorMap.put(level, String.valueOf(num + 1));
					}
				}
			}
		}
		PieChartView pView = null;
		if ("mainPie".equals(form.getDetractorCodeType())) {
			pView = this.getDetractorMainPieChart(detractorMap);
			pView.getChartInfo().setPieRadius("75");
		} else if ("subPie".equals(form.getDetractorCodeType())) {
			pView = getDetractorSubPieChart(detractorMap, form.getParentType());
			pView.getChartInfo().setPieRadius("70");
		}

		if (pView != null) {
			pView.getChartInfo().setLegendPosition("bottom");
			pView.getChartInfo().setManageLabelOverflow("1");
			pView.getChartInfo().setUseEllipsesWhenOverflow("1");
		}
		if (StringUtils.isNotBlank(form.getSortColumn())
				&& StringUtils.isNotBlank(form.getSortType())
				&& CollectionUtils.isNotEmpty(ttvGridDetractorCodeViewList)) {
			ListSortUtil.sort(ttvGridDetractorCodeViewList,
					form.getSortColumn(), form.getSortType());
		}
		view.setGrid(ttvGridDetractorCodeViewList);
		view.setChart(pView);
		return view;
	}

	@Override
	public MSColumnChartView getOutlookJsonChartDataByWeekly(
			SearchOutlookDataForm form, Boolean isPreview,
			List<NpiOrder> orders, boolean isSnapshot) throws ParseException {
		return this.getOutlookJsonChartDataByWeekly(form, isPreview, orders,
				isSnapshot, null);
	}

	@Override
	public MSColumnChartView getSgaOutlookJsonChartDataByWeekly(
			SearchOutlookDataForm form, Boolean isPreview,
			List<NpiOrder> orders, boolean isSnapshot,
			Map<String, NPISimulationPreviewData> previewDataMap)
			throws ParseException, BusinessException {

		boolean actualSgaFlag = true;
		// fetch wave info
		ProjectSummary ps = nPIProductSummaryDao.getProductInfoByWaveId(
				form.getWaveId(), form.getVersionDate());
		// process start date and end date
		if (form.getStartDate() == null) {
			if (ps.getSgaTtvTargetDate() == null) {
				return null;
			}
			Float startNum = masterDataService
					.getThresholdByName(Threshold.SGA_TTV_OUTLOOK_STARTDATE
							.name());
			Float endNum = masterDataService
					.getThresholdByName(Threshold.SGA_TTV_OUTLOOK_ENDDATE
							.name());

			form.setStartDate(CalendarUtil.getMondayDateByWeeks(
					ps.getSgaTtvTargetDate(), startNum.intValue()));
			form.setEndDate(CalendarUtil.getMondayDateByWeeks(
					ps.getSgaTtvTargetDate(), endNum.intValue()));
		} else {
			Float durationNum = masterDataService
					.getThresholdByName(Threshold.SGA_TTV_OUTLOOK_DURATION
							.name());
			form.setEndDate(CalendarUtil.getMondayDateByWeeks(
					form.getStartDate(), durationNum.intValue()));
		}
		if (form.getVersionDate() == null) {
			Date versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil
					.getTodayWithoutMins());
			form.setVersionDate(versionDate);
		}

		boolean odmFpy = "ODM".equals(form.getFpy()) ? true : false;
		List<TTVOutlookChartData> tTVOutlookChartDataList;
		if (previewDataMap != null) {
			tTVOutlookChartDataList = tTVOutlookService.simulationSGAPreview(
					form.getWaveId(), form.getStartDate(), form.getEndDate(),
					TimeFrequencyEnum.WEEKLY, odmFpy, form.getVersionDate(),
					form.isShowSgaOrSle(), previewDataMap);
		} else {
			if (!isPreview) {
				// fetch data by calling tTVOutlookService interface
				tTVOutlookChartDataList = tTVOutlookService.getSgaChartData(
						form.getWaveId(), form.getStartDate(),
						form.getEndDate(), TimeFrequencyEnum.WEEKLY, odmFpy,
						form.getVersionDate(), form.isShowSgaOrSle(),
						isSnapshot);
			} else {
				tTVOutlookChartDataList = tTVOutlookService
						.excludeSGAOrderPreview(form.getWaveId(),
								form.getStartDate(), form.getEndDate(),
								TimeFrequencyEnum.WEEKLY, odmFpy,
								form.getVersionDate(), form.isShowSgaOrSle(),
								orders);
			}
		}
		Map<String, TTVOutlookChartData> ttvOutlookListMap = new HashMap<String, TTVOutlookChartData>();
		if (CollectionUtils.isNotEmpty(tTVOutlookChartDataList)) {
			for (TTVOutlookChartData data : tTVOutlookChartDataList) {
				ttvOutlookListMap.put(CalendarUtil.date2String(CalendarUtil
						.getMondayDateByDate(data.getDate())), data);
			}
		}

		LineSet ttvLineSet = new LineSet();
		ttvLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_TTV);
		ttvLineSet.setColor(SysConfig.TTV_OUTLOOK_TTV_COLOR);
		ttvLineSet.setShowValues("0");
		ttvLineSet.setLineThickness("2");

		LineSet targetLineSet = new LineSet();
		targetLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_TTV_TARGET);
		targetLineSet.setColor(SysConfig.TTV_OUTLOOK_TTV_TARGET_COLOR);
		targetLineSet.setShowValues("0");
		targetLineSet.setLineThickness("2");

		LineSet sgaTtvLineSet = new LineSet();
		sgaTtvLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_ACTUALSGATTV);
		sgaTtvLineSet.setColor(SysConfig.TTV_OUTLOOK_SGATTV_COLOR);
		sgaTtvLineSet.setShowValues("0");
		sgaTtvLineSet.setLineThickness("2");

		LineSet sgaTargetLineSet = new LineSet();
		sgaTargetLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_SGATTV_TARGET);
		sgaTargetLineSet.setColor(SysConfig.TTV_OUTLOOK_SGATTV_TARGET_COLOR);
		sgaTargetLineSet.setShowValues("0");
		sgaTargetLineSet.setLineThickness("2");

		// ODM Ramp Commit
		DataSetColumn rampCommitDataSetColumn = new DataSetColumn();
		rampCommitDataSetColumn
				.setSeriesName(SysConfig.TTV_OUTLOOK_SGARAMPCOMMIT);
		rampCommitDataSetColumn
				.setColor(SysConfig.TTV_OUTLOOK_SGARAMPCOMMIT_COLOR);

		DataSetColumn capacityDataSetColumn = new DataSetColumn();
		capacityDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_CAPACITY);
		capacityDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_CAPACITY_COLOR);

		DataSetColumn gapDataSetColumn = new DataSetColumn();
		gapDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_GAP);
		gapDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_GAP_COLOR);

		DataSetColumn forecastDataSetColumn = new DataSetColumn();
		forecastDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_FORECAST);
		forecastDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_FORECAST_COLOR);

		DataSetColumn orderDataSetColumn = new DataSetColumn();
		orderDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_ORDER);
		orderDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_ORDER_COLOR);

		DataSetColumn shipmentDataSetColumn = new DataSetColumn();
		shipmentDataSetColumn.setSeriesName(SysConfig.TTV_OUTLOOK_SHIPMENT);
		shipmentDataSetColumn.setColor(SysConfig.TTV_OUTLOOK_SHIPMENT_COLOR);
		// /////////////////

		MSColumnChartView columnChartView = new MSColumnChartView();
		columnChartView.getChartInfo().setShowAlternateHGridColor("0");
		columnChartView.getChartInfo().setPyaxisname("Unit");
		columnChartView.getChartInfo().setSyaxisname("TTV Percentage %");
		columnChartView.getChartInfo().setNumbersuffix("(pcs)");
		Categories categories = new Categories();
		columnChartView.setCategories(categories);
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		categories.setCategoryList(categoryList);

		// lineset and dataset
		List<DataSet> dataSetList = new ArrayList<DataSet>();
		List<LineSet> lineSetList = new ArrayList<LineSet>();

		columnChartView.setDataSetList(dataSetList);
		columnChartView.setLineSetList(lineSetList);

		DataSet rampCommitDataSet = new DataSet();
		DataSet capacityDataSet = new DataSet();
		DataSet gapDataSet = new DataSet();
		DataSet forecastDataSet = new DataSet();
		DataSet orderDataSet = new DataSet();
		DataSet shipmentDataSet = new DataSet();

		dataSetList.add(rampCommitDataSet);
		dataSetList.add(forecastDataSet);
		dataSetList.add(capacityDataSet);
		dataSetList.add(gapDataSet);
		dataSetList.add(orderDataSet);
		dataSetList.add(shipmentDataSet);

		lineSetList.add(sgaTtvLineSet);
		lineSetList.add(sgaTargetLineSet);
		if (form.isShowSgaOrSle()) {
			lineSetList.add(ttvLineSet);
			lineSetList.add(targetLineSet);
		}
		// dataset:seriesName
		List<DataSetParent> rampCommitDataSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> capacitySetList = new ArrayList<DataSetParent>();
		List<DataSetParent> gapSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> forecastSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> orderSetList = new ArrayList<DataSetParent>();
		List<DataSetParent> shipmentSetList = new ArrayList<DataSetParent>();

		List<ColumnData> ttvColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> sgaTtvColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> sgaTargetCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> rampCommitCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> capacityCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> gapCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> forecastCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> orderCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> shipmentColumnDataList = new ArrayList<ColumnData>();

		rampCommitDataSetColumn.setDataList(rampCommitCloumnDataList);
		rampCommitDataSetList.add(rampCommitDataSetColumn);

		capacityDataSetColumn.setDataList(capacityCloumnDataList);
		capacitySetList.add(capacityDataSetColumn);

		gapDataSetColumn.setDataList(gapCloumnDataList);
		gapSetList.add(gapDataSetColumn);

		forecastDataSetColumn.setDataList(forecastCloumnDataList);
		forecastSetList.add(forecastDataSetColumn);

		orderDataSetColumn.setDataList(orderCloumnDataList);
		orderSetList.add(orderDataSetColumn);

		shipmentDataSetColumn.setDataList(shipmentColumnDataList);
		shipmentSetList.add(shipmentDataSetColumn);

		rampCommitDataSet.setDataSetList(rampCommitDataSetList);
		capacityDataSet.setDataSetList(capacitySetList);
		gapDataSet.setDataSetList(gapSetList);
		forecastDataSet.setDataSetList(forecastSetList);
		orderDataSet.setDataSetList(orderSetList);
		shipmentDataSet.setDataSetList(shipmentSetList);

		ttvLineSet.setDataList(ttvColumnDataList);
		targetLineSet.setDataList(targetCloumnDataList);

		sgaTtvLineSet.setDataList(sgaTtvColumnDataList);
		sgaTargetLineSet.setDataList(sgaTargetCloumnDataList);

		// /////////////////////////
		boolean flag = false;
		int currentWeekCount = 0;
		int count = masterDataService.getThresholdByName(
				Threshold.TTV_OUTLOOK_DURATION.name()).intValue();
		// category
		// String currentModay =
		// CalendarUtil.date2String(CalendarUtil.getMondayDateByDate(Calendar.getInstance().getTime()));
		String currentModay = CalendarUtil.date2String(form.getVersionDate());
		for (int i = 0; i <= count; i++) {
			String thisMonday = CalendarUtil.date2String(CalendarUtil
					.getMondayDateByWeeks(form.getStartDate(), i));
			String lastModay = CalendarUtil.date2String(CalendarUtil
					.getMondayDateByWeeks(form.getVersionDate(), -1));
			LabelCategory category = new LabelCategory();
			if (ps != null) {
				if (ps.getTtmTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getTtmTargetDate())))) {
					category.setName(thisMonday + "(SS)");
				} else if (ps.getTtvTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getTtvTargetDate())))) {
					category.setName(thisMonday + "(SLE)");
				} else if (ps.getSvtPlanDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSvtPlanDate())))) {
					category.setName(thisMonday + "(SVT)");
				} else if (ps.getSovpPlanDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSovpPlanDate())))) {
					category.setName(thisMonday + "(SOVP)");
				} else if (ps.getSgaTtvTargetDate() != null
						&& thisMonday.equals(CalendarUtil
								.date2String(CalendarUtil
										.getMondayDateByDate(ps
												.getSgaTtvTargetDate())))) {
					category.setName(thisMonday + "(SGA)");
				} else
					category.setName(thisMonday);
				categoryList.add(category);
			}

			TTVOutlookChartData tTVOutlookChartData = ttvOutlookListMap
					.get(thisMonday);
			String trackingCausesMonday = null;
			String trackingCausesSunday = null;
			trackingCausesMonday = CalendarUtil.getDateByDays(
					form.getStartDate(), 7 * i);
			trackingCausesSunday = CalendarUtil.getDateByDays(
					CalendarUtil.stringT2Date(trackingCausesMonday), 6);

			// Demand Order or Demand Rolling or Demand Forecast
			if (tTVOutlookChartData != null) {
				// TTL Gap
				ColumnData tTLGap = new ColumnData();
				/*
				 * boolean isGapExist = tTVOutlookChartData.getTotalGap() == 0 ?
				 * false : true;
				 */
				boolean isGapExist = true;
				int futureDemand;
				if (null != tTVOutlookChartData.getRampCommit()
						&& tTVOutlookChartData.getRampCommit() > 0) {
					futureDemand = Math.min(tTVOutlookChartData.getForecast(),
							tTVOutlookChartData.getRampCommit());
				} else {
					futureDemand = tTVOutlookChartData.getForecast() != null ? tTVOutlookChartData
							.getForecast() : 0;
				}
				int odm = tTVOutlookChartData.getOdm();
				int tooling = tTVOutlookChartData.getTooling();
				int supply = tTVOutlookChartData.getSupply();
				if (isGapExist) {
					tTLGap.setValue(-tTVOutlookChartData.getTotalGap());
					if (previewDataMap != null) {
						if (thisMonday.compareTo(currentModay) >= 0) {
							tTLGap.setLink("j-previewTrackingCause-"
									+ trackingCausesMonday + "|" + futureDemand
									+ "|" + odm + "|" + tooling + "|" + supply);
						}
					} else {
						setOutlookWeeklyColumnLink(tTLGap, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
				}
				gapCloumnDataList.add(tTLGap);

				// Ramp Commit
				ColumnData rampCommit = new ColumnData();
				if (isGapExist) {
					if (previewDataMap != null) {
						if (thisMonday.compareTo(currentModay) >= 0) {
							rampCommit.setLink("j-previewTrackingCause-"
									+ trackingCausesMonday + "|" + futureDemand
									+ "|" + odm + "|" + tooling + "|" + supply);
						}
					} else {
						setOutlookWeeklyColumnLink(rampCommit, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
				}
				if (tTVOutlookChartData.getRampCommit() != null
						&& tTVOutlookChartData.getRampCommit() != 0) {
					if (tTVOutlookChartData.getRampCommit() == -1) {
						rampCommit.setValue(0);
					} else {
						rampCommit.setValue(tTVOutlookChartData.getRampCommit()
								.floatValue());
					}
				}
				rampCommitCloumnDataList.add(rampCommit);

				ColumnData forecast = new ColumnData();
				if (tTVOutlookChartData.getForecast() != null
						&& tTVOutlookChartData.getForecast() > 0) {
					forecast.setValue(tTVOutlookChartData.getForecast());
				}
				if (isGapExist) {
					if (previewDataMap != null) {
						if (thisMonday.compareTo(currentModay) >= 0) {
							forecast.setLink("j-previewTrackingCause-"
									+ trackingCausesMonday + "|" + futureDemand
									+ "|" + odm + "|" + tooling + "|" + supply);
						}
					} else {
						setOutlookWeeklyColumnLink(forecast, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
					// setOutlookWeeklyColumnLink(forecast, thisMonday,
					// currentModay, trackingCausesMonday,
					// trackingCausesSunday);
				}
				forecastCloumnDataList.add(forecast);

				ColumnData order = new ColumnData();
				if (tTVOutlookChartData.getOrder() != null
						&& tTVOutlookChartData.getOrder() > 0) {
					order.setValue(tTVOutlookChartData.getOrder());
				}
				if (isGapExist) {
					if (previewDataMap != null) {
						if (thisMonday.compareTo(currentModay) >= 0) {
							order.setLink("j-previewTrackingCause-"
									+ trackingCausesMonday + "|" + futureDemand
									+ "|" + odm + "|" + tooling + "|" + supply);
						}
					} else {
						setOutlookWeeklyColumnLink(order, thisMonday,
								currentModay, trackingCausesMonday,
								trackingCausesSunday);
					}
					// setOutlookWeeklyColumnLink(order, thisMonday,
					// currentModay, trackingCausesMonday,
					// trackingCausesSunday);
				}
				orderCloumnDataList.add(order);

				// Capacity
				ColumnData capacity = new ColumnData();
				ColumnData shipment = new ColumnData();
				if (thisMonday.compareTo(currentModay) >= 0) {
					if (isGapExist) {
						if (previewDataMap != null) {
							if (thisMonday.compareTo(currentModay) >= 0) {
								capacity.setLink("j-previewTrackingCause-"
										+ trackingCausesMonday + "|"
										+ futureDemand + "|" + odm + "|"
										+ tooling + "|" + supply);
							}
						} else {
							setOutlookWeeklyColumnLink(capacity, thisMonday,
									currentModay, trackingCausesMonday,
									trackingCausesSunday);
						}
						// setOutlookWeeklyColumnLink(capacity, thisMonday,
						// currentModay, trackingCausesMonday,
						// trackingCausesSunday);
					}
					if (tTVOutlookChartData.getCapacity() > 0) {
						capacity.setValue(tTVOutlookChartData.getCapacity()
								.floatValue());
					}
					capacityCloumnDataList.add(capacity);

					// shipment.setValue(0);
					shipmentColumnDataList.add(shipment);
					capacity.setDashed("1");
					tTLGap.setDashed("1");
					rampCommit.setDashed("1");
					forecast.setDashed("1");
					order.setDashed("1");
				} else {
					// capacity.setValue(0f);
					capacityCloumnDataList.add(capacity);

					if (isGapExist) {
						if (previewDataMap != null) {
							if (thisMonday.compareTo(currentModay) >= 0) {
								shipment.setLink("j-previewTrackingCause-"
										+ trackingCausesMonday + "|"
										+ futureDemand + "|" + odm + "|"
										+ tooling + "|" + supply);
							}
						} else {
							setOutlookWeeklyColumnLink(shipment, thisMonday,
									currentModay, trackingCausesMonday,
									trackingCausesSunday);
						}
						// setOutlookWeeklyColumnLink(shipment, thisMonday,
						// currentModay, trackingCausesMonday,
						// trackingCausesSunday);
					}
					if (tTVOutlookChartData.getShipment() > 0) {
						shipment.setValue(tTVOutlookChartData.getShipment());
					}

					shipmentColumnDataList.add(shipment);
				}

				// Actual TTV or Estimated TTV
				ColumnData ttv = new ColumnData();

				ttv.setValue(tTVOutlookChartData.getTtv());

				ttvColumnDataList.add(ttv);

				ColumnData sgaTtv = new ColumnData();
				if (tTVOutlookChartData.getSgaTTV() == -1) {
					sgaTtv.setValue(100f);
				} else {
					sgaTtv.setValue(tTVOutlookChartData.getSgaTTV());
				}
				sgaTtvColumnDataList.add(sgaTtv);

				// LOGGER.info(i+"##############Integer.valueOf(trackingCausesMonday.replace(\"-\", \"\"))##############"+Integer.valueOf(trackingCausesMonday.replace("-",
				// "")));
				// System.out.println(i+"##############Integer.valueOf(trackingCausesMonday.replace(\"-\", \"\"))##############"+Integer.valueOf(trackingCausesMonday.replace("-",
				// "")));
				// LOGGER.info(i+"##############Integer.valueOf(currentModay.replace(\"-\",\"\"))##############"+Integer.valueOf(currentModay.replace("-",
				// "")));
				// System.out.println(i+"##############Integer.valueOf(currentModay.replace(\"-\",\"\"))##############"+Integer.valueOf(currentModay.replace("-",
				// "")));
				// LOGGER.info("#############tTVOutlookChartData.getTtv()#########"+tTVOutlookChartData.getTtv());

				if (Integer.valueOf(trackingCausesMonday.replace("-", "")) >= Integer
						.valueOf(currentModay.replace("-", ""))) {
					if (tTVOutlookChartData.getSgaTTV() != null)
						actualSgaFlag = false;
				}

				if (thisMonday.compareTo(lastModay) >= 0) {
					ttv.setDashed("1");
					sgaTtv.setDashed("1");
				}

				Vline vline = new Vline();
				categoryList.add(vline);
				if (lastModay.equalsIgnoreCase(thisMonday)) {
					flag = true;
				}
				if (flag) {
					currentWeekCount++;
				}
				if (currentWeekCount == 1) {
					vline.setLabel("Current Week");
					vline.setLabelHAlign("left");
				}
				if (flag) {
					vline.setDashed("0");
					vline.setThickness("2");
				}
				vline.setVline("true");
				if (currentWeekCount == 2) {
					flag = false;
				}
			} else {
				ColumnData capacity = new ColumnData();
				// capacity.setValue(0);
				capacityCloumnDataList.add(capacity);

				ColumnData tTLGap = new ColumnData();
				// tTLGap.setValue(0);
				gapCloumnDataList.add(tTLGap);

				ColumnData rampCommit = new ColumnData();
				// rampCommit.setValue(0);
				rampCommitCloumnDataList.add(rampCommit);

				// Actual TTV or Estimated TTV
				ColumnData ttv = new ColumnData();
				// ttv.setValue(0);
				ttvColumnDataList.add(ttv);

				ColumnData sgaTtv = new ColumnData();
				// sgaTtv.setValue(0);
				sgaTtvColumnDataList.add(sgaTtv);

				ColumnData forecast = new ColumnData();
				// forecast.setValue(0);
				forecastCloumnDataList.add(forecast);

				ColumnData order = new ColumnData();
				// order.setValue(0);
				orderCloumnDataList.add(order);

				ColumnData shipment = new ColumnData();
				// shipment.setValue(0);
				shipmentColumnDataList.add(shipment);

				if (lastModay.equalsIgnoreCase(thisMonday) || flag) {
					Vline vline = new Vline();
					categoryList.add(vline);
					if (lastModay.equalsIgnoreCase(thisMonday)) {
						flag = true;
					}
					if (flag) {
						currentWeekCount++;
					}
					if (currentWeekCount == 1) {
						vline.setLabel("Current Week");
						vline.setLabelHAlign("left");
					}
					if (flag) {
						vline.setDashed("0");
						vline.setThickness("2");
					}
					vline.setVline("true");
					if (currentWeekCount == 2) {
						flag = false;
					}

				}
			}
			// Target
			ColumnData target = new ColumnData();
			target.setValue(ps != null && ps.getTtvTarget() != null ? ps
					.getTtvTarget() : 0);
			targetCloumnDataList.add(target);

			ColumnData sgaTarget = new ColumnData();
			sgaTarget.setValue(ps != null && ps.getSgaTtvTarget() != null ? ps
					.getSgaTtvTarget() : 0);
			sgaTargetCloumnDataList.add(sgaTarget);

		}
		if (!actualSgaFlag) {
			sgaTtvLineSet.setSeriesName(SysConfig.TTV_OUTLOOK_SGATTV);
		}

		return columnChartView;
	}
}
