package com.lenovo.bi.engine;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.service.npi.helper.NPIWaveSummaryHelper;
/**
 * 
 * 
 * @author henry_lian
 *
 */
@Component
@Order(1)
public class TTVStatusProcessor implements TTVKPIProcessor {

	@Autowired
	private NPIWaveSummaryHelper nPIWaveSummaryHelper;
	
	@Override
	public void process(ProjectSummary ps, Date versionDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String todayStr = sdf.format(new Date())  ;
		Date today = null;
		try {
			today = sdf.parse(todayStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		float ttvTarget = ps.getTtvTarget();
		if(ps.getPhaseNumber() == null || ps.getTtvTargetDate() == null){
			ps.setTtvStatus(Status.NA.name());
		} else if(ps.getTtvSignOffDate() != null){
			if(ps.getTtvSignOffDate().before(ps.getTtvTargetDate())){
				if(ps.getActualTTV() >= ttvTarget){
					ps.setTtvStatus(Status.Success.name());
				} else{
					ps.setTtvStatus(Status.Fail.name());
				}
			} else{
				ProjectSummary snapshot = nPIWaveSummaryHelper.getProductInfoByWaveId(ps.getPmsWaveId(), ps.getTtvTargetDate());
				if(snapshot == null){
					ps.setTtvStatus(Status.Fail.name());
				}else if(snapshot.getActualTTV() >= ttvTarget){
					ps.setTtvStatus(Status.Success.name());
				} else{
					ps.setTtvStatus(Status.Fail.name());
				}
			}
		}else{
			if(today.after(ps.getTtvTargetDate())){
				ProjectSummary snapshot = nPIWaveSummaryHelper.getProductInfoByWaveId(ps.getPmsWaveId(), ps.getTtvTargetDate());
				if(snapshot != null && snapshot.getActualTTV() >= ttvTarget){
					ps.setTtvStatus(Status.In_Progress.name());
					ps.setTTVRisk(false);
				} else{
					ps.setTtvStatus(Status.Fail.name());
				}
			} else{
				ps.setTtvStatus(Status.In_Progress.name());
				if(ps.getEstimatedTTV() >= ttvTarget){
					ps.setTTVRisk(false);
				}else{
					ps.setTTVRisk(true);
				}
			}
		}

	}

}
