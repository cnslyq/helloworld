package com.lenovo.bi.form.simulation;

/**
 * 
 * @author Michael_xu02
 *
 */
//for create or update npi simulation summary
public class NPISimulationForm {
	
	private Integer id;
	
	private String productName;
	
	private Integer waveId;
	
	private String waveName;
	
	private String name;
	
	private String simulationName;
	
	private String description;
	
	private  Integer isShared;
	
	private String createdBy;
	
	private String type;
	
	private String ssDate;
	
	private String sleDate;
	
	private String sgaDate;
	
	private String sgaVersionDate;
	
	private String sleVersionDate;
	
	private Integer simulationId;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getWaveId() {
		return waveId;
	}

	public void setWaveId(Integer waveId) {
		this.waveId = waveId;
	}

	public String getWaveName() {
		return waveName;
	}

	public void setWaveName(String waveName) {
		this.waveName = waveName;
	}

	public String getSimulationName() {
		return simulationName;
	}

	public void setSimulationName(String simulationName) {
		this.simulationName = simulationName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getIsShared() {
		return isShared;
	}

	public void setIsShared(Integer isShared) {
		this.isShared = isShared;
	}

	public String getSsDate() {
		return ssDate;
	}

	public void setSsDate(String ssDate) {
		this.ssDate = ssDate;
	}

	public String getSleDate() {
		return sleDate;
	}

	public void setSleDate(String sleDate) {
		this.sleDate = sleDate;
	}

	public String getSgaDate() {
		return sgaDate;
	}

	public void setSgaDate(String sgaDate) {
		this.sgaDate = sgaDate;
	}

	public String getSgaVersionDate() {
		return sgaVersionDate;
	}

	public void setSgaVersionDate(String sgaVersionDate) {
		this.sgaVersionDate = sgaVersionDate;
	}

	public String getSleVersionDate() {
		return sleVersionDate;
	}

	public void setSleVersionDate(String sleVersionDate) {
		this.sleVersionDate = sleVersionDate;
	}

	public Integer getSimulationId() {
		return simulationId;
	}

	public void setSimulationId(Integer simulationId) {
		this.simulationId = simulationId;
	}
	
	
	
}
