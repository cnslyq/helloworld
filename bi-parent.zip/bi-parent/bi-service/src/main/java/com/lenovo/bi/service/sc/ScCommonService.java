package com.lenovo.bi.service.sc;

import java.util.List;
import java.util.Map;

import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;

public interface ScCommonService {
	public PieChartView getDetractorMainPieChart(Map<String, String> detractorMap, String linkName);
	public PieChartView getDetractorSubPieChart(Map<String, String> detractorMap, String linkName, String parentType);
	public Map<String,Object> getOrderDetail(List<String> orderKeys, SearchOtsForm form);
}
