package com.lenovo.bi.view.npi.chart.common;


public class LabelCategory extends CategoryParent {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
