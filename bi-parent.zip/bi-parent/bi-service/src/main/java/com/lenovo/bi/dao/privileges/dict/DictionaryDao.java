package com.lenovo.bi.dao.privileges.dict;

import java.util.List;

import org.apache.poi.ss.formula.functions.T;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.system.GroupDetail;
import com.lenovo.bi.model.system.GroupMember;
import com.lenovo.bi.view.system.dictionary.BuDetailView;
import com.lenovo.bi.view.system.dictionary.CompanyDetailView;
import com.lenovo.bi.view.system.dictionary.DepartmentDetailView;
import com.lenovo.bi.view.system.dictionary.GroupDetailView;
import com.lenovo.bi.view.system.dictionary.GroupMemberDetailView;
import com.lenovo.bi.view.system.dictionary.PrivilegeDetailView;
import com.lenovo.bi.view.system.dictionary.UserDetailView;
import com.lenovo.common.model.PagerInformation;

public interface DictionaryDao{

	public GroupDetail findGroupById(Integer groupId);
	
	public GroupDetail findGroupByName(String groupName);
	
	public List<PrivilegeDetailView> getPrivilegeDetailList(DictSearchForm form, PagerInformation pagerInfo);
	
	public int getPrivilegeDetailCountByConditions(DictSearchForm form);
	
	public List<GroupDetailView> listGroup(DictSearchForm form, PagerInformation pagerInfo);
	
	public List<GroupDetailView> listGroupsForExcel(DictSearchForm form);
	
	public int getGroupDetailCountByConditions(DictSearchForm form);
	
	public void saveGroup(GroupDetail groupDetail);
	
	public void saveGroupMember(List<GroupMember> groupMemberList);
	
	public void saveEditedGroup(GroupDetail groupDetail);
	
	public void saveEditedGroupMember(int gId,List<GroupMember> groupMemberList);
	
	public void deleteGroups(String groupIds);
	
	public List<T> listOrg(String type,String name);
	
	public List<GroupMemberDetailView> getGroupMemberByGroupId(Integer groupId,Integer memberType);
	
	public GroupDetailView getGroupById(Integer groupId);
	
	public List<KeyNameObject> getCompanyList();
	
	public List<KeyNameObject> getBuList();
	
	public List<CompanyDetailView> queryCompanyByConditions(String companyName);
	
	public List<BuDetailView>  queryBuByConditions(String compId,String buName);
	
	public List<DepartmentDetailView>  queryDepByConditions(String compId,String buId,String depName);
	
	public List<UserDetailView>  queryUserByConditions(String companyName,String buName,String depName,String userName);
}
