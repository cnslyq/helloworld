package com.lenovo.bi.engine;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.enumobj.KPILights;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.service.npi.NPIDefectService;
import com.lenovo.bi.util.CalendarUtil;

/**
 * 
 * 
 * @author henry_lian
 *
 */
@Component
@Order(2)
public class TTMDefectKPIProcessor implements TTMKPIProcessor{
	
	@Inject
	private NPIDefectService nPIDefectService;

	@Override
	public void process(ProjectSummary ps,Date versionDate) {
		if(ps.getTtmStatus().equals(Status.NA.name())){
			return;
		}
		Date targetDate = ps.getTtmTargetDate();
		if(targetDate != null){
			targetDate = CalendarUtil.getMondayDateByDate(targetDate);
		}
		List<Defect> list = nPIDefectService.getGatingDefectsByProductWave(ps.getPmsWaveId(), versionDate, versionDate);
		
		KPILights kpi = KPILights.GREEN;
		if(list != null && !list.isEmpty()){
			kpi = KPILights.YELLOW;
			for(Defect defect: list){
				if(defect.getTargetDate() == null || defect.getTargetDate().after(ps.getTtmTargetDate())){
					kpi = KPILights.RED;
					break;
				}
			}
		}
		ps.setDefects(kpi.name());
	}

}
