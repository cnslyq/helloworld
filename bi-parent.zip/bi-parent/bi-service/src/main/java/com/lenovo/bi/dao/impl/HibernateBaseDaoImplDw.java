package com.lenovo.bi.dao.impl;

import javax.inject.Inject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;

public class HibernateBaseDaoImplDw<T> extends HibernateBaseDaoImpl<T> {
//	protected SessionFactory sessionFactory;

	@Inject
	@Qualifier("sessionFactoryDw")
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	protected Session getSession() {
		return sessionFactory.getCurrentSession();
	}
}
