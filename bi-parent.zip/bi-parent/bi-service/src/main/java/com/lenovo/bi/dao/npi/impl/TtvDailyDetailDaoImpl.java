package com.lenovo.bi.dao.npi.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.model.TtvDailyDetail;

@Repository
public class TtvDailyDetailDaoImpl extends HibernateBaseDaoImplBi<TtvDailyDetail>{ 
	public List<TtvDailyDetail> getNpiDailyDetail(int pmsWaveId) {
		return list("from TtvDailyDetail where pmsWaveId = :pmsWaveId order by targetDate", "pmsWaveId", new Integer[]{pmsWaveId});
	}

	/**
	 * Return the details between start date and end date, both inclusively
	 * @param pmsWaveId 
	 * @param startDate can be null
	 * @param endDate can be null
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<TtvDailyDetail> getNpiDailyDetail(int pmsWaveId, Date startDate, Date endDate) {
		StringBuffer hql = new StringBuffer("from TtvDailyDetail where pmsWaveId = :pmsWaveId ");
		
		if (startDate != null) {
			hql.append("and datediff(day, :startDate, targetDate) >= 0 ");
		}
		
		if (endDate != null) {
			hql.append("and datediff(day, targetDate, :endDate) >= 0 ");
		}
		
		hql.append("order by targetDate ");
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("pmsWaveId", pmsWaveId);
		
		if (startDate != null) {
			query.setParameter("startDate", startDate);
		}
		
		if (endDate != null) {
			query.setParameter("endDate", endDate);
		}
		
		return (List<TtvDailyDetail>)query.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<Integer> getPmsWaveIdsForVersionDate(Date versionDate) {
		StringBuffer hql = new StringBuffer("select distinct pmsWaveId from TtvDailyDetail where datediff(day, versionDate, :versionDate) = 0 order by pmsWaveId");
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("versionDate", versionDate);		
		
		return query.list();
	}
}
