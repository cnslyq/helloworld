package com.lenovo.bi.engine;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lenovo.bi.dto.ProductKeyPmsWaveId;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.SysConstants;

@Component
public class ProductKeyPmsWaveIdMap {
	private Map<String, String> pmsWaveIdToProductKey;
	private Map<String, String> productKeyToPmsWaveId;
	
	@Autowired
	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	
	private static Logger LOGGER = Logger.getLogger(SysConstants.LOG_WEEKLY_BATCH_CATALOG);
	
	@PostConstruct
	public synchronized void constructMaps() {
		pmsWaveIdToProductKey = new HashMap<String, String>();
		productKeyToPmsWaveId = new HashMap<String, String>();
		
		List<ProductKeyPmsWaveId> productKeyPmsWaveIdList = ttvOutlookServiceDwHelper.getProductKeyPmsWaveIdList();
		
		for (ProductKeyPmsWaveId item : productKeyPmsWaveIdList) {
			pmsWaveIdToProductKey.put(item.getPmsWaveId(), item.getProductKey());
			productKeyToPmsWaveId.put(item.getProductKey(), item.getPmsWaveId());
		}
		
		LOGGER.info("Number of entries in ProductKeyPmsWaveIdMap: " + productKeyPmsWaveIdList.size());
	}
	
	// TODO-Ying, remove comment sign
	//@Scheduled(cron="0 0 20 * * *")  // Run every day at 20 o'clock
	public void refreshMaps() {
		constructMaps();
	}
	
	public synchronized String getPmsWaveIdFromProductKey(String productKey) {
		return productKeyToPmsWaveId.get(productKey);
	}
	
	public synchronized String getProductKeyFromPmsWaveId(String pmsWaveId) {
		return pmsWaveIdToProductKey.get(pmsWaveId);
	}
}
