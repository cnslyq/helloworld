package com.lenovo.bi.engine;

public class BomNumberGeographyOdmCvKeyKey {
	private String bomNumber;
	private String geographyName;
	private String odmName;
	private int cvKey;
	
	public BomNumberGeographyOdmCvKeyKey(String bomNumber,
			String geographyName, String odmName, int cvKey) {
		super();
		this.bomNumber = bomNumber;
		this.geographyName = geographyName;
		this.odmName = odmName;
		this.cvKey = cvKey;
	}

	public String getBomNumber() {
		return bomNumber;
	}
	
	public String getGeographyName() {
		return geographyName;
	}

	public String getOdmName() {
		return odmName;
	}

	public int getCvKey() {
		return cvKey;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((bomNumber == null) ? 0 : bomNumber.hashCode());
		result = prime * result + cvKey;
		result = prime * result
				+ ((geographyName == null) ? 0 : geographyName.hashCode());
		result = prime * result + ((odmName == null) ? 0 : odmName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BomNumberGeographyOdmCvKeyKey other = (BomNumberGeographyOdmCvKeyKey) obj;
		if (bomNumber == null) {
			if (other.bomNumber != null)
				return false;
		} else if (!bomNumber.equals(other.bomNumber))
			return false;
		if (cvKey != other.cvKey)
			return false;
		if (geographyName == null) {
			if (other.geographyName != null)
				return false;
		} else if (!geographyName.equals(other.geographyName))
			return false;
		if (odmName == null) {
			if (other.odmName != null)
				return false;
		} else if (!odmName.equals(other.odmName))
			return false;
		return true;
	}
	
	
}
