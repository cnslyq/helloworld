package com.lenovo.bi.service.system;

import java.util.List;

import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.system.ThresholdDetail;
import com.lenovo.bi.view.system.console.BiWeeklyProcessStatusView;
import com.lenovo.bi.view.system.console.FailedJobDetailView;
import com.lenovo.bi.view.system.console.ThresholdDetailView;
import com.lenovo.common.model.Pager;

public interface ConsoleService {

	public ThresholdDetail findThresholdById(Integer thresholdId);
	
	public ThresholdDetailView getThresholdById(Integer thresholdId);
	
	public void saveThreshold(ThresholdDetail thresholdDetail);
	
	public void saveEditedThreshold(ThresholdDetail thresholdDetail);
	
	public void deleteThresholds(String thresholdIds);
	
	public Pager<ThresholdDetailView> listThresholds(DictSearchForm form);
	
	public List<BiWeeklyProcessStatusView> getEngineStatusHistory();
	
	public Pager<FailedJobDetailView> listFailedJobs(DictSearchForm form,String jobStatus);
	
	public void restartFailedJobs(String packageName);
	
	public List<FailedJobDetailView> listFailedJobDetails(String startDate, String packageName);
}
