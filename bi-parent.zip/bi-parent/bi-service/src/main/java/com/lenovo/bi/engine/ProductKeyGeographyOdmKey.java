package com.lenovo.bi.engine;

import org.apache.commons.lang.StringUtils;

public class ProductKeyGeographyOdmKey {
	private String productKey;
	private String geographyName;
	private String odmName;

	public ProductKeyGeographyOdmKey(String productKey, String geographyName, String odmName) {
		super();

		if (productKey == null || productKey.isEmpty() || StringUtils.isEmpty(geographyName) || StringUtils.isEmpty(odmName)) {
			throw new IllegalArgumentException("Product key, geography name, or ODM name is empty.");
		}

		this.productKey = productKey;
		this.geographyName = geographyName;
		this.odmName = odmName;
	}

	public ProductKeyGeographyOdmKey(Integer productKey, String geographyName, String odmName) {
		super();

		if (productKey == null || StringUtils.isEmpty(geographyName) || StringUtils.isEmpty(odmName)) {
			throw new IllegalArgumentException("Product key, geography name, or ODM name is empty.");
		}

		this.productKey = productKey.toString();
		this.geographyName = geographyName;
		this.odmName = odmName;
	}

	public String getProductKey() {
		return productKey;
	}

	public String getGeographyName() {
		return geographyName;
	}

	public String getOdmName() {
		return odmName;
	}

	@Override
	public String toString() {
		return "ProductKeyGeographyOdmKey [productKey=" + productKey + ", geographyName=" + geographyName + ", odmName=" + odmName + "]";
	}

	@Override
	public int hashCode() {
		return 97 * productKey.hashCode() + 89 * geographyName.hashCode() + 83 * odmName.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof ProductKeyGeographyOdmKey) {
			ProductKeyGeographyOdmKey key = (ProductKeyGeographyOdmKey) obj;
			return this.productKey.equals(key.getProductKey()) && this.geographyName.equals(key.getGeographyName())
					&& this.getOdmName().equals(key.getOdmName());
		} else {
			return false;
		}
	}

}
