package com.lenovo.bi.form.npi.ttm;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.form.npi.SearchBase;
/**
 * This class is a condition object for search pie chart base on left menu entrance: my projects, overview all, search product
 * @author coris_zhao
 *
 */
@Deprecated
public class SearchPieChartDataForm extends SearchBase{
	private Status type;//ttm overview/in progress/fail/success/NA
//	private List<ProductWave> productWaves;
	private Date ttmTargetDateBefore;
	private List<Integer> npiIds;
	
	public List<Integer> getNpiIds() {
		return npiIds;
	}
	public void setNpiIds(List<Integer> npiIds) {
		this.npiIds = npiIds;
	}
	public Date getTtmTargetDateBefore() {
		return ttmTargetDateBefore;
	}
	public void setTtmTargetDateBefore(Date ttmTargetDateBefore) {
		this.ttmTargetDateBefore = ttmTargetDateBefore;
	}
	public Status getType() {
		return type;
	}
	public void setType(Status type) {
		this.type = type;
	}
}
