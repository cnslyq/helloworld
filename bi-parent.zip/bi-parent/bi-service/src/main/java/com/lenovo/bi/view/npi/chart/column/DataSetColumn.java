package com.lenovo.bi.view.npi.chart.column;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;

public class DataSetColumn extends DataSetParent {

	private List<ColumnData> dataList;
	private String color;

	public List<ColumnData> getDataList() {
		return dataList;
	}

	@JsonProperty("data")
	public void setDataList(List<ColumnData> dataList) {
		this.dataList = dataList;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
