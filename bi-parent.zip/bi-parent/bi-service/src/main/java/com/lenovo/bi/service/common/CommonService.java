package com.lenovo.bi.service.common;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FpsdRemarkChartData;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;

/**
 * this interface for handler common event
 * @author coris_zhao
 *
 */
public interface CommonService {
	
	public String getKPILightColor(String orderType, float makeRate);
	
	public String getOnsKPILightColor(float makeRate);//ONS
	
	public String getFlexibilityKPILightColor(String dimension,float rate);
	
	public float calculateOtsMakeRate(String date,Map<String,Integer> dataMap) throws ParseException ; //OTS
	
	public float calculateOtsMakeRateForQuarter(SearchOtsForm form,String quarter,Map<String,Integer> dataMap) throws ParseException ; //OTS:Quarter
	
	public float calculateMakeRate(String date,Map<String, Integer> dataMap) throws ParseException ; //FPSD
	
	public float calculateMFGCaMakeRate(String date,String currentRolMonth,Map<String,Integer> dataMap, boolean isCa) throws ParseException ; //MFGCA
	
	public float calculateSalesCaMakeRate(String date,String currentRolMonth,Map<String,Integer> dataMap, boolean isCa) throws ParseException ; //SalseCA
	
	public float calculateFpsdMakeRate(String date,FpsdRemarkChartData fpsdRemarkChartData, SearchOtsForm form) throws ParseException ;//FPSD
	
	public float calculateComponentFa(String date,Map<String,Integer> dataMap) throws ParseException ; //Component FA
	
	
	public List<String> getOdms();
	
	public List<String> getProductFamily();
	
	public List<String> getProduct();
	
	public String getRegionTreeJson();
	
	public String getSelectRegionTreeJsonByIds(String treeIds);
	
	public List<KeyNameObject> getOrderTypeList();
	
	public List<KeyNameObject> getOrderSubTypeList(Integer orderType);
	
	public List<KeyNameObject> getOdmList();
	
	public List<KeyNameObject> getProductList();
	
	public List<KeyNameObject> getComponentList();
	
	public List<KeyNameObject> getComponentValueList();
	//BPS productFamily
	public List<KeyNameObject> getProductFamilyList();
	
	public List<KeyNameObject> getFamilyList();
	
	public List<KeyNameObject> getPortfolioList();
	
	public List<KeyNameObject> getPurchaseTypeList();
}
