package com.lenovo.bi.service.sc;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.form.sc.ca.SearchCaForm;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.sc.ca.CaDetailGridView;


public interface CAService {
	public ColumnChartView getOverviewChart(SearchCaForm form) throws ParseException;
	
	public String getOverviewOverall(SearchCaForm form) throws ParseException;
	
	public ColumnChartView getRemarkChart(SearchCaForm form) throws ParseException;
	
	public List<CaDetailGridView> getSumCaDetails(SearchCaForm form) throws ParseException;
	
	public List<CaDetailGridView> getRemarkCaDetails(SearchCaForm form);
	
	public Map<String,Object> getCaRemarkOrderDetail(SearchCaForm form) throws ParseException;
	
	public Map<String,Object> getCaOrderDetail(SearchCaForm form) throws ParseException;
	
	public void setFormDimParam(SearchCaForm form, String dim, String dimKeys);
}
