package com.lenovo.bi.batch;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;



@Service
public class EnagineScheduler extends EnagineWeeklyBatch {
	//engine entrance
	@Override
	//@Scheduled(cron="0 0 5,12 * * *") // Run every day at 5 o'clock
	public void runBatch() {
		super.runBatch();
	}

}
