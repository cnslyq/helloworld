package com.lenovo.bi.service.sc;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.sc.fa.FADetailView;

public interface ComponentFAService {
	
	public ColumnChartView getOverviewChart(SearchFaForm form) throws ParseException;
	
	public ColumnChartView getDashboardChart(SearchFaForm form) throws ParseException;
	
	public ColumnChartView getRemarkChart(SearchFaForm form) throws ParseException;
	
	public PieChartView getOverviewPieChart(SearchFaForm form) throws ParseException;
	
	public String getLackProduct(SearchFaForm form) throws ParseException;
	
	public String getLackRegion(SearchFaForm form) throws ParseException;
	
	public String getGeo(SearchFaForm form) throws ParseException;
	
	public List<FADetailView> getComponentFaDetail(SearchFaForm form);
	
	public List<FADetailView> getComponentFaGEODetail(SearchFaForm form);
	
	public List<FADetailView> getComponentFaPieDetail(SearchFaForm form);
	
	public long getComponentFaDetailCount(SearchFaForm form);
	
	public long getComponentFaDashboardDetailCount(SearchFaForm form);
	
	public Map<String,Object> getComponentFADetailExprot(SearchFaForm form);
	
}
