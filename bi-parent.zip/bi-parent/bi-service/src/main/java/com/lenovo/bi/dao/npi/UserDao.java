package com.lenovo.bi.dao.npi;

import com.lenovo.bi.model.User;

public interface UserDao {
	
	public User getUserById(String userId);
}
