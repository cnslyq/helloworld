package com.lenovo.bi.dao;

import java.sql.Types;

import org.hibernate.dialect.SQLServer2008Dialect;
import org.hibernate.type.StandardBasicTypes;

public class LenovoSQLServerDialect extends SQLServer2008Dialect {
	private static final int MAX_LENGTH = 4000;

	public LenovoSQLServerDialect() {
		super();
		registerHibernateType(Types.NVARCHAR, MAX_LENGTH, StandardBasicTypes.STRING.getName());
		registerHibernateType(Types.DECIMAL, StandardBasicTypes.FLOAT.getName());
		registerHibernateType(Types.DOUBLE, StandardBasicTypes.FLOAT.getName());
	}
	
}
