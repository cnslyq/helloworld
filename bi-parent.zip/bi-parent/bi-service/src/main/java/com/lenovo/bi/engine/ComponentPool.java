package com.lenovo.bi.engine;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.lenovo.bi.dto.DnsEntry;
import com.lenovo.bi.dto.MtmCvConfig;
import com.lenovo.bi.dto.SingleUnitCvConfig;
import com.lenovo.bi.enumobj.DnsShortageCodeEnum;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;

public class ComponentPool {
	private Map<Integer, DnsEntry> dnsMap = new HashMap<Integer, DnsEntry>();
	
	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	
	private Date versionDate;
	
	
	public ComponentPool(TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper, Date versionDate) {
		super();
		this.ttvOutlookServiceDwHelper = ttvOutlookServiceDwHelper;
		this.versionDate = versionDate;
	}

	public void initializePool(Date targetMonday) {
		List<DnsEntry> allDnsEntriesInWeek = ttvOutlookServiceDwHelper.getAllDnsEntriesInWeekForVersionDate(targetMonday, versionDate);
		
		// Demand does not carry over from week to week. Reset demand.
		for (DnsEntry dnsEntry : dnsMap.values()) {
			dnsEntry.setDemand(0);
			dnsEntry.setTotalDemand(0);
		}
		
		// Supply carries over from week to week.
		for (DnsEntry dnsEntry : allDnsEntriesInWeek) {
			DnsEntry dnsEntry2 = dnsMap.get(dnsEntry.getCvKey());
			if (dnsEntry2 == null) {
				dnsMap.put(dnsEntry.getCvKey(), dnsEntry);
			}
			else {
				dnsEntry2.setDemand(dnsEntry.getDemand());
				dnsEntry2.setSupply(dnsEntry2.getSupply() + dnsEntry.getSupply());
			}
		}
	}
	
	public Set<Integer> getAllCvs() {
		return dnsMap.keySet();
	}
	
	public DnsEntry getDnsEntry(int cvKey) {
		return dnsMap.get(cvKey);
	}
	
	public List<Integer> filterCvsWithShortageCode(DnsShortageCodeEnum shortageCode) {
		List<Integer> cvs = new ArrayList<Integer>();
		
		for (DnsEntry dnsEntry : dnsMap.values()) {
			if (dnsEntry.getShortageCode() == shortageCode) {
				cvs.add(dnsEntry.getCvKey());
			}
		}
		
		return cvs;
	}
	
	public int calculateMaxMtmNumberOfUnits(MtmCvConfig mtmCvConfig) {
		int min = mtmCvConfig.getNumberOfUnits();
		
		for (Integer cv : mtmCvConfig.getAllCvs()) {
			//-1 return will be treated as infinitive supply
			if(getSupplyQuantity(cv) != -1){
				int available = getSupplyQuantity(cv) / mtmCvConfig.getSingleUnitQuantity(cv);
				min = Math.min(min, available);
			}
		}
		
		return min;
	}
	
	public void deductMtmUnits(SingleUnitCvConfig singleUnitCvConfig, int numberOfUnits) {
		MtmCvConfig mtmCvConfig = new MtmCvConfig(singleUnitCvConfig, numberOfUnits);
		
		if (numberOfUnits > calculateMaxMtmNumberOfUnits(mtmCvConfig)) {
			throw new IllegalArgumentException("The number of MTM units cannot be covered by current component pool");
		}
		
		for (Integer cvKey : singleUnitCvConfig.getAllCvs()) {
			reduceCvQuantity(cvKey, mtmCvConfig.getQuantity(cvKey));
		}
	}	
	
	/**
	 * Deduct the quantity not exceeding the existing supply amount.
	 * @param cvKey
	 * @param quantity
	 * @return The quantity that can be deducted.
	 */
	public int deductMaxCvQuantity(int cvKey, int quantity) {
		DnsEntry dnsEntry = dnsMap.get(cvKey);
		int min = 0;
		
		if (dnsEntry != null) {
			min = Math.min(quantity, dnsEntry.getSupply());
			int demand = dnsEntry.getDemand() - min >= 0 ? dnsEntry.getDemand() - min : 0;
			int supply = dnsEntry.getSupply() - min >= 0 ? dnsEntry.getSupply() - min : 0;
			
			dnsEntry.setDemand(demand);
			dnsEntry.setSupply(supply);
		}

		return min;
	}
	
	public void incrementTotalDemand(int cvKey, int quantity) {
		DnsEntry dnsEntry = dnsMap.get(cvKey);
		
		if (dnsEntry != null) {
			dnsEntry.setTotalDemand(dnsEntry.getTotalDemand() + quantity);
		}
	}
	
	public void setTotalDemand(int cvKey, int quantity) {
		DnsEntry dnsEntry = dnsMap.get(cvKey);
		
		if (dnsEntry != null) {
			dnsEntry.setTotalDemand(quantity);
		}
	}
	
	
	private int getSupplyQuantity(int cvKey) {
		DnsEntry dnsEntry = dnsMap.get(cvKey);
		
		if (dnsEntry == null) {
			return -1;
		}
		else {
			return dnsEntry.getSupply();
		}
	}
	
	private void reduceCvQuantity(int cvKey, int quantity) {
		DnsEntry dnsEntry = dnsMap.get(cvKey);
		if(dnsEntry == null){
			return;
		}
		dnsEntry.setDemand(dnsEntry.getDemand() - quantity);
		dnsEntry.setSupply(dnsEntry.getSupply() - quantity);
	}


}
