package com.lenovo.bi.dao.sc.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.LtfcDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FaOverViewChartData;
import com.lenovo.bi.dto.sc.LTFCRemarkChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.LtfcTypeEnum;
import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.sc.fa.LTFCDetailView;
import com.lenovo.common.model.PagerInformation;

@Repository
public class LtfcDaoImpl extends HibernateBaseDaoImplDw implements LtfcDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> fetchLtfcOverViewChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		String ltfcVersion=form.getLtfcVersion();
		String mapsVersion=form.getMpsVersion();
		String ltfcIsNull=isNullLTFC(ltfcVersion);
		String mpsIsNull=isNullMPS(mapsVersion);
		String orderIsNull=isNullOrder();
		
		String sumLtfc=" sum(case when ltfc.["+ltfcVersion+"DaysLTFCQty] is null then 0 else ltfc.["+ltfcVersion+"DaysLTFCQty] end) ";
		
		sBuffer.append("select case when "+sumLtfc+" is null then 0 else "+sumLtfc+" end  as typeValue, ")
   		.append("'Ltfc' as typeName")
   		.append(" from FactMonthlySummaryofLTFCFA ltfc");
		
	    sBuffer.append(" where ltfc.Year = ").append(form.getYear())
	    		.append(" and ltfc.Month = ").append(form.getMonth());
	    
	    sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
	    //dodo
	    sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
	    
		sBuffer.append(" union ");
		
		//if(LtfcTypeEnum.Mps.getTypeName().equals(form.getLtfcType())) {
			String mpsLtfc=" sum(case when ltfc.["+mapsVersion+"DaysMPSQty] is null then 0 else ltfc.["+mapsVersion+"DaysMPSQty] end) ";
			sBuffer.append("select case when "+mpsLtfc+" is null then 0 else "+mpsLtfc+" end  as typeValue, ")
	   		.append("'Mps' as typeName")
	   		.append(" from FactMonthlySummaryofLTFCFA ltfc");
		
			sBuffer.append(" where ltfc.Year = ").append(form.getYear())
    		.append(" and ltfc.Month = ").append(form.getMonth());
    //}
    	 sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
    	 //dodo
    	 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
		//}
		//else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
			
			sBuffer.append(" union ");	
			
			String orderLtfc=" sum(case when ltfc.OrderQty is null then 0 else ltfc.OrderQty end) ";
			sBuffer.append("select case when "+orderLtfc+" is null then 0 else "+orderLtfc+" end  as typeValue, ")
	    	.append("'Order' as typeName ")
	    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		//}
		/*if(form.isShowQuarterOverview())
			sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
			   .append(form.getQuarterFrom()).append("'")
			   .append(" and '").append(form.getQuarterTo()).append("'");
	    else {*/
	    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
	    		.append(" and ltfc.Month = ").append(form.getMonth());
	    //}
	    	 sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
	    	//dodo
	    	 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
	    	
	    	 sBuffer.append(" union ");	 
	    	
	    	 String minRemarkMPS=" sum(case when "+ltfcIsNull+" < "+mpsIsNull+" then "+ltfcIsNull+" else "+mpsIsNull+" end)  ";
				sBuffer.append("select case when "+minRemarkMPS+" is null then 0 else "+minRemarkMPS+" end  as typeValue, ")
		    	.append("'minRemarkMPS' as typeName ")
		    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
				
			 sBuffer.append(" where ltfc.Year = ").append(form.getYear())
	    		.append(" and ltfc.Month = ").append(form.getMonth());
			 
	    	 sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
	    	//dodo
	    	 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
	    	
	    	 sBuffer.append(" union ");	
	    	 
	    	 String maxRemarkMPS=" sum(case when "+ltfcIsNull+" > "+mpsIsNull+" then "+ltfcIsNull+" else "+mpsIsNull+" end) ";
				sBuffer.append("select case when "+maxRemarkMPS+" is null then 0 else "+maxRemarkMPS+" end  as typeValue, ")
		    	.append("'maxRemarkMPS' as typeName ")
		    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
				
			 sBuffer.append(" where ltfc.Year = ").append(form.getYear())
	    		.append(" and ltfc.Month = ").append(form.getMonth());
			 
	    	 sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
	    	//dodo
	    	 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
	    	 
	    	 sBuffer.append(" union ");	 
		    	
	    	 String minRemarkOrder=" sum(case when "+ltfcIsNull+" < "+orderIsNull+" then "+ltfcIsNull+" else "+orderIsNull+" end)  ";
				sBuffer.append("select case when "+minRemarkOrder+" is null then 0 else "+minRemarkOrder+" end  as typeValue, ")
		    	.append("'minRemarkOrder' as typeName ")
		    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
				
			 sBuffer.append(" where ltfc.Year = ").append(form.getYear())
	    		.append(" and ltfc.Month = ").append(form.getMonth());
			 
	    	 sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
	    	//dodo
	    	 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
	    	
	    	 sBuffer.append(" union ");	
	    	 
	    	 String maxRemarkOrder=" sum(case when "+ltfcIsNull+" > "+orderIsNull+" then "+ltfcIsNull+" else "+orderIsNull+" end) ";
				sBuffer.append("select case when "+maxRemarkOrder+" is null then 0 else "+maxRemarkOrder+" end  as typeValue, ")
		    	.append("'maxRemarkOrder' as typeName ")
		    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
				
			 sBuffer.append(" where ltfc.Year = ").append(form.getYear())
	    		.append(" and ltfc.Month = ").append(form.getMonth());
			 
	    	 sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
	    	//dodo
	    	 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
	    	 
	    	 
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("typeName", StringType.INSTANCE)
				.addScalar("typeValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchTop15SubDimensions(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		//for Family remark chart
		if("Family".equals(form.getDimension())) {
			sBuffer.append("select top 15 ltfc.RegionKey as objKey,geography.GeographyName as objName,'Region' as type")
			   .append(" from FactMonthlySummaryofLTFCFA ltfc ")
			   .append(" left join DimGeography geography on ltfc.RegionKey = geography.GeographyKey");
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
			    	sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
					   .append(form.getQuarterFrom()).append("'")
					   .append(" and '").append(form.getQuarterTo()).append("'");
				}
				//month
				else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
				}
			}
			
			//dashboard overview chart:ODM or Product
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			//show geo or region overview 
			if(!form.isShowGeoOverview()) 
				sBuffer.append(" and geography.GeographyType = 'Region'");
			else
				sBuffer.append(" and geography.GeographyType = 'Geo'");
			//dodo
			sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			
			sBuffer.append(" group by ltfc.RegionKey,geography.GeographyName,ltfc.OrderQty having ltfc.RegionKey != '' order by OrderQty desc");
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append("select top 15 ltfc.ODMKey as objKey,odm.ODMEnglishName as objName,'Odm' as type")
			   .append(" from FactMonthlySummaryofProductFA ltfc ")
			   .append(" left join DimODM odm on ltfc.ODMKey = odm.ODMKey");
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
			    	sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
					   .append(form.getQuarterFrom()).append("'")
					   .append(" and '").append(form.getQuarterTo()).append("'");
				}
				//month
				else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
				}
			}
			
			//dashboard overview chart:Region or Product
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			sBuffer.append(" group by ltfc.ODMKey,odm.ODMEnglishName,ltfc.OrderQty having ltfc.ODMKey != '' order by OrderQty desc");
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append("select top 15 ltfc.ProductKey as objKey,product.ProductEnglishName as objName,'Product' as type")
			   .append(" from FactMonthlySummaryofProductFA ltfc ")
			   .append(" left join DimProduct product on ltfc.ProductKey = product.ProductKey");
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
			    	sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
					   .append(form.getQuarterFrom()).append("'")
					   .append(" and '").append(form.getQuarterTo()).append("'");
				}
				//month
				else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
				}
			}
			
			//dashboard overview chart:Region or Odm
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
			
			sBuffer.append(" group by ltfc.ProductKey,product.ProductEnglishName,ltfc.OrderQty having ltfc.ProductKey != '' order by OrderQty desc");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchSelectedSubDimensions(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append("select ltfc.RegionKey as objKey,geography.GeographyName as objName,'Region' as type")
			   .append(" from FactMonthlySummaryofProductFA ltfc ")
			   .append(" left join DimGeography geography on ltfc.RegionKey = geography.GeographyKey");
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
			    	sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
					   .append(form.getQuarterFrom()).append("'")
					   .append(" and '").append(form.getQuarterTo()).append("'");
				}
				//month
				else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ltfc.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//overview chart:ODM or Product
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			//show geo or region overview 
			if(!form.isShowGeoOverview()) 
				sBuffer.append(" and geography.GeographyType = 'Region'");
			else
				sBuffer.append(" and geography.GeographyType = 'Geo'");
			
			sBuffer.append(" group by ltfc.RegionKey,geography.GeographyName,ltfc.OrderQty having ltfc.RegionKey != '' order by OrderQty desc");
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append("select ltfc.ODMKey as objKey,odm.ODMEnglishName as objName,'Odm' as type")
			   .append(" from FactMonthlySummaryofProductFA ltfc ")
			   .append(" left join DimODM odm on ltfc.ODMKey = odm.ODMKey");
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
			    	sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
					   .append(form.getQuarterFrom()).append("'")
					   .append(" and '").append(form.getQuarterTo()).append("'");
				}
				//month
				else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
				}
			}
			
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ltfc.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//overview chart:Region or Product
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			sBuffer.append(" group by ltfc.ODMKey,odm.ODMEnglishName,ltfc.OrderQty having ltfc.ODMKey != '' order by OrderQty desc");
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append("select ltfc.ProductKey as objKey,product.ProductEnglishName as objName,'Product' as type")
			   .append(" from FactMonthlySummaryofProductFA ltfc ")
			   .append(" left join DimProduct product on ltfc.ProductKey = product.ProductKey");
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
			    	sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
					   .append(form.getQuarterFrom()).append("'")
					   .append(" and '").append(form.getQuarterTo()).append("'");
				}
				//month
				else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ltfc.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//overview chart:Region or Odm
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
			
			sBuffer.append(" group by ltfc.ProductKey,product.ProductEnglishName,ltfc.OrderQty having ltfc.ProductKey != '' order by OrderQty desc");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchDimensions(SearchFaForm form) {
		PagerInformation pagerInfo = form.getPagerInfo();
		String ltfcVersion=form.getLtfcVersion();
		String mapsVersion=form.getMpsVersion();
		StringBuffer sBuffer = new StringBuffer();
		
		//for Family overview chart
		if("Family".equals(form.getDashboardType())) {
		    sBuffer.append("select productFamily.familyKey as objKey,productFamily.familyName as objName,'Family' as type")
		    		.append(" from FactMonthlySummaryofLTFCFA ltfc ")
		    		.append(" left join (")
		    		.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName as familyName from DimProduct product")
		    		.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
		    		.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
		
	    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
	    		.append(" and ltfc.Month = ").append(form.getMonth());
	    	sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
			//dodo
			sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			
			sBuffer.append(" group by productFamily.familyKey,productFamily.familyName having productFamily.familyKey != ''");
			
			sBuffer.append(" order by productFamily.familyName asc ");
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
		    sBuffer.append("select ltfc.ODMKey as objKey,odm.ODMEnglishName as objName,'Odm' as type")
		    .append(" from FactMonthlySummaryofLTFCFA ltfc ")
		    .append(" left join DimODM odm on ltfc.ODMKey = odm.ODMKey");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" join (")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
				sBuffer.append(" where family.ProductFamilyKey in (").append(form.getFamilyIds()).append(")");
				sBuffer.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			sBuffer.append(" where ltfc.Year = ").append(form.getYear())
    		.append(" and ltfc.Month = ").append(form.getMonth());
			sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
			//dodo
			sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			
			sBuffer.append(" group by ltfc.ODMKey,odm.ODMEnglishName having ltfc.ODMKey != ''");
			
			sBuffer.append(" order by odm.ODMEnglishName asc ");
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
		    sBuffer.append("select ltfc.ProductKey as objKey,product.ProductEnglishName as objName,'Product' as type")
		    .append(" from FactMonthlySummaryofLTFCFA ltfc ")
		    .append(" left join DimProduct product on ltfc.ProductKey = product.ProductKey");
		    
		    if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append("  join (")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
				sBuffer.append(" where family.ProductFamilyKey in (").append(form.getFamilyIds()).append(")");
				sBuffer.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			
		    sBuffer.append(" where ltfc.Year = ").append(form.getYear())
    		.append(" and ltfc.Month = ").append(form.getMonth());
		    sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
			//dodo
			sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			
			sBuffer.append(" group by ltfc.ProductKey,product.ProductEnglishName having ltfc.ProductKey != ''");
			
			sBuffer.append(" order by product.ProductEnglishName asc ");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}
	
	public String isNullLTFC(String version){
		return " ISNULL(ltfc.["+version+"DaysLTFCQty],0) ";
	}
	
	public String isNullMPS(String version){
		return " ISNULL(ltfc.["+version+"DaysMPSQty],0) ";
	}
	
	public String isNullMPSForOrderDetail(String version){
		return " ISNULL(ltfc.["+version+"DaysMPSQty],'') ";
	}
	
	private String isNullOrder(){
		return " ISNULL(ltfc.OrderQty,0) ";
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<LTFCRemarkChartData> fetchLtfcRemarkChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		String ltfcVersion=form.getLtfcVersion();
		String mapsVersion=form.getMpsVersion();
		String ltfcIsNull=isNullLTFC(ltfcVersion);
		String mpsIsNull=isNullMPS(mapsVersion);
		String orderIsNull=isNullOrder();
		if(LtfcTypeEnum.Mps.getTypeName().equals(form.getLtfcType())) {
			sBuffer.append("select top 15 sum(case when "+ltfcIsNull+" > "+mpsIsNull+" then "+ltfcIsNull+" else "+mpsIsNull+" end) as maxQTY, sum(case when "+ltfcIsNull+" < "+mpsIsNull+" then "+ltfcIsNull+" else "+mpsIsNull+" end) as minQTY,");
		}
		else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
			sBuffer.append("select top 15 sum(case when "+ltfcIsNull+" > "+orderIsNull+" then "+ltfcIsNull+" else "+orderIsNull+" end) as maxQTY, sum(case when "+ltfcIsNull+" < "+orderIsNull+" then "+ltfcIsNull+" else "+orderIsNull+" end) as minQTY,");
		}
		
		//for Product remark chart
		if("Product".equals(form.getDimension())) {
			sBuffer.append(" ltfc.ProductKey as subDimensionKey,product.ProductEnglishName as subDimensionName ")
					.append(" from FactMonthlySummaryofLTFCFA ltfc ")
					.append(" join DimProduct product on ltfc.ProductKey=product.ProductKey ");
			if(form.getDashboardTypeKey() != -1) {
				if("Family".equals(form.getDashboardType())) {//ä¸�ä¼šä¸ŽFamilyIdså†²çª�,å› ä¸ºdashboardTypeæ˜¯Familysæ—¶,ä¸�ä¼šæœ‰FamilyIdè¿™ä¸ªé€‰é¡¹
					sBuffer.append("  join ( ")
							.append(" select product.ProductKey from DimProduct product ")
							.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey ")
							.append(" where family.ProductFamilyKey = ").append(form.getDashboardTypeKey())
							.append(" ) productFamily on ltfc.ProductKey = productFamily.ProductKey ");
				}
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Family".equals(form.getCrossMonthType())) {
					sBuffer.append(" join (")
							.append("select product.ProductKey from DimProduct product")
							.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
							.append(" where family.ProductFamilyKey =").append(form.getCrossMonthTypeKey())
							.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
				}
			}
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" join (")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(" where family.ProductFamilyKey in ( ").append(form.getFamilyIds()+") ")
				.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'")
				   .append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
			    	sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			}
			
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
			
			sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
			
			//dodo
			sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			
			sBuffer.append(" group by ltfc.ProductKey,product.ProductEnglishName having product.ProductEnglishName<>'' ");
		}
		//for Odm remark chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append("ltfc.ODMKey as subDimensionKey,odm.ODMEnglishName as subDimensionName")
			.append(" from FactMonthlySummaryofLTFCFA ltfc")
			.append(" left join DimODM odm on ltfc.ODMKey=odm.ODMKey");
			
			
			//ä¸‹é�¢éœ€è¦�ç”¨FamilyIdsä½œä¸ºæ�¡ä»¶
			if(form.getDashboardTypeKey() != -1) {
				if("Family".equals(form.getDashboardType())) {
					sBuffer.append(" join ( ")
							.append("select product.ProductKey from DimProduct product")
							.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
							.append(" where family.ProductFamilyKey =").append(form.getDashboardTypeKey())
							.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
				}
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Family".equals(form.getCrossMonthType())) {
					sBuffer.append(" join (")
							.append("select product.ProductKey from DimProduct product")
							.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
							.append(" where family.ProductFamilyKey =").append(form.getCrossMonthTypeKey())
							.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
				}
			}
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" join (")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(" where family.ProductFamilyKey in ( ").append(form.getFamilyIds()+") ")
				.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'")
				   .append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
			    	sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			}
			
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
			
			//dodo
			sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			
			sBuffer.append(" group by ltfc.ODMKey,odm.ODMEnglishName having odm.ODMEnglishName <>'' ");
		}
		//for Family remark chart, and overview chart maybe ODM or Region
		else if("Family".equals(form.getDimension())) {
			sBuffer.append("productFamily.familyKey as subDimensionKey,productFamily.productFamilyEnglishName as subDimensionName")
					.append(" from FactMonthlySummaryofLTFCFA ltfc")
					.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyEnglishName as productFamilyEnglishName,family.ProductFamilyKey as familyKey")
					.append(" from DimProduct product join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
				
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			sBuffer.append(")productFamily on ltfc.ProductKey = productFamily.productKey");
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'")
				   .append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
			    	sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			}
			
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
			
			sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
			
			//dodo
			sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			
			sBuffer.append(" group by productFamily.familyKey,productFamily.productFamilyEnglishName having productFamily.familyKey != ''");
		}
		
		if(LtfcTypeEnum.Mps.getTypeName().equals(form.getLtfcType())) {
			sBuffer.append(" order by isnull( ( sum ( case when "+ltfcIsNull+" < "+mpsIsNull+" then "+ltfcIsNull+" else "+mpsIsNull+" end ) / cast (nullif(sum ( case when "+ltfcIsNull+" > "+mpsIsNull+" then "+ltfcIsNull+" else "+mpsIsNull+" end ),0) as NUMERIC(15,2) ) ),0) desc ");
			
		}
		else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
			sBuffer.append(" order by isnull( ( sum ( case when "+ltfcIsNull+" < "+orderIsNull+" then "+ltfcIsNull+" else "+orderIsNull+" end ) / cast (nullif(sum ( case when "+ltfcIsNull+" > "+orderIsNull+" then "+ltfcIsNull+" else "+orderIsNull+" end ),0) as NUMERIC(15,2) ) ),0) desc ");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("subDimensionName", StringType.INSTANCE)
				.addScalar("minQTY", IntegerType.INSTANCE)
				.addScalar("maxQTY", IntegerType.INSTANCE)
				.addScalar("subDimensionKey", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(LTFCRemarkChartData.class));
		
		return query.list();
	}
	
	@Override
	public Integer fetchToltalDimensionFAData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		if(LtfcTypeEnum.Mps.getTypeName().equals(form.getLtfcType())) {
			sBuffer.append("select case when sum(ltfc.[90DaysForecastQty])+sum([60DaysForecastQty])+sum([30DaysForecastQty]) is null then 0")
					.append(" else sum(ltfc.[90DaysForecastQty])+sum([60DaysForecastQty])+sum([30DaysForecastQty])")
					.append(" end as totalFaValue");
		}
		else if(LtfcTypeEnum.Outlook.getTypeName().equals(form.getLtfcType())) {
			sBuffer.append("select case when sum(ltfc.SCOutLookQty) is null then 0")
					.append(" else sum(ltfc.SCOutLookQty)")
					.append(" end as totalFaValue");
		}
		else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
			sBuffer.append("select case when sum(ltfc.OrderQty) is null then 0")
					.append(" else sum(ltfc.OrderQty)")
					.append(" end as totalFaValue");
		}
		
		//for region remark chart
		if("Product".equals(form.getDimension())) {
			sBuffer.append(" from FactMonthlySummaryofProductFA ltfc")
				.append(" left join DimProduct product on ltfc.ProductKey=product.ProductKey");
			
			if(form.getDashboardTypeKey() != -1) {
				if("Family".equals(form.getDashboardType())) {
					sBuffer.append(" left join (")
							.append("select product.ProductKey from DimProduct product")
							.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
							.append(" where family.ProductFamilyKey =").append(form.getDashboardTypeKey())
							.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
				}
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Family".equals(form.getCrossMonthType())) {
					sBuffer.append(" left join (")
							.append("select product.ProductKey from DimProduct product")
							.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
							.append(" where family.ProductFamilyKey =").append(form.getCrossMonthTypeKey())
							.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
				}
			}
			
			//quarter
			if(form.isShowQuarterOverview()) {
		    	sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
		    		.append(" and ltfc.Month = ").append(form.getMonth());
			}
			sBuffer.append(" and ltfc.ProductKey != ''");
			
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
		}
		//for Odm remark chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" from FactMonthlySummaryofProductFA ltfc")
				.append(" left join DimODM odm on ltfc.ODMKey=odm.ODMKey");
			
			if(form.getDashboardTypeKey() != -1) {
				if("Family".equals(form.getDashboardType())) {
					sBuffer.append(" left join (")
							.append("select product.ProductKey from DimProduct product")
							.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
							.append(" where family.ProductFamilyKey =").append(form.getDashboardTypeKey())
							.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
				}
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Family".equals(form.getCrossMonthType())) {
					sBuffer.append(" left join (")
							.append("select product.ProductKey from DimProduct product")
							.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
							.append(" where family.ProductFamilyKey =").append(form.getCrossMonthTypeKey())
							.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
				}
			}
			//quarter
			if(form.isShowQuarterOverview()) {
		    	sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
		    		.append(" and ltfc.Month = ").append(form.getMonth());
			}
			
			sBuffer.append(" and ltfc.ODMKey != ''");
			
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
		}
		//for Family remark chart, and overview chart maybe ODM or Region
		else if("Family".equals(form.getDimension())) {
				sBuffer.append(" from FactMonthlySummaryofProductFA ltfc")
					.append(" left join (")
					.append("select product.ProductKey as productKey")
					.append(" from DimProduct product join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
				if(!StringUtil.isEmpty(form.getFamilyIds())) {
					sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
				}
				sBuffer.append(")productFamily on ltfc.ProductKey = productFamily.productKey");
			
			//quarter
			if(form.isShowQuarterOverview()) {
		    	sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
		    		.append(" and ltfc.Month = ").append(form.getMonth());
			}
			sBuffer.append(" and ltfc.ProductKey != ''");
			
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		
		if(LtfcTypeEnum.Mps.getTypeName().equals(form.getLtfcType())) {
			sBuffer.append(" order by sum(ltfc.[90DaysForecastQty])+sum([60DaysForecastQty])+sum([30DaysForecastQty]) asc");
		}
		else if(LtfcTypeEnum.Outlook.getTypeName().equals(form.getLtfcType())) {
			sBuffer.append(" order by sum(ltfc.SCOutLookQty) asc");
		}
		else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
			sBuffer.append(" order by sum(ltfc.OrderQty) asc");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> fetchLtfcDashboardOverViewChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		String ltfcVersion=form.getLtfcVersion();
		String mapsVersion=form.getMpsVersion();
		String ltfcIsNull=isNullLTFC(ltfcVersion);
		String mpsIsNull=isNullMPS(mapsVersion);
		String orderIsNull=isNullOrder();
		String condition=getDashboardOverviewCondition(form);
		sBuffer.append("select sum(case when ltfc.["+ltfcVersion+"DaysLTFCQty] is null then 0 else ltfc.["+ltfcVersion+"DaysLTFCQty] end)  as typeValue, ")
		   		.append("'Ltfc' as typeName")
		   		.append(" from FactMonthlySummaryofLTFCFA ltfc");
		
		sBuffer.append(condition);
		
		sBuffer.append(" union ");
		
//		if(LtfcTypeEnum.Mps.getTypeName().equals(form.getLtfcType())) {
		sBuffer.append("select sum(case when ltfc.["+mapsVersion+"DaysMPSQty] is null then 0 else ltfc.["+mapsVersion+"DaysMPSQty] end)  as typeValue, ")
	   		.append("'Mps' as typeName")
	   		.append(" from FactMonthlySummaryofLTFCFA ltfc");
			
		sBuffer.append(condition);
		
		sBuffer.append(" union ");
			
		sBuffer.append(" select sum(case when ltfc.OrderQty is null then 0 else ltfc.OrderQty end)  as typeValue, ")
			    	.append("'Order' as typeName ")
			    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		
		sBuffer.append(condition);
		
		sBuffer.append(" union ");
		
		
		String minRemarkMPS=" sum(case when "+ltfcIsNull+" < "+mpsIsNull+" then "+ltfcIsNull+" else "+mpsIsNull+" end)  ";
		sBuffer.append("select case when "+minRemarkMPS+" is null then 0 else "+minRemarkMPS+" end  as typeValue, ")
				.append("'minRemarkMPS' as typeName ")
				.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		
		sBuffer.append(condition);		
			
		sBuffer.append(" union ");
		
		//else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
		String maxRemarkMPS=" sum(case when "+ltfcIsNull+" > "+mpsIsNull+" then "+ltfcIsNull+" else "+mpsIsNull+" end) ";
			sBuffer.append("select case when "+maxRemarkMPS+" is null then 0 else "+maxRemarkMPS+" end  as typeValue, ")
	    	.append("'maxRemarkMPS' as typeName ")
	    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
			
		sBuffer.append(condition);
		
		sBuffer.append(" union ");
		
		String minRemarkOrder=" sum(case when "+ltfcIsNull+" < "+orderIsNull+" then "+ltfcIsNull+" else "+orderIsNull+" end)  ";
			sBuffer.append("select case when "+minRemarkOrder+" is null then 0 else "+minRemarkOrder+" end  as typeValue, ")
					.append("'minRemarkOrder' as typeName ")
					.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		
		sBuffer.append(condition);	
		
		sBuffer.append(" union ");
		
		String maxRemarkOrder=" sum(case when "+ltfcIsNull+" > "+orderIsNull+" then "+ltfcIsNull+" else "+orderIsNull+" end) ";
			sBuffer.append("select case when "+maxRemarkOrder+" is null then 0 else "+maxRemarkOrder+" end  as typeValue, ")
	    	.append("'maxRemarkOrder' as typeName ")
	    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
			
		sBuffer.append(condition);
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("typeName", StringType.INSTANCE)
				.addScalar("typeValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		
		return query.list();
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> fetchLtfcCrossMonthOverviewChartData(SearchFaForm form) {
		String ltfcVersion=form.getLtfcVersion();
		String mapsVersion=form.getMpsVersion();
		StringBuffer sBuffer = new StringBuffer();
		String ltfcIsNull=isNullLTFC(ltfcVersion);
		String mpsIsNull=isNullMPS(mapsVersion);
		String orderIsNull=isNullOrder();
		String condition=getCrossMonthOverviewCondition(form);
		String sumLtfc=" sum(case when ltfc.["+ltfcVersion+"DaysLTFCQty] is null then 0 else ltfc.["+ltfcVersion+"DaysLTFCQty] end) ";
		
		sBuffer.append("select case when "+sumLtfc+" is null then 0 else "+sumLtfc+" end  as typeValue, ")
   		.append("'Ltfc' as typeName")
   		.append(" from FactMonthlySummaryofLTFCFA ltfc");
		
		sBuffer.append(condition);
		
		sBuffer.append(" union ");
		
		//if(LtfcTypeEnum.Mps.getTypeName().equals(form.getLtfcType())) {
			String mpsLtfc=" sum(case when ltfc.["+mapsVersion+"DaysMPSQty] is null then 0 else ltfc.["+mapsVersion+"DaysMPSQty] end) ";
			sBuffer.append("select case when "+mpsLtfc+" is null then 0 else "+mpsLtfc+" end  as typeValue, ")
	   		.append("'Mps' as typeName")
	   		.append(" from FactMonthlySummaryofLTFCFA ltfc");
			
		sBuffer.append(condition);	
		
		sBuffer.append(" union ");
		
		//else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
			String orderLtfc=" sum(case when ltfc.OrderQty is null then 0 else ltfc.OrderQty end) ";
			sBuffer.append("select case when "+orderLtfc+" is null then 0 else "+orderLtfc+" end  as typeValue, ")
	    	.append("'Order' as typeName ")
	    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
			
		sBuffer.append(condition);		
		
		sBuffer.append(" union ");
		
		//else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
		String minRemarkMPS=" sum(case when "+ltfcIsNull+" < "+mpsIsNull+" then "+ltfcIsNull+" else "+mpsIsNull+" end)  ";
			sBuffer.append("select case when "+minRemarkMPS+" is null then 0 else "+minRemarkMPS+" end  as typeValue, ")
					.append("'minRemarkMPS' as typeName ")
					.append(" from FactMonthlySummaryofLTFCFA ltfc ");
			
		sBuffer.append(condition);		
			
		sBuffer.append(" union ");
		
		//else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
		String maxRemarkMPS=" sum(case when "+ltfcIsNull+" > "+mpsIsNull+" then "+ltfcIsNull+" else "+mpsIsNull+" end) ";
			sBuffer.append("select case when "+maxRemarkMPS+" is null then 0 else "+maxRemarkMPS+" end  as typeValue, ")
	    	.append("'maxRemarkMPS' as typeName ")
	    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
			
		sBuffer.append(condition);
		
		sBuffer.append(" union ");
		
		String minRemarkOrder=" sum(case when "+ltfcIsNull+" < "+orderIsNull+" then "+ltfcIsNull+" else "+orderIsNull+" end)  ";
			sBuffer.append("select case when "+minRemarkOrder+" is null then 0 else "+minRemarkOrder+" end  as typeValue, ")
					.append("'minRemarkOrder' as typeName ")
					.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		
		sBuffer.append(condition);	
		
		sBuffer.append(" union ");
		
		String maxRemarkOrder=" sum(case when "+ltfcIsNull+" > "+orderIsNull+" then "+ltfcIsNull+" else "+orderIsNull+" end) ";
			sBuffer.append("select case when "+maxRemarkOrder+" is null then 0 else "+maxRemarkOrder+" end  as typeValue, ")
	    	.append("'maxRemarkOrder' as typeName ")
	    	.append(" from FactMonthlySummaryofLTFCFA ltfc ");
			
		sBuffer.append(condition);	
				
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("typeName", StringType.INSTANCE)
				.addScalar("typeValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> getOverviewOverall(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select OrderQty as orderNum")
			   .append(" from FactMonthlySummaryofProductFA ltfc")
			   .append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		
		//crossmonth overview chart:Region or Odm or Product
		if(form.getCrossMonthTypeKey() != -1) {
			if("Region".equals(form.getCrossMonthType()))
				sBuffer.append(" and ltfc.RegionKey = ").append(form.getCrossMonthTypeKey());
			else if("Odm".equals(form.getCrossMonthType()))
				sBuffer.append(" and ltfc.ODMKey = ").append(form.getCrossMonthTypeKey());
			else if("Product".equals(form.getCrossMonthType()))
				sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> getFaCrossMonthPieChart(SearchFaForm form) {
		StringBuilder sBuffer = new StringBuilder();
		String ltfcVersion=form.getLtfcVersion();
		String mpsVersion=form.getMpsVersion();
		String isNullLtfc=isNullLTFC(ltfcVersion);
		String isNullMps=isNullMPS(mpsVersion);
		String isNullOrder=isNullOrder();
		if("Mps".equals(form.getLtfcType())){
			sBuffer.append("select rowname,value from")
			.append("(select sum(case when "+isNullMps+" > "+isNullLtfc+" then 1 else 0 end) as [under plan],")
			.append("sum(case when "+isNullMps+" < "+isNullLtfc+" then 1 else 0 end) as [over plan],")
			.append("sum(case when "+isNullMps+" = "+isNullLtfc+" then 1 else 0 end) as [equal plan] ")
			.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		}else{
			sBuffer.append("select rowname,value from")
			.append("(select sum(case when "+isNullOrder+" > "+isNullLtfc+" then 1 else 0 end) as [under plan],")
			.append("sum(case when "+isNullOrder+" < "+isNullLtfc+" then 1 else 0 end) as [over plan],")
			.append("sum(case when "+isNullOrder+" = "+isNullLtfc+" then 1 else 0 end) as [equal plan] ")
			.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		}
			
			if("Family".equals(form.getCrossMonthType())) {
				sBuffer.append(" join ( ")
						.append("select product.ProductKey from DimProduct product")
						.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
						.append(" where family.ProductFamilyKey =").append(form.getCrossMonthTypeKey())
						.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
				
				if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
					sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
					   .append(form.getStartDate()).append("'")
					   .append(" and '").append(form.getEndDate()).append("'");
				else {
				    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
				    		.append(" and ltfc.Month = ").append(form.getMonth());
				}
				
				sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
				
				sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mpsVersion+"DaysMPSQty]>0) ");
				 //dodo
				 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
				if(!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
				}
				
				if(!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
				}
				
			}
			
			if("Odm".equals(form.getCrossMonthType())){
				if(!StringUtil.isEmpty(form.getFamilyIds())) {
					sBuffer.append(" join (")
					.append("select product.ProductKey from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(" where family.ProductFamilyKey in ( ").append(form.getFamilyIds()+") ")
					.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
				}
				if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
					sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
					   .append(form.getStartDate()).append("'")
					   .append(" and '").append(form.getEndDate()).append("'");
				else {
				    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
				    		.append(" and ltfc.Month = ").append(form.getMonth());
				}
				sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
				
				sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mpsVersion+"DaysMPSQty]>0) ");
				 //dodo
				 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
				sBuffer.append(" and ltfc.ODMKey = ").append(form.getCrossMonthTypeKey());
				
				if(!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
				}
				
			}
			
			if("Product".equals(form.getCrossMonthType())){
				if(!StringUtil.isEmpty(form.getFamilyIds())) {
					sBuffer.append(" join (")
					.append("select product.ProductKey from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(" where family.ProductFamilyKey in ( ").append(form.getFamilyIds()+") ")
					.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
				}
				
				if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
					sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
					   .append(form.getStartDate()).append("'")
					   .append(" and '").append(form.getEndDate()).append("'");
				else {
				    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
				    		.append(" and ltfc.Month = ").append(form.getMonth());
				}
				sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
				
				sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mpsVersion+"DaysMPSQty]>0) ");
				
				 //dodo
				 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
				sBuffer.append(" and ltfc.ProductKey = ").append(form.getCrossMonthTypeKey());
				
				if(!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
				}
				
			}
		
					
		sBuffer.append(" ) p ")
			.append("UNPIVOT (value for rowname in([under plan],[over plan],[equal plan])) p");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
			.addScalar("value", IntegerType.INSTANCE)
			.addScalar("rowName", StringType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> getFaDashboardPieChart(SearchFaForm form) {
		StringBuilder sBuffer = new StringBuilder();
		String ltfcVersion=form.getLtfcVersion();
		String mpsVersion=form.getMpsVersion();
		String isNullLtfc=isNullLTFC(ltfcVersion);
		String isNullMps=isNullMPS(mpsVersion);
		String isNullOrder=isNullOrder();
		if("Mps".equals(form.getLtfcType())){
			sBuffer.append("select rowname,value from")
			.append("(select sum(case when "+isNullMps+" > "+isNullLtfc+" then 1 else 0 end) as [under plan],")
			.append("sum(case when "+isNullMps+" < "+isNullLtfc+" then 1 else 0 end) as [over plan],")
			.append("sum(case when "+isNullMps+" = "+isNullLtfc+" then 1 else 0 end) as [equal plan] ")
			.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		}else{
			sBuffer.append("select rowname,value from")
			.append("(select sum(case when "+isNullOrder+" > "+isNullLtfc+" then 1 else 0 end) as [under plan],")
			.append("sum(case when "+isNullOrder+" < "+isNullLtfc+" then 1 else 0 end) as [over plan],")
			.append("sum(case when "+isNullOrder+" = "+isNullLtfc+" then 1 else 0 end) as [equal plan] ")
			.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		}
		if(form.getDashboardTypeKey() != -1) {
			if("Family".equals(form.getDashboardType())) {//ä¸�ä¼šä¸ŽFamilyIdså†²çª�,å› ä¸ºdashboardTypeæ˜¯Familysæ—¶,ä¸�ä¼šæœ‰FamilyIdè¿™ä¸ªé€‰é¡¹
			sBuffer.append("  join ( ")
					.append(" select product.ProductKey from DimProduct product ")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey ")
					.append(" where family.ProductFamilyKey = ").append(form.getDashboardTypeKey())
					.append(" ) productFamily on ltfc.ProductKey = productFamily.ProductKey ");
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
			}
			sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			
			sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mpsVersion+"DaysMPSQty]>0) ");
			 //dodo
			 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}	
		}
		
		if("Product".equals(form.getDashboardType())) {
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" join (")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(" where family.ProductFamilyKey in ( ").append(form.getFamilyIds()+") ")
				.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
			}
			sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			
			sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mpsVersion+"DaysMPSQty]>0) ");
			
			 //dodo
			 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			sBuffer.append(" and ltfc.ProductKey = ").append(form.getDashboardTypeKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			
		}
		
		if("Odm".equals(form.getDashboardType())) {
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" join (")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(" where family.ProductFamilyKey in ( ").append(form.getFamilyIds()+") ")
				.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
			}
			sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			
			sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mpsVersion+"DaysMPSQty]>0) ");
			 //dodo
			 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			sBuffer.append(" and ltfc.ODMKey = ").append(form.getDashboardTypeKey());
			
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
		}
		
		}else{
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" join (")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(" where family.ProductFamilyKey in ( ").append(form.getFamilyIds()+") ")
				.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
				sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			else {
			    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
			    		.append(" and ltfc.Month = ").append(form.getMonth());
			}
			sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
			
			sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mpsVersion+"DaysMPSQty]>0) ");
			 //dodo
			 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			
		}	
			
		sBuffer.append(" ) p ")
			.append("UNPIVOT (value for rowname in([under plan],[over plan],[equal plan])) p");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
			.addScalar("value", IntegerType.INSTANCE)
			.addScalar("rowName", StringType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		return query.list();
	}
	
	@Override
	public int getDashboardOrderDetailCount(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		String ltfcVersion=form.getLtfcVersion();
		String ltfcType=form.getLtfcType();
		String mapsVersion=form.getMpsVersion();
		String isNullLtfc=isNullLTFC(ltfcVersion);
		String isNullMps=isNullMPS(mapsVersion);
		String isNullOrder=isNullOrder();
		sBuffer.append("select count(*) as orderNum")
		   .append(" from FactMonthlySummaryofLTFCFA ltfc")
		   .append(" left join ( ")
		   .append(" select product.ProductKey,family.ProductFamilyKey from DimProduct product " )
		   .append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
		   .append(" ) productFamily on ltfc.ProductKey = productFamily.ProductKey ");
		   
		sBuffer.append(" where ltfc.Year = ").append(form.getYear())
				.append(" and ltfc.Month = ").append(form.getMonth());
		sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
		
		sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
		
		 //dodo
		 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
		 
		 if("Mps".equals(ltfcType)){
			 if("over plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" > "+isNullMps);
			 }else if("equal plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" = "+isNullMps);
			 }else if("under plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" < "+isNullMps);
			 }	
		 }else{
			 if("over plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" > "+isNullOrder);
			 }else if("equal plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" = "+isNullOrder);
			 }else if("under plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" < "+isNullOrder);
			 }	
		 }
		 
			//for Odm overview chart
		    if("Odm".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ltfc.ODMKey = ").append(form.getOverViewSubDimensionKey());
				
				if(!StringUtil.isEmpty(form.getFamilyIds())) {
					sBuffer.append(" and productFamily.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
				}
			}
			//for Product overview chart
			else if("Product".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ltfc.ProductKey = ").append(form.getOverViewSubDimensionKey());
				
				if(!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getFamilyIds())) {
					sBuffer.append(" and productFamily.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
				}
			}
		    
			else if("Family".equals(form.getOverViewDimension())){
				if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and productFamily.ProductFamilyKey = ").append(form.getOverViewSubDimensionKey());
				
				if(!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
				}
			}
			
			//for Region remark chart
			if("Family".equals(form.getRemarkDimension())) {
				sBuffer.append(" and productFamily.ProductFamilyKey = ").append(form.getRemarkSubDimensionKey());
			}
			//for Odm remark chart
			else if("Odm".equals(form.getRemarkDimension())) {
				sBuffer.append(" and ltfc.ODMKey = ").append(form.getRemarkSubDimensionKey());
			}
			//for Product remark chart
			else if("Product".equals(form.getRemarkDimension())) {
				sBuffer.append(" and ltfc.ProductKey = ").append(form.getRemarkSubDimensionKey());
			}
			
		 	
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}


	@Override
	public List<LTFCDetailView> getDashboardOrderDetail(
			SearchFaForm form) {
		String ltfcVersion=form.getLtfcVersion();
		String mapsVersion=form.getMpsVersion();
		String ltfcType=form.getLtfcType();
		String isNullLtfc=isNullLTFC(ltfcVersion);
		String isNullMps=isNullMPS(mapsVersion);
		String isNullOrder=isNullOrder();
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append(" select ltfc.month,dimODM.ODMEnglishName as odm,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("ltfc.orderQty ,")
				.append("ltfc.["+ltfcVersion+"DaysLTFCQty] as ltfcQty,")
				.append("ltfc.["+mapsVersion+"DaysMPSQty] as mpsQty,")
				.append("productFamily.ProductFamilyEnglishName as family,");
		if("Mps".equals(ltfcType)){
			sBuffer	.append("case when ltfc.["+ltfcVersion+"DaysLTFCQty] > ltfc.["+mapsVersion+"DaysMPSQty]  then 'over plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] = ltfc.["+mapsVersion+"DaysMPSQty] then 'equal plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] < ltfc.["+mapsVersion+"DaysMPSQty] then 'under plan' else '' end as rootCause,")
					.append(getOrderByConditionMps(ltfcVersion,mapsVersion) +" as ltfcVsMps ");
		}else{
			sBuffer	.append("case when ltfc.["+ltfcVersion+"DaysLTFCQty] > ltfc.OrderQty  then 'over plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] = ltfc.OrderQty then 'equal plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] < ltfc.OrderQty then 'under plan' else '' end as rootCause,")
					.append(getOrderByConditionOrder(ltfcVersion)+" as ltfcVsOrder ");
		}
		sBuffer	.append(" from FactMonthlySummaryofLTFCFA ltfc ")
				.append(" left join DimProduct dimProduct on ltfc.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ltfc.ODMKey = dimODM.ODMKey")
				.append(" left join ( ")
				.append(" select   product.ProductKey as productKey,   family.ProductFamilyEnglishName ,   family.ProductFamilyKey   from DimProduct product   join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey ) as productFamily ")
				.append(" on ltfc.ProductKey=productFamily.ProductKey ");
		
		sBuffer.append(" where ltfc.Year = ").append(form.getYear())
		 			.append(" and ltfc.Month = ").append(form.getMonth());
		sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
		
		sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
		
		 //dodo
		 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
		
		 if("Mps".equals(ltfcType)){
			 if("over plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" > "+isNullMps);
			 }else if("equal plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" = "+isNullMps);
			 }else if("under plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" < "+isNullMps);
			 }	
		 }else{
			 if("over plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" > "+isNullOrder);
			 }else if("equal plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" = "+isNullOrder);
			 }else if("under plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" < "+isNullOrder);
			 }	
		 }
		
		//for Odm overview chart
	    if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ltfc.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ltfc.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
		}
	    
		else if("Family".equals(form.getOverViewDimension())){
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and productFamily.ProductFamilyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Family".equals(form.getRemarkDimension())) {
			sBuffer.append(" and productFamily.ProductFamilyKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ltfc.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ltfc.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			if("rootCause".equalsIgnoreCase(form.getSortColumn())){
				if("Mps".equals(ltfcType)){
					sBuffer.append(" order by ").append("(case when "+isNullLtfc+" > "+isNullMps+"  then 'over plan' when "+isNullLtfc+" = "+isNullMps+"  then 'equal plan' when "+isNullLtfc+" < "+isNullMps+"  then 'under plan' else '' end)").append(form.getSortType());
				}else{
					sBuffer.append(" order by ").append("(case when "+isNullLtfc+" > "+isNullOrder+" then 'over plan' when "+isNullLtfc+" = "+isNullOrder+" then 'equal plan' when "+isNullLtfc+" < "+isNullOrder+" then 'under plan' else '' end)").append(form.getSortType());
				}
			}else if("ltfcVsOrder".equalsIgnoreCase(form.getSortColumn())){
				sBuffer.append(" order by ").append(getOrderByConditionOrder(ltfcVersion)).append(form.getSortType());
			}else if("ltfcVsMps".equalsIgnoreCase(form.getSortColumn())){
				sBuffer.append(" order by ").append(getOrderByConditionMps(ltfcVersion,mapsVersion)).append(form.getSortType());
			}else{
				sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType());
			}
		}
		
		SQLQuery query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("month", StringType.INSTANCE)
				.addScalar("rootCause", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE);
			if("Mps".equals(ltfcType)){
				query.addScalar("ltfcVsMps",StringType.INSTANCE);
			}else{
				query.addScalar("ltfcVsOrder",StringType.INSTANCE);
			}
		   query.addScalar("family", StringType.INSTANCE)
		   		.addScalar("orderQty", StringType.INSTANCE)
				.addScalar("ltfcQty", StringType.INSTANCE)
				.addScalar("mpsQty", StringType.INSTANCE).
				setResultTransformer(Transformers.aliasToBean(LTFCDetailView.class));
		query.setFirstResult((form.getCurrentPage()-1)*SysConfig.NUMBER_OF_ROW_COUNT);
		query.setMaxResults(SysConfig.NUMBER_OF_ROW_COUNT);
		return query.list();
		
	}
	
	@Override
	public List<LTFCDetailView> getAllOrderDetail(SearchFaForm form) {
		String ltfcVersion = form.getLtfcVersion();
		String mapsVersion = form.getMpsVersion();
		String isNullLtfc=isNullLTFC(ltfcVersion);
		String isNullMps=isNullMPS(mapsVersion);
		String isNullOrder=isNullOrder();
		String ltfcType=form.getLtfcType();
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append(" select ltfc.month,dimODM.ODMEnglishName as odm,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("ltfc.orderQty ,")
				.append("ltfc.[" + ltfcVersion + "DaysLTFCQty] as ltfcQty,")
				.append("ltfc.[" + mapsVersion + "DaysMPSQty] as mpsQty,")
				.append("productFamily.ProductFamilyEnglishName as family,");
		if("Mps".equals(ltfcType)){
			sBuffer	.append("case when ltfc.["+ltfcVersion+"DaysLTFCQty] > ltfc.["+mapsVersion+"DaysMPSQty]  then 'over plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] = ltfc.["+mapsVersion+"DaysMPSQty] then 'equal plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] < ltfc.["+mapsVersion+"DaysMPSQty] then 'under plan' else '' end as rootCause,")
					.append(getOrderByConditionMps(ltfcVersion,mapsVersion) +" as ltfcVsMps ");
		}else{
			sBuffer	.append("case when ltfc.["+ltfcVersion+"DaysLTFCQty] > ltfc.OrderQty  then 'over plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] = ltfc.OrderQty then 'equal plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] < ltfc.OrderQty then 'under plan' else '' end as rootCause,")
					.append(getOrderByConditionOrder(ltfcVersion)+" as ltfcVsOrder ");
		}
		
		 sBuffer.append(" from FactMonthlySummaryofLTFCFA ltfc ")
				.append(" left join DimProduct dimProduct on ltfc.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ltfc.ODMKey = dimODM.ODMKey")
				.append(" left join ( ")
				.append(" select   product.ProductKey as productKey,   family.ProductFamilyEnglishName ,   family.ProductFamilyKey   from DimProduct product   join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey ) as productFamily ")
				.append(" on ltfc.ProductKey=productFamily.ProductKey ");
		
		sBuffer.append(" where ltfc.Year = ").append(form.getYear())
				.append(" and ltfc.Month = ").append(form.getMonth());
		sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
		
		sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
		
		 //dodo
		 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
		
		 if("Mps".equals(ltfcType)){
			 if("over plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" > "+isNullMps);
			 }else if("equal plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" = "+isNullMps);
			 }else if("under plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" < "+isNullMps);
			 }	
		 }else{
			 if("over plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" > "+isNullOrder);
			 }else if("equal plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" = "+isNullOrder);
			 }else if("under plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" < "+isNullOrder);
			 }	
		 }
		
		if (form.getChartType().equals("remark")) {
			if (("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil
					.isEmpty(form.getSubDimension()))) {
				sBuffer.append(" and dimODM.ODMEnglishName = '"
						+ form.getSubDimension().toUpperCase() + "' ");
			} else if (("product".equalsIgnoreCase(form.getDimension()) && !StringUtil
					.isEmpty(form.getSubDimension()))) {
				sBuffer.append(" and dimProduct.ProductEnglishName = '"
						+ form.getSubDimension().toUpperCase() + "' ");
			} else if (("family".equalsIgnoreCase(form.getDimension()) && !StringUtil
					.isEmpty(form.getSubDimension()))) {
				sBuffer.append(" and productFamily.ProductFamilyEnglishName = '"
						+ form.getSubDimension().toUpperCase() + "' ");
			}
		} else if (ChartTypeEnum.Dashboard.getTypeName().equals(
				form.getChartType())
				|| ChartTypeEnum.CrossMonth.getTypeName().equals(
						form.getChartType())) {
			// for Odm overview chart
			if ("Odm".equals(form.getOverViewDimension())) {
				if (form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ltfc.ODMKey = ").append(
							form.getOverViewSubDimensionKey());

				if (!StringUtil.isEmpty(form.getFamilyIds())) {
					sBuffer.append(" and productFamily.ProductFamilyKey in(")
							.append(form.getFamilyIds()).append(")");
				}
				if (!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and ltfc.ProductKey in(")
							.append(form.getProductIds()).append(")");
				}
			}
			// for Product overview chart
			else if ("Product".equals(form.getOverViewDimension())) {
				if (form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ltfc.ProductKey = ").append(
							form.getOverViewSubDimensionKey());

				if (!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and ltfc.ODMKey in(")
							.append(form.getOdmIds()).append(")");
				}
				if (!StringUtil.isEmpty(form.getFamilyIds())) {
					sBuffer.append(" and productFamily.ProductFamilyKey in(")
							.append(form.getFamilyIds()).append(")");
				}
			}

			else if ("Family".equals(form.getOverViewDimension())) {
				if (form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and productFamily.ProductFamilyKey = ")
							.append(form.getOverViewSubDimensionKey());

				if (!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and ltfc.ODMKey in(")
							.append(form.getOdmIds()).append(")");
				}
				if (!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and ltfc.ProductKey in(")
							.append(form.getProductIds()).append(")");
				}
			}

			// for Region remark chart
			if ("Family".equals(form.getRemarkDimension())) {
				sBuffer.append(" and productFamily.ProductFamilyKey = ")
						.append(form.getRemarkSubDimensionKey());
			}
			// for Odm remark chart
			else if ("Odm".equals(form.getRemarkDimension())) {
				sBuffer.append(" and ltfc.ODMKey = ").append(
						form.getRemarkSubDimensionKey());
			}
			// for Product remark chart
			else if ("Product".equals(form.getRemarkDimension())) {
				sBuffer.append(" and ltfc.ProductKey = ").append(
						form.getRemarkSubDimensionKey());
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			if("rootCause".equalsIgnoreCase(form.getSortColumn())){
				if("Mps".equals(ltfcType)){
					sBuffer.append(" order by ").append("(case when "+isNullLtfc+" > "+isNullMps+"  then 'over plan' when "+isNullLtfc+" = "+isNullMps+"  then 'equal plan' when "+isNullLtfc+" < "+isNullMps+"  then 'under plan' else '' end)").append(form.getSortType());
				}else{
					sBuffer.append(" order by ").append("(case when "+isNullLtfc+" > "+isNullOrder+" then 'over plan' when "+isNullLtfc+" = "+isNullOrder+" then 'equal plan' when "+isNullLtfc+" < "+isNullOrder+" then 'under plan' else '' end)").append(form.getSortType());
				}
			}else if("ltfcVsOrder".equalsIgnoreCase(form.getSortColumn())){
				sBuffer.append(" order by ").append(getOrderByConditionOrder(ltfcVersion)).append(form.getSortType());
			}else if("ltfcVsMps".equalsIgnoreCase(form.getSortColumn())){
				sBuffer.append(" order by ").append(getOrderByConditionMps(ltfcVersion,mapsVersion)).append(form.getSortType());
			}else{
				sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType());
			}
		}

		SQLQuery query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("month", StringType.INSTANCE)
				.addScalar("rootCause", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE);
			if("Mps".equals(ltfcType)){
				query.addScalar("ltfcVsMps",StringType.INSTANCE);
			}else{
				query.addScalar("ltfcVsOrder",StringType.INSTANCE);
			}
		   query.addScalar("family", StringType.INSTANCE)
		   		.addScalar("orderQty", StringType.INSTANCE)
				.addScalar("ltfcQty", StringType.INSTANCE)
				.addScalar("mpsQty", StringType.INSTANCE).
				setResultTransformer(Transformers.aliasToBean(LTFCDetailView.class));
		return query.list();
	}

	@Override
	public int getRemarkOrderDetailCount(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		String ltfcVersion=form.getLtfcVersion();
		String mapsVersion=form.getMpsVersion();
		String ltfcType=form.getLtfcType();
		String isNullLtfc=isNullLTFC(ltfcVersion);
		String isNullMps=isNullMPS(mapsVersion);
		String isNullOrder=isNullOrder();
		sBuffer.append("select count(*) as orderNum")
		   .append(" from FactMonthlySummaryofLTFCFA ltfc")
		   .append(" left join ( ")
		   .append(" select product.ProductKey,family.ProductFamilyKey,product.ProductEnglishName,family.ProductFamilyEnglishName from DimProduct product " )
		   .append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
		   .append(" ) productFamily on ltfc.ProductKey = productFamily.ProductKey ");
		
		if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("left join DimODM odm on ltfc.ODMKey = odm.ODMKey ");
		}
		
		sBuffer.append(" where ltfc.Year = ").append(form.getYear())
    			   .append(" and ltfc.Month = ").append(form.getMonth());
		sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");

		sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
		
		//dodo
		sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
		
		if("Mps".equals(ltfcType)){
			 if("over plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" > "+isNullMps);
			 }else if("equal plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" = "+isNullMps);
			 }else if("under plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" < "+isNullMps);
			 }	
		 }else{
			 if("over plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" > "+isNullOrder);
			 }else if("equal plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" = "+isNullOrder);
			 }else if("under plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" < "+isNullOrder);
			 }	
		 }
		
	    if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
//			if(form.isShowAllRemarkOrder()){
//				sBuffer.append(" and odm.ODMEnglishName in(" +  form.getSubDimension() + ") ");
//			}
//			else{
				sBuffer.append(" and odm.ODMEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			//}
			
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
				sBuffer.append(" and productFamily.ProductEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
		}else if("family".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and productFamily.ProductFamilyEnglishName = '"
					+ form.getSubDimension().toUpperCase()+ "' ");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return ((Integer) query.uniqueResult());
	}


	@Override
	public List<LTFCDetailView> getRemarkOrderDetail(SearchFaForm form) {
		String ltfcVersion=form.getLtfcVersion();
		String mapsVersion=form.getMpsVersion();
		String isNullLtfc=isNullLTFC(ltfcVersion);
		String isNullMps=isNullMPS(mapsVersion);
		String isNullOrder=isNullOrder();
		String ltfcType=form.getLtfcType();
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append(" select ltfc.month,dimODM.ODMEnglishName as odm,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("ltfc.orderQty ,")
				.append(" ltfc.[" + ltfcVersion + "DaysLTFCQty] as ltfcQty,")
				.append("ltfc.[" + mapsVersion + "DaysMPSQty] as mpsQty,")
				.append("productFamily.ProductFamilyEnglishName as family,");
		if("Mps".equals(ltfcType)){
			sBuffer	.append("case when ltfc.["+ltfcVersion+"DaysLTFCQty] > ltfc.["+mapsVersion+"DaysMPSQty]  then 'over plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] = ltfc.["+mapsVersion+"DaysMPSQty] then 'equal plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] < ltfc.["+mapsVersion+"DaysMPSQty] then 'under plan' else '' end as rootCause,")
					.append(getOrderByConditionMps(ltfcVersion,mapsVersion) +" as ltfcVsMps ");
		}else{
			sBuffer	.append("case when ltfc.["+ltfcVersion+"DaysLTFCQty] > ltfc.OrderQty  then 'over plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] = ltfc.OrderQty then 'equal plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] < ltfc.OrderQty then 'under plan' else '' end as rootCause,")
					.append(getOrderByConditionOrder(ltfcVersion)+" as ltfcVsOrder ");
		}
		sBuffer	.append(" from FactMonthlySummaryofLTFCFA ltfc ")
				.append(" left join DimProduct dimProduct on ltfc.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ltfc.ODMKey = dimODM.ODMKey")
				.append(" left join ( ")
				.append(" select   product.ProductKey as productKey,   family.ProductFamilyEnglishName ,   family.ProductFamilyKey   from DimProduct product   join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey ) as productFamily ")
				.append(" on ltfc.ProductKey=productFamily.ProductKey ");
		
		 sBuffer.append(" where ltfc.Year = ").append(form.getYear())
		 		.append(" and ltfc.Month = ").append(form.getMonth());
		 sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
		 
		 sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mapsVersion+"DaysMPSQty]>0) ");
		 
		 //dodo
		 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
		 
		 if("Mps".equals(ltfcType)){
			 if("over plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" > "+isNullMps);
			 }else if("equal plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" = "+isNullMps);
			 }else if("under plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" < "+isNullMps);
			 }	
		 }else{
			 if("over plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" > "+isNullOrder);
			 }else if("equal plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" = "+isNullOrder);
			 }else if("under plan".equalsIgnoreCase(form.getRootCause())){
				 sBuffer.append(" and "+isNullLtfc+" < "+isNullOrder);
			 }	
		 }
		 
//		if(form.getStartDate().equals(form.getEndDate())){
//			sBuffer.append(" where ltfc.Year = ").append(form.getYear())
//    			   .append(" and ltfc.Month = ").append(form.getMonth());
//		}else{
//			sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
//			   .append(form.getStartDate()).append("'")
//			   .append(" and '").append(form.getEndDate()).append("'");
//		}
		
		
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
//			if(form.isShowAllRemarkOrder()){
//				sBuffer.append(" and odm.ODMEnglishName in(" +  form.getSubDimension() + ") ");
//			}
//			else{
				sBuffer.append(" and dimODM.ODMEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			//}
			
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
				sBuffer.append(" and dimProduct.ProductEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
		}else if("family".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and productFamily.ProductFamilyEnglishName = '"
					+ form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			if("rootCause".equalsIgnoreCase(form.getSortColumn())){
				if("Mps".equals(ltfcType)){
					sBuffer.append(" order by ").append("(case when "+isNullLtfc+" > "+isNullMps+"  then 'over plan' when "+isNullLtfc+" = "+isNullMps+"  then 'equal plan' when "+isNullLtfc+" < "+isNullMps+"  then 'under plan' else '' end)").append(form.getSortType());
				}else{
					sBuffer.append(" order by ").append("(case when "+isNullLtfc+" > "+isNullOrder+" then 'over plan' when "+isNullLtfc+" = "+isNullOrder+" then 'equal plan' when "+isNullLtfc+" < "+isNullOrder+" then 'under plan' else '' end)").append(form.getSortType());
				}
			}else if("ltfcVsOrder".equalsIgnoreCase(form.getSortColumn())){
				sBuffer.append(" order by ").append(getOrderByConditionOrder(ltfcVersion)).append(form.getSortType());
			}else if("ltfcVsMps".equalsIgnoreCase(form.getSortColumn())){
				sBuffer.append(" order by ").append(getOrderByConditionMps(ltfcVersion,mapsVersion)).append(form.getSortType());
			}else{
				sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType());
			}
		}
		
		SQLQuery query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE)
				.addScalar("month", StringType.INSTANCE)
				.addScalar("rootCause", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE);
			if("Mps".equals(ltfcType)){
				query.addScalar("ltfcVsMps",StringType.INSTANCE);
			}else{
				query.addScalar("ltfcVsOrder",StringType.INSTANCE);
			}
		   query.addScalar("family", StringType.INSTANCE).addScalar("orderQty", StringType.INSTANCE)
				.addScalar("ltfcQty", StringType.INSTANCE).addScalar("mpsQty", StringType.INSTANCE).
				setResultTransformer(Transformers.aliasToBean(LTFCDetailView.class));
		
		query.setFirstResult((form.getCurrentPage()-1)*SysConfig.NUMBER_OF_ROW_COUNT);
		query.setMaxResults(SysConfig.NUMBER_OF_ROW_COUNT);
		
		return query.list();
		
	}

	//TODO
	@Override
	public List<String> getPoorProducts(SearchFaForm form, int target) {
		StringBuffer sBuffer=new StringBuffer(); 
		String ltfcVersion=form.getLtfcVersion();
		String mapsVersion=form.getMpsVersion();																				//sum(case when ltfc.[90DaysLTFCQty] is null then 0 else ltfc.[90DaysLTFCQty] end)
		sBuffer.append(" select poor.product from ( select dimProduct.ProductEnglishName as product,dimProduct.ProductKey, sum(case when ltfc.["+ltfcVersion+"DaysLTFCQty] is null then 0 else ltfc.["+ltfcVersion+"DaysLTFCQty] end) as ltfcQty,");
		if("Mps".equalsIgnoreCase(form.getLtfcType())){//ltfc.OrderQty
			sBuffer.append("sum(case when ltfc.["+mapsVersion+"DaysMPSQty] is null then 0 else ltfc.["+mapsVersion+"DaysMPSQty] end) as mpsQty");
		}else {
			sBuffer.append("sum(case when ltfc.OrderQty is null then 0 else ltfc.OrderQty end) as OrderQty");
		}
		sBuffer.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		sBuffer.append(" join DimProduct dimProduct on ltfc.ProductKey = dimProduct.ProductKey ");
		sBuffer.append(" where ltfc.Year = ").append(form.getYear())
		       .append(" and ltfc.Month = ").append(form.getMonth());
		sBuffer.append(" group by dimProduct.ProductKey,dimProduct.ProductEnglishName ");
		sBuffer.append(" having isNull( (sum(case when ltfc.["+ltfcVersion+"DaysLTFCQty] is null then 0 else ltfc.["+ltfcVersion+"DaysLTFCQty] end))*100 / cast( ");
		if("Mps".equalsIgnoreCase(form.getLtfcType())){
			sBuffer.append("  nullif ( (sum(case when ltfc.["+mapsVersion+"DaysMPSQty] is null then 0 else ltfc.["+mapsVersion+"DaysMPSQty] end)),0) as  NUMERIC(15,2) ");
		}else {
			sBuffer.append("  nullif ( (sum(case when ltfc.OrderQty is null then 0 else ltfc.OrderQty end)  ),0) as  NUMERIC(15,2) ");
		}
		sBuffer.append(" ) , 0 ) < "+target+" ) poor ");
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return query.list();
	}

	@Override
	public List<FaOverViewChartData> getFaPieChart(SearchFaForm form) {
		StringBuilder sBuffer = new StringBuilder();
		String ltfcVersion=form.getLtfcVersion();
		String mpsVersion=form.getMpsVersion();
		String isNullLtfc=isNullLTFC(ltfcVersion);
		String isNullMps=isNullMPS(mpsVersion);
		String isNullOrder=isNullOrder();
		if("Mps".equals(form.getLtfcType())){
			sBuffer.append("select rowname,value from")
			.append("(select sum(case when "+isNullMps+" > "+isNullLtfc+" then 1 else 0 end) as [under plan],")
			.append("sum(case when "+isNullMps+" < "+isNullLtfc+" then 1 else 0 end) as [over plan],")
			.append("sum(case when "+isNullMps+" = "+isNullLtfc+" then 1 else 0 end) as [equal plan] ")
			.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		}else{
			sBuffer.append("select rowname,value from")
			.append("(select sum(case when "+isNullOrder+" > "+isNullLtfc+" then 1 else 0 end) as [under plan],")
			.append("sum(case when "+isNullOrder+" < "+isNullLtfc+" then 1 else 0 end) as [over plan],")
			.append("sum(case when "+isNullOrder+" = "+isNullLtfc+" then 1 else 0 end) as [equal plan] ")
			.append(" from FactMonthlySummaryofLTFCFA ltfc ");
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
			sBuffer.append(" where CONVERT(nvarchar(20), ltfc.Year)+'-'+CONVERT(nvarchar(20), ltfc.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		else {
		    	sBuffer.append(" where ltfc.Year = ").append(form.getYear())
		    		.append(" and ltfc.Month = ").append(form.getMonth());
		}
		sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
		
		sBuffer.append(" and (ltfc.["+ltfcVersion+"DaysLTFCQty]>0 or ltfc.OrderQty>0 or ltfc.["+mpsVersion+"DaysMPSQty]>0) ");
		
		 //dodo
		 sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
		sBuffer.append(" ) p ")
		.append("UNPIVOT (value for rowname in([under plan],[over plan],[equal plan])) p");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
		.addScalar("value", IntegerType.INSTANCE)
		.addScalar("rowName", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		return query.list();
	}
	
	private String getCrossMonthOverviewCondition(SearchFaForm form){
		boolean hasWhereFlag = true;
		StringBuffer sBuffer=new StringBuffer();
		//for Family overview chart
		if("Family".equals(form.getDimension())) {
			boolean hasWhere=false;
			sBuffer.append("  join (")
			.append("select product.ProductKey from DimProduct product")
			.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
	
			sBuffer.append(" where family.ProductFamilyKey = ").append(form.getSubDimensionKey());
			sBuffer.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" where ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
				hasWhere=true;
			}
			if(!StringUtil.isEmpty(form.getProductIds())){
				if(hasWhere){
					sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
				}else{
					sBuffer.append(" where ltfc.ProductKey in(").append(form.getProductIds()).append(")");
					hasWhere=true;
				}
			}
			hasWhereFlag=hasWhere;
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append("  join (")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
		
				sBuffer.append(" where family.ProductFamilyKey in (").append(form.getFamilyIds()).append(")");
				sBuffer.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			
			sBuffer.append(" where ltfc.ODMKey = ").append(form.getSubDimensionKey());

			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append("  join ( ")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
		
				sBuffer.append(" where family.ProductFamilyKey in (").append(form.getFamilyIds()).append(")")
					.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			
			sBuffer.append(" where ltfc.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
		}
		
		if(!hasWhereFlag)
			sBuffer.append(" where");
		else{ 
			sBuffer.append(" and");
		}
			
		sBuffer.append(" ltfc.Year = ").append(form.getYear())
		.append(" and ltfc.Month = ").append(form.getMonth());
		sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
		//dodo
		sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
		return sBuffer.toString();
	}
	
	private String getDashboardOverviewCondition(SearchFaForm form){
		StringBuffer sBuffer=new StringBuffer();
		boolean hasWhereFlag = true;
		//for Family overview chart
		if("Family".equals(form.getDimension())) {
			boolean hasWhere=false;
			sBuffer.append("  join (")
			.append("select product.ProductKey from DimProduct product")
			.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			
			sBuffer.append(" where family.ProductFamilyKey = ").append(form.getSubDimensionKey())
					.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" where ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
				hasWhere=true;
			}
			
			if(!StringUtil.isEmpty(form.getProductIds())){
				if(hasWhere){
					sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
				}else{
					sBuffer.append(" where ltfc.ProductKey in(").append(form.getProductIds()).append(")");
					hasWhere=true;
				}
			}
			hasWhereFlag=hasWhere;
		}
		//for Odm overview chart
		//click Odm All
		else if("Odm".equals(form.getDimension())) {
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append("  join (")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
		
				sBuffer.append(" where family.ProductFamilyKey in (").append(form.getFamilyIds()).append(")")
					.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			
			sBuffer.append(" where ltfc.ODMKey = ").append(form.getSubDimensionKey());

			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ltfc.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append("  join ( ")
				.append("select product.ProductKey from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
		
				sBuffer.append(" where family.ProductFamilyKey in (").append(form.getFamilyIds()).append(")")
					.append(")productFamily on ltfc.ProductKey = productFamily.ProductKey");
			}
			
			sBuffer.append(" where ltfc.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ltfc.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			
			
		}
		
		if(!hasWhereFlag)
			sBuffer.append(" where");
		else{ 
			sBuffer.append(" and");
		}
		sBuffer.append(" ltfc.Year = ").append(form.getYear())
			.append(" and ltfc.Month = ").append(form.getMonth());
		sBuffer.append(" and ltfc.VersionDate=(select max(VersionDate) from FactMonthlySummaryofLTFCFA ltfcb ) ");
		//dodo
		sBuffer.append(" and ltfc.productKey not in (select d.productKey from DimProduct d where d.ProductEnglishName in ('K2450','K20-80','K4450A','K41-70','E4430A','E4430G','E31-70','E40-70','E40-80','E40-30','E50-70','E50-80','E31-70') )");
		return sBuffer.toString();
	}
	
	private String getOrderByConditionMps(String ltfcVersion,String mpsVersion){
		StringBuffer sb=new StringBuffer();
		sb.append("case when isNull(ltfc.["+ltfcVersion+"DaysLTFCQty],0)<isNull(ltfc.["+mpsVersion+"DaysMPSQty],0) then cast (100*ltfc.["+ltfcVersion+"DaysLTFCQty]/cast (nullif(ltfc.["+mpsVersion+"DaysMPSQty],0) as NUMERIC(15,2))as NUMERIC(15,2))"
				+ " else cast (100*ltfc.["+mpsVersion+"DaysMPSQty]/cast (nullif(ltfc.["+ltfcVersion+"DaysLTFCQty],0) as NUMERIC(15,2))as NUMERIC(15,2)) end  ");
		return sb.toString();
	}
	
	private String getOrderByConditionOrder(String ltfcVersion){
		StringBuffer sb=new StringBuffer();
		sb.append("case when isNull(ltfc.["+ltfcVersion+"DaysLTFCQty],0)<isNull(ltfc.OrderQty,0) then cast (100*ltfc.["+ltfcVersion+"DaysLTFCQty]/cast (nullif(ltfc.OrderQty,0) as NUMERIC(15,2))as NUMERIC(15,2))"
				+ " else cast (100*ltfc.OrderQty/cast (nullif(ltfc.["+ltfcVersion+"DaysLTFCQty],0) as NUMERIC(15,2))as NUMERIC(15,2)) end  ");
		return sb.toString();
	}
	
}
