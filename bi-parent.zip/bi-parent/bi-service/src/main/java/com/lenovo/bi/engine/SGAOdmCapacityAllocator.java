package com.lenovo.bi.engine;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.model.SGATtvWeeklyDetail;

public class SGAOdmCapacityAllocator extends OdmCapacityAllocator<SGATtvWeeklyDetail> {

	//public SGAOdmCapacityAllocator(Map<String, SGATtvWeeklyDetail> weeklyDetailMap, List<OrderData> orderDataList, List<ForecastData> forecastDataList) {
	public SGAOdmCapacityAllocator(Map<Date, SGATtvWeeklyDetail> weeklyDetailMap, List<NpiWeeklyComponentCommitmentOnOrder> orderDataList, 
			List<NpiWeeklyComponentCommitmentOnForecast> forecastDataList) {
		super(weeklyDetailMap, orderDataList, forecastDataList);
	}

	public void run() {
		//for (OrderData orderData : orderDataList) {
		for (NpiWeeklyComponentCommitmentOnOrder orderData : orderDataList) {
			//LOGGER.info("Process odm capacity for order: " + orderData.getUniqueIdentifier());

			int quantity = orderData.getQuantity();
			//SGATtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(orderData.getProductKey()+orderData.getPmsWaveId());
			SGATtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(orderData.getTargetDate());

			if (weeklyDetail != null) {
				// Process using ODM FPY
				int odmFpyCapacity = weeklyDetail.getOdmFpyCapacity();

				if (odmFpyCapacity >= quantity) {
					weeklyDetail.setOdmFpyCapacity(odmFpyCapacity - quantity);
					weeklyDetail.setOdmRpyCapacity(weeklyDetail.getOdmFpyCapacity());

					//orderData.setOdmCommit(quantity);
					orderData.setOdmShortage(0);
				} else {
					weeklyDetail.setOdmFpyCapacity(0);
					weeklyDetail.setOdmRpyCapacity(0);

					//orderData.setOdmCommit(odmFpyCapacity);
					orderData.setOdmShortage(quantity - odmFpyCapacity);
				}

				// Process using TDMS FPY
				int tdmsFpyCapacity = weeklyDetail.getTdmsFpyCapacity();

				if (tdmsFpyCapacity >= quantity) {
					weeklyDetail.setTdmsFpyCapacity(tdmsFpyCapacity - quantity);
					weeklyDetail.setTdmsRpyCapacity(weeklyDetail.getTdmsFpyCapacity());

					//orderData.setTdmsOdmCommit(quantity);
					//orderData.setTdmsOdmShortage(0);
				} else {
					weeklyDetail.setTdmsFpyCapacity(0);
					weeklyDetail.setTdmsRpyCapacity(0);

					//orderData.setTdmsOdmCommit(tdmsFpyCapacity);
					//orderData.setTdmsOdmShortage(quantity - tdmsFpyCapacity);
				}
			} else {
				// It is SC order
			}
		}

		//for (ForecastData forecastData : forecastDataList) {
		for (NpiWeeklyComponentCommitmentOnForecast forecastData : forecastDataList) {
			//LOGGER.info("Process tooling capacity for forecast: " + forecastData.getUniqueIdentifier());

			int quantity = forecastData.getQuantity();
			//SGATtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(forecastData.getProductKey()+forecastData.getPmsWaveId());
			SGATtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(forecastData.getTargetDate());

			if (weeklyDetail != null) {
				// Process using ODM FPY
				int odmFpyCapacity = weeklyDetail.getOdmFpyCapacity();

				if (odmFpyCapacity >= quantity) {
					weeklyDetail.setOdmFpyCapacity(odmFpyCapacity - quantity);
					weeklyDetail.setOdmRpyCapacity(weeklyDetail.getOdmFpyCapacity());

					//forecastData.setOdmCommit(quantity);
					forecastData.setOdmShortage(0);
				} else {
					weeklyDetail.setOdmFpyCapacity(0);
					weeklyDetail.setOdmRpyCapacity(0);

					//forecastData.setOdmCommit(odmFpyCapacity);
					forecastData.setOdmShortage(quantity - odmFpyCapacity);
				}

				// Process using TDMS FPY
				int tdmsFpyCapacity = weeklyDetail.getTdmsFpyCapacity();

				if (tdmsFpyCapacity >= quantity) {
					weeklyDetail.setTdmsFpyCapacity(tdmsFpyCapacity - quantity);
					weeklyDetail.setTdmsRpyCapacity(weeklyDetail.getTdmsFpyCapacity());

					//forecastData.setTdmsOdmCommit(quantity);
					//forecastData.setTdmsOdmShortage(0);
				} else {
					weeklyDetail.setTdmsFpyCapacity(0);
					weeklyDetail.setTdmsRpyCapacity(0);

					//forecastData.setTdmsOdmCommit(tdmsFpyCapacity);
					//forecastData.setTdmsOdmShortage(quantity - tdmsFpyCapacity);
				}
			} else {
				// It is SC forecast
			}
		}
	}
}
