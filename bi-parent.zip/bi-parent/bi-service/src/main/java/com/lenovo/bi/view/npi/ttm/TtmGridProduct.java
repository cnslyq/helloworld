package com.lenovo.bi.view.npi.ttm;

import com.lenovo.bi.view.npi.AbstractGridProduct;

public class TtmGridProduct extends AbstractGridProduct {
	//return value is yellow/red/green
	private String doiLight;
	private String gatingDefectsLight;
	private String fpyLight;
	private String odmLight;
	private String toolingLight;
	private String ttmTargetDate;
	private boolean targetDatePassed = false;
	private boolean showSignedSnapshot = false;
	private String ttmSignOffDate;

	// page in progress
	private String risk;
	private String riskColor;
	// page risk
	// page success
	private String successStatus;
	private String successColor;
	// page NA
	private String naCurrentPhase;
	private String startDate;
	// page overview
	private String status;
	private String statusColor;
	
	public boolean getTargetDatePassed() {
		return targetDatePassed;
	}

	public void setTargetDatePassed(boolean targetDatePassed) {
		this.targetDatePassed = targetDatePassed;
	}

	public String getSuccessColor() {
		return successColor;
	}

	public void setSuccessColor(String successColor) {
		this.successColor = successColor;
	}

	public String getRiskColor() {
		return riskColor;
	}

	public void setRiskColor(String riskColor) {
		this.riskColor = riskColor;
	}

	public String getStatusColor() {
		return statusColor;
	}

	public String getTtmTargetDate() {
		return ttmTargetDate;
	}

	public void setTtmTargetDate(String ttmTargetDate) {
		this.ttmTargetDate = ttmTargetDate;
	}

	public String getTtmSignOffDate() {
		return ttmSignOffDate;
	}

	public void setTtmSignOffDate(String ttmSignOffDate) {
		this.ttmSignOffDate = ttmSignOffDate;
	}

	public void setStatusColor(String statusColor) {
		this.statusColor = statusColor;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRisk() {
		return risk;
	}

	public void setRisk(String risk) {
		this.risk = risk;
	}

	public String getSuccessStatus() {
		return successStatus;
	}

	public void setSuccessStatus(String successStatus) {
		this.successStatus = successStatus;
	}

	public String getNaCurrentPhase() {
		return naCurrentPhase;
	}

	public void setNaCurrentPhase(String naCurrentPhase) {
		this.naCurrentPhase = naCurrentPhase;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getDoiLight() {
		return doiLight;
	}

	public void setDoiLight(String doiLight) {
		this.doiLight = doiLight;
	}

	public String getGatingDefectsLight() {
		return gatingDefectsLight;
	}

	public void setGatingDefectsLight(String gatingDefectsLight) {
		this.gatingDefectsLight = gatingDefectsLight;
	}

	public String getFpyLight() {
		return fpyLight;
	}

	public void setFpyLight(String fpyLight) {
		this.fpyLight = fpyLight;
	}

	public String getOdmLight() {
		return odmLight;
	}

	public void setOdmLight(String odmLight) {
		this.odmLight = odmLight;
	}

	public String getToolingLight() {
		return toolingLight;
	}

	public void setToolingLight(String toolingLight) {
		this.toolingLight = toolingLight;
	}

	public boolean isShowSignedSnapshot() {
		return showSignedSnapshot;
	}

	public void setShowSignedSnapshot(boolean showSignedSnapshot) {
		this.showSignedSnapshot = showSignedSnapshot;
	}
	
	

}
