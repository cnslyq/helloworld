package com.lenovo.bi.service.npi;

import java.text.ParseException;
import java.util.List;

import com.lenovo.bi.form.npi.ttv.SearchOrderHitRateForm;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.ttv.OrderHitRateView;

public interface TTVOutlookOrderHitRateService {

	public ColumnChartView getColumnChartView(SearchOrderHitRateForm searchForm) throws ParseException;
	public List<OrderHitRateView> getGrid(SearchOrderHitRateForm searchForm) throws ParseException;
}
