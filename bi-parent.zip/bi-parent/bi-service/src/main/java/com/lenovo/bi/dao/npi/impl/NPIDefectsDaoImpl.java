package com.lenovo.bi.dao.npi.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BooleanType;
import org.hibernate.type.DateType;
import org.hibernate.type.FloatType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.npi.NPIDefectDao;
import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.util.CalendarUtil;

/**
 * 
 * 
 * @author henry_lian
 * 
 */
@Repository
public class NPIDefectsDaoImpl extends HibernateBaseDaoImplDw implements
		NPIDefectDao {

	@Override
	public List<Defect> getGatingDefectsByProductWave(int waveId,
			Date targetDate, Date versionDate) {
		return getDefects(waveId, targetDate, versionDate, false, true, false);
	}

	@Override
	public List<Defect> getOOBDefectsByProductWave(int waveId, Date targetDate,
			Date versionDate) {
		return getDefects(waveId, targetDate, versionDate, true, false, false);
	}

	@Override
	public List<Defect> getNonOOBDefectsByProductWave(int waveId,
			Date targetDate, Date versionDate) {
		return getDefects(waveId, targetDate, versionDate, false, false, true);
	}

	@Override
	public List<Defect> getGatingDefectsByProductWave(int waveId,
			Date targetDate) {
		return getDefects(waveId, targetDate, null, false, true, false);
	}

	@Override
	public List<Defect> getOOBDefectsByProductWave(int waveId, Date targetDate) {
		return getDefects(waveId, targetDate, null, true, false, false);
	}

	@Override
	public List<Defect> getNonOOBDefectsByProductWave(int waveId,
			Date targetDate) {
		return getDefects(waveId, targetDate, null, false, false, true);
	}

	private List<Defect> getDefects(int waveId, Date targetDate,
			Date versionDate, boolean isOOB, boolean isGating, boolean isNonOOB) {
		StringBuilder sql = new StringBuilder(
				"select dd.TDMSDefectIDAlternateKey as defectNo, dd.DefectSubject as defectTitle, dd.category as category, fd.FPYImpact as impactFPY, fd.FailRate as failRate,  ")
				.append("cast(cast(dd.EstimatedResolveDateKey as varchar) as date) as estimatedResolveDate, ")
				.append("t2.FullDateAlternateKey as targetDate, dd.CreatedDate as createDate, dd.IsOpen as isOpen, dd.IsLimitation as isLimitation, dd.IsOOBDefect as oBEDefect, dd.IsGatingDefect as gatingDefect, dd.DefectOwner as owner ")
				.append("from FactWeeklySummaryofDefect fd inner join DimDefect dd on fd.DefectKey = dd.DefectKey")
				.append(" inner join DimTime t on fd.TargetDateKey = t.TimeKey")
				.append(" left join DimTime t2 on t2.TimeKey = dd.EstimatedResolveDateKey ")
				.append(" inner join DimProduct pd on pd.ProductKey = fd.ProductKey")
				.append(" inner join DimNPIProject p on p.ProductKey = pd.ProductKey")
				.append(" inner join DimNPIWave w on w.NPIProjectKey = p.NPIProjectKey");
			 sql.append(" inner join DimTime dt on fd.VersionDateKey = dt.TimeKey");

			 sql.append(" where w.PMSWaveIDAlternateKey = :waveId ")
			    .append( "and datediff(day, t.FullDateAlternateKey, :targetDate) = 0 ");
			 sql.append("and datediff(day, dt.FullDateAlternateKey, :versionDate) = 0  ");
			 sql.append(" and dd.IsCurrent = 1 and p.IsCurrent = 1 and w.IsCurrent = 1 ");
		if (isOOB){
			sql.append("and fd.IsOOBDefect = 1 ");
		}
		if (isGating){
			sql.append(" and fd.IsGatingDefect = 1 ");
		}
		if (isNonOOB){
			sql.append("and fd.IsOOBDefect = 0 ");
		}
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("defectNo", StringType.INSTANCE)
				.addScalar("defectTitle", StringType.INSTANCE)
				.addScalar("failRate", FloatType.INSTANCE)
				.addScalar("impactFPY", FloatType.INSTANCE)
				.addScalar("estimatedResolveDate", DateType.INSTANCE)
				.addScalar("targetDate", DateType.INSTANCE)
				.addScalar("createDate", DateType.INSTANCE)
				.addScalar("isOpen", BooleanType.INSTANCE)
				.addScalar("isLimitation", BooleanType.INSTANCE)
				.addScalar("oBEDefect", BooleanType.INSTANCE)
				.addScalar("gatingDefect", BooleanType.INSTANCE)
				.addScalar("owner", StringType.INSTANCE)
				.addScalar("category", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(Defect.class));
		query.setParameter("waveId", waveId);
		query.setParameter("targetDate", targetDate);
		if (versionDate != null) {
			query.setParameter("versionDate", versionDate);
		} else{
			query.setParameter("versionDate", CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		}
		List<Defect> list = query.list();
		return list;
	}

}
