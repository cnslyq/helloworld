package com.lenovo.bi.dao.npi;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.dto.DimMtm;
import com.lenovo.bi.dto.DimODM;
import com.lenovo.bi.dto.DimOrderForDetractor;
import com.lenovo.bi.dto.DimOrderForNPIExclude;
import com.lenovo.bi.dto.GeoData;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.form.npi.ttv.SearchOutlookDataForm;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.model.DimDetractor;
import com.lenovo.bi.view.npi.ttv.PoNumberAndPoItem;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;

public interface NpiOrderDaoDw {

	public List<DimOrderForNPIExclude> getDimOrderByWaveId(int waveId, Date weekDate, Date sgaDate);
	
	public List<DimOrderForNPIExclude> getSleDimOrderByWaveId(int waveId, Date weekDate, Date sgaDate);
	
	public List<DimOrderForNPIExclude> getSgaDimOrderByWaveIdInWeek(int waveId, Date weekDate, Date sgaDate);
	
	public List<DimOrderForNPIExclude> getSleDimOrderByWaveIdInWeek(int waveId, Date weekDate, Date sgaDate);

	public List<PieDivider> getDetractorMainDivider(SearchOutlookDataForm form);

	public List<PieDivider> getDetractorSubDivider(SearchOutlookDataForm form);

	public List<DimOrderForDetractor> getDetractorMainUnknownDivider(SearchOutlookDataForm form);

	public List<TtvGridDetractorCodeView> getDetractorCodeDataGrid(SearchOutlookDataForm form);

	public List<PieDivider> getOdmMainDivider(SearchOutlookDataForm form);

	public List<GeoData> getGeoIdAndName();

	public List<GeoData> getRegionIdAndName(Integer geoId);
	
	public DimDetractor getDetractorById(Integer detractorKey);

	public GeoData getRegionById(Integer geoId);

	public DimODM getODMById(Integer odmId);

	public DimMtm getMtmById(int mtmKey);

	public List<PoNumberAndPoItem> getPoNumberAndPoItemByConditions(Integer geoId, Integer regionId, List<String> mtms);

	public List<Defect> getDefectsList(SearchOutlookDataForm form);

	public List<TtvGridDetractorCodeView> getDetractorCodeDataByOrderkeys(Date beginDate, Date endDate, List<String> orderKeys);

	public List<TtvGridDetractorCodeView> getDetractorCodeDataByOrderkeys(Date beginDate, Date endDate, List<String> orderKeys, String sortColumn,
			String sortType);

	public List<TtvGridDetractorCodeView> getDetractorCodeDataByOrderkeys(Date beginDate, Date endDate, List<String> orderKeys, SearchOtsForm form);

	public int getDetractorCodeCountByOrderkeys(Date beginDate, Date endDate, List<String> orderKeys, SearchOtsForm form);

}
