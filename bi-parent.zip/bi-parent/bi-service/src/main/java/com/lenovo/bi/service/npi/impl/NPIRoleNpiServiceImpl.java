package com.lenovo.bi.service.npi.impl;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.npi.NPIProductSummaryDao;
import com.lenovo.bi.enumobj.NPIPhase;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
import com.lenovo.bi.service.npi.NPIRoleNpiService;

/**
 * 
 * 
 * @author Henry_Lian
 *
 */
@Service
public class NPIRoleNpiServiceImpl implements NPIRoleNpiService {
	
	@Inject
	private NPIProductSummaryDao npiProductSummaryDao;

	@Override
	public Map<Integer, List<String>> getNPIByWaveIds(List<Integer> waveIds) {
		
		return npiProductSummaryDao.getNPIByWaveIds(waveIds);
	}

	@Override
	public List<String> getNPIByConditions(OverviewSearchForm form, NPIPhase phase) {
		return npiProductSummaryDao.getNPIByConditions(form, phase);
	}

}
