package com.lenovo.bi.service.sc.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.npi.NpiOrderDaoDw;
import com.lenovo.bi.enumobj.DBEnum;
import com.lenovo.bi.enumobj.DetractorEnum;
import com.lenovo.bi.enumobj.FulfillmentEnum;
import com.lenovo.bi.enumobj.FutureEnum;
import com.lenovo.bi.enumobj.MFGQualityEnum;
import com.lenovo.bi.enumobj.NewWorkingEnum;
import com.lenovo.bi.enumobj.OverSPEnum;
import com.lenovo.bi.enumobj.SupplyEnum;
import com.lenovo.bi.enumobj.ToGoCaEnum;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.service.sc.ScCommonService;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.chart.pie.PieSlice;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;

@Repository
public class ScCommonServiceImpl implements ScCommonService{
	
	@Inject
	NpiOrderDaoDw npiOrderDaoDw;

	@Override
	public PieChartView getDetractorMainPieChart(
			Map<String, String> detractorMap, String linkName) {
		if(detractorMap != null){
			PieSlice p1 = new PieSlice();
			p1.setLink("j-"+linkName+"-Future");
			p1.setLabel(DetractorEnum.Future.toString());
			p1.setColor(DetractorEnum.Future.getColor());
			p1.setValue(detractorMap.get(DetractorEnum.Future.toString().toUpperCase()));

			PieSlice p2 = new PieSlice();
			p2.setLink("j-"+linkName+"-DB");
			p2.setLabel(DetractorEnum.DB.toString());
			p2.setColor(DetractorEnum.DB.getColor());
			p2.setValue(detractorMap.get(DetractorEnum.DB.toString().toUpperCase()));

			PieSlice p3 = new PieSlice();
			p3.setLink("j-"+linkName+"-Over SP");
			p3.setLabel(DetractorEnum.Over_SP.toString());
			p3.setColor(DetractorEnum.Over_SP.getColor());
			p3.setValue(detractorMap.get(DetractorEnum.Over_SP.toString().toUpperCase()));

			PieSlice p4 = new PieSlice();
			p4.setLink("j-"+linkName+"-Supply");
			p4.setLabel(DetractorEnum.Supply.toString());
			p4.setColor(DetractorEnum.Supply.getColor());
			p4.setValue(detractorMap.get(DetractorEnum.Supply.toString().toUpperCase()));

			PieSlice p5 = new PieSlice();
			p5.setLink("j-"+linkName+"-Fulfillment");
			p5.setLabel(DetractorEnum.Fulfillment.toString());
			p5.setColor(DetractorEnum.Fulfillment.getColor());
			p5.setValue(detractorMap.get(DetractorEnum.Fulfillment.toString().toUpperCase()));

			PieSlice p6 = new PieSlice();
			p6.setLink("j-"+linkName+"-MFG/Quality");
			p6.setLabel(DetractorEnum.MFG_Quality.toString());
			p6.setColor(DetractorEnum.MFG_Quality.getColor());
			p6.setValue(detractorMap.get(DetractorEnum.MFG_Quality.toString().toUpperCase()));

			PieSlice p7 = new PieSlice();
			p7.setLink("j-"+linkName+"-NEW/Working");
			p7.setLabel(DetractorEnum.NEW_Working.toString());
			p7.setColor(DetractorEnum.NEW_Working.getColor());
			p7.setValue(detractorMap.get(DetractorEnum.NEW_Working.toString().toUpperCase()));

			PieSlice p8 = new PieSlice();
			p8.setLink("j-"+linkName+"-To Go CA");
			p8.setLabel(DetractorEnum.To_Go_CA.toString());
			p8.setColor(DetractorEnum.To_Go_CA.getColor());
			p8.setValue(detractorMap.get(DetractorEnum.To_Go_CA.toString().toUpperCase()));

			PieSlice p9 = new PieSlice();
			p9.setLink("j-"+linkName+"-Unknown");
			p9.setLabel(DetractorEnum.Unknown.toString());
			p9.setColor(DetractorEnum.Unknown.getColor());
			p9.setValue(detractorMap.get(DetractorEnum.Unknown.toString().toUpperCase()));

			List<PieSlice> list = new ArrayList<PieSlice>();
			list.add(p1);
			list.add(p2);
			list.add(p3);
			list.add(p4);
			list.add(p5);
			list.add(p6);
			list.add(p7);
			list.add(p8);
			list.add(p9);
			PieChartView pView = new PieChartView();

			pView.setElements(list);
			return pView;
		}else{
			return null;
		}
	}

	@Override
	public PieChartView getDetractorSubPieChart(
			Map<String, String> detractorMap, String linkName, String parentType) {
		if(detractorMap != null){
			List<PieSlice> list = null;
			if (DetractorEnum.Supply.toString().equals(parentType)) {
				list = this.getSupplyPieChart(detractorMap, linkName, parentType);
			} 
			else if (DetractorEnum.Over_SP.toString().equals(parentType)) {
				list = this.getOverSPPieChart(detractorMap, linkName, parentType);
			} 
			else if (DetractorEnum.Fulfillment.toString().equals(parentType)) {
				list = this.getFulfillmentPieChart(detractorMap, linkName, parentType);
			} 
			else if (DetractorEnum.MFG_Quality.toString().equals(parentType)) {
				list = this.getMFGQualityPieChart(detractorMap, linkName, parentType);
			} 
			else if (DetractorEnum.Future.toString().equals(parentType)) {
				list = this.getFuturePieChart(detractorMap, linkName, parentType);
			} 
			else if (DetractorEnum.DB.toString().equals(parentType)) {
				list = this.getDBPieChart(detractorMap, linkName, parentType);
			} 
			else if (DetractorEnum.NEW_Working.toString().equals(parentType)) {
				list = this.getNewWorkingPieChart(detractorMap, linkName, parentType);
			} 
			else if (DetractorEnum.To_Go_CA.toString().equals(parentType)) {
				list = this.getToGoCAPieChart(detractorMap, linkName, parentType);
			} 
			else if (DetractorEnum.Unknown.toString().equals(parentType)) {
				// list = getUnknownPieChart(detractorMap);
			}

			PieChartView pView = new PieChartView();
			pView.setElements(list);
			return pView;
		}else{
			return null;
		}
	}
	
	public List<PieSlice> getToGoCAPieChart(Map<String, String> detractorMap, String linkName, String parentType) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-"+linkName+"-" + ToGoCaEnum.To_Go_CA.toString() + "," + parentType);
		p1.setLabel(ToGoCaEnum.To_Go_CA.toString());
		p1.setColor(ToGoCaEnum.To_Go_CA.getColor());
		p1.setValue(detractorMap.get(ToGoCaEnum.To_Go_CA.getName().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);

		return list;
	}
	public List<PieSlice> getNewWorkingPieChart(Map<String, String> detractorMap, String linkName, String parentType) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-"+linkName+"-" + NewWorkingEnum.Working.toString() + "," + parentType);
		p1.setLabel(NewWorkingEnum.Working.toString());
		p1.setColor(NewWorkingEnum.Working.getColor());
		p1.setValue(detractorMap.get(NewWorkingEnum.Working.toString().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);

		return list;
	}
	public List<PieSlice> getDBPieChart(Map<String, String> detractorMap, String linkName, String parentType) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-"+linkName+"-" + DBEnum.Delivery_block_L.toString() + "," + parentType);
		p1.setLabel(DBEnum.Delivery_block_L.toString());
		p1.setColor(DBEnum.Delivery_block_L.getColor());
		p1.setValue(detractorMap.get(DBEnum.Delivery_block_L.toString().toUpperCase()));
		
		PieSlice p2 = new PieSlice();
		p2.setLink("j-"+linkName+"-" + DBEnum.Delivery_block.toString() + "," + parentType);
		p2.setLabel(DBEnum.Delivery_block.toString());
		p2.setColor(DBEnum.Delivery_block.getColor());
		p2.setValue(detractorMap.get(DBEnum.Delivery_block.toString().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);

		return list;
	}
	public List<PieSlice> getFulfillmentPieChart(Map<String, String> detractorMap, String linkName, String parentType) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-"+linkName+"-" + FulfillmentEnum.Holiday_Cycle_Count.toString() + "," + parentType);
		p1.setLabel(FulfillmentEnum.Holiday_Cycle_Count.toString());
		p1.setColor(FulfillmentEnum.Holiday_Cycle_Count.getColor());
		p1.setValue(detractorMap.get(FulfillmentEnum.Holiday_Cycle_Count.toString().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);

		return list;
	}
	public List<PieSlice> getSupplyPieChart(Map<String, String> detractorMap, String linkName, String parentType) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-"+linkName+"-" + SupplyEnum.BS_parts_shortage.toString() + "," + parentType);
		p1.setLabel(SupplyEnum.BS_parts_shortage.toString());
		p1.setColor(SupplyEnum.BS_parts_shortage.getColor());
		p1.setValue(detractorMap.get(SupplyEnum.BS_parts_shortage.toString().toUpperCase()));

		PieSlice p2 = new PieSlice();
		p2.setLink("j-"+linkName+"-" + SupplyEnum.ODM_buy_parts_shortage.toString() + "," + parentType);
		p2.setLabel(SupplyEnum.ODM_buy_parts_shortage.toString());
		p2.setColor(SupplyEnum.ODM_buy_parts_shortage.getColor());
		p2.setValue(detractorMap.get(SupplyEnum.ODM_buy_parts_shortage.toString().toUpperCase()));

		PieSlice p3 = new PieSlice();
		p3.setLink("j-"+linkName+"-" + SupplyEnum.Tie_order_L.toString() + "," + parentType);
		p3.setLabel(SupplyEnum.Tie_order_L.toString());
		p3.setColor(SupplyEnum.Tie_order_L.getColor());
		p3.setValue(detractorMap.get(SupplyEnum.Tie_order_L.toString().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);

		return list;
	}

	public List<PieSlice> getOverSPPieChart(Map<String, String> detractorMap, String linkName, String parentType) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-"+linkName+"-" + OverSPEnum.Over_EOL_LTB_L.toString() + "," + parentType);
		p1.setLabel(OverSPEnum.Over_EOL_LTB_L.toString());
		p1.setColor(OverSPEnum.Over_EOL_LTB_L.getColor());
		p1.setValue(detractorMap.get(OverSPEnum.Over_EOL_LTB_L.toString().toUpperCase()));

		PieSlice p2 = new PieSlice();
		p2.setLink("j-"+linkName+"-" + OverSPEnum.Over_forecast.toString() + "," + parentType);
		p2.setLabel(OverSPEnum.Over_forecast.toString());
		p2.setColor(OverSPEnum.Over_forecast.getColor());
		p2.setValue(detractorMap.get(OverSPEnum.Over_forecast.toString().toUpperCase()));
		
		PieSlice p3 = new PieSlice();
		p3.setLink("j-"+linkName+"-" + OverSPEnum.No_forecast.toString() + "," + parentType);
		p3.setLabel(OverSPEnum.No_forecast.toString());
		p3.setColor(OverSPEnum.No_forecast.getColor());
		p3.setValue(detractorMap.get(OverSPEnum.No_forecast.toString().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);

		return list;
	}

	public List<PieSlice> getMFGQualityPieChart(Map<String, String> detractorMap, String linkName, String parentType) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-"+linkName+"-" + MFGQualityEnum.Npi_issue_O.getName() + "," + parentType);
		p1.setLabel(MFGQualityEnum.Npi_issue_O.getName());
		p1.setColor(MFGQualityEnum.Npi_issue_O.getColor());
		p1.setValue(detractorMap.get(MFGQualityEnum.Npi_issue_O.getName().toUpperCase()));

		PieSlice p2 = new PieSlice();
		p2.setLink("j-"+linkName+"-" + MFGQualityEnum.Npi_issue_L.getName() + "," + parentType);
		p2.setLabel(MFGQualityEnum.Npi_issue_L.getName());
		p2.setColor(MFGQualityEnum.Npi_issue_L.getColor());
		p2.setValue(detractorMap.get(MFGQualityEnum.Npi_issue_L.getName().toUpperCase()));

		PieSlice p3 = new PieSlice();
		p3.setLink("j-"+linkName+"-" + MFGQualityEnum.Output_delay.getName() + "," + parentType);
		p3.setLabel(MFGQualityEnum.Output_delay.getName());
		p3.setColor(MFGQualityEnum.Output_delay.getColor());
		p3.setValue(detractorMap.get(MFGQualityEnum.Output_delay.getName().toUpperCase()));

		PieSlice p4 = new PieSlice();
		p4.setLink("j-"+linkName+"-" + MFGQualityEnum.Quality_issue_O.getName() + "," + parentType);
		p4.setLabel(MFGQualityEnum.Quality_issue_O.getName());
		p4.setColor(MFGQualityEnum.Quality_issue_O.getColor());
		p4.setValue(detractorMap.get(MFGQualityEnum.Quality_issue_O.getName().toUpperCase()));

		PieSlice p5 = new PieSlice();
		p5.setLink("j-"+linkName+"-" + MFGQualityEnum.Quality_issue_L.getName() + "," + parentType);
		p5.setLabel(MFGQualityEnum.Quality_issue_L.getName());
		p5.setColor(MFGQualityEnum.Quality_issue_L.getColor());
		p5.setValue(detractorMap.get(MFGQualityEnum.Quality_issue_L.getName().toUpperCase()));

		PieSlice p6 = new PieSlice();
		p6.setLink("j-"+linkName+"-" + MFGQualityEnum.Engineer_issue_O.getName() + "," + parentType);
		p6.setLabel(MFGQualityEnum.Engineer_issue_O.getName());
		p6.setColor(MFGQualityEnum.Engineer_issue_O.getColor());
		p6.setValue(detractorMap.get(MFGQualityEnum.Engineer_issue_O.getName().toUpperCase()));

		PieSlice p7 = new PieSlice();
		p7.setLink("j-"+linkName+"-" + MFGQualityEnum.Engineer_issue_L.getName() + "," + parentType);
		p7.setLabel(MFGQualityEnum.Engineer_issue_L.getName());
		p7.setColor(MFGQualityEnum.Engineer_issue_L.getColor());
		p7.setValue(detractorMap.get(MFGQualityEnum.Engineer_issue_L.getName().toUpperCase()));

		PieSlice p8 = new PieSlice();
		p8.setLink("j-"+linkName+"-" + MFGQualityEnum.Capacity_constraint_O.getName() + "," + parentType);
		p8.setLabel(MFGQualityEnum.Capacity_constraint_O.getName());
		p8.setColor(MFGQualityEnum.Capacity_constraint_O.getColor());
		p8.setValue(detractorMap.get(MFGQualityEnum.Capacity_constraint_O.toString().toUpperCase()));

		PieSlice p9 = new PieSlice();
		p9.setLink("j-"+linkName+"-" + MFGQualityEnum.Capacity_constraint_L.getName() + "," + parentType);
		p9.setLabel(MFGQualityEnum.Capacity_constraint_L.getName());
		p9.setColor(MFGQualityEnum.Capacity_constraint_L.getColor());
		p9.setValue(detractorMap.get(MFGQualityEnum.Capacity_constraint_L.toString().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		list.add(p5);
		list.add(p6);
		list.add(p7);
		list.add(p8);
		list.add(p9);

		return list;
	}

	public List<PieSlice> getFuturePieChart(Map<String, String> detractorMap, String linkName, String parentType) {
		PieSlice p1 = new PieSlice();
		p1.setLink("j-"+linkName+"-" + FutureEnum.Future_order_L.toString() + "," + parentType);
		p1.setLabel(FutureEnum.Future_order_L.toString());
		p1.setColor(FutureEnum.Future_order_L.getColor());
		p1.setValue(detractorMap.get(FutureEnum.Future_order_L.toString().toUpperCase()));

		PieSlice p2 = new PieSlice();
		p2.setLink("j-"+linkName+"-" + FutureEnum.Late_RSD_L.toString() + "," + parentType);
		p2.setLabel(FutureEnum.Late_RSD_L.toString());
		p2.setColor(FutureEnum.Late_RSD_L.getColor());
		p2.setValue(detractorMap.get(FutureEnum.Late_RSD_L.toString().toUpperCase()));

		PieSlice p3 = new PieSlice();
		p3.setLink("j-"+linkName+"-" + FutureEnum.Late_order_L.toString() + "," + parentType);
		p3.setLabel(FutureEnum.Late_order_L.toString());
		p3.setColor(FutureEnum.Late_order_L.getColor());
		p3.setValue(detractorMap.get(FutureEnum.Late_order_L.toString().toUpperCase()));
		
		PieSlice p4 = new PieSlice();
		p3.setLink("j-"+linkName+"-" + FutureEnum.Future_order.toString() + "," + parentType);
		p3.setLabel(FutureEnum.Future_order.toString());
		p3.setColor(FutureEnum.Future_order.getColor());
		p3.setValue(detractorMap.get(FutureEnum.Future_order.toString().toUpperCase()));

		List<PieSlice> list = new ArrayList<PieSlice>();
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		return list;
	}
	
	@Override
	public Map<String,Object> getOrderDetail(List<String> orderKeys, SearchOtsForm form){
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		if(CollectionUtils.isNotEmpty(orderKeys)){
			totalCount = npiOrderDaoDw.getDetractorCodeCountByOrderkeys(null, null, orderKeys,form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				grid = npiOrderDaoDw.getDetractorCodeDataByOrderkeys(null, null, orderKeys,form); 
			}
		}
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	
}
