package com.lenovo.bi.view.npi.ttm;

import java.util.List;

import com.lenovo.bi.view.npi.ProductWave;
/**
 * 
 * 
 * @author henry_lian
 *
 */
public class TTMProductDetail {
	private ProjectInformation info;
	private List<ProductWave> productWaves;
	private ProductWave currentWave;
	private List<DoiGrid> doiViews;
	private List<DefectView> gatingDefects;
	private List<DefectView> nonOOB;
	private List<DefectView> obes;
	private ToolingCapacityGrid tooling;
	private OdmCapacityGrid odmPlanDetails;
	private String fypTarget;
	private String fypActual;
	private String obeTarget;
	private String obeActual;
	
	public String getFypTarget() {
		return fypTarget;
	}
	public void setFypTarget(String fypTarget) {
		this.fypTarget = fypTarget;
	}
	public String getFypActual() {
		return fypActual;
	}
	public void setFypActual(String fypActual) {
		this.fypActual = fypActual;
	}
	public String getObeTarget() {
		return obeTarget;
	}
	public void setObeTarget(String obeTarget) {
		this.obeTarget = obeTarget;
	}
	public String getObeActual() {
		return obeActual;
	}
	public void setObeActual(String obeActual) {
		this.obeActual = obeActual;
	}
	public ProductWave getCurrentWave() {
		return currentWave;
	}
	public void setCurrentWave(ProductWave currentWave) {
		this.currentWave = currentWave;
	}
	public ProjectInformation getInfo() {
		return info;
	}
	public void setInfo(ProjectInformation info) {
		this.info = info;
	}
	public List<ProductWave> getProductWaves() {
		return productWaves;
	}
	public void setProductWaves(List<ProductWave> productWaves) {
		this.productWaves = productWaves;
	}
	public List<DoiGrid> getDoiViews() {
		return doiViews;
	}
	public void setDoiViews(List<DoiGrid> doiViews) {
		this.doiViews = doiViews;
	}
	public List<DefectView> getGatingDefects() {
		return gatingDefects;
	}
	public void setGatingDefects(List<DefectView> gatingDefects) {
		this.gatingDefects = gatingDefects;
	}
	public List<DefectView> getNonOOB() {
		return nonOOB;
	}
	public void setNonOOB(List<DefectView> nonOOB) {
		this.nonOOB = nonOOB;
	}
	public List<DefectView> getObes() {
		return obes;
	}
	public void setObes(List<DefectView> obes) {
		this.obes = obes;
	}
	public ToolingCapacityGrid getTooling() {
		return tooling;
	}
	public void setTooling(ToolingCapacityGrid tooling) {
		this.tooling = tooling;
	}
	public OdmCapacityGrid getOdmPlanDetails() {
		return odmPlanDetails;
	}
	public void setOdmPlanDetails(OdmCapacityGrid odmPlanDetails) {
		this.odmPlanDetails = odmPlanDetails;
	}
	
}
