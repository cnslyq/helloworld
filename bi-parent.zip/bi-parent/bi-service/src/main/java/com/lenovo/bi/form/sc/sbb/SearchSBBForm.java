package com.lenovo.bi.form.sc.sbb;

import com.lenovo.common.model.PagerInformation;


public class SearchSBBForm {
	private String geoIds;
	private String productIds;
	private String sbbType;
	private String demandStatus;
	
	private String sortColumn;
	private String sortType;
	private int endRow;
	private long rowCount;
	private String reversalSortType;
	
	private int currentPage=1;
	
	private PagerInformation pagerInfo;
	
	public String getGeoIds() {
		return geoIds;
	}
	public void setGeoIds(String geoIds) {
		this.geoIds = geoIds;
	}
	public String getProductIds() {
		return productIds;
	}
	public void setProductIds(String productIds) {
		this.productIds = productIds;
	}
	public String getSortColumn() {
		return sortColumn;
	}
	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}
	public String getSortType() {
		return sortType;
	}
	public void setSortType(String sortType) {
		this.sortType = sortType;
		if("asc".equalsIgnoreCase(sortType)){
			this.reversalSortType = "desc";
		}else if("desc".equalsIgnoreCase(sortType)){
			this.reversalSortType = "asc";
		}
	}
	public int getEndRow() {
		return endRow;
	}
	public void setEndRow(int endRow) {
		this.endRow = endRow;
	}
	public long getRowCount() {
		return rowCount;
	}
	public void setRowCount(long rowCount) {
		this.rowCount = rowCount;
	}
	public String getReversalSortType() {
		return reversalSortType;
	}
	public void setReversalSortType(String reversalSortType) {
		this.reversalSortType = reversalSortType;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public PagerInformation getPagerInfo() {
		return pagerInfo;
	}
	public void setPagerInfo(PagerInformation pagerInfo) {
		this.pagerInfo = pagerInfo;
	}
	public String getSbbType() {
		return sbbType;
	}
	public void setSbbType(String sbbType) {
		this.sbbType = sbbType;
	}
	public String getDemandStatus() {
		return demandStatus;
	}
	public void setDemandStatus(String demandStatus) {
		this.demandStatus = demandStatus;
	}
	
}
