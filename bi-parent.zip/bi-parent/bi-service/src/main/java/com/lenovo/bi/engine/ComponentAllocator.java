package com.lenovo.bi.engine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.lenovo.bi.dto.CtoCvConfig;
import com.lenovo.bi.dto.DnsEntry;
import com.lenovo.bi.dto.EolForecast;
import com.lenovo.bi.dto.Forecast;
import com.lenovo.bi.dto.MtmCvConfig;
import com.lenovo.bi.dto.MtmGeographyOdmCvQuantity;
import com.lenovo.bi.dto.Product;
import com.lenovo.bi.dto.SingleUnitCvConfig;
import com.lenovo.bi.enumobj.DnsShortageCodeEnum;
import com.lenovo.bi.enumobj.ForecastCommitTypeEnum;
import com.lenovo.bi.model.WeeklyComponentCommitmentOnMtmCto;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.SysConstants;
import com.lenovo.common.logging.Logger;
import com.lenovo.common.logging.LoggerFactory;

public class ComponentAllocator {
	private static Logger LOGGER = LoggerFactory.getLogger(SysConstants.LOG_WEEKLY_BATCH_CATALOG);

	private List<Date> targetDates;
	private Date versionDate;

	// One HashMap per week
	private List<HashMap<BomNumberGeographyOdmCvKeyKey, Integer>> mtmQuotas = new ArrayList<HashMap<BomNumberGeographyOdmCvKeyKey, Integer>>();
	private List<HashMap<BomNumberGeographyOdmCvKeyKey, Integer>> ctoQuotas = new ArrayList<HashMap<BomNumberGeographyOdmCvKeyKey, Integer>>();

	private List<Forecast> allForecastsInWeek;

	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	private TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper;

	private MtmCvConfigMap mtmCvConfigMap;

	public ComponentAllocator(List<Date> targetDates, Date versionDate, MtmCvConfigMap mtmCvConfigMap) {
		super();
		this.versionDate = versionDate;
		this.targetDates = targetDates;
		this.mtmCvConfigMap = mtmCvConfigMap;

		for (int i = 0; i < targetDates.size(); i++) {
			mtmQuotas.add(new HashMap<BomNumberGeographyOdmCvKeyKey, Integer>());
			ctoQuotas.add(new HashMap<BomNumberGeographyOdmCvKeyKey, Integer>());
		}
	}

	public void run() {
		// The component pool is shared among all weeks
		ComponentPool componentPool = new ComponentPool(ttvOutlookServiceDwHelper, versionDate);

		for (int i = 0; i < targetDates.size(); i++) {
			Date targetDate = targetDates.get(i);

			LOGGER.info("Process target date: " + targetDate);

			componentPool.initializePool(targetDate);

			// Step 1
			allocateToEolForecasts(componentPool, targetDate, i);

			// Step 3
			allocateNoShortageCv(componentPool, i);

			// Step 4
			allocateTimingIssueCv(componentPool, targetDate, i);

			// Step 5
			allocateShortageCv(componentPool, targetDate, i);

			// Persist the quotas
			persistQuotas(mtmQuotas.get(i), targetDate, false);
			persistQuotas(ctoQuotas.get(i), targetDate, true);
		}
	}

	public void setTtvOutlookServiceDwHelper(TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper) {
		this.ttvOutlookServiceDwHelper = ttvOutlookServiceDwHelper;
	}

	public void setTtvOutlookServiceBiHelper(TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper) {
		this.ttvOutlookServiceBiHelper = ttvOutlookServiceBiHelper;
	}

	public List<HashMap<BomNumberGeographyOdmCvKeyKey, Integer>> getMtmComponentQuotas() {
		return mtmQuotas;
	}

	public List<HashMap<BomNumberGeographyOdmCvKeyKey, Integer>> getCtoComponentQuotas() {
		return ctoQuotas;
	}

	private void allocateToEolForecasts(ComponentPool componentPool, Date targetMonday, int weekNumber) {
		// Retrieve EOL products
		List<Product> allEolProductsInWeek = ttvOutlookServiceDwHelper.getAllEolProductsInWeek(targetMonday, weekNumber > 0);

		Map<Integer, Product> eolProductMap = new HashMap<Integer, Product>();

		for (Product product : allEolProductsInWeek) {
			eolProductMap.put(product.getProductKey(), product);
		}

		// MTM forecasts first
		allForecastsInWeek = ttvOutlookServiceDwHelper.getAllMtmForecastsInWeek(targetMonday, versionDate);

		// Add CTO forecasts
		List<CtoCvConfig> allCtoForecastsInWeek = ttvOutlookServiceDwHelper.getAllCtoForecastsInWeek(targetMonday, versionDate);

		combineCtoForecasts(allForecastsInWeek, allCtoForecastsInWeek);

		List<EolForecast> eolForecastsInWeek = new ArrayList<EolForecast>();

		for (int j = 0; j < allForecastsInWeek.size(); j++) {
			Forecast forecast = allForecastsInWeek.get(j);
			Product eolProduct = eolProductMap.get(forecast.getProductKey());
			if (eolProduct != null) { // It is forecast of EOL product
				EolForecast eolForecast = new EolForecast(forecast, eolProduct.getEolDate());
				allForecastsInWeek.set(j, eolForecast); // Replace with EOL
														// forecast

				eolForecastsInWeek.add(eolForecast);
			}
		}

		Map<BomNumberGeographyOdmCvKeyKey, Integer> mtmQuotaForTheWeek = mtmQuotas.get(weekNumber);
		Map<BomNumberGeographyOdmCvKeyKey, Integer> ctoQuotaForTheWeek = ctoQuotas.get(weekNumber);

		Collections.sort(eolForecastsInWeek, new EolForecastDateComparator());

		for (EolForecast eolForecast : eolForecastsInWeek) {
			if (eolForecast.getForecastType() != ForecastCommitTypeEnum.CTO) { // 59
																				// and
																				// MTM
				SingleUnitCvConfig singleUnitCvConfig = mtmCvConfigMap.getSingleUnitCvConfigOfMtm(eolForecast.getBomNumber());
				if (singleUnitCvConfig != null) {// add by Nicolas on July
													// 4,2014
					MtmCvConfig mtmCvConfig = new MtmCvConfig(singleUnitCvConfig, eolForecast.getQuantity());
					int maxNumberOfUnits = componentPool.calculateMaxMtmNumberOfUnits(mtmCvConfig);

					if (maxNumberOfUnits > 0) {
						eolForecast.setQuantity(eolForecast.getQuantity() - maxNumberOfUnits);
						componentPool.deductMtmUnits(singleUnitCvConfig, maxNumberOfUnits);

						Set<Integer> allCvs = singleUnitCvConfig.getAllCvs();

						for (Integer cvKey : allCvs) {
							BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(eolForecast.getBomNumber(), eolForecast.getGeographyName(),
									eolForecast.getOdmName(), cvKey);

							Integer originalQuantity = mtmQuotaForTheWeek.get(key);
							if (originalQuantity == null) {
								mtmQuotaForTheWeek.put(key, singleUnitCvConfig.getQuantity(cvKey) * maxNumberOfUnits);
							} else {
								mtmQuotaForTheWeek.put(key, originalQuantity + singleUnitCvConfig.getQuantity(cvKey) * maxNumberOfUnits);
							}
						}
					}
				}
			} else { // CTO
						// CTO does not consider the box-level number of units

				CtoCvConfig ctoCvConfig = eolForecast.getCtoCvConfig();
				for (Integer cvKey : ctoCvConfig.getAllCvs()) {
					int existingQuantity = ctoCvConfig.getQuantity(cvKey);
					int deductedQuantity = componentPool.deductMaxCvQuantity(cvKey, existingQuantity);

					if (deductedQuantity > 0) {
						ctoCvConfig.addCv(cvKey, existingQuantity - deductedQuantity); // Addition
																						// is
																						// replacement.

						BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(eolForecast.getBomNumber(), eolForecast.getGeographyName(),
								eolForecast.getOdmName(), cvKey);

						Integer originalQuantity = ctoQuotaForTheWeek.get(key);
						if (originalQuantity == null) {
							ctoQuotaForTheWeek.put(key, deductedQuantity);
						} else {
							ctoQuotaForTheWeek.put(key, originalQuantity + deductedQuantity);
						}
					}
				}
			}
		}
	}

	private void persistQuotas(HashMap<BomNumberGeographyOdmCvKeyKey, Integer> quotas, Date targetDate, boolean isCto) {
		Date now = new Date();
		List<WeeklyComponentCommitmentOnMtmCto> commitments = new ArrayList<WeeklyComponentCommitmentOnMtmCto>();

		Set<BomNumberGeographyOdmCvKeyKey> keySet = quotas.keySet();

		for (BomNumberGeographyOdmCvKeyKey key : keySet) {
			Integer quantity = quotas.get(key);

			WeeklyComponentCommitmentOnMtmCto commitment = new WeeklyComponentCommitmentOnMtmCto();
			commitment.setBomNumber(key.getBomNumber());
			commitment.setGlobalCvKey(key.getCvKey());
			commitment.setGeographyName(key.getGeographyName());
			commitment.setOdmName(key.getOdmName());
			commitment.setCto(isCto);
			commitment.setCommitment(quantity);
			commitment.setVersionDate(versionDate);
			commitment.setTargetDate(targetDate);
			commitment.setCreatedDate(now);
			commitment.setLastModifiedDate(now);

			commitments.add(commitment);
		}

		ttvOutlookServiceBiHelper.addWeeklyComponentCommitmentOnMtmCto(commitments);
	}

	private void allocateNoShortageCv(ComponentPool componentPool, int weekNumber) {
		List<Integer> noShortageCvs = componentPool.filterCvsWithShortageCode(DnsShortageCodeEnum.NO_SHORTAGE);

		// Allocate CV to forecasts based on the weight of the demand over total
		// demand after EOL
		for (Integer cvKey : noShortageCvs) {
			DnsEntry dnsEntry = componentPool.getDnsEntry(cvKey);
			int quantityToAllocate = Math.min(dnsEntry.getDemand(), dnsEntry.getSupply());
			int totalDemand = calculateTotalDemandFromForecasts(allForecastsInWeek, cvKey);

			allocateCvBasedOnForecasts(componentPool, allForecastsInWeek, cvKey, quantityToAllocate, totalDemand, weekNumber);
		}
	}

	private void allocateCvBasedOnForecasts(ComponentPool componentPool, List<Forecast> forecasts, int cvKey, int quantityToAllocate, int totalDemand,
			int weekNumber) {
		Map<BomNumberGeographyOdmCvKeyKey, Integer> mtmQuotaForTheWeek = mtmQuotas.get(weekNumber);
		Map<BomNumberGeographyOdmCvKeyKey, Integer> ctoQuotaForTheWeek = ctoQuotas.get(weekNumber);

		int allocatedQuantity = 0;

		for (Forecast forecast : forecasts) {
			if (forecast.getForecastType() != ForecastCommitTypeEnum.CTO) {
				if (totalDemand > 0) {
					if (mtmCvConfigMap.getSingleUnitCvConfigOfMtm(forecast.getBomNumber()) != null) {
						MtmCvConfig mtmCvConfig = new MtmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(forecast.getBomNumber()), forecast.getQuantity());
						allocatedQuantity = quantityToAllocate * mtmCvConfig.getQuantity(cvKey) / totalDemand;
					}
					if (allocatedQuantity > 0) {
						BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(forecast.getBomNumber(), forecast.getGeographyName(),
								forecast.getOdmName(), cvKey);

						if (mtmQuotaForTheWeek.get(key) == null) {
							mtmQuotaForTheWeek.put(key, allocatedQuantity);
						} else {
							mtmQuotaForTheWeek.put(key, mtmQuotaForTheWeek.get(key) + allocatedQuantity);
						}

						componentPool.deductMaxCvQuantity(cvKey, allocatedQuantity);
					}
				}
			} else {
				if (totalDemand > 0) {
					allocatedQuantity = quantityToAllocate * forecast.getCtoCvConfig().getQuantity(cvKey) / totalDemand;

					if (allocatedQuantity > 0) {
						BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(forecast.getBomNumber(), forecast.getGeographyName(),
								forecast.getOdmName(), cvKey);

						if (ctoQuotaForTheWeek.get(key) == null) {
							ctoQuotaForTheWeek.put(key, allocatedQuantity);
						} else {
							ctoQuotaForTheWeek.put(key, ctoQuotaForTheWeek.get(key) + allocatedQuantity);
						}

						componentPool.deductMaxCvQuantity(cvKey, allocatedQuantity);
					}
				}
			}
		}

	}

	private int calculateTotalDemandFromForecasts(List<Forecast> forecasts, Integer cvKey) {
		int totalDemand = 0;

		for (Forecast forecast : forecasts) {
			if (forecast.getForecastType() != ForecastCommitTypeEnum.CTO) { // 59
																			// and
																			// MTM
				if (mtmCvConfigMap.getSingleUnitCvConfigOfMtm(forecast.getBomNumber()) != null) {// add
																									// by
																									// Nicolas
																									// on
																									// Jul
																									// 3,2014
					MtmCvConfig mtmCvConfig = new MtmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(forecast.getBomNumber()), forecast.getQuantity());
					totalDemand += mtmCvConfig.getQuantity(cvKey);
				}
			} else { // CTO
				totalDemand += forecast.getCtoCvConfig().getQuantity(cvKey);
			}
		}

		return totalDemand;
	}

	private void allocateTimingIssueCv(ComponentPool componentPool, Date targetDate, int weekNumber) {
		Map<BomNumberGeographyOdmCvKeyKey, Integer> mtmQuotaForTheWeek = mtmQuotas.get(weekNumber);
		Map<BomNumberGeographyOdmCvKeyKey, Integer> ctoQuotaForTheWeek = ctoQuotas.get(weekNumber);

		List<Integer> timingIssueCvs = componentPool.filterCvsWithShortageCode(DnsShortageCodeEnum.TIMING_ISSUE);

		int allocatedQuantity = 0;

		// Calculate remaining demand
		List<MtmGeographyOdmCvQuantity> allFulfilledCvQuantity = ttvOutlookServiceDwHelper.getAllFulfilledCvQuantityInMonth(targetDate, versionDate);
		Map<BomNumberGeographyOdmCvKeyKey, MtmGeographyOdmCvQuantity> fulfilledCvQuantityMap = convertToMap(allFulfilledCvQuantity);

		List<MtmGeographyOdmCvQuantity> allMtmForecastCvQuantity = ttvOutlookServiceDwHelper.getAllMtmForecastCvQuantityInMonth(targetDate, versionDate);

		for (MtmGeographyOdmCvQuantity item : allMtmForecastCvQuantity) {
			BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(item.getBomNumber(), item.getGeographyName(), item.getOdmName(),
					item.getCvKey());
			MtmGeographyOdmCvQuantity fulfilledCvQuantity = fulfilledCvQuantityMap.get(key);

			if (fulfilledCvQuantity != null) {
				item.setQuantity(item.getQuantity() >= fulfilledCvQuantity.getQuantity() ? item.getQuantity() - fulfilledCvQuantity.getQuantity() : 0);
			}
		}

		List<MtmGeographyOdmCvQuantity> allCtoForecastCvQuantity = ttvOutlookServiceDwHelper.getAllCtoForecastCvQuantityInMonth(targetDate, versionDate);

		// Calculate total demand
		for (MtmGeographyOdmCvQuantity item : allMtmForecastCvQuantity) {
			componentPool.incrementTotalDemand(item.getCvKey(), item.getQuantity());
		}

		for (MtmGeographyOdmCvQuantity item : allCtoForecastCvQuantity) {
			componentPool.incrementTotalDemand(item.getCvKey(), item.getQuantity());
		}

		// Allocate CV to forecasts based on the weight of the demand excluding
		// shipped orders
		for (Integer cvKey : timingIssueCvs) {
			DnsEntry dnsEntry = componentPool.getDnsEntry(cvKey);
			int quantityToAllocate = Math.min(dnsEntry.getDemand(), dnsEntry.getSupply());
			int totalRemainingDemand = dnsEntry.getTotalDemand();

			for (MtmGeographyOdmCvQuantity item : allMtmForecastCvQuantity) {
				if (totalRemainingDemand > 0 && item.getCvKey() == cvKey) {
					allocatedQuantity = quantityToAllocate * item.getQuantity() / totalRemainingDemand;

					if (allocatedQuantity > 0) {
						BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(item.getBomNumber(), item.getGeographyName(), item.getOdmName(),
								cvKey);

						if (mtmQuotaForTheWeek.get(key) == null) {
							mtmQuotaForTheWeek.put(key, allocatedQuantity);
						} else {
							mtmQuotaForTheWeek.put(key, mtmQuotaForTheWeek.get(key) + allocatedQuantity);
						}
					}

					componentPool.deductMaxCvQuantity(cvKey, allocatedQuantity);
				}
			}
		}

		for (Integer cvKey : timingIssueCvs) {
			DnsEntry dnsEntry = componentPool.getDnsEntry(cvKey);
			int quantityToAllocate = Math.min(dnsEntry.getDemand(), dnsEntry.getSupply());
			int totalRemainingDemand = dnsEntry.getTotalDemand();

			for (MtmGeographyOdmCvQuantity item : allCtoForecastCvQuantity) {
				if (totalRemainingDemand > 0) {
					allocatedQuantity = quantityToAllocate * item.getQuantity() / totalRemainingDemand;

					if (allocatedQuantity > 0) {
						BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(item.getBomNumber(), item.getGeographyName(), item.getOdmName(),
								cvKey);

						if (ctoQuotaForTheWeek.get(key) == null) {
							ctoQuotaForTheWeek.put(key, allocatedQuantity);
						} else {
							ctoQuotaForTheWeek.put(key, ctoQuotaForTheWeek.get(key) + allocatedQuantity);
						}
					}

					componentPool.deductMaxCvQuantity(cvKey, allocatedQuantity);
				}
			}
		}
	}

	private void allocateShortageCv(ComponentPool componentPool, Date targetMonday, int weekNumber) {
		List<Integer> shortageCvs = componentPool.filterCvsWithShortageCode(DnsShortageCodeEnum.SHORTAGE);

		// Normal quantity
		Date minus8VersionDate = CalendarUtil.getMondayDateByWeeks(new Date(), -8);
		List<Forecast> allForecastsInWeekMinus8Version = ttvOutlookServiceDwHelper.getAllMtmForecastsInWeek(targetMonday, minus8VersionDate);
		List<CtoCvConfig> allCtoForecastsInWeekMinus8Version = ttvOutlookServiceDwHelper.getAllCtoForecastsInWeek(targetMonday, minus8VersionDate);

		combineCtoForecasts(allForecastsInWeekMinus8Version, allCtoForecastsInWeekMinus8Version);

		// Allocate CV to forecasts based on the weight of the demand over total
		// demand
		for (Integer cvKey : shortageCvs) {
			DnsEntry dnsEntry = componentPool.getDnsEntry(cvKey);
			int quantityToAllocate = Math.min(dnsEntry.getNormalQuantity(), dnsEntry.getSupply());
			int totalDemand = calculateTotalDemandFromForecasts(allForecastsInWeekMinus8Version, cvKey);

			allocateCvBasedOnForecasts(componentPool, allForecastsInWeekMinus8Version, cvKey, quantityToAllocate, totalDemand, weekNumber);
		}

		// Offset/upside quantity
		List<Forecast> allForecastsInWeek = ttvOutlookServiceDwHelper.getAllMtmForecastsInWeek(targetMonday, versionDate);
		List<CtoCvConfig> allCtoForecastsInWeek = ttvOutlookServiceDwHelper.getAllCtoForecastsInWeek(targetMonday, versionDate);

		combineCtoForecasts(allForecastsInWeek, allCtoForecastsInWeek);

		// Allocate CV to forecasts based on the weight of the demand over total
		// demand
		for (Integer cvKey : shortageCvs) {
			DnsEntry dnsEntry = componentPool.getDnsEntry(cvKey);

			if (dnsEntry.getSupply() > 0) { // Execute only there is still
											// supply
				int quantityToAllocate = Math.min(dnsEntry.getUpsideQuantity(), dnsEntry.getSupply());
				int totalDemand = calculateTotalDemandFromForecasts(allForecastsInWeek, cvKey);

				allocateCvBasedOnForecasts(componentPool, allForecastsInWeek, cvKey, quantityToAllocate, totalDemand, weekNumber);
			}
		}
	}

	private void combineCtoForecasts(List<Forecast> forecasts, List<CtoCvConfig> ctoForecasts) {
		for (CtoCvConfig ctoCvConfig : ctoForecasts) {
			Forecast ctoForecast = new Forecast();
			ctoForecast.setProductKey(Integer.valueOf(ctoCvConfig.getProductKey()));
			ctoForecast.setBomNumber(ctoCvConfig.getBomNumber());
			ctoForecast.setGeographyName(ctoCvConfig.getGeographyName());
			ctoForecast.setOdmName(ctoCvConfig.getOdmName());
			ctoForecast.setCtoCvConfig(ctoCvConfig);
			forecasts.add(ctoForecast);
		}
	}

	private Map<BomNumberGeographyOdmCvKeyKey, MtmGeographyOdmCvQuantity> convertToMap(List<MtmGeographyOdmCvQuantity> mtmCvQuantityList) {
		Map<BomNumberGeographyOdmCvKeyKey, MtmGeographyOdmCvQuantity> map = new HashMap<BomNumberGeographyOdmCvKeyKey, MtmGeographyOdmCvQuantity>();

		for (MtmGeographyOdmCvQuantity item : mtmCvQuantityList) {
			BomNumberGeographyOdmCvKeyKey key = new BomNumberGeographyOdmCvKeyKey(item.getBomNumber(), item.getGeographyName(), item.getOdmName(),
					item.getCvKey());
			map.put(key, item);
		}

		return map;
	}
}
