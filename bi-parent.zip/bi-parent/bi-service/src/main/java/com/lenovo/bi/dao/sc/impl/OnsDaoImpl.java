package com.lenovo.bi.dao.sc.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.OnsDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.dto.sc.OnsRemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.GeographyType;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;
import com.lenovo.common.model.PagerInformation;

@Repository
public class OnsDaoImpl extends HibernateBaseDaoImplDw implements OnsDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchOnsOverViewChartData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select case when sum(ons.OrderQuantity) is null then 0 else sum(ons.OrderQuantity) end as orderNum")
			   .append(" from FactMonthlySummaryofONS ons");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
	    else {
	    	sBuffer.append(" where ons.Year = ").append(form.getYear())
	    			.append(" and ons.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for SC overview:fpsd
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<OnsRemarkChartData> fetchDimensionRemarkDataList(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append("select SUB.RegionKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(SUB.OrderQuantity) as orderQuantity")
					.append(" from (select ons.*,geography.GeographyName as dimensionName ")
			   		.append(" from FactMonthlySummaryofONS ons ");
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on ons.regionkey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join DimGeography geography on geography.GeographyKey = ons.RegionKey");
			}
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where ons.Year = ").append(form.getYear())
	    			   .append(" and ons.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), ons.Year)+'-'+CONVERT(nvarchar(20), ons.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(ons.PONumber as nvarchar)+'_'+cast(ons.POItem as nvarchar)+'_'+cast(isnull(ons.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				sBuffer.append(" and geography.geographyname = 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				sBuffer.append(" and geography.geographyname <> 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:ODM or Product
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			}
			
			sBuffer.append(")SUB group by SUB.RegionKey,SUB.dimensionName order by orderQuantity DESC");
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append("select SUB.ODMKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(SUB.OrderQuantity) as orderQuantity")
					.append(" from (select ons.*,odm.ODMEnglishName as dimensionName ")
			   		.append(" from FactMonthlySummaryofONS ons ")
			   		.append(" left join DimODM odm on ons.ODMKey = odm.ODMKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on ons.regionkey = geoRegion.regionKey");
				
			}
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where ons.Year = ").append(form.getYear())
	    			   .append(" and ons.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), ons.Year)+'-'+CONVERT(nvarchar(20), ons.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(ons.PONumber as nvarchar)+'_'+cast(ons.POItem as nvarchar)+'_'+cast(isnull(ons.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:Region or Product
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and ons.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			} 
			
			sBuffer.append(")SUB group by SUB.ODMKey,SUB.dimensionName order by orderQuantity DESC");
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append("select SUB.ProductKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(SUB.OrderQuantity) as orderQuantity")
					.append(" from (select ons.*,product.ProductEnglishName as dimensionName ")
			   		.append(" from FactMonthlySummaryofONS ons ")
			   		.append(" join DimProduct product on ons.ProductKey = product.ProductKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on ons.regionkey = geoRegion.regionKey");
				
			}
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where ons.Year = ").append(form.getYear())
	    			   .append(" and ons.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), ons.Year)+'-'+CONVERT(nvarchar(20), ons.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(ons.PONumber as nvarchar)+'_'+cast(ons.POItem as nvarchar)+'_'+cast(isnull(ons.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:Region or Odm
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and ons.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			} 
			
			sBuffer.append(")SUB group by SUB.ProductKey,SUB.dimensionName order by orderQuantity DESC");
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			//sBuffer.append("select SUB.DetractorKey as dimensionKey,SUB.dimensionName as dimensionName,")
			sBuffer.append("select 0 as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(SUB.OrderQuantity) as orderQuantity ")
					.append(" from (select ons.*,isNull(detractor.Level1,'UNKNOWN') as dimensionName ")
			   		.append(" from FactMonthlySummaryofONS ons ")
			   		.append(" left join DimDetractor detractor on ons.DetractorKey = detractor.DetractorKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on ons.regionkey = geoRegion.regionKey");
				
			} 
		
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where ons.Year = ").append(form.getYear())
	    			   .append(" and ons.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), ons.Year)+'-'+CONVERT(nvarchar(20), ons.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(ons.PONumber as nvarchar)+'_'+cast(ons.POItem as nvarchar)+'_'+cast(isnull(ons.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:Region or Odm or Porduct
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and ons.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			}
			
			sBuffer.append(" )SUB group by SUB.dimensionName order by orderQuantity DESC");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
								.addScalar("dimensionKey", IntegerType.INSTANCE)
								.addScalar("dimensionName", StringType.INSTANCE)
								.addScalar("orderQuantity", IntegerType.INSTANCE)
								.setResultTransformer(Transformers.aliasToBean(OnsRemarkChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchGeoDimensions(SearchOtsForm form) {
		PagerInformation pagerInfo = form.getPagerInfo();
		StringBuffer sBuffer = new StringBuffer();
		
		//for Geo overview chart
		if("Region".equals(form.getDashboardType())) {
		    sBuffer.append("select geoRegion.geoKey as objkey,geoRegion.geoName as objname,'Geo' as type")
		    	   .append(" from FactMonthlySummaryofONS ons ")
		    	   .append(" left join ")
		    	   .append("(")
		    	   .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
		    	   .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
		    	   .append(")")
		    	   .append(" as geoRegion on ons.regionkey = geoRegion.regionKey");
		    	   
	    	/*sBuffer.append(" where ons.Year = ").append(form.getYear())
	    		.append(" and ons.Month = ").append(form.getMonth());*/
	    	sBuffer.append(" where ons.Year * 100 + ons.Month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
    		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
			
	    	if(form.getOrderTypeId() == 1) {
	    		sBuffer.append(" and geoRegion.geoName = 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				sBuffer.append(" and geoRegion.geoName <> 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			sBuffer.append(" group by geoRegion.geoKey,geoRegion.geoName having geoRegion.geoKey <> '' order by sum(OrderQuantity) desc");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchDimensions(SearchOtsForm form) {
		PagerInformation pagerInfo = form.getPagerInfo();
		StringBuffer sBuffer = new StringBuffer();
		
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
		    sBuffer.append("select ons.RegionKey as objKey,geography.GeographyName as objName,'Region' as type")
		    .append(" from FactMonthlySummaryofONS ons ")
		    .append(" left join DimGeography geography on ons.RegionKey = geography.GeographyKey");
		
		    sBuffer.append(" where ons.Year * 100 + ons.Month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
    		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
			
	    	if(form.getOrderTypeId() == 1) {
	    		sBuffer.append(" and geography.geographyname = 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (1,2)");
				}
			}
	    	
			if(form.getOrderTypeId() == 2) {
				sBuffer.append(" and geography.geographyname <> 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			//show geo or region overview 
			if(!form.isShowGeoOverview()) 
				sBuffer.append(" and geography.GeographyType = 'Region'");
			else
				sBuffer.append(" and geography.GeographyType = 'Geo'");
			
			sBuffer.append(" group by ons.RegionKey,geography.GeographyName having ons.RegionKey <> '' order by sum(OrderQuantity) desc");
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
		    sBuffer.append("select ons.ODMKey as objKey,odm.ODMEnglishName as objName,'Odm' as type")
		    .append(" from FactMonthlySummaryofONS ons ")
		    .append(" left join DimODM odm on ons.ODMKey = odm.ODMKey");
		    sBuffer.append(" where ons.Year * 100 + ons.Month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
    		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
			
	    	if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			sBuffer.append(" group by ons.ODMKey,odm.ODMEnglishName having ons.ODMKey <> '' order by sum(OrderQuantity) desc");
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
		    sBuffer.append("select ons.ProductKey as objKey,product.ProductEnglishName as objName,'Product' as type")
		    .append(" from FactMonthlySummaryofONS ons ")
		    .append(" left join DimProduct product on ons.ProductKey = product.ProductKey");
		    sBuffer.append(" where ons.Year * 100 + ons.Month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
    		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
			
	    	if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			sBuffer.append(" group by ons.ProductKey,product.ProductEnglishName having ons.ProductKey <> '' order by sum(OrderQuantity) desc");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchOnsRemarkChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select case when sum(ons.OrderQuantity) is null then 0 else sum(ons.OrderQuantity) end as orderNum")
			   .append(" from FactMonthlySummaryofONS ons");
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
			sBuffer.append(" where ons.Year*100 + ons.Month between ")
			   .append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				sBuffer.append(" where ons.Year*100 + ons.Month = ")
						.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			}
			//month
			else {
				sBuffer.append(" where ons.Year*100 + ons.Month between ")
				   .append(CalendarUtil.yearMonthConvert(form.getStartDate()))
				   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
			}
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ons.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())) {
				sBuffer.append(" and ons.DetractorKey is null");
			}
			else {
				sBuffer.append(" and ons.DetractorKey in (")
						.append(" select detractorKey from dimDetractor where level1 = '")
						.append(form.getSubDimension()).append("')");
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchOnsGeoRemarkChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select case when sum(ons.OrderQuantity) is null then 0 else sum(ons.OrderQuantity) end as orderNum")
			   .append(" from FactMonthlySummaryofONS ons");
		
		if(form.getDashboardTypeKey() != -1) {
			if("Region".equals(form.getDashboardType())) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on ons.regionkey = geoRegion.regionKey");
			}
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType()))
			sBuffer.append(" where ons.Year*100 + ons.Month between ")
			   .append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				sBuffer.append(" where ons.Year*100 + ons.Month = ")
						.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			}
			//month
			else {
				sBuffer.append(" where ons.Year*100 + ons.Month between ")
				   .append(CalendarUtil.yearMonthConvert(form.getStartDate()))
				   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
			}
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ons.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			//sBuffer.append(" and ons.DetractorKey = ").append(form.getSubDimensionKey());
			if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())) {
				sBuffer.append(" and ons.DetractorKey is null");
			}
			else {
				sBuffer.append(" and ons.DetractorKey in (")
						.append(" select detractorKey from dimDetractor where level1 = '")
						.append(form.getSubDimension()).append("')");
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		if(form.getDashboardTypeKey() != -1)
			sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchOnsDashboardOverViewChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select case when sum(ons.OrderQuantity) is null then 0 else sum(ons.OrderQuantity) end as orderNum")
			   .append(" from FactMonthlySummaryofONS ons")
			   .append(" where ons.Year * 100 + ons.Month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
			sBuffer.append(" and ons.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchOnsGeoDashboardOverViewChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select case when sum(ons.OrderQuantity) is null then 0 else sum(ons.OrderQuantity) end as orderNum")
			   .append(" from FactMonthlySummaryofONS ons")
			   .append(" left join ")
		       .append("(")
		       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
		       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
		       .append(")")
		       .append(" as geoRegion on ons.regionkey = geoRegion.regionKey")
			   .append(" where ons.Year * 100 + ons.Month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
    		   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()))
			   .append(" and geoRegion.geoKey = ").append(form.getGeoKey());
		
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
			//sBuffer.append(" and ons.RegionKey = ").append(form.getGeoKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchOnsCrossMonthOverviewChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select case when sum(ons.OrderQuantity) is null then 0 else sum(ons.OrderQuantity) end as orderNum")
			   .append(" from FactMonthlySummaryofONS ons");
		if(form.isShowQuarterOverview())
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
	    else {
	    	sBuffer.append(" where ons.Year = ").append(form.getYear())
	    		.append(" and ons.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ons.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> getOverviewOverall(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select case when sum(ons.OrderQuantity) is null then 0 else sum(ons.OrderQuantity) end as orderNum")
			   .append(" from FactMonthlySummaryofONS ons")
			   .append(" where ons.Year*100 + ons.Month between ")
			   .append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//crossmonth overview chart:Region or Odm or Porduct
		/*if(form.getCrossMonthTypeKey() != -1) {
			if("Region".equals(form.getCrossMonthType()))
				sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
			else if("Odm".equals(form.getCrossMonthType()))
				sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
			else if("Product".equals(form.getCrossMonthType()))
				sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
		}*/
		//for Region overview chart
		if("Region".equals(form.getCrossMonthType())) {
			sBuffer.append(" and ons.RegionKey = ").append(form.getCrossMonthTypeKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getCrossMonthType())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getCrossMonthTypeKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getCrossMonthType())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getCrossMonthTypeKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchOnsOverViewSumOrderDetailData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select ons.orderKey as orderKey")
			   .append(" from FactMonthlySummaryofONS ons");
		if(form.isShowQuarterOverview())
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
	    else {
	    	sBuffer.append(" where ons.Year = ").append(form.getYear())
	    		.append(" and ons.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchOnsCrossMonthSumOrderDetailData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  ons.orderKey as orderKey")
			   .append(" from FactMonthlySummaryofONS ons");
		if(form.isShowQuarterOverview())
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
	    else {
	    	sBuffer.append(" where ons.Year = ").append(form.getYear())
	    		.append(" and ons.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ons.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchOnsDashboardSumOrderDetailData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select ons.orderKey as orderKey")
			   .append(" from FactMonthlySummaryofONS ons")
			   .append(" where ons.Year = ").append(form.getYear())
			   .append(" and ons.Month = ").append(form.getMonth());
		
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
			sBuffer.append(" and ons.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		
		return query.list();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchOnsOrderKeysByDims(SearchOtsForm form) {
		StringBuffer sb = new StringBuffer();
		sb.append("select ons.OrderKey from FactMonthlySummaryofONS ons");
		if(StringUtils.isNotBlank(form.getLevel1Detractor()) || StringUtils.isNotBlank(form.getLevel2Detractor())){
			sb.append(" inner join dimdetractor d on d.detractorKey = ons.detractorKey");
		}
		sb.append(" where ons.year*100 + ons.month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and  ons.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and  ons.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and  ons.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sb.append(" and  ons.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor())){
			sb.append(" and upper(d.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor())){
			sb.append(" and upper(d.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PieDivider> getDetractorMainDivider(SearchOtsForm form) {
		StringBuffer sb = new StringBuffer();
		if(form.getLevel() == 2){
			sb.append("select ISNULL(upper(rtrim(ltrim(d.Level2))),'UNKNOWN') as level2Name,count(ons.id) as level2Num ");
		}else{
			sb.append("select ISNULL(upper(rtrim(ltrim(d.Level1))),'UNKNOWN') as level1Name,count(ons.id) as level1Num ");
		}
		sb.append(" from FactMonthlySummaryofOns ons")
			.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
			.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
			;
		sb.append(" left join dimdetractor d on d.detractorkey = ons.detractorkey ");
		sb.append(" where ons.year*100 + ons.month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sb.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sb.append(" and  ons.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and  ons.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and  ons.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sb.append(" and  ons.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor())){
			sb.append(" and upper(d.Level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(form.getLevel() == 2){
			sb.append(" group by d.Level2 ");
		}else{
			sb.append(" group by d.Level1 ");
		}
		Query query;
		if(form.getLevel() == 2){
			query = getSession().createSQLQuery(sb.toString())
					.addScalar("level2Name", StringType.INSTANCE)
					.addScalar("level2Num", IntegerType.INSTANCE)
					.setResultTransformer(Transformers.aliasToBean(PieDivider.class));
		}else{
			query = getSession().createSQLQuery(sb.toString())
					.addScalar("level1Name", StringType.INSTANCE)
					.addScalar("level1Num", IntegerType.INSTANCE)
					.setResultTransformer(Transformers.aliasToBean(PieDivider.class));
		}
		return query.list();
	}	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchOnsOverViewRemarkOrderDetailData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select ons.OrderKey as orderKey ")
			   .append(" from FactMonthlySummaryofOnS ons ");
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimGeography geo on ons.RegionKey = geo.GeographyKey and geo.GeographyType = '"
					+ GeographyType.Region.name()
					+ "' and geo.GeographyName = '"
					+ form.getSubDimension().toUpperCase()+ "' ");
		}else if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimODM odm on ons.ODMKey = odm.ODMKey and odm.ODMEnglishName = '"
					+ form.getSubDimension().toUpperCase() + "' ");
		}else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimProduct pro on ons.ProductKey = pro.ProductKey and pro.ProductEnglishName = '"
					+ form.getSubDimension().toUpperCase() + "' ");
		}else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append("INNER JOIN DimDetractor detractor on ons.DetractorKey = detractor.DetractorKey and upper(detractor.Level1) = '"
					+ form.getSubDimension().toUpperCase() + "' ");
		}
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		}else {
	    	sBuffer.append(" where ons.Year = ").append(form.getYear())
	    			.append(" and ons.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		
		return query.list();
	}
	
	@Override
	public int getOverviewOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ons.OrderQuantity) as orderNum")
		   .append(" from FactMonthlySummaryofONS ons");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		}
		else {
		 	sBuffer.append(" where ons.Year = ").append(form.getYear())
		 			.append(" and ons.Month = ").append(form.getMonth());
		 }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	public int getCrossMonthOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ons.OrderQuantity) as orderNum")
		   		.append(" from FactMonthlySummaryofONS ons")
		   		.append(" left join DimDetractor dimDetractor on ons.DetractorKey =  dimDetractor.DetractorKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		}
		else {
		 	sBuffer.append(" where ons.Year = ").append(form.getYear())
		 			.append(" and ons.Month = ").append(form.getMonth());
		 }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
			sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
			sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
			sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ons.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	public int getDashboardOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ons.OrderQuantity) as orderNum")
		   		.append(" from FactMonthlySummaryofONS ons")
		   		.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
			    .append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
		   		.append(" left join DimDetractor dimDetractor on ons.DetractorKey =  dimDetractor.DetractorKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		}
		else {
		 	sBuffer.append(" where ons.Year = ").append(form.getYear())
		 			.append(" and ons.Month = ").append(form.getMonth());
		 }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey = ").append(form.getRemarkSubDimensionKey());
			else 
				sBuffer.append(" and ons.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getOverviewOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ons.POItem as poItem,")
				.append("ons.PONumber as poNumber,")
				.append("ons.POItem as itemNo,")
				.append("ons.OrderQuantity as qty,")
				.append("ons.OrderDate as orderDate,")
				.append("ons.RSDDate as rsd,")
				.append("ons.FPSDDate as fpsd,")
				.append("ons.ShipDate as shippedDate,")
				.append("ons.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ons.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofONS ons")
				.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ons.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		}
		else {
		 	sBuffer.append(" where ons.Year = ").append(form.getYear())
		 			.append(" and ons.Month = ").append(form.getMonth());
		 }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getCrossMonthOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ons.POItem as poItem,")
				.append("ons.PONumber as poNumber,")
				.append("ons.POItem as itemNo,")
				.append("ons.OrderQuantity as qty,")
				.append("ons.OrderDate as orderDate,")
				.append("ons.RSDDate as rsd,")
				.append("ons.FPSDDate as fpsd,")
				.append("ons.ShipDate as shippedDate,")
				.append("ons.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ons.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofONS ons")
				.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ons.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		}
		else {
		 	sBuffer.append(" where ons.Year = ").append(form.getYear())
		 			.append(" and ons.Month = ").append(form.getMonth());
		 }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
			sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
			sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
			sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ons.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getDashboardOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ons.POItem as poItem,")
				.append("ons.PONumber as poNumber,")
				.append("ons.POItem as itemNo,")
				.append("ons.OrderQuantity as qty,")
				.append("ons.OrderDate as orderDate,")
				.append("ons.RSDDate as rsd,")
				.append("ons.FPSDDate as fpsd,")
				.append("ons.ShipDate as shippedDate,")
				.append("ons.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ons.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofONS ons")
				.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ons.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		}
		else {
		 	sBuffer.append(" where ons.Year = ").append(form.getYear())
		 			.append(" and ons.Month = ").append(form.getMonth());
		 }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey = ").append(form.getRemarkSubDimensionKey());
			else 
				sBuffer.append(" and ons.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ons.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ons.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	public int getRemarkOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ons.OrderQuantity) as orderNum ")
			   .append(" from FactMonthlySummaryofONS ons");
				
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" INNER JOIN DimGeography geo on ons.RegionKey = geo.GeographyKey ");
					}
		else if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" INNER JOIN DimODM odm on ons.ODMKey = odm.ODMKey ");
		}
		else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" INNER JOIN DimProduct pro on ons.ProductKey = pro.ProductKey ");
		}
		else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
				if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
					sBuffer.append(" INNER JOIN DimDetractor detractor on ons.DetractorKey = detractor.DetractorKey ");
				}
				else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
					sBuffer.append(" INNER JOIN DimDetractor detractor on ons.DetractorKey = detractor.DetractorKey ");
				}
		}
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where ons.Year = ").append(form.getYear())
    			   .append(" and ons.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), ons.Year)+'-'+CONVERT(nvarchar(20), ons.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and geo.GeographyName in(" +  form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append(" and geo.GeographyName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}else if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and odm.ODMEnglishName in(" +  form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append(" and odm.ODMEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and pro.ProductEnglishName in(" +  form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append(" and pro.ProductEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
			
		}else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
				sBuffer.append(" and upper(detractor.Level1)  in(" +  form.getSubDimension() + ") ");
			}
			else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append(" and upper(detractor.Level1) = '" + form.getSubDimension().toUpperCase() + "' ");
			}
			else if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				if("Region".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
						sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());				
				}
				else if("Odm".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
						sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());			
				}
				else if("Product".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
						sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());			
				}
				sBuffer.append(" and ons.DetractorKey is null");
			 }
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer) query.uniqueResult();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getRemarkOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		if(form.isShowAllRemarkOrder()){
			sBuffer.append("(select top ").append(form.getRowCount() + form.getOrderNumber()).append(" * from ");
		}else{
			sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		}
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ons.POItem as poItem,")
				.append("ons.PONumber as poNumber,")
				.append("ons.POItem as itemNo,")
				.append("ons.OrderQuantity as qty,")
				.append("ons.OrderDate as orderDate,")
				.append("ons.RSDDate as rsd,")
				.append("ons.FPSDDate as fpsd,")
				.append("ons.ShipDate as shippedDate,")
				.append("ons.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ons.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofONS ons")
				.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ons.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where ons.Year = ").append(form.getYear())
    			   .append(" and ons.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), ons.Year)+'-'+CONVERT(nvarchar(20), ons.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "'");
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and region.GeographyName in("+ form.getSubDimension()+ ") ");
			}
			else{
				sBuffer.append(" and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}
		else if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and dimODM.ODMEnglishName in(" +  form.getSubDimension() + ")");
			}
			else{
				sBuffer.append(" and dimODM.ODMEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}
		else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and dimProduct.ProductEnglishName in(" +  form.getSubDimension() + ")");
			}
			else{
				sBuffer.append(" and dimProduct.ProductEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}
		else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
				sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
				
				sBuffer.append(" union all ");
				sBuffer.append("select  top ").append(form.getOrderNumber());
				sBuffer.append(" dimODM.ODMEnglishName as odm,")
						.append("geo.GeographyName as geo,")
						.append("region.GeographyName as region,")
						.append("country.GeographyName as country,")
						.append("dimProduct.ProductEnglishName as product,")
						.append("mtm.BOMNumberAlternateKey as pn,")
						.append("mtm.MTMEnglishDescription as itemDesc,")
						.append("ons.POItem as poItem,")
						.append("ons.PONumber as poNumber,")
						.append("ons.POItem as itemNo,")
						.append("ons.OrderQuantity as qty,")
						.append("ons.OrderDate as orderDate,")
						.append("ons.RSDDate as rsd,")
						.append("ons.FPSDDate as fpsd,")
						.append("ons.ShipDate as shippedDate,")
						.append("ons.IsShipped as shipped,")
						.append("'' as level1,")
						.append("'' as level2 ,")
						.append("ons.LateReason2 as level3 ")
						.append(" from FactMonthlySummaryofONS ons")
						.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
						.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
						.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
						.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
						.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
						.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
				
				if(form.isShowQuarterOverview()){
					form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
					form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
					sBuffer.append(" where ons.Year*100 + ons.Month = ")
							.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
				}
				else {
				 	sBuffer.append(" where ons.Year = ").append(form.getYear())
				 			.append(" and ons.Month = ").append(form.getMonth());
				}
				if(form.getOrderTypeId() == 1) {
					if(form.getOrderSubTypeId() != -1) {
						sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
					}
					else {
						sBuffer.append(" and ons.OTSTypeKey in (1,2)");
					}
				}
				
				if(form.getOrderTypeId() == 2) {
					if(form.getOrderSubTypeId() != -1) {
						sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
					}
					else {
						sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
					}
				}
				sBuffer.append(" and ons.DetractorKey is null");
			}
			else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getSubDimension().toUpperCase() + "' ");
			}else if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append(" and ons.DetractorKey is null");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	public int getDetractorOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ons.OrderQuantity) as orderNum ")
			   .append(" from FactMonthlySummaryofONS ons")
			   .append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
			   .append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
			   ;
		if(StringUtils.isNotBlank(form.getLevel1Detractor()) || StringUtils.isNotBlank(form.getLevel2Detractor())){
			sBuffer.append(" left join dimdetractor d on d.detractorKey = ons.detractorKey");
		}
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		}else {
	    	sBuffer.append(" where ons.Year = ").append(form.getYear())
	    			.append(" and ons.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sBuffer.append(" and  ons.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sBuffer.append(" and  ons.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and  ons.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sBuffer.append(" and  ons.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())) 
				sBuffer.append(" and ons.DetractorKey is null");
			else
				sBuffer.append(" and upper(d.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())) 
				sBuffer.append(" and ons.DetractorKey is null");
			else
				sBuffer.append(" and upper(d.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer) query.uniqueResult();
	}

	@Override
	public List<TtvGridDetractorCodeView> getDetractorOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ons.POItem as poItem,")
				.append("ons.PONumber as poNumber,")
				.append("ons.POItem as itemNo,")
				.append("ons.OrderQuantity as qty,")
				.append("ons.OrderDate as orderDate,")
				.append("ons.RSDDate as rsd,")
				.append("ons.FPSDDate as fpsd,")
				.append("ons.ShipDate as shippedDate,")
				.append("ons.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ons.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofONS ons")
				.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ons.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
				
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		}
		else {
		 	sBuffer.append(" where ons.Year = ").append(form.getYear())
		 			.append(" and ons.Month = ").append(form.getMonth());
		 }
		
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sBuffer.append(" and  ons.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sBuffer.append(" and  ons.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and  ons.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sBuffer.append(" and  ons.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())){
			sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel2Detractor())){
			sBuffer.append(" and upper(dimDetractor.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		
		if("odm".equalsIgnoreCase(form.getDimension())){
			sBuffer.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase() + "' ");
		}
		else if("product".equalsIgnoreCase(form.getDimension())){
			sBuffer.append(" and dimProduct.ProductEnglishName = '"+ form.getSubDimension().toUpperCase() + "' ");
		}
		else if("Detractor".equalsIgnoreCase(form.getDimension())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor()) || "UNKNOWN".equalsIgnoreCase(form.getSubDimension())) 
				sBuffer.append(" and ons.DetractorKey is null");
			else
				sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getLevel1Detractor().toUpperCase() + "' ");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

	@Override
	public List<TtvGridDetractorCodeView> getAllOrderDetail(
			SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ons.POItem as poItem,")
				.append("ons.PONumber as poNumber,")
				.append("ons.POItem as itemNo,")
				.append("ons.OrderQuantity as qty,")
				.append("ons.OrderDate as orderDate,")
				.append("ons.RSDDate as rsd,")
				.append("ons.FPSDDate as fpsd,")
				.append("ons.ShipDate as shippedDate,")
				.append("ons.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ons.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofONS ons")
				.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ons.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where ons.Year = ").append(form.getYear())
    			   .append(" and ons.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), ons.Year)+'-'+CONVERT(nvarchar(20), ons.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		if(form.getChartType().equals("remark")){
			if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
				sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "'");
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and region.GeographyName in ("+ form.getSubDimension() + ") ");
				}
				else{
					sBuffer.append(" and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
				}
			}else if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and dimODM.ODMEnglishName in(" +  form.getSubDimension() + ")");
				}
				else{
					sBuffer.append(" and dimODM.ODMEnglishName = '"
							+ form.getSubDimension().toUpperCase()+ "' ");
				}
			}else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and dimProduct.ProductEnglishName in(" +  form.getSubDimension() + ")");
				}
				else{
					sBuffer.append(" and dimProduct.ProductEnglishName = '"
							+ form.getSubDimension().toUpperCase()+ "' ");
				}
			}else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
				if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
					sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
					
					if(form.getOrderNumber() > 0){
						sBuffer.append(" union all ");
						sBuffer.append("select  top ").append(form.getOrderNumber());
						sBuffer.append(" dimODM.ODMEnglishName as odm,")
								.append("geo.GeographyName as geo,")
								.append("region.GeographyName as region,")
								.append("country.GeographyName as country,")
								.append("dimProduct.ProductEnglishName as product,")
								.append("mtm.BOMNumberAlternateKey as pn,")
								.append("mtm.MTMEnglishDescription as itemDesc,")
								.append("ons.POItem as poItem,")
								.append("ons.PONumber as poNumber,")
								.append("ons.POItem as itemNo,")
								.append("ons.OrderQuantity as qty,")
								.append("ons.OrderDate as orderDate,")
								.append("ons.RSDDate as rsd,")
								.append("ons.FPSDDate as fpsd,")
								.append("ons.ShipDate as shippedDate,")
								.append("ons.IsShipped as shipped,")
								.append("'' as level1,")
								.append("'' as level2 ,")
								.append("ons.LateReason2 as level3 ")
								.append(" from FactMonthlySummaryofONS ons")
								.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
								.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
								.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
								.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
								.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
								.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
						
						if(form.isShowQuarterOverview()){
							form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
							form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
							sBuffer.append(" where ons.Year*100 + ons.Month = ")
									.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
						}
						else {
						 	sBuffer.append(" where ons.Year = ").append(form.getYear())
						 			.append(" and ons.Month = ").append(form.getMonth());
						}
						if(form.getOrderTypeId() == 1) {
							if(form.getOrderSubTypeId() != -1) {
								sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
							}
							else {
								sBuffer.append(" and ons.OTSTypeKey in (1,2)");
							}
						}
						
						if(form.getOrderTypeId() == 2) {
							if(form.getOrderSubTypeId() != -1) {
								sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
							}
							else {
								sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
							}
						}
						
						sBuffer.append(" and ons.DetractorKey is null");
					}
				}
				else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
					sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getSubDimension().toUpperCase() + "' ");
				}else if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
					sBuffer.append(" and ons.DetractorKey is null");
				}
			}
		}else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName()) || form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())){
			//for Region overview chart
			if("Region".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1) {
					if(form.isShowGeoOverview())//geo overview
						sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
					else 
						sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
				}
				
				if(!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
				}
			}
			//for Odm overview chart
			else if("Odm".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
				
				if(!StringUtil.isEmpty(form.getGeoIds())) {
					sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
				}
			}
			//for Product overview chart
			else if("Product".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
				
				if(!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getGeoIds())) {
					sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
				}
			}
			
			//for Region remark chart
			if("Region".equals(form.getRemarkDimension())) {
				if(form.isShowDashBoradCrossMonth()){
					sBuffer.append(" and region.GeographyName in(").append(form.getSubDimension()).append(")");
				}else{
					if(form.isShowGeoOverview())//geo overview
						sBuffer.append(" and geo.GeographyKey = ").append(form.getRemarkSubDimensionKey());
					else 
						sBuffer.append(" and ons.RegionKey = ").append(form.getRemarkSubDimensionKey());
				}
			}
			//for Odm remark chart
			else if("Odm".equals(form.getRemarkDimension())) {
				if(form.isShowDashBoradCrossMonth()){
					sBuffer.append(" and dimODM.ODMEnglishName in(").append(form.getSubDimension()).append(")");
				}else{
					sBuffer.append(" and ons.ODMKey = ").append(form.getRemarkSubDimensionKey());
				}
			}
			//for Product remark chart
			else if("Product".equals(form.getRemarkDimension())) {
				if(form.isShowDashBoradCrossMonth()){
					sBuffer.append(" and dimProduct.ProductEnglishName in(").append(form.getSubDimension()).append(")");
				}else{
					sBuffer.append(" and ons.ProductKey = ").append(form.getRemarkSubDimensionKey());
				}
			}
			//for Detractor remark chart
			else if("Detractor".equals(form.getRemarkDimension())) {
				if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
					sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
					
					if(form.getOrderNumber() > 0){
						sBuffer.append(" union all ");
						sBuffer.append("select  top ").append(form.getOrderNumber());
						sBuffer.append(" dimODM.ODMEnglishName as odm,")
								.append("geo.GeographyName as geo,")
								.append("region.GeographyName as region,")
								.append("country.GeographyName as country,")
								.append("dimProduct.ProductEnglishName as product,")
								.append("mtm.BOMNumberAlternateKey as pn,")
								.append("mtm.MTMEnglishDescription as itemDesc,")
								.append("ons.POItem as poItem,")
								.append("ons.PONumber as poNumber,")
								.append("ons.POItem as itemNo,")
								.append("ons.OrderQuantity as qty,")
								.append("ons.OrderDate as orderDate,")
								.append("ons.RSDDate as rsd,")
								.append("ons.FPSDDate as fpsd,")
								.append("ons.ShipDate as shippedDate,")
								.append("ons.IsShipped as shipped,")
								.append("'' as level1,")
								.append("'' as level2 ,")
								.append("ons.LateReason2 as level3 ")
								.append(" from FactMonthlySummaryofONS ons")
								.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
								.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
								.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
								.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
								.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
								.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
						
						if(form.isShowQuarterOverview()){
							form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
							form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
							sBuffer.append(" where ons.Year*100 + ons.Month = ")
									.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
						}
						else {
						 	sBuffer.append(" where ons.Year = ").append(form.getYear())
						 			.append(" and ons.Month = ").append(form.getMonth());
						}
						if(form.getOrderTypeId() == 1) {
							if(form.getOrderSubTypeId() != -1) {
								sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
							}
							else {
								sBuffer.append(" and ons.OTSTypeKey in (1,2)");
							}
						}
						
						if(form.getOrderTypeId() == 2) {
							if(form.getOrderSubTypeId() != -1) {
								sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
							}
							else {
								sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
							}
						}
						
						//for Region overview chart
						if("Region".equals(form.getOverViewDimension())) {
							if(form.getOverViewSubDimensionKey() != -1) {
								if(form.isShowGeoOverview())//geo overview
									sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
								else 
									sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
							}
							
							if(!StringUtil.isEmpty(form.getOdmIds())) {
								sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
							}
							if(!StringUtil.isEmpty(form.getProductIds())) {
								sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
							}
						}
						//for Odm overview chart
						else if("Odm".equals(form.getOverViewDimension())) {
							if(form.getOverViewSubDimensionKey() != -1)
							sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
							
							if(!StringUtil.isEmpty(form.getGeoIds())) {
								sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
							}
							if(!StringUtil.isEmpty(form.getProductIds())) {
								sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
							}
						}
						//for Product overview chart
						else if("Product".equals(form.getOverViewDimension())) {
							if(form.getOverViewSubDimensionKey() != -1)
							sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
							
							if(!StringUtil.isEmpty(form.getOdmIds())) {
								sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
							}
							if(!StringUtil.isEmpty(form.getGeoIds())) {
								sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
							}
						}
						sBuffer.append(" and ons.DetractorKey is null");
					}
				}
				else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
					sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getRemarkSubDimension() + "' ");
				}else if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
					sBuffer.append(" and ons.DetractorKey is null");
				}
			
				
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

	@Override
	public List<TtvGridDetractorCodeView> getDashCrossRemarkOrderDetail(
			SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		if("Detractor".equals(form.getRemarkDimension())){
			sBuffer.append(" sum.odm,sum.geo,sum.region,sum.country,sum.product,sum.pn,sum.itemDesc,sum.poItem,sum.poNumber,")
					.append("sum.itemNo,sum.qty,sum.orderDate,sum.rsd,sum.fpsd,sum.shippedDate,sum.shipped,")
					.append("sum.level1,sum.level2,sum.level3 from (select ");
		}
		
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ons.POItem as poItem,")
				.append("ons.PONumber as poNumber,")
				.append("ons.POItem as itemNo,")
				.append("ons.OrderQuantity as qty,")
				.append("ons.OrderDate as orderDate,")
				.append("ons.RSDDate as rsd,")
				.append("ons.FPSDDate as fpsd,")
				.append("ons.ShipDate as shippedDate,")
				.append("ons.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ons.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofONS ons")
				.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ons.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where ons.Year = ").append(form.getYear())
    			   .append(" and ons.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), ons.Year)+'-'+CONVERT(nvarchar(20), ons.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and region.GeographyName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ons.RegionKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and dimODM.ODMEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ons.ODMKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and dimProduct.ProductEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ons.ProductKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
			if(form.getOrderNumber() > 0){
				sBuffer.append(" union all ");
				sBuffer.append("select  top ").append(form.getOrderNumber());
				sBuffer.append(" dimODM.ODMEnglishName as odm,")
						.append("geo.GeographyName as geo,")
						.append("region.GeographyName as region,")
						.append("country.GeographyName as country,")
						.append("dimProduct.ProductEnglishName as product,")
						.append("mtm.BOMNumberAlternateKey as pn,")
						.append("mtm.MTMEnglishDescription as itemDesc,")
						.append("ons.POItem as poItem,")
						.append("ons.PONumber as poNumber,")
						.append("ons.POItem as itemNo,")
						.append("ons.OrderQuantity as qty,")
						.append("ons.OrderDate as orderDate,")
						.append("ons.RSDDate as rsd,")
						.append("ons.FPSDDate as fpsd,")
						.append("ons.ShipDate as shippedDate,")
						.append("ons.IsShipped as shipped,")
						.append("'' as level1,")
						.append("'' as level2 ,")
						.append("ons.LateReason2 as level3 ")
						.append(" from FactMonthlySummaryofONS ons")
						.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
						.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
						.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
						.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
						.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
						.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
				
				if(form.isShowQuarterOverview()){
					form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
					form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
					sBuffer.append(" where ons.Year*100 + ons.Month = ")
							.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
				}
				else {
				 	sBuffer.append(" where ons.Year = ").append(form.getYear())
				 			.append(" and ons.Month = ").append(form.getMonth());
				}
				if(form.getOrderTypeId() == 1) {
					if(form.getOrderSubTypeId() != -1) {
						sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
					}
					else {
						sBuffer.append(" and ons.OTSTypeKey in (1,2)");
					}
				}
				
				if(form.getOrderTypeId() == 2) {
					if(form.getOrderSubTypeId() != -1) {
						sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
					}
					else {
						sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
					}
				}
				
				//for Region overview chart
				if("Region".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
					
					if(!StringUtil.isEmpty(form.getOdmIds())) {
						sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getProductIds())) {
						sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
					}
				}
				//for Odm overview chart
				else if("Odm".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
					
					if(!StringUtil.isEmpty(form.getGeoIds())) {
						sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getProductIds())) {
						sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
					}
				}
				//for Product overview chart
				else if("Product".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
					
					if(!StringUtil.isEmpty(form.getOdmIds())) {
						sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getGeoIds())) {
						sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
					}
				}
				sBuffer.append(" and ons.DetractorKey is null");
			}
			sBuffer.append(")sum");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

	@Override
	public int getDashCrossRemarkOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ons.OrderQuantity) as orderNum")
		   		.append(" from FactMonthlySummaryofONS ons")
		   		.append(" left join DimDetractor dimDetractor on ons.DetractorKey =  dimDetractor.DetractorKey")
		   		.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
		   		.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
		   		.append(" left join  DimProduct product on ons.ProductKey = product.ProductKey");
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where ons.Year = ").append(form.getYear())
    			   .append(" and ons.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), ons.Year)+'-'+CONVERT(nvarchar(20), ons.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
				
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ons.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ons.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ons.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and region.GeographyName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ons.RegionKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and dimODM.ODMEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ons.ODMKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and product.ProductEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ons.ProductKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and upper(dimDetractor.level1) in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
			
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	public List<TtvGridDetractorCodeView> getAllDetractorOrder(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ons.POItem as poItem,")
				.append("ons.PONumber as poNumber,")
				.append("ons.POItem as itemNo,")
				.append("ons.OrderQuantity as qty,")
				.append("ons.OrderDate as orderDate,")
				.append("ons.RSDDate as rsd,")
				.append("ons.FPSDDate as fpsd,")
				.append("ons.ShipDate as shippedDate,")
				.append("ons.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ons.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofONS ons")
				.append(" left join DimProduct dimProduct on ons.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ons.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ons.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ons.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ons.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ons.CountryKey = country.GeographyKey");
				
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ons.Year*100 + ons.Month = ")
					.append(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		}
		else {
		 	sBuffer.append(" where ons.Year = ").append(form.getYear())
		 			.append(" and ons.Month = ").append(form.getMonth());
		 }
		
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ons.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ons.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and ons.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ODMKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ons.ProductKey = ").append(form.getOverViewSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sBuffer.append(" and  ons.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sBuffer.append(" and  ons.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and  ons.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sBuffer.append(" and  ons.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())){
			sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel2Detractor())){
			sBuffer.append(" and upper(dimDetractor.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		
		if("odm".equalsIgnoreCase(form.getDimension())){
			sBuffer.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase() + "' ");
		}
		else if("product".equalsIgnoreCase(form.getDimension())){
			sBuffer.append(" and dimProduct.ProductEnglishName = '"+ form.getSubDimension().toUpperCase() + "' ");
		}
		else if("Detractor".equalsIgnoreCase(form.getDimension())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor()) || "UNKNOWN".equalsIgnoreCase(form.getSubDimension())) 
				sBuffer.append(" and ons.DetractorKey is null");
			else
				sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getLevel1Detractor().toUpperCase() + "' ");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

}
