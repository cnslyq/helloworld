package com.lenovo.bi.engine;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.lenovo.bi.dto.MtmCvConfig;
import com.lenovo.bi.dto.Order;
import com.lenovo.bi.dto.SingleUnitCvConfig;
import com.lenovo.bi.enumobj.PhaseEnum;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.ForecastData;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.model.OrderData;
import com.lenovo.bi.model.SGATtvWeeklyDetail;

public class SGAWeeklyFifoSorter extends WeeklyFifoSorter {

	private Map<String, SGATtvWeeklyDetail> weeklyDetailMap;
	
	public SGAWeeklyFifoSorter(Map<String, SGATtvWeeklyDetail> weeklyDetailMap, PhaseEnum phase, Date targetDate, Date versionDate, boolean includeBacklog,
			ComponentQuota mtmComponentQuota, ComponentQuota ctoComponentQuota, TTVPhase tTVPhase) {
		super(phase, targetDate, versionDate, includeBacklog, mtmComponentQuota, ctoComponentQuota, tTVPhase);
		this.weeklyDetailMap = weeklyDetailMap;
	}
	
	void deductOrdersFromForecasts() {
		// Deduct against week 0
		Map<BomNumberGeographyOdmKey, ForecastData> mtmForecastDataMap = labelMtmForecastsAccordingToForecasts();
		//remove ctoForecast for now
		//Map<ProductKeyGeographyOdmKey, ForecastData> ctoForecastDataMap = labelCtoForecastsAccordingToForecasts();
		Map<ProductKeyGeographyOdmKey, ForecastData> ctoForecastDataMap = new HashMap<ProductKeyGeographyOdmKey, ForecastData>();
		
		// Process orders
		for (OrderData orderData : orderDataList) {
			// MTM forecasts
			BomNumberGeographyOdmKey bomNumberKey = new BomNumberGeographyOdmKey(orderData.getBomNumber(), orderData.getGeographyName(), orderData.getOdmName());

			ForecastData mtmForecastData = mtmForecastDataMap.get(bomNumberKey);
			if (mtmForecastData == null) {
				// Nothing
			} else {
				int forecastQuantity = mtmForecastData.getQuantity();
				if (forecastQuantity >= orderData.getQuantity()) {
					mtmForecastData.setQuantity(forecastQuantity - orderData.getQuantity());
				} else {
					mtmForecastData.setQuantity(0);
				}
				mtmForecastDataMap.put(bomNumberKey, mtmForecastData);
			}

			// CTO forecasts
			ProductKeyGeographyOdmKey productKeyKey = new ProductKeyGeographyOdmKey(orderData.getProductKey(), orderData.getGeographyName(),
					orderData.getOdmName());

			ForecastData ctoForecastData = ctoForecastDataMap.get(productKeyKey+orderData.getPmsWaveId());
			if (ctoForecastData == null) {
				// Nothing
			} else {
				SingleUnitCvConfig mtmSingleUnitCvConfig = mtmCvConfigMap.getSingleUnitCvConfigOfMtm(orderData.getBomNumber());
				MtmCvConfig mtmCvConfig = new MtmCvConfig(mtmSingleUnitCvConfig, orderData.getQuantity());
				int maxNumberOfUnits = ctoForecastData.getCtoCvConfig().calculateMaxMtmNumberOfUnits(mtmCvConfig);

				if (maxNumberOfUnits > 0) {
					int origQuantity = ctoForecastData.getQuantity();
					ctoForecastData.setQuantity(origQuantity - maxNumberOfUnits);
					ctoForecastData.getCtoCvConfig().deductMtmUnits(mtmSingleUnitCvConfig, maxNumberOfUnits);
				}
			}

			// Increment the future order quantity
			SGATtvWeeklyDetail detail = weeklyDetailMap.get(orderData.getProductKey()+orderData.getPmsWaveId());
			if (detail != null) {
				if (detail.getFutureOrderQuantity() == -1){
					detail.setFutureOrderQuantity(orderData.getQuantity());
				} else{
					detail.setFutureOrderQuantity(detail.getFutureOrderQuantity() + orderData.getQuantity());
				}
			}
		}

		// Process remaining MTM forecasts
		for (Entry<BomNumberGeographyOdmKey, ForecastData> entry : mtmForecastDataMap.entrySet()) {
			ForecastData forecastData = entry.getValue();
			if (forecastData.getQuantity() > 0) {
				forecastDataList.add(forecastData);

				// Increment the future forecast quantity
				SGATtvWeeklyDetail detail = weeklyDetailMap.get(forecastData.getProductKey()+forecastData.getPmsWaveId());
				if (detail != null) { // Only NPI orders have detail
					if (detail.getFutureForecastQuantity() == -1){
						detail.setFutureForecastQuantity(forecastData.getQuantity());
					} else{
						detail.setFutureForecastQuantity(detail.getFutureForecastQuantity() + forecastData.getQuantity());
					}
					
				}
			}
		}

		// Process remaining CTO forecasts
		for (Entry<ProductKeyGeographyOdmKey, ForecastData> entry : ctoForecastDataMap.entrySet()) {
			ForecastData forecastData = entry.getValue();
			if (forecastData.getQuantity() > 0) {
				forecastDataList.add(forecastData);

				// Increment the future forecast quantity
				SGATtvWeeklyDetail detail = weeklyDetailMap.get(forecastData.getProductKey()+forecastData.getPmsWaveId());
				if (detail != null) { // Only NPI orders have detail
					detail.setFutureForecastQuantity(detail.getFutureForecastQuantity() + forecastData.getQuantity());
				}
			}
		}
	}

	@Override
	List<NpiOrder> getExcludedOrdersInWeek() {
		return ttvOutlookServiceBiHelper.getTTVExcludedOrderInWeek(targetDate, versionDate, TTVPhase.sga);
	}

	@Override
	List<NpiOrder> getAllExcludedOrders() {
		return ttvOutlookServiceBiHelper.getTTVAllExcludedOrders(TTVPhase.sga, versionDate);
	}

	@Override
	List<Order> getAllOrdersInWeek() {
		return ttvOutlookServiceDwHelper.getSGAAllOrdersInWeek(targetDate, versionDate);
	}

	@Override
	List<Order> getUnshippedOrdersBeforeWeek() {
		return ttvOutlookServiceDwHelper.getSGAUnshippedOrdersBeforeWeek(targetDate, versionDate);
	}

}
