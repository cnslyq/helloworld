package com.lenovo.bi.dao.impl;

import java.util.Date;

import javax.inject.Inject;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;

public class HibernateBaseDaoImplBi<T> extends HibernateBaseDaoImpl<T> {
	@Inject
	@Qualifier("sessionFactoryBi")
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	protected void deleteDataForVersionDate(String entityName, Date versionDate) {
		StringBuffer hql = new StringBuffer("delete from " + entityName +  " where datediff(day, versionDate, :versionDate) = 0 ");
		
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("versionDate", versionDate);
		query.executeUpdate();
	}
}
