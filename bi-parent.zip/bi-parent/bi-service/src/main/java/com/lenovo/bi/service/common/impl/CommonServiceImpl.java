package com.lenovo.bi.service.common.impl;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.lenovo.bi.dao.common.MasterDataDao;
import com.lenovo.bi.dao.sc.FpsdDao;
import com.lenovo.bi.dao.sc.OTSDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.privilege.GeoTree;
import com.lenovo.bi.dto.sc.FpsdRemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.enumobj.CAStatusEnum;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.FPSDStatusEnum;
import com.lenovo.bi.enumobj.KPILights;
import com.lenovo.bi.enumobj.OTSStatusEnum;
import com.lenovo.bi.enumobj.OrderTypeEnum;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.service.common.CommonService;
import com.lenovo.bi.util.CalendarUtil;

@Service 
public class CommonServiceImpl implements CommonService {
	@Inject
	private MasterDataDao masterDataDao;
	
	@Inject
	FpsdDao fpsdDao;
	
	@Inject
	OTSDao otsDao;
	
	@Override
	public String getKPILightColor(String orderType, float makeRate) {
		String color = null;
		if(orderType == null || "All".equals(orderType) ) {
			color = getColorByMakeRate(makeRate,80,70);
		}
		else {
			if(orderType.equals(OrderTypeEnum.PRC_BTO.getType()) ||
					orderType.equals(OrderTypeEnum.WW_BTP.getType())) {
				color = getColorByMakeRate(makeRate,95,80);
			}
			else if(orderType.equals(OrderTypeEnum.PRC_BTS_FORWARD.getType()) ||
					orderType.equals(OrderTypeEnum.WW_FORWARD.getType())) {
				color = getColorByMakeRate(makeRate,95,80);
			}
			else if(orderType.equals(OrderTypeEnum.WW_BTO_AIR.getType())) {
				color = getColorByMakeRate(makeRate,75,60);
			}
			else if(orderType.equals(OrderTypeEnum.WW_BTO_SEA.getType())) {
				color = getColorByMakeRate(makeRate,75,60);
			}else if(orderType.equals(OrderTypeEnum.FPSD.getType())){//Defect 10757 modify by Dolly 2014-08-15
				color = getColorByMakeRate(makeRate,84);
			}else if(OrderTypeEnum.CA.getType().equals(orderType)){
				color = getColorByMakeRate(makeRate,100,95);
			}else if(OrderTypeEnum.BPS.getType().equals(orderType)){
				if(makeRate > 20){
					color = KPILights.RED.toString();
				}else if(makeRate <= 10){
					color = KPILights.GREEN.toString();
				}else{
					color = KPILights.YELLOW.toString();
				}
			}
			else if(OrderTypeEnum.FA.getType().equals(orderType)){
				if(makeRate <= 50.0){
					color = KPILights.RED.toString();
				}else if(makeRate > 50.0 && makeRate <= 70.0){
					color = KPILights.YELLOW.toString();
				}else{
					color = KPILights.GREEN.toString();
				}
			}
			else if(OrderTypeEnum.COMPONENTFA.getType().equals(orderType)){
				if( makeRate <= 50.0){
					color = KPILights.RED.toString();
				}else if(makeRate > 50.0 && makeRate <= 70.0){
					color = KPILights.YELLOW.toString();
				}else{
					color = KPILights.GREEN.toString();
				}
			}
		}
		
		return color;
	}
	
	@Override
	public String getOnsKPILightColor(float makeRate) {
		String color = null;
		if(makeRate >= 60*1000)
			color = KPILights.RED.toString();
		else if(makeRate >= 40*1000 && makeRate < 60*1000)
			color = KPILights.YELLOW.toString();
		else
			color = KPILights.GREEN.toString();
		
		return color;
	}
	
	@Override
	public float calculateOtsMakeRate(String date, Map<String, Integer> dataMap) {
		
		BigDecimal makeRate = new BigDecimal(0.00);
		MathContext mc = new MathContext(4, RoundingMode.HALF_DOWN);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
		
		String currentDate = sdf.format(Calendar.getInstance().getTime());
		
		int make = dataMap.get(OTSStatusEnum.MAKE.getTypeName()) == null ? 0 : dataMap.get(OTSStatusEnum.MAKE.getTypeName());
		int fail = dataMap.get(OTSStatusEnum.FAIL.getTypeName()) == null ? 0 : dataMap.get(OTSStatusEnum.FAIL.getTypeName());
		int toBeMake = dataMap.get(OTSStatusEnum.ToBeMake.getTypeName()) == null ? 0 : dataMap.get(OTSStatusEnum.ToBeMake.getTypeName());
		int toBeFail = dataMap.get(OTSStatusEnum.ToBeFail.getTypeName()) == null ? 0 : dataMap.get(OTSStatusEnum.ToBeFail.getTypeName());
		
		try{
			//history: 
			if(date.compareTo(currentDate) < 0) {
				makeRate = new BigDecimal(make).divide
								   (
										 new BigDecimal(make)
									.add(new BigDecimal(fail)),mc
								   )
									.multiply(new BigDecimal(100));
			}
			//current
			else if(date.compareTo(currentDate) == 0) {
				makeRate = new BigDecimal(make).add(new BigDecimal(toBeMake))
							.divide
						   (
								 new BigDecimal(make)
							.add(new BigDecimal(fail))
							.add(new BigDecimal(toBeMake))
							.add(new BigDecimal(toBeFail)),mc
						   )
							.multiply(new BigDecimal(100));
			}
			//future
			else {
				makeRate = new BigDecimal(toBeMake).divide
						   (
								  new BigDecimal(toBeMake)
							.add(new BigDecimal(toBeFail)),mc
						   )
							.multiply(new BigDecimal(100));
			}
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return makeRate.floatValue();
	}
	
	@Override
	public float calculateOtsMakeRateForQuarter(SearchOtsForm form, String quarter, Map<String, Integer> dataMap) {
		
		BigDecimal makeRate = new BigDecimal(0.00);
		MathContext mc = new MathContext(4, RoundingMode.HALF_DOWN);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
		
		String currentDate = sdf.format(Calendar.getInstance().getTime());
		
		int make = dataMap.get(OTSStatusEnum.MAKE.getTypeName()) == null ? 0 : dataMap.get(OTSStatusEnum.MAKE.getTypeName());
		int fail = dataMap.get(OTSStatusEnum.FAIL.getTypeName()) == null ? 0 : dataMap.get(OTSStatusEnum.FAIL.getTypeName());
		int toBeMake = dataMap.get(OTSStatusEnum.ToBeMake.getTypeName()) == null ? 0 : dataMap.get(OTSStatusEnum.ToBeMake.getTypeName());
		//int toBeFail = dataMap.get(OTSStatusEnum.ToBeFail.getTypeName()) == null ? 0 : dataMap.get(OTSStatusEnum.ToBeFail.getTypeName());
		
		
		int makeOrderItems = make;
		int shippedOrderItems = make + fail;
		int toBeMakeOrderItems = toBeMake;
		int currentShippedOrderItems = shippedOrderItems;
		int unshippedBacklog = otsDao.fetchUnshippedBacklog(form); //指RSD在历史某一期且尚未发货的Order的条数
		int currentUnshippedOrderItems = otsDao.fetchCurrentUnshippedOrderItems(form); //指RSD在当期且未发货的Order的条数.
		int futureOrderItems = otsDao.fetchFutureOrderItems(form); //指RSD在未来某个月/季度的Order的条数
		
		int index = quarter.indexOf("||");
		String quarterFrom = quarter.substring(0, index);
		String quarterTo =  quarter.substring(index+2);
		try{
			//history: 
			if(currentDate.compareTo(quarterFrom) > 0) {
				makeRate = new BigDecimal(makeOrderItems).divide
								   (
										 new BigDecimal(shippedOrderItems),mc
								   )
									.multiply(new BigDecimal(100));
			}
			//current
			else if(currentDate.compareTo(quarterFrom) > 0 && currentDate.compareTo(quarterTo) < 0) {
				makeRate = new BigDecimal(makeOrderItems).add(new BigDecimal(toBeMakeOrderItems))
							.divide
						   (
								 new BigDecimal(currentShippedOrderItems)
								 .add(new BigDecimal(unshippedBacklog))
								 .add(new BigDecimal(currentUnshippedOrderItems)),mc
						   )
							.multiply(new BigDecimal(100));
			}
			//future
			else if(currentDate.compareTo(quarterFrom) < 0) {
				makeRate = new BigDecimal(toBeMakeOrderItems).divide
						   (
								  new BigDecimal(futureOrderItems),mc
						   )
							.multiply(new BigDecimal(100));
			}
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return makeRate.floatValue();
	}
	
	@Override
	public float calculateMakeRate(String date, Map<String, Integer> dataMap) {
		
		BigDecimal makeRate = new BigDecimal(0);
		MathContext mc = new MathContext(2, RoundingMode.HALF_DOWN);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		
		String currentDate = sdf.format(Calendar.getInstance().getTime());
		int currentDateNum = Integer.parseInt(currentDate);
		int beginDateNum;
		int endDateNum;
		//Defect #10756 modify by dolly 2014-08-15
		List<String> dates = CalendarUtil.getDatesByString(date);
		if(CollectionUtils.isNotEmpty(dates)){
			if(dates.size() < 2){
				beginDateNum = Integer.parseInt(dates.get(0).replace("-", ""));
				endDateNum = Integer.parseInt(dates.get(0).replace("-", ""));
			}else{
				beginDateNum = Integer.parseInt(dates.get(0).replace("-", ""));
				endDateNum = Integer.parseInt(dates.get(1).replace("-", ""));
			}
		}else{
			return 0.0f;
		}
		int ok = dataMap.get(FPSDStatusEnum.OK.getTypeName()) == null ? 0 : dataMap.get(FPSDStatusEnum.OK.getTypeName());
		int early = dataMap.get(FPSDStatusEnum.Early.getTypeName()) == null ? 0 : dataMap.get(FPSDStatusEnum.Early.getTypeName());
		int late = dataMap.get(FPSDStatusEnum.Late.getTypeName()) == null ? 0 : dataMap.get(FPSDStatusEnum.Late.getTypeName());
		int toBeOk = dataMap.get(FPSDStatusEnum.ToBeOk.getTypeName()) == null ? 0 : dataMap.get(FPSDStatusEnum.ToBeOk.getTypeName());
		int toBeEarly = dataMap.get(FPSDStatusEnum.ToBeEarly.getTypeName()) == null ? 0 : dataMap.get(FPSDStatusEnum.ToBeEarly.getTypeName());
		int toBeLate = dataMap.get(FPSDStatusEnum.ToBeLate.getTypeName()) == null ? 0 : dataMap.get(FPSDStatusEnum.ToBeLate.getTypeName());
		
		try{
			if(currentDateNum > endDateNum) {//history: 
				makeRate = new BigDecimal(ok).divide
								   (
										 new BigDecimal(ok)
									.add(new BigDecimal(early))
									.add(new BigDecimal(late)),mc
								   )
									.multiply(new BigDecimal(100));
			}else if(currentDateNum < beginDateNum){//future
				makeRate = new BigDecimal(ok).divide
						   (
								 new BigDecimal(ok)
							.add(new BigDecimal(toBeOk))
							.add(new BigDecimal(toBeEarly))
							.add(new BigDecimal(toBeLate)),mc
						   )
							.multiply(new BigDecimal(100));
			}else{//current
				//OK +early+late+ toBeOK + toBeEarly + toBeLate+(last month toBeOK + toBeEarly + toBeLate)
				makeRate = new BigDecimal(ok).add(new BigDecimal(toBeOk))
							.divide
						   (
								 new BigDecimal(ok)
							.add(new BigDecimal(early))
							.add(new BigDecimal(late))
							.add(new BigDecimal(toBeOk))
							.add(new BigDecimal(toBeEarly))
							.add(new BigDecimal(toBeLate)),mc
						   )
							.multiply(new BigDecimal(100));
			}
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return makeRate.floatValue();
	}
	
	@Override
	public float calculateFpsdMakeRate(String date, FpsdRemarkChartData fpsdRemarkChartData,SearchOtsForm form) throws ParseException {
		
		BigDecimal makeRate = new BigDecimal(0);
		MathContext mc = new MathContext(3, RoundingMode.HALF_DOWN);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		
		String currentDate = sdf.format(Calendar.getInstance().getTime());
		int currentDateNum = Integer.parseInt(currentDate);
		String beginDate;
		int beginDateNum;
		int endDateNum;
		//Defect #10756 modify by dolly 2014-08-15
		List<String> dates = CalendarUtil.getDatesByString(date);
		if(CollectionUtils.isNotEmpty(dates)){
			beginDate = dates.get(0);
			if(dates.size() < 2){
				beginDateNum = Integer.parseInt(beginDate.replace("-", ""));
				endDateNum = Integer.parseInt(dates.get(0).replace("-", ""));
			}else{
				beginDateNum = Integer.parseInt(beginDate.replace("-", ""));
				endDateNum = Integer.parseInt(dates.get(1).replace("-", ""));
			}
		}else{
			return 0.0f;
		}
		int ok = fpsdRemarkChartData.getOk();
		int early = fpsdRemarkChartData.getEarly();
		int late = fpsdRemarkChartData.getLate();
		int toBeOk = fpsdRemarkChartData.getToBeOk();
		int toBeEarly = fpsdRemarkChartData.getToBeEarly();
		int toBeLate = fpsdRemarkChartData.getToBeLate();
		
		try{
			if(currentDateNum > endDateNum) {//history: 
				makeRate = new BigDecimal(ok).divide
								   (
										 new BigDecimal(ok)
									.add(new BigDecimal(early))
									.add(new BigDecimal(late)),mc
								   )
									.multiply(new BigDecimal(100));
			}else if(currentDateNum < beginDateNum){//future
				makeRate = new BigDecimal(toBeOk).divide
						   (
								 new BigDecimal(ok)
							.add(new BigDecimal(toBeOk))
							.add(new BigDecimal(toBeEarly))
							.add(new BigDecimal(toBeLate)),mc
						   )
							.multiply(new BigDecimal(100));
			}else{//current
				//(this month: OK + ToBeOK)/(this month : OK +early+late+ toBeOK + toBeEarly + toBeLate) + (last month : toBeOK + toBeEarly + toBeLate)
				//Defect #10756 modify by dolly 2014-08-15 add last month value
				List<ScOverViewChartData> lastMonthOrderCounts = new ArrayList<ScOverViewChartData>();
				String lastCycBeginDate;
				String lastCycEndDate;
				if(!form.isShowQuarterOverview()){
					lastCycBeginDate = CalendarUtil.getYearMonthByMonths(beginDate, -1);
					lastCycEndDate = lastCycBeginDate;
				}else{
					lastCycBeginDate = CalendarUtil.getYearMonthByMonths(beginDate, -3);
					lastCycEndDate = CalendarUtil.getYearMonthByMonths(beginDate, -1);
				}
				form.setYear( Integer.parseInt(lastCycBeginDate.substring(0,4)));
				form.setMonth( Integer.parseInt(lastCycBeginDate.substring(5,7)));
				form.setQuarterFrom(lastCycBeginDate);
				form.setQuarterTo(lastCycEndDate);
				if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
					lastMonthOrderCounts = fpsdDao.fetchFpsdOverViewChartData(form);
				}else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
					lastMonthOrderCounts = fpsdDao.fetchFpsdCrossMonthOverviewChartData(form);
				}
				else{
					List<KeyNameObject> dimensionList = fpsdDao.fetchDimensions(form);
					for(KeyNameObject keyNameObject : dimensionList) {
						form.setSubDimensionKey(keyNameObject.getObjKey());
						lastMonthOrderCounts.addAll(fpsdDao.fetchFpsdDashboardOverViewChartData(form));
					}
				}
				BigDecimal unshippedBacklog;
				if(CollectionUtils.isNotEmpty(lastMonthOrderCounts)){
					int lastMonthUnShippedCount = 0;
					for(ScOverViewChartData orderCount : lastMonthOrderCounts){
						if(FPSDStatusEnum.ToBeOk.getTypeName().equals(orderCount.getScStatusName())
							||FPSDStatusEnum.ToBeLate.getTypeName().equals(orderCount.getScStatusName())
							||FPSDStatusEnum.ToBeEarly.getTypeName().equals(orderCount.getScStatusName())){
							
							lastMonthUnShippedCount = lastMonthUnShippedCount + orderCount.getOrderNum();
						}
					}
					unshippedBacklog = new BigDecimal(lastMonthUnShippedCount);
				}else{
					unshippedBacklog = BigDecimal.ZERO;
				}
				makeRate = new BigDecimal(ok).add(new BigDecimal(toBeOk))
							.divide
						   (
								 new BigDecimal(ok)
							.add(new BigDecimal(early))
							.add(new BigDecimal(late))
							.add(new BigDecimal(toBeOk))
							.add(new BigDecimal(toBeEarly))
							.add(new BigDecimal(toBeLate))
							.add(unshippedBacklog),mc
						   )
							.multiply(new BigDecimal(100));
			}
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return makeRate.floatValue();
	}
	
	public String getColorByMakeRate(float makeRate,int greenValue, int yellowValue) {
		String color = null;
		if(makeRate >= greenValue)
			color = KPILights.GREEN.toString();
		else if(makeRate >= yellowValue && makeRate < greenValue)
			color = KPILights.YELLOW.toString();
		else if(makeRate < yellowValue)
			color = KPILights.RED.toString();
		
		return color;
	}
	private String getColorByMakeRate(float makeRate,int greenValue) {
		String color = null;
		if(makeRate >= greenValue){
			color = KPILights.GREEN.toString();
		}else{
			color = KPILights.RED.toString();
		}
		return color;
	}
	
	@Override
	public String getRegionTreeJson(){
		
		List<GeoTree> treeList = masterDataDao.getRegionTreeList();
		
		String jsonStr = new Gson().toJson(treeList);
		
		//System.out.println("the return json is: " + jsonStr);
		return jsonStr;
	}
	
	@Override
	public String getSelectRegionTreeJsonByIds(String treeIds){
		
		List<GeoTree> treeList = masterDataDao.getRegionTreeList();
		if(StringUtils.isNotBlank(treeIds)){
			String[] idList = treeIds.split(",");
			if(idList != null && idList.length >= 1){
				if(CollectionUtils.isNotEmpty(treeList)){
					for(GeoTree tree : treeList){
						for(int index = 0; index < idList.length; index++){
							if(tree.getId().equals(idList[index])){
								tree.setChecked(true);
							}
						}
					}
				}
			}
		}
		String jsonStr = new Gson().toJson(treeList);
		
		//System.out.println("the return json is: " + jsonStr);
		return jsonStr;
	}

	@Override
	public List<String> getOdms() {
		return masterDataDao.getOdmList();
	}

	@Override
	public List<String> getProductFamily() {
		return masterDataDao.getProductFamily();
	}

	@Override
	public List<String> getProduct() {
		return  masterDataDao.getProductList();
	}

	@Override
	public List<KeyNameObject> getOrderTypeList() {
		List<KeyNameObject> objectList = new ArrayList<KeyNameObject>();
		KeyNameObject keyNameObject1 = new KeyNameObject();
		keyNameObject1.setObjKey(1);
		keyNameObject1.setObjName("PRC");
		
		KeyNameObject keyNameObject2 = new KeyNameObject();
		keyNameObject2.setObjKey(2);
		keyNameObject2.setObjName("WW");
		
		objectList.add(keyNameObject1);
		objectList.add(keyNameObject2);
		
		return objectList;
	}
	
	@Override
	public List<KeyNameObject> getOrderSubTypeList(Integer orderType) {
		return masterDataDao.getOrderSubTypes(orderType);
	}

	@Override
	public List<KeyNameObject> getOdmList() {
		return masterDataDao.getOdms();
	}

	@Override
	public List<KeyNameObject> getProductList() {
		return masterDataDao.getProducts();
	}
	
	@Override
	public List<KeyNameObject> getComponentList() {
		return masterDataDao.getComponents();
	}
	
	@Override
	public List<KeyNameObject> getProductFamilyList() {
		return masterDataDao.getProductFamilys();
	}
	
	@Override
	public List<KeyNameObject> getFamilyList() {
		return masterDataDao.getFamilyList();
	}

	@Override
	public List<KeyNameObject> getPortfolioList() {
		return masterDataDao.getPortfolioList();
	}
	
	@Override
	public List<KeyNameObject> getPurchaseTypeList() {
		return masterDataDao.getPurchaseTypeList();
	}

	@Override
	public float calculateMFGCaMakeRate(String date, String currentRolMonth, Map<String, Integer> dataMap, boolean isCa)
			throws ParseException {
		BigDecimal caRate = new BigDecimal(0);
		MathContext mc = new MathContext(3, RoundingMode.HALF_DOWN);
		/*SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		String currentDate = sdf.format(Calendar.getInstance().getTime());*/
		int currentDateNum = Integer.parseInt(currentRolMonth.replace("-", ""));
		String beginDate;
		int beginDateNum;
		int endDateNum;
		List<String> dates = CalendarUtil.getDatesByString(date);
		if(CollectionUtils.isNotEmpty(dates)){
			beginDate = dates.get(0);
			if(dates.size() < 2){
				beginDateNum = Integer.parseInt(beginDate.replace("-", ""));
				endDateNum = Integer.parseInt(dates.get(0).replace("-", ""));
			}else{
				beginDateNum = Integer.parseInt(beginDate.replace("-", ""));
				endDateNum = Integer.parseInt(dates.get(1).replace("-", ""));
			}
		}else{
			return 0.0f;
		}
		int commitment = dataMap.get(CAStatusEnum.Commitment.getTypeName()) == null ? 0 : dataMap.get(CAStatusEnum.Commitment.getTypeName());
		int risk = dataMap.get(CAStatusEnum.RiskOrder.getTypeName()) == null ? 0 : dataMap.get(CAStatusEnum.RiskOrder.getTypeName());
		int shipment = dataMap.get(CAStatusEnum.Shipment.getTypeName()) == null ? 0 : dataMap.get(CAStatusEnum.Shipment.getTypeName());
		int commited = dataMap.get(CAStatusEnum.CommitedOrder.getTypeName()) == null ? 0 : dataMap.get(CAStatusEnum.CommitedOrder.getTypeName());
		int target = dataMap.get("CATarget");
		int ctp = dataMap.get("CTP");
		int denominator = 0;
		
		if(isCa)
			denominator = target;
		else
			denominator = ctp;
		try{
			if(currentDateNum > endDateNum) {//history: 
				caRate = new BigDecimal(shipment)
								.divide(new BigDecimal(denominator),mc)
								.multiply(new BigDecimal(100));
			}
			else if(currentDateNum < beginDateNum){//future
				caRate = new BigDecimal(commitment).add(new BigDecimal(-risk)).add(new BigDecimal(commited))
								.divide(new BigDecimal(denominator),mc)
								.multiply(new BigDecimal(100));
			}
			else{//current
				caRate = new BigDecimal(shipment).add(new BigDecimal(-risk)).add(new BigDecimal(commited))
								.divide(new BigDecimal(denominator),mc)
								.multiply(new BigDecimal(100));
			}
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return caRate.floatValue();
	}
	@Override
	public float calculateSalesCaMakeRate(String date, String currentRolMonth, Map<String, Integer> dataMap, boolean isCa)
			throws ParseException {
		BigDecimal makeRate = new BigDecimal(0);
		MathContext mc = new MathContext(3, RoundingMode.HALF_DOWN);
		/*SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		
		String currentDate = sdf.format(Calendar.getInstance().getTime());*/
		int currentDateNum = Integer.parseInt(currentRolMonth.replace("-", ""));
		String beginDate;
		int beginDateNum;
		int endDateNum;
		List<String> dates = CalendarUtil.getDatesByString(date);
		if(CollectionUtils.isNotEmpty(dates)){
			beginDate = dates.get(0);
			if(dates.size() < 2){
				beginDateNum = Integer.parseInt(beginDate.replace("-", ""));
				endDateNum = Integer.parseInt(dates.get(0).replace("-", ""));
			}else{
				beginDateNum = Integer.parseInt(beginDate.replace("-", ""));
				endDateNum = Integer.parseInt(dates.get(1).replace("-", ""));
			}
		}else{
			return 0.0f;
		}
		
		//int outlook = dataMap.get(CAStatusEnum.Commitment.getTypeName()) == null ? 0 : dataMap.get(CAStatusEnum.Commitment.getTypeName());
		int shipment = dataMap.get(CAStatusEnum.Shipment.getTypeName()) == null ? 0 : dataMap.get(CAStatusEnum.Shipment.getTypeName());
		int target = dataMap.get("CATarget");
		int ctp = dataMap.get("CTP");
		int denominator = 0;
		
		if(isCa)
			denominator = target;
		else
			denominator = ctp;
		try{
			if(currentDateNum > endDateNum) {//history: 
				makeRate = new BigDecimal(shipment)
								.divide(new BigDecimal(denominator),mc)
								.multiply(new BigDecimal(100));
			}
			else if(currentDateNum < beginDateNum){//future
				/*makeRate = new BigDecimal(outlook)
				.divide(new BigDecimal(target),mc)
				.multiply(new BigDecimal(100));*/
				makeRate = new BigDecimal(0);
			}
			else{//current
				makeRate = new BigDecimal(shipment)
				.divide(new BigDecimal(denominator),mc)
				.multiply(new BigDecimal(100));
			}
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return makeRate.floatValue();
	}

	@Override
	public float calculateComponentFa(String date, Map<String, Integer> dataMap)
			throws ParseException {
		return 50;
	}

	@Override
	public List<KeyNameObject> getComponentValueList() {
		return masterDataDao.getComponentValues();
	}

	@Override
	public String getFlexibilityKPILightColor(String dimension,float rate) {
		if("Product".equals(dimension)){
			if(rate>=30f){
				return KPILights.GREEN.toString();
			}else{
				return KPILights.RED.toString();
			}
		}else{
			if(rate>=65f){
				return KPILights.GREEN.toString();
			}else{
				return KPILights.RED.toString();
			}
		}
		
	}
}
