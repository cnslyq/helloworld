package com.lenovo.bi.service.sc.impl;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.common.ExcludeOrderDao;
import com.lenovo.bi.dao.npi.NpiOrderDaoDw;
import com.lenovo.bi.dao.sc.FpsdDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.dto.sc.FpsdRemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.FPSDStatusEnum;
import com.lenovo.bi.enumobj.OrderTypeEnum;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.service.common.CommonService;
import com.lenovo.bi.service.common.MasterDataService;
import com.lenovo.bi.service.sc.FPSDService;
import com.lenovo.bi.service.sc.ScCommonService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.FpsdRemarkChartDataComparator;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.LineSet;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSet;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;

@Service
public class FPSDServiceImpl implements FPSDService {

	@Inject
	FpsdDao fpsdDao;
	
	@Inject
	CommonService commonService;
	
	@Inject
	NpiOrderDaoDw npiOrderDaoDw;
	
	@Inject
	ScCommonService scCommonService;
	
	@Inject
	ExcludeOrderDao excludeOrderDao;
	
	@Inject
	private MasterDataService masterDataService;
	
	@Override
	public MSColumnChartView getOverviewChart(SearchOtsForm form) throws ParseException {
		MSColumnChartView columnChartView = new MSColumnChartView();
		setOverviewChartInfomation(columnChartView);
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
				|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
			String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
			
			if(!form.isShowQuarterOverview()) {
				for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
					String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
					if (form.getEndDate()!=null && yearMonth.compareTo(form.getEndDate()) > 0) 
						break;
					Category category = new Category();
					category.setName(yearMonth);
					categoryList.add(category);
				}
			}
			else {
				String date = "";
				if(form.getStartDate().substring(5).compareTo("04") < 0)
					date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
				else
					date = form.getStartDate().substring(0, 5) + "04";
				for(int i=0; i<4; i++) {
					Category category = new Category();
					category.setName("Q"+ (i+1));
					String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
					String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
					category.setQuarterValue(quarterFrom + "||" + quarterTo);
					categoryList.add(category);
				}
			}
			
		}
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		//dataset list and lineset list
		List<DataSet> dataSetList = new ArrayList<DataSet>();
		List<LineSet> lineSetList = new ArrayList<LineSet>();
		
		//dataset
		DataSet fpsdOrderDataSet = new DataSet();
		
		LineSet makeRateLineSet = new LineSet();
		makeRateLineSet.setSeriesName("Make Rate");
		makeRateLineSet.setColor("009966");
		makeRateLineSet.setShowValues("0");
		makeRateLineSet.setLineThickness("2");
		
		LineSet targetLineSet = new LineSet();
		targetLineSet.setSeriesName("Target");
		targetLineSet.setColor("FF0099");
		targetLineSet.setShowValues("0");
		targetLineSet.setLineThickness("2");
		
		//dataset:seriesName
		List<DataSetParent> fpsdOrderDataSetList = new ArrayList<DataSetParent>();
		
		//OK("Company",1),Early("Early",2),Late("Late",3),ToBeOk("To-be OK",4),ToBeEarly("To-be Early",5),ToBeLate("To-be Late",6)
		DataSetColumn okDataSetColumn = new DataSetColumn();
		okDataSetColumn.setSeriesName(FPSDStatusEnum.OK.getTypeName());
		okDataSetColumn.setColor("00CC00");
		List<ColumnData> okCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn earlyDataSetColumn = new DataSetColumn();
		earlyDataSetColumn.setSeriesName(FPSDStatusEnum.Early.getTypeName());
		earlyDataSetColumn.setColor("888888");
		List<ColumnData> earlyCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn lateDataSetColumn = new DataSetColumn();
		lateDataSetColumn.setSeriesName(FPSDStatusEnum.Late.getTypeName());
		lateDataSetColumn.setColor("FF0000");
		List<ColumnData> lateCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn toBeOkDataSetColumn = new DataSetColumn();
		toBeOkDataSetColumn.setSeriesName(FPSDStatusEnum.ToBeOk.getTypeName());
		toBeOkDataSetColumn.setColor("66FF99");
		List<ColumnData> toBeOkCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn toBeEarlyDataSetColumn = new DataSetColumn();
		toBeEarlyDataSetColumn.setSeriesName(FPSDStatusEnum.ToBeEarly.getTypeName());
		toBeEarlyDataSetColumn.setColor("CCCCCC");
		List<ColumnData> toBeEarlyCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn toBeLateDataSetColumn = new DataSetColumn();
		toBeLateDataSetColumn.setSeriesName(FPSDStatusEnum.ToBeLate.getTypeName());
		toBeLateDataSetColumn.setColor("FF99FF");
		List<ColumnData> toBeLateCloumnDataList = new ArrayList<ColumnData>();
		
		List<ColumnData> makeRateColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		
		LinkedHashMap<Object,List<ScOverViewChartData>> fpsdOverviewMap = null;
		int dimensionsCount = 0;
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			fpsdOverviewMap = fetchFpsdOverViewChartData(form);
			dimensionsCount = fpsdOverviewMap.size();
		}else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			fpsdOverviewMap = fetchFpsdCrossMonthOverviewChartData(form);
			dimensionsCount = fpsdOverviewMap.size();
		}
		else{
			int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
			int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			dimensionsCount =this.fetchFpsdDashboardOverViewChartDataCount(form);
			fpsdOverviewMap = fetchFpsdDashboardOverViewChartData(form);
		}
		int i=0;
		for(Map.Entry<Object, List<ScOverViewChartData>> entry : fpsdOverviewMap.entrySet()) {
			String name = ((KeyNameObject)entry.getKey()).getObjName();
			int key = -1;
			if(((KeyNameObject)entry.getKey()).getObjKey() != null)
				key = ((KeyNameObject)entry.getKey()).getObjKey();
			List<ScOverViewChartData> chartDataList = entry.getValue();
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				Category category = new Category();
				category.setName(name);
				categoryList.add(category);
			}
			
			ColumnData ok = new ColumnData();
			setFPSDOverviewColumnLink(ok,name,key);
			ok.setValue(0);
			
			ColumnData early = new ColumnData();
			setFPSDOverviewColumnLink(early,name,key);
			early.setValue(0);
			
			ColumnData late = new ColumnData();
			setFPSDOverviewColumnLink(late,name,key);
			late.setValue(0);
			
			ColumnData toBeOk = new ColumnData();
			setFPSDOverviewColumnLink(toBeOk,name,key);
			toBeOk.setValue(0);
			
			ColumnData toBeEarly = new ColumnData();
			setFPSDOverviewColumnLink(toBeEarly,name,key);
			toBeEarly.setValue(0);
			
			ColumnData toBeLate = new ColumnData();
			setFPSDOverviewColumnLink(toBeLate,name,key);
			toBeLate.setValue(0);
			
			ColumnData makeRate = new ColumnData();
			makeRate.setValue(0);
			//Map<String,Integer> dataMap = new HashMap<String,Integer>();
			FpsdRemarkChartData fpsdRemarkChartData = new FpsdRemarkChartData();
			
			StringBuffer valueBuffer = new StringBuffer("[{");
			Category category = (Category)(categoryList.get(i));
			for(ScOverViewChartData fpsdOverViewChartData : chartDataList) {
				if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.OK.getTypeName())) {
					setFPSDOverviewColumnLink(ok,name,key);
					ok.setValue(fpsdOverViewChartData.getOrderNum());
					valueBuffer.append("ok:");
					fpsdRemarkChartData.setOk(fpsdOverViewChartData.getOrderNum());
				}
				else if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.Early.getTypeName())) {
					setFPSDOverviewColumnLink(early,name,key);
					early.setValue(fpsdOverViewChartData.getOrderNum());
					valueBuffer.append("early:");
					fpsdRemarkChartData.setEarly(fpsdOverViewChartData.getOrderNum());
				}
				else if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.Late.getTypeName())) {
					setFPSDOverviewColumnLink(late,name,key);
					late.setValue(fpsdOverViewChartData.getOrderNum());
					valueBuffer.append("late:");
					fpsdRemarkChartData.setLate(fpsdOverViewChartData.getOrderNum());
				}
				else if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.ToBeOk.getTypeName())) {
					setFPSDOverviewColumnLink(toBeOk,name,key);
					toBeOk.setValue(fpsdOverViewChartData.getOrderNum());
					valueBuffer.append("toBeOk:");
					fpsdRemarkChartData.setToBeOk(fpsdOverViewChartData.getOrderNum());
				}
				else if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.ToBeEarly.getTypeName())) {
					setFPSDOverviewColumnLink(toBeEarly,name,key);
					toBeEarly.setValue(fpsdOverViewChartData.getOrderNum());
					valueBuffer.append("toBeEarly:");
					fpsdRemarkChartData.setToBeEarly(fpsdOverViewChartData.getOrderNum());
				}
				else if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.ToBeLate.getTypeName())) {
					setFPSDOverviewColumnLink(toBeLate,name,key);
					toBeLate.setValue(fpsdOverViewChartData.getOrderNum());
					valueBuffer.append("toBeLate:");
					fpsdRemarkChartData.setToBeLate(fpsdOverViewChartData.getOrderNum());
				}
				valueBuffer.append(fpsdOverViewChartData.getOrderNum()).append(",");
			}
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				valueBuffer.append("subDimensionName:");
				valueBuffer.append("'" + name + "'").append(",");
			}
			
			float makeRateValue;
			if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
					|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
				//Defect #10756 modify by dolly 2014-08-15
				if(!form.isShowQuarterOverview()){
					makeRateValue = commonService.calculateFpsdMakeRate(category.getName(), fpsdRemarkChartData, form);
				}else{
					makeRateValue = commonService.calculateFpsdMakeRate(category.getQuarterValue(), fpsdRemarkChartData, form);
				}
			}
			else{
				makeRateValue = commonService.calculateFpsdMakeRate(form.getSelectMonth(), fpsdRemarkChartData, form);
			}
			makeRate.setValue(makeRateValue);	
			makeRateColumnDataList.add(makeRate);
			
			valueBuffer.append("makeRate:");
			valueBuffer.append(makeRateValue).append(",");
			//Defect 10757 modify by Dolly 2014-08-15
			String lightColor = commonService.getKPILightColor(OrderTypeEnum.FPSD.getType(),makeRateValue);
			valueBuffer.append("lightColor:");
			valueBuffer.append("'" + lightColor + "'");
			//Defect #10716 modify by Dolly 2014-08-18  
			valueBuffer.append(",dimensionsCount:");
			valueBuffer.append(dimensionsCount);
			valueBuffer.append("}").append("]");
			//System.out.println("----------KPI:" + valueBuffer.toString());
			
			category.setValues(valueBuffer.toString());
			okCloumnDataList.add(ok);
			earlyCloumnDataList.add(early);
			lateCloumnDataList.add(late);
			toBeOkCloumnDataList.add(toBeOk);
			toBeEarlyCloumnDataList.add(toBeEarly);
			toBeLateCloumnDataList.add(toBeLate);
			
			//Target
			ColumnData target = new ColumnData();
			float targetValue = 0;
			Float thresholdValue = masterDataService.getThresholdByName(Threshold.SC_OTS_FPSD_TARGET.name());
			if(thresholdValue != null)
				targetValue = thresholdValue.floatValue();
			target.setValue(targetValue);
			targetCloumnDataList.add(target);
			i++;
		}
		
		okDataSetColumn.setDataList(okCloumnDataList);
		fpsdOrderDataSetList.add(okDataSetColumn);
		
		earlyDataSetColumn.setDataList(earlyCloumnDataList);
		fpsdOrderDataSetList.add(earlyDataSetColumn);
		
		lateDataSetColumn.setDataList(lateCloumnDataList);
		fpsdOrderDataSetList.add(lateDataSetColumn);
		
		toBeOkDataSetColumn.setDataList(toBeOkCloumnDataList);
		fpsdOrderDataSetList.add(toBeOkDataSetColumn);
		
		toBeEarlyDataSetColumn.setDataList(toBeEarlyCloumnDataList);
		fpsdOrderDataSetList.add(toBeEarlyDataSetColumn);
		
		toBeLateDataSetColumn.setDataList(toBeLateCloumnDataList);
		fpsdOrderDataSetList.add(toBeLateDataSetColumn);
		
		fpsdOrderDataSet.setDataSetList(fpsdOrderDataSetList);
		makeRateLineSet.setDataList(makeRateColumnDataList);
		targetLineSet.setDataList(targetCloumnDataList);
		
		dataSetList.add(fpsdOrderDataSet);
		lineSetList.add(makeRateLineSet);
		lineSetList.add(targetLineSet);
		
		columnChartView.setDataSetList(dataSetList);
		columnChartView.setLineSetList(lineSetList);
		
		return columnChartView;
	}
	
	
	public float calFpsdRate(String date,SearchOtsForm form) throws ParseException {
		
		float makeRateValue = 0;
		form.setStartDate(date);
		LinkedHashMap<Object,List<ScOverViewChartData>> fpsdOverviewMap = fetchFpsdOverViewChartDataByMonth(form);
		
		for(Map.Entry<Object, List<ScOverViewChartData>> entry : fpsdOverviewMap.entrySet()) {
			
			List<ScOverViewChartData> chartDataList = entry.getValue();
			
			FpsdRemarkChartData fpsdRemarkChartData = new FpsdRemarkChartData();
			
			for(ScOverViewChartData fpsdOverViewChartData : chartDataList) {
				if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.OK.getTypeName())) {
					fpsdRemarkChartData.setOk(fpsdOverViewChartData.getOrderNum());
				}
				else if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.Early.getTypeName())) {
					fpsdRemarkChartData.setEarly(fpsdOverViewChartData.getOrderNum());
				}
				else if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.Late.getTypeName())) {
					fpsdRemarkChartData.setLate(fpsdOverViewChartData.getOrderNum());
				}
				else if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.ToBeOk.getTypeName())) {
					fpsdRemarkChartData.setToBeOk(fpsdOverViewChartData.getOrderNum());
				}
				else if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.ToBeEarly.getTypeName())) {
					fpsdRemarkChartData.setToBeEarly(fpsdOverViewChartData.getOrderNum());
				}
				else if(fpsdOverViewChartData.getScStatusName().equals(FPSDStatusEnum.ToBeLate.getTypeName())) {
					fpsdRemarkChartData.setToBeLate(fpsdOverViewChartData.getOrderNum());
				}
			}
			
			
			makeRateValue = commonService.calculateFpsdMakeRate(date, fpsdRemarkChartData, form);
			//String lightColor = commonService.getKPILightColor(OrderTypeEnum.FPSD.getType(),makeRateValue);
			
		}
		return makeRateValue;
	}

	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchFpsdOverViewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> fpsdOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		if(!form.isShowQuarterOverview()) {
			String yearMonth = "";
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
				fpsdOverviewMap.put(keyNameObject, fpsdDao.fetchFpsdOverViewChartData(form));
			}
		}
		else {
			String date = "";
			if(form.getStartDate().substring(5).compareTo("04") < 0)
				date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
			else
				date = form.getStartDate().substring(0, 5) + "04";
			for(int i=0; i<4; i++) {
				KeyNameObject keyNameObject = new KeyNameObject();
				String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
				String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
				//modify by Dolly 2014-08-10 Defect #10725
				form.setQuarterFrom(quarterFrom);
				form.setQuarterTo(quarterTo);
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , quarterFrom.replace("-", "") , quarterTo.replace("-", "")));
				keyNameObject.setObjName(quarterFrom + "||" + quarterTo);
				fpsdOverviewMap.put(keyNameObject, fpsdDao.fetchFpsdOverViewChartData(form));
			}
		}
		
		return fpsdOverviewMap;
	}
	
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchFpsdOverViewChartDataByMonth(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> fpsdOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		
		String date = form.getStartDate();
		KeyNameObject keyNameObject = new KeyNameObject();
		keyNameObject.setObjName(date);
		int year = Integer.parseInt(date.substring(0,4));
		int month = Integer.parseInt(date.substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
		form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
		fpsdOverviewMap.put(keyNameObject, fpsdDao.fetchFpsdOverViewChartData(form));
		
		return fpsdOverviewMap;
	}
	
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchFpsdCrossMonthOverviewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> fpsdOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
		if(!form.isShowQuarterOverview()) {
			String yearMonth = "";
			for(int i=0; i<12; i++) {
				String date = CalendarUtil.getYearMonthByMonths(startDate, i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
				fpsdOverviewMap.put(keyNameObject, fpsdDao.fetchFpsdCrossMonthOverviewChartData(form));
			}
		}
		else {
			String date = "";
			if(form.getStartDate().substring(5).compareTo("04") < 0)
				date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
			else
				date = form.getStartDate().substring(0, 5) + "04";
			for(int i=0; i<4; i++) {
				KeyNameObject keyNameObject = new KeyNameObject();
				String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
				String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
				form.setQuarterFrom(quarterFrom);
				form.setQuarterTo(quarterTo);
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , quarterFrom.replace("-", "") , quarterTo.replace("-", "")));
				keyNameObject.setObjName(quarterFrom + "||" + quarterTo);
				fpsdOverviewMap.put(keyNameObject, fpsdDao.fetchFpsdCrossMonthOverviewChartData(form));
			}
		}
		
		return fpsdOverviewMap;
	}
	
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchFpsdDashboardOverViewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> fpsdDashboardOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
		form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
		List<KeyNameObject> dimensionList = fpsdDao.fetchDimensions(form);
		for(KeyNameObject keyNameObject : dimensionList) {
			form.setSubDimensionKey(keyNameObject.getObjKey());
			fpsdDashboardOverviewMap.put(keyNameObject, fpsdDao.fetchFpsdDashboardOverViewChartData(form));
		}
		
		return fpsdDashboardOverviewMap;
	}
	
	private int fetchFpsdDashboardOverViewChartDataCount(SearchOtsForm form) throws ParseException {
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		return fpsdDao.fetchDimensionsCount(form);
	}
	
	public void setFPSDOverviewColumnLink(ColumnData cloumnData,String name, int key) {
		/*cloumnData.setLink("j-showDetractorMainPieAndData-"
				+ weekNo + "," 
				+ trackingCausesMonday + "|" 
				+trackingCausesSunday);*/
		cloumnData.setLink("j-refreshRemark-" + name + "," + key);
	}
	
	@Override
	public ColumnChartView getRemarkChart(SearchOtsForm form) throws ParseException {		
		ColumnChartView columnChartView = setFpsdRemarkChartInfomation();
		
		//dataset:seriesName
		List<DataSetParent> fpsdDimensionDataSetList = new ArrayList<DataSetParent>();
		
		//Early Rate; Late Rate; To-be Early Rate; To-be Late Rate 
		DataSetColumn earlyDataSetColumn = new DataSetColumn();
		earlyDataSetColumn.setSeriesName("Early");
		earlyDataSetColumn.setColor("888888");
		List<ColumnData> earlyCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn lateDataSetColumn = new DataSetColumn();
		lateDataSetColumn.setSeriesName("Late");
		lateDataSetColumn.setColor("FF0000");
		List<ColumnData> lateCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn toBeEarlyDataSetColumn = new DataSetColumn();
		toBeEarlyDataSetColumn.setSeriesName("To-be Early");
		toBeEarlyDataSetColumn.setColor("CCCCCC");
		List<ColumnData> toBeEarlyCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn toBeLateDataSetColumn = new DataSetColumn();
		toBeLateDataSetColumn.setSeriesName("To-be Late");
		toBeLateDataSetColumn.setColor("FF99FF");
		List<ColumnData> toBeLateCloumnDataList = new ArrayList<ColumnData>();
		
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		List<FpsdRemarkChartData> fpsdRemarkChartDataList  = fetchFpsdRemarkChartData(form);
		
		for(int i=0; i<fpsdRemarkChartDataList.size(); i++) {
			if(i == 15) break;
			FpsdRemarkChartData fpsdRemarkChartData = fpsdRemarkChartDataList.get(i);
			String name = fpsdRemarkChartData.getDimensionName();
			int value = fpsdRemarkChartData.getDimensionKey();
			
			Category category = new Category();
			category.setName(name);
			category.setValue(value);
			categoryList.add(category);
			
			String dimensionInfo = "";
			if(ChartTypeEnum.OverView.getTypeName().equals(form.getChartType()))
				dimensionInfo = form.getDimension()+ "," + name;
			else
				dimensionInfo = form.getDimension()+ "," + name + "~" + value;
			
			ColumnData early = new ColumnData();
			setRemarkColumnLink(dimensionInfo,early,form);
			early.setValue(0);
			
			ColumnData late = new ColumnData();
			setRemarkColumnLink(dimensionInfo,late,form);
			late.setValue(0);
			
			ColumnData toBeEarly = new ColumnData();
			setRemarkColumnLink(dimensionInfo,toBeEarly,form);
			toBeEarly.setValue(0);
			
			ColumnData toBeLate = new ColumnData();
			setRemarkColumnLink(dimensionInfo,toBeLate,form);
			toBeLate.setValue(0);
			
			setRemarkColumnLink(dimensionInfo+","+FPSDStatusEnum.Early.getTypeName(),early,form);
			early.setValue(fpsdRemarkChartData.getEarlyRate());
			early.setTooltext(FPSDStatusEnum.Early.getTypeName() +", " + name + ", "+ fpsdRemarkChartData.getEarlyRate() + "%");
			
			setRemarkColumnLink(dimensionInfo+","+FPSDStatusEnum.Late.getTypeName(),late,form);
			late.setValue(fpsdRemarkChartData.getLateRate());
			late.setTooltext(FPSDStatusEnum.Late.getTypeName() +", " + name + ", "+ fpsdRemarkChartData.getLateRate() + "%");
			
			setRemarkColumnLink(dimensionInfo+","+FPSDStatusEnum.ToBeEarly.getTypeName(),toBeEarly,form);
			toBeEarly.setValue(fpsdRemarkChartData.getToBeEarlyRate());
			toBeEarly.setTooltext(FPSDStatusEnum.ToBeEarly.getTypeName() +", " + name + ", "+ fpsdRemarkChartData.getToBeEarlyRate() + "%");
			
			setRemarkColumnLink(dimensionInfo+","+FPSDStatusEnum.ToBeLate,toBeLate,form);
			toBeLate.setValue(fpsdRemarkChartData.getToBeLateRate());
			toBeLate.setTooltext(FPSDStatusEnum.ToBeLate.getTypeName() +", " + name + ", "+ fpsdRemarkChartData.getToBeLateRate() + "%");
			
			if(early.getValue().intValue() != 0) 
				earlyCloumnDataList.add(early);
			else
				earlyCloumnDataList.add(null);
			if(late.getValue().intValue() != 0) 
				lateCloumnDataList.add(late);
			else
				lateCloumnDataList.add(null);
			if(toBeEarly.getValue().intValue() != 0) 
				toBeEarlyCloumnDataList.add(toBeEarly);
			else
				toBeEarlyCloumnDataList.add(null);
			if(toBeLate.getValue().intValue() != 0) 
				toBeLateCloumnDataList.add(toBeLate);
			else
				toBeLateCloumnDataList.add(null);
		}
		
		Categories categories = new Categories();
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		earlyDataSetColumn.setDataList(earlyCloumnDataList);
		fpsdDimensionDataSetList.add(earlyDataSetColumn);
		
		lateDataSetColumn.setDataList(lateCloumnDataList);
		fpsdDimensionDataSetList.add(lateDataSetColumn);
		
		toBeEarlyDataSetColumn.setDataList(toBeEarlyCloumnDataList);
		fpsdDimensionDataSetList.add(toBeEarlyDataSetColumn);
		
		toBeLateDataSetColumn.setDataList(toBeLateCloumnDataList);
		fpsdDimensionDataSetList.add(toBeLateDataSetColumn);
		
		columnChartView.setDataSetList(fpsdDimensionDataSetList);
		
		return columnChartView;
	}

	
	public List<FpsdRemarkChartData> fetchFpsdRemarkChartData(SearchOtsForm form) throws ParseException {
				
		if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			if(!form.isShowQuarterOverview()) {
				String yearStr = form.getSelectMonth().substring(0,4);
				String monthStr = form.getSelectMonth().substring(5,7);
				int year = Integer.parseInt(yearStr);
				int month = Integer.parseInt(monthStr);
				form.setYear(year);
				form.setMonth(month);
				String yearMonth =  monthStr.length() < 2 ? yearStr + "-0" + monthStr : yearStr + "-" + monthStr;
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
			}
			else{
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
			}
		}else{
			if(form.getStartDate().equalsIgnoreCase(form.getEndDate())){
				String yearMonth = form.getStartDate();
				String yearStr = yearMonth.substring(0,4);
				String monthStr = yearMonth.substring(5,7);
				int year = Integer.parseInt(yearStr);
				int month = Integer.parseInt(monthStr);
				form.setYear(year);
				form.setMonth(month);
				String yearMonthTmp =  monthStr.length() < 2 ? yearStr + "-0" + monthStr : yearStr + "-" + monthStr;
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonthTmp , "" , ""));
			}else{
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
			}	
		}
				
		List<FpsdRemarkChartData> fpsdRemarkChartDataList = new ArrayList<FpsdRemarkChartData>();
		fpsdRemarkChartDataList = fpsdDao.fetchDimensionRemarkDataList(form);
		
		//filter for the small quantity order for product
		if("Product".equals(form.getDimension())) {
			int totalProductOrderQty = 0;
			int totalProductNum = fpsdRemarkChartDataList.size();
			if(totalProductNum != 0) {
				for(FpsdRemarkChartData fpsdRemarkChartData : fpsdRemarkChartDataList) {
					totalProductOrderQty += fpsdRemarkChartData.getTotal();
				}
				MathContext mc = new MathContext(5, RoundingMode.HALF_UP);
				BigDecimal averProductOrderQty = new BigDecimal(totalProductOrderQty)
											.divide(new BigDecimal(totalProductNum),mc)
											.multiply(new BigDecimal(0.1));
				
				for(int i=0; i<fpsdRemarkChartDataList.size(); i++) {
					FpsdRemarkChartData fpsdRemarkChartData = fpsdRemarkChartDataList.get(i);
					if(new BigDecimal(fpsdRemarkChartData.getTotal()).compareTo(averProductOrderQty) == -1) {
						fpsdRemarkChartDataList.remove(fpsdRemarkChartData);
						--i;
					}
						
				}
			}
		}
		
		FpsdRemarkChartDataComparator fpsdRemarkChartDataComparator = new FpsdRemarkChartDataComparator();
		Collections.sort(fpsdRemarkChartDataList, fpsdRemarkChartDataComparator);
		
		return fpsdRemarkChartDataList;
	}
	
	public double calFaRate(int totalFa, int subFa) {
		BigDecimal faRate = new BigDecimal(0);
		MathContext mc = new MathContext(1, RoundingMode.HALF_DOWN);
		
		try{
			faRate = new BigDecimal(subFa).divide(new BigDecimal(totalFa),mc).multiply(new BigDecimal(100));
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return Math.floor(faRate.floatValue());
	}
	
	public void setColumnLink(int weekNo,ColumnData cloumnData) {
		
		cloumnData.setLink("j-refreshRemark-");
	
	}
	
	public void setRemarkColumnLink(String dimensionInfo,ColumnData cloumnData,SearchOtsForm form) {
		
		if(ChartTypeEnum.CrossMonth.getTypeName().equals(form.getChartType()))
			cloumnData.setLink( "j-fpsdCrossMonthOrderDetailShow-"+dimensionInfo );
		else if(ChartTypeEnum.Dashboard.getTypeName().equals(form.getChartType()))
			cloumnData.setLink( "j-fpsdDashboardOrderDetailShow-"+dimensionInfo );
		else
			cloumnData.setLink( "j-showFPSDOrderDetail-"+dimensionInfo );
	
	}
	
	private ColumnChartView setRemarkChartInfomation() {
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		columnChartView.getChartInfo().setFormatNumber("%");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setShowBorder("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setShowValues("0");
//		columnChartView.getChartInfo().setSnumberSuffix("%");
		columnChartView.getChartInfo().setNumbersuffix("%");
//		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");
		
		return columnChartView;
	}
	
	private ColumnChartView setFpsdRemarkChartInfomation() {
		
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumbersuffix("%");
		columnChartView.getChartInfo().setNumdivlines("10");
		columnChartView.getChartInfo().setShowValues("1");
		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setShowBorder("0");
		
		/*columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		columnChartView.getChartInfo().setFormatNumber("%");*/
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		//columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");
		
		return columnChartView;
	}
	
	private void setOverviewChartInfomation(MSColumnChartView mSColumnChartView) {
		mSColumnChartView.getChartInfo().setCaption("");
		mSColumnChartView.getChartInfo().setNumdivlines("9");
		mSColumnChartView.getChartInfo().setyAxisMinValue("0");
		mSColumnChartView.getChartInfo().setyAxisMaxValue("160");
		mSColumnChartView.getChartInfo().setsYAxisMinValue("0");
		mSColumnChartView.getChartInfo().setsYAxisMaxValue("100");
		mSColumnChartView.getChartInfo().setFormatNumberScale("0");
		mSColumnChartView.getChartInfo().setLegendIconScale("1");
		mSColumnChartView.getChartInfo().setShowBorder("1");
		mSColumnChartView.getChartInfo().setCanvasBorderThickness("1");
		mSColumnChartView.getChartInfo().setShowZeroPlaneValue("1");
		mSColumnChartView.getChartInfo().setCanvasBorderAlpha("60");
		mSColumnChartView.getChartInfo().setPlotSpacePercent("70");
		mSColumnChartView.getChartInfo().setBgalpha("0,0");
		mSColumnChartView.getChartInfo().setLegendPosition("");
		mSColumnChartView.getChartInfo().setShowBorder("0");
		mSColumnChartView.getChartInfo().setShowPlotBorder("0");
		mSColumnChartView.getChartInfo().setShowValues("0");
	}

	@Override
	public List<ScOverViewChartData> getOverviewOverall(SearchOtsForm form) {
//		form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		if(form.getStartDate().equalsIgnoreCase(form.getEndDate())){
			String yearMonth = form.getStartDate();
			String yearStr = yearMonth.substring(0,4);
			String monthStr = yearMonth.substring(5,7);
			int year = Integer.parseInt(yearStr);
			int month = Integer.parseInt(monthStr);
			form.setYear(year);
			form.setMonth(month);
			String yearMonthTmp =  monthStr.length() < 2 ? yearStr + "-0" + monthStr : yearStr + "-" + monthStr;
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonthTmp , "" , ""));
		}else{
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		}
		return fpsdDao.getOverviewOverall(form);
	}
	@Override
	public int getFPSDOrderDetailCount(SearchOtsForm form) throws ParseException {
		List<String> orderKeys = null;
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			orderKeys = this.getFpsdOverViewOrderDetail(form);
		}
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			orderKeys = this.getFpsdCrossMonthOrderDetail(form);
		}
		else{
			orderKeys = this.getFpsdDashboardOrderDetail(form);
		}
		return orderKeys.size();
	}
	
	@Override
	public Map<String,Object> getFPSDOrderDetail(
			SearchOtsForm form) throws ParseException {
		/*List<String> orderKeys = null;
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			orderKeys = this.getFpsdOverViewOrderDetail(form);
		}
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			orderKeys = this.getFpsdCrossMonthOrderDetail(form);
		}
		else{
			orderKeys = this.getFpsdDashboardOrderDetail(form);
		}
		return scCommonService.getOrderDetail(orderKeys, form);*/
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		}
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			totalCount = fpsdDao.getOverviewOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				grid = fpsdDao.getOverviewOrderDetail(form);
			}
		}
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			totalCount = fpsdDao.getCrossMonthOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				grid = fpsdDao.getCrossMonthOrderDetail(form);
			}
		}
		else{
			totalCount = fpsdDao.getDashboardOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				grid = fpsdDao.getDashboardOrderDetail(form);
			}
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	
	@Override
	public Map<String,Object> getFPSDRemarkOrderDetail(SearchOtsForm form) throws ParseException {
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		}
		
		if(!StringUtil.isEmpty(form.getScStatus()) && "all".equalsIgnoreCase(form.getScStatus())){
			form.setShowAllRemarkOrder(true);
			form.setShowUnknownOrder(false);
			List<FpsdRemarkChartData> fpsdRemarkChartDataList = new ArrayList<FpsdRemarkChartData>();
			fpsdRemarkChartDataList = fpsdDao.fetchDimensionRemarkDataList(form);
			String scStatusKey ="";
			boolean hasLate =false;
			boolean hasToBeLate =false;
			boolean hasEarly =false;
			boolean hasToBeEarly =false;
			/*StringBuffer remarkDimensionKey = new StringBuffer();
			StringBuffer remarkSubDimension = new StringBuffer();*/
			for(FpsdRemarkChartData fpsdRemarkChartData : fpsdRemarkChartDataList){
				/*remarkDimensionKey.append(fpsdRemarkChartData.getDimensionKey()).append(',');
				remarkSubDimension.append("'").append(fpsdRemarkChartData.getDimensionName()).append("'").append(',');*/
				if(!hasLate && fpsdRemarkChartData.getLate() > 0){
					scStatusKey = scStatusKey + "3," ;
					hasLate =true;
				}
				if(!hasToBeLate && fpsdRemarkChartData.getToBeLate() > 0){
					scStatusKey = scStatusKey + "6," ;
					hasToBeLate =true;
				}
				if(!hasEarly && fpsdRemarkChartData.getEarly() > 0){
					scStatusKey = scStatusKey + "2," ;
					hasEarly =true;
				}
				if(!hasToBeEarly && fpsdRemarkChartData.getToBeEarly() > 0){
					scStatusKey = scStatusKey + "5," ;
					hasToBeEarly =true;
				}
				
				if(hasLate && hasToBeLate && hasEarly && hasToBeEarly){
					break;
				}
			}
			form.setScStatus(scStatusKey.substring(0, scStatusKey.length() - 1));
			/*String remarkSubDimensionKeys = remarkDimensionKey.toString();
			String remarkSubDimensions = remarkSubDimension.toString();
			form.setRemarkSubDimensionKeys(remarkSubDimensionKeys.substring(0, remarkSubDimensionKeys.length() - 1));
			form.setRemarkSubDimensions(remarkSubDimensions.substring(0, remarkSubDimensions.length() - 1));*/
		}
		
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		int unkownTotalCount = 0;
		if(form.isShowDashBoradCrossMonth()){
			totalCount = fpsdDao.getDashCrossRemarkOrderDetailCount(form);
		}else{
			totalCount = fpsdDao.getRemarkOrderDetailCount(form);
		}
		
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			if("Detractor".equalsIgnoreCase(form.getDimension()) && form.isShowAllRemarkOrder()){
				String subDimensionTmp = form.getSubDimension();
				form.setSubDimension("UNKNOWN");
				form.setShowUnknownOrder(true);
				unkownTotalCount = fpsdDao.getRemarkOrderDetailCount(form);
				totalCount = totalCount + unkownTotalCount ;
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				form.setSubDimension(subDimensionTmp);
				form.setOrderNumber(unkownTotalCount);
				form.setShowUnknownOrder(false);
			}
			
			if(form.isShowDashBoradCrossMonth()){
				grid = fpsdDao.getDashCrossRemarkOrderDetail(form);
			}else{
				grid = fpsdDao.getRemarkOrderDetail(form);
			}
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		map.put("unkownTotalCount", unkownTotalCount);
		return map;
	}
	
	private List<String> getFpsdOverViewOrderDetail(SearchOtsForm form) throws ParseException{
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}
		else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		return fpsdDao.fetchFpsdOverViewOrderDetail(form);
	}
	private List<String> getFpsdOverViewRemarkOrderDetail(SearchOtsForm form) throws ParseException{
		if(!form.isShowQuarterOverview()) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}
		else {
			form.setQuarterFrom(form.getStartDate().replace("-", ""));
			form.setQuarterTo(form.getEndDate().replace("-", ""));
		}
		return fpsdDao.fetchFpsdOverViewRemarkOrderDetail(form);
	}
	private List<String> getFpsdCrossMonthOrderDetail(SearchOtsForm form) throws ParseException{
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}
		else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		return fpsdDao.fetchFpsdCrossMonthOrderDetail(form);
	}
	private List<String> getFpsdDashboardOrderDetail(SearchOtsForm form) throws ParseException{
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		List<KeyNameObject> dimensionList = fpsdDao.fetchDimensions(form);
		List<String> result = new ArrayList<String>();
		for(KeyNameObject keyNameObject : dimensionList) {
			form.setSubDimensionKey(keyNameObject.getObjKey());
			result.addAll(fpsdDao.fetchFpsdDashboardOverOderDetail(form));
		}
		return result;
	}

	@Override
	public Map<String,Object> getFPSDRemarkDetractorTableDetail(
			SearchOtsForm form) throws ParseException {
		/*List<String> orderKeys = fpsdDao.fetchFpsdOrderKeysByDims(form);
		return scCommonService.getOrderDetail(orderKeys, form);*/
		
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		totalCount = fpsdDao.getDetractorOrderDetailCount(form);
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			grid = fpsdDao.getDetractorOrderDetail(form);
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	@Override
	public int getFPSDRemarkDetractorTableDetailCount(
			SearchOtsForm form) throws ParseException {
		List<String> orderKeys = fpsdDao.fetchFpsdOrderKeysByDims(form);
		if(CollectionUtils.isNotEmpty(orderKeys)){
			return orderKeys.size();
		}else{
			return 0;
		}
	}
	@Override
	public PieChartView getFpsdDetractorMainPieChart(SearchOtsForm form) {
		form.setLevel(1);
		form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(form.getStartDate() + "-" +form.getEndDate() , "" , ""));
		List<PieDivider> detractorDividerList = fpsdDao.getDetractorMainDivider(form);
		Map<String, String> detractorMap = new HashMap<String, String>();

		for (PieDivider detractorDivider : detractorDividerList) {
			detractorMap.put(detractorDivider.getLevel1Name(), detractorDivider.getLevel1Num() + "");
		}
		String linkName = "showFpsdDetractorSubPieAndData";
		
		return scCommonService.getDetractorMainPieChart(detractorMap, linkName);
	}

	@Override
	public PieChartView getFpsdDetractorSubPieChart(SearchOtsForm form) {
		String parentType = form.getLevel1Detractor();
		form.setLevel(2);
		form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(form.getStartDate() + "-" +form.getEndDate() , "" , ""));
		List<PieDivider> detractorDividerList = fpsdDao.getDetractorMainDivider(form);
		
		Map<String, String> detractorMap = new HashMap<String, String>();

		for (PieDivider detractorDivider : detractorDividerList) {
			detractorMap.put(detractorDivider.getLevel2Name(), detractorDivider.getLevel2Num() + "");
		}
		String linkName = "showFpdsDetractorTableBylevel2";
		return scCommonService.getDetractorSubPieChart(detractorMap, linkName, parentType);
	}

	@Override
	public List<TtvGridDetractorCodeView> getTtvGridDetractorCodeView(SearchOtsForm form) throws ParseException{
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonth , "" , ""));
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		}
		
		if(!StringUtil.isEmpty(form.getScStatus()) && "all".equalsIgnoreCase(form.getScStatus())){
			form.setShowAllRemarkOrder(true);
			form.setShowUnknownOrder(false);
			List<FpsdRemarkChartData> fpsdRemarkChartDataList = new ArrayList<FpsdRemarkChartData>();
			fpsdRemarkChartDataList = fpsdDao.fetchDimensionRemarkDataList(form);
			String scStatusKey ="";
			boolean hasLate =false;
			boolean hasToBeLate =false;
			boolean hasEarly =false;
			boolean hasToBeEarly =false;
			for(FpsdRemarkChartData otsRemarkChartData : fpsdRemarkChartDataList){
				if(!hasLate && otsRemarkChartData.getLate() > 0){
					scStatusKey = scStatusKey + "3," ;
					hasLate =true;
				}
				if(!hasToBeLate && otsRemarkChartData.getToBeLate() > 0){
					scStatusKey = scStatusKey + "6," ;
					hasToBeLate =true;
				}
				if(!hasEarly && otsRemarkChartData.getEarly() > 0){
					scStatusKey = scStatusKey + "2," ;
					hasEarly =true;
				}
				if(!hasToBeEarly && otsRemarkChartData.getToBeEarly() > 0){
					scStatusKey = scStatusKey + "5," ;
					hasToBeEarly =true;
				}
				
				if(hasLate && hasToBeLate && hasEarly && hasToBeEarly){
					break;
				}
			}
			form.setScStatus(scStatusKey.substring(0, scStatusKey.length() - 1));
		}
		return fpsdDao.getAllOrderDetail(form);
	}
	
	@Override
	public List<TtvGridDetractorCodeView> getDetractorOrderDetail (	SearchOtsForm form) throws ParseException{
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		
		return fpsdDao.getAllDetractorOrder(form);
	}
}
