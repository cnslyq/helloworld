package com.lenovo.bi.service.npi;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.NpiDnsEntry;
import com.lenovo.bi.dto.NpiForecast;

/**
 * forecast service, dealing with all the forecast related business
 * 
 * @author henry_lian
 *
 */
public interface ForecastService {
	
	/**
	 * 
	 * return SS-8 Version forecast, starting from SS-8 to SGA+2
	 * 
	 * re-fill the SGA+1, SGA+2 forecast by version SS-7 if SS-8 forecast isn't able to cover SGA+1, SGA+2
	 * 
	 * forecast supports both MTM and CTO-SBB.
	 * 
	 * forecast is on product level. 
	 * 
	 * if SS Plan & SS actual are in the week, use ss plan if ss actual is null.
	 * 
	 * if ss plan & ss actual are in the different week, use ss actual. 
	 * 
	 * @param waveId
	 * @return
	 */
	public Map<Date, Integer> getSGATTVForecast(int pmsWaveId);

	public List<NpiForecast> getNpiForecastByTargetDate(Integer cvKey,
			Integer versionDateKey, Integer targetDateKey, Integer i);

	public List<NpiForecast> getForecastRateMonthone(Integer month_1, Integer month_2, Integer year_1, Integer year_2, NpiDnsEntry dns,Integer forecastDate, Integer dnsversion);

	public List<NpiForecast> getForecastRateMonthtwo(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2,
			String shortegeCode_1, NpiDnsEntry dns,Integer forecastDate,Integer dnsversion);

	public List<NpiForecast> getForecastRateMonththree(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2,
			String shortegeCode_1, String shortegeCode_2, NpiDnsEntry dns,Integer forecastDate,Integer dnsversion);

	public Integer get2MonthsAgoMondayOfMonthkDate(int targetDateKey);

	public Integer get3MonthsAgo4WeeksMondayOfMonthkDate(int targetDateKey);

	public List getForecastByVersionDate(Integer forecastDate);
}
