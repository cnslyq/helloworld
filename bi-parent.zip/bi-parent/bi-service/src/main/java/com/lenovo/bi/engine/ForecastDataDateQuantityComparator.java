package com.lenovo.bi.engine;

import java.util.Comparator;

import com.lenovo.bi.model.ForecastData;
import com.lenovo.bi.util.CalendarUtil;

public class ForecastDataDateQuantityComparator implements Comparator<ForecastData> {

	@Override
	public int compare(ForecastData o1, ForecastData o2) {
		if (CalendarUtil.isSameDay(o1.getTargetDate(), o2.getTargetDate())) {
			return o1.getQuantity() - o2.getQuantity();
		}
		else {
			if (o1.getTargetDate().before(o2.getTargetDate())) {
				return -1;
			}
			else {
				return 1;
			}
		}
	}

}
