package com.lenovo.bi.engine;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.model.TtvWeeklyDetail;

public class SLEToolingCapacityAllocator extends ToolingCapacityAllocator<TtvWeeklyDetail> {

	//public SLEToolingCapacityAllocator(Map<String, TtvWeeklyDetail> weeklyDetailMap, List<OrderData> orderDataList, List<ForecastData> forecastDataList) {
	public SLEToolingCapacityAllocator(Map<Date, TtvWeeklyDetail> weeklyDetailMap, List<NpiWeeklyComponentCommitmentOnOrder> orderDataList, 
			List<NpiWeeklyComponentCommitmentOnForecast> forecastDataList) {
		super(weeklyDetailMap, orderDataList, forecastDataList);
	}

	public void run() {
		//for (OrderData orderData : orderDataList) {
		for (NpiWeeklyComponentCommitmentOnOrder orderData : orderDataList) {
			//LOGGER.info("Process tooling capacity for order: " + orderData.getUniqueIdentifier());

			int quantity = orderData.getQuantity();
			//TtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(orderData.getProductKey()+orderData.getPmsWaveId());
			TtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(orderData.getTargetDate());

			if (weeklyDetail != null) {
				int coverA = weeklyDetail.getCoverA();
				if (coverA >= quantity) {
					weeklyDetail.setCoverA(coverA - quantity);
					//orderData.setCoverACommit(quantity);
					orderData.setCoverAShortage(0);
				} else {
					weeklyDetail.setCoverA(0);
					//orderData.setCoverACommit(coverA);
					orderData.setCoverAShortage(quantity - coverA);
				}

				int coverB = weeklyDetail.getCoverB();
				if (coverB >= quantity) {
					weeklyDetail.setCoverB(coverB - quantity);
					//orderData.setCoverBCommit(quantity);
					orderData.setCoverBShortage(0);
				} else {
					weeklyDetail.setCoverB(0);
					//orderData.setCoverBCommit(coverB);
					orderData.setCoverBShortage(quantity - coverB);
				}

				int coverC = weeklyDetail.getCoverC();
				if (coverC >= quantity) {
					weeklyDetail.setCoverC(coverC - quantity);
					//orderData.setCoverCCommit(quantity);
					orderData.setCoverCShortage(0);
				} else {
					weeklyDetail.setCoverC(0);
					//orderData.setCoverCCommit(coverC);
					orderData.setCoverCShortage(quantity - coverC);
				}

				int coverD = weeklyDetail.getCoverD();
				if (coverD >= quantity) {
					weeklyDetail.setCoverD(coverD - quantity);
					//orderData.setCoverDCommit(quantity);
					orderData.setCoverDShortage(0);
				} else {
					weeklyDetail.setCoverD(0);
					//orderData.setCoverDCommit(coverD);
					orderData.setCoverDShortage(quantity - coverD);
				}
			} else {
				// It is SC order
			}
		}

		//for (ForecastData forecastData : forecastDataList) {
		for (NpiWeeklyComponentCommitmentOnForecast forecastData : forecastDataList) {
			//LOGGER.info("Process tooling capacity for forecast: " + forecastData.getUniqueIdentifier());

			int quantity = forecastData.getQuantity();
			//TtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(forecastData.getProductKey()+forecastData.getPmsWaveId());
			TtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(forecastData.getTargetDate());

			if (weeklyDetail != null) {
				int coverA = weeklyDetail.getCoverA();
				if (coverA >= quantity) {
					weeklyDetail.setCoverA(coverA - quantity);
					//forecastData.setCoverACommit(quantity);
					forecastData.setCoverAShortage(0);
				} else {
					weeklyDetail.setCoverA(0);
					//forecastData.setCoverACommit(coverA);
					forecastData.setCoverAShortage(quantity - coverA);
				}

				int coverB = weeklyDetail.getCoverB();
				if (coverB >= quantity) {
					weeklyDetail.setCoverB(coverB - quantity);
					//forecastData.setCoverBCommit(quantity);
					forecastData.setCoverBShortage(0);
				} else {
					weeklyDetail.setCoverB(0);
					//forecastData.setCoverBCommit(coverB);
					forecastData.setCoverBShortage(quantity - coverB);
				}

				int coverC = weeklyDetail.getCoverC();
				if (coverC >= quantity) {
					weeklyDetail.setCoverC(coverC - quantity);
					//forecastData.setCoverCCommit(quantity);
					forecastData.setCoverCShortage(0);
				} else {
					weeklyDetail.setCoverC(0);
					//forecastData.setCoverCCommit(coverC);
					forecastData.setCoverCShortage(quantity - coverC);
				}

				int coverD = weeklyDetail.getCoverD();
				if (coverD >= quantity) {
					weeklyDetail.setCoverD(coverD - quantity);
					//forecastData.setCoverDCommit(quantity);
					forecastData.setCoverDShortage(0);
				} else {
					weeklyDetail.setCoverD(0);
					//forecastData.setCoverDCommit(coverD);
					forecastData.setCoverDShortage(quantity - coverD);
				}
			} else {
				// It is SC order
			}
		}
	}
}
