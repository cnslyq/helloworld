package com.lenovo.bi.dao.sc;

import java.util.List;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FaOverViewChartData;
import com.lenovo.bi.dto.sc.GeoFA;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.view.sc.fa.FADetailView;

public interface FADao {
	
	public List<FaOverViewChartData> fetchFaOverViewChartData(SearchFaForm form);
	
	public List<KeyNameObject> fetchDimensions(SearchFaForm form);
	
	public List<ScRemarkChartData> fetchFaRemarkChartData(SearchFaForm form);
	public List<ScRemarkChartData> fetchFaCrossMonthRemarkChartData(SearchFaForm form);
	public List<ScRemarkChartData> fetchFaDashboardRemarkChartData(SearchFaForm form);
	
	public List<FaOverViewChartData> getFaPieChart(SearchFaForm form);
	public List<FaOverViewChartData> getFaDashboardPieChart(SearchFaForm form);
	public List<FaOverViewChartData> getFaCrossmonthPieChart(SearchFaForm form);
	
	public List<FaOverViewChartData> fetchFaDashboardOverViewChartData(SearchFaForm form);

	public List<FaOverViewChartData> fetchFaCrossMonthOverviewChartData(SearchFaForm form);
	
	public List<FADetailView> getFaDetail(SearchFaForm form);
	
	public List<FADetailView> getFaPieDetail(SearchFaForm form);
	
	public long getFaDetailCount(SearchFaForm form);
	
	public long getFaGEODetailCount(SearchFaForm form);
	
	public long getFaPieDetailCount(SearchFaForm form);
	
	public List<String> getLackRegion(SearchFaForm form, int target);
	public List<String> getLackProduct(SearchFaForm form, int target);
	public List<GeoFA> getGeoFa(SearchFaForm form);
	
	public List<FADetailView> getFaGEODetail(SearchFaForm form);
	public List<FADetailView> getFAGEODetailExport(SearchFaForm form);
	public List<FADetailView> getFADetailExport(SearchFaForm form);
	
//	public List<FADetailView> getFaDashboardDetail(SearchFaForm form);
//	public List<FADetailView> getFaCrossmonthDetail(SearchFaForm form);
}
