package com.lenovo.bi.form.sc.mwd;

import com.lenovo.common.model.PagerInformation;


public class SearchMWDForm {
	private String startDate;
	private String endDate;
	private String selectMonth;
	private int purchaseTypeKey;
	private String eol;
	private String chartType;
	private int year;
	private int month;
	private String dimension;
	private String dimensionKey;
	
	private String dashboardType;
	private int dashboardTypeKey = -1;
	private String crossMonthType;
	private int crossMonthTypeKey = -1;
	
	private String overViewDimension;
	private String overViewSubDimension;
	private int overViewSubDimensionKey = -1;
	
	private String remarkDimension;
	private String remarkSubDimension;
	private int remarkSubDimensionKey = -1;
	
	private String remarkSubDimensionKeys ;
	private String remarkSubDimensions ;
	
	private String subDimension;
	private int subDimensionKey=-1;
	private String subKey;
	private String geoIds;
	private String familyIds;
	private String productIds;
	private String components;
	private String odmIds;
	private String componentsValue;
	
	private String sortColumn;
	private String sortType;
	private int endRow;
	private long rowCount;
	private String purchaseType;
	private String reversalSortType;
	
	private int currentPage=1;
	private int mwdTypeKey;
	
	private PagerInformation pagerInfo;
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getSelectMonth() {
		return selectMonth;
	}
	public void setSelectMonth(String selectMonth) {
		this.selectMonth = selectMonth;
	}
	public int getPurchaseTypeKey() {
		return purchaseTypeKey;
	}
	public void setPurchaseTypeKey(int purchaseTypeKey) {
		this.purchaseTypeKey = purchaseTypeKey;
	}
	public String getEol() {
		return eol;
	}
	public void setEol(String eol) {
		this.eol = eol;
	}
	public String getChartType() {
		return chartType;
	}
	public void setChartType(String chartType) {
		this.chartType = chartType;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public String getDimension() {
		return dimension;
	}
	public void setDimension(String dimension) {
		this.dimension = dimension;
	}
	public String getOverViewDimension() {
		return overViewDimension;
	}
	public void setOverViewDimension(String overViewDimension) {
		this.overViewDimension = overViewDimension;
	}
	public String getOverViewSubDimension() {
		return overViewSubDimension;
	}
	public void setOverViewSubDimension(String overViewSubDimension) {
		this.overViewSubDimension = overViewSubDimension;
	}
	public int getOverViewSubDimensionKey() {
		return overViewSubDimensionKey;
	}
	public void setOverViewSubDimensionKey(int overViewSubDimensionKey) {
		this.overViewSubDimensionKey = overViewSubDimensionKey;
	}
	public String getDashboardType() {
		return dashboardType;
	}
	public void setDashboardType(String dashboardType) {
		this.dashboardType = dashboardType;
	}
	public int getDashboardTypeKey() {
		return dashboardTypeKey;
	}
	public void setDashboardTypeKey(int dashboardTypeKey) {
		this.dashboardTypeKey = dashboardTypeKey;
	}
	public String getRemarkDimension() {
		return remarkDimension;
	}
	public void setRemarkDimension(String remarkDimension) {
		this.remarkDimension = remarkDimension;
	}
	public String getRemarkSubDimension() {
		return remarkSubDimension;
	}
	public void setRemarkSubDimension(String remarkSubDimension) {
		this.remarkSubDimension = remarkSubDimension;
	}
	public int getRemarkSubDimensionKey() {
		return remarkSubDimensionKey;
	}
	public void setRemarkSubDimensionKey(int remarkSubDimensionKey) {
		this.remarkSubDimensionKey = remarkSubDimensionKey;
	}
	public String getRemarkSubDimensionKeys() {
		return remarkSubDimensionKeys;
	}
	public void setRemarkSubDimensionKeys(String remarkSubDimensionKeys) {
		this.remarkSubDimensionKeys = remarkSubDimensionKeys;
	}
	public String getRemarkSubDimensions() {
		return remarkSubDimensions;
	}
	public void setRemarkSubDimensions(String remarkSubDimensions) {
		this.remarkSubDimensions = remarkSubDimensions;
	}
	public String getSubDimension() {
		return subDimension;
	}
	public void setSubDimension(String subDimension) {
		this.subDimension = subDimension;
	}
	public int getSubDimensionKey() {
		return subDimensionKey;
	}
	public void setSubDimensionKey(int subDimensionKey) {
		this.subDimensionKey = subDimensionKey;
	}
	public String getGeoIds() {
		return geoIds;
	}
	public void setGeoIds(String geoIds) {
		this.geoIds = geoIds;
	}
	public String getFamilyIds() {
		return familyIds;
	}
	public void setFamilyIds(String familyIds) {
		this.familyIds = familyIds;
	}
	public String getProductIds() {
		return productIds;
	}
	public void setProductIds(String productIds) {
		this.productIds = productIds;
	}
	public String getComponents() {
		return components;
	}
	public void setComponents(String components) {
		this.components = components;
	}
	public String getOdmIds() {
		return odmIds;
	}
	public void setOdmIds(String odmIds) {
		this.odmIds = odmIds;
	}
	public String getCrossMonthType() {
		return crossMonthType;
	}
	public void setCrossMonthType(String crossMonthType) {
		this.crossMonthType = crossMonthType;
	}
	public int getCrossMonthTypeKey() {
		return crossMonthTypeKey;
	}
	public void setCrossMonthTypeKey(int crossMonthTypeKey) {
		this.crossMonthTypeKey = crossMonthTypeKey;
	}
	public String getSortColumn() {
		return sortColumn;
	}
	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}
	public String getSortType() {
		return sortType;
	}
	public void setSortType(String sortType) {
		this.sortType = sortType;
		if("asc".equalsIgnoreCase(sortType)){
			this.reversalSortType = "desc";
		}else if("desc".equalsIgnoreCase(sortType)){
			this.reversalSortType = "asc";
		}
	}
	public int getEndRow() {
		return endRow;
	}
	public void setEndRow(int endRow) {
		this.endRow = endRow;
	}
	public long getRowCount() {
		return rowCount;
	}
	public void setRowCount(long rowCount) {
		this.rowCount = rowCount;
	}
	public String getPurchaseType() {
		return purchaseType;
	}
	public void setPurchaseType(String purchaseType) {
		this.purchaseType = purchaseType;
	}
	public String getDimensionKey() {
		return dimensionKey;
	}
	public void setDimensionKey(String dimensionKey) {
		this.dimensionKey = dimensionKey;
	}
	public String getReversalSortType() {
		return reversalSortType;
	}
	public void setReversalSortType(String reversalSortType) {
		this.reversalSortType = reversalSortType;
	}
	public String getSubKey() {
		return subKey;
	}
	public void setSubKey(String subKey) {
		this.subKey = subKey;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public String getComponentsValue() {
		return componentsValue;
	}
	public void setComponentsValue(String componentsValue) {
		this.componentsValue = componentsValue;
	}
	public int getMwdTypeKey() {
		return mwdTypeKey;
	}
	public void setMwdTypeKey(int mwdTypeKey) {
		this.mwdTypeKey = mwdTypeKey;
	}
	public PagerInformation getPagerInfo() {
		return pagerInfo;
	}
	public void setPagerInfo(PagerInformation pagerInfo) {
		this.pagerInfo = pagerInfo;
	}
	
}
