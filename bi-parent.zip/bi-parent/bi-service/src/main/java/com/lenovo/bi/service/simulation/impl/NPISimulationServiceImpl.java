package com.lenovo.bi.service.simulation.impl;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.npi.NPIOverviewDao;
import com.lenovo.bi.dao.simulation.NPISimulationDao;
import com.lenovo.bi.dto.GlobalCV;
import com.lenovo.bi.dto.OdmCapacityPlanDetail;
import com.lenovo.bi.dto.SingleUnitCvConfig;
import com.lenovo.bi.dto.SupplyShortage;
import com.lenovo.bi.dto.TdmsDefectDetail;
import com.lenovo.bi.dto.ToolingCapacityDetail;
import com.lenovo.bi.engine.MtmCvConfigMap;
import com.lenovo.bi.enumobj.NPISimulationCategoryCode;
import com.lenovo.bi.enumobj.NPISimulationItemName;
import com.lenovo.bi.enumobj.NPISimulationType;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.form.simulation.CVSupply;
import com.lenovo.bi.form.simulation.NPISimulationForm;
import com.lenovo.bi.form.simulation.NPISimulationPreviewData;
import com.lenovo.bi.form.simulation.PreviewOutlookDataForm;
import com.lenovo.bi.form.simulation.SearchNPISimulationForm;
import com.lenovo.bi.form.simulation.SearchNPISimulationHistoryForm;
import com.lenovo.bi.model.NPISimulationDetail;
import com.lenovo.bi.model.NPISimulationSummary;
import com.lenovo.bi.service.npi.TTVService;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.service.simulation.NPISimulationService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;
import com.lenovo.bi.view.simulation.DefectView;
import com.lenovo.bi.view.simulation.NPISimulationItemsView;
import com.lenovo.bi.view.simulation.NPISimulationSummaryView;
import com.lenovo.bi.view.simulation.ODMView;
import com.lenovo.bi.view.simulation.SupplyView;
import com.lenovo.common.model.Pager;
@Service
public class NPISimulationServiceImpl implements NPISimulationService {

	@Inject
	private NPISimulationDao npiSimulationDao;
	@Inject
	private NPIOverviewDao npiOverviewDao;
	@Inject
	private TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper;
	@Inject
	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	@Autowired
	private MtmCvConfigMap mtmCvConfigMap;
	@Inject
	private TTVService tTVService;
	
	@Override
	public List<NPISimulationSummaryView> getNPISimulationSummaryByCondition(
			SearchNPISimulationForm form,Pager<NPISimulationSummaryView>pager) {
		List<NPISimulationSummary> list=npiSimulationDao.getNPISimulationSummaryByCondition(form,pager);
		List<NPISimulationSummaryView>viewList=null;
		if(list!=null&&list.size()>0){
			viewList=new ArrayList<NPISimulationSummaryView>();
			for(NPISimulationSummary summary:list){
				NPISimulationSummaryView view=new NPISimulationSummaryView();
				view.setId(summary.getId());
				Date date=summary.getCreatedDate();
				try {
					view.setCreateDate(CalendarUtil.date2String(date));
				} catch (ParseException e) {
					e.printStackTrace();
				}
				view.setSimulationName(summary.getName());
				view.setProductName(summary.getProductName());
				view.setWaveName(summary.getWaveName());
				view.setTtvPhase(summary.getType()==null?"":summary.getType().toUpperCase());
				try {
					view.setLastModifiedDate(CalendarUtil.date2String(summary.getLastModifiedDate()));
				} catch (ParseException e) {
					e.printStackTrace();
				}
				view.setCreatedBy(summary.getCreatedBy());
				view.setDescription(summary.getDescription());
				view.setSimulationName(summary.getName());
				if(summary.getIsShared() != null){
					view.setType(summary.getIsShared()==1?"Public":"Private");
				}else{
					view.setType("Private");
				}
				viewList.add(view);
			}
		}
		return viewList;
	}

	@Override
	@Transactional("bi")
	public void saveNPISimulationSummary(NPISimulationForm simulation) {
		try {
			NPISimulationSummary simulationSummary=new NPISimulationSummary();
			PropertyUtils.copyProperties(simulationSummary, simulation);
			simulationSummary.setId(simulation.getSimulationId());
			simulationSummary.setLastModifiedDate(new Date());
			simulationSummary.setLastModifiedBy(simulation.getCreatedBy());
			if(simulationSummary.getId()==null){
				simulationSummary.setCreatedDate(new Date());
				npiSimulationDao.addNPISimulationSummary(simulationSummary);
			}else{
				npiSimulationDao.updateNPISimulationSummary(simulationSummary);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<NPISimulationDetail> getNPISimulationHistoryByCondition(
			SearchNPISimulationHistoryForm form) {
		
		List<NPISimulationDetail> simulationList=npiSimulationDao.getHistoricalNPISimulationDetailByCondition(form);
		
		return simulationList;
	}

	@Override
	public NPISimulationSummaryView getNPISimulationSummaryById(String id) {
		NPISimulationSummary summary = npiSimulationDao.getNPISimulationSummaryById(id);
		NPISimulationSummaryView simulation = new NPISimulationSummaryView();
		if(summary != null){
			simulation.setCreatedBy(summary.getCreatedBy());
			try {
				simulation.setCreateDate(CalendarUtil.date2String(summary.getCreatedDate()));
			} catch (ParseException e) {
			}
			simulation.setDescription(summary.getDescription());
			simulation.setId(summary.getId());
			simulation.setSimulationName(summary.getName());
			simulation.setTtvPhase(summary.getType());
			if(summary.getIsShared() == 1){
				simulation.setType(NPISimulationType.Public.name());
			}else{
				simulation.setType(NPISimulationType.Private.name());
			}
			simulation.setWaveId(String.valueOf(summary.getWaveId()));
			simulation.setProductId(npiOverviewDao.getPmsProjectIdByPmsWaveId(simulation.getWaveId()));
			simulation.setProductName(summary.getProductName());
			simulation.setWaveName(summary.getWaveName());
		}
		return simulation;
	}
	
	@Override
	public NPISimulationSummary loadNPISimulationSummaryById(String id) {
		NPISimulationSummary summary = npiSimulationDao.getNPISimulationSummaryById(id);
		return summary;
	}

	@Override
	public NPISimulationItemsView getNPISimulationItemsGrid(
			NPISimulationForm form) throws ParseException {
		//获取odm实体类
		List<NPISimulationDetail> details = npiSimulationDao.getLastestNPISimulationDetailByCondition(form.getSimulationId());//
		List<NPISimulationDetail> supplyDetails = null;
		List<NPISimulationDetail> rampCommitDetails = null;
		List<NPISimulationDetail> defectDetails = null;
		List<NPISimulationDetail> odmDetails = null;
		List<NPISimulationDetail> toolingDetails = null;
		if(CollectionUtils.isNotEmpty(details)){
			supplyDetails = new ArrayList<NPISimulationDetail>();
			rampCommitDetails = new ArrayList<NPISimulationDetail>();
			defectDetails = new ArrayList<NPISimulationDetail>();
			odmDetails = new ArrayList<NPISimulationDetail>();
			toolingDetails = new ArrayList<NPISimulationDetail>();
			for(NPISimulationDetail detail : details){
				if(NPISimulationCategoryCode.RampCommit.name().equals(detail.getCategoryCode())){
					rampCommitDetails.add(detail);
				}else if(NPISimulationCategoryCode.Supply.name().equals(detail.getCategoryCode())){
					supplyDetails.add(detail);
				}else if(NPISimulationCategoryCode.ODM.name().equals(detail.getCategoryCode())){
					odmDetails.add(detail);
				}else if(NPISimulationCategoryCode.Tooling.name().equals(detail.getCategoryCode())){
					toolingDetails.add(detail);
				}else if(NPISimulationCategoryCode.Defect.name().equals(detail.getCategoryCode())){
					defectDetails.add(detail);
				}
			}
		}
		NPISimulationItemsView view=new NPISimulationItemsView();
		Map<String, String> rapCommits = ttvOutlookServiceDwHelper.getRampCommitItems(form.getWaveId()+"", form.getSsDate(), form.getSgaDate());
		if(CollectionUtils.isNotEmpty(rampCommitDetails)){
			for(int i=0;i<rampCommitDetails.size();i++){
				NPISimulationDetail detail=rampCommitDetails.get(i);
				Object modifiedData= rapCommits.get(CalendarUtil.date2String(detail.getTargetDate()));
				if(modifiedData!=null){
					rapCommits.put(CalendarUtil.date2String(detail.getTargetDate()), detail.getModifiedData()+"("+detail.getOriginalData()+")");
				}
			}
		}
		view.setRampCommits(rapCommits);
		String versionDate="";
		String endDate="";
		if(form.getType().equalsIgnoreCase(TTVPhase.sle.name())){
			versionDate=form.getSleVersionDate();
			endDate=form.getSleDate();
		}else{
			versionDate=form.getSgaVersionDate();
			endDate=form.getSgaDate();
		}
		List<ToolingCapacityDetail> toolinglist=ttvOutlookServiceDwHelper.getToolingItems(form.getWaveId()+"", versionDate, form.getSsDate(), endDate);
		List<HashMap<String, Object>> coverList=new ArrayList<HashMap<String,Object>>();
		
		for(ToolingCapacityDetail tooling:toolinglist){
			StringBuffer sb=new StringBuffer();
			sb.append(tooling.getCover()).append(tooling.getTech()).append(tooling.getTooling()).append(tooling.getSupply());
			boolean flag=false;
			for(HashMap<String, Object> cover:coverList){
				if(sb.toString().equals((cover.get("key").toString()))){
					flag=true;
					cover.put(CalendarUtil.date2String(tooling.getTargetDate()), tooling.getCapacity());
				}
			}
			if(flag==false){
				HashMap<String, Object> temp=new HashMap<String, Object>();
				temp.put("key", sb.toString());
				temp.put("part", tooling.getCover());
				temp.put("v", tooling.getTech());
				temp.put("supplier", tooling.getSupply());
				temp.put("tooling", tooling.getTooling());
				temp.put(CalendarUtil.date2String(tooling.getTargetDate()), tooling.getCapacity());
				coverList.add(temp);
			}
		}
		for(HashMap<String, Object> coverMap: coverList ){
		   //boolean flag=false;
		   if(CollectionUtils.isNotEmpty(toolingDetails)){
			   for(int i=0;i<toolingDetails.size();i++){
	        	   StringBuffer sb=new StringBuffer();
	        	   NPISimulationDetail t=toolingDetails.get(i);
	        	   sb.append(t.getIndicator1()).append(t.getIndicator2()).append(t.getIndicator3()).append(t.getIndicator4());
	        	   if(sb.toString().equals(coverMap.get("key"))){
	        		   coverMap.put(CalendarUtil.date2String(t.getTargetDate()), t.getModifiedData()+"("+t.getOriginalData()+")");
	        	   }
	           }
		   }
		}
		view.setCoverList(coverList);
		Map<String,Integer>demand=new HashMap<String,Integer>();
		if(form.getType().equalsIgnoreCase(TTVPhase.sle.name())){
			demand=ttvOutlookServiceBiHelper.getSleTTVDemandByWaveId(form.getWaveId()+"",form.getSleVersionDate(),form.getSsDate(),form.getSleDate());
			
		}else{
			demand=ttvOutlookServiceBiHelper.getSgaTTVDemandByWaveId(form.getWaveId()+"",form.getSgaVersionDate(),form.getSsDate(),form.getSgaDate());
		}
		view.setDemand(demand);
		/**ODM Start**/
		List<OdmCapacityPlanDetail>odmList=ttvOutlookServiceDwHelper.getOdmItems(form.getWaveId(), form.getSleVersionDate(), form.getSsDate(), form.getSleDate());
		
		List<ODMView>views=new ArrayList<ODMView>();
		
		//OdmCapacityPlanDetail==>ODMView
		for(OdmCapacityPlanDetail detail:odmList){
			ODMView odmView=new ODMView();
			odmView.setOdmCapacityPlanId(detail.getOdmNpiCapacityPlanId());
			odmView.setOdmName(detail.getOdmName());
			odmView.setLine(detail.getLine());
			odmView.setCrew(detail.getCrew());
			odmView.setUnitsPerHour(detail.getUnitsPerHour()+"");
			odmView.setDaysPerWeek(detail.getDaysPerWeek()+"");
			odmView.setFpy(detail.getFpy()+"%");
			odmView.setHoursPerDay(detail.getHoursPerDay()+"");
			odmView.setRpy(detail.getRpy()+"%");
			odmView.setTargetDate(detail.getTargetDate());
			odmView.setUseRpy(detail.isUseRpy());
			views.add(odmView);
		}
		
		//结合simulationDetail,95%(94%)
		
		for(ODMView odmView:views){
			// odmView 的 odmName line crew targetDate 和 detail 的 indicator1 indicator2  indicator3  targetDate
			if(CollectionUtils.isNotEmpty(odmDetails)){
				for(NPISimulationDetail odmSimulation:odmDetails){
					if(odmView.getOdmName().equalsIgnoreCase(odmSimulation.getIndicator1())
							&&odmView.getLine().equalsIgnoreCase(odmSimulation.getIndicator2())
								&&odmView.getCrew().equalsIgnoreCase(odmSimulation.getIndicator3())
									&&odmView.getTargetDate().equals(odmSimulation.getTargetDate())){
						getODMView(odmView,odmSimulation);
					}
				}
			}
			if(CollectionUtils.isNotEmpty(odmDetails)){
				for(NPISimulationDetail odmSimulation:odmDetails){
					if(odmView.getOdmName().equalsIgnoreCase(odmSimulation.getIndicator1())
							&&odmView.getLine().equalsIgnoreCase(odmSimulation.getIndicator2())
								&&odmView.getCrew().equalsIgnoreCase(odmSimulation.getIndicator3())){
						getUseRPY(odmView,odmSimulation);
					}
				}
			}
		}
		
		//key是odmName+crew+line  value是List<ODMView>
		Map<String,List<ODMView>>map=new HashMap<String,List<ODMView>>();
		for(ODMView odmV:views){
			if(map.get(odmV.getOdmName()+" "+odmV.getCrew()+" "+odmV.getLine())==null){
				List<ODMView>list=new ArrayList<ODMView>();
				list.add(odmV);
				map.put(odmV.getOdmName()+" "+odmV.getCrew()+" "+odmV.getLine(), list);
			}else{
				map.get(odmV.getOdmName()+" "+odmV.getCrew()+" "+odmV.getLine()).add(odmV);
			}
		}
		
		//给页面的List
		List<Map<String,ODMView>>finalList=new ArrayList<Map<String,ODMView>>();
		
		for(Entry<String,List<ODMView>>entry:map.entrySet()){
			List<ODMView>subOdm=entry.getValue();
			//TargerDate , List<ODMView>
			Map<String,ODMView>finalMap=new HashMap<String,ODMView>();
			for(ODMView v:subOdm){
				try {
					if(finalMap.get(CalendarUtil.date2String(v.getTargetDate()))==null){
						finalMap.put(CalendarUtil.date2String(v.getTargetDate()), v);
					}else{
						//System.out.println("ODM Simulation error");
					}
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
			finalList.add(finalMap);
		}
		/**ODM end**/
		view.setOdms(finalList);
		
		try {
			view.setDefects(this.getDefectItems(form, defectDetails));
		} catch (Exception e) {
			view.setDefects(null);
			e.printStackTrace();
		} 
		view.setSupplys(this.getSupplyItems(form, supplyDetails));
		return view;
	}
	private void getODMView(ODMView odmView,NPISimulationDetail odmDetails){
		
		if(odmDetails.getItemName().equalsIgnoreCase(NPISimulationItemName.UPH.toString())
				&&StringUtils.isNotBlank(odmDetails.getModifiedData())){
			odmView.setUnitsPerHour(odmDetails.getModifiedData()+"("+odmView.getUnitsPerHour()+")");
		}else{
			odmView.setUnitsPerHour(odmView.getUnitsPerHour()+"");
		}
		
		if(odmDetails.getItemName().equalsIgnoreCase(NPISimulationItemName.FPY.toString())
				&&StringUtils.isNotBlank(odmDetails.getModifiedData())){
			odmView.setFpy(odmDetails.getModifiedData()+"%("+odmView.getFpy()+")");
		}else{
			odmView.setFpy(odmView.getFpy()+"");
		}
		
		if(odmDetails.getItemName().equalsIgnoreCase(NPISimulationItemName.RPY.toString())
				&&StringUtils.isNotBlank(odmDetails.getModifiedData())){
			odmView.setRpy(odmDetails.getModifiedData()+"%("+odmView.getRpy()+")");
		}else{
			odmView.setRpy(odmView.getRpy()+"");
		}
		
		if(odmDetails.getItemName().equalsIgnoreCase(NPISimulationItemName.Hours_Per_Day.toString())
				&&StringUtils.isNotBlank(odmDetails.getModifiedData())){
			odmView.setHoursPerDay(odmDetails.getModifiedData()+"("+odmView.getHoursPerDay()+")");
		}else{
			odmView.setHoursPerDay(odmView.getHoursPerDay()+"");
		}
		
		if(odmDetails.getItemName().equalsIgnoreCase(NPISimulationItemName.Days_Per_Week.toString())
				&&StringUtils.isNotBlank(odmDetails.getModifiedData())){
			odmView.setDaysPerWeek(odmDetails.getModifiedData()+"("+odmView.getDaysPerWeek()+")");
		}else{
			odmView.setDaysPerWeek(odmView.getDaysPerWeek()+"");
		}
		
	}
	private List<DefectView> getDefectItems(NPISimulationForm form,List<NPISimulationDetail> defectDetails) throws ParseException, IllegalAccessException, InvocationTargetException, NoSuchMethodException{
		List<TdmsDefectDetail> defectDwList;
		if(TTVPhase.sle.name().equalsIgnoreCase(form.getType())){
			defectDwList = ttvOutlookServiceDwHelper.getDefectItems(String.valueOf(form.getWaveId()), CalendarUtil.stringT2Date(form.getSleVersionDate()));
		}else{
			defectDwList = ttvOutlookServiceDwHelper.getDefectItems(String.valueOf(form.getWaveId()), CalendarUtil.stringT2Date(form.getSgaVersionDate()));
		}
		if(CollectionUtils.isNotEmpty(defectDwList)){
			Map<String,Map<NPISimulationItemName,String>> detailMap = new HashMap<String,Map<NPISimulationItemName,String>>();
			if(defectDetails != null){
				Map<NPISimulationItemName,String> itemValue;
				for(NPISimulationDetail detail : defectDetails){
					if(detailMap.get(detail.getIndicator1()) != null){
						itemValue = detailMap.get(detail.getIndicator1());
					}else{
						itemValue = new HashMap<NPISimulationItemName,String>();
					}
					
					if(NPISimulationItemName.Target_Resolve_Date.toString().equals(detail.getItemName())){
						itemValue.put(NPISimulationItemName.Target_Resolve_Date, detail.getModifiedData());
					}else if(NPISimulationItemName.Target_FPY_Impact.toString().equals(detail.getItemName())){
						itemValue.put(NPISimulationItemName.Target_FPY_Impact, detail.getModifiedData());
					}
					detailMap.put(detail.getIndicator1(), itemValue);
				}
			}
			List<DefectView> defectItems = new  ArrayList<DefectView>();
			DefectView item;
			Map<NPISimulationItemName,String> modifyValue;
			for(TdmsDefectDetail defect : defectDwList){
				item = new DefectView();
				PropertyUtils.copyProperties(item, defect);
				modifyValue = detailMap.get(defect.getDefectNo());
				if(modifyValue != null){
					String modifyFpyImpact = modifyValue.get(NPISimulationItemName.Target_FPY_Impact);
					String modifyTargetDate = modifyValue.get(NPISimulationItemName.Target_Resolve_Date);
					if(StringUtils.isNotBlank(modifyFpyImpact)){
						item.setModifyFpyImpact(Float.valueOf(modifyFpyImpact));
					}
					if(StringUtils.isNotBlank(modifyTargetDate)){
						item.setModifyTargetDate(CalendarUtil.stringT2Date(modifyTargetDate));
					}
				}
				defectItems.add(item);
			}
			return defectItems;
		}else{
			return null;
		}
	}
	private List<SupplyView> getSupplyItems(NPISimulationForm form, List<NPISimulationDetail> supplySimulations) throws ParseException{
		String productKey = ttvOutlookServiceDwHelper.getProductKeyByPmsWaveId(form.getWaveId());
		List<SupplyShortage>  supplyShortages;
		if(StringUtils.isNotBlank(productKey)){
			if(TTVPhase.sga.name().equalsIgnoreCase(form.getType())){
				supplyShortages = ttvOutlookServiceBiHelper.getSupplyShortageByProductKey(productKey, CalendarUtil.stringT2Date(form.getSgaVersionDate()), 
						CalendarUtil.getMondayDateByWeeks(CalendarUtil.stringT2Date(form.getSsDate()), -2), CalendarUtil.stringT2Date(form.getSgaDate()), TTVPhase.sga.name());
			}else{
				supplyShortages = ttvOutlookServiceBiHelper.getSupplyShortageByProductKey(productKey, CalendarUtil.stringT2Date(form.getSleVersionDate()), 
						CalendarUtil.getMondayDateByWeeks(CalendarUtil.stringT2Date(form.getSsDate()), -2), CalendarUtil.stringT2Date(form.getSleDate()), TTVPhase.sle.name());
			}
			if(CollectionUtils.isNotEmpty(supplyShortages)){
				Map<String,GlobalCV> cvMap = ttvOutlookServiceDwHelper.getAllGolobalCV();
				Map<GlobalCV,Map<String,Map<String,Integer>>> shortageMap = new HashMap<GlobalCV,Map<String,Map<String,Integer>>>();
				Map<String,Map<String,Integer>> dateMap;
				Map<String,Integer> valueMap;
				GlobalCV cv;
				for(SupplyShortage supplyShortage : supplyShortages){
					cv = cvMap.get(supplyShortage.getGlobalCVKey());
					if(cv != null){
						dateMap = shortageMap.get(cv);
						if(dateMap == null){
							dateMap = new HashMap<String,Map<String,Integer>>();
							valueMap = new HashMap<String,Integer>();
						}else{
							valueMap = dateMap.get(CalendarUtil.date2String(supplyShortage.getTargetDate()));
							if(valueMap == null){
								valueMap = new HashMap<String,Integer>();
							}
						}
						valueMap.put("OriginalData", supplyShortage.getShortage());
						valueMap.put("CommitmentData", supplyShortage.getCommitment());
						dateMap.put(CalendarUtil.date2String(supplyShortage.getTargetDate()), valueMap);
						shortageMap.put(cv, dateMap);
					}
				}
				if(CollectionUtils.isNotEmpty(supplySimulations)){
					for(NPISimulationDetail detail : supplySimulations){
						cv = new GlobalCV();
						cv.setC(detail.getIndicator1());
						cv.setV(detail.getIndicator2());
						dateMap = shortageMap.get(cv);
						if(dateMap != null){
							valueMap = dateMap.get(CalendarUtil.date2String(detail.getTargetDate()));
							if(valueMap != null){
								valueMap.put("ModifiedData", Integer.parseInt(detail.getModifiedData()));
							}
						}
					}
				}
				List<SupplyView> supplyList = new ArrayList<SupplyView>();
				SupplyView supply;
				Set<GlobalCV> key = shortageMap.keySet();
				GlobalCV gcv;
		        for (Iterator<GlobalCV> it = key.iterator(); it.hasNext();) {
		        	supply = new SupplyView();
		        	gcv = (GlobalCV) it.next();
		        	supply.setCv(gcv);
		        	supply.setDateMap(shortageMap.get(gcv));
		        	supplyList.add(supply);
		        }
				return supplyList;
			}
		}
		return null;
	}
	@Override
	public MSColumnChartView previewOutlookJsonChartData(
			PreviewOutlookDataForm form) {
		List<NPISimulationPreviewData> perviewDataList = form.getPerviewDataList();
		Map<String,NPISimulationPreviewData> perviewDataMap = new HashMap<String,NPISimulationPreviewData>();
		if(CollectionUtils.isNotEmpty(perviewDataList)){
			for(NPISimulationPreviewData data : perviewDataList){
				perviewDataMap.put(data.getTargetDate(), data);
			}
		}
		try {
			if(TTVPhase.sga.name().equalsIgnoreCase(form.getSgaOrSle())){
				
					return tTVService.getSgaOutlookJsonChartDataByWeekly(form.getChartForm(), false, null, false,perviewDataMap);
			}else{
					return tTVService.getOutlookJsonChartDataByWeekly(form.getChartForm(), false,
									null, false,perviewDataMap);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public void saveBatchNPISimulationDetail(List<NPISimulationDetail> list) {
		npiSimulationDao.batchAddNPISimulationDetail(list);
	}

	@Override
	@Transactional("bi")
	public Integer saveAsNPISimulation(NPISimulationForm simulation) {
		try {
			NPISimulationSummary simulationSummary=new NPISimulationSummary();
			PropertyUtils.copyProperties(simulationSummary, simulation);
			simulationSummary.setCreatedDate(new Date());
			simulationSummary.setLastModifiedDate(new Date());
			simulationSummary.setLastModifiedBy(simulation.getCreatedBy());
			
			NPISimulationSummary newSimulation=npiSimulationDao.addNPISimulationSummary(simulationSummary);
			
			List<NPISimulationDetail> list=npiSimulationDao.getSimulationDetailBySimulationId(simulation.getId());
			for(NPISimulationDetail detail:list){
				detail.setnPISimulationSummary(newSimulation);
			}
			npiSimulationDao.batchAddNPISimulationDetail(list);
			
			return newSimulation.getId();
		} catch (Exception e) {
			e.printStackTrace();
		}
     return null;
	}
	
	@Override
	public int getTotalCountNPISimulationSummaryByCondition(SearchNPISimulationForm form){
		return npiSimulationDao.getTotalCountNPISimulationSummaryByCondition(form);
	}

	@Override
	public void deleteNPISimulation(Integer[] ids) {
		npiSimulationDao.batchDeleteNPISimulationSummary(ids);
	}

	@Override
	public List<String> getCreatedBy() {
		return npiSimulationDao.getCreatedBy();
	}

	@Override
	public void calculateSupplyCommitment(Date versionDate,Date startDate, Date endDate,
			String waveId,String ttvPhase, List<NPISimulationPreviewData> perviewDataList) {
		if(CollectionUtils.isNotEmpty(perviewDataList)){
			String productKey = ttvOutlookServiceDwHelper.getProductKeyByPmsWaveId(Integer.parseInt(waveId));
			List<SupplyShortage> allBomNumberList = ttvOutlookServiceBiHelper.queryBomNumberByProductKey(productKey,versionDate,startDate,endDate,ttvPhase);
			Map<Date,List<String>> bomNuberMap = new HashMap<Date,List<String>>();
			List<String> bomList = null;
			if(allBomNumberList != null){
				for(SupplyShortage bom : allBomNumberList){
					bomList = bomNuberMap.get(bom.getTargetDate());
					if(bomList == null){
						bomList = new ArrayList<String>();
					}
					bomList.add(bom.getBomNumber());
					bomNuberMap.put(bom.getTargetDate(), bomList);
				}
			}
			for(NPISimulationPreviewData previewData : perviewDataList){
				ArrayList<CVSupply> cvSupplyList = previewData.getSupplys();
				if(CollectionUtils.isNotEmpty(cvSupplyList)){
					try {
						bomList = bomNuberMap.get(CalendarUtil.stringT2Date(previewData.getTargetDate()));
					} catch (ParseException e) {
						bomList = null;
					}
					if(CollectionUtils.isNotEmpty(bomList)){
						for(String bomNumber : bomList){
							int min = Integer.MAX_VALUE;
							SingleUnitCvConfig cvQty = mtmCvConfigMap.getSingleUnitCvConfigOfMtm(bomNumber);
							for(CVSupply supply : cvSupplyList){
								int qty = cvQty.getQuantity(supply.getGlobalCVKey());
								if(qty >0){
									int available = supply.getCommitment()/qty;
									min = Math.min(min, available);
								}
							}
							previewData.setSupplyCommit(previewData.getSupplyCommit() + min);
							for(CVSupply supply : cvSupplyList){
								supply.setCommitment(supply.getCommitment() - (min*cvQty.getQuantity(supply.getGlobalCVKey())));
							}
						}
					}
				}
			}
		}
	}

	public void getUseRPY(ODMView odmView,NPISimulationDetail odmDetails){
		//如果针对未来的话用detail
		if(NPISimulationItemName.IsRPYinclude.toString().equalsIgnoreCase(odmDetails.getItemName())){
			if(odmView.getTargetDate().after(CalendarUtil.getMonday())||odmView.getTargetDate().equals(CalendarUtil.getMonday())){
				odmView.setUseRpy("1".equals(odmDetails.getModifiedData())?true:false);
			}
		}
	}

}
