package com.lenovo.bi.view.npi.chart.common;

public class DataSetParent {

	private String seriesName;

	public String getSeriesName() {
		return seriesName;
	}

	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}

}
