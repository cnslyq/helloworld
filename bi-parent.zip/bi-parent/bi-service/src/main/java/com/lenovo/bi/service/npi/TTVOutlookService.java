package com.lenovo.bi.service.npi;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.Forecast;
import com.lenovo.bi.dto.TTVOutlookChartData;
import com.lenovo.bi.dto.TTVOutlookDetractorCode;
import com.lenovo.bi.enumobj.TimeFrequencyEnum;
import com.lenovo.bi.exception.BusinessException;
import com.lenovo.bi.form.simulation.NPISimulationPreviewData;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.view.npi.ForecastCompare;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.TtvGridTrackingCauses;

public interface TTVOutlookService {
	/**
	 * Return pre-calculated chart data
	 * 
	 * @param waveId
	 * @param startDate
	 * @param endDate
	 * @param timeFrequency
	 * @param odmFpy
	 *            Use ODM FPY or TDMS FPY
	 * @return Chart data between start date and end date
	 */
	List<TTVOutlookChartData> getChartData(int waveId, Date startDate, Date endDate, TimeFrequencyEnum timeFrequency, boolean odmFpy, Date versionDate,
			boolean isShowSGA,boolean isSnapshot);

	/**
	 * Return pre-calculated chart data
	 * 
	 * @param waveId
	 * @param startDate
	 * @param endDate
	 * @param timeFrequency
	 * @param odmFpy
	 *            Use ODM FPY or TDMS FPY
	 * @param isShowSLE
	 * @return Chart data between start date and end date
	 * @throws BusinessException 
	 */
	List<TTVOutlookChartData> getSgaChartData(int waveId, Date startDate, Date endDate, TimeFrequencyEnum timeFrequency, boolean odmFpy, Date versionDate,
			boolean isShowSLE, boolean isSnapshot) throws BusinessException;

	/**
	 * Recalculate chart data
	 */
	void calculateChartData(int waveId);

	/**
	 * Return SLE cause of one day or one week
	 * 
	 * @param waveId
	 * @param startDate
	 *            Must be current date or later. For weekly cause, startDate is
	 *            the Monday?
	 * @param timeFrequency
	 * @param odmFpy
	 * @return Cause of one day or one week
	 */
	TtvGridTrackingCauses getCause(int waveId, Date startDate, TimeFrequencyEnum timeFrequency, boolean odmFpy, Date versionDate);

	/**
	 * 
	 * return SGA causes of one day or one week
	 * 
	 * @param waveId
	 * @param startDate
	 * @param timeFrequency
	 * @param odmFpy
	 * @return
	 */
	TtvGridTrackingCauses getSGACause(int waveId, Date startDate, TimeFrequencyEnum timeFrequency, boolean odmFpy, Date versionDate);

	/**
	 * Return detractor code of one day or one week
	 * 
	 * @param waveId
	 * @param startDate
	 * @param timeFrequency
	 * @return Detractor code of one day or one week
	 */
	List<TTVOutlookDetractorCode> getDetractorCode(int waveId, Date startDate, TimeFrequencyEnum timeFrequency);

	Map<Date, List<Forecast>> getForecastVersions(int waveId, Date targetDate, Date versionDate, int versioncount,boolean showGeo);

	List<ForecastCompare> getForecastComparison(int waveId, Date TargetDate, Date comparedDate,Date compareDate,String region);

	List<TTVOutlookChartData> excludeOrderPreview(int waveId, Date startDate, Date endDate, TimeFrequencyEnum timeFrequency, boolean odmFpy, Date versionDate,
			boolean isShowSGA, List<NpiOrder> orders);

	List<TTVOutlookChartData> excludeSGAOrderPreview(int waveId, Date startDate, Date endDate, TimeFrequencyEnum weekly, boolean odmFpy, Date versionDate,
			boolean showSle, List<NpiOrder> orders);
	public List<TTVOutlookChartData> simulationSLEPreview(int waveId,boolean odmFpy,Date versionDate,Date startDate,Date endDate,boolean isShowSga,Map<String,NPISimulationPreviewData> previewDataMap);
	public List<TTVOutlookChartData> simulationSGAPreview(int waveId, Date startDate, Date endDate, TimeFrequencyEnum weekly, boolean odmFpy, Date versionDate,
			boolean showSle, Map<String,NPISimulationPreviewData> previewDataMap);
}
