package com.lenovo.bi.engine;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.ToolingCapacity;
import com.lenovo.bi.model.TtvWeeklyDetail;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.SysConstants;
import com.lenovo.common.logging.Logger;
import com.lenovo.common.logging.LoggerFactory;

public class SLEProductCommittedToolingCapacityCalculator extends ProductCommittedToolingCapacityCalculator<TtvWeeklyDetail> {
	//private Date versionDate;
	//private Date targetDate;

	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	private ProductKeyPmsWaveIdMap productKeyPmsWaveIdMap;

	private static Logger LOGGER = LoggerFactory.getLogger(SysConstants.LOG_WEEKLY_BATCH_CATALOG);

	/*
	public SLEProductCommittedToolingCapacityCalculator(Date targetDate, Date versionDate, ProductKeyPmsWaveIdMap productKeyPmsWaveIdMap) {
		super(targetDate, versionDate, productKeyPmsWaveIdMap);
	}
	*/
	public SLEProductCommittedToolingCapacityCalculator(Integer pmsWaveId, Date versionDate) {
		super(pmsWaveId, versionDate);
	}

	//public void calculate(Map<String, TtvWeeklyDetail> weeklyDetailMap) {
	public void calculate(Map<Date, TtvWeeklyDetail> weeklyDetailMap) {
		//List<ToolingCapacity> toolingCapacityInWeek = ttvOutlookServiceDwHelper.getToolingCapacityInWeek(targetDate, versionDate);
		List<ToolingCapacity> toolingCapacityInWeek = ttvOutlookServiceDwHelper.getToolingCapacityByWave(pmsWaveId, versionDate);

		for (ToolingCapacity toolingCapacity : toolingCapacityInWeek) {
			//String pmsWaveId = toolingCapacity.getPmsWaveId();
			//String productKey = productKeyPmsWaveIdMap.getProductKeyFromPmsWaveId(pmsWaveId);

			//LOGGER.info("Process tooling capacity of product key: " + productKey);

			//TtvWeeklyDetail npiWeeklyDetail = weeklyDetailMap.get(productKey+pmsWaveId);
			TtvWeeklyDetail npiWeeklyDetail = weeklyDetailMap.get(toolingCapacity.getTargetDate());

			if (npiWeeklyDetail != null) {
				int fullCapacity = toolingCapacity.getCapacity() + toolingCapacity.getBoh();
				switch (toolingCapacity.getCover()) {
				case A:
					npiWeeklyDetail.setCoverA(fullCapacity);
					break;
				case B:
					npiWeeklyDetail.setCoverB(fullCapacity);
					break;
				case C:
					npiWeeklyDetail.setCoverC(fullCapacity);
					break;
				case D:
					npiWeeklyDetail.setCoverD(fullCapacity);
					break;
				default:
					//StringBuffer sb = new StringBuffer("Tooling capacity for product key " + productKey);
					StringBuffer sb = new StringBuffer("Tooling capacity for wave " + pmsWaveId);
					sb.append(" has an unrecognized cover: " + toolingCapacity.getCover());
					LOGGER.error(sb.toString());
					break;
				}
			} else {
				// It is SC capacity
				// TODO-Ying Does SC care about tooling capacity?
			}
		}
	}

	public void setTtvOutlookServiceDwHelper(TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper) {
		this.ttvOutlookServiceDwHelper = ttvOutlookServiceDwHelper;
	}
}
