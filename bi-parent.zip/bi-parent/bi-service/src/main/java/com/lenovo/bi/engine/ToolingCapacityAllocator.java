package com.lenovo.bi.engine;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.util.SysConstants;
import com.lenovo.common.logging.Logger;
import com.lenovo.common.logging.LoggerFactory;

abstract public class ToolingCapacityAllocator<T> {
	//protected Map<String, T> weeklyDetailMap;
	protected Map<Date, T> weeklyDetailMap;

	//protected List<OrderData> orderDataList = new ArrayList<OrderData>();
	//protected List<ForecastData> forecastDataList = new ArrayList<ForecastData>();
	protected List<NpiWeeklyComponentCommitmentOnOrder> orderDataList = new ArrayList<NpiWeeklyComponentCommitmentOnOrder>();
	protected List<NpiWeeklyComponentCommitmentOnForecast> forecastDataList = new ArrayList<NpiWeeklyComponentCommitmentOnForecast>();

	protected static Logger LOGGER = LoggerFactory.getLogger(SysConstants.LOG_WEEKLY_BATCH_CATALOG);

	//public ToolingCapacityAllocator(Map<String, T> weeklyDetailMap, List<OrderData> orderDataList, List<ForecastData> forecastDataList) {
	public ToolingCapacityAllocator(Map<Date, T> weeklyDetailMap, List<NpiWeeklyComponentCommitmentOnOrder> orderDataList, 
			List<NpiWeeklyComponentCommitmentOnForecast> forecastDataList) {
		this.weeklyDetailMap = weeklyDetailMap;
		this.orderDataList = orderDataList;
		this.forecastDataList = forecastDataList;
	}

	abstract public void run();
}
