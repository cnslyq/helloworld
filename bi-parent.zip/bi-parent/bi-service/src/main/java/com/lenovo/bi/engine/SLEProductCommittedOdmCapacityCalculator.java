package com.lenovo.bi.engine;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.OdmCapacityPlan;
import com.lenovo.bi.dto.TdmsDefect;
import com.lenovo.bi.enumobj.TimeFrequencyEnum;
import com.lenovo.bi.model.TtvWeeklyDetail;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;

public class SLEProductCommittedOdmCapacityCalculator extends ProductCommittedOdmCapacityCalculator<TtvWeeklyDetail> {

	/*
	public SLEProductCommittedOdmCapacityCalculator(Date targetDate, Date versionDate) {
		super(targetDate, versionDate);
	}
	*/
	public SLEProductCommittedOdmCapacityCalculator(Integer pmsWaveId, Date versionDate) {
		super(pmsWaveId, versionDate);
	}

	/**
	 * Calculate the ODM capacity available to the product based on ODM and TDMS
	 * FPY
	 * 
	 * @param npiWeeklyDetails
	 */
	public void calculate(List<TtvWeeklyDetail> npiWeeklyDetails) {
		for (TtvWeeklyDetail detail : npiWeeklyDetails) {
			//LOGGER.info("Process ODM capacity for TtvWeeklyDetail with ID: " + detail.getTtvWeeklyDetailId());

			//List<OdmCapacityPlan> plans = ttvOutlookServiceDwHelper.getOdmNpiCapacityPlanForTargetDate(detail.getPmsWaveId(), targetDate, versionDate);
			List<OdmCapacityPlan> plans = ttvOutlookServiceDwHelper.getOdmNpiCapacityPlanForTargetDate(pmsWaveId, detail.getTargetDate(), versionDate);

			// Calculate ODM capacity based on ODM FPY. RPY is relevant.
			detail.setOdmFpyCapacity(ttvOutlookServiceDwHelper.calculateOdmNpiCapacity(plans, TimeFrequencyEnum.WEEKLY, false, false));
			detail.setOdmRpyCapacity(ttvOutlookServiceDwHelper.calculateOdmNpiCapacity(plans, TimeFrequencyEnum.WEEKLY, true, false));

			// Calculate ODM capacity based on TDMS FPY. RPY is irrelevant.
			//List<TdmsDefect> tdmsDefects = ttvOutlookServiceDwHelper.getTdmsDefectsForTargetDate(detail.getPmsWaveId(), targetDate, versionDate);
			List<TdmsDefect> tdmsDefects = ttvOutlookServiceDwHelper.getTdmsDefectsForTargetDate(pmsWaveId, detail.getTargetDate(), versionDate);
			float tdmsFpy = ttvOutlookServiceDwHelper.calculateTdmsDefectFpy(tdmsDefects);

			int productTdmsOdmCapacity = ttvOutlookServiceDwHelper.calculateOdmNpiCapacity(plans, tdmsFpy*100f, TimeFrequencyEnum.WEEKLY);
			detail.setTdmsFpyCapacity(productTdmsOdmCapacity);
			detail.setTdmsRpyCapacity(productTdmsOdmCapacity);
		}
	}

	public void setTtvOutlookServiceDwHelper(TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper) {
		this.ttvOutlookServiceDwHelper = ttvOutlookServiceDwHelper;
	}

}
