package com.lenovo.bi.service.npi.helper;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.npi.impl.NpiCommittedCVAllocatorDaoBiImpl;
import com.lenovo.bi.dto.WeeklyComponentCommitmentOnProductDto;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnProduct;

@Service
@Transactional("bi")
public class NpiCommittedCVAllocatorBiHelper {

	@Autowired
	private NpiCommittedCVAllocatorDaoBiImpl allocatorDaoBi;
	
	public NpiCommittedCVAllocatorDaoBiImpl getAllocatorDaoBi() {
		return allocatorDaoBi;
	}

	public void setAllocatorDaoBi(NpiCommittedCVAllocatorDaoBiImpl allocatorDaoBi) {
		this.allocatorDaoBi = allocatorDaoBi;
	}

	/**
	 * get commit CV on product map
	 * @param versionDate
	 * @param initDate
	 * @param financeEndDate
	 * @return
	 */
	public Map<Integer, WeeklyComponentCommitmentOnProductDto> getCommitmentOnProductMap(Date versionDate, 
			Date initDate, Date financeEndDate){
		Map<Integer, WeeklyComponentCommitmentOnProductDto> commitOnProductMap = 
				new HashMap<Integer, WeeklyComponentCommitmentOnProductDto>();
		
		//get committed CV on product
		List<NpiWeeklyComponentCommitmentOnProduct> commitOnProductList = 
				allocatorDaoBi.getCommitmentOnProduct(versionDate, initDate, financeEndDate);
		
		for(NpiWeeklyComponentCommitmentOnProduct commitOnProduct : commitOnProductList){
			//init
			WeeklyComponentCommitmentOnProductDto commitOnProductDto = null;
			//List<Integer> targetDateList = null;

			int productKey = commitOnProduct.getProductKey();
			//get DTO object
			if(null == commitOnProductMap.get(productKey)){
				commitOnProductDto = new WeeklyComponentCommitmentOnProductDto();
				//targetDateList = new ArrayList<Integer>();
				//set DTO object
				commitOnProductDto.setProductKey(productKey);
				commitOnProductDto.setVersionDate(versionDate);
				//commitOnProductDto.setTargetDateList(targetDateList);
				commitOnProductDto.setTargetDateCvMap(new HashMap<Integer, Map<Integer,Long>>());
				commitOnProductMap.put(productKey, commitOnProductDto);
			}
			commitOnProductDto = commitOnProductMap.get(productKey);
			//targetDateList = commitOnProductDto.getTargetDateList();
			Map<Integer, Map<Integer, Long>> targetDateCvMap = commitOnProductDto.getTargetDateCvMap();
			
			//get target date, CV key and quantity
			Integer targetDate = commitOnProduct.getTargetDate();			
			int cvKey = commitOnProduct.getGlobalCVKey();
			Long quantity = commitOnProduct.getCommitment();
			
			//add target date to the list
			//if(!targetDateList.contains(targetDate))
			//	targetDateList.add(targetDate);
			
			//add target date and CV mapping to the map
			if(null == targetDateCvMap.get(targetDate)){
				targetDateCvMap.put(targetDate, new HashMap<Integer, Long>());
			}
			Map<Integer, Long> cvMap = targetDateCvMap.get(targetDate);
			cvMap.put(cvKey, quantity);
		}
		return commitOnProductMap;
	}
	
	/**
	 * save order allocation results
	 * @param commitOnOrderList
	 */
	public void saveCommitmentOnOrder(List<NpiWeeklyComponentCommitmentOnOrder> commitOnOrderList){
		allocatorDaoBi.saveCommitmentOnOrder(commitOnOrderList);
	}
	
	/**
	 * save forecast allocation results
	 * @param commitOnForecastList
	 */
	public void saveCommitmentOnForecast(List<NpiWeeklyComponentCommitmentOnForecast> commitOnForecastList){
		allocatorDaoBi.saveCommitmentOnForecast(commitOnForecastList);
	}
	
	/**
	 * update order allocation results
	 * @param commitOnOrderList
	 */
	public void updateCommitmentOnOrder(List<NpiWeeklyComponentCommitmentOnOrder> commitOnOrderList){
		allocatorDaoBi.updateCommitmentOnOrder(commitOnOrderList);
	}
	
	/**
	 * update forecast allocation results
	 * @param commitOnForecastList
	 */
	public void updateCommitmentOnForecast(List<NpiWeeklyComponentCommitmentOnForecast> commitOnForecastList){
		allocatorDaoBi.updateCommitmentOnForecast(commitOnForecastList);
	}
	
	/*
	public void updateTtvWeeklyDetail(Date versionDate){
		allocatorDaoBi.updateTtvWeeklyDetail(versionDate);
	}
	
	public void updateSGATtvWeeklyDetail(Date versionDate){
		allocatorDaoBi.updateSGATtvWeeklyDetail(versionDate);
	}
	*/
	
	/**
	 * update supplyCommit in ttv weekly details
	 * @param versionDate
	 * @param commitOnOrderList
	 * @param commitOnForecastList
	 * @param ttvPhase
	 * @return
	 */
	public Map<Date, Map<Integer, Integer>> updateTtvWeeklyDetail(Date versionDate,
			List<NpiWeeklyComponentCommitmentOnOrder> commitOnOrderList, 
			List<NpiWeeklyComponentCommitmentOnForecast> commitOnForecastList, String ttvPhase){
		
		Map<Date, Map<Integer, Integer>> dateWaveCommitMap = new HashMap<Date, Map<Integer, Integer>>();
		//loop order list
		for(NpiWeeklyComponentCommitmentOnOrder commitOnOrder : commitOnOrderList){
			//no shortage
			if(0 == commitOnOrder.getMaterialShortage()){
				//TTVPhase
				if(ttvPhase.equalsIgnoreCase(commitOnOrder.getTtvPhase())){
					Date targetDate = commitOnOrder.getTargetDate();
					if(null == dateWaveCommitMap.get(targetDate)){
						dateWaveCommitMap.put(targetDate, new HashMap<Integer, Integer>());
					}
					Map<Integer, Integer> waveCommitMap = dateWaveCommitMap.get(targetDate);
					
					int pmsWaveId = commitOnOrder.getPmsWaveId();
					if(null == waveCommitMap.get(pmsWaveId)){
						waveCommitMap.put(pmsWaveId, commitOnOrder.getQuantity());
					}else{
						waveCommitMap.put(pmsWaveId, waveCommitMap.get(pmsWaveId) + commitOnOrder.getQuantity());
					}
				}
			}
		}
		
		//loop forecast list
		for(NpiWeeklyComponentCommitmentOnForecast commitOnForecast : commitOnForecastList){
			//no shortage
			if(0 == commitOnForecast.getMaterialShortage()){
				//TTVPhase
				if(ttvPhase.equalsIgnoreCase(commitOnForecast.getTtvPhase())){
					Date targetDate = commitOnForecast.getTargetDate();
					if(null == dateWaveCommitMap.get(targetDate)){
						dateWaveCommitMap.put(targetDate, new HashMap<Integer, Integer>());
					}
					Map<Integer, Integer> waveCommitMap = dateWaveCommitMap.get(targetDate);
					
					int pmsWaveId = commitOnForecast.getPmsWaveId();
					if(null == waveCommitMap.get(pmsWaveId)){
						waveCommitMap.put(pmsWaveId, commitOnForecast.getQuantity());
					}else{
						waveCommitMap.put(pmsWaveId, waveCommitMap.get(pmsWaveId) + commitOnForecast.getQuantity());
					}
				}
			}
		}
		
		allocatorDaoBi.updateTtvWeeklyDetail(versionDate, dateWaveCommitMap, ttvPhase);
		return dateWaveCommitMap;
	}
	
	/**
	 * clean old data
	 * @param versionDate
	 */
	public void cleanDataByVersionDate(Date versionDate){
		allocatorDaoBi.cleanDataByVersionDate(versionDate);
	}
	
	/**
	 * get unfulfilled order allocation results
	 * @param versionDate
	 * @param targetDate
	 * @param ttvPhase
	 * @return
	 */
	public List<NpiWeeklyComponentCommitmentOnOrder> getUnfulfilledOrder(Date versionDate, Integer pmsWaveId, String ttvPhase){
		return allocatorDaoBi.getUnfulfilledOrder(versionDate, pmsWaveId, ttvPhase);
	}
	
	/**
	 * get unfulfilled forecast allocation results
	 * @param versionDate
	 * @param targetDate
	 * @param ttvPhase
	 * @return
	 */
	public List<NpiWeeklyComponentCommitmentOnForecast> getUnfulfilledForecast(Date versionDate, Integer pmsWaveId, String ttvPhase){
		return allocatorDaoBi.getUnfulfilledForecast(versionDate, pmsWaveId, ttvPhase);
	}
	
}
