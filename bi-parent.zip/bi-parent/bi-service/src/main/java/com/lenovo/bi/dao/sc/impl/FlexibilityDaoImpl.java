package com.lenovo.bi.dao.sc.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.FlexibilityDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FlexibilityChartData;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.sc.flexibility.FlexibilityDetailGridView;
import com.lenovo.common.model.PagerInformation;

@Repository
public class FlexibilityDaoImpl extends HibernateBaseDaoImplDw implements FlexibilityDao {
 
	@SuppressWarnings("unchecked")
	@Override
	public List<FlexibilityChartData> fetchFlexibilityOverViewChartData(SearchOtsForm form) {
	
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select sum(flexibility.CWOrder) as orderQty, sum(flexibility.[60DMD]) as stockForecastQty, ")
			   .append("sum(flexibility.CWShipment) as shipmentQty, sum(flexibility.CWCommit) as commitQty")
			   .append(" from FactMonthlySummaryofFlexibility flexibility ")
		       .append(" left join DimProduct product on flexibility.ProductKey = product.ProductKey ");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where flexibility.Year*100 + flexibility.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
	    else {
	    	sBuffer.append(" where flexibility.Year = ").append(form.getYear())
	    			.append(" and flexibility.Month = ").append(form.getMonth());
	    }
		
		sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
		
		sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
		
		sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
		
		sBuffer.append(" group by product.productKey,product.productEnglishName ");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("commitQty", IntegerType.INSTANCE)
				.addScalar("shipmentQty", IntegerType.INSTANCE)
				.addScalar("orderQty", IntegerType.INSTANCE)
				.addScalar("stockForecastQty", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FlexibilityChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FlexibilityChartData> fetchDimensionRemarkDataList(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append("select SUB.ProductKey as productKey,SUB.dimensionKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(SUB.CWOrder) as orderQty,")
					.append("sum(SUB.[60DMD]) as stockForecastQty,")
					.append("sum(SUB.CWShipment) as shipmentQty,")
					.append("sum(SUB.CWCommit) as commitQty")	//mark 要改成region geo
					.append(" from (select flexibility.*, geography.regionName as dimensionName , geography.regionKey as dimensionKey ")//这里是region
			   		.append(" from FactMonthlySummaryofFlexibility flexibility ");
			sBuffer.append(" left join DimProduct product on flexibility.ProductKey = product.ProductKey")
			   		.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on flexibility.ProductKey = productFamily.ProductKey");
			
			/*if(form.isShowGeoOverview()) {//flexibility有regionKey
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as GeographyKey,region.geographykey as regionKey,geo.geographyname as GeographyName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on flexibility.regionkey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join DimGeography geoRegion on geoRegion.GeographyKey = flexibility.RegionKey");
			}*/
			sBuffer.append(" left join ( ")
					.append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
					.append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
					.append(" on  flexibility.regionKey=geography.regionKey ");
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where flexibility.Year = ").append(form.getYear())
	    			   .append(" and flexibility.Month = ").append(form.getMonth());
			}
			else{
				sBuffer.append(" where CONVERT(nvarchar(20), flexibility.Year)+'-'+CONVERT(nvarchar(20), flexibility.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
			
			sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
			
			sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:ODM or Product,点过dashboard的柱子之后
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){	//并且没有点过geo按钮
					if(!form.isShowGeoOverview()){
						sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					}else{
						sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
					}
				}
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and flexibility.ProductKey = ").append(form.getDashboardTypeKey());
				else if("Family".equals(form.getDashboardType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
				else if("Geo".equals(form.getDashboardType())){
					if(form.isShowGeoOverview()){
						sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
					}else{
						sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					}
				}
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and flexibility.ProductKey = ").append(form.getCrossMonthTypeKey());
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey());
				else if("Geo".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
			}
			
			/*if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			}*/
			
			sBuffer.append(" )SUB group by SUB.ProductKey,SUB.dimensionName,SUB.dimensionKey having SUB.dimensionName <> ''  ");
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Family".equals(form.getDimension())) {
					sBuffer.append("select SUB.productKey as productKey,SUB.familyKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(SUB.CWOrder) as orderQty,")
					.append("sum(SUB.[60DMD]) as stockForecastQty,")
					.append("sum(SUB.CWShipment) as shipmentQty,")
					.append("sum(SUB.CWCommit) as commitQty")
					.append(" from (select flexibility.*,productFamily.familyKey,productFamily.ProductFamilyEnglishName as dimensionName ")
			   		.append(" from FactMonthlySummaryofFlexibility flexibility ");
			sBuffer.append(" left join DimProduct product on flexibility.ProductKey = product.ProductKey")
			   		.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on flexibility.ProductKey = productFamily.ProductKey");
			/*if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on flexibility.regionkey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join DimGeography geography on geography.GeographyKey = flexibility.RegionKey");
			}*/
			sBuffer.append(" left join ( ")
					.append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
					.append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
					.append(" on  flexibility.regionKey=geography.regionKey ");
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where flexibility.Year = ").append(form.getYear())
					   .append(" and flexibility.Month = ").append(form.getMonth());
			}
			else{
				sBuffer.append(" where CONVERT(nvarchar(20), flexibility.Year)+'-'+CONVERT(nvarchar(20), flexibility.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
			
			sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
			
			sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:ODM or Product,点过dashboard的柱子之后
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){	//并且没有点过geo按钮
					if(!form.isShowGeoOverview()){
						sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					}else{
						sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
					}
				}
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and flexibility.ProductKey = ").append(form.getDashboardTypeKey());
				else if("Family".equals(form.getDashboardType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
				else if("Geo".equals(form.getDashboardType())){
					if(form.isShowGeoOverview()){
						sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
					}else{
						sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					}
				}
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and flexibility.ProductKey = ").append(form.getCrossMonthTypeKey());
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey());
				else if("Geo".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
			}
			
			//当你点过Region/Geo选项时,除了overview变化外,点了overview柱子后传入的条件也不一样
			/*if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
			}*/
			
			sBuffer.append(")SUB group by SUB.ProductKey, SUB.familyKey,SUB.dimensionName having SUB.dimensionName <> '' order by SUB.familyKey");
		}
		else if("Product".equals(form.getDimension())) {
					sBuffer.append("select SUB.ProductKey as productKey,SUB.ProductKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(SUB.CWOrder) as orderQty,")
					.append("sum(SUB.[60DMD]) as stockForecastQty,")
					.append("sum(SUB.CWShipment) as shipmentQty,")
					.append("sum(SUB.CWCommit) as commitQty")
					.append(" from (select flexibility.*,product.ProductEnglishName as dimensionName ")
			   		.append(" from FactMonthlySummaryofFlexibility flexibility ");
			sBuffer.append(" left join DimProduct product on flexibility.ProductKey = product.ProductKey")
			   		.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on flexibility.ProductKey = productFamily.ProductKey");
			/*if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on flexibility.regionkey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join DimGeography geography on geography.GeographyKey = flexibility.RegionKey");
			}*/
			
			sBuffer.append(" left join ( ")
					.append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
					.append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
					.append(" on  flexibility.regionKey=geography.regionKey ");
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where flexibility.Year = ").append(form.getYear())
					   .append(" and flexibility.Month = ").append(form.getMonth());
			}
			else{
				sBuffer.append(" where CONVERT(nvarchar(20), flexibility.Year)+'-'+CONVERT(nvarchar(20), flexibility.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
			
			sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
			
			sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:ODM or Product,点过dashboard的柱子之后
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){	//并且没有点过geo按钮
					if(!form.isShowGeoOverview()){
						sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					}else{
						sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
					}
				}
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and flexibility.ProductKey = ").append(form.getDashboardTypeKey());
				else if("Family".equals(form.getDashboardType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
				else if("Geo".equals(form.getDashboardType())){
					if(form.isShowGeoOverview()){
						sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
					}else{
						sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					}
				}
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and flexibility.ProductKey = ").append(form.getCrossMonthTypeKey());
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey());
				else if("Geo".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
			}
			
			/*if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
			}*/
			
			sBuffer.append(")SUB group by SUB.ProductKey,SUB.dimensionName having SUB.dimensionName <> '' order by SUB.ProductKey");
		}
		else if("Geo".equals(form.getDimension())) {
			sBuffer.append("select SUB.ProductKey as productKey,'-2' as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(SUB.CWOrder) as orderQty,")
					.append("sum(SUB.[60DMD]) as stockForecastQty,")
					.append("sum(SUB.CWShipment) as shipmentQty,")
					.append("sum(SUB.CWCommit) as commitQty")
					.append(" from (select flexibility.*,geography.geoName as dimensionName ")
	   		.append(" from FactMonthlySummaryofFlexibility flexibility ");
			sBuffer.append(" left join DimProduct product on flexibility.ProductKey = product.ProductKey")
					.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on flexibility.ProductKey = productFamily.ProductKey");
			//if(form.isShowGeoOverview()) {//flexibility有regionKey
			sBuffer.append(" left join ( ")
						.append(" select region.geographyname as regionName,region.GeographyKey ,geography.NormalizedGeo as geoName from DimGeography region ")
				   		.append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
				   		.append(" on  flexibility.regionKey=geography.GeographyKey ");
						/*.append("(")
						.append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
						.append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
						.append(")")
						.append(" as geoRegion on flexibility.regionkey = geoRegion.regionKey");*/
		
//			}
//			else {
//				sBuffer.append(" left join DimGeography geography on geography.GeographyKey = flexibility.RegionKey");
//			}
	
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where flexibility.Year = ").append(form.getYear())
						.append(" and flexibility.Month = ").append(form.getMonth());
			}
			else{
				sBuffer.append(" where CONVERT(nvarchar(20), flexibility.Year)+'-'+CONVERT(nvarchar(20), flexibility.Month) between '")
						.append(form.getStartDate()).append("'")
						.append(" and '").append(form.getEndDate()).append("'");
			}
	
			sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
			
			sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
			
			sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
			}
	
			//dashboard overview chart:ODM or Product,点过dashboard的柱子之后
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){	//并且没有点过geo按钮
					if(!form.isShowGeoOverview()){
						sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					}else{
						sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
					}
				}
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and flexibility.ProductKey = ").append(form.getDashboardTypeKey());
				else if("Family".equals(form.getDashboardType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
				else if("Geo".equals(form.getDashboardType())){
					if(form.isShowGeoOverview()){
						sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
					}else{
						sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					}
				}
			}
	
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and flexibility.ProductKey = ").append(form.getCrossMonthTypeKey());
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey());
				else if("Geo".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
			}
	
			/*if(form.isShowGeoOverview()) {//geography.geoName
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			}*/
	
				sBuffer.append(" )SUB group by SUB.ProductKey,SUB.dimensionName having SUB.dimensionName <> ''  ");
			}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
								.addScalar("productKey", IntegerType.INSTANCE)
								.addScalar("dimensionKey", IntegerType.INSTANCE)
								.addScalar("dimensionName", StringType.INSTANCE)
								.addScalar("commitQty", IntegerType.INSTANCE)
								.addScalar("shipmentQty", IntegerType.INSTANCE)
								.addScalar("orderQty", IntegerType.INSTANCE)
								.addScalar("stockForecastQty", IntegerType.INSTANCE)
								.setResultTransformer(Transformers.aliasToBean(FlexibilityChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FlexibilityChartData> fetchFlexibilityRemarkChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		
		if("Region".equals(form.getDimension())) {
			sBuffer.append("select fa.RegionKey as subDimensionKey,geography.GeographyName as subDimesnionName,sum(fa.OrderQty) as orderQty,")
				.append("sum(fa.[60DaysForecastQty]) as stockForecastQty, sum(fa.ShipQty) as shipmentQty, sum(fa.CommitQty) as commitQty")
			    .append(" from FactMonthlySummaryofProductFA fa")
			    .append(" left join ")
			    .append(" DimTime dt on fa.TargetDateKey = dt.TimeKey")
			    .append(" left join DimGeography geography on fa.RegionKey = geography.GeographyKey");
	
			sBuffer.append(" where SUBSTRING(CONVERT(nvarchar(20), dt.FullDateAlternateKey),1,7) = '")
		   		.append(form.getSelectMonth()).append("'")
		   		.append(" group by fa.RegionKey,geography.GeographyName");
		}
		else if("Family".equals(form.getDimension())) {
			sBuffer.append("select productFamily.familyKey as subDimensionKey,productFamily.familyName as subDimesnionName,sum(fa.OrderQty) as orderQty,")
				.append("sum(fa.[60DaysForecastQty]) as stockForecastQty, sum(fa.ShipQty) as shipmentQty, sum(fa.CommitQty) as commitQty")
			    .append(" from FactMonthlySummaryofProductFA fa")
			    .append(" left join ")
			    .append(" DimTime dt on fa.TargetDateKey = dt.TimeKey")
			    .append(" left join (")
			    .append(" select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName as familyName")
			    .append(" from DimProduct product join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			    .append(")productFamily on fa.ProductKey = productFamily.ProductKey");
	
			sBuffer.append(" where SUBSTRING(CONVERT(nvarchar(20), dt.FullDateAlternateKey),1,7) = '")
		   		.append(form.getSelectMonth()).append("'")
		   		.append(" group by productFamily.familyKey,productFamily.familyName having productFamily.familyKey != ''");
		}
		if("Product".equals(form.getDimension())) {
			sBuffer.append("select fa.ProductKey as subDimensionKey,product.ProductEnglishName as subDimesnionName,sum(fa.OrderQty) as orderQty,")
				.append("sum(fa.[60DaysForecastQty]) as stockForecastQty, sum(fa.ShipQty) as shipmentQty, sum(fa.CommitQty) as commitQty")
			    .append(" from FactMonthlySummaryofProductFA fa")
			    .append(" left join ")
			    .append(" DimTime dt on fa.TargetDateKey = dt.TimeKey")
			    .append(" left join DimProduct product on fa.ProductKey = product.ProductKey ");
	
			sBuffer.append(" where SUBSTRING(CONVERT(nvarchar(20), dt.FullDateAlternateKey),1,7) = '")
		   		.append(form.getSelectMonth()).append("'")
		   		.append(" group by fa.ProductKey,product.ProductEnglishName");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("commitQty", IntegerType.INSTANCE)
				.addScalar("shipmentQty", IntegerType.INSTANCE)
				.addScalar("orderQty", IntegerType.INSTANCE)
				.addScalar("stockForecastQty", IntegerType.INSTANCE)
				.addScalar("stockForecastQty", IntegerType.INSTANCE)
				.addScalar("subDimensionKey", IntegerType.INSTANCE)
				.addScalar("subDimesnionName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FlexibilityChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FlexibilityChartData> fetchFlexibilityCrossMonthOverviewChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(flexibility.CWOrder) as orderQty, sum(flexibility.[60DMD]) as stockForecastQty, ")
				.append("sum(flexibility.CWShipment) as shipmentQty, sum(flexibility.CWCommit) as commitQty")
				.append(" from FactMonthlySummaryofFlexibility flexibility");
		sBuffer.append(" left join DimProduct product on flexibility.ProductKey = product.ProductKey")
		   		.append(" left join (")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on flexibility.ProductKey = productFamily.ProductKey");
		sBuffer.append(" left join ( ")
				.append(" select region.geographyname as regionName,region.GeographyKey ,geography.NormalizedGeo as geoName from DimGeography region ")
				.append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
				.append(" on  flexibility.regionKey=geography.GeographyKey ");
		//quarter
		if(form.isShowQuarterOverview()) {
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where flexibility.Year*100 + flexibility.Month between '")
			   .append(form.getQuarterFrom()).append("'")
			   .append(" and '").append(form.getQuarterTo()).append("'");
		}
		//month
		else {
	    	sBuffer.append(" where flexibility.Year = ").append(form.getYear())
	    		.append(" and flexibility.Month = ").append(form.getMonth());
		}
		
		sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
		
		sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
		
		sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		
		if("Product".equals(form.getDimension())) {
			sBuffer.append(" and flexibility.ProductKey = ").append(form.getSubDimensionKey());
		}
			
		if("Family".equals(form.getDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getSubDimensionKey());
		}
			
		if("Region".equals(form.getDimension())) {
			//要改成regionName
			sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
		}
		
		if("Geo".equals(form.getDimension())) {
			//要改成regionName
			sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
		}
		
		sBuffer.append(" group by product.productKey,product.productEnglishName ");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("commitQty", IntegerType.INSTANCE)
				.addScalar("shipmentQty", IntegerType.INSTANCE)
				.addScalar("orderQty", IntegerType.INSTANCE)
				.addScalar("stockForecastQty", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FlexibilityChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchDimensions(SearchOtsForm form) {
		form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
		form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		PagerInformation pagerInfo = form.getPagerInfo();
		StringBuffer sBuffer = new StringBuffer();
		
		//for Family overview chart
		if("Family".equals(form.getDashboardType())) {
			sBuffer.append("select family.ProductFamilyKey as objKey,family.ProductFamilyEnglishName as objName,'Family' as type");
			
			sBuffer.append(" from FactMonthlySummaryofFlexibility flexibility");
			sBuffer.append(" left join DimProduct product on product.ProductKey = flexibility.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			
			sBuffer.append(" where flexibility.Year * 100 + flexibility.Month between ").append(form.getStartDate().replace("-", ""))
					.append(" and  ").append(form.getEndDate().replace("-", ""));
	    	
			sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
			
			sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
			
			sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
			
	    	if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				if(!form.isShowSalesOverview()){
					sBuffer.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
				}
			}
			
			sBuffer.append(" group by family.ProductFamilyKey,family.ProductFamilyEnglishName having family.ProductFamilyKey <> ''");
			sBuffer.append(" order by sum(flexibility.CWOrder) desc");
		}
		//for Region overview chart
		else if("Region".equals(form.getDashboardType())) {
			if(!form.isShowGeoOverview()) {
				 sBuffer.append("select  -2 as objKey,geography.regionName as objName,'Region' as type");
			}
			else {
				sBuffer.append("select -2 as objKey,geography.geoName as objName,'Geo' as type");
			}
			
			sBuffer.append(" from FactMonthlySummaryofFlexibility flexibility");
			
			sBuffer.append(" left join DimProduct product on product.ProductKey = flexibility.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			
			/*sBuffer.append(" left join DimGeography geography on flexibility.RegionKey = geography.GeographyKey");
			
			if(form.isShowGeoOverview()){
				sBuffer.append(" left join DimGeography parentGeography on parentGeography.GeographyKey = geography.parentGeographyKey");
			}*/
			
			/*sBuffer.append(" left join DimGeography geography on  flexibility.regionKey=geography.GeographyKey and geography.GeographyType='Region' ");
			sBuffer.append(" left join FactGeoListMapping geo on geography.geographyname=geo.NormalizedSubgeo ");*/
			
			sBuffer.append(" left join ( ")
					.append(" select region.geographyname as regionName,region.GeographyKey ,geography.NormalizedGeo as geoName from DimGeography region ")
					.append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
					.append(" on  flexibility.regionKey=geography.GeographyKey ");
			
	    	sBuffer.append(" where flexibility.Year * 100 + flexibility.Month between ").append(form.getStartDate().replace("-", ""))
	    			.append(" and  ").append(form.getEndDate().replace("-", ""));
	    	
	    	sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
			
			sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
			
			sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
	    	
	    	if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//show geo or region overview 
			if(!form.isShowGeoOverview()) {
				sBuffer.append(" group by geography.regionName ");//,flexibility.RegionKey having flexibility.RegionKey <> ''
			}
			else{
				sBuffer.append(" group by geography.geoName having geography.geoName <> '' ");
			}
			
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append("select product.ProductKey as objKey,product.ProductEnglishName as objName,'Product' as type");
			
			sBuffer.append(" from FactMonthlySummaryofFlexibility flexibility");
			sBuffer.append(" left join DimProduct product on product.ProductKey = flexibility.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			
			sBuffer.append(" where flexibility.Year * 100 + flexibility.Month between ").append(form.getStartDate().replace("-", ""))
					.append(" and  ").append(form.getEndDate().replace("-", ""));
	    	
			sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
			
			sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
			
			sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
			
	    	if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			sBuffer.append(" group by product.ProductKey,product.ProductEnglishName having product.ProductKey <> ''");
		}
		//for Geo overview chart
		else if("Geo".equals(form.getDashboardType())){
			if(!form.isShowGeoOverview()) {
				sBuffer.append("select  -2 as objKey,geography.regionName as objName,'Region' as type");
			}
			else {
				sBuffer.append("select -2 as objKey,geography.geoName as objName,'Geo' as type");
			}
			
			sBuffer.append(" from FactMonthlySummaryofFlexibility flexibility ");
			sBuffer.append(" left join DimProduct product on product.ProductKey = flexibility.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" left join  ( ");
					sBuffer.append(" select region.geographyname as regionName,region.GeographyKey as regionKey,geography.NormalizedGeo as geoName ");
					sBuffer.append(" from DimGeography region ");
					sBuffer.append(" left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo ");
					sBuffer.append(" where region.GeographyType='Region'  ");
			sBuffer.append(" ) as geography on flexibility.regionkey = geography.regionKey ");	
			sBuffer.append(" where flexibility.Year * 100 + flexibility.Month between ").append(form.getStartDate().replace("-", ""))
				   .append(" and  ").append(form.getEndDate().replace("-", ""));
			
			sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
			
			sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
			
			sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
			
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//show geo or region overview 
			if(!form.isShowGeoOverview()) {
				sBuffer.append(" group by geography.regionName ");//,flexibility.RegionKey having flexibility.RegionKey <> ''
			}
			else{
				sBuffer.append(" group by geography.geoName having geography.geoName <> '' ");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FlexibilityChartData> fetchFlexibilityDashboardOverViewChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select sum(flexibility.CWOrder) as orderQty, sum(flexibility.[60DMD]) as stockForecastQty, ")
				.append("sum(flexibility.CWShipment) as shipmentQty, sum(flexibility.CWCommit) as commitQty")
				.append(" from FactMonthlySummaryofFlexibility flexibility");
		sBuffer.append(" left join DimProduct product on flexibility.ProductKey = product.ProductKey")
		   		.append(" left join (")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on flexibility.ProductKey = productFamily.ProductKey");
		
		/*if(form.isShowGeoOverview()) {
			sBuffer.append(" left join  ( ");
			sBuffer.append(" select region.geographyname as regionName,region.GeographyKey as regionKey,geography.NormalizedGeo as geoName ");
			sBuffer.append(" from DimGeography region ");
			sBuffer.append(" left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo ");
			sBuffer.append(" where region.GeographyType='Region'  ");
			sBuffer.append(" ) as geoRegion on flexibility.regionkey = geoRegion.regionKey ");	
		}
		else {
			sBuffer.append(" left join DimGeography geography on geography.GeographyKey = flexibility.RegionKey");
		}*/
		sBuffer.append(" left join ( ")
				.append(" select region.geographyname as regionName,region.GeographyKey ,geography.NormalizedGeo as geoName from DimGeography region ")
				.append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
				.append(" on  flexibility.regionKey=geography.GeographyKey ");
		
		//quarter
		if(form.isShowQuarterOverview()) {
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
	    	sBuffer.append(" where flexibility.Year*100 + flexibility.Month between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
		}
		//month
		else {
	    	sBuffer.append(" where flexibility.Year = ").append(form.getYear())
	    		.append(" and flexibility.Month = ").append(form.getMonth());
		}
		
		//代表这是geo 还是 regionDashboard
		if("Geo".equals(form.getDimension())){
			if(form.isShowGeoOverview()){
				sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
			}else{
				sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
			}
		}else if("Region".equals(form.getDimension())){
			if(form.isShowGeoOverview()){
				sBuffer.append(" and geography.geoName = '").append(form.getSubDimension()+"'");
			}else{
				sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
			}
		}else if("Product".equals(form.getDimension())){
			sBuffer.append(" and flexibility.ProductKey = ").append(form.getSubDimensionKey());
		}else if("Family".equals(form.getDimension())){
			sBuffer.append(" and productFamily.familyKey = ").append(form.getSubDimensionKey());
		}
		
		
		/*//for Family dashboard overview chart
		if("Family".equals(form.getDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getSubDimensionKey());
		}
		//for Region overview chart
		else if("Region".equals(form.getDimension())) {
			if(form.isShowGeoOverview()){
				sBuffer.append(" and geoRegion.geoName = '").append(form.getSubDimension()+"'");
			}
			else{
				sBuffer.append(" and flexibility.RegionKey = ").append(form.getSubDimensionKey());
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and flexibility.ProductKey = ").append(form.getSubDimensionKey());
		}*/
			
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sBuffer.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		
		sBuffer.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
		
		sBuffer.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
		
		sBuffer.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
		
		sBuffer.append(" group by product.productKey,product.productEnglishName ");
		
		/*if(StringUtils.isNotBlank(form.getSortColumn())){
			if("rootCause".equalsIgnoreCase(form.getSortColumn())){
				sBuffer.append(" order by ").append("(case when ltfc.["+ltfcVersion+"DaysLTFCQty] > ltfc.OrderQty then 'over plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] = ltfc.OrderQty then 'equal plan' when ltfc.["+ltfcVersion+"DaysLTFCQty] < ltfc.OrderQty then 'under plan' else '' end)").append(form.getSortType());
			}else if("ltfcVsOrder".equalsIgnoreCase(form.getSortColumn())){
				sBuffer.append(" order by ").append("cast (100*ltfc.["+ltfcVersion+"DaysLTFCQty]/cast (ltfc.OrderQty as NUMERIC(15,2))as NUMERIC(15,2)) ").append(form.getSortType());
			}else{
				sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType());
			}
		}*/
		
		
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("commitQty", IntegerType.INSTANCE)
				.addScalar("shipmentQty", IntegerType.INSTANCE)
				.addScalar("orderQty", IntegerType.INSTANCE)
				.addScalar("stockForecastQty", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FlexibilityChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FlexibilityDetailGridView> fetchFlexibilityDetail(SearchOtsForm form) {
		StringBuffer sb = new StringBuffer();
		
		sb.append(" select * from ( select ");
		
		if("Family".equals(form.getRemarkDimension())||"Product".equals(form.getRemarkDimension())){
			sb.append("isNull(family.ProductFamilyEnglishName,'Unknown') as Family,");
		}
		
		if("Region".equals(form.getRemarkDimension())){
			sb.append(" isNull(geography.geoName,'Unknown') as Geo,")
			  .append("isNull(geography.regionName,'Unknown') as Region,");
		}
		
		if("Geo".equals(form.getRemarkDimension())){
			sb.append(" isNull(geography.geoName,'Unknown') as Geo,");
		}
		
		
		sb.append("isNull(product.ProductEnglishName,'Unknown') as Product,")
			.append("sum(flexibility.CWShipment) as shipment,")
			.append("sum(flexibility.CWOrder) as cwOrder,")
			.append("sum(flexibility.CWCommit) as cwCommit,")
			.append("sum(flexibility.[60DMD]) as stockForecastQty");
		
		/*if(!form.isShowQuarterOverview()){
			sb.append(" ,flexibility.year as Year,flexibility.month as Month ");
		}*/
		
		sb.append(" from FactMonthlySummaryofFlexibility flexibility");
		
		sb.append(" left join ( ")
		  .append(" select region.geographyname as regionName,region.GeographyKey ,geography.NormalizedGeo as geoName from DimGeography region ")
   		  .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
   		  .append(" on  flexibility.regionKey=geography.GeographyKey ");
		
		sb.append(" left join DimProduct product on product.ProductKey = flexibility.ProductKey");
		sb.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
		
		sb.append(" where flexibility.year*100 + flexibility.month between ")
			.append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			.append("  and  ")
			.append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		
		sb.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
		
		sb.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
		
		sb.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sb.append(" and product.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		
		//for Region overview chart,点过柱子没
		if("Region".equals(form.getOverViewDimension())) {
			if("dashboard".equals(form.getChartType())){
				if(form.getOverViewSubDimensionKey() != -1) {
					if(form.isShowGeoOverview())//geo overview
						sb.append(" and geography.geoName = '").append(form.getOverViewSubDimension()+"'");
					else 
						//OverViewSubDimensionKey是要换成名字了. and flexibility.RegionKey =
						sb.append(" and geography.regionName = '").append(form.getOverViewSubDimension()+"' ");
				}
			}else{
				sb.append(" and geography.regionName = '").append(form.getOverViewSubDimension()+"' ");
			}
			
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sb.append(" and product.ProductFamilyKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sb.append(" and flexibility.ProductKey = ").append(form.getOverViewSubDimensionKey());
		}
		else if("Geo".equals(form.getOverViewDimension())){	//在Dashboard才会区分isShowGeoOverview
			if("dashboard".equals(form.getChartType())){
				if(form.getOverViewSubDimensionKey() != -1){
					if(form.isShowGeoOverview())//geo overview
						sb.append(" and geography.geoName = '").append(form.getOverViewSubDimension()+"'");
					else 
						//OverViewSubDimensionKey是要换成名字了. and flexibility.RegionKey =
						sb.append(" and geography.regionName = '").append(form.getOverViewSubDimension()+"' ");
				}
			}else{
				sb.append(" and geography.geoName = '").append(form.getOverViewSubDimension()+"'");
			}
		}
		
		//remark dimesion 
		if("Region".equalsIgnoreCase(form.getRemarkDimension())){
			sb.append(" and geography.regionName ='").append(form.getRemarkSubDimensionKeys()+"'");
		}
		
		if("Product".equalsIgnoreCase(form.getRemarkDimension())){
			//原来overview 情况下 sb.append(" and product.ProductEnglishName = '").append(form.getRemarkSubDimensionKeys()+"' ");
			sb.append(" and product.ProductKey = '").append(form.getRemarkSubDimensionKeys()+"' ");
		}
		
		if("Family".equalsIgnoreCase(form.getRemarkDimension())){
			//原来用的是name sb.append(" and family.ProductFamilyEnglishName = '").append(form.getRemarkSubDimensionKeys()+"' ");
			sb.append(" and family.ProductFamilyKey = '").append(form.getRemarkSubDimensionKeys()+"' ");
		}
		
		if("Geo".equalsIgnoreCase(form.getRemarkDimension())){
			sb.append(" and geography.geoName = '").append(form.getRemarkSubDimensionKeys()+"' ");
		}
		
		sb.append(" group by product.ProductKey,product.ProductEnglishName ");
		
		if("Family".equals(form.getRemarkDimension())||"Product".equals(form.getRemarkDimension())){
			sb.append(" ,family.ProductFamilyKey,family.ProductFamilyEnglishName ");
		}
		
		if("Region".equals(form.getRemarkDimension())){
			sb.append(" ,geography.geoName,geography.regionName ");
		}
		
		if("Geo".equals(form.getRemarkDimension())){
			sb.append(" ,geography.geoName ");
		}
		
		/*if(!form.isShowQuarterOverview()){
			sb.append(" ,flexibility.year,flexibility.month ");
		}*/
		
		sb.append(" ) a ");
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			if(form.getSortColumn().equals("Flexibility")
					||form.getSortColumn().equals("A")
					||form.getSortColumn().equals("B")
					||form.getSortColumn().equals("C")){
				
			}else{
				sb.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType());
			}
		}
		
		SQLQuery query = getSession().createSQLQuery(sb.toString());
		
		if("Family".equals(form.getRemarkDimension())||"Product".equals(form.getRemarkDimension())){
			query.addScalar("Family", StringType.INSTANCE);
		}
		
		if("Region".equals(form.getRemarkDimension())){
			query.addScalar("Geo", StringType.INSTANCE);
			query.addScalar("Region", StringType.INSTANCE);
		}
		
		if("Geo".equals(form.getRemarkDimension())){
			query.addScalar("Geo", StringType.INSTANCE);
		}
		
			query.addScalar("Product", StringType.INSTANCE)
				.addScalar("shipment", IntegerType.INSTANCE)
				.addScalar("cwOrder", IntegerType.INSTANCE)
				.addScalar("cwCommit", IntegerType.INSTANCE)
				.addScalar("stockForecastQty", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FlexibilityDetailGridView.class));
		
		/*query.setFirstResult((form.getCurrentPage()-1)*SysConfig.NUMBER_OF_ROW_COUNT);
		query.setMaxResults(SysConfig.NUMBER_OF_ROW_COUNT);*/
		
		return query.list();
	}
	
	@Override
	public List<KeyNameObject> fetchComponents(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
	    sBuffer.append("select productFamily.familyKey as objKey,productFamily.familyName as objName,'Component' as type")
	    		.append(" from FactMonthlySummaryofProductFA fa ")
	    		.append(" left join ")
	    		.append(" DimTime dt on fa.TargetDateKey = dt.TimeKey")
	    		.append(" left join (")
	    		.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName as familyName from DimProduct product")
	    		.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
	    		.append(")productFamily on fa.ProductKey = productFamily.ProductKey");
	
	    sBuffer.append(" where SUBSTRING(CONVERT(nvarchar(20), dt.FullDateAlternateKey),1,7) = '")
				.append(form.getSelectMonth()).append("'");
		
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
		}
		
		sBuffer.append(" group by productFamily.familyKey,productFamily.familyName having productFamily.familyKey != ''");
		
		sBuffer.append(" order by sum(fa.OrderQty) desc");
		
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}

	@Override
	public List<FlexibilityChartData> fetchComponentOverViewChartData(
			SearchOtsForm form) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<FlexibilityChartData> fetchComponentRemarkChartData(
			SearchOtsForm form) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public Integer calFlexibility(Integer A,Integer B,Integer C,Integer D,Integer stockForecast) {
		Integer flexibility = 0;
		
		if(stockForecast == 0) {
			if(A == 0)
				flexibility = 0;
			else if(A > 0)
				flexibility = 1;
			/*else if(A < 0)
				break;*/
		}
		if(A < stockForecast) {
			if(C >= 1)
				flexibility = 1;
			else if(C <= 0)
				flexibility = 0;
			else
				flexibility = C;
		}
		else {
			if(B >= 1)
				flexibility = 1;
			else if(B <= 0)
				flexibility = 0;
			else 
				flexibility = B;
		}
		
		return flexibility;
	}

	@Override
	public int fetchFlexibilityDetailCount(SearchOtsForm form) {
		StringBuffer sb = new StringBuffer();
		
		sb.append(" select count(*) from ( select ");
		
		if("Family".equals(form.getRemarkDimension())||"Product".equals(form.getRemarkDimension())){
			sb.append("isNull(family.ProductFamilyEnglishName,'Unknown') as Family,");
		}
		
		if("Region".equals(form.getRemarkDimension())){
			sb.append(" isNull(geography.geoName,'Unknown') as Geo,")
			  .append("isNull(geography.regionName,'Unknown') as Region,");
		}
		
		if("Geo".equals(form.getRemarkDimension())){
			sb.append(" isNull(geography.geoName,'Unknown') as Geo,");
		}
		
		
		sb.append("isNull(product.ProductEnglishName,'Unknown') as Product,")
			.append("sum(flexibility.CWShipment) as shipment,")
			.append("sum(flexibility.CWOrder) as cwOrder,")
			.append("sum(flexibility.CWCommit) as cwCommit,")
			.append("sum(flexibility.[60DMD]) as stockForecastQty");
		
		/*if(!form.isShowQuarterOverview()){
			sb.append(" ,flexibility.year as Year,flexibility.month as Month ");
		}*/
		
		sb.append(" from FactMonthlySummaryofFlexibility flexibility");
		
		sb.append(" left join ( ")
		  .append(" select region.geographyname as regionName,region.GeographyKey ,geography.NormalizedGeo as geoName from DimGeography region ")
   		  .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
   		  .append(" on  flexibility.regionKey=geography.GeographyKey ");
		
		sb.append(" left join DimProduct product on product.ProductKey = flexibility.ProductKey");
		sb.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
		
		sb.append(" where flexibility.year*100 + flexibility.month between ")
			.append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			.append("  and  ")
			.append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		
		sb.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
		
		sb.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
		
		sb.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sb.append(" and product.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		
		//for Region overview chart,点过柱子没
		if("Region".equals(form.getOverViewDimension())) {
			if("dashboard".equals(form.getChartType())){
				if(form.getOverViewSubDimensionKey() != -1) {
					if(form.isShowGeoOverview())//geo overview
						sb.append(" and geography.geoName = '").append(form.getOverViewSubDimension()+"'");
					else 
						//OverViewSubDimensionKey是要换成名字了. and flexibility.RegionKey =
						sb.append(" and geography.regionName = '").append(form.getOverViewSubDimension()+"' ");
				}
			}else{
				sb.append(" and geography.regionName = '").append(form.getOverViewSubDimension()+"' ");
			}
			
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sb.append(" and product.ProductFamilyKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sb.append(" and flexibility.ProductKey = ").append(form.getOverViewSubDimensionKey());
		}
		else if("Geo".equals(form.getOverViewDimension())){	//在Dashboard才会区分isShowGeoOverview
			if("dashboard".equals(form.getChartType())){
				if(form.getOverViewSubDimensionKey() != -1){
					if(form.isShowGeoOverview())//geo overview
						sb.append(" and geography.geoName = '").append(form.getOverViewSubDimension()+"'");
					else 
						//OverViewSubDimensionKey是要换成名字了. and flexibility.RegionKey =
						sb.append(" and geography.regionName = '").append(form.getOverViewSubDimension()+"' ");
				}
			}else{
				sb.append(" and geography.geoName = '").append(form.getOverViewSubDimension()+"'");
			}
		}
		
		//remark dimesion 
		if("Region".equalsIgnoreCase(form.getRemarkDimension())){
			sb.append(" and geography.regionName ='").append(form.getRemarkSubDimensionKeys()+"'");
		}
		
		if("Product".equalsIgnoreCase(form.getRemarkDimension())){
			//原来overview 情况下 sb.append(" and product.ProductEnglishName = '").append(form.getRemarkSubDimensionKeys()+"' ");
			sb.append(" and product.ProductKey = '").append(form.getRemarkSubDimensionKeys()+"' ");
		}
		
		if("Family".equalsIgnoreCase(form.getRemarkDimension())){
			//原来用的是name sb.append(" and family.ProductFamilyEnglishName = '").append(form.getRemarkSubDimensionKeys()+"' ");
			sb.append(" and family.ProductFamilyKey = '").append(form.getRemarkSubDimensionKeys()+"' ");
		}
		
		if("Geo".equalsIgnoreCase(form.getRemarkDimension())){
			sb.append(" and geography.geoName = '").append(form.getRemarkSubDimensionKeys()+"' ");
		}
		
		sb.append(" group by product.ProductKey,product.ProductEnglishName ");
		
		if("Family".equals(form.getRemarkDimension())||"Product".equals(form.getRemarkDimension())){
			sb.append(" ,family.ProductFamilyKey,family.ProductFamilyEnglishName ");
		}
		
		if("Region".equals(form.getRemarkDimension())){
			sb.append(" ,geography.geoName,geography.regionName ");
		}
		
		if("Geo".equals(form.getRemarkDimension())){
			sb.append(" ,geography.geoName ");
		}
		
		/*if(!form.isShowQuarterOverview()){
			sb.append(" ,flexibility.year,flexibility.month ");
		}*/
		
		sb.append(" ) a ");
		
		Query query = getSession().createSQLQuery(sb.toString());
		
		return (Integer) query.uniqueResult();
	}

	@Override
	public List<FlexibilityDetailGridView> fetchFlexibilityDetailForExcel(
			SearchOtsForm form) {
		StringBuffer sb = new StringBuffer();
		
		sb.append(" select * from ( select ");
		
		if("Family".equals(form.getRemarkDimension())||"Product".equals(form.getRemarkDimension())){
			sb.append("isNull(family.ProductFamilyEnglishName,'Unknown') as Family,");
		}
		
		if("Region".equals(form.getRemarkDimension())){
			sb.append(" isNull(geography.geoName,'Unknown') as Geo,")
			  .append("isNull(geography.regionName,'Unknown') as Region,");
		}
		
		if("Geo".equals(form.getRemarkDimension())){
			sb.append(" isNull(geography.geoName,'Unknown') as Geo,");
		}
		
		
		sb.append("isNull(product.ProductEnglishName,'Unknown') as Product,")
			.append("sum(flexibility.CWShipment) as shipment,")
			.append("sum(flexibility.CWOrder) as cwOrder,")
			.append("sum(flexibility.CWCommit) as cwCommit,")
			.append("sum(flexibility.[60DMD]) as stockForecastQty");
		
		/*if(!form.isShowQuarterOverview()){
			sb.append(" ,flexibility.year as Year,flexibility.month as Month ");
		}*/
		
		sb.append(" from FactMonthlySummaryofFlexibility flexibility");
		
		sb.append(" left join ( ")
		  .append(" select region.geographyname as regionName,region.GeographyKey ,geography.NormalizedGeo as geoName from DimGeography region ")
   		  .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
   		  .append(" on  flexibility.regionKey=geography.GeographyKey ");
		
		sb.append(" left join DimProduct product on product.ProductKey = flexibility.ProductKey");
		sb.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
		
		sb.append(" where flexibility.year*100 + flexibility.month between ")
			.append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			.append("  and  ")
			.append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		
		sb.append(" and (flexibility.isEOL is null or flexibility.isEOL=0) ");
		
		sb.append(" and (flexibility.IsNew is null or flexibility.IsNew=0) ");
		
		sb.append(" and flexibility.VersionDate=(select max(VersionDate) from FactMonthlySummaryofFlexibility flexibilityb) ");
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and flexibility.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and flexibility.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sb.append(" and product.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		
		//for Region overview chart,点过柱子没
		if("Region".equals(form.getOverViewDimension())) {
			if("dashboard".equals(form.getChartType())){
				if(form.getOverViewSubDimensionKey() != -1) {
					if(form.isShowGeoOverview())//geo overview
						sb.append(" and geography.geoName = '").append(form.getOverViewSubDimension()+"'");
					else 
						//OverViewSubDimensionKey是要换成名字了. and flexibility.RegionKey =
						sb.append(" and geography.regionName = '").append(form.getOverViewSubDimension()+"' ");
				}
			}else{
				sb.append(" and geography.regionName = '").append(form.getOverViewSubDimension()+"' ");
			}
			
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sb.append(" and product.ProductFamilyKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sb.append(" and flexibility.ProductKey = ").append(form.getOverViewSubDimensionKey());
		}
		else if("Geo".equals(form.getOverViewDimension())){	//在Dashboard才会区分isShowGeoOverview
			if("dashboard".equals(form.getChartType())){
				if(form.getOverViewSubDimensionKey() != -1){
					if(form.isShowGeoOverview())//geo overview
						sb.append(" and geography.geoName = '").append(form.getOverViewSubDimension()+"'");
					else 
						//OverViewSubDimensionKey是要换成名字了. and flexibility.RegionKey =
						sb.append(" and geography.regionName = '").append(form.getOverViewSubDimension()+"' ");
				}
			}else{
				sb.append(" and geography.geoName = '").append(form.getOverViewSubDimension()+"'");
			}
		}
		
		//remark dimesion 
		if("Region".equalsIgnoreCase(form.getRemarkDimension())){
			sb.append(" and geography.regionName ='").append(form.getRemarkSubDimensionKeys()+"'");
		}
		
		if("Product".equalsIgnoreCase(form.getRemarkDimension())){
			//原来overview 情况下 sb.append(" and product.ProductEnglishName = '").append(form.getRemarkSubDimensionKeys()+"' ");
			sb.append(" and product.ProductKey = '").append(form.getRemarkSubDimensionKeys()+"' ");
		}
		
		if("Family".equalsIgnoreCase(form.getRemarkDimension())){
			//原来用的是name sb.append(" and family.ProductFamilyEnglishName = '").append(form.getRemarkSubDimensionKeys()+"' ");
			sb.append(" and family.ProductFamilyKey = '").append(form.getRemarkSubDimensionKeys()+"' ");
		}
		
		if("Geo".equalsIgnoreCase(form.getRemarkDimension())){
			sb.append(" and geography.geoName = '").append(form.getRemarkSubDimensionKeys()+"' ");
		}
		
		sb.append(" group by product.ProductKey,product.ProductEnglishName ");
		
		if("Family".equals(form.getRemarkDimension())||"Product".equals(form.getRemarkDimension())){
			sb.append(" ,family.ProductFamilyKey,family.ProductFamilyEnglishName ");
		}
		
		if("Region".equals(form.getRemarkDimension())){
			sb.append(" ,geography.geoName,geography.regionName ");
		}
		
		if("Geo".equals(form.getRemarkDimension())){
			sb.append(" ,geography.geoName ");
		}
		
		/*if(!form.isShowQuarterOverview()){
			sb.append(" ,flexibility.year,flexibility.month ");
		}*/
		
		sb.append(" ) a ");
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			if(form.getSortColumn().equals("Flexibility")
					||form.getSortColumn().equals("A")
					||form.getSortColumn().equals("B")
					||form.getSortColumn().equals("C")){
				
			}else{
				sb.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType());
			}
		}
		
		SQLQuery query = getSession().createSQLQuery(sb.toString());
		
		if("Family".equals(form.getRemarkDimension())||"Product".equals(form.getRemarkDimension())){
			query.addScalar("Family", StringType.INSTANCE);
		}
		
		if("Region".equals(form.getRemarkDimension())){
			query.addScalar("Geo", StringType.INSTANCE);
			query.addScalar("Region", StringType.INSTANCE);
		}
		
		if("Geo".equals(form.getRemarkDimension())){
			query.addScalar("Geo", StringType.INSTANCE);
		}
		
			query.addScalar("Product", StringType.INSTANCE)
				.addScalar("shipment", IntegerType.INSTANCE)
				.addScalar("cwOrder", IntegerType.INSTANCE)
				.addScalar("cwCommit", IntegerType.INSTANCE)
				.addScalar("stockForecastQty", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FlexibilityDetailGridView.class));
		
		/*query.setFirstResult((form.getCurrentPage()-1)*SysConfig.NUMBER_OF_ROW_COUNT);
		query.setMaxResults(SysConfig.NUMBER_OF_ROW_COUNT);*/
		
		return query.list();
	}
}
