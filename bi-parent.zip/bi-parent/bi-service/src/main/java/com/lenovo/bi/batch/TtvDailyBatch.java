package com.lenovo.bi.batch;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.EtlDailyStatus;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.model.TtvDailyDetail;
import com.lenovo.bi.model.TtvDailySummary;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.util.CalendarUtil;

@Service
@Transactional("bi")
public class TtvDailyBatch implements BatchRunner {
	@Autowired
	private TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper;
	
	private static int SLEEP_TIME = 5 * 60 * 1000; // 5 min
		
	@Override
	//@Scheduled(cron="0 0 21 * * *")  // Run every day at 21 o'clock
	public void runBatch() {
		Date processDate = waitForEtlCompletion();
		fillEtlData(processDate);
		List<Integer> pmsWaveIds = retrievePmsWaveIdsForProcessing(processDate);
		
		for (Integer pmsWaveId : pmsWaveIds) {
			process(pmsWaveId, processDate);
		}		
	}
	
	private void process(int pmsWaveId, Date processDate) {
		Date midnight = CalendarUtil.adjustTimeToMidnight(processDate);
		List<TtvDailyDetail> details = ttvOutlookServiceBiHelper.getNpiDailyDetail(pmsWaveId, midnight, null);
		
		TtvDailySummary previousDailySummary = ttvOutlookServiceBiHelper.getPreviousDailySummary(pmsWaveId, midnight);
		List<NpiOrder> excludedOrders = ttvOutlookServiceBiHelper.getTTVExcludedOrder(pmsWaveId, TTVPhase.sle, processDate);
		
		ttvOutlookServiceBiHelper.deleteNpiDailySummaryAfter(pmsWaveId, midnight);
		
		boolean useRpy = true; // For TTV outlook, always use the data that includes RPY 
		// Pass in next day because today is considered history in daily processing
		Date nextMidnight = CalendarUtil.addDays(midnight, 1); 
		ttvOutlookServiceBiHelper.calculateTtvDailySummaryAndPersist(nextMidnight, useRpy, details, previousDailySummary, excludedOrders);		
	}

	private List<Integer> retrievePmsWaveIdsForProcessing(Date processDate) {
		return ttvOutlookServiceBiHelper.getPmsWaveIdsForDailyVersionDate(processDate);
	}

	private void fillEtlData(Date processDate) {
		// TODO-Ying
		
	}

	private Date waitForEtlCompletion() {
		while (true) {
			EtlDailyStatus latestEtlDailyStatus = ttvOutlookServiceBiHelper.getLatestEtlDailyStatus();
			
			if (latestEtlDailyStatus == null || !latestEtlDailyStatus.getComplete()) {
				try {
					//System.out.println("Waiting for weekly ETL to complete...");
					Thread.sleep(SLEEP_TIME);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else {
				return latestEtlDailyStatus.getVersionDate();
			}
		}
	}
}
