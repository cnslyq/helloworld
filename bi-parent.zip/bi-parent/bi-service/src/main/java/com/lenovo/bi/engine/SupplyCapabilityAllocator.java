package com.lenovo.bi.engine;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.enumobj.PhaseEnum;
import com.lenovo.bi.model.ForecastData;
import com.lenovo.bi.model.OrderData;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;

abstract public class SupplyCapabilityAllocator<T> {
	protected MtmCvConfigMap mtmCvConfigMap;
	protected PhaseEnum phase;
	protected Date targetDate;
	protected Date versionDate;

	protected TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper;

	public SupplyCapabilityAllocator(MtmCvConfigMap mtmCvConfigMap, PhaseEnum phase, Date targetDate, Date versionDate,
			TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper) {
		this.mtmCvConfigMap = mtmCvConfigMap;
		this.phase = phase;
		this.targetDate = targetDate;
		this.versionDate = versionDate;
		this.ttvOutlookServiceBiHelper = ttvOutlookServiceBiHelper;
	}

	abstract public void processOrderData(List<OrderData> orderDataList, ComponentQuota mtmComponentQuota, Map<String, T> weeklyDetailMap);

	abstract public void processForecastData(List<ForecastData> forecastDataList, ComponentQuota ctoComponentQuota, Map<String, T> weeklyDetailMap);

}
