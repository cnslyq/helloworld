package com.lenovo.bi.view.npi.chart.column;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;

public class Categories {

	private List<CategoryParent> categoryList;

	public List<CategoryParent> getCategoryList() {
		return categoryList;
	}

	@JsonProperty("category")
	public void setCategoryList(List<CategoryParent> categoryList) {
		this.categoryList = categoryList;
	}
	
	
}
