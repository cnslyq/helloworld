package com.lenovo.bi.engine;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.lenovo.bi.dao.common.OdmCapacityDao;
import com.lenovo.bi.dto.OdmCapacityPlan;
import com.lenovo.bi.enumobj.KPILights;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.enumobj.TimeFrequencyEnum;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.service.common.MasterDataService;
import com.lenovo.bi.util.CalendarUtil;
/**
 * 
 * 
 * @author henry_lian
 *
 */
@Component
@Order(2)
public class TTMODMKPIProcessor implements TTMKPIProcessor {
	
	@Inject
	private OdmCapacityDao odmCapacityDao;
	@Inject
	private OdmCapacityCalculator odmCapacityCalculator;
	@Inject
	private MasterDataService masterDataService;
	@Override
	public void process(ProjectSummary ps, Date versionDate) {
		if(ps.getTtmStatus().equals(Status.NA.name())){
			return;
		}
		Date targetDate = ps.getTtmTargetDate();
		if(targetDate != null){
			targetDate = CalendarUtil.getMondayDateByDate(targetDate);
			//targetDate = CalendarUtil.getMondayDateByWeeks(targetDate, 1);
		}
		List<OdmCapacityPlan> list = odmCapacityDao.getOdmNpiCapacityPlanForTargetDate(ps.getPmsWaveId(), targetDate, versionDate);
		//List<OdmCapacityPlan> list = odmCapacityDao.getOdmNpiCapacityPlanForTargetDate(ps.getPmsWaveId(), versionDate, versionDate);
		if(list.isEmpty()){
			ps.setOdm(KPILights.GREEN.name());
		}else{
			int totalCap = odmCapacityCalculator.calculateOdmNpiCapacity(list, TimeFrequencyEnum.WEEKLY);
			Float threshold = masterDataService.getThresholdByName(Threshold.TTM_ODM.name());
			if(totalCap >= ps.getTtmTargetDateDemand()){
				ps.setOdm(KPILights.GREEN.name());
				
			} else if(totalCap >= ps.getTtmTargetDateDemand()*threshold){
				ps.setOdm(KPILights.YELLOW.name());
			} else{
				ps.setOdm(KPILights.RED.name());
			}
		}
	}

}
