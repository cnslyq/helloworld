package com.lenovo.bi.dao.sc;


import java.util.List;

import com.lenovo.bi.dto.DimOrderForDetractor;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.dto.sc.FpsdRemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;

public interface FpsdDao {

	public List<ScOverViewChartData> fetchFpsdOverViewChartData(SearchOtsForm form);
	
	public List<FpsdRemarkChartData> fetchDimensionRemarkDataList(SearchOtsForm form);
	
	public List<KeyNameObject> fetchDimensions(SearchOtsForm form);
	
	public int fetchDimensionsCount(SearchOtsForm form);
	
	public List<ScRemarkChartData> fetchFpsdRemarkChartData(SearchOtsForm form);
	
	public List<ScRemarkChartData> fetchFpsdGeoRemarkChartData(SearchOtsForm form);
	
	public List<ScOverViewChartData> fetchFpsdDashboardOverViewChartData(SearchOtsForm form);

	public List<ScOverViewChartData> fetchFpsdCrossMonthOverviewChartData(SearchOtsForm form);
	
	public List<ScOverViewChartData> getOverviewOverall(SearchOtsForm form);
	
	public Integer fetchToltalDimensionFpsdData(SearchOtsForm form);
	
	public Integer fetchToltalGeoDimensionFpsdData(SearchOtsForm form);
	
	public List<String> fetchFpsdOverViewOrderDetail(SearchOtsForm form);
	
	public List<String> fetchFpsdCrossMonthOrderDetail(SearchOtsForm form);
	
	public List<String> fetchFpsdDashboardOverOderDetail(SearchOtsForm form);
	
	public List<String> fetchFpsdOverViewRemarkOrderDetail(SearchOtsForm form);
	
	public List<String> fetchFpsdOrderKeysByDims(SearchOtsForm form);
	
	public List<PieDivider> getDetractorMainDivider(SearchOtsForm form);
	
	public List<DimOrderForDetractor> getDetractorMainUnknownDivider(SearchOtsForm form);
	
	//overview order detail
	public int getOverviewOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getOverviewOrderDetail(SearchOtsForm form);
	
	public int getCrossMonthOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getCrossMonthOrderDetail(SearchOtsForm form);
	
	public int getDashboardOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getDashboardOrderDetail(SearchOtsForm form);
	
	//remark order detail
	public int getRemarkOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getRemarkOrderDetail(SearchOtsForm form);
	
	//detractor order detail
	public int getDetractorOrderDetailCount(SearchOtsForm form);
		
	public List<TtvGridDetractorCodeView> getDetractorOrderDetail(SearchOtsForm form);
		
	public List<TtvGridDetractorCodeView> getAllOrderDetail(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getDashCrossRemarkOrderDetail(SearchOtsForm form);
	
	public int getDashCrossRemarkOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getAllDetractorOrder(SearchOtsForm form);
}
