package com.lenovo.bi.batch;

public interface BatchRunner {
	void runBatch();
}
