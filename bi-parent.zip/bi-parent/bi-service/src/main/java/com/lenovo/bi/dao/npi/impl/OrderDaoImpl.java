package com.lenovo.bi.dao.npi.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.MtmGeographyOdmCvQuantity;
import com.lenovo.bi.dto.Order;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.view.npi.ttv.OrderHitRateView;
import com.lenovo.common.logging.Logger;
import com.lenovo.common.logging.LoggerFactory;

@SuppressWarnings("rawtypes")
@Repository
public class OrderDaoImpl extends HibernateBaseDaoImplDw {
	/**
	 * 
	 * @param targetDate
	 *            Monday of the week
	 * @return ALL orders (including NPI and SC orders) in the week of the
	 *         Monday passed in. Ordered by order date and then quantity.
	 */
	private static  Logger log = LoggerFactory.getLogger("OrderDaoImpl");
	@SuppressWarnings("unchecked")
	public List<Order> getSLEAllOrdersInWeek(Date targetDate, Date versionDate) {
		// ENGINE
		/*
		 * StringBuffer sql = new StringBuffer(
		 * "select  mtm.BOMNumberAlternateKey as bomNumber, mtm.MTMEnglishDescription as mtmDesc,psd.PONumber as poNumber, psd.POItem as poItem, pr.productKey as productKey,"
		 * ) .append(
		 * "geo.GeographyName as geographyName, odm.ODMEnglishName as odmName, psd.quantity as quantity,psd.rsddate as rsd, psd.OrderDate as orderDate, psd.ShipDate as shipDate, psd.FGDate as fgDate"
		 * ) .append(" from FactDailyPSD psd").append(
		 * " inner join DimMTM mtm on mtm.MTMKey = psd.MTMKey")
		 * .append(" inner join DimProduct pr on mtm.ProductKey = pr.ProductKey"
		 * ) .append(
		 * " inner join DimGeography geo on geo.GeographyKey = psd.RegionKey")
		 * .append(" inner join DimODM odm on odm.ODMKey = psd.ODMKey")
		 * .append(" where datediff(day, ?, psd.rsddate) >=0  ")
		 * .append(" and datediff(day, ?, psd.rsddate) <=0  ")
		 * .append(" and datediff(day, ?, psd.versiondate) =0");
		 */

		StringBuffer sql = new StringBuffer(
				"{CALL dw_sp_get_upshipped_order_in_Week(?)}");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bomNumber", StringType.INSTANCE)
				.addScalar("mtmDesc", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE)
				.addScalar("geographyName", StringType.INSTANCE)
				.addScalar("odmName", StringType.INSTANCE)
				.addScalar("quantity", IntegerType.INSTANCE)
				.addScalar("rsd", DateType.INSTANCE)
				.addScalar("orderDate", DateType.INSTANCE)
				.addScalar("shipDate", DateType.INSTANCE)
				.addScalar("fgDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(Order.class));
		Date now = new Date();
		if (CalendarUtil.getMondayDateByDate(now).compareTo(targetDate) == 0) {
			query.setParameter(0, now);
		} else {
			query.setParameter(0, targetDate);
		}
		List<Order> orders = query.list();

		for (Order order : orders) {
			order.setTargetDate(targetDate);
		}
		return orders;
	}

	@SuppressWarnings("unchecked")
	public List<Order> getSLEOrdersInWeekByProductKey(Date targetDate,
			String productKey, String waveId,Date startDate, Date endDate) {
		StringBuffer sql = new StringBuffer("select ");
		sql.append("mtm.BOMNumberAlternateKey as bomNumber ,");
		sql.append("max(mtm.MTMEnglishDescription) as mtmDesc,");
		sql.append("geo.GeographyName as geographyName ,");
		sql.append("pg.GeographyName as parentGeoName,");
		sql.append("odm.ODMEnglishName as odmName ,");
		sql.append("dbo.GetMondayFor (RSDDate) as versionDate, ");
		sql.append("sum(psd.quantity) as quantity ");
		sql.append("from view_orderdetail psd ");
		sql.append("inner join DimMTM mtm on psd.mtmkey=mtm.mtmkey ");
		sql.append("inner join DimGeography geo on geo.GeographyKey = psd.RegionKey ");
		sql.append("left join DimGeography pg on pg.GeographyKey = geo.ParentGeographyKey ");
		sql.append("inner join DimODM odm on odm.ODMKey = psd.ODMKey ");
		sql.append("inner join view_getNew_mtm_wave wave on psd.MTMKey = wave.MTMKey ");
		sql.append("INNER JOIN DimNPIWave npiwave ON wave.NPIWaveKey = npiwave.NPIWaveKey ");
		sql.append("where  ");
	//	sql.append("and IsShipped = 0 ");
		//sql.append("dbo.GetMondayFor (RSDDate) BETWEEN ? and ? ");
		sql.append("dbo.GetMondayFor (RSDDate) = ? ");
		sql.append("and mtm.productKey = ? ");
		sql.append("and npiwave.PMSWaveIDAlternateKey = ? ");
		sql.append("group by mtm.BOMNumberAlternateKey,geo.GeographyName,pg.GeographyName,odm.ODMEnglishName,dbo.GetMondayFor(RSDDate) ");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bomNumber", StringType.INSTANCE)
				.addScalar("mtmDesc", StringType.INSTANCE)
				.addScalar("geographyName", StringType.INSTANCE)
				.addScalar("parentGeoName", StringType.INSTANCE)
				.addScalar("odmName", StringType.INSTANCE)
				.addScalar("quantity", IntegerType.INSTANCE)
				.addScalar("versionDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(Order.class));
		/*
		query.setParameter(0, startDate);
		query.setParameter(1, endDate);
		query.setParameter(2, productKey);
		query.setParameter(3, waveId);
		*/
		query.setParameter(0, targetDate);
		query.setParameter(1, productKey);
		query.setParameter(2, waveId);
		List<Order> orders = query.list();

		return orders;
	}

	@SuppressWarnings("unchecked")
	public List<OrderHitRateView> getOrderAndForecast(Date versionDate,
			Date targetDate, String productKey, String regionName,String waveId) {
		StringBuffer sql = new StringBuffer(
				"select od.mtm,od.description,od.region,od.geo,od.odm,od.quantity,isnull(fcs.forecast,0) as forecast from (");
		sql.append(
				"select m.BOMNumberAlternateKey as mtm,max(m.MTMEnglishDescription) as description,geo.GeographyName as region ,")
				.append("pg.GeographyName as geo ,odm.ODMEnglishName as odm ,isnull(sum(psd.quantity),0) as quantity  ");
		sql.append("from view_orderdetail psd ");
		sql.append("inner join DimMTM m on psd.mtmkey=m.mtmkey ");
		sql.append("inner join  dbo.view_getNew_mtm_wave wave on psd.MTMKey =wave.MTMKey  ");
		sql.append("inner join DimNPIWave npiwave on wave.NPIWaveKey =npiwave.NPIWaveKey ");
		sql.append("inner join DimGeography geo on geo.GeographyKey = psd.RegionKey ");
		sql.append("left join DimGeography pg on pg.GeographyKey = geo.ParentGeographyKey ");
		sql.append("inner join DimODM odm on odm.ODMKey = psd.ODMKey ");
		sql.append("where  ");
		sql.append("dbo.GetMondayFor(RSDDate)=? ");
		sql.append("and m.productKey=? ");
		sql.append("and npiwave.PMSWaveIDAlternateKey=	? ");
		if (StringUtils.isNotBlank(regionName)) {
			sql.append("and geo.GeographyName = '").append(regionName)
					.append("' ");
		}
		sql.append("group by m.BOMNumberAlternateKey,geo.GeographyName,pg.GeographyName,odm.ODMEnglishName) as od ");
		sql.append("left join(select m.BOMNumberAlternateKey as mtm, region.GeographyName as region, odm.ODMEnglishName as odm,isnull(sum(f.quantity),0) as forecast ");
		sql.append("from FactWeeklyForecast f ");
		sql.append("inner join DimMTM m on f.MTMKey = m.MTMKey ");
		sql.append("inner join dbo.view_getNew_mtm_wave wave on f.MTMKey =wave.MTMKey  ");
		sql.append("inner join DimNPIWave npiwave on wave.NPIWaveKey =npiwave.NPIWaveKey  ");
		sql.append("inner join DimForecastAndCommitType fct on f.ForecastType = fct.FCTypeKey ");
		sql.append("inner join DimTime t1 on f.TargetDateKey = t1.TimeKey ");
		sql.append("inner join DimTime t2 on f.VersionDateKey = t2.TimeKey ");
		sql.append("inner join DimGeography region on region.GeographyKey = f.GeographyKey ");
		sql.append("inner join DimODM odm on f.ODMKey = odm.ODMKey ");
		sql.append("where DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0 ");
		sql.append("and DATEDIFF(day, t2.FullDateAlternateKey, ?) = 0 ");
		sql.append("and fct.FCType = '59' ");
		sql.append("and f.Quantity > 0 ");
		sql.append("and m.productKey=? ");
		sql.append("and npiwave.PMSWaveIDAlternateKey = ? ");
		if (StringUtils.isNotBlank(regionName)) {
			sql.append("and region.GeographyName = '").append(regionName)
					.append("' ");
		}
		sql.append("group by m.BOMNumberAlternateKey,region.GeographyName,odm.ODMEnglishName) as fcs ");
		sql.append("on fcs.mtm = od.mtm and fcs.region = od.region and fcs.odm = od.odm ");
		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(OrderHitRateView.class));
//		Date now = new Date();
//		if (CalendarUtil.getMondayDateByDate(now).compareTo(targetDate) == 0) {
//			query.setParameter(0, now);
//			query.setParameter(1, now);
//		} else {
//			query.setParameter(0, targetDate);
//			query.setParameter(1, targetDate);
//		}
		//query.setParameter(0, versionDate);
		query.setParameter(0, targetDate);
		query.setParameter(1, productKey);
		query.setParameter(2, waveId);
//		query.setParameter(3, versionDate);
//		query.setParameter(4, targetDate);
		query.setParameter(3, targetDate);
		query.setParameter(4, versionDate);
		query.setParameter(5, productKey);
		query.setParameter(6, waveId);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<Order> getSGAOrdersInWeekByProduct(Date targetDate,
			Date versionDate, String productKey) {
		StringBuffer sql = new StringBuffer(
				"select  mtm.BOMNumberAlternateKey as bomNumber, mtm.MTMEnglishDescription as mtmDesc,psd.PONumber as poNumber, psd.POItem as poItem, pr.productKey as productKey,")

				.append("geo.GeographyName as geographyName, odm.ODMEnglishName as odmName, psd.quantity as quantity,psd.rsddate as rsd, psd.OrderDate as orderDate, psd.ShipDate as shipDate, psd.FGDate as fgDate")
				.append(" from FactDailyPSD psd")
				.append(" inner join DimMTM mtm on mtm.MTMKey = psd.MTMKey")
				.append(" inner join DimProduct pr on mtm.ProductKey = pr.ProductKey")
				.append(" inner join DimGeography geo on geo.GeographyKey = psd.RegionKey")
				.append(" inner join DimODM odm on odm.ODMKey = psd.ODMKey")
				.append(" where datediff(day, ?, psd.OrderDate) >=0  ")
				.append(" and datediff(day, ?, psd.OrderDate) <=0  ")
				.append(" and datediff(day, ?, psd.versiondate) =0 and pr.ProductKey = ? ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(Order.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, CalendarUtil.getSundayDateByDate(targetDate));
		query.setParameter(2, versionDate);
		query.setParameter(3, productKey);
		List<Order> orders = query.list();

		for (Order order : orders) {
			order.setTargetDate(targetDate);
		}
		return orders;
	}

	/**
	 * 
	 * @param targetDate
	 *            Must be Monday
	 * @return ALL orders (including NPI and SC orders) that are not shipped
	 *         before the week of the Monday passed in. Ordered by order date
	 *         and then quantity.
	 */
	@SuppressWarnings("unchecked")
	public List<Order> getUnshippedOrdersBeforeWeek(Date targetDate,
			Date versionDate) {
		// ENGINE
		/*
		 * StringBuffer sql = new StringBuffer(
		 * "select  mtm.BOMNumberAlternateKey as bomNumber, mtm.MTMEnglishDescription as mtmDesc,psd.PONumber as poNumber, psd.POItem as poItem, pr.productKey as productKey,"
		 * )
		 * 
		 * .append(
		 * "geo.GeographyName as geographyName, odm.ODMEnglishName as odmName, psd.quantity as quantity,psd.rsddate as rsd, psd.OrderDate as orderDate, psd.ShipDate as shipDate, psd.FGDate as fgDate"
		 * ) .append(" from FactDailyPSD psd").append(
		 * " inner join DimMTM mtm on mtm.MTMKey = psd.MTMKey")
		 * .append(" inner join DimProduct pr on mtm.ProductKey = pr.ProductKey"
		 * ) .append(
		 * " inner join DimGeography geo on geo.GeographyKey = psd.RegionKey"
		 * ).append(" inner join DimODM odm on odm.ODMKey = psd.ODMKey")
		 * .append(" where datediff(day, ?, psd.rsddate) > 0  ").append(
		 * " and psd.IsShipped = 0 "
		 * ).append(" and datediff(day, ?, psd.versiondate) =0");
		 */
		StringBuffer sql = new StringBuffer(
				"{CALL dw_sp_get_upshipped_order_before_Week(?)}");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bomNumber", StringType.INSTANCE)
				.addScalar("mtmDesc", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE)
				.addScalar("geographyName", StringType.INSTANCE)
				.addScalar("odmName", StringType.INSTANCE)
				.addScalar("quantity", IntegerType.INSTANCE)
				.addScalar("rsd", DateType.INSTANCE)
				.addScalar("orderDate", DateType.INSTANCE)
				.addScalar("shipDate", DateType.INSTANCE)
				.addScalar("fgDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(Order.class));
		query.setParameter(0, targetDate);
		List<Order> orders = query.list();

		for (Order order : orders) {
			order.setTargetDate(CalendarUtil.getMondayDateByWeeks(targetDate,
					-1));
		}
		return orders;
	}

	public List<MtmGeographyOdmCvQuantity> getAllFulfilledCvQuantityInMonth(
			Date targetDate, Date lastSunday, Date versionDate) {
		// ENGINE
		StringBuilder sql = new StringBuilder(
				"select m.BOMNumberAlternateKey as bomNumber, cvf.GlobalCVKey as cvKey, ")
				.append("gm.geographyName, odm.ODMEnglishName as odmName, SUM(psd.Quantity * cvf.Quantity) as quantity ")
				.append("from FactDailyPSD psd, DimGeography g, DimGeography gm, DimODM odm, DimMTM m, FactPORinGlobalCVFormat cvf ")
				.append("where psd.MTMKey = m.MTMKey ")
				.append("and psd.RegionKey = g.GeographyKey ")
				.append("and g.ParentGeographyKey = gm.GeographyKey ")
				.append("and psd.ODMKey = odm.ODMKey ")
				.append("and m.BOMNumberAlternateKey = cvf.MTMBOMNumber ")
				.append("and psd.IsShipped <> 0 ")
				.append("and datediff(month,psd.ShipDate, ?) = 0 ")
				.append("and datediff(day, psd.ShipDate, ?) >= 0 ")
				.append("and datediff(day, psd.VersionDate, ?) = 0 ")
				.append("group by m.BOMNumberAlternateKey, gm.GeographyName, odm.ODMEnglishName, cvf.GlobalCVKey ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers
								.aliasToBean(MtmGeographyOdmCvQuantity.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, lastSunday);
		query.setParameter(2, versionDate);

		@SuppressWarnings("unchecked")
		List<MtmGeographyOdmCvQuantity> cvQuantityList = query.list();

		return cvQuantityList;
	}

	@SuppressWarnings("unchecked")
	public List<Order> getOrderByPoItemAndNumber(
			List<NpiWeeklyComponentCommitmentOnOrder> list) {

		if (list == null || list.isEmpty()) {
			return null;
		}

		List<String> poItemNumber = new ArrayList<String>();
		for (NpiWeeklyComponentCommitmentOnOrder order : list) {
			poItemNumber.add("'" + order.getPoItem() + "'+'"
					+ order.getPoNumber() + "'");
		}

		StringBuffer sql = new StringBuffer(
				"select (o.PONumber + '|' + cast(o.POItem as varchar)) as orderId, m.BOMNumberAlternateKey as bomNumber, ")
				.append("m.MTMEnglishDescription as mtmDesc,o.PONumber, cast(o.POItem as varchar) as poItem, pr.productKey, geo.GeographyName, odm.ODMEnglishName, o.quantity, t1.FullDateAlternateKey as rsd, t2.FullDateAlternateKey as orderDate, t3.FullDateAlternateKey as shipDate ")
				.append("from DimOrder o, DimMTM m, DimProduct pr, DimTime t1, DimTime t2, DimTime t3, DimGeography geo, DimODM odm ")
				.append("where o.MTMKey = m.MTMKey ")
				.append("and m.ProductKey = pr.ProductKey ")
				.append("and o.RSDDateKey = t1.TimeKey ")
				.append("and o.OrderDateKey = t2.TimeKey ")
				.append("and o.ShipDateKey = t3.TimeKey ")
				.append("and geo.GeographyKey = o.GeographyKey ")
				.append("and odm.ODMKey = o.ODMKey ")
				.append("and o.IsCurrent = 1 ")
				.append("and o.PONumber+convert(varchar(10),o.POItem) in (:orders)");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(Order.class));
		query.setParameterList("orders", poItemNumber);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<Order> getSGAAllOrdersInWeek(Date targetDate, Date versionDate) {
		/*
		 * StringBuffer sql = new StringBuffer(
		 * "select  mtm.BOMNumberAlternateKey as bomNumber, mtm.MTMEnglishDescription as mtmDesc,psd.PONumber as poNumber, psd.POItem as poItem, pr.productKey as productKey,"
		 * )
		 * 
		 * .append(
		 * "geo.GeographyName as geographyName, odm.ODMEnglishName as odmName, psd.quantity as quantity,psd.rsddate as rsd, psd.OrderDate as orderDate, psd.ShipDate as shipDate, psd.FGDate as fgDate"
		 * ) .append(" from FactDailyPSD psd").append(
		 * " inner join DimMTM mtm on mtm.MTMKey = psd.MTMKey")
		 * .append(" inner join DimProduct pr on mtm.ProductKey = pr.ProductKey"
		 * ) .append(
		 * " inner join DimGeography geo on geo.GeographyKey = psd.RegionKey"
		 * ).append(" inner join DimODM odm on odm.ODMKey = psd.ODMKey")
		 * .append(" where datediff(day, ?, psd.OrderDate) >=0  ").append(
		 * " and datediff(day, ?, psd.OrderDate) <=0  ")
		 * .append(" and datediff(day, ?, psd.versiondate) =0");
		 * 
		 * Query query =
		 * getSession().createSQLQuery(sql.toString()).setResultTransformer
		 * (Transformers.aliasToBean(Order.class)); query.setParameter(0,
		 * targetDate); query.setParameter(1,
		 * CalendarUtil.getSundayDateByDate(targetDate)); query.setParameter(2,
		 * versionDate); List<Order> orders = query.list();
		 */
		StringBuffer sql = new StringBuffer(
				"{CALL dw_sp_get_upshipped_order_in_Week_sga(?)}");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bomNumber", StringType.INSTANCE)
				.addScalar("mtmDesc", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE)
				.addScalar("geographyName", StringType.INSTANCE)
				.addScalar("odmName", StringType.INSTANCE)
				.addScalar("quantity", IntegerType.INSTANCE)
				.addScalar("rsd", DateType.INSTANCE)
				.addScalar("orderDate", DateType.INSTANCE)
				.addScalar("shipDate", DateType.INSTANCE)
				.addScalar("fgDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(Order.class));
		Date now = new Date();
		if (CalendarUtil.getMondayDateByDate(now).compareTo(targetDate) == 0) {
			query.setParameter(0, now);
		} else {
			query.setParameter(0, targetDate);
		}

		List<Order> orders = query.list();

		for (Order order : orders) {
			order.setTargetDate(targetDate);
		}
		return orders;
	}

	@SuppressWarnings("unchecked")
	public List<Order> getSGAUnshippedOrdersBeforeWeek(Date targetDate,
			Date versionDate) {
		// ENGINE
		/*
		 * StringBuffer sql = new StringBuffer(
		 * "select  mtm.BOMNumberAlternateKey as bomNumber, mtm.MTMEnglishDescription as mtmDesc,psd.PONumber as poNumber, psd.POItem as poItem, pr.productKey as productKey,"
		 * )
		 * 
		 * .append(
		 * "geo.GeographyName as geographyName, odm.ODMEnglishName as odmName, psd.quantity as quantity,psd.rsddate as rsd, psd.OrderDate as orderDate, psd.ShipDate as shipDate, psd.FGDate as fgDate"
		 * ) .append(" from FactDailyPSD psd").append(
		 * " inner join DimMTM mtm on mtm.MTMKey = psd.MTMKey")
		 * .append(" inner join DimProduct pr on mtm.ProductKey = pr.ProductKey"
		 * ) .append(
		 * " inner join DimGeography geo on geo.GeographyKey = psd.RegionKey"
		 * ).append(" inner join DimODM odm on odm.ODMKey = psd.ODMKey")
		 * .append(" where datediff(day, ?, psd.OrderDate) > 0  ").append(
		 * " and psd.IsShipped = 0 "
		 * ).append(" and datediff(day, ?, psd.versiondate) =0");
		 * 
		 * Query query =
		 * getSession().createSQLQuery(sql.toString()).setResultTransformer
		 * (Transformers.aliasToBean(Order.class)); query.setParameter(0,
		 * targetDate); query.setParameter(1, versionDate); List<Order> orders =
		 * query.list();
		 */
		StringBuffer sql = new StringBuffer(
				"{CALL dw_sp_get_upshipped_order_before_Week_sga(?)}");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bomNumber", StringType.INSTANCE)
				.addScalar("mtmDesc", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE)
				.addScalar("geographyName", StringType.INSTANCE)
				.addScalar("odmName", StringType.INSTANCE)
				.addScalar("quantity", IntegerType.INSTANCE)
				.addScalar("rsd", DateType.INSTANCE)
				.addScalar("orderDate", DateType.INSTANCE)
				.addScalar("shipDate", DateType.INSTANCE)
				.addScalar("fgDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(Order.class));
		query.setParameter(0, targetDate);

		List<Order> orders = query.list();
		for (Order order : orders) {
			order.setTargetDate(CalendarUtil.getMondayDateByWeeks(targetDate,
					-1));
		}
		return orders;
	}
}
