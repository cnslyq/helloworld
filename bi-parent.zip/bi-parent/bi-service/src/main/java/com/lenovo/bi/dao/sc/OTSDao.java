package com.lenovo.bi.dao.sc;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.dto.sc.OtsRemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;

public interface OTSDao {
	public List<ScOverViewChartData> fetchOtsOverViewChartData(SearchOtsForm form);
	
	public List<ScOverViewChartData> fetchScOtsOverViewChartData(SearchOtsForm form);
	
	public List<OtsRemarkChartData> fetchDimensionRemarkDataList(SearchOtsForm form);
	
	public List<KeyNameObject> fetchDimensions(SearchOtsForm form);
	
	public List<KeyNameObject> fetchGeoDimensions(SearchOtsForm form);
	
	public List<ScRemarkChartData> fetchOtsRemarkChartData(SearchOtsForm form);
	
	public List<ScRemarkChartData> fetchOtsGeoRemarkChartData(SearchOtsForm form);
	
	public List<ScOverViewChartData> fetchOtsDashboardOverViewChartData(SearchOtsForm form);
	
	public List<ScOverViewChartData> fetchOtsGeoDashboardOverViewChartData(SearchOtsForm form);

	public List<ScOverViewChartData> fetchOtsCrossMonthOverviewChartData(SearchOtsForm form);
	
	public List<ScOverViewChartData> getOverviewOverall(SearchOtsForm form);
	
	public Integer fetchTotalDimensionOtsData(SearchOtsForm form);
	
	public Integer fetchTotalGeoDimensionOtsData(SearchOtsForm form);
	
	public Integer fetchTotalFailValue(SearchOtsForm form);
	
	public Integer fetchTotalGeoFailValue(SearchOtsForm form);
	
	public List<String> fetchOtsOverViewOrderDetailData(SearchOtsForm form);
	
	public List<String> fetchOtsDashboardOrderDetailData(SearchOtsForm form);

	public List<String> fetchOtsCrossMonthOrderDetailData(SearchOtsForm form);
	public List<String> fetchOtsOverViewRemarkOrderDetailData(SearchOtsForm form) ;

	public List<String> fetchOtsOrderKeysByDims(SearchOtsForm form);

	public List<PieDivider> getDetractorMainDivider(SearchOtsForm form);
	
	//overview order detail
	public int getOverviewOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getOverviewOrderDetail(SearchOtsForm form);
	
	public int getCrossMonthOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getCrossMonthOrderDetail(SearchOtsForm form);
	
	public int getDashboardOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getDashboardOrderDetail(SearchOtsForm form);
	
	//remark order detail
	public int getRemarkOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getRemarkOrderDetail(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getAllOrderDetail(SearchOtsForm form);
	
	//detractor order detail
	public int getDetractorOrderDetailCount(SearchOtsForm form);
		
	public List<TtvGridDetractorCodeView> getDetractorOrderDetail(SearchOtsForm form);
	
	//makeRate calculate formula for quarter
	public Integer fetchUnshippedBacklog(SearchOtsForm form);
	
	public Integer fetchCurrentUnshippedOrderItems(SearchOtsForm form);
	
	public Integer fetchFutureOrderItems(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getDashCrossRemarkOrderDetail(SearchOtsForm form);
	
	public int getDashCrossRemarkOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getAllDetractorOrder(SearchOtsForm form);
}
