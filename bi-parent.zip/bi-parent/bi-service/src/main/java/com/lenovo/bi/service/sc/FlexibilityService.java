package com.lenovo.bi.service.sc;

import java.text.ParseException;
import java.util.List;

import com.lenovo.bi.dto.sc.FlexibilityChartData;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView2DLine;
import com.lenovo.bi.view.sc.flexibility.FlexibilityDetailGridView;


public interface FlexibilityService {
	public MSColumnChartView2DLine getOverviewChart(SearchOtsForm form) throws ParseException;
	
	public ColumnChartView getRemarkChart(SearchOtsForm form) throws ParseException;
	
	public void setFormDimParam(SearchOtsForm form, String dim, String dimKeys);
	
	public List<FlexibilityDetailGridView> getRemarkFlexibilityDetails(SearchOtsForm form);
	
	public List<FlexibilityDetailGridView> getFlexibilityDetailsForExcel(SearchOtsForm form);
	
	public int getTotalPageForRemarkFlexibilityDetails(SearchOtsForm form);

	public Float calFlexibility(FlexibilityChartData flexibilityChartData);

}
