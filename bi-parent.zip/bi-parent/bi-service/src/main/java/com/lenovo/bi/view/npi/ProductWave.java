package com.lenovo.bi.view.npi;

public class ProductWave {
	private Integer projectId;
	private Integer productId;
	private Integer waveId;
	private String productName;
	private String waveName;
	private String npiName;
	private String frequency;
	
	private String doiLight;
	private String gatingDefectsLight;
	private String toolingLight;
	private String odmLight;
	private String fpyLight;
	private String obeLight;
	private String ttmTargetDate;//ss date
	private String ttmSignOffDate;
	
	private String ttvTargetDate; // sga date
	private String ttvSignOffDate;
	private String startDate;
	private String ttvStatus; 
	private String ttvTarget; 
	private String estimatedTTV;
	private String actualTTV;
	private boolean isTTVSignOff;
	private String pm;
	private String svtDate;
	private String sovpDate;
	private Integer ttmTargetDateDemand;
	
	private String sgaTtvTargetDate; // sga date
	private String sgaTtvSignOffDate;
	private String sgaTtvStatus; 
	private String sgaTtvTarget; 
	private String sgaEstimatedTTV;
	private String sgaActualTTV;
	private boolean isSgaTTVSignOff;
	private String sgaStartDate;
	
	public Integer getTtmTargetDateDemand() {
		return ttmTargetDateDemand;
	}

	public void setTtmTargetDateDemand(Integer ttmTargetDateDemand) {
		this.ttmTargetDateDemand = ttmTargetDateDemand;
	}

	public String getSvtDate() {
		return svtDate;
	}

	public void setSvtDate(String svtDate) {
		this.svtDate = svtDate;
	}

	public String getSovpDate() {
		return sovpDate;
	}

	public void setSovpDate(String sovpDate) {
		this.sovpDate = sovpDate;
	}

	public String getPm() {
		return pm;
	}

	public void setPm(String pm) {
		this.pm = pm;
	}

	public String getDoiLight() {
		return doiLight;
	}

	public void setDoiLight(String doiLight) {
		this.doiLight = doiLight;
	}

	public String getGatingDefectsLight() {
		return gatingDefectsLight;
	}

	public void setGatingDefectsLight(String gatingDefectsLight) {
		this.gatingDefectsLight = gatingDefectsLight;
	}

	public String getToolingLight() {
		return toolingLight;
	}

	public void setToolingLight(String toolingLight) {
		this.toolingLight = toolingLight;
	}

	public String getOdmLight() {
		return odmLight;
	}

	public void setOdmLight(String odmLight) {
		this.odmLight = odmLight;
	}

	public String getFpyLight() {
		return fpyLight;
	}

	public void setFpyLight(String fpyLight) {
		this.fpyLight = fpyLight;
	}

	public String getObeLight() {
		return obeLight;
	}

	public void setObeLight(String obeLight) {
		this.obeLight = obeLight;
	}

	public String getTtmTargetDate() {
		return ttmTargetDate;
	}

	public void setTtmTargetDate(String ttmTargetDate) {
		this.ttmTargetDate = ttmTargetDate;
	}

	public String getTtmSignOffDate() {
		return ttmSignOffDate;
	}

	public void setTtmSignOffDate(String ttmSignOffDate) {
		this.ttmSignOffDate = ttmSignOffDate;
	}

	public String getTtvTargetDate() {
		return ttvTargetDate;
	}

	public void setTtvTargetDate(String ttvTargetDate) {
		this.ttvTargetDate = ttvTargetDate;
	}

	public String getTtvSignOffDate() {
		return ttvSignOffDate;
	}

	public void setTtvSignOffDate(String ttvSignOffDate) {
		this.ttvSignOffDate = ttvSignOffDate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getTtvStatus() {
		return ttvStatus;
	}

	public void setTtvStatus(String ttvStatus) {
		this.ttvStatus = ttvStatus;
	}

	public String getTtvTarget() {
		return ttvTarget;
	}

	public void setTtvTarget(String ttvTarget) {
		this.ttvTarget = ttvTarget;
	}

	public String getEstimatedTTV() {
		return estimatedTTV;
	}

	public void setEstimatedTTV(String estimatedTTV) {
		this.estimatedTTV = estimatedTTV;
	}

	public String getActualTTV() {
		return actualTTV;
	}

	public void setActualTTV(String actualTTV) {
		this.actualTTV = actualTTV;
	}

	public boolean isTTVSignOff() {
		return isTTVSignOff;
	}

	public void setTTVSignOff(boolean isTTVSignOff) {
		this.isTTVSignOff = isTTVSignOff;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getWaveId() {
		return waveId;
	}

	public void setWaveId(Integer waveId) {
		this.waveId = waveId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getWaveName() {
		return waveName;
	}

	public void setWaveName(String waveName) {
		this.waveName = waveName;
	}

	public String getNpiName() {
		return npiName;
	}

	public void setNpiName(String npiName) {
		this.npiName = npiName;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getSgaTtvTargetDate() {
		return sgaTtvTargetDate;
	}

	public void setSgaTtvTargetDate(String sgaTtvTargetDate) {
		this.sgaTtvTargetDate = sgaTtvTargetDate;
	}

	public String getSgaTtvSignOffDate() {
		return sgaTtvSignOffDate;
	}

	public void setSgaTtvSignOffDate(String sgaTtvSignOffDate) {
		this.sgaTtvSignOffDate = sgaTtvSignOffDate;
	}

	public String getSgaTtvStatus() {
		return sgaTtvStatus;
	}

	public void setSgaTtvStatus(String sgaTtvStatus) {
		this.sgaTtvStatus = sgaTtvStatus;
	}

	public String getSgaTtvTarget() {
		return sgaTtvTarget;
	}

	public void setSgaTtvTarget(String sgaTtvTarget) {
		this.sgaTtvTarget = sgaTtvTarget;
	}

	public String getSgaEstimatedTTV() {
		return sgaEstimatedTTV;
	}

	public void setSgaEstimatedTTV(String sgaEstimatedTTV) {
		this.sgaEstimatedTTV = sgaEstimatedTTV;
	}

	public String getSgaActualTTV() {
		return sgaActualTTV;
	}

	public void setSgaActualTTV(String sgaActualTTV) {
		this.sgaActualTTV = sgaActualTTV;
	}

	public boolean isSgaTTVSignOff() {
		return isSgaTTVSignOff;
	}

	public void setSgaTTVSignOff(boolean isSgaTTVSignOff) {
		this.isSgaTTVSignOff = isSgaTTVSignOff;
	}

	public String getSgaStartDate() {
		return sgaStartDate;
	}

	public void setSgaStartDate(String sgaStartDate) {
		this.sgaStartDate = sgaStartDate;
	}
}
