package com.lenovo.bi.dao.common.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.common.ExcludeOrderDao;
import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.model.ExcludeOrder;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.common.model.PagerInformation;

@Repository
@Transactional("bi")
public class ExcludeOrderDaoImpl extends HibernateBaseDaoImplBi implements	ExcludeOrderDao {

	@Override
	public void batchSaveExcludeOrder(List<ExcludeOrder> excludeOrders) {
		Session session = getSession();
		for(int i = 0; i<excludeOrders.size() ; i++){
			session.save(excludeOrders.get(i));
			if(i % SysConfig.EXCLUDE_ORDER_BATCH_OPERATE_SIZE == 0){
				session.flush();  
	            session.clear();
			}
		}
		session.flush();  
        session.clear();
	}


	@Override
	public void deleteExcudeOrder(String month) {
		StringBuffer hql = new StringBuffer("delete from ExcludeOrder  where convert(varchar(7),Month,120)= :month");
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("month", month);
		query.executeUpdate();
	}

	@Override
	public List<ExcludeOrder> getExcludeOrdersByCondition(
			String selMonth, PagerInformation pagerInfo) {
		StringBuilder sql = new StringBuilder(
				"select  PONumber as poNumber, POItem as poItem, OrderNo as orderNo, Reason as reason, Month as month");
				sql.append(" from BI_ExcludeOrder  where convert(varchar(7),Month,120)= :month");

		Query q = getSession().createSQLQuery(sql.toString())
				.addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE)
				.addScalar("orderNo", StringType.INSTANCE)
				.addScalar("reason", StringType.INSTANCE)
				.addScalar("month", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ExcludeOrder.class));
		q.setString("month", selMonth);
		q.setMaxResults(pagerInfo.getPageSize());
		q.setFirstResult(pagerInfo.getStartRow());
		return q.list();
	}

	@Override
	public int getExcludeOrderCountByMonth(String month) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(PONumber) from BI_ExcludeOrder  where convert(varchar(7),Month,120)= :month");
		Query query = getSession().createSQLQuery(sBuffer.toString());
		query.setString("month", month);
		List<Integer> rs = query.list(); 
		if (rs.size() == 0){
			return 0;
		} else{
			return rs.get(0).intValue(); 
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public String getPoNumberItemOrderNoByMonth(String selMonth , String quarterFrom, String quarterTo) {
		StringBuilder sql = new StringBuilder(
				"select  PONumber as poNumber, POItem as poItem, OrderNo as orderNo  from BI_ExcludeOrder  where ");
		        if(StringUtils.isEmpty(selMonth)){
		        	sql.append("convert(varchar(7),Month,120)  between :quarterFrom and :quarterTo");
		        	
		        }else{
		        	sql.append("convert(varchar(7),Month,120) = :month");
		        }

		Query q = getSession().createSQLQuery(sql.toString())
				.addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE)
				.addScalar("orderNo", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ExcludeOrder.class));
		if(StringUtils.isEmpty(selMonth)){
        	q.setString("quarterFrom", quarterFrom);
        	q.setString("quarterTo", quarterTo);
        }else{
        	q.setString("month", selMonth);
        }
		
		List<ExcludeOrder> excludeOrders= (List<ExcludeOrder>)q.list();
		String resultStr = "";
		String strTmp = "";
		if(excludeOrders.size() > 0 && excludeOrders != null){
			StringBuffer strBuffer = new StringBuffer();
			for(ExcludeOrder excludeOrder : excludeOrders){
				strBuffer.append("'");
				strBuffer.append(excludeOrder.getPoNumber());
				strBuffer.append("_");
				strBuffer.append(excludeOrder.getPoItem());
				strBuffer.append("_");
				strBuffer.append(excludeOrder.getOrderNo());
				strBuffer.append("'");
				strBuffer.append(", ");
			}
			strTmp = strBuffer.toString();
			resultStr =  strTmp.substring(0,strTmp.lastIndexOf(','));
		}
		return resultStr;
	}

}
