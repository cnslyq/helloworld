package com.lenovo.bi.form.npi.ttm;

import java.util.Date;

import com.lenovo.bi.form.npi.SearchBase;

public class SearchPillarChartDataForm extends SearchBase {

	private String weekNo;
	private String startDateStr;
	private String endDateStr;
	private Date startDate;
	private Date endDate;
	private String fpy;
	private String frequency;
	private int waveId;

	public String getWeekNo() {
		return weekNo;
	}

	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getStartDateStr() {
		return startDateStr;
	}

	public void setStartDateStr(String startDateStr) {
		this.startDateStr = startDateStr;
	}

	public String getEndDateStr() {
		return endDateStr;
	}

	public void setEndDateStr(String endDateStr) {
		this.endDateStr = endDateStr;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public int getWaveId() {
		return waveId;
	}

	public void setWaveId(int waveId) {
		this.waveId = waveId;
	}

	public String getFpy() {
		return fpy;
	}

	public void setFpy(String fpy) {
		this.fpy = fpy;
	}

	
}
