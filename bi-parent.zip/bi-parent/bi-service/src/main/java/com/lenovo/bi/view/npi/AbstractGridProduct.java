package com.lenovo.bi.view.npi;

import java.util.List;

public class AbstractGridProduct {

	private Integer productId;
	private Integer waveId;
	private String productName;
	private String waveName;
	private String npiOwner;
	private List<String> npiOwnerMails;
	private String pmOwner;
	private String pmOwnerMail;
	private String currentPhase;

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getWaveId() {
		return waveId;
	}

	public void setWaveId(Integer waveId) {
		this.waveId = waveId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getWaveName() {
		return waveName;
	}

	public void setWaveName(String waveName) {
		this.waveName = waveName;
	}

	public String getNpiOwner() {
		return npiOwner;
	}

	public void setNpiOwner(String npiOwner) {
		this.npiOwner = npiOwner;
	}

	public String getPmOwner() {
		return pmOwner;
	}

	public void setPmOwner(String pmOwner) {
		this.pmOwner = pmOwner;
	}

	public String getCurrentPhase() {
		return currentPhase;
	}

	public void setCurrentPhase(String currentPhase) {
		this.currentPhase = currentPhase;
	}

	public List<String> getNpiOwnerMails() {
		return npiOwnerMails;
	}

	public void setNpiOwnerMails(List<String> npiOwnerMails) {
		this.npiOwnerMails = npiOwnerMails;
	}

	public String getPmOwnerMail() {
		return pmOwnerMail;
	}

	public void setPmOwnerMail(String pmOwnerMail) {
		this.pmOwnerMail = pmOwnerMail;
	}

}
