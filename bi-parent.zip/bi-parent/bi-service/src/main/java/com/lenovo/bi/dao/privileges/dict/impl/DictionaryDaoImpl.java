package com.lenovo.bi.dao.privileges.dict.impl;

import java.util.List;

import org.apache.poi.ss.formula.functions.T;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.dao.privileges.dict.DictionaryDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.enumobj.OrgEnum;
import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.system.GroupDetail;
import com.lenovo.bi.model.system.GroupMember;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.system.dictionary.BuDetailView;
import com.lenovo.bi.view.system.dictionary.CompanyDetailView;
import com.lenovo.bi.view.system.dictionary.DepartmentDetailView;
import com.lenovo.bi.view.system.dictionary.GroupDetailView;
import com.lenovo.bi.view.system.dictionary.GroupMemberDetailView;
import com.lenovo.bi.view.system.dictionary.PrivilegeDetailView;
import com.lenovo.bi.view.system.dictionary.UserDetailView;
import com.lenovo.common.model.PagerInformation;

@Repository
public class DictionaryDaoImpl extends HibernateBaseDaoImplBi implements DictionaryDao  {

	@Override
	public List<PrivilegeDetailView> getPrivilegeDetailList(DictSearchForm form, PagerInformation pagerInfo) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select privilege.id as id,")
			   .append("privilege.Name as name,")
			   .append("parent.Name as category,")
			   .append("privilege.Code as code,")
			   .append("privilege.Type as type,")
			   .append("privilege.Description as description,")
			   .append("privilege.url as url,")
			   .append("privilege.ParentId as parentId")
			   .append( " from BI_Privilege privilege")
			   .append( " left join BI_Privilege parent")
			   .append( " on privilege.ParentId = parent.id");
		if(form.getSearchBy() != null) {
			sBuffer.append(" where privilege.Name like '%").append(form.getSearchBy().replace("'","''")).append("%'");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("category", StringType.INSTANCE)
				.addScalar("code", StringType.INSTANCE)
				.addScalar("type", IntegerType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("url", StringType.INSTANCE)
				.addScalar("parentId", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PrivilegeDetailView.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}

	@Override
	public int getPrivilegeDetailCountByConditions(DictSearchForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(code)")
			   .append( " from BI_Privilege privilege");
		if(form.getSearchBy() != null) {
			sBuffer.append(" where privilege.Name like '%").append(form.getSearchBy().replace("'","''")).append("%'");
		}
		Query query = getSession().createSQLQuery(sBuffer.toString());
		List<Integer> rs = query.list(); 
		if (rs.size() == 0){
			return 0;
		} else{
			return rs.get(0).intValue(); 
		}
	}

	
	@Override
	public List<GroupDetailView> listGroup(DictSearchForm form, PagerInformation pagerInfo) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biGroup.id as id,")
			   .append("biGroup.Name as name,")
			   .append("biGroup.Description as description,")
			   .append("biGroup.CreatedBy as createdBy,")
			   .append("biGroup.CreatedDate as createdDate")
			   .append( " from BI_Group biGroup");
		if(form.getSearchBy() != null) {
			sBuffer.append(" where biGroup.Name like '%").append(form.getSearchBy().replace("'","''")).append("%'");
		}
		
		if(form.getSortColumn() != null && form.getSortType() != null) {
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("createdBy", StringType.INSTANCE)
				.addScalar("createdDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GroupDetailView.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}
	
	@Override
	public List<GroupDetailView> listGroupsForExcel(DictSearchForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biGroup.id as id,")
			   .append("biGroup.Name as name,")
			   .append("biGroup.CreatedBy as createdBy,")
			   .append("biGroup.CreatedDate as createdDate")
			   .append( " from BI_Group biGroup");
		if(form.getSearchBy() != null) {
			sBuffer.append(" where biGroup.Name like '%").append(form.getSearchBy().replace("'","''")).append("%'");
		}
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("createdBy", StringType.INSTANCE)
				.addScalar("createdDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GroupDetailView.class));
		
		return query.list();
	}
	
	@Override
	public int getGroupDetailCountByConditions(DictSearchForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(name)")
			   .append( " from BI_Group biGroup");
		if(form.getSearchBy() != null) {
			sBuffer.append(" where biGroup.Name like '%").append(form.getSearchBy().replace("'","''")).append("%'");
		}
		Query query = getSession().createSQLQuery(sBuffer.toString());
		List<Integer> rs = query.list(); 
		if (rs.size() == 0){
			return 0;
		} else{
			return rs.get(0).intValue(); 
		}
	}
	
	@Override
	public GroupDetail findGroupById(Integer groupId) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append( "from GroupDetail groupDetail")
			   .append( " where groupDetail.id=").append(groupId)
			   ;
		Query query = getSession().createQuery(sBuffer.toString());
		return (GroupDetail)(query.list().get(0));
	}
	
	public GroupDetail findGroupByName(String groupName) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("from GroupDetail groupDetail")
				.append(" where groupDetail.name= '").append(groupName)
				.append("'");
		Query query = getSession().createQuery(sBuffer.toString());
		if(query.list().size() == 0){
			return null;
		}
		return (GroupDetail) (query.list().get(0));
	}

	@Override
	public void saveGroup(GroupDetail groupDetail) {
		this.add(groupDetail);
	}
	
	@Override
	public void saveGroupMember(List<GroupMember> groupMemberList) {
		for(GroupMember groupMember : groupMemberList) {
			this.add(groupMember);
		}
	}
	
	@Override
	public void saveEditedGroup(GroupDetail groupDetail) {
		this.update(groupDetail);
		//getSession().update(groupDetail);
		getSession().flush();
	}
	
	@Override
	public void saveEditedGroupMember(int gId,List<GroupMember> groupMemberList) {
		deleteGroupMemberByGroupId(gId);
		for(GroupMember groupMember : groupMemberList) {
			this.add(groupMember);
		}
	}
	
	@Override
	public void deleteGroups(String groupIds) {
		
		StringBuffer sBuffer1 = new StringBuffer();
		sBuffer1.append("delete")
			   .append( " from BI_Group_Privilege")
			   .append(" where GroupId in (")
		       .append(groupIds).append(")");
		Query q1 = getSession().createSQLQuery(sBuffer1.toString());
		q1.executeUpdate();
		
		StringBuffer sBuffer2 = new StringBuffer();
		sBuffer2.append("delete")
			   .append( " from BI_Group_Member")
			   .append(" where GroupId in (")
			   .append(groupIds).append(")");
		Query q2 = getSession().createSQLQuery(sBuffer2.toString());
		q2.executeUpdate();
		
		StringBuffer sBuffer3 = new StringBuffer();
		sBuffer3.append("delete")
			   .append( " from GroupDetail biGroup")
			   .append(" where biGroup.id in (")
			   .append(groupIds).append(")");
		Query q3 = getSession().createQuery(sBuffer3.toString());
		q3.executeUpdate();
		
	}
	
	public void deleteGroupById(Integer groupId) {
		
		StringBuffer sBuffer1 = new StringBuffer();
		sBuffer1.append("delete")
			   .append( " from BI_Group_Privilege")
			   .append(" where GroupId =").append(groupId);
		Query q1 = getSession().createSQLQuery(sBuffer1.toString());
		q1.executeUpdate();
		
		StringBuffer sBuffer2 = new StringBuffer();
		sBuffer2.append("delete")
			   .append( " from BI_Group_Member")
			   .append(" where GroupId =").append(groupId);
		Query q2 = getSession().createSQLQuery(sBuffer2.toString());
		q2.executeUpdate();
		
		StringBuffer sBuffer3 = new StringBuffer();
		sBuffer3.append("delete")
			   .append( " from GroupDetail biGroup")
			   .append(" where biGroup.id =").append(groupId);
		Query q3 = getSession().createQuery(sBuffer3.toString());
		q3.executeUpdate();
		
	}
	
	public void deleteGroupMemberByGroupId(Integer groupId) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("delete")
			   .append( " from GroupMember biGroupMember")
			   .append(" where biGroupMember.groupId =").append(groupId);
		Query q = getSession().createQuery(sBuffer.toString());
		q.executeUpdate();
		
	}

	@Override
	public List<T> listOrg(String type,String name) {
		StringBuffer hql = new StringBuffer();
		if(type.equals(OrgEnum.Company.getTypeName())) {
			hql.append("from PassportCompany where name like '%"+ name + "%'");
		}
		else if(type.equals(OrgEnum.BU.getTypeName())) {
			hql.append("from PassportBusinessUnit where name like '%"+ name + "%'");
		}
		else if(type.equals(OrgEnum.Department.getTypeName())) {
			hql.append("from PassportDepartment where name like '%"+ name + "%'");
		}
		else if(type.equals(OrgEnum.User.getTypeName())) {
			//hql.append("from PassportUser where companyId = 27 and name like '%"+ name + "%'");
			hql.append("from PassportUser where name like '%"+ name + "%'");
		}
		Query query = getSession().createQuery(hql.toString());
		List<T> list = query.list();
		
		return list;
	}

	@Override
	public List<GroupMemberDetailView> getGroupMemberByGroupId(Integer groupId,Integer memberType) {
		
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biGroup.id as groupId,biGroup.Name as groupName,biGroup.IsActive as isActive,biGroup.Description as description,")
			   .append("biGroup.CreatedBy as createdBy,biGroup.CreatedDate as createdDate,")
			   .append("bgm.memberId as memberId,bgm.memberName as name,")
			   .append("bgm.memberId as id,")
			   .append("bgm.memberType as memberType")
			   .append( " from BI_Group biGroup")
			   .append( " left join (");
	    if(memberType == 0) {
	    	sBuffer.append("select groupMember.GroupId as groupId,groupMember.MemberId as memberId,groupMember.MemberType as memberType,Name as memberName")
			       .append(" from BI_Group_Member groupMember")
	    	       .append(" left join PASSPORT_Company company on groupMember.MemberId=company.id");
	    }
	    else if(memberType == 1) {
	    	sBuffer.append("select groupMember.GroupId as groupId,groupMember.MemberId as memberId,groupMember.MemberType as memberType,Name as memberName")
		       		.append(" from BI_Group_Member groupMember")
		       		.append(" left join PASSPORT_BusinessUnit business on groupMember.MemberId=business.id");
	    }
	    else if(memberType == 2) {
	    	sBuffer.append("select groupMember.GroupId as groupId,groupMember.MemberId as memberId,groupMember.MemberType as memberType,Name as memberName")
		       		.append(" from BI_Group_Member groupMember")
		       		.append(" left join PASSPORT_Department department on groupMember.MemberId=department.id");
	    }
	    else if(memberType == 3) {
	    	sBuffer.append("select groupMember.GroupId as groupId,groupMember.MemberId as memberId,groupMember.MemberType as memberType,puser.UserId as memberName")
       				.append(" from BI_Group_Member groupMember")
       				.append(" left join PASSPORT_User puser on groupMember.MemberId=puser.id");
	    }
	    	
	    sBuffer.append(")bgm").append(" on biGroup.id=bgm.groupId");
	    sBuffer.append(" where biGroup.id=").append(groupId)
	    		.append(" and bgm.memberType=").append(memberType);
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("groupId", IntegerType.INSTANCE)
				.addScalar("groupName", StringType.INSTANCE)
				.addScalar("isActive", StringType.INSTANCE)
				.addScalar("memberId", IntegerType.INSTANCE)
				.addScalar("memberType", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("createdBy", StringType.INSTANCE)
				.addScalar("createdDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GroupMemberDetailView.class));
		
		return query.list();
	}

	public GroupDetailView getGroupById(Integer groupId) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biGroup.id as id,biGroup.Name as name,biGroup.IsActive as isActive,biGroup.Description as description,")
			   .append("biGroup.CreatedBy as createdBy,biGroup.CreatedDate as createdDate")
			   .append( " from BI_Group biGroup");
	    sBuffer.append(" where biGroup.id=").append(groupId);
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("isActive", StringType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("createdBy", StringType.INSTANCE)
				.addScalar("createdDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GroupDetailView.class));
		
		return (GroupDetailView)query.list().get(0);
	}
	
	
	
	@Override
	public List<KeyNameObject> getCompanyList() {
		StringBuffer sBuffer = new StringBuffer();
		   sBuffer.append("select company.id as objKey,company.Name as objName")
		   .append(" from PASSPORT_Company company");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}
	
	@Override
	public List<KeyNameObject> getBuList() {
		StringBuffer sBuffer = new StringBuffer();
		   sBuffer.append("select bu.id as objKey,bu.Name as objName")
		   .append(" from Passport_BusinessUnit bu");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}
	
	@Override
	public List<CompanyDetailView> queryCompanyByConditions(String companyName) {
		StringBuffer sBuffer = new StringBuffer();
		   sBuffer.append("select company.Id as id,company.Name as name")
		   			.append(" from PASSPORT_Company company")
		   			.append(" where company.Name like '%")
		   			.append(companyName)
		   			.append("%'")
		   			;
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(CompanyDetailView.class));
		//query.setString(0, companyName);
		
		return query.list();
	}
	
	@Override
	public List<BuDetailView>  queryBuByConditions(String compId,String buName) {
		StringBuffer sBuffer = new StringBuffer();
		   sBuffer.append("select bu.Id as id,bu.Name as name,company.Name as companyName")
		   			.append(" from Passport_BusinessUnit bu");
		   
		   sBuffer.append(" left join PASSPORT_Company company")
		   			.append(" on bu.CompanyId = company.Id");
		  		
		   sBuffer.append(" where bu.Name like '%")
		   			.append(buName)
		   			.append("%'");
   		   if(!StringUtil.isEmpty(compId)) {
			   sBuffer.append(" and company.id =")
			   			.append(Integer.parseInt(compId));
		   }	
   			
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("companyName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BuDetailView.class));
		
		return query.list();
	}
	
	public List<DepartmentDetailView>  queryDepByConditions(String compId,String buId,String depName) {
		StringBuffer sBuffer = new StringBuffer();
		   sBuffer.append("select dep.Id as id,dep.Name as name,company.Name as companyName,bu.Name as buName")
		   			.append(" from PASSPORT_Department dep");
		   
		   sBuffer.append(" left join PASSPORT_Company company")
		   			.append(" on dep.CompanyId = company.Id");
		   
		   sBuffer.append(" left join Passport_BusinessUnit bu")
  					.append(" on dep.BusinessUnitId = bu.Id");
		  		
		   sBuffer.append(" where dep.Name like '%")
		   			.append(depName)
		   			.append("%'");
		   if(!StringUtil.isEmpty(compId)) {
			   sBuffer.append(" and company.id =")
			   			.append(Integer.parseInt(compId));
		   }
		   if(!StringUtil.isEmpty(buId)) {
			   sBuffer.append(" and bu.id =")
			   			.append(Integer.parseInt(buId));
		   }
			
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("companyName", StringType.INSTANCE)
				.addScalar("buName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(DepartmentDetailView.class));
		
		return query.list();
	}
	
	public List<UserDetailView>  queryUserByConditions(String companyName,String buName,String depName,String userName) {
		StringBuffer sBuffer = new StringBuffer();
		   sBuffer.append("select puser.Id as id,puser.UserId as name,puser.DisplayName as displayName,puser.EmailAddress as emailAddress,")
		   			.append("depBuCompany.companyName as companyName,depBuCompany.buName as buName,depBuCompany.depName as depName")
		   			.append(" from PASSPORT_User puser");
		   sBuffer.append(" join Passport_Department_User depUser on depUser.UserId = puser.Id");
		   sBuffer.append(" join (")
					.append(" select dep.id as depId,dep.Name as depName,company.id as companyId,company.Name as companyName, bu.id as buId,bu.Name as buName")
		   			.append(" from Passport_Department dep")
		   			.append(" left join Passport_BusinessUnit bu on dep.BusinessUnitId = bu.id")
					.append(" left join PASSPORT_Company company on dep.CompanyId = company.id")
					.append(" where company.Name like '%").append(companyName).append("%'")
					.append(" and bu.Name  like '%").append(buName).append("%'")
					.append(" and dep.Name  like '%").append(depName).append("%'")
				  .append(")depBuCompany")
		   		  .append(" on depUser.DepartmentId = depBuCompany.depId");	 	
		   sBuffer.append(" where puser.UserId like '%").append(userName).append("%'");
			
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("companyName", StringType.INSTANCE)
				.addScalar("buName", StringType.INSTANCE)
				.addScalar("depName", StringType.INSTANCE)
				.addScalar("emailAddress", StringType.INSTANCE)
				.addScalar("displayName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(UserDetailView.class));
		
		return query.list();
	}
}
