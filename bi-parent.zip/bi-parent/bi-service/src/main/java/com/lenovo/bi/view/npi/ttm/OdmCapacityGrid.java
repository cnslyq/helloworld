package com.lenovo.bi.view.npi.ttm;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * 
 * @author henry_lian
 *
 */
public class OdmCapacityGrid {

	private int demand;
	private int gap;
	private int totalCapacity;
	private String weekDate;
	private List<OdmCapacity> odmCapacity = new ArrayList<OdmCapacity>();
	
	public int getDemand() {
		return demand;
	}
	public void setDemand(int demand) {
		this.demand = demand;
	}
	public List<OdmCapacity> getOdmCapacity() {
		return odmCapacity;
	}
	public void setOdmCapacity(List<OdmCapacity> odmCapacity) {
		this.odmCapacity = odmCapacity;
	}
	public String getWeekDate() {
		return weekDate;
	}
	public void setWeekDate(String weekDate) {
		this.weekDate = weekDate;
	}
	public int getGap() {
		return gap;
	}
	public void setGap(int gap) {
		this.gap = gap;
	}
	public int getTotalCapacity() {
		return totalCapacity;
	}
	public void setTotalCapacity(int totalCapacity) {
		this.totalCapacity = totalCapacity;
	}
}
