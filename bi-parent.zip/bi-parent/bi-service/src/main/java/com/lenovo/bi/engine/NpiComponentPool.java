package com.lenovo.bi.engine;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.NpiDnsEntry;
import com.lenovo.bi.enumobj.DnsShortageCodeEnum;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;

public class NpiComponentPool {
	private Map<Integer, List<NpiDnsEntry>> dnsMap = new HashMap<Integer,  List<NpiDnsEntry>>();
	
	private List<Integer> cvKeyList;
	
	private Map<Integer,Map<Integer,DnsShortageCodeEnum>> shortageMap;
	
	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	
	private Date versionDate;
	public NpiComponentPool(TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper, Date versionDate) {
		super();
		this.ttvOutlookServiceDwHelper = ttvOutlookServiceDwHelper;
		this.versionDate = versionDate;
	}
	
	

	public Map<Integer, Map<Integer, DnsShortageCodeEnum>> getShortageMap() {
		return shortageMap;
	}



	public void setShortageMap(
			Map<Integer, Map<Integer, DnsShortageCodeEnum>> shortageMap) {
		this.shortageMap = shortageMap;
	}



	public List<Integer> getCvKeyList() {
		return cvKeyList;
	}

	public void setCvKeyList(List<Integer> cvKeyList) {
		this.cvKeyList = cvKeyList;
	}

	public Map<Integer, List<NpiDnsEntry>> getDnsMap() {
		return dnsMap;
	}

	public void setDnsMap(Map<Integer, List<NpiDnsEntry>> dnsMap) {
		this.dnsMap = dnsMap;
	}

	public TTVOutlookServiceDwHelper getTtvOutlookServiceDwHelper() {
		return ttvOutlookServiceDwHelper;
	}
	public void setTtvOutlookServiceDwHelper(
			TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper) {
		this.ttvOutlookServiceDwHelper = ttvOutlookServiceDwHelper;
	}
	public Date getVersionDate() {
		return versionDate;
	}
	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}
	/**
	 * 初始化dnslist，取13周的dns
	 * @param versionDate
	 */
	public void initializePool(Date versionDate) {
		// TODO Auto-generated method stub
		cvKeyList=ttvOutlookServiceDwHelper.getDnsCvKeyList(versionDate);
		for(Integer cvKey : cvKeyList ){
		List<NpiDnsEntry> entryList = ttvOutlookServiceDwHelper.getDnsList(versionDate,cvKey);
		dnsMap.put(cvKey, entryList);
		}
	}
	
}
