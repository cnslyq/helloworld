package com.lenovo.bi.view.npi.chart.column;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;

public class DataSetLine extends DataSetParent {

	private String parentYaxis;
	private String renderas;
	private String color;
	private String drawAnchors;
	private List<ColumnData> dataList;
	
	public String getParentYaxis() {
		return parentYaxis;
	}

	public void setParentYaxis(String parentYaxis) {
		this.parentYaxis = parentYaxis;
	}

	public List<ColumnData> getDataList() {
		return dataList;
	}

	@JsonProperty("data")
	public void setDataList(List<ColumnData> dataList) {
		this.dataList = dataList;
	}

	public String getRenderas() {
		return renderas;
	}

	public void setRenderas(String renderas) {
		this.renderas = renderas;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getDrawAnchors() {
		return drawAnchors;
	}

	public void setDrawAnchors(String drawAnchors) {
		this.drawAnchors = drawAnchors;
	}
	
}
