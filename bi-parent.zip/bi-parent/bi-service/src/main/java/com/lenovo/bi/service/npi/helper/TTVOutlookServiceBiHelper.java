package com.lenovo.bi.service.npi.helper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.impl.ForecastDataDaoImpl;
import com.lenovo.bi.dao.impl.OrderDataDaoImpl;
import com.lenovo.bi.dao.impl.WeeklyComponentCommitmentOnMtmCtoDaoImpl;
import com.lenovo.bi.dao.impl.WeeklyComponentCommitmentOnOrderForecastDaoImpl;
import com.lenovo.bi.dao.npi.NpiOrderDaoBi;
import com.lenovo.bi.dao.npi.NpiWeeklyComponentCommitmentOnProductDao;
import com.lenovo.bi.dao.npi.impl.BiWeeklyProcessStatusDaoImpl;
import com.lenovo.bi.dao.npi.impl.EtlDailyStatusDaoImpl;
import com.lenovo.bi.dao.npi.impl.EtlWeeklyStatusDaoImpl;
import com.lenovo.bi.dao.npi.impl.OrderDaoImpl;
import com.lenovo.bi.dao.npi.impl.SGATtvWeeklyDetailDaoImpl;
import com.lenovo.bi.dao.npi.impl.SGATtvWeeklySummaryDaoImpl;
import com.lenovo.bi.dao.npi.impl.TtvDailyDetailDaoImpl;
import com.lenovo.bi.dao.npi.impl.TtvDailySummaryDaoImpl;
import com.lenovo.bi.dao.npi.impl.TtvWeeklyDetailDaoImpl;
import com.lenovo.bi.dao.npi.impl.TtvWeeklySummaryDaoImpl;
import com.lenovo.bi.dto.SupplyShortage;
import com.lenovo.bi.enumobj.ForecastComparisonTypeEnum;
import com.lenovo.bi.enumobj.JobStatusEnum;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.BiWeeklyProcessStatus;
import com.lenovo.bi.model.EtlDailyStatus;
import com.lenovo.bi.model.EtlWeeklyStatus;
import com.lenovo.bi.model.ForecastData;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnProduct;
import com.lenovo.bi.model.OrderData;
import com.lenovo.bi.model.SGATtvWeeklyDetail;
import com.lenovo.bi.model.SGATtvWeeklySummary;
import com.lenovo.bi.model.TtvDailyDetail;
import com.lenovo.bi.model.TtvDailySummary;
import com.lenovo.bi.model.TtvWeeklyDetail;
import com.lenovo.bi.model.TtvWeeklySummary;
import com.lenovo.bi.model.WeeklyComponentCommitmentOnMtmCto;
import com.lenovo.bi.model.WeeklyComponentCommitmentOnOrderForecast;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.CollectionUtil;
import com.lenovo.bi.util.MathUtil;

@Service
@Transactional("bi")
public class TTVOutlookServiceBiHelper {
	@Autowired
	private TtvWeeklyDetailDaoImpl ttvWeeklyDetailDao;

	@Autowired
	private SGATtvWeeklyDetailDaoImpl sgaTtvWeeklyDetailDao;

	@Autowired
	private TtvDailyDetailDaoImpl ttvDailyDetailDao;

	@Autowired
	private TtvWeeklySummaryDaoImpl ttvWeeklySummaryDao;

	@Autowired
	private SGATtvWeeklySummaryDaoImpl sgaTtvWeeklySummaryDao;

	@Autowired
	private TtvDailySummaryDaoImpl ttvDailySummaryDao;

	@Inject
	private NpiOrderDaoBi npiOrderDaoBi;

	@Autowired
	private OrderDaoImpl orderDaoImpl;

	@Autowired
	private EtlWeeklyStatusDaoImpl etlWeeklyStatusDao;

	@Autowired
	private EtlDailyStatusDaoImpl etlDailyStatusDao;

	@Autowired
	private BiWeeklyProcessStatusDaoImpl biWeeklyProcessStatusDao;

	@Autowired
	private OrderDataDaoImpl orderDataDao;

	@Autowired
	private ForecastDataDaoImpl forecastDataDao;

	@Autowired
	private WeeklyComponentCommitmentOnMtmCtoDaoImpl weeklyComponentCommitmentOnMtmCtoDao;

	@Autowired
	private WeeklyComponentCommitmentOnOrderForecastDaoImpl WeeklyComponentCommitmentOnOrderForecastDao;
	
	@Autowired
	private NpiWeeklyComponentCommitmentOnProductDao npiWeeklyComponentCommitmentOnProductDao;
	
	public List<TtvWeeklyDetail> getNpiWeeklyDetail(int pmsWaveId, Date versionDate) {
		return ttvWeeklyDetailDao.getNpiWeeklyDetail(pmsWaveId, versionDate);
	}

	public List<SGATtvWeeklyDetail> getSgaNpiWeeklyDetail(int pmsWaveId, Date versionDate) {
		return sgaTtvWeeklyDetailDao.getNpiWeeklyDetail(pmsWaveId, versionDate);
	}

	public List<TtvDailyDetail> getNpiDailyDetail(int pmsWaveId) {
		return ttvDailyDetailDao.getNpiDailyDetail(pmsWaveId);
	}

	public List<TtvWeeklyDetail> getNpiWeeklyDetail(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		return ttvWeeklyDetailDao.getNpiWeeklyDetail(pmsWaveId, startDate, endDate, versionDate);
	}
	
	public List<TtvWeeklyDetail> getLastNpiWeeklyDetail(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		return ttvWeeklyDetailDao.getLastNpiWeeklyDetail(pmsWaveId, startDate, endDate, versionDate);
	}

	public List<SGATtvWeeklyDetail> getSgaNpiWeeklyDetail(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		return sgaTtvWeeklyDetailDao.getNpiWeeklyDetail(pmsWaveId, startDate, endDate, versionDate);
	}
	
	public List<SGATtvWeeklyDetail> getLastSgaNpiWeeklyDetail(int pmsWaveId, Date ssDate, Date startDate, Date endDate, Date versionDate) {
		return sgaTtvWeeklyDetailDao.getLastNpiWeeklyDetail(pmsWaveId, ssDate, startDate, endDate, versionDate);
	}

	public List<TtvDailyDetail> getNpiDailyDetail(int pmsWaveId, Date startDate, Date endDate) {
		return ttvDailyDetailDao.getNpiDailyDetail(pmsWaveId, startDate, endDate);
	}

	public List<Integer> getPmsWaveIdsForWeeklyVersionDate(Date versionDate) {
		return ttvWeeklyDetailDao.getPmsWaveIdsForVersionDate(versionDate);
	}
	public Date getMaxSleVersionDateByWaveId(String waveId) {
		return ttvWeeklyDetailDao.getMaxVersionDateByWaveId(waveId);
	}
	public Date getMaxSgaVersionDateByWaveId(String waveId) {
		return sgaTtvWeeklyDetailDao.getMaxVersionDateByWaveId(waveId);
	}
	public List<Integer> getSGAPmsWaveIdsForWeeklyVersionDate(Date versionDate) {
		return sgaTtvWeeklyDetailDao.getPmsWaveIdsForVersionDate(versionDate);
	}
	/*public void test(String str) {
		 sgaTtvWeeklyDetailDao.test(str);
		 sgaTtvWeeklyDetailDao.test(str);
	}*/
	public Map<String,Integer> getSleTTVDemandByWaveId(String waveId,String versionDate,String startDate,String endDate){
		List<Object[]>list=ttvWeeklyDetailDao.getTTVDemandByWaveId(waveId, versionDate, startDate, endDate);
		Map<String,Integer>map=new HashMap<String,Integer>();
		for(Object[] obj:list){
			try {
				map.put(CalendarUtil.date2String((Date) obj[0]), (Integer)obj[1]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return map;
	}
	public Map<String,Integer> getSgaTTVDemandByWaveId(String waveId,String versionDate,String startDate,String endDate){
		List<Object[]>list=sgaTtvWeeklyDetailDao.getTTVDemandByWaveId(waveId, versionDate, startDate, endDate);
		Map<String,Integer>map=new HashMap<String,Integer>();
		for(Object[] obj:list){
			try {
				map.put(CalendarUtil.date2String((Date)obj[0]), (Integer)obj[1]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return map;
	}
	public List<Integer> getPmsWaveIdsForDailyVersionDate(Date versionDate) {
		return ttvDailyDetailDao.getPmsWaveIdsForVersionDate(versionDate);
	}

	public List<TtvWeeklySummary> getNpiWeeklySummary(int pmsWaveId) {
		return ttvWeeklySummaryDao.getNpiWeeklySummary(pmsWaveId);
	}

	public List<TtvDailySummary> getNpiDailySummary(int pmsWaveId) {
		return ttvDailySummaryDao.getNpiDailySummary(pmsWaveId);
	}

	public List<TtvWeeklySummary> getNpiWeeklySummary(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		return ttvWeeklySummaryDao.getNpiWeeklySummary(pmsWaveId, startDate, endDate, versionDate);
	}
	
	public List<TtvWeeklySummary> getLastNpiWeeklySummary(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		return ttvWeeklySummaryDao.getLastNpiWeeklySummary(pmsWaveId, startDate, endDate, versionDate);
	}

	public List<SGATtvWeeklySummary> getSgaNpiWeeklySummary(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		return sgaTtvWeeklySummaryDao.getNpiWeeklySummary(pmsWaveId, startDate, endDate, versionDate);
	}
	public List<SGATtvWeeklySummary> getLastSgaNpiWeeklySummary(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		return sgaTtvWeeklySummaryDao.getLastNpiWeeklySummary(pmsWaveId, startDate, endDate, versionDate);
	}
	public void deleteSgaTtvWeeklySummaryByWaveId(int pmsWaveId, Date versionDate){
		sgaTtvWeeklySummaryDao.deleteSgaTtvWeeklySummaryByWaveId(pmsWaveId, versionDate);
	}
	public List<TtvDailySummary> getNpiDailySummary(int pmsWaveId, Date startDate, Date endDate) {
		return ttvDailySummaryDao.getNpiDailySummary(pmsWaveId, startDate, endDate);
	}

	public TtvWeeklySummary getPreviousWeeklySummary(int pmsWaveId, Date targetDate) {
		return ttvWeeklySummaryDao.getPreviousWeeklySummary(pmsWaveId, targetDate);
	}

	public TtvDailySummary getPreviousDailySummary(int pmsWaveId, Date targetDate) {
		return ttvDailySummaryDao.getPreviousDailySummary(pmsWaveId, targetDate);
	}

	public List<NpiOrder> getTTVExcludedOrder(int pmsWaveId, TTVPhase ttvPhase, Date versionDate) {
		return npiOrderDaoBi.getTTVExcludedOrder(pmsWaveId, ttvPhase, versionDate);
	}

	public List<NpiOrder> getTTVAllExcludedOrders(TTVPhase ttvPhase, Date versionDate) {
		return npiOrderDaoBi.getTTVAllExcludedOrders(ttvPhase, versionDate);
	}

	public List<NpiOrder> getTTVExcludedOrderInWeek(Date targetDate, Date versionDate, TTVPhase ttvPhase) {
		return npiOrderDaoBi.getTTVExcludedOrderInWeek(targetDate, versionDate, ttvPhase);
	}

	public void deleteAllNpiWeeklySummary(int pmsWaveId) {
		ttvWeeklySummaryDao.deleteTtvWeeklySummaryAfter(pmsWaveId, null);
	}

	public void deleteAllNpiDailySummary(int pmsWaveId) {
		ttvDailySummaryDao.deleteTtvDailySummaryAfter(pmsWaveId, null);
	}

	public void deleteNpiWeeklySummaryAfter(int pmsWaveId, Date targetDate) {
		ttvWeeklySummaryDao.deleteTtvWeeklySummaryAfter(pmsWaveId, targetDate);
	}

	public void deleteNpiDailySummaryAfter(int pmsWaveId, Date targetDate) {
		ttvDailySummaryDao.deleteTtvDailySummaryAfter(pmsWaveId, targetDate);
	}

	public void deleteTtvWeeklySummaryForVersionDate(Date versionDate) {
		ttvWeeklySummaryDao.deleteTtvWeeklySummaryForVersionDate(versionDate);
	}

	public void clearSGATtvWeeklySummary(Date versionDate) {
		sgaTtvWeeklySummaryDao.deleteTtvWeeklySummaryForVersionDate(versionDate);
	}

	public void deleteSGATtvWeeklySummaryForVersionDate(Date versionDate) {
		sgaTtvWeeklySummaryDao.deleteTtvWeeklySummaryForVersionDate(versionDate);
	}

	public void deleteWeeklyComponentCommitmentOnMtmCtoForVersionDate(Date versionDate) {
		weeklyComponentCommitmentOnMtmCtoDao.deleteWeeklyComponentCommitmentOnMtmCtoForVersionDate(versionDate);
	}

	public void deleteWeeklyComponentCommitmentOnOrderForecastForVersionDate(Date versionDate) {
		WeeklyComponentCommitmentOnOrderForecastDao.deleteWeeklyComponentCommitmentOnOrderForecastForVersionDate(versionDate);
	}
	public List<SupplyShortage> getSupplyShortageByProductKey(String productKey, Date versionDate, Date startDate, Date endDate, String ttvPhase){
		return WeeklyComponentCommitmentOnOrderForecastDao.querySupplyShortageByProductKey(productKey, versionDate, startDate, endDate, ttvPhase);
	}
	public List<SupplyShortage> queryBomNumberByProductKey(String productKey, Date versionDate, Date startDate, Date endDate, String ttvPhase){
		return WeeklyComponentCommitmentOnOrderForecastDao.queryBomNumberByProductKey(productKey, versionDate, startDate, endDate, ttvPhase);
	}
	public void deleteOrderDataForVersionDate(Date versionDate) {
		orderDataDao.deleteOrderDataForVersionDate(versionDate);
	}

	public void deleteForecastDataForVersionDate(Date versionDate) {
		forecastDataDao.deleteForecastDataForVersionDate(versionDate);
	}

	@Transactional(value = "bi", propagation = Propagation.REQUIRES_NEW)
	public void addBiWeeklyProcessStatus(BiWeeklyProcessStatus biWeeklyProcessStatus) {
		biWeeklyProcessStatusDao.add(biWeeklyProcessStatus);
	}

	@Transactional(value = "bi", propagation = Propagation.REQUIRES_NEW)
	public void updateBiWeeklyProcessStatus(BiWeeklyProcessStatus biWeeklyProcessStatus) {
		biWeeklyProcessStatusDao.update(biWeeklyProcessStatus);
	}

	public void addNpiWeeklySummery(TtvWeeklySummary ttvWeeklySummary) {
		ttvWeeklySummaryDao.add(ttvWeeklySummary);
	}

	public void addNpiDailySummery(TtvDailySummary ttvDailySummary) {
		ttvDailySummaryDao.add(ttvDailySummary);
	}

	public void updateNpiWeeklyDetail(TtvWeeklyDetail ttvWeeklyDetail) {
		ttvWeeklyDetail.setLastModifiedDate(new Date());
		ttvWeeklyDetailDao.update(ttvWeeklyDetail);
	}

	public void updateSGANpiWeeklyDetail(SGATtvWeeklyDetail ttvWeeklyDetail) {
		ttvWeeklyDetail.setLastModifiedDate(new Date());
		sgaTtvWeeklyDetailDao.update(ttvWeeklyDetail);
	}

	public void updateNpiWeeklyDetail(List<TtvWeeklyDetail> ttvWeeklyDetails) {
		for (TtvWeeklyDetail ttvWeeklyDetail : ttvWeeklyDetails) {
			ttvWeeklyDetail.setLastModifiedDate(new Date());
			ttvWeeklyDetailDao.update(ttvWeeklyDetail);
		}
	}

	public void updateSGANpiWeeklyDetail(List<SGATtvWeeklyDetail> ttvWeeklyDetails) {

		for (SGATtvWeeklyDetail ttvWeeklyDetail : ttvWeeklyDetails) {
			ttvWeeklyDetail.setLastModifiedDate(new Date());
			sgaTtvWeeklyDetailDao.update(ttvWeeklyDetail);
		}
	}

	public void addSGANpiWeeklySummary(List<SGATtvWeeklySummary> ttvWeeklySummaries) {
		for (SGATtvWeeklySummary summary : ttvWeeklySummaries) {
			sgaTtvWeeklySummaryDao.add(summary);
		}
	}

	public void setOutput(List<SGATtvWeeklyDetail> ttvWeeklyDetails, Date versionDate) {
		for (SGATtvWeeklyDetail ttvWeeklyDetail : ttvWeeklyDetails) {
			Integer output = ttvWeeklyDetail.getFgQuantity();
			Integer tdmsOutput = ttvWeeklyDetail.getFgQuantity();

			if (!versionDate.after(ttvWeeklyDetail.getTargetDate())) {

				Integer coverA = ttvWeeklyDetail.getCoverA();
				Integer coverB = ttvWeeklyDetail.getCoverB();
				Integer coverC = ttvWeeklyDetail.getCoverC();
				Integer coverD = ttvWeeklyDetail.getCoverD();
				Integer supplyCapacity = ttvWeeklyDetail.getSupplyCommit();
				Integer odmCapacity = ttvWeeklyDetail.getOdmRpyCapacity();
				Integer tdmsCapacity = ttvWeeklyDetail.getTdmsRpyCapacity();
				Integer rampCommit = ttvWeeklyDetail.getRampCommit();

				List<Integer> odmCalParticipants = new ArrayList<Integer>();
				List<Integer> tdmsCalParticipants = new ArrayList<Integer>();
				if (coverA != -1) {
					odmCalParticipants.add(coverA);
					tdmsCalParticipants.add(coverA);
				}
				if (coverB != -1) {
					odmCalParticipants.add(coverB);
					tdmsCalParticipants.add(coverB);
				}
				if (coverC != -1) {
					odmCalParticipants.add(coverC);
					tdmsCalParticipants.add(coverC);
				}
				if (coverD != -1) {
					odmCalParticipants.add(coverD);
					tdmsCalParticipants.add(coverD);
				}
				if (supplyCapacity != -1) {
					odmCalParticipants.add(supplyCapacity);
					tdmsCalParticipants.add(supplyCapacity);
				}
				if (odmCapacity != -1) {
					odmCalParticipants.add(odmCapacity);
				}
				if (tdmsCapacity != -1) {
					tdmsCalParticipants.add(tdmsCapacity);
				}

				odmCalParticipants.add(rampCommit);
				tdmsCalParticipants.add(rampCommit);

				output = MathUtil.min(odmCalParticipants);
				tdmsOutput = MathUtil.min(tdmsCalParticipants);
			}

			ttvWeeklyDetail.setOutput(output);
			ttvWeeklyDetail.setTdmsOutput(tdmsOutput);
		}
	}

	public void setToGoForecast(List<SGATtvWeeklyDetail> ttvWeeklyDetails) {

		int i = 0;
		for (; i < ttvWeeklyDetails.size(); i++) {
			SGATtvWeeklyDetail ttvWeeklyDetail = ttvWeeklyDetails.get(i);
			if (i == 0) {
				ttvWeeklyDetail.setToGoForecast(ttvWeeklyDetail.getForecast());
				ttvWeeklyDetail.setTdmsToGoForecast(ttvWeeklyDetail.getForecast());
			} else {
				SGATtvWeeklyDetail preTtvWeeklyDetail = ttvWeeklyDetails.get(i - 1);
				Integer toGoFst = ttvWeeklyDetail.getForecast() + preTtvWeeklyDetail.getToGoForecast() - preTtvWeeklyDetail.getOutput();
				if (toGoFst < 0) {
					toGoFst = 0;
				}
				Integer tdmsToGoFst = ttvWeeklyDetail.getForecast() + preTtvWeeklyDetail.getTdmsToGoForecast() - preTtvWeeklyDetail.getTdmsOutput();
				if (tdmsToGoFst < 0) {
					tdmsToGoFst = 0;
				}
				ttvWeeklyDetail.setToGoForecast(toGoFst);
				ttvWeeklyDetail.setTdmsToGoForecast(tdmsToGoFst);

			}
		}
	}

	public void excludeOrders(List<?> ttvWeeklyDetails, List<NpiOrder> excludeOrders) {
		if (ttvWeeklyDetails != null && ttvWeeklyDetails.size() > 0) {
			for (int i = 0; i < ttvWeeklyDetails.size(); i++) {
				Object o = ttvWeeklyDetails.get(i);
				if (o instanceof SGATtvWeeklyDetail) {
					SGATtvWeeklyDetail ttvWeeklyDetail = (SGATtvWeeklyDetail) o;
					Date targetDate = ttvWeeklyDetail.getTargetDate();
					Integer orderQuantity = ttvWeeklyDetail.getOrderQuantity();
					Date orderDateFrom = CalendarUtil.getMondayDateByDate(targetDate);
					Date orderDateTo = CalendarUtil.getSundayDateByDate(targetDate);
					if (excludeOrders != null && excludeOrders.size() > 0) {
						for (NpiOrder npiOrder : excludeOrders) {
							Date orderDate = npiOrder.getOrderDate();
							Integer quantity = npiOrder.getQuantity() == null ? 0 : npiOrder.getQuantity();
							if (i == 0){
								if (orderDate.compareTo(orderDateFrom) < 0) {
									orderQuantity -= quantity;
								}
							} else{
								if (orderDate.compareTo(orderDateFrom) >= 0 && orderDate.compareTo(orderDateTo) <= 0) {
									orderQuantity -= quantity;
								}
							}
							
						}
					}
					ttvWeeklyDetail.setOrderQuantity(orderQuantity < 0 ? 0 : orderQuantity);
				} else {
					TtvWeeklyDetail ttvWeeklyDetail = (TtvWeeklyDetail) o;
					Date targetDate = ttvWeeklyDetail.getTargetDate();
					Integer orderQuantity = ttvWeeklyDetail.getOrderQuantity();
					Date orderDateFrom = CalendarUtil.getMondayDateByDate(targetDate);
					Date orderDateTo = CalendarUtil.getSundayDateByDate(targetDate);
					if (excludeOrders != null && excludeOrders.size() > 0) {
						for (NpiOrder npiOrder : excludeOrders) {
							Date orderDate = npiOrder.getOrderDate();
							Integer quantity = npiOrder.getQuantity() == null ? 0 : npiOrder.getQuantity();
							if (i == 0){
								if (orderDate.compareTo(orderDateFrom) < 0) {
									orderQuantity -= quantity;
								}
							} else{
								if (orderDate.compareTo(orderDateFrom) >= 0 && orderDate.compareTo(orderDateTo) <= 0) {
									orderQuantity -= quantity;
								}
							}
						}
					}
					ttvWeeklyDetail.setOrderQuantity(orderQuantity < 0 ? 0 : orderQuantity);
				}

			}

		}
	}

	@Deprecated
	public void excludeOrder(Integer pmsWaveId, List<SGATtvWeeklyDetail> ttvWeeklyDetails) {
		// List<NPIPhase> phases = npiPhaseDao.getNPIPhase(new String[] { "SS",
		// "SGA" }, pmsWaveId);
		// if (phases == null || phases.size() != 2) {
		// return;
		// }
		// Date sgaDate =
		// CalendarUtil.getMondayDateByDate(phases.get(1).getPlanDate());
		//
		// int i = 0;
		// for (; i < ttvWeeklyDetails.size(); i++) {
		// SGATtvWeeklyDetail ttvWeeklyDetail = ttvWeeklyDetails.get(i);
		// Date targetDate = ttvWeeklyDetail.getTargetDate();
		// Date versionDate = ttvWeeklyDetail.getVersionDate();
		// Integer orderQuantity = ttvWeeklyDetail.getOrderQuantity();
		//
		// List<Order> orders = null;
		// List<NpiOrder> excludeOrders = null;
		// if (i == 0) {
		// Date orderDateTo = CalendarUtil.getSundayDateByDate(targetDate);
		// orders = orderDaoImpl.getOrders(pmsWaveId, versionDate, sgaDate,
		// null, null, orderDateTo);
		// excludeOrders = npiOrderDaoBi.getExcludedOrder(pmsWaveId, null,
		// orderDateTo, true);
		// } else {
		// orders = orderDaoImpl.getOrders(pmsWaveId, versionDate, sgaDate,
		// null, targetDate);
		// excludeOrders = npiOrderDaoBi.getExcludedOrder(pmsWaveId, targetDate,
		// true);
		// }
		//
		// if (orders == null) {
		// orders = new ArrayList<Order>();
		// }
		// if (excludeOrders != null && excludeOrders.size() > 0) {
		// for (NpiOrder npiOrder : excludeOrders) {
		// String poNumber = npiOrder.getPoNumber();
		// String poItem = npiOrder.getPoItem();
		// Integer quantity = npiOrder.getQuantity() == null ? 0 :
		// npiOrder.getQuantity();
		// Date orderDate = npiOrder.getOrderDate();
		// Date rsdDate = npiOrder.getRsdDate();
		// boolean isInclude = false;
		// for (Order order : orders) {
		// if (npiOrder.getPoNumber().equals(order.getPoNumber()) &&
		// npiOrder.getPoItem().equals(order.getPoItem())) {
		// isInclude = true;
		// break;
		// }
		// }
		// if (!isInclude) {
		// Order order = new Order();
		// order.setPoNumber(poNumber);
		// order.setPoItem(poItem);
		// order.setQuantity(quantity);
		// order.setOrderDate(orderDate);
		// order.setRsd(rsdDate);
		// orders.add(order);
		// }
		// }
		// }
		//
		// for (Order order : orders) {
		// orderQuantity -= order.getQuantity();
		// }
		//
		// ttvWeeklyDetail.setOrderQuantity(orderQuantity < 0 ? 0 :
		// orderQuantity);
		//
		// }
	}

	public void setToGoOrder(List<SGATtvWeeklyDetail> ttvWeeklyDetails) {

		int i = 0;
		for (; i < ttvWeeklyDetails.size(); i++) {
			SGATtvWeeklyDetail ttvWeeklyDetail = ttvWeeklyDetails.get(i);
			Integer toGoOrder = 0;
			Integer tdmsToGoOrder = 0;
			if (i == 0) {
				toGoOrder = ttvWeeklyDetail.getOrderQuantity();
				tdmsToGoOrder = toGoOrder;
			} else if (i == 1) {
				SGATtvWeeklyDetail preTtvWeeklyDetail = ttvWeeklyDetails.get(0);
				Integer toGoOrderTempt = preTtvWeeklyDetail.getToGoOrder() == null ? 0 : preTtvWeeklyDetail.getToGoOrder();
				Integer output = preTtvWeeklyDetail.getOutput() == null ? 0 : preTtvWeeklyDetail.getOutput();
				Integer tdmsToGoOrderTempt = preTtvWeeklyDetail.getTdmsToGoOrder() == null ? 0 : preTtvWeeklyDetail.getTdmsToGoOrder();
				Integer tdmsOutput = preTtvWeeklyDetail.getTdmsOutput() == null ? 0 : preTtvWeeklyDetail.getTdmsOutput();
				toGoOrder = toGoOrderTempt - output;
				tdmsToGoOrder = tdmsToGoOrderTempt - tdmsOutput;
			} else {
				SGATtvWeeklyDetail preTtvWeeklyDetail = ttvWeeklyDetails.get(i - 1);
				Integer orderQuantity = preTtvWeeklyDetail.getOrderQuantity() == null ? 0 : preTtvWeeklyDetail.getOrderQuantity();
				Integer toGoOrderTempt = preTtvWeeklyDetail.getToGoOrder() == null ? 0 : preTtvWeeklyDetail.getToGoOrder();
				Integer output = preTtvWeeklyDetail.getOutput() == null ? 0 : preTtvWeeklyDetail.getOutput();
				Integer tdmsToGoOrderTempt = preTtvWeeklyDetail.getTdmsToGoOrder() == null ? 0 : preTtvWeeklyDetail.getTdmsToGoOrder();
				Integer tdmsOutput = preTtvWeeklyDetail.getTdmsOutput() == null ? 0 : preTtvWeeklyDetail.getTdmsOutput();

				toGoOrder = orderQuantity + toGoOrderTempt - output;
				tdmsToGoOrder = orderQuantity + tdmsToGoOrderTempt - tdmsOutput;
			}
			if (toGoOrder < 0) {
				toGoOrder = 0;
			}
			if (tdmsToGoOrder < 0) {
				tdmsToGoOrder = 0;
			}
			ttvWeeklyDetail.setToGoOrder(toGoOrder);
			ttvWeeklyDetail.setTdmsToGoOrder(tdmsToGoOrder);
		}
	}

	public void addOrderData(OrderData orderData) {
		orderDataDao.add(orderData);
	}

	public void addOrderData(List<OrderData> orderDataList) {
		for (OrderData orderData : orderDataList) {
			orderDataDao.add(orderData);
		}
	}

	public void addForecastData(ForecastData forecastData) {
		forecastDataDao.add(forecastData);
	}

	public void addForecastData(List<ForecastData> forecastDataList) {
		for (ForecastData forecastData : forecastDataList) {
			forecastDataDao.add(forecastData);
		}
	}

	public void addWeeklyComponentCommitmentOnMtmCto(WeeklyComponentCommitmentOnMtmCto commitment) {
		weeklyComponentCommitmentOnMtmCtoDao.add(commitment);
	}

	public void addWeeklyComponentCommitmentOnMtmCto(List<WeeklyComponentCommitmentOnMtmCto> commitments) {
		for (WeeklyComponentCommitmentOnMtmCto commitment : commitments) {
			weeklyComponentCommitmentOnMtmCtoDao.add(commitment);
		}
	}

	public void addWeeklyComponentCommitmentOnOrderForecast(WeeklyComponentCommitmentOnOrderForecast weeklyComponentCommitmentOnOrderForecast) {
		WeeklyComponentCommitmentOnOrderForecastDao.add(weeklyComponentCommitmentOnOrderForecast);
	}

	public void addWeeklyComponentCommitmentOnOrderForecast(List<WeeklyComponentCommitmentOnOrderForecast> weeklyComponentCommitmentOnOrderForecast) {
		for (WeeklyComponentCommitmentOnOrderForecast commitment : weeklyComponentCommitmentOnOrderForecast) {
			WeeklyComponentCommitmentOnOrderForecastDao.add(commitment);
		}
	}

	public JobStatusEnum getBiWeeklyProcessStatus() {
		return biWeeklyProcessStatusDao.getBiWeeklyProcessStatus();
	}

	public EtlWeeklyStatus getLatestEtlWeeklyStatus() {
		return etlWeeklyStatusDao.getLatestEtlWeeklyStatus();
	}

	public EtlDailyStatus getLatestEtlDailyStatus() {
		return etlDailyStatusDao.getLatestEtlDailyStatus();
	}

	/**
	 * Return list of TtvWeeklySummary, one entry for each entry in details
	 * 
	 * @param processDate
	 * @param useRpy
	 * @param details
	 *            sorted by targetDate
	 * @param previousSummary
	 *            sorted by targetDate. Entry earlier than the processDate
	 * @param excludedOrders
	 *            sorted by targetDate
	 * @return
	 */
	public List<TtvWeeklySummary> calculateSLETTVWeeklySummary(Date versionDate, List<TtvWeeklyDetail> details, List<NpiOrder> excludedOrders) {
		return calculateTtvWeeklySummary(versionDate, true, details, null, excludedOrders);
	}

	/**
	 * @param versionDate
	 * @param useRpy
	 * @param details
	 * @param previousSummary
	 * @param excludedOrders
	 * @return
	 */
	public List<TtvWeeklySummary> calculateTtvWeeklySummary(Date versionDate, boolean useRpy, List<TtvWeeklyDetail> details, TtvWeeklySummary previousSummary,
			List<NpiOrder> excludedOrders) {
		List<TtvWeeklySummary> summaries = new ArrayList<TtvWeeklySummary>();
		if (details == null || details.size() == 0) {
			//throw new IllegalArgumentException("The TTVWeeklyDetail list contains no value.");
			return summaries;
		}

		TtvWeeklyDetail firstDetail = details.get(0);
		int pmsWaveId = firstDetail.getPmsWaveId();

		Date firstFutureMondayMidnight = CalendarUtil.adjustTimeToMidnight(CalendarUtil.getMondayDateByWeeks(versionDate, 0));

		int previousAccumulatedDemand = 0, previousAccumulatedCapacityOdm = 0, previousAccumulatedCapacityTdms = 0, 
				previousTotalWeeklyGapOdm = 0, previousTotalWeeklyGapTdms = 0;

		if (previousSummary != null) {
			previousAccumulatedDemand = previousSummary.getAccumulatedDemand();
			previousAccumulatedCapacityOdm = previousSummary.getAccumulatedCapacityOdm();
			previousAccumulatedCapacityTdms = previousSummary.getAccumulatedCapacityTdms();
			previousTotalWeeklyGapOdm = previousSummary.getTotalWeeklyGapOdm();
			previousTotalWeeklyGapTdms = previousSummary.getTotalWeeklyGapTdms();
		}

		// Make a copy to avoid modifying original objects that will be flushed
		// if modified
		List<TtvWeeklyDetail> copiedDetails = CollectionUtil.copyList(details);

		// Order exclusions only affect history portion
		adjustWeeklyOrderExclusion(copiedDetails, excludedOrders, firstFutureMondayMidnight);
		
		Collections.sort(copiedDetails, new Comparator<TtvWeeklyDetail>() {
			@Override
			public int compare(TtvWeeklyDetail o1, TtvWeeklyDetail o2) {
				return o1.getTargetDate().compareTo(o2.getTargetDate());
			}
		});

		int pastFGQuantity = 0, pastOrderQuantity = 0, futureCapcity = 0, futureDemand = 0;
		
		for (TtvWeeklyDetail detail : copiedDetails) {
			TtvWeeklySummary summary = new TtvWeeklySummary();
			summary.setTargetDate(detail.getTargetDate());
			summary.setVersionDate(versionDate);
			summary.setPmsWaveId(pmsWaveId);
			summary.setCreatedDate(new Date());
			summary.setLastModifiedDate(new Date());

			if (detail.getTargetDate().before(firstFutureMondayMidnight)) {
				summary.setAccumulatedDemand(previousAccumulatedDemand + detail.getOrderQuantity());

				// summary.setWeeklyCapacityOdm(detail.getShipQuantity());
				summary.setWeeklyCapacityOdm(detail.getFgQuantity());
				summary.setWeeklyCapacityTdms(summary.getWeeklyCapacityOdm());

				// summary.setAccumulatedCapacityOdm(previousAccumulatedCapacityOdm
				// + detail.getShipQuantity());
				summary.setAccumulatedCapacityOdm(previousAccumulatedCapacityOdm + detail.getFgQuantity());
				summary.setAccumulatedCapacityTdms(summary.getAccumulatedCapacityOdm());

				// summary.setWeeklyGapOdm(detail.getOrderQuantity() -
				// detail.getShipQuantity());
				summary.setWeeklyGapOdm(detail.getOrderQuantity() - detail.getFgQuantity());
				
				summary.setWeeklyGapTdms(summary.getWeeklyGapOdm());
				
				summary.setTotalWeeklyGapOdm(previousTotalWeeklyGapOdm + summary.getWeeklyGapOdm());
				
				summary.setTotalWeeklyGapTdms(summary.getTotalWeeklyGapOdm());
				// Actual TTV calculation based on wave. 
				pastFGQuantity += detail.getFgQuantity();
				pastOrderQuantity += detail.getOrderQuantity();
				
				if(pastOrderQuantity>0){
					summary.setTtvOdm((float) pastFGQuantity / pastOrderQuantity * 100);
				}
				else{
					summary.setTtvOdm(0);
				}
				/*
				if (summary.getAccumulatedDemand() == 0) {
					summary.setTtvOdm(0); // It is 0 if accumulated demand is 0.
				} else {
					summary.setTtvOdm((float) summary.getAccumulatedCapacityOdm() / summary.getAccumulatedDemand() * 100);
				}*/
				summary.setTtvTdms(summary.getTtvOdm());
				
				if (summary.getWeeklyGapOdm() < 0){
					summary.setWeeklyGapOdm(0);
				}
				if(summary.getWeeklyGapTdms() < 0){
					summary.setWeeklyGapTdms(0);
				}
				
			} else {
				summary.setAccumulatedDemand(previousAccumulatedDemand + detail.getFutureOrderQuantity() + detail.getFutureForecastQuantity());

				int odmCapacityOdm, odmCapacityTdms;

				if (useRpy) {
					odmCapacityOdm = detail.getOdmRpyCapacity();
					odmCapacityTdms = detail.getTdmsRpyCapacity();
				} else {
					odmCapacityOdm = detail.getOdmFpyCapacity();
					odmCapacityTdms = detail.getTdmsFpyCapacity();
				}

				int capacityOdm, capacityTdms;
				
				List<Integer> capOdmParticipants = new ArrayList<Integer>();
				if(odmCapacityOdm != -1){
					capOdmParticipants.add(odmCapacityOdm);
				}
				if(detail.getCoverA() != -1){
					capOdmParticipants.add(detail.getCoverA());
				}
				if(detail.getCoverB() != -1){
					capOdmParticipants.add(detail.getCoverB());
				}
				if(detail.getCoverC() != -1){
					capOdmParticipants.add(detail.getCoverC());
				}
				if(detail.getCoverD() != -1){
					capOdmParticipants.add(detail.getCoverD());
				}
				if(detail.getSupplyCommit() != -1){
					capOdmParticipants.add(detail.getSupplyCommit());
				}
				if(capOdmParticipants.isEmpty()){
					capacityOdm = summary.getAccumulatedDemand();
				} else{
					capacityOdm = MathUtil.min(capOdmParticipants);
				}
				
				List<Integer> captdmsParticipants = new ArrayList<Integer>();
				if(odmCapacityTdms != -1){
					captdmsParticipants.add(odmCapacityTdms);
				}
				if(detail.getCoverA() != -1){
					captdmsParticipants.add(detail.getCoverA());
				}
				if(detail.getCoverB() != -1){
					captdmsParticipants.add(detail.getCoverB());
				}
				if(detail.getCoverC() != -1){
					captdmsParticipants.add(detail.getCoverC());
				}
				if(detail.getCoverD() != -1){
					captdmsParticipants.add(detail.getCoverD());
				}
				if(detail.getSupplyCommit() != -1){
					captdmsParticipants.add(detail.getSupplyCommit());
				}
				if(captdmsParticipants.isEmpty()){
					capacityTdms = summary.getAccumulatedDemand();
				} else{
					capacityTdms = MathUtil.min(captdmsParticipants);
				}

				summary.setWeeklyCapacityOdm(capacityOdm);
				summary.setWeeklyCapacityTdms(capacityTdms);

				summary.setAccumulatedCapacityOdm(previousAccumulatedCapacityOdm + capacityOdm);
				summary.setAccumulatedCapacityTdms(previousAccumulatedCapacityTdms + capacityTdms);

				summary.setWeeklyGapOdm(detail.getFutureOrderQuantity() + detail.getFutureForecastQuantity() - capacityOdm);
				
				summary.setWeeklyGapTdms(detail.getFutureOrderQuantity() + detail.getFutureForecastQuantity() - capacityTdms);
				
				summary.setTotalWeeklyGapOdm(previousTotalWeeklyGapOdm + summary.getWeeklyGapOdm());
				summary.setTotalWeeklyGapTdms(previousTotalWeeklyGapTdms + summary.getWeeklyGapTdms());
				
				// Estimated TTV calculation based on wave// 
				/*if(futureCapcity == 0 && futureDemand ==0){
					getTotalCapacityAndDemand(futureCapcity,futureDemand,copiedDetails,firstFutureMondayMidnight);
					summary.setTtvOdm((float) futureCapcity / futureDemand * 100);
					summary.setTtvTdms((float) futureCapcity / futureDemand * 100);		
					futureCapcity -= detail.getFutureOrderQuantity();
					futureDemand -= (detail.getFutureOrderQuantity() + detail.getFutureForecastQuantity() + previousTotalWeeklyGapOdm);
					
				} else if (0 != futureDemand){
					summary.setTtvOdm((float) futureCapcity / futureDemand * 100);
					summary.setTtvTdms((float) futureCapcity / futureDemand * 100);
					futureCapcity -= detail.getFutureOrderQuantity();
					futureDemand -= (detail.getFutureOrderQuantity() + detail.getFutureForecastQuantity() + previousTotalWeeklyGapOdm);
				} else{
					summary.setTtvOdm(0f);
					summary.setTtvTdms(0f);
				}*/

				if (summary.getAccumulatedDemand() == 0) {
					// It is 0 if accumulated demand is 0.
					summary.setTtvOdm(0);
					summary.setTtvTdms(0);
				} else {
					summary.setTtvOdm((float) summary.getAccumulatedCapacityOdm() / summary.getAccumulatedDemand() * 100);
					summary.setTtvTdms((float) summary.getAccumulatedCapacityTdms() / summary.getAccumulatedDemand() * 100);
				}
				
				if(summary.getWeeklyGapOdm() < 0){
					summary.setWeeklyGapOdm(0);
				}
				if(summary.getWeeklyGapTdms() < 0){
					summary.setWeeklyGapTdms(0);
				}
			}

			summaries.add(summary);

			previousAccumulatedDemand = summary.getAccumulatedDemand();
			previousAccumulatedCapacityOdm = summary.getAccumulatedCapacityOdm();
			previousAccumulatedCapacityTdms = summary.getAccumulatedCapacityTdms();
			previousTotalWeeklyGapOdm = summary.getTotalWeeklyGapOdm();
			if(summary.getTotalWeeklyGapOdm() < 0){
				summary.setTotalWeeklyGapOdm(0);
			}
			previousTotalWeeklyGapTdms = summary.getTotalWeeklyGapTdms();
			if(summary.getTotalWeeklyGapTdms() < 0){
				summary.setTotalWeeklyGapTdms(0);
			}
		}

		return summaries;
	}

	/**
	 * @param futureCapcity
	 * @param futureDemand
	 * @param copiedDetails
	 * @param firstFutureMondayMidnight
	 */
	@SuppressWarnings("unused")
	private void getTotalCapacityAndDemand(int futureCapcity, int futureDemand,
			List<TtvWeeklyDetail> copiedDetails, Date firstFutureMondayMidnight) {
		int previousTotalWeeklyGapOdm = 0;
		for (TtvWeeklyDetail ttvWeeklyDetail : copiedDetails) {
			if (ttvWeeklyDetail.getTargetDate()
					.after(firstFutureMondayMidnight)) {
				futureCapcity += ttvWeeklyDetail.getFutureOrderQuantity();
				futureDemand += ttvWeeklyDetail.getFutureOrderQuantity()
						+ ttvWeeklyDetail.getFutureForecastQuantity()
						+ previousTotalWeeklyGapOdm;

				int capacityTdms = 0, odmCapacityOdm;
				List<Integer> capOdmParticipants = new ArrayList<Integer>();
				odmCapacityOdm = ttvWeeklyDetail.getOdmRpyCapacity();
				if (odmCapacityOdm != -1) {
					capOdmParticipants.add(odmCapacityOdm);
				}
				if (ttvWeeklyDetail.getCoverA() != -1) {
					capOdmParticipants.add(ttvWeeklyDetail.getCoverA());
				}
				if (ttvWeeklyDetail.getCoverB() != -1) {
					capOdmParticipants.add(ttvWeeklyDetail.getCoverB());
				}
				if (ttvWeeklyDetail.getCoverC() != -1) {
					capOdmParticipants.add(ttvWeeklyDetail.getCoverC());
				}
				if (ttvWeeklyDetail.getCoverD() != -1) {
					capOdmParticipants.add(ttvWeeklyDetail.getCoverD());
				}
				if (ttvWeeklyDetail.getSupplyCommit() != -1) {
					capOdmParticipants.add(ttvWeeklyDetail.getSupplyCommit());
				}
				if (capOdmParticipants.isEmpty()) {
					MathUtil.min(capOdmParticipants);
				}

				previousTotalWeeklyGapOdm = capacityTdms;

			}
		}

	}

	/**
	 * Return list of TtvDailySummary, one entry for each entry in details
	 * 
	 * @param processDatee
	 * @param useRpy
	 * @param details
	 *            sorted by targetDate
	 * @param previousSummary
	 *            sorted by targetDate. Entry earlier than the processDate
	 * @param excludedOrders
	 *            sorted by targetDate
	 * @return
	 */
	public List<TtvDailySummary> calculateTtvDailySummary(Date processDate, boolean useRpy, List<TtvDailyDetail> details, TtvDailySummary previousSummary,
			List<NpiOrder> excludedOrders) {
		if (details == null || details.size() == 0) {
			throw new IllegalArgumentException("The TTVDailyDetail list contains no value.");
		}

		TtvDailyDetail firstDetail = details.get(0);
		int pmsWaveId = firstDetail.getPmsWaveId();

		Date processDateMidnight = CalendarUtil.adjustTimeToMidnight(processDate);
		List<TtvDailySummary> summaries = new ArrayList<TtvDailySummary>();

		int previousAccumulatedDemand = 0, previousAccumulatedCapacityOdm = 0, previousAccumulatedCapacityTdms = 0, previousTotalDailyGapOdm = 0, previousTotalDailyGapTdms = 0;

		if (previousSummary != null) {
			previousAccumulatedDemand = previousSummary.getAccumulatedDemand();
			previousAccumulatedCapacityOdm = previousSummary.getAccumulatedCapacityOdm();
			previousAccumulatedCapacityTdms = previousSummary.getAccumulatedCapacityTdms();
			previousTotalDailyGapOdm = previousSummary.getTotalDailyGapOdm();
			previousTotalDailyGapTdms = previousSummary.getTotalDailyGapTdms();
		}

		// Make a copy to avoid modifying original objects that will be flushed
		// if modified
		List<TtvDailyDetail> copiedDetails = CollectionUtil.copyList(details);

		// if SGA , No need to call this function
		adjustDailyOrderExclusion(copiedDetails, excludedOrders, processDateMidnight);

		for (TtvDailyDetail detail : copiedDetails) {
			TtvDailySummary summary = new TtvDailySummary();
			summary.setTargetDate(detail.getTargetDate());
			summary.setPmsWaveId(pmsWaveId);
			summary.setCreatedDate(new Date());
			summary.setLastModifiedDate(new Date());

			if (detail.getTargetDate().before(processDateMidnight)) {
				summary.setAccumulatedDemand(previousAccumulatedDemand + detail.getOrderQuantity());

				summary.setDailyCapacityOdm(detail.getShipQuantity());
				summary.setDailyCapacityTdms(summary.getDailyCapacityOdm());

				summary.setAccumulatedCapacityOdm(previousAccumulatedCapacityOdm + detail.getShipQuantity());
				summary.setAccumulatedCapacityTdms(summary.getAccumulatedCapacityOdm());

				summary.setDailyGapOdm(detail.getOrderQuantity() - detail.getShipQuantity());
				summary.setDailyGapTdms(summary.getDailyGapOdm());

				summary.setTotalDailyGapOdm(previousTotalDailyGapOdm + summary.getDailyGapOdm());
				summary.setTotalDailyGapTdms(summary.getTotalDailyGapOdm());

				if (summary.getAccumulatedDemand() == 0) {
					// It is 0 if accumulated demand is 0.
					summary.setTtvOdm(0);
				} else {
					summary.setTtvOdm((float) summary.getAccumulatedCapacityOdm() / summary.getAccumulatedDemand() * 100);
				}
				summary.setTtvTdms(summary.getTtvOdm());
			} else {
				summary.setAccumulatedDemand(previousAccumulatedDemand + detail.getFutureDemandQuantity());

				int odmCapacityOdm, odmCapacityTdms;

				if (useRpy) {
					odmCapacityOdm = detail.getOdmRpyCapacity();
					odmCapacityTdms = detail.getTdmsRpyCapacity();
				} else {
					odmCapacityOdm = detail.getOdmFpyCapacity();
					odmCapacityTdms = detail.getTdmsFpyCapacity();
				}

				int capacityOdm, capacityTdms;
				capacityOdm = MathUtil.min(odmCapacityOdm, detail.getCoverA(), detail.getCoverB(), detail.getCoverC(), detail.getCoverD(),
						detail.getSupplyCommit());
				capacityTdms = MathUtil.min(odmCapacityTdms, detail.getCoverA(), detail.getCoverB(), detail.getCoverC(), detail.getCoverD(),
						detail.getSupplyCommit());

				summary.setDailyCapacityOdm(capacityOdm);
				summary.setDailyCapacityTdms(capacityTdms);

				summary.setAccumulatedCapacityOdm(previousAccumulatedCapacityOdm + capacityOdm);
				summary.setAccumulatedCapacityTdms(previousAccumulatedCapacityTdms + capacityTdms);

				summary.setDailyGapOdm(detail.getFutureDemandQuantity() - capacityOdm);
				summary.setDailyGapTdms(detail.getFutureDemandQuantity() - capacityTdms);

				summary.setTotalDailyGapOdm(previousTotalDailyGapOdm + summary.getDailyGapOdm());
				summary.setTotalDailyGapTdms(previousTotalDailyGapTdms + summary.getDailyGapTdms());

				if (summary.getAccumulatedDemand() == 0) {
					// It is 0 if accumulated demand is 0.
					summary.setTtvOdm(0);
					summary.setTtvTdms(0);
				} else {
					summary.setTtvOdm((float) summary.getAccumulatedCapacityOdm() / summary.getAccumulatedDemand() * 100);
					summary.setTtvTdms((float) summary.getAccumulatedCapacityTdms() / summary.getAccumulatedDemand() * 100);
				}
			}

			summaries.add(summary);

			previousAccumulatedDemand = summary.getAccumulatedDemand();
			previousAccumulatedCapacityOdm = summary.getAccumulatedCapacityOdm();
			previousAccumulatedCapacityTdms = summary.getAccumulatedCapacityTdms();
			previousTotalDailyGapOdm = summary.getTotalDailyGapOdm();
			previousTotalDailyGapTdms = summary.getTotalDailyGapTdms();
		}

		return summaries;
	}

	public void PersistTtvWeeklySummary(List<TtvWeeklySummary> summaries) {
		for (TtvWeeklySummary summary : summaries) {
			ttvWeeklySummaryDao.add(summary);
		}
	}
	public void deleteTtvWeeklySummaryByWaveId(int pmsWaveId,Date versionDate ){
		ttvWeeklySummaryDao.deleteTtvWeeklySummaryByWaveId(pmsWaveId, versionDate);
	}
	public void calculateTtvDailySummaryAndPersist(Date processDate, boolean useRpy, List<TtvDailyDetail> details, TtvDailySummary previousSummary,
			List<NpiOrder> excludedOrders) {
		List<TtvDailySummary> summaries = calculateTtvDailySummary(processDate, useRpy, details, previousSummary, excludedOrders);
		for (TtvDailySummary summary : summaries) {
			ttvDailySummaryDao.add(summary);
		}
	}

	private void adjustWeeklyOrderExclusion(List<TtvWeeklyDetail> details, List<NpiOrder> excludedOrders, Date processDateMidnight) {
		if(CollectionUtils.isNotEmpty(details)){
			for (TtvWeeklyDetail detail : details) {
				if (detail != null) {// add by Nicolas on Jul 1,2014
					if(CollectionUtils.isNotEmpty(excludedOrders)){
						for (NpiOrder excludedOrder : excludedOrders) {
							if (excludedOrder != null && detail.getTargetDate() != null && excludedOrder.getRsdDate() != null) {
								if (CalendarUtil.isSameWeek(detail.getTargetDate(), excludedOrder.getRsdDate())) {
									int quantity = excludedOrder.getQuantity();
									// Only need to consider history. Future adjustment
									// is done in FIFO
									if (detail.getTargetDate().before(processDateMidnight)) {
										detail.setOrderQuantity(detail.getOrderQuantity() - quantity);
										detail.setShipQuantity(detail.getFgQuantity() - quantity);
									}
								}
							}
						}
					}
				}
			}
		}
	}

	@SuppressWarnings("unused")
	private void adjustSGAWeeklyOrderExclusion(List<SGATtvWeeklyDetail> details, List<NpiOrder> excludedOrders, Date processDateMidnight) {
		for (SGATtvWeeklyDetail detail : details) {
			if (detail != null) {// add by Nicolas on Jul 1,2014
				for (NpiOrder excludedOrder : excludedOrders) {
					if (excludedOrder != null && detail.getTargetDate() != null && excludedOrder.getRsdDate() != null) {
						if (CalendarUtil.isSameWeek(detail.getTargetDate(), excludedOrder.getRsdDate())) {
							int quantity = excludedOrder.getQuantity();
							// Only need to consider history. Future adjustment
							// is done in FIFO
							if (detail.getTargetDate().before(processDateMidnight)) {
								// detail.setOrderQuantity(detail.getOrderQuantity()
								// - quantity);
								detail.setShipQuantity(detail.getFgQuantity() - quantity);
							}
						}
					}
				}
			}

		}
	}

	private void adjustDailyOrderExclusion(List<TtvDailyDetail> details, List<NpiOrder> excludedOrders, Date processDateMidnight) {
		for (TtvDailyDetail detail : details) {
			for (NpiOrder excludedOrder : excludedOrders) {
				if (CalendarUtil.isSameDay(detail.getTargetDate(), excludedOrder.getRsdDate())) {
					int quantity = excludedOrder.getQuantity();

					if (detail.getTargetDate().before(processDateMidnight)) {
						detail.setOrderQuantity(detail.getOrderQuantity() - quantity);
						detail.setShipQuantity(detail.getShipQuantity() - quantity);
					} else {
						detail.setFutureDemandQuantity(detail.getFutureDemandQuantity() - quantity);
					}

				}
			}
		}
	}

	public List<TtvWeeklyDetail> getNpiWeeklyDetail(Date targetDate, Date versionDate) {
		return ttvWeeklyDetailDao.getNpiWeeklyDetail(targetDate, versionDate);
	}

	public List<SGATtvWeeklyDetail> getSGANpiWeeklyDetail(Date targetDate, Date versionDate) {
		return sgaTtvWeeklyDetailDao.getNpiWeeklyDetail(targetDate, versionDate);
	}

	public List<SGATtvWeeklyDetail> getSGANpiWeeklyDetail(Date versionDate) {
		return sgaTtvWeeklyDetailDao.getNpiWeeklyDetail(versionDate);
	}

	public List<Date> getNpiWeeklyDetailTargetDates(Date versionDate) {
		return ttvWeeklyDetailDao.getTargetDates(versionDate);
	}

	/**
	 * @param waveKey
	 * @param targetDate
	 * @param versionDate
	 * @param ttvPhase
	 * @return
	 */
	public List<NpiWeeklyComponentCommitmentOnForecast> getForecastDataByProductKey(String waveKey, Date targetDate, Date versionDate,TTVPhase ttvPhase) {
		return forecastDataDao.getForecastDataByProduct(waveKey, targetDate, versionDate, ttvPhase);
	}

	public List<OrderData> getOrderDataByProductKey(List<String> orders) {
		return orderDataDao.getOrderData(orders);
	}

	public List<NpiWeeklyComponentCommitmentOnForecast> getCausedForecastDataByProduct(String productKey, Date targetDate, Date versionDate, ForecastComparisonTypeEnum type) {
		return forecastDataDao.getCausedForecastDataByProduct(productKey, targetDate, versionDate, type);
	}

	public List<NpiWeeklyComponentCommitmentOnOrder> getCausedOrderByProduct(String pmsWaveId, Date versionDate, ForecastComparisonTypeEnum type) {
		return orderDataDao.getCausedOrderByProduct(pmsWaveId, versionDate, type);
	}
	public List<NpiWeeklyComponentCommitmentOnOrder> getOrderByProduct(String productKey, Date versionDate, Date targetDate, TTVPhase ttvPhase) {
		return orderDataDao.getOrderByProduct(productKey, versionDate, targetDate, ttvPhase);
	}

	public void cleanUpSGATTVWeeklyDetails(List<SGATtvWeeklyDetail> npiWeeklyDetails) {
		for (SGATtvWeeklyDetail std : npiWeeklyDetails) {
			//std.setSupplyCommit(null);
			std.setCoverA(-1);
			std.setCoverB(-1);
			std.setCoverC(-1);
			std.setCoverD(-1);
			std.setOdmFpyCapacity(-1);
			std.setOdmRpyCapacity(-1);
			std.setTdmsFpyCapacity(-1);
			std.setTdmsRpyCapacity(-1);
			std.setFutureForecastQuantity(0);
			std.setFutureOrderQuantity(0);
			std.setRampCommit(null);
			std.setForecast(null);
			std.setToGoForecast(0);
			std.setToGoOrder(0);
			std.setOutput(0);
			std.setTdmsToGoForecast(0);
			std.setTdmsToGoOrder(0);
			std.setTdmsOutput(0);
		}
	}

	public void cleanUpSLETTVWeeklyDetails(List<TtvWeeklyDetail> npiWeeklyDetails) {
		for(TtvWeeklyDetail std: npiWeeklyDetails){
			//std.setSupplyCommit(0);
			std.setBackOrderQuantity(0);
			std.setFutureOrderQuantity(0);
			std.setFutureForecastQuantity(0);
			std.setCoverA(-1);
			std.setCoverB(-1);
			std.setCoverC(-1);
			std.setCoverD(-1);
			std.setOdmFpyCapacity(-1);
			std.setOdmRpyCapacity(-1);
			std.setTdmsFpyCapacity(-1);
			std.setTdmsRpyCapacity(-1);
			std.setTdmsFpy(1f);
		}
	}
	
	public void saveNpiWeeklyComponentCommitmentOnProduct(NpiWeeklyComponentCommitmentOnProduct obj){
		npiWeeklyComponentCommitmentOnProductDao.saveComponentCommitmentOnProduct(obj);
	}

	public void deleteComponentCommitmentOnProduct(Date versionDate) {
		npiWeeklyComponentCommitmentOnProductDao.deleteComponentCommitmentOnProduct(versionDate);
		
	}
}
