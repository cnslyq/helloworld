package com.lenovo.bi.engine;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.dto.OdmCapacityPlan;
import com.lenovo.bi.enumobj.TimeFrequencyEnum;
/**
 * 
 * 
 * @author henry_lian
 *
 */
@Component
public class OdmCapacityCalculator {

	public int calculateOdmNpiCapacity(List<OdmCapacityPlan> plans, TimeFrequencyEnum frequency) {
		int totalCapacity = 0;
		for (OdmCapacityPlan plan : plans) {
			float py = 0;
			if (plan.isUseRpy()) {
				py = plan.getFpy() + (100 - plan.getFpy()) * plan.getRpy()/100;
			}
			else {
				py = plan.getFpy();
			}
			
			int output;
			if (frequency == TimeFrequencyEnum.WEEKLY) {				
				output = (int) (plan.getUnitsPerHour() * plan.getHoursPerDay() * plan.getDaysPerWeek() * py/100);
			}
			else {
				output = (int) (plan.getUnitsPerHour() * plan.getHoursPerDay() * py/100);
			}
			
			totalCapacity += output;
			plan.setOutput(output);
		}
		return totalCapacity;  
	}
	
	public float calculateFpy(List<Defect> tdmsDefects) {
		float individualFpy;
		float compositeFpy = 1f;
		for (Defect tdmsDefect : tdmsDefects) {
			if (tdmsDefect.getImpactFPY() != null) {
				if (tdmsDefect.getImpactFPY() > 0) {
					individualFpy = tdmsDefect.getImpactFPY();		
				}
				else {
					individualFpy = 1f;
				}
			}
			else {
				if(tdmsDefect.getFailRate() != null){
					individualFpy = (float) (1 - tdmsDefect.getFailRate());
				}else{
					individualFpy = 1f;
				}
			}
			
			compositeFpy = (float) (compositeFpy * individualFpy);
		}
		
		return compositeFpy;
	}
	
	//FPY calculation
	public Map<String, Float> calculateFpy(List<Defect> tdmsDefects, Date ttmTargetDate) {
		//init variables
		Map<String, Float> fpyMap = new HashMap<String, Float>();
		float fpy1 = 1f;
		float fpy2 = 1f;
		float fpy = 1f;
		//loop the defect list
		for (Defect tdmsDefect : tdmsDefects) {
			Date estimatedResolvedDate = tdmsDefect.getEstimatedResolveDate();
			//if estimatedResolvedDate is not null and estimatedResolvedDate <= SSDate, calculate FPY1
			if(estimatedResolvedDate != null && estimatedResolvedDate.compareTo(ttmTargetDate) <= 0){
				fpy1 *= getIndividualFpy(tdmsDefect);
			}else{		//if estimatedResolvedDate is null or estimatedResolvedDate > SSDate, calculate FPY2
				fpy2 *= getIndividualFpy(tdmsDefect);
			}
		}
		//Total FPY = FPY1 * FPY2
		fpy = fpy1 * fpy2;
		//set the result map
		fpyMap.put("fpy1", fpy1);
		fpyMap.put("fpy2", fpy2);
		fpyMap.put("fpy", fpy);
		return fpyMap;
	}
	//individual FPY calculation
	private float getIndividualFpy(Defect tdmsDefect){
		float individualFpy = 1f;
		if (tdmsDefect.getImpactFPY() != null) {
			if (tdmsDefect.getImpactFPY() > 0) {
				individualFpy = tdmsDefect.getImpactFPY();		
			}
		}else if(tdmsDefect.getFailRate() != null) {
			individualFpy = (float) (1 - tdmsDefect.getFailRate());
		}
		return individualFpy;
	}
	
	
}
