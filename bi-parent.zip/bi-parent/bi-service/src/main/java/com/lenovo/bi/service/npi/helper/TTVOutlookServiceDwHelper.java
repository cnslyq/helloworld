package com.lenovo.bi.service.npi.helper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.common.OdmCapacityDao;
import com.lenovo.bi.dao.common.ToolingCapacityDao;
import com.lenovo.bi.dao.common.impl.DnsDaoImpl;
import com.lenovo.bi.dao.common.impl.ForecastDaoImpl;
import com.lenovo.bi.dao.common.impl.MtmDaoImpl;
import com.lenovo.bi.dao.common.impl.ProductDaoImpl;
import com.lenovo.bi.dao.npi.NPIDefectDao;
import com.lenovo.bi.dao.npi.impl.NPIPhaseDaoImpl;
import com.lenovo.bi.dao.npi.impl.NPIToolingDaoImpl;
import com.lenovo.bi.dao.npi.impl.NpiProjectWaveDaoImpl;
import com.lenovo.bi.dao.npi.impl.OrderDaoImpl;
import com.lenovo.bi.dao.sc.FADao;
import com.lenovo.bi.dto.CtoCvConfig;
import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.dto.DimTime;
import com.lenovo.bi.dto.DnsEntry;
import com.lenovo.bi.dto.EolForecast;
import com.lenovo.bi.dto.Forecast;
import com.lenovo.bi.dto.GlobalCV;
import com.lenovo.bi.dto.MtmCvQuantity;
import com.lenovo.bi.dto.MtmGeographyOdmCvQuantity;
import com.lenovo.bi.dto.NpiDnsEntry;
import com.lenovo.bi.dto.NpiForecast;
import com.lenovo.bi.dto.OdmCapacityPlan;
import com.lenovo.bi.dto.OdmCapacityPlanDetail;
import com.lenovo.bi.dto.OdmCommitDto;
import com.lenovo.bi.dto.Order;
import com.lenovo.bi.dto.Product;
import com.lenovo.bi.dto.ProductKeyPmsWaveId;
import com.lenovo.bi.dto.RampCommitDTO;
import com.lenovo.bi.dto.SingleUnitCvConfig;
import com.lenovo.bi.dto.TdmsDefect;
import com.lenovo.bi.dto.TdmsDefectDetail;
import com.lenovo.bi.dto.ToolingCapacity;
import com.lenovo.bi.dto.ToolingCapacityDetail;
import com.lenovo.bi.enumobj.TimeFrequencyEnum;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.model.SGATtvWeeklyDetail;
import com.lenovo.bi.model.SGATtvWeeklySummary;
import com.lenovo.bi.model.dw.NPIPhase;
import com.lenovo.bi.service.npi.ForecastService;
import com.lenovo.bi.service.npi.RampCommitService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.MathUtil;
import com.lenovo.bi.view.npi.ForecastCompare;
import com.lenovo.bi.view.npi.ttv.OrderHitRateView;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.CausesByForecast;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.CausesByOrder;

/**
 * @author Sweet_Yang
 *
 */
@Service
@Transactional("dw")
public class TTVOutlookServiceDwHelper {
	@Autowired
	private NPIToolingDaoImpl npiToolingDaoImpl;

	@Autowired
	private OdmCapacityDao npiOdmCapacityDaoImpl;

	@Autowired
	private ToolingCapacityDao toolingCapacityDaoImpl;

	@Autowired
	private OrderDaoImpl orderDaoImpl;

	@Autowired
	private ForecastDaoImpl forecastDaoImpl;

	@Autowired
	private MtmDaoImpl mtmDaoImpl;

	@Autowired
	private NpiProjectWaveDaoImpl npiProjectWaveDaoImpl;

	@Autowired
	private DnsDaoImpl dnsDaoImpl;

	@Autowired
	private ProductDaoImpl productDaoImpl;

	@Autowired
	private NPIDefectDao nPIDefectDao;

	@Autowired
	private FADao faDaoImpl;
	
	@Autowired
	private RampCommitService rampCommitService;
	
	@Autowired
	private ForecastService forecastService;
	
	@Autowired
	private NPIPhaseDaoImpl npiPhaseDao;

	public List<Defect> getGatingDefectsByProductWave(int waveId, Date targetDate, Date versionDate) {
		return nPIDefectDao.getGatingDefectsByProductWave(waveId, targetDate, versionDate);
	}

	public List<DimTime> getFactNPIToolingTracking() {
		return npiToolingDaoImpl.getFactNPIToolingTracking();
	}

	public Map<Long, Integer> getRampCommitByWaveId(Integer waveId){
		Map<Long, Integer> map = new HashMap<Long, Integer>();
		List<RampCommitDTO> list = rampCommitService.getRampCommitByWaveId(waveId);
		for(RampCommitDTO rcdto:list){
			map.put(rcdto.getTargetDate().getTime(), rcdto.getValue());
		}
		return map;
	}
	
	public void setRampCommit(Integer pmsWaveId, List<SGATtvWeeklyDetail> ttvWeeklyDetails, Map<Long, Integer> rampCommitMap) {
		int i = 0;
		for (; i < ttvWeeklyDetails.size(); i++) {
			SGATtvWeeklyDetail ttvWeeklyDetail = ttvWeeklyDetails.get(i);
			Date targetDate = ttvWeeklyDetail.getTargetDate();
			Integer rampCommit = 0;
			if (i > 0) {
				rampCommit = rampCommitMap.get(targetDate.getTime()) != null?rampCommitMap.get(targetDate.getTime()):-1;
			}
			ttvWeeklyDetail.setRampCommit(rampCommit);
		}
	}
	
	public Map<Date, Integer> getSGAForecastByWaveId(Integer waveId){
		return forecastService.getSGATTVForecast(waveId);
	}

	public void setForecast(Integer pmsWaveId, List<SGATtvWeeklyDetail> ttvWeeklyDetails, Map<Date, Integer> forecastMap) {

		List<NPIPhase> phases = npiPhaseDao.getNPIPhase(new String[] { "SS", "SGA" }, pmsWaveId);
		if (phases == null || phases.size() != 2) {
			return;
		}
		Date ssDate = CalendarUtil.getMondayDateByDate(phases.get(0).getPlanDate());
//		Date sgaDate = CalendarUtil.getMondayDateByDate(phases.get(1).getPlanDate());
		Date startDate8 = CalendarUtil.getMondayDateByWeeks(ssDate, -8);
//		Date startDate7 = CalendarUtil.getMondayDateByWeeks(ssDate, -7);
//		Date endDate = CalendarUtil.getMondayDateByWeeks(sgaDate, 2);
//
//		List forecasts8 = forecastDao.getForecast(pmsWaveId, startDate8);
//		List forecasts7 = forecastDao.getForecast(pmsWaveId, startDate7);
//
//		Map<Date, Integer> forecasts = new Hashtable<Date, Integer>();
//		for (int i = 0; i < forecasts8.size(); i++) {
//			Object[] forecast = (Object[]) forecasts8.get(i);
//			Date targetDate = (Date) forecast[0];
//			Integer quantity = (Integer) forecast[1];
//			if (forecasts.get(targetDate) == null) {
//				forecasts.put(targetDate, quantity);
//			}
//		}
//		for (int i = 0; i < forecasts7.size(); i++) {
//			Object[] forecast = (Object[]) forecasts7.get(i);
//			Date targetDate = (Date) forecast[0];
//			Integer quantity = (Integer) forecast[1];
//			if (forecasts.get(targetDate) == null) {
//				forecasts.put(targetDate, quantity);
//			}
//		}
//
//		for (Date d = startDate8; d.compareTo(endDate) <= 0;) {
//			if (forecasts.get(d) == null) {
//				forecasts.put(d, 0);
//			}
//			d = CalendarUtil.getMondayDateByWeeks(d, 1);
//		}

		int i = 0;
		for (; i < ttvWeeklyDetails.size(); i++) {
			SGATtvWeeklyDetail ttvWeeklyDetail = ttvWeeklyDetails.get(i);

			if (i == 0) {
				Integer quantity = 0;
				for (Date d = startDate8; d.compareTo(ssDate) < 0;) {
					quantity += forecastMap.get(d);
					d = CalendarUtil.getMondayDateByWeeks(d, 1);
				}
				ttvWeeklyDetail.setForecast(quantity);
			} else {
				Integer quantity = forecastMap.get(ttvWeeklyDetail.getTargetDate());
				ttvWeeklyDetail.setForecast(quantity);
			}
		}
	}
	
	public List<SGATtvWeeklySummary> calculateSGATtvWeeklySummary(Integer pmsWaveId, List<SGATtvWeeklyDetail> details) {
		List<SGATtvWeeklySummary> summaries = new ArrayList<SGATtvWeeklySummary>();
		if (details == null || details.size() == 0) {
			//throw new IllegalArgumentException("The TTVWeeklyDetail list contains no value.");
			return summaries;
		}

		List<NPIPhase> phases = npiPhaseDao.getNPIPhase(new String[] { "SS", "SGA" }, pmsWaveId);
		if (phases == null || phases.size() != 2) {
			return null;
		}

		Date ssDate = CalendarUtil.getMondayDateByDate(phases.get(0).getPlanDate());
//		Date sgaDate = CalendarUtil.getMondayDateByDate(phases.get(1).getPlanDate());
//		Date startDate = CalendarUtil.getMondayDateByWeeks(ssDate, -8);
//		Date endDate = CalendarUtil.getMondayDateByWeeks(sgaDate, 2);


		int accumulatedDemand = 0;
		int accumulatedCapacityOdm = 0;
		int accumulatedCapacityTdms = 0;
		int totalWeeklyGapOdm = 0;
		int totalWeeklyGapTdms = 0;
		int numerator = 0;
		int denominator = 0;
		int tdmsNumerator = 0;
		int tdmsDenominator = 0;
		int loop = 0;

		for (SGATtvWeeklyDetail detail : details) {

			SGATtvWeeklySummary summary = new SGATtvWeeklySummary();
			summary.setTargetDate(detail.getTargetDate());
			summary.setVersionDate(detail.getVersionDate());
			summary.setPmsWaveId(pmsWaveId);
			summary.setCreatedDate(new Date());
			summary.setLastModifiedDate(new Date());

			Date currentWeek = CalendarUtil.getMondayDateByDate(detail.getVersionDate());

			if (detail.getTargetDate().before(currentWeek)) {
				summary.setAccumulatedDemand(accumulatedDemand + detail.getOrderQuantity());

				summary.setWeeklyCapacityOdm(detail.getFgQuantity());
				summary.setWeeklyCapacityTdms(summary.getWeeklyCapacityOdm());

				summary.setAccumulatedCapacityOdm(accumulatedCapacityOdm + detail.getFgQuantity());
				summary.setAccumulatedCapacityTdms(summary.getAccumulatedCapacityOdm());

				summary.setWeeklyGapOdm(detail.getOrderQuantity() - detail.getFgQuantity());

				summary.setTotalWeeklyGapOdm(totalWeeklyGapOdm + summary.getWeeklyGapOdm());
				
				summary.setTotalWeeklyGapTdms(summary.getTotalWeeklyGapOdm());
				if (summary.getWeeklyGapOdm() < 0){
					summary.setWeeklyGapOdm(0);
				}
				summary.setWeeklyGapTdms(summary.getWeeklyGapOdm());

			} else {
				summary.setAccumulatedDemand(accumulatedDemand + Math.min(detail.getForecast() != null ? detail.getForecast() : 0, detail.getRampCommit() != null ? detail.getRampCommit() : 0));
				if(summary.getAccumulatedDemand() < 0){
					summary.setAccumulatedDemand(0);
				}
				
				int odmCapacityOdm = detail.getOdmRpyCapacity();
				
				List<Integer> capOdmParticipants = new ArrayList<Integer>();
				if(odmCapacityOdm != -1){
					capOdmParticipants.add(odmCapacityOdm);
				}
				if(detail.getCoverA() != -1){
					capOdmParticipants.add(detail.getCoverA());
				}
				if(detail.getCoverB() != -1){
					capOdmParticipants.add(detail.getCoverB());
				}
				if(detail.getCoverC() != -1){
					capOdmParticipants.add(detail.getCoverC());
				}
				if(detail.getCoverD() != -1){
					capOdmParticipants.add(detail.getCoverD());
				}
				if(detail.getSupplyCommit() != -1){
					capOdmParticipants.add(detail.getSupplyCommit());
				}
				
				int capacityOdm = 0;
				if(CollectionUtils.isNotEmpty(capOdmParticipants)){
					capacityOdm = MathUtil.min(capOdmParticipants);
				} else{
					if(detail.getRampCommit() < 0){
						capacityOdm = detail.getForecast();
					} else{
						capacityOdm = MathUtil.min(detail.getRampCommit(), detail.getForecast());
					}
				}

				int odmCapacityTdms = detail.getTdmsRpyCapacity();
				
				List<Integer> capTdmsParticipants = new ArrayList<Integer>();
				if(odmCapacityTdms != -1){
					capTdmsParticipants.add(odmCapacityTdms);
				}
				if(detail.getCoverA() != -1){
					capTdmsParticipants.add(detail.getCoverA());
				}
				if(detail.getCoverB() != -1){
					capTdmsParticipants.add(detail.getCoverB());
				}
				if(detail.getCoverC() != -1){
					capTdmsParticipants.add(detail.getCoverC());
				}
				if(detail.getCoverD() != -1){
					capTdmsParticipants.add(detail.getCoverD());
				}
				if(detail.getSupplyCommit() != -1){
					capTdmsParticipants.add(detail.getSupplyCommit());
				}
				
				int capacityTdms = 0;
				if(CollectionUtils.isNotEmpty(capTdmsParticipants)){
					capacityTdms = MathUtil.min(capTdmsParticipants);
				} else{
					if(detail.getRampCommit() < 0){
						capacityTdms = detail.getForecast();
					} else{
						capacityTdms = MathUtil.min(detail.getRampCommit(), detail.getForecast());
					}
				}
				

				summary.setWeeklyCapacityOdm(capacityOdm);
				summary.setWeeklyCapacityTdms(capacityTdms);

				summary.setAccumulatedCapacityOdm(accumulatedCapacityOdm + capacityOdm);
				summary.setAccumulatedCapacityTdms(accumulatedCapacityTdms + capacityTdms);
				
				if(detail.getRampCommit() < 0){
					//summary.setWeeklyGapOdm(detail.getForecast() != null ? detail.getForecast() : 0 - capacityOdm);
					//summary.setWeeklyGapTdms(detail.getForecast() != null ? detail.getForecast() : 0 - capacityTdms);
					summary.setWeeklyGapOdm((detail.getForecast() != null ? detail.getForecast() : 0) - capacityOdm);
					summary.setWeeklyGapTdms((detail.getForecast() != null ? detail.getForecast() : 0) - capacityTdms);
				} else{
					summary.setWeeklyGapOdm(Math.min(detail.getForecast() != null ? detail.getForecast() : 0, detail.getRampCommit() != null ? detail.getRampCommit() : 0) - capacityOdm);
					
					summary.setWeeklyGapTdms(Math.min(detail.getForecast() != null ? detail.getForecast() : 0, detail.getRampCommit() != null ? detail.getRampCommit() : 0) - capacityTdms);
				}

				summary.setTotalWeeklyGapOdm(totalWeeklyGapOdm + summary.getWeeklyGapOdm());
				if(summary.getTotalWeeklyGapOdm() < 0){
					summary.setTotalWeeklyGapOdm(0);
				}
				summary.setTotalWeeklyGapTdms(totalWeeklyGapTdms + summary.getWeeklyGapTdms());
				
				if(summary.getWeeklyGapOdm() < 0){
					summary.setWeeklyGapOdm(0);
				}
				if(summary.getWeeklyGapTdms() < 0){
					summary.setWeeklyGapTdms(0);
				}
			}

			accumulatedDemand = summary.getAccumulatedDemand();
			accumulatedCapacityOdm = summary.getAccumulatedCapacityOdm();
			accumulatedCapacityTdms = summary.getAccumulatedCapacityTdms();
			totalWeeklyGapOdm = summary.getTotalWeeklyGapOdm();
			if(summary.getTotalWeeklyGapOdm() <0){
				summary.setTotalWeeklyGapOdm(0);
			}
			totalWeeklyGapTdms = summary.getTotalWeeklyGapTdms();
			if(summary.getTotalWeeklyGapTdms() < 0){
				summary.setTotalWeeklyGapTdms(0);
			}
			Integer toGoForecast = detail.getToGoForecast() == null ? -1 : detail.getToGoForecast();
			Integer output = detail.getOutput() == null ? -1 : detail.getOutput();
			Integer rampCommit = detail.getRampCommit() == null ? -1 : detail.getRampCommit();
			Integer toGoOrder = detail.getToGoOrder() == null ? -1 : detail.getToGoOrder();
			List<Integer> odmNumeratorPats = new ArrayList<Integer>();
			if(toGoForecast != -1){
				odmNumeratorPats.add(toGoForecast);
			}
			if(output != -1){
				odmNumeratorPats.add(output);
			}
			if(rampCommit != -1){
				odmNumeratorPats.add(rampCommit);
			}
			numerator += MathUtil.min(odmNumeratorPats);
			List<Integer> odmDenominatorPats = new ArrayList<Integer>();
			if(toGoForecast != -1){
				odmDenominatorPats.add(toGoForecast);
			}
			if(toGoOrder != -1){
				odmDenominatorPats.add(toGoOrder);
			}
			if(rampCommit != -1){
				odmDenominatorPats.add(rampCommit);
			}
			denominator += MathUtil.min(odmDenominatorPats);
			float ttv = 0f;
			if (denominator != 0){
				if(numerator < 0){
					numerator = 0;
				}
				ttv = (float) numerator / denominator * 100;
			} else{
				//change ttv from 100 to -1 when denominator = 0
				//ttv = 100f;
				ttv = -1f;
			}
			Integer tdmsToGoForecast = detail.getTdmsToGoForecast() == null ? -1 : detail.getTdmsToGoForecast();
			Integer tdmsOutput = detail.getTdmsOutput() == null ? -1 : detail.getTdmsOutput();
			Integer tdmsToGoOrder = detail.getTdmsToGoOrder() == null ? -1 : detail.getTdmsToGoOrder();
			List<Integer> tdmsNumeratorPats = new ArrayList<Integer>();
			if(tdmsToGoForecast != -1){
				tdmsNumeratorPats.add(tdmsToGoForecast);
			}
			if(tdmsOutput != -1){
				tdmsNumeratorPats.add(tdmsOutput);
			}
			if(rampCommit != -1){
				tdmsNumeratorPats.add(rampCommit);
			}
			tdmsNumerator += MathUtil.min(tdmsNumeratorPats);
			List<Integer> tdmsDenominatorPats = new ArrayList<Integer>();
			if(tdmsToGoForecast != -1){
				tdmsDenominatorPats.add(tdmsToGoForecast);
			}
			if(tdmsToGoOrder != -1){
				tdmsDenominatorPats.add(tdmsToGoOrder);
			}
			if(rampCommit != -1){
				tdmsDenominatorPats.add(rampCommit);
			}
			tdmsDenominator += MathUtil.min(tdmsDenominatorPats);
			float tdmsTtv = 0f;
			if (tdmsDenominator != 0){
				if(tdmsNumerator < 0){
					tdmsNumerator = 0;
				}
				tdmsTtv = (float) tdmsNumerator / tdmsDenominator * 100;
			} else{
				tdmsTtv = 100f;
			}

//			if (currentWeek.compareTo(startDate) < 0) {
//				summary.setTtvOdm(0);
//				summary.setTtvTdms(0);
//			} else if (currentWeek.compareTo(startDate) > 0 && currentWeek.compareTo(ssDate) <= 0) {
//				summary.setTtvOdm(0);
//				summary.setTtvTdms(ttv);
//			} else if (currentWeek.compareTo(ssDate) > 0 && currentWeek.compareTo(endDate) <= 0) {
//				if (detail.getTargetDate().before(currentWeek)) {
//					summary.setTtvOdm(ttv);
//					summary.setTtvTdms(0);
//				} else {
//					summary.setTtvOdm(0);
//					summary.setTtvTdms(ttv);
//				}
//			}
			
			if (detail.getTargetDate().compareTo(ssDate) >= 0){
				summary.setTtvOdm(ttv);
				summary.setTtvTdms(tdmsTtv);
			} else{
				summary.setTtvOdm(0);
				summary.setTtvTdms(0);
			}

			if(loop != 0){
				summaries.add(summary);
			}
			loop++;
		}

		return summaries;
	}
	
	public int calculateOdmNpiCapacity(List<OdmCapacityPlan> plans, TimeFrequencyEnum frequency, boolean includeRpy, boolean isTdms) {
		int totalCapacity = -1;
		for (OdmCapacityPlan plan : plans) {

			// Defect #10634; modify_date:2014-08-04
			//this injects more problems!
//			if (!isTdms) {
//				if (plan.getFpy() > 0) {
//					plan.setFpy(plan.getFpy() / 100);
//				}
//				if (plan.getRpy() > 0) {
//					plan.setRpy(plan.getRpy() / 100);
//				}
//			}

			float py = 0f;
			if (includeRpy && plan.isUseRpy()) { // Include RPY only when asked
													// and the plan actually
													// uses RPY
				py = (float) ((plan.getFpy()/100) + (100 - plan.getFpy()) * (plan.getRpy()/100));
			} else {
				py = plan.getFpy()/100;
			}

			int output;
			if (frequency == TimeFrequencyEnum.WEEKLY) {
				output = (int) (plan.getUnitsPerHour() * plan.getHoursPerDay() * plan.getDaysPerWeek() * py);
			} else {
				output = (int) (plan.getUnitsPerHour() * plan.getHoursPerDay() * py);
			}
			if(totalCapacity == -1){
				totalCapacity = 0;
			}
			totalCapacity += output;
			plan.setOutput(output);
		}
		return totalCapacity;
	}

	public int calculateOdmNpiCapacity(List<OdmCapacityPlan> plans, float tdmsFpy, TimeFrequencyEnum frequency) {
		// Override all FPY's with TDMS FPY
		for (OdmCapacityPlan plan : plans) {
			plan.setFpy(tdmsFpy);
		}

		return calculateOdmNpiCapacity(plans, frequency, false, true);
	}

	public float calculateTdmsDefectFpy(List<TdmsDefect> tdmsDefects) {
		float individualFpy;
		float compositeFpy = 1f;
		for (TdmsDefect tdmsDefect : tdmsDefects) {
			if (tdmsDefect.getFpyImpact() != null) {
				if (tdmsDefect.getFpyImpact() > 0) {
					individualFpy = tdmsDefect.getFpyImpact();
				} else {
					individualFpy = 1f;
				}
			} else {
			float	failRate =  tdmsDefect.getFailRate()!=null?tdmsDefect.getFailRate():0;
				individualFpy = (float) (1 - failRate);
			}

			compositeFpy = (float) (compositeFpy * individualFpy);
		}

		return compositeFpy;
	}

	public List<OdmCapacityPlan> getOdmNpiCapacityPlanForTargetDate(int pmsWaveId, Date targetDate, Date versionDate) {
		return npiOdmCapacityDaoImpl.getOdmNpiCapacityPlanForTargetDate(pmsWaveId, targetDate, versionDate);
	}

	public List<TdmsDefect> getTdmsDefectsForTargetDate(int pmsWaveId, Date targetDate, Date versionDate) {
		return npiOdmCapacityDaoImpl.getTdmsDefectsForTargetDate(pmsWaveId, targetDate, versionDate);
	}
	public List<Order> getSLEAllOrdersInWeek(Date processDate, Date versionDate) {
		Date monday = CalendarUtil.getMondayDateByDate(processDate);
		return orderDaoImpl.getSLEAllOrdersInWeek(monday, versionDate);
	}
	
	public List<Order> getSLEOrdersInWeekByProductKey(Date processDate, String productKey,String waveId,Date startDate,Date endDate) {
		return orderDaoImpl.getSLEOrdersInWeekByProductKey(processDate, productKey,waveId,startDate,endDate);
	}
	public List<OrderHitRateView> getOrderAndForecast(Date versionDate,Date targeteDate,String productKey,String regionName,String waveId){
		return orderDaoImpl.getOrderAndForecast( versionDate, targeteDate, productKey,regionName,waveId);
	}
	public List<Order> getSGAAllOrdersInWeek(Date processDate, Date versionDate) {
		return orderDaoImpl.getSGAAllOrdersInWeek(processDate, versionDate);
	}

	public List<Order> getSGAOrdersInWeekByProduct(Date processDate, Date versionDate, String productKey) {
		return orderDaoImpl.getSGAOrdersInWeekByProduct(processDate, versionDate, productKey);
	}

	public List<Order> getSLEUnshippedOrdersBeforeWeek(Date targetDate, Date versionDate) {
		Date monday = CalendarUtil.getMondayDateByDate(targetDate);
		return orderDaoImpl.getUnshippedOrdersBeforeWeek(monday, versionDate);
	}
	
	public List<Order> getSGAUnshippedOrdersBeforeWeek(Date targetDate, Date versionDate) {
		return orderDaoImpl.getSGAUnshippedOrdersBeforeWeek(targetDate, versionDate);
	}

	public List<MtmGeographyOdmCvQuantity> getAllFulfilledCvQuantityInMonth(Date targetDate, Date versionDate) {
		Date monday = CalendarUtil.getMondayDateByDate(targetDate);
		Date lastSunday = CalendarUtil.addDays(monday, -1);

		if (!CalendarUtil.isSameMonth(monday, lastSunday)) {
			// Use targetDate if the first Sunday of the month has not arrived
			lastSunday = targetDate;
		}

		return orderDaoImpl.getAllFulfilledCvQuantityInMonth(targetDate, lastSunday, versionDate);
	}

	public List<Forecast> getAllMtmForecastsInWeek(Date targetDate, Date versionDate) {
		Date monday = CalendarUtil.getMondayDateByDate(targetDate);
		return forecastDaoImpl.getAllMtmForecastsInWeek(monday, versionDate);
	}

	public List<CtoCvConfig> getAllCtoForecastsInWeek(Date targetDate, Date versionDate) {
		Date monday = CalendarUtil.getMondayDateByDate(targetDate);
		return forecastDaoImpl.getAllCtoForecastsInWeek(monday, versionDate);
	}

	@Deprecated
	public List<EolForecast> getAllEolMtmForecastsInWeek(Date targetDate, Date versionDate, boolean justLastWeek) {
		Date monday = CalendarUtil.getMondayDateByDate(targetDate);
		return forecastDaoImpl.getAllEolMtmForecastsInWeek(monday, versionDate, justLastWeek);
	}

	public List<MtmGeographyOdmCvQuantity> getAllMtmForecastCvQuantityInMonth(Date targetDate, Date versionDate) {
		return forecastDaoImpl.getAllMtmForecastCvQuantityInMonth(targetDate, versionDate);
	};

	public List<MtmGeographyOdmCvQuantity> getAllCtoForecastCvQuantityInMonth(Date targetDate, Date versionDate) {
		return forecastDaoImpl.getAllCtoForecastCvQuantityInMonth(targetDate, versionDate);
	}

	public List<Forecast> getAllMtmForecastsInWeekForVersionWeek(Date targetDate, Date versionDate, int versionWeek) {
		Date versionMonday = CalendarUtil.getMondayDateByWeeks(versionDate, versionWeek);
		return forecastDaoImpl.getAllMtmForecastsInWeekForVersionDate(targetDate, versionMonday);
	}
	public List<Forecast> getForecastsInWeekByProductKey(Date targetDate, Date versionDateStart,Date versionDateEnd,String productKey,String waveId){
		return forecastDaoImpl.getForecastsInWeekByProductKey(targetDate, versionDateStart,versionDateEnd, productKey,waveId);
	}
	public List<CtoCvConfig> getAllCtoForecastsInWeekForVersionDate(Date targetDate, Date versionDate, int versionWeek) {
		Date versionMonday = CalendarUtil.getMondayDateByWeeks(versionDate, versionWeek);
		return forecastDaoImpl.getAllCtoForecastsInWeekForVersionDate(targetDate, versionMonday);
	}

	@SuppressWarnings("deprecation")
	public CtoCvConfig getCtoForecast(String productKey, String geographyName, String odmName, Date targetDate, Date versionDate) {
		Date monday = CalendarUtil.getMondayDateByDate(targetDate);
		return forecastDaoImpl.getCtoForecast(productKey, geographyName, odmName, monday, versionDate);
	}

	public void fillCtoCvConfig(CtoCvConfig ctoCvConfig, Date targetDate, Date versionDate) {
		Date monday = CalendarUtil.getMondayDateByDate(targetDate);
		forecastDaoImpl.fillCtoCvConfig(ctoCvConfig, monday, versionDate);
	}

	public SingleUnitCvConfig getSingleUnitCvConfigOfMtm(String bomNumber) {
		return mtmDaoImpl.getSingleUnitCvConfigOfMtm(bomNumber);
	}

	public List<MtmCvQuantity> getAllMtmCvQuantity() {
		return mtmDaoImpl.getAllMtmCvQuantity();
	}
	public Map<String,GlobalCV> getAllGolobalCV(){
		List<GlobalCV> list = mtmDaoImpl.getAllGolobalCV();
		if(CollectionUtils.isNotEmpty(list)){
			Map<String,GlobalCV> map = new HashMap<String,GlobalCV>();
			for(GlobalCV cv : list){
				map.put(cv.getGlobalCVKey(), cv);
			}
			return map;
		}else{
			return null;
		}
	}
	public List<ProductKeyPmsWaveId> getProductKeyPmsWaveIdList() {
		return npiProjectWaveDaoImpl.getProductKeyPmsWaveIdList();
	}
	public String getProductKeyByPmsWaveId(Integer waveId){
		return npiProjectWaveDaoImpl.getProductKeyByPmsWaveId(waveId);
	}
	public List<ToolingCapacity> getToolingCapacityInWeek(Date targetDate, Date versionDate) {
		return toolingCapacityDaoImpl.getToolingCapacityInWeek(targetDate, versionDate);
	}
	public List<ToolingCapacity> getToolingCapacityByWave(Integer pmsWaveId, Date versionDate){
		return toolingCapacityDaoImpl.getToolingCapacityByWave(pmsWaveId, versionDate);
	}
	public List<DnsEntry> getAllDnsEntriesInWeekForVersionDate(Date targetDate, Date versionDate) {
		return dnsDaoImpl.getAllDnsEntriesInWeekForVersionDate(targetDate, versionDate);
	}

	public List<Product> getAllEolProductsInWeek(Date targetDate, boolean justLastWeek) {
		return productDaoImpl.getAllEolProductsInWeek(targetDate, justLastWeek);
	}

	public List<CausesByOrder> getCauseOrderDetail(List<NpiWeeklyComponentCommitmentOnOrder> list) {

		List<Order> orders = orderDaoImpl.getOrderByPoItemAndNumber(list);
		List<CausesByOrder> result = new ArrayList<CausesByOrder>();
		if (orders != null) {
			for (Order order : orders) {
				CausesByOrder cbo = new CausesByOrder();
				cbo.setRegion(order.getGeographyName());
				cbo.setMtm(order.getBomNumber());
				cbo.setMtmDesc(order.getMtmDesc());
				cbo.setOdm(order.getOdmName());
				cbo.setOrderDate(order.getOrderDate());
				cbo.setQuantity(String.valueOf(order.getQuantity()));
				cbo.setRsd(order.getRsd());
				cbo.setShipmentDate(order.getShipDate());
			}
		}

		return result;
	}

	public List<CausesByForecast> getCauseForecastDetail(Date targetDate, Date versionDate, List<NpiWeeklyComponentCommitmentOnForecast> list) {

		List<Forecast> fcst = forecastDaoImpl.getCausedByForecastByForecastData(targetDate, versionDate, list);
		List<CausesByForecast> result = new ArrayList<CausesByForecast>();
		if (fcst != null) {
			for (Forecast forecast : fcst) {
				CausesByForecast cbf = new CausesByForecast();
				cbf.setRegion(forecast.getGeographyName());
				cbf.setMtm(forecast.getBomNumber());
				cbf.setMtmDesc(forecast.getMtmDesc());
				cbf.setOdm(forecast.getOdmName());
				cbf.setQuantity(String.valueOf(forecast.getQuantity()));
			}
		}

		return result;
	}

	public Map<Date, List<Forecast>> getForecastByRange(int waveId, Date targetDate, Date versionEndWeek, Date versionStartWeek,boolean showGeo) {
		return forecastDaoImpl.getForecastByRange(waveId, targetDate, versionEndWeek, versionStartWeek,showGeo);
	}

	public List<ForecastCompare> getForecastByDates(String waveId, Date targetDate,Date comparedDate, Date compareDate,String region) {
		return forecastDaoImpl.getForecastByDates(waveId, targetDate, comparedDate, compareDate, region);
	}
	public List<OdmCapacityPlanDetail> getOdmItems(int pmsWaveId, String versionDate, String startDate,String endDate){
		return npiOdmCapacityDaoImpl.getOdmItems(pmsWaveId, versionDate, startDate, endDate);
	}
	public List<TdmsDefectDetail> getDefectItems(String pmsWaveId, Date versionDate){
		return npiOdmCapacityDaoImpl.getDefectItems(pmsWaveId, versionDate);
	}
	public Map<String,String> getRampCommitItems(String pmsWaveId, String startDate,String endDate){
		Map map=new HashMap();
		List<RampCommitDTO> list=rampCommitService.getRampCommitByWaveIdAndTargetDate(pmsWaveId, startDate, endDate);
		try {
			for(RampCommitDTO ramp:list){
					map.put(CalendarUtil.date2String(ramp.getTargetDate()) , ramp.getValue());
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return map;
	}
	public List<ToolingCapacityDetail> getToolingItems(String pmsWaveId, String versionDate, String startDate,String endDate){
		return toolingCapacityDaoImpl.getToolingItems(pmsWaveId, versionDate, startDate, endDate);
	}

	public List<DnsEntry> getNpiDnsEntryList(Date versionDate) {
		// TODO Auto-generated method stub
		return dnsDaoImpl.getAllDnsEntriesInWeekForVersionDate(null, versionDate);
	}

	/**
	 * 
	 * @param versionDate
	 * @param cvKey
	 * @return
	 */
	public List<NpiDnsEntry> getDnsList(Date versionDate,Integer cvKey) {
		// TODO Auto-generated method stub
		return dnsDaoImpl.getDnsList(versionDate,cvKey);
	}

	/**
	 * 获得13周的dns数据
	 * @param versionDate
	 * @return
	 */
	public List<Integer> getDnsCvKeyList(Date versionDate) {
		// TODO Auto-generated method stub
		return  dnsDaoImpl.getDnsCvKeyList(versionDate);
	}

	public List<NpiForecast> getNpiForecastByTargetDate(Integer cvKey,
			Integer versionDateKey, Integer targetDateKey, Integer i) {
		// TODO Auto-generated method stub
		return forecastService.getNpiForecastByTargetDate( cvKey,
				 versionDateKey,  targetDateKey,  i);
	}



	/**
	 * 若当月为第一个月，调此方法获取forecast
	 * @param month_1
	 * @param month_2
	 * @param year_1
	 * @param year_2
	 * @param dns
	 * @param forecastDate
	 * @param dnsversion 
	 * @return
	 */
	public List<NpiForecast> getForecastRateMonthone(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2, NpiDnsEntry dns,Integer forecastDate, Integer dnsversion) {
		// TODO Auto-generated method stub
		return forecastService.getForecastRateMonthone( month_1,
				 month_2,  year_1,  year_2,  dns,forecastDate,dnsversion);
	}

	public List<NpiForecast> getForecastRateMonthtwo(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2,
			String shortegeCode_1, NpiDnsEntry dns,Integer forecastDate,Integer dnsversion) {
		// TODO Auto-generated method stub
		return forecastService.getForecastRateMonthtwo( month_1,
				 month_2,  year_1,  year_2,
				 shortegeCode_1,  dns,forecastDate,dnsversion);
	}

	public List<NpiForecast> getForecastRateMonththree(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2,
			String shortegeCode_1, String shortegeCode_2, NpiDnsEntry dns,Integer forecastDate,Integer dnsversion) {
		// TODO Auto-generated method stub
		return forecastService.getForecastRateMonththree( month_1,
				 month_2,  year_1,  year_2,
				 shortegeCode_1,  shortegeCode_2,  dns,forecastDate,dnsversion);
	}

	public Integer get2MonthsAgoMondayOfMonthkDate(int targetDateKey) {
		// TODO Auto-generated method stub
		return forecastService.get2MonthsAgoMondayOfMonthkDate(targetDateKey);
	}

	public Integer get3MonthsAgo4WeeksMondayOfMonthkDate(int targetDateKey) {
		// TODO Auto-generated method stub
		return forecastService.get3MonthsAgo4WeeksMondayOfMonthkDate(targetDateKey);
	}

	public boolean getForecastByVersionDate(Integer forecastDate) {
		// TODO Auto-generated method stub
	 List list = forecastService.getForecastByVersionDate(forecastDate);
	 if( !(null==list||list.size()==0)){
		return true;
		}
	 return false;
	}
	
	public Date getDnsVersionDate(Date versionDate){
		return dnsDaoImpl.getDnsVersionDate(versionDate);
	}
	
	//public Map<String, Integer> getOdmCommitMap(Date versionDate, Date targetDate, Date dnsVersionDate){
	public Map<Date, Integer> getOdmCommitMap(Date versionDate, Integer pmsWaveId, Date dnsVersionDate){
		//Map<String, Integer> odmCommitMap = new HashMap<String, Integer>();
		//List<OdmCommitDto> odmCommitList = npiOdmCapacityDaoImpl.getOdmCommit(versionDate, targetDate, dnsVersionDate);
		Map<Date, Integer> odmCommitMap = new HashMap<Date, Integer>();
		List<OdmCommitDto> odmCommitList = npiOdmCapacityDaoImpl.getOdmCommit(versionDate, pmsWaveId, dnsVersionDate);
		for(OdmCommitDto odmCommitDto : odmCommitList){
			//odmCommitMap.put("" + odmCommitDto.getProductKey() + odmCommitDto.getPmsWaveId(), odmCommitDto.getOdmCommit());
			odmCommitMap.put(odmCommitDto.getTargetDate(), odmCommitDto.getOdmCommit());
		}
		return odmCommitMap;
	}
	
}
