package com.lenovo.bi.service.sc.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.npi.NpiOrderDaoDw;
import com.lenovo.bi.dao.sc.OTSDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.OTSStatusEnum;
import com.lenovo.bi.enumobj.OrderTypeEnum;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.service.common.CommonService;
import com.lenovo.bi.service.sc.BPSService;
import com.lenovo.bi.service.sc.FPSDService;
import com.lenovo.bi.service.sc.ONSService;
import com.lenovo.bi.service.sc.SCService;
import com.lenovo.bi.service.sc.ScCommonService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.LineSet;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSet;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;

@Service
public class SCServiceImpl implements SCService {

	@Inject
	OTSDao otsDao;
	
	@Inject
	CommonService commonService;
	
	@Inject
	NpiOrderDaoDw npiOrderDaoDw;
	
	@Inject
	ScCommonService scCommonService;
	
	@Inject
	FPSDService fpsdService;
	
	@Inject
	ONSService onsService;
	
	@Inject
	BPSService bpsService;
	
	@Override
	public MSColumnChartView getSCOtsOverviewChart(SearchOtsForm form) throws ParseException {
		MSColumnChartView columnChartView = new MSColumnChartView();
		setOverviewChartInfomation(columnChartView);
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
				|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
			String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
			
			if(!form.isShowQuarterOverview()) {
				for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
					String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
					if (form.getEndDate()!=null && yearMonth.compareTo(form.getEndDate()) > 0) 
						break;
					Category category = new Category();
					category.setName(yearMonth);
					categoryList.add(category);
				}
			}
			else {
				String date = form.getStartDate().substring(0, 5) + "01"; 
				for(int i=0; i<4; i++) {
					Category category = new Category();
					category.setName("Q"+ (i+1));
					String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
					String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
					category.setQuarterValue(quarterFrom + "||" + quarterTo);
					categoryList.add(category);
				}
			}
			
		}
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		//dataset list and lineset list
		List<DataSet> dataSetList = new ArrayList<DataSet>();
		List<LineSet> lineSetList = new ArrayList<LineSet>();
		
		//dataset
		DataSet otsOrderDataSet = new DataSet();
		
		LineSet makeRateLineSet = new LineSet();
		makeRateLineSet.setSeriesName("Make Rate");
		makeRateLineSet.setColor("0000FF");
		makeRateLineSet.setShowValues("0");
		makeRateLineSet.setLineThickness("2");
		
		LineSet targetLineSet = new LineSet();
		targetLineSet.setSeriesName("Target");
		targetLineSet.setColor("CC9933");
		targetLineSet.setShowValues("0");
		targetLineSet.setLineThickness("2");
		
		//dataset:seriesName
		List<DataSetParent> otsOrderDataSetList = new ArrayList<DataSetParent>();
		
		DataSetColumn makeDataSetColumn = new DataSetColumn();
		makeDataSetColumn.setSeriesName(OTSStatusEnum.MAKE.getTypeName());
		makeDataSetColumn.setColor("00CC00");
		List<ColumnData> makeCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn failDataSetColumn = new DataSetColumn();
		failDataSetColumn.setSeriesName(OTSStatusEnum.FAIL.getTypeName());
		failDataSetColumn.setColor("FF0000");
		List<ColumnData> failCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn toBeMakeDataSetColumn = new DataSetColumn();
		toBeMakeDataSetColumn.setSeriesName(OTSStatusEnum.ToBeMake.getTypeName());
		toBeMakeDataSetColumn.setColor("FFCC00");
		List<ColumnData> toBeMakeCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn toBeFailDataSetColumn = new DataSetColumn();
		toBeFailDataSetColumn.setSeriesName(OTSStatusEnum.ToBeFail.getTypeName());
		toBeFailDataSetColumn.setColor("999999");
		List<ColumnData> toBeFailCloumnDataList = new ArrayList<ColumnData>();
		
		List<ColumnData> makeRateColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		
		LinkedHashMap<Object,List<ScOverViewChartData>> otsOverviewMap = null;
		
		otsOverviewMap = fetchOtsOverViewChartData(form);
		
		int i=0;
		for(Map.Entry<Object, List<ScOverViewChartData>> entry : otsOverviewMap.entrySet()) {
			String name = ((KeyNameObject)entry.getKey()).getObjName();
			int key = -1;
			if(((KeyNameObject)entry.getKey()).getObjKey() != null)
				key = ((KeyNameObject)entry.getKey()).getObjKey();
			List<ScOverViewChartData> chartDataList = entry.getValue();
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				Category category = new Category();
				category.setName(name);
				categoryList.add(category);
			}
			
			ColumnData make = new ColumnData();
			setOTSOverviewColumnLink(make,name,key);
			make.setValue(0);
			
			ColumnData fail = new ColumnData();
			setOTSOverviewColumnLink(fail,name,key);
			fail.setValue(0);
			
			ColumnData toBeMake = new ColumnData();
			setOTSOverviewColumnLink(toBeMake,name,key);
			toBeMake.setValue(0);
			
			ColumnData toBeFail = new ColumnData();
			setOTSOverviewColumnLink(toBeFail,name,key);
			toBeFail.setValue(0);
			
			ColumnData makeRate = new ColumnData();
			makeRate.setValue(0);
			ColumnData onsNum = new ColumnData();
			onsNum.setValue(0);
			ColumnData fpsdRate = new ColumnData();
			fpsdRate.setValue(0);
			ColumnData bpsRate = new ColumnData();
			bpsRate.setValue(0);
			
			Map<String,Integer> dataMap = new HashMap<String,Integer>();
			
			StringBuffer valueBuffer = new StringBuffer("[{");
			Category category = (Category)(categoryList.get(i));
			for(ScOverViewChartData otsOverViewChartData : chartDataList) {
				if(otsOverViewChartData.getScStatusName().equals(OTSStatusEnum.MAKE.getTypeName())) {
					setOTSOverviewColumnLink(make,name,key);
					make.setValue(otsOverViewChartData.getOrderNum());
					valueBuffer.append("make:");
					dataMap.put(OTSStatusEnum.MAKE.getTypeName(), otsOverViewChartData.getOrderNum());
				}
				else if(otsOverViewChartData.getScStatusName().equals(OTSStatusEnum.FAIL.getTypeName())) {
					setOTSOverviewColumnLink(fail,name,key);
					fail.setValue(otsOverViewChartData.getOrderNum());
					valueBuffer.append("fail:");
					dataMap.put(OTSStatusEnum.FAIL.getTypeName(), otsOverViewChartData.getOrderNum());
				}
				else if(otsOverViewChartData.getScStatusName().equals(OTSStatusEnum.ToBeMake.getTypeName())) {
					setOTSOverviewColumnLink(toBeMake,name,key);
					toBeMake.setValue(otsOverViewChartData.getOrderNum());
					valueBuffer.append("toBeMake:");
					dataMap.put(OTSStatusEnum.ToBeMake.getTypeName(), otsOverViewChartData.getOrderNum());
				}
				else if(otsOverViewChartData.getScStatusName().equals(OTSStatusEnum.ToBeFail.getTypeName())) {
					setOTSOverviewColumnLink(toBeFail,name,key);
					toBeFail.setValue(otsOverViewChartData.getOrderNum());
					valueBuffer.append("toBeFail:");
					dataMap.put(OTSStatusEnum.ToBeFail.getTypeName(), otsOverViewChartData.getOrderNum());
				}
				valueBuffer.append(otsOverViewChartData.getOrderNum()).append(",");
			}
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				valueBuffer.append("subDimensionName:");
				valueBuffer.append("'" + name + "'").append(",");
			}
			
			float makeRateValue = 0;
			float onsNumValue = 0;
			float fpsdRateValue = 0;
			float bpsRateValue = 0;
			
			//ots:makeRateValue
			if(!form.isShowQuarterOverview()) {
				if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
						|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
					makeRateValue = commonService.calculateOtsMakeRate(category.getName(), dataMap);
				}
				else
					makeRateValue = commonService.calculateOtsMakeRate(form.getSelectMonth(), dataMap);
			}
			else {
				makeRateValue = commonService.calculateOtsMakeRateForQuarter(form, category.getQuarterValue(), dataMap);
			}
			
			if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())) {
				//fpsd:fpsdRateValue
				fpsdRateValue = fpsdService.calFpsdRate(category.getName(), form);
				
				//ons:onsNum
				onsNumValue = onsService.calOnsNum(category.getName(), form);
				
				//bps:bpsRateValue
				bpsRateValue = bpsService.calOverViewBpsRateByMonth(category.getName());
			}
			
			makeRate.setValue(makeRateValue);
			onsNum.setValue(onsNumValue);
			fpsdRate.setValue(fpsdRateValue);
			bpsRate.setValue(bpsRateValue);
			makeRateColumnDataList.add(makeRate);
			
			valueBuffer.append("makeRate:");
			valueBuffer.append(makeRateValue).append(",");
			valueBuffer.append("onsNum:");
			valueBuffer.append(onsNumValue).append(",");
			valueBuffer.append("fpsdRate:");
			valueBuffer.append(fpsdRateValue).append(",");
			valueBuffer.append("bpsRate:");
			valueBuffer.append(bpsRateValue).append(",");
			
			String lightColor = commonService.getKPILightColor(form.getOrderTypeName(),makeRateValue);
			valueBuffer.append("lightColor:");
			valueBuffer.append("'" + lightColor + "',");
			String onsLightColor = commonService.getOnsKPILightColor(onsNumValue);
			valueBuffer.append("onsLightColor:");
			valueBuffer.append("'" + onsLightColor + "',");
			String fpsdLightColor = commonService.getKPILightColor(OrderTypeEnum.FPSD.getType(),makeRateValue);
			valueBuffer.append("fpsdLightColor:");
			valueBuffer.append("'" + fpsdLightColor + "',");
			String bpsLightColor = commonService.getKPILightColor(OrderTypeEnum.BPS.getType(),bpsRateValue);
			valueBuffer.append("bpsLightColor:");
			valueBuffer.append("'" + bpsLightColor + "'");
			
			valueBuffer.append("}").append("]");
			//System.out.println("----------KPI:" + valueBuffer.toString());
			
			category.setValues(valueBuffer.toString());
			makeCloumnDataList.add(make);
			failCloumnDataList.add(fail);
			toBeMakeCloumnDataList.add(toBeMake);
			toBeFailCloumnDataList.add(toBeFail);
			
			//Target
			ColumnData target = new ColumnData();
			target.setValue(92);//TODO
			targetCloumnDataList.add(target);
			i++;
		}
		
		makeDataSetColumn.setDataList(makeCloumnDataList);
		otsOrderDataSetList.add(makeDataSetColumn);
		
		failDataSetColumn.setDataList(failCloumnDataList);
		otsOrderDataSetList.add(failDataSetColumn);
		
		toBeMakeDataSetColumn.setDataList(toBeMakeCloumnDataList);
		otsOrderDataSetList.add(toBeMakeDataSetColumn);
		
		toBeFailDataSetColumn.setDataList(toBeFailCloumnDataList);
		otsOrderDataSetList.add(toBeFailDataSetColumn);
		
		otsOrderDataSet.setDataSetList(otsOrderDataSetList);
		makeRateLineSet.setDataList(makeRateColumnDataList);
		targetLineSet.setDataList(targetCloumnDataList);
		
		dataSetList.add(otsOrderDataSet);
		lineSetList.add(makeRateLineSet);
		lineSetList.add(targetLineSet);
		
		columnChartView.setDataSetList(dataSetList);
		columnChartView.setLineSetList(lineSetList);
		
		return columnChartView;
	}
	
	/*@Override
	public MSColumnChartView getSCCaOverviewChart(SearchOtsForm form) throws ParseException {
		
	}*/

	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchOtsOverViewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> otsOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
			String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
			if (date.compareTo(form.getEndDate()) > 0) 
				break;
			KeyNameObject keyNameObject = new KeyNameObject();
			keyNameObject.setObjName(date);
			int year = Integer.parseInt(date.substring(0,4));
			int month = Integer.parseInt(date.substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			otsOverviewMap.put(keyNameObject, otsDao.fetchOtsOverViewChartData(form));
		}
		
		
		return otsOverviewMap;
	}
	
	public void setOTSOverviewColumnLink(ColumnData cloumnData,String name, int key) {
		cloumnData.setLink("j-refreshRemark-" + name + "," + key);
	}
	
	private void setOverviewChartInfomation(MSColumnChartView mSColumnChartView) {
		mSColumnChartView.getChartInfo().setCaption("");
		mSColumnChartView.getChartInfo().setNumdivlines("8");
		mSColumnChartView.getChartInfo().setyAxisMinValue("0");
		mSColumnChartView.getChartInfo().setyAxisMaxValue("160");
		mSColumnChartView.getChartInfo().setsYAxisMinValue("0");
		mSColumnChartView.getChartInfo().setsYAxisMaxValue("100");
		mSColumnChartView.getChartInfo().setFormatNumberScale("0");
		mSColumnChartView.getChartInfo().setLegendIconScale("1");
		mSColumnChartView.getChartInfo().setShowBorder("1");
		mSColumnChartView.getChartInfo().setCanvasBorderThickness("1");
		mSColumnChartView.getChartInfo().setShowZeroPlaneValue("1");
		mSColumnChartView.getChartInfo().setCanvasBorderAlpha("60");
		mSColumnChartView.getChartInfo().setPlotSpacePercent("70");
		mSColumnChartView.getChartInfo().setBgalpha("0,0");
		mSColumnChartView.getChartInfo().setLegendPosition("");
		mSColumnChartView.getChartInfo().setShowBorder("0");
		mSColumnChartView.getChartInfo().setShowPlotBorder("0");
		mSColumnChartView.getChartInfo().setShowValues("0");
	}

	

}
