package com.lenovo.bi.form.sc.bps;

public class SearchBpsForm {
	
	private String startMonth;
	private String endMonth;
	private String startDate;
	private String endDate;
	private String frequency;
	private String dimension;
	private String subDimension;
	private String seriesName;
	private String chartType;

	private String orderTypeId;
	private String orderTypes;
	private String orderSubTypeId;
	private String geoIds;
	private String regionIds;
	private String odmIds;
	private String productIds;
	private String productFamilyIds;
	
	private String kpi;
	private String kpiMonitor;
	private boolean kpiFlg;
	private boolean isDetail;
	private boolean showMonthOverview;
	private String currentMonthOrDay;
	private String selectMonthOrDay;
	private String keyValue;
	private String overDueTime;
	private String sortColumn;
	private String sortType;
	private String reversalSortType;
	private String versionDate;
	
	private String durationFrom;
	private String durationTo;
	
	private int year;
	private int month;
	
	private String partsId;
	private String subPartsId;
	private String purchaseTypeId;
	private String pageType;
	private boolean isShowGeo;
	private String subDimensionKey;
	
	private int endRow;
	private long rowCount;
	
	private String filterPurchaseTypeId;
	
	public String getSortColumn() {
		return sortColumn;
	}
	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}
	public String getSortType() {
		return sortType;
	}
	public void setSortType(String sortType) {
		this.sortType = sortType;
		if("asc".equalsIgnoreCase(sortType)){
			this.reversalSortType = "desc";
		}else if("desc".equalsIgnoreCase(sortType)){
			this.reversalSortType = "asc";
		}
	}
	public String getOrderTypes() {
		return orderTypes;
	}
	public void setOrderTypes(String orderTypes) {
		this.orderTypes = orderTypes;
	}
	public String getStartMonth() {
		return startMonth;
	}
	public void setStartMonth(String startMonth) {
		this.startMonth = startMonth;
	}
	public String getEndMonth() {
		return endMonth;
	}
	public void setEndMonth(String endMonth) {
		this.endMonth = endMonth;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getDimension() {
		return dimension;
	}
	public void setDimension(String dimension) {
		this.dimension = dimension;
	}
	public String getSubDimension() {
		return subDimension;
	}
	public void setSubDimension(String subDimension) {
		this.subDimension = subDimension;
	}
	public String getOrderTypeId() {
		return orderTypeId;
	}
	public void setOrderTypeId(String orderTypeId) {
		this.orderTypeId = orderTypeId;
	}
	public String getOrderSubTypeId() {
		return orderSubTypeId;
	}
	public void setOrderSubTypeId(String orderSubTypeId) {
		this.orderSubTypeId = orderSubTypeId;
	}
	public String getGeoIds() {
		return geoIds;
	}
	public void setGeoIds(String geoIds) {
		this.geoIds = geoIds;
	}
	public String getRegionIds() {
		return regionIds;
	}
	public void setRegionIds(String regionIds) {
		this.regionIds = regionIds;
	}
	public String getOdmIds() {
		return odmIds;
	}
	public void setOdmIds(String odmIds) {
		this.odmIds = odmIds;
	}
	public String getProductIds() {
		return productIds;
	}
	public void setProductIds(String productIds) {
		this.productIds = productIds;
	}
	public String getKpi() {
		return kpi;
	}
	public void setKpi(String kpi) {
		this.kpi = kpi;
	}
	public String getKpiMonitor() {
		return kpiMonitor;
	}
	public void setKpiMonitor(String kpiMonitor) {
		this.kpiMonitor = kpiMonitor;
	}
	public boolean isKpiFlg() {
		return kpiFlg;
	}
	public void setKpiFlg(boolean kpiFlg) {
		this.kpiFlg = kpiFlg;
	}
	public String getCurrentMonthOrDay() {
		return currentMonthOrDay;
	}
	public void setCurrentMonthOrDay(String currentMonthOrDay) {
		this.currentMonthOrDay = currentMonthOrDay;
	}
	public String getSelectMonthOrDay() {
		return selectMonthOrDay;
	}
	public void setSelectMonthOrDay(String selectMonthOrDay) {
		this.selectMonthOrDay = selectMonthOrDay;
	}
	public String getKeyValue() {
		return keyValue;
	}
	public void setKeyValue(String keyValue) {
		this.keyValue = keyValue;
	}
	public String getSeriesName() {
		return seriesName;
	}
	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}
	public String getChartType() {
		return chartType;
	}
	public void setChartType(String chartType) {
		this.chartType = chartType;
	}
	public boolean isDetail() {
		return isDetail;
	}
	public void setDetail(boolean isDetail) {
		this.isDetail = isDetail;
	}
	public String getOverDueTime() {
		return overDueTime;
	}
	public void setOverDueTime(String overDueTime) {
		this.overDueTime = overDueTime;
	}
	public String getVersionDate() {
		return versionDate;
	}
	public void setVersionDate(String versionDate) {
		this.versionDate = versionDate;
	}
	public boolean isShowMonthOverview() {
		return showMonthOverview;
	}
	public void setShowMonthOverview(boolean showMonthOverview) {
		this.showMonthOverview = showMonthOverview;
	}
	public String getDurationFrom() {
		return durationFrom;
	}
	public void setDurationFrom(String durationFrom) {
		this.durationFrom = durationFrom;
	}
	public String getDurationTo() {
		return durationTo;
	}
	public void setDurationTo(String durationTo) {
		this.durationTo = durationTo;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public String getPartsId() {
		return partsId;
	}
	public void setPartsId(String partsId) {
		this.partsId = partsId;
	}
	public boolean isShowGeo() {
		return isShowGeo;
	}
	public void setShowGeo(boolean isShowGeo) {
		this.isShowGeo = isShowGeo;
	}
	public String getPageType() {
		return pageType;
	}
	public void setPageType(String pageType) {
		this.pageType = pageType;
	}
	public String getPurchaseTypeId() {
		return purchaseTypeId;
	}
	public void setPurchaseTypeId(String purchaseTypeId) {
		this.purchaseTypeId = purchaseTypeId;
	}
	public int getEndRow() {
		return endRow;
	}
	public void setEndRow(int endRow) {
		this.endRow = endRow;
	}
	public long getRowCount() {
		return rowCount;
	}
	public void setRowCount(long rowCount) {
		this.rowCount = rowCount;
	}
	public String getReversalSortType() {
		return reversalSortType;
	}
	public void setReversalSortType(String reversalSortType) {
		this.reversalSortType = reversalSortType;
	}
	public String getSubPartsId() {
		return subPartsId;
	}
	public void setSubPartsId(String subPartsId) {
		this.subPartsId = subPartsId;
	}
	public String getSubDimensionKey() {
		return subDimensionKey;
	}
	public void setSubDimensionKey(String subDimensionKey) {
		this.subDimensionKey = subDimensionKey;
	}
	public String getProductFamilyIds() {
		return productFamilyIds;
	}
	public void setProductFamilyIds(String productFamilyIds) {
		this.productFamilyIds = productFamilyIds;
	}
	public String getFilterPurchaseTypeId() {
		return filterPurchaseTypeId;
	}
	public void setFilterPurchaseTypeId(String filterPurchaseTypeId) {
		this.filterPurchaseTypeId = filterPurchaseTypeId;
	}
}
