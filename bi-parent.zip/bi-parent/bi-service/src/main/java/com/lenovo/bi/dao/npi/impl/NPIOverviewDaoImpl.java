package com.lenovo.bi.dao.npi.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateQueryBaseBi;
import com.lenovo.bi.dao.npi.NPIOverviewDao;
import com.lenovo.bi.dto.ProductDataForPopup;
import com.lenovo.bi.dto.TTMProduct;
import com.lenovo.bi.dto.TTVProduct;
import com.lenovo.bi.enumobj.FailProductType;
import com.lenovo.bi.enumobj.NAType;
import com.lenovo.bi.enumobj.NPIPhase;
import com.lenovo.bi.enumobj.PermissionScope;
import com.lenovo.bi.enumobj.Risk;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.enumobj.Success;
import com.lenovo.bi.enumobj.TTVGridColumns;
import com.lenovo.bi.form.npi.SearchProductsFormForPopUp;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
import com.lenovo.common.model.NameValuePair;
import com.lenovo.common.model.PagerInformation;

/**
 * 
 * 
 * @author Henry_Lian
 * 
 */
@SuppressWarnings("unchecked")
@Repository
public class NPIOverviewDaoImpl extends HibernateQueryBaseBi implements
		NPIOverviewDao {

	@Override
	public List<NameValuePair> getProjectStatusByPhase(NPIPhase phase,
			OverviewSearchForm form) {
		StringBuilder hql = null;
		if (phase == NPIPhase.ttm) {
			hql = new StringBuilder(
					"select ttmStatus, count(pmsWaveId) from ProjectSummary as ps where  not exists(select 1 from ProjectSummary where pmsProjectId = ps.pmsProjectId and pmsWaveId = ps.pmsWaveId and DATEDIFF(day,versionDate,ps.versionDate)<0 ) ");
		} else if (phase == NPIPhase.sgaTtv) {
			hql = new StringBuilder(
					"select sgaTtvStatus, count(pmsWaveId) from ProjectSummary as ps where  not exists(select 1 from ProjectSummary where pmsProjectId = ps.pmsProjectId and pmsWaveId = ps.pmsWaveId and DATEDIFF(day,versionDate,ps.versionDate)<0 )  ");
		} else {
			hql = new StringBuilder(
					"select ttvStatus, count(pmsWaveId) from ProjectSummary as ps where  not exists(select 1 from ProjectSummary where pmsProjectId = ps.pmsProjectId and pmsWaveId = ps.pmsWaveId and DATEDIFF(day,versionDate,ps.versionDate)<0 )  ");
		}
		hql.append("  and ((startDate >= :start and startDate <= :end) or (endDate >= :start and endDate <= :end)) ");
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			hql.append(" and pmsProjectId in (select distinct pr.projectId from ProjectRoleUser AS pr join pr.user AS u where u.userId = :userId)");
		}
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			hql.append(" and pmsWaveId in (:ids)");
		}
		if (phase == NPIPhase.ttm) {
			hql.append(" group by ttmStatus");
		} else if (phase == NPIPhase.sgaTtv) {
			hql.append(" group by sgaTtvStatus");
		} else {
			hql.append(" group by ttvStatus");
		}

		Query q = getSession().createQuery(hql.toString());
		// q.setDate("versionDate",
		// CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		q.setDate("start", form.getDurationFrom());
		q.setDate("end", form.getDurationTo());
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			q.setParameterList("ids", form.getWaveIds());
		}
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			q.setString("userId", form.getCurrentUserId());
		}
		List<Object[]> rawlist = q.list();
		List<NameValuePair> list = new ArrayList<NameValuePair>();
		if (rawlist.size() > 0) {
			for (Object[] objectList : rawlist) {
				String status = (String) objectList[0];
				String stats = String.valueOf((Long) objectList[1]);
				list.add(new NameValuePair(status, stats));
			}
		}
		return list;
	}

	@Override
	public List<NameValuePair> getRiskStatusByPhase(NPIPhase phase,
			OverviewSearchForm form) {
		StringBuilder hql = null;
		if (phase == NPIPhase.ttm) {
			hql = new StringBuilder(
					"select isTTMRisk, count(pmsWaveId) from ProjectSummary as p where  not exists(select 1 from ProjectSummary AS ps where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,ps.versionDate,p.versionDate)<0 )  and ttmStatus = 'In_Progress' ");
		} else if (phase == NPIPhase.sgaTtv) {
			hql = new StringBuilder(
					"select isSgaTtvRisk, count(pmsWaveId) from ProjectSummary as p where  not exists(select 1 from ProjectSummary AS ps where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,ps.versionDate,p.versionDate)<0 )  and sgaTtvStatus = 'In_Progress' ");

		} else {
			hql = new StringBuilder(
					"select isTTVRisk, count(pmsWaveId) from ProjectSummary as p where  not exists(select 1 from ProjectSummary AS ps where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,ps.versionDate,p.versionDate)<0 )  and ttvStatus = 'In_Progress' ");
		}
		hql.append("  and ((startDate >= :start and startDate <= :end) or (endDate >= :start and endDate <= :end)) ");
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			hql.append(" and pmsProjectId in (select distinct pr.projectId from ProjectRoleUser AS pr join pr.user AS u where u.userId = :userId)");
		}
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			hql.append(" and pmsWaveId in (:ids)");
		}
		if (phase == NPIPhase.ttm) {
			hql.append(" group by isTTMRisk");
		} else if (phase == NPIPhase.sgaTtv) {
			hql.append(" group by isSgaTtvRisk");
		} else {
			hql.append(" group by isTTVRisk");
		}

		Query q = getSession().createQuery(hql.toString());
		// q.setDate("versionDate",
		// CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		q.setDate("start", form.getDurationFrom());
		q.setDate("end", form.getDurationTo());
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			q.setParameterList("ids", form.getWaveIds());
		}
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			q.setString("userId", form.getCurrentUserId());
		}
		List<Object[]> rawlist = q.list();
		List<NameValuePair> list = new ArrayList<NameValuePair>();
		if (rawlist.size() > 0) {
			for (Object[] objectList : rawlist) {
				Boolean isRisk = (Boolean) objectList[0];
				String stats = String.valueOf((Long) objectList[1]);
				list.add(new NameValuePair(Risk.fromBoolean(isRisk).name(),
						stats));
			}
		}
		return list;
	}

	@Override
	public List<Integer> getSuccessDelays(OverviewSearchForm form) {
		StringBuilder hql = new StringBuilder(
				"select ttmDelays from ProjectSummary as ps where  not exists(select 1 from ProjectSummary where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,versionDate,ps.versionDate)<0 )  and ttmStatus = 'Success' ");
		hql.append("  and ((startDate >= :start and startDate <= :end) or (endDate >= :start and endDate <= :end)) ");
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			hql.append(" and pmsProjectId in (select distinct pr.projectId from ProjectRoleUser AS pr join pr.user AS u where u.userId = :userId)");
		}
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			hql.append(" and pmsWaveId in (:ids)");
		}
		Query q = getSession().createQuery(hql.toString());
		// q.setDate("versionDate",
		// CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		q.setDate("start", form.getDurationFrom());
		q.setDate("end", form.getDurationTo());
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			q.setParameterList("ids", form.getWaveIds());
		}
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			q.setString("userId", form.getCurrentUserId());
		}
		return q.list();
	}

	@Override
	public List<TTMProduct> getTTMProductsByConditions(OverviewSearchForm form) {
		return getTTMProductsByConditions(form, null);
	}

	public List<TTMProduct> getRedTTMProductsByConditions(
			OverviewSearchForm form) {
		StringBuilder hql = new StringBuilder(
				"select new com.lenovo.bi.dto.TTMProduct(pmsWaveId, productName, waveName, ttmStatus, doi, defects, fpy, odm, tooling, ttmTargetDate, ttmSignOffDate,isTTMRisk, ttmDelays, pmsProjectId, currentPhase, pm, startDate) from ProjectSummary as ps where  not exists(select 1 from ProjectSummary where pmsProjectId = ps.pmsProjectId and pmsWaveId = ps.pmsWaveId and DATEDIFF(day,versionDate,ps.versionDate)<0 ) ");

		if (null != form.getDurationFrom()) {
			hql.append(" and (startDate >= :start or endDate >= :start) ");
		}
		if (null != form.getDurationTo()) {
			hql.append(" and (startDate <= :end or endDate <= :end) ");
		}
		hql.append(" and (DOI = 'RED' or GatingDefects = 'RED') ");

		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			hql.append(" and pmsProjectId in (select distinct pr.projectId from ProjectRoleUser AS pr join pr.user AS u where u.userId = :userId)");
		}
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			hql.append(" and pmsWaveId in (:ids)");
		}

		if (null != form.getGridType() && form.getGridType() != Status.All) {
			hql.append(" and ttmStatus = :status");
		}

		if (null != form.getRisk() && form.getRisk() != Risk.All) {
			hql.append(" and isTTMRisk = :risk");
		}

		if (null != form.getSuccess() && form.getSuccess() != Success.All
				&& form.getSuccessDelay() != null) {
			if (form.getSuccess() == Success.On_Schedule) {
				hql.append(" and TTMSuccessDelay <= 0");
			} else if (form.getSuccess() == Success.Delay_Greater_than_NUM_Days) {
				hql.append(" and TTMSuccessDelay > ");
				hql.append(form.getSuccessDelay());
			} else {
				hql.append(" and TTMSuccessDelay <= ");
				hql.append(form.getSuccessDelay());
				hql.append(" and TTMSuccessDelay > 0");
			}
		}

		if (null != form.getTtmSortColumn()) {
			hql.append(" order by ");
			hql.append(form.getTtmSortColumn().getDbColumnName());
			hql.append(" ");
			hql.append(form.getSortType().toString());
		}

		Query q = getSession().createQuery(hql.toString());
		// q.setDate("versionDate",
		// CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		if (null != form.getDurationFrom()) {
			q.setDate("start", form.getDurationFrom());
		}
		if (null != form.getDurationTo()) {
			q.setDate("end", form.getDurationTo());
		}
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			q.setParameterList("ids", form.getWaveIds());
		}
		if (null != form.getGridType() && form.getGridType() != Status.All) {
			q.setString("status", form.getGridType().name());
		}
		if (null != form.getRisk() && form.getRisk() != Risk.All) {
			q.setBoolean("risk", form.getRisk().isRisk());
		}
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			q.setString("userId", form.getCurrentUserId());
		}
		return q.list();
	}

	@Override
	public List<TTMProduct> getTTMProductsByConditions(OverviewSearchForm form,
			PagerInformation pageInfo) {
		StringBuilder hql = new StringBuilder(
				"select new com.lenovo.bi.dto.TTMProduct(pmsWaveId, productName, waveName, ttmStatus, doi, defects, fpy, odm, tooling, ttmTargetDate, ttmSignOffDate,isTTMRisk, ttmDelays, pmsProjectId, currentPhase, pm, startDate) from ProjectSummary as ps where  not exists(select 1 from ProjectSummary where pmsProjectId = ps.pmsProjectId and pmsWaveId = ps.pmsWaveId and DATEDIFF(day,versionDate,ps.versionDate)<0 ) ");

		hql.append(" and ((startDate >= :start and startDate <= :end) ");
		hql.append(" or (endDate <= :end and endDate >= :start) )");
		if (null != form.getFailProductType()) {
			if (form.getFailProductType() == FailProductType.DOI_Not_Ready)
				hql.append(" and DOI = 'RED'");
			else if (form.getFailProductType() == FailProductType.Gating_Defects)
				hql.append(" and GatingDefects = 'RED'");
		}

		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			hql.append(" and pmsProjectId in (select distinct pr.projectId from ProjectRoleUser AS pr join pr.user AS u where u.userId = :userId)");
		}
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			hql.append(" and pmsWaveId in (:ids)");
		}

		if (null != form.getGridType() && form.getGridType() != Status.All) {
			hql.append(" and ttmStatus = :status");
		}

		if (null != form.getRisk() && form.getRisk() != Risk.All) {
			hql.append(" and isTTMRisk = :risk");
		}

		if (null != form.getSuccess() && form.getSuccess() != Success.All
				&& form.getSuccessDelay() != null) {
			if (form.getSuccess() == Success.On_Schedule) {
				hql.append(" and TTMSuccessDelay <= 0");
			} else if (form.getSuccess() == Success.Delay_Greater_than_NUM_Days) {
				hql.append(" and TTMSuccessDelay > ");
				hql.append(form.getSuccessDelay());
			} else {
				hql.append(" and TTMSuccessDelay <= ");
				hql.append(form.getSuccessDelay());
				hql.append(" and TTMSuccessDelay > 0");
			}
		}

		if (null != form.getTtmSortColumn()) {
			hql.append(" order by ");
			hql.append(form.getTtmSortColumn().getDbColumnName());
			hql.append(" ");
			hql.append(form.getSortType().toString());
		}

		Query q = getSession().createQuery(hql.toString());
		// q.setDate("versionDate",
		// CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		if (null != form.getDurationFrom()) {
			q.setDate("start", form.getDurationFrom());
		}
		if (null != form.getDurationTo()) {
			q.setDate("end", form.getDurationTo());
		}
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			q.setParameterList("ids", form.getWaveIds());
		}
		if (null != form.getGridType() && form.getGridType() != Status.All) {
			q.setString("status", form.getGridType().name());
		}
		if (null != form.getRisk() && form.getRisk() != Risk.All) {
			q.setBoolean("risk", form.getRisk().isRisk());
		}
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			q.setString("userId", form.getCurrentUserId());
		}
		if (pageInfo != null) {
			q.setMaxResults(pageInfo.getPageSize());
			q.setFirstResult(pageInfo.getStartRow());
		}
		return q.list();
	}

	@Override
	public int getTTMProductCountByConditions(OverviewSearchForm form) {
		StringBuilder hql = new StringBuilder(
				"select count(pmsWaveId) from ProjectSummary as ps where  not exists(select 1 from ProjectSummary where pmsProjectId = ps.pmsProjectId and pmsWaveId = ps.pmsWaveId and DATEDIFF(day,versionDate,ps.versionDate)<0 )  ");
		hql.append("and ((startDate >= :start and startDate <= :end) or (endDate >= :start and endDate <= :end)) ");
		if (null != form.getFailProductType()) {
			if (form.getFailProductType() == FailProductType.DOI_Not_Ready)
				hql.append(" and DOI = 'RED'");
			else if (form.getFailProductType() == FailProductType.Gating_Defects)
				hql.append(" and GatingDefects = 'RED'");
		}

		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			hql.append(" and pmsProjectId in (select distinct pr.projectId from ProjectRoleUser AS pr join pr.user AS u where u.userId = :userId)");
		}
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			hql.append(" and pmsWaveId in (:ids)");
		}

		if (null != form.getGridType() && form.getGridType() != Status.All) {
			hql.append(" and ttmStatus = :status");
		}

		if (null != form.getRisk() && form.getRisk() != Risk.All) {
			hql.append(" and isTTMRisk = :risk");
		}

		if (null != form.getSuccess() && form.getSuccess() != Success.All
				&& form.getSuccessDelay() != null) {
			if (form.getSuccess() == Success.On_Schedule) {
				hql.append(" and TTMSuccessDelay <= 0");
			} else if (form.getSuccess() == Success.Delay_Greater_than_NUM_Days) {
				hql.append(" and TTMSuccessDelay > ");
				hql.append(form.getSuccessDelay());
			} else {
				hql.append(" and TTMSuccessDelay <= ");
				hql.append(form.getSuccessDelay());
				hql.append(" and TTMSuccessDelay > 0");
			}
		}

		Query q = getSession().createQuery(hql.toString());
		// q.setDate("versionDate",
		// CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		q.setDate("start", form.getDurationFrom());
		q.setDate("end", form.getDurationTo());
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			q.setParameterList("ids", form.getWaveIds());
		}
		if (null != form.getGridType() && form.getGridType() != Status.All) {
			q.setString("status", form.getGridType().name());
		}
		if (null != form.getRisk() && form.getRisk() != Risk.All) {
			q.setBoolean("risk", form.getRisk().isRisk());
		}
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			q.setString("userId", form.getCurrentUserId());
		}
		List<Long> rs = q.list();
		if (rs.size() == 0) {
			return 0;
		} else {
			return rs.get(0).intValue();
		}

	}

	@Override
	public List<ProductDataForPopup> getPopupGridDataByConditions(
			SearchProductsFormForPopUp form) {

		StringBuilder sql = new StringBuilder(
				"select ps.pmsWaveId as npiWaveId ,ps.ProductName,ps.WaveName,ps.family");
		sql.append(" from BI_ProjectSummary ps ");

		sql.append(" where  not exists(select 1 from BI_ProjectSummary where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,versionDate,ps.versionDate)<0 ) ");
		if (form.getDurationFrom() != null && form.getDurationTo() != null) {
			sql.append("and ((startDate >= :start and startDate <= :end) ");
			sql.append("or (endDate >= :start and endDate <= :end)) ");
		}

		setSearchConditon(form, sql);

		if (form.getScope().name().equals(PermissionScope.my.name())) {
			sql.append(" and ps.pmsprojectid in ");
			sql.append(" (select distinct pr.projectid from V_PMS_Project_Role_User AS pr where pr.UserId = :userId )");
		}

		Query query = getSession()
				.createSQLQuery(sql.toString())
				.addScalar("npiWaveId", IntegerType.INSTANCE)
				.addScalar("ProductName", StringType.INSTANCE)
				.addScalar("WaveName", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.setResultTransformer(
						Transformers.aliasToBean(ProductDataForPopup.class));
		// query.setDate("versionDate",
		// CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		if (form.getDurationFrom() != null) {
			query.setDate("start", form.getDurationFrom());
		}
		if (form.getDurationTo() != null) {
			query.setDate("end", form.getDurationTo());
		}

		setSearchValues(form, query);

		if (form.getScope().name().equals(PermissionScope.my.name())) {
			query.setString("userId", form.getCurrentUserId());
		}

		return query.list();
	}

	@Override
	public List<TTVProduct> getTTVProductsByConditions(OverviewSearchForm form,
			PagerInformation pagerInfo) {

		StringBuilder hql = new StringBuilder(
				"select new com.lenovo.bi.dto.TTVProduct(ps.pmsWaveId, ps.productName, ps.waveName, ps.ttvStatus, ps.ttmSignOffDate, ps.ttvTargetDate, ps.ttvSignOffDate, ");
		hql.append(
				"ps.ttvTarget,isnull(ps.isTTVRisk,1), ps.estimatedTTV,ps.actualTTV, ps.pmsProjectId,ps.currentPhase, ps.pm, ps.startDate,ps.ttmTargetDate,ps.isProjectPlanned,")
				.append("ps.sgaTtvStatus,ps.sgaTtvTargetDate,ps.sgaTtvSignOffDate,ps.sgaTtvTarget,ps.sgaEstimatedTTV,ps.sgaActualTTV,isnull(ps.isSgaTtvRisk,1), ")
				.append("case ps.isProjectPlanned when 0 then 'No Project Plan' else case  when ps.ttvTargetDate is null then 'No TTV Target Date' end  end as naType, ")
				.append("case ps.isProjectPlanned when 0 then 'No Project Plan' else case  when ps.sgaTtvTargetDate is null then 'No TTV Target Date' end  end as sgaNaType")
				.append(") ");
		hql.append(" from ProjectSummary AS ps");

		if (form.getNpi() != null && !form.getNpi().isEmpty()) {
			hql.append(" join ps.projectRoleUser AS pr join pr.pmsRole AS po join pr.user AS user");
		}

		hql.append(" where not exists(select 1 from ProjectSummary where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,versionDate,ps.versionDate)<0 ) ");
		hql.append(" and ((ps.startDate >= :start and ps.startDate <= :end) or (ps.endDate >= :start and ps.endDate <= :end)) ");
		if (null != form.getNaType()) {
			if (form.getNaType() == NAType.No_Project_Plan)
				hql.append(" and ps.isProjectPlanned = 0 ");
			else if (form.getNaType() == NAType.No_TTV_Target_Date) {
				hql.append(" and ps.isProjectPlanned = 1 ");
				if (null != form.getSgaGridType()
						&& form.getSgaGridType() != Status.All) {
					hql.append(" and ps.sgaTtvTargetDate is null");
				} else {
					hql.append(" and ps.ttvTargetDate is null");
				}
			}
		}

		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			hql.append(" and pmsProjectId in (select distinct pr.projectId from ProjectRoleUser AS pr join pr.user AS u where u.userId = :userId)");
		}
		if (form.getNpi() != null && !form.getNpi().isEmpty()) {
			hql.append("  and user.userId in (:npiIds) and po.buildinRoleCode = 'NPI' ");
		}

		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			hql.append(" and ps.pmsWaveId in (:ids)");
		}

		if (null != form.getGridType() && form.getGridType() != Status.All) {
			hql.append(" and ps.ttvStatus = :status");
		}

		if (null != form.getRisk() && form.getRisk() != Risk.All) {
			hql.append(" and ps.isTTVRisk = :risk");
		}

		if (null != form.getSgaGridType()
				&& form.getSgaGridType() != Status.All) {
			hql.append(" and ps.sgaTtvStatus = :sgaStatus");
		}

		if (null != form.getSgaRisk() && form.getSgaRisk() != Risk.All) {
			hql.append(" and ps.isSgaTtvRisk = :sgaRisk");
		}

		if (null != form.getTtvSortColumn()) {
			hql.append(" order by ");
			if (form.getTtvSortColumn() == TTVGridColumns.NaType) {
				hql.append(" case ps.isProjectPlanned when 0 then 'No Project Plan' else case  when ps.ttvTargetDate is null then 'No TTV Target Date' end  end ");
			} else if (form.getTtvSortColumn() == TTVGridColumns.SgaNaType) {
				hql.append(" case ps.isProjectPlanned when 0 then 'No Project Plan' else case  when ps.sgaTtvTargetDate is null then 'No TTV Target Date' end  end ");
			} else {
				hql.append(form.getTtvSortColumn().getDbColumnName());
			}

			hql.append(" ");
			hql.append(form.getSortType().toString());
		}

		Query q = getSession().createQuery(hql.toString());
		// q.setDate("versionDate",
		// CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		q.setDate("start", form.getDurationFrom());
		q.setDate("end", form.getDurationTo());
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			q.setParameterList("ids", form.getWaveIds());
		}
		if (null != form.getGridType() && form.getGridType() != Status.All) {
			q.setString("status", form.getGridType().name());
		}
		if (null != form.getRisk() && form.getRisk() != Risk.All) {
			q.setBoolean("risk", form.getRisk().isRisk());
		}
		if (null != form.getSgaGridType()
				&& form.getSgaGridType() != Status.All) {
			q.setString("sgaStatus", form.getSgaGridType().name());
		}
		if (null != form.getSgaRisk() && form.getSgaRisk() != Risk.All) {
			q.setBoolean("sgaRisk", form.getSgaRisk().isRisk());
		}
		if (form.getNpi() != null && !form.getNpi().isEmpty()) {
			q.setParameterList("npiIds", form.getNpi());
		}
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			q.setString("userId", form.getCurrentUserId());
		}
		q.setMaxResults(pagerInfo.getPageSize());
		q.setFirstResult(pagerInfo.getStartRow());
		return q.list();
	}

	@Override
	public int getTTVProductCountByConditions(OverviewSearchForm form) {
		StringBuilder hql = new StringBuilder(
				"select count(ps.pmsWaveId) from ProjectSummary AS ps");

		if (form.getNpi() != null && !form.getNpi().isEmpty()) {
			hql.append(" join ps.projectRoleUser AS pr join pr.pmsRole AS po join pr.user AS user");
		}

		hql.append(" where  not exists(select 1 from ProjectSummary where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,versionDate,ps.versionDate)<0 )  ");
		hql.append(" and ((ps.startDate >= :start and ps.startDate <= :end) or (ps.endDate >= :start and ps.endDate <= :end)) ");
		if (null != form.getNaType()) {
			if (form.getNaType() == NAType.No_Project_Plan)
				hql.append(" and ps.isProjectPlanned = 0 ");
			else if (form.getNaType() == NAType.No_TTV_Target_Date) {
				hql.append(" and ps.isProjectPlanned = 1 ");
				if (null != form.getSgaGridType()
						&& form.getSgaGridType() != Status.All) {
					hql.append(" and ps.sgaTtvTargetDate is null");
				} else {
					hql.append(" and ps.ttvTargetDate is null");
				}
			}
		}

		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			hql.append(" and pmsProjectId in (select distinct pr.projectId from ProjectRoleUser AS pr join pr.user AS u where u.userId = :userId)");
		}
		if (form.getNpi() != null && !form.getNpi().isEmpty()) {
			hql.append("  and user.userId in (:displayName) and po.buildinRoleCode = 'NPI' ");
		}

		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			hql.append(" and ps.pmsWaveId in (:ids)");
		}

		if (null != form.getGridType() && form.getGridType() != Status.All) {
			hql.append(" and ps.ttvStatus = :status");
		}

		if (null != form.getRisk() && form.getRisk() != Risk.All) {
			hql.append(" and ps.isTTVRisk = :risk");
		}

		if (null != form.getSgaGridType()
				&& form.getSgaGridType() != Status.All) {
			hql.append(" and ps.sgaTtvStatus = :sgaStatus");
		}

		if (null != form.getSgaRisk() && form.getSgaRisk() != Risk.All) {
			hql.append(" and ps.isSgaTtvRisk = :sgaRisk");
		}

		Query q = getSession().createQuery(hql.toString());
		// q.setDate("versionDate",
		// CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		q.setDate("start", form.getDurationFrom());
		q.setDate("end", form.getDurationTo());
		if (null != form.getWaveIds() && !form.getWaveIds().isEmpty()) {
			q.setParameterList("ids", form.getWaveIds());
		}
		if (null != form.getGridType() && form.getGridType() != Status.All) {
			q.setString("status", form.getGridType().name());
		}
		if (null != form.getRisk() && form.getRisk() != Risk.All) {
			q.setBoolean("risk", form.getRisk().isRisk());
		}
		if (null != form.getSgaGridType()
				&& form.getSgaGridType() != Status.All) {
			q.setString("sgaStatus", form.getSgaGridType().name());
		}
		if (null != form.getSgaRisk() && form.getSgaRisk() != Risk.All) {
			q.setBoolean("sgaRisk", form.getSgaRisk().isRisk());
		}
		if (form.getNpi() != null && !form.getNpi().isEmpty()) {
			q.setParameterList("displayName", form.getNpi());
		}
		if (null != form.getScope() && form.getScope() == PermissionScope.my) {
			q.setString("userId", form.getCurrentUserId());
		}
		List<Long> rs = q.list();
		if (rs.size() == 0) {
			return 0;
		} else {
			return rs.get(0).intValue();
		}
	}

	@Override
	public List<ProductDataForPopup> getPopupGridDataForDoi(
			SearchProductsFormForPopUp form) {
		StringBuilder sql = new StringBuilder(
				"select ps.pmsWaveId as npiWaveId,ps.ProductName,ps.WaveName,ps.family");
		sql.append(" from BI_ProjectSummary ps ");

		sql.append(" where  not exists(select 1 from BI_ProjectSummary where pmsWaveId = ps.pmsWaveId and pmsProjectId = ps.pmsProjectId and DATEDIFF(day,versionDate,ps.versionDate)<0 )  ");

		setSearchConditon(form, sql);

		sql.append(" and ps.pmsprojectid in ");
		sql.append(" (select distinct pr.projectid from V_PMS_Project_Role_User AS pr where pr.UserId =:userId )");

		Query query = getSession()
				.createSQLQuery(sql.toString())
				.addScalar("npiWaveId", IntegerType.INSTANCE)
				.addScalar("ProductName", StringType.INSTANCE)
				.addScalar("WaveName", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.setResultTransformer(
						Transformers.aliasToBean(ProductDataForPopup.class));

		setSearchValues(form, query);
		// query.setDate("versionDate",
		// CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins()));
		query.setString("userId", form.getCurrentUserId());

		return query.list();
	}

	private void setSearchValues(SearchProductsFormForPopUp form, Query query) {
		if (StringUtils.isNotBlank(form.getProductName())) {
			query.setString("productName",
					"%" + form.getProductName().replace("_", "[_]") + "%");
		}

		if (StringUtils.isNotBlank(form.getFamilyName())) {
			query.setString("family",
					"%" + form.getFamilyName().replace("_", "[_]") + "%");
		}

		if (CollectionUtils.isNotEmpty(form.getWaveIds())) {
			query.setParameterList("listWaveIds", form.getWaveIds());
		}
	}

	private void setSearchConditon(SearchProductsFormForPopUp form,
			StringBuilder sql) {
		if (StringUtils.isNotBlank(form.getProductName())) {
			sql.append(" and productName like :productName");
		}

		if (StringUtils.isNotBlank(form.getFamilyName())) {
			sql.append(" and family like :family");
		}

		if (CollectionUtils.isNotEmpty(form.getWaveIds())) {
			sql.append(" and pmsWaveId in (:listWaveIds)");
		}
	}

	@Override
	public String getPmsProjectIdByPmsWaveId(String waveId) {
		if (StringUtils.isNotBlank(waveId)) {
			StringBuilder sql = new StringBuilder(
					"select top 1 pmsprojectid from BI_ProjectSummary where pmswaveId= :pmswaveId");
			Query q = getSession().createSQLQuery(sql.toString());
			q.setString("pmswaveId", waveId);
			List<String> list = q.list();
			if (CollectionUtils.isNotEmpty(list)) {
				return String.valueOf(list.get(0));
			}
		}
		return null;
	}

}
