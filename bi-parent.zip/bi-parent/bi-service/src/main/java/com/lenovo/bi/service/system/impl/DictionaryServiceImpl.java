package com.lenovo.bi.service.system.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.poi.ss.formula.functions.T;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.lenovo.bi.dao.privileges.dict.DictionaryDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.system.GroupDetail;
import com.lenovo.bi.model.system.GroupMember;
import com.lenovo.bi.service.system.DictionaryService;
import com.lenovo.bi.view.system.dictionary.BuDetailView;
import com.lenovo.bi.view.system.dictionary.CompanyDetailView;
import com.lenovo.bi.view.system.dictionary.DepartmentDetailView;
import com.lenovo.bi.view.system.dictionary.GroupDetailView;
import com.lenovo.bi.view.system.dictionary.GroupMemberDetailView;
import com.lenovo.bi.view.system.dictionary.PrivilegeDetailView;
import com.lenovo.bi.view.system.dictionary.UserDetailView;
import com.lenovo.common.model.Pager;
import com.lenovo.common.model.PagerInformation;

@Service
public class DictionaryServiceImpl implements DictionaryService {

	@Inject
	private DictionaryDao dictDao;
	
	@Override
	public GroupDetail findGroupById(Integer groupId) {
		return dictDao.findGroupById(groupId);
	}
	
	@Override
	public GroupDetail findGroupByName(String groupName) {
		return dictDao.findGroupByName(groupName);
	}

	
	@Override
	public void saveGroup(GroupDetail groupDetail) {
		dictDao.saveGroup(groupDetail);
	}
	
	@Override
	public void saveGroupMember(List<GroupMember> groupMemberList) {
		dictDao.saveGroupMember(groupMemberList);
	}
	
	@Override
	public void saveEditedGroup(GroupDetail groupDetail) {
		dictDao.saveEditedGroup(groupDetail);
	}
	
	@Override
	public void saveEditedGroupMember(int gId,List<GroupMember> groupMemberList) {
		dictDao.saveEditedGroupMember(gId,groupMemberList);
	}
	
	@Override
	public void deleteGroups(String groupIds) {
		dictDao.deleteGroups(groupIds);
		
	}

	@Override
	public Pager<GroupDetailView> listGroups(DictSearchForm form) {
		Pager<GroupDetailView> pager = new Pager<GroupDetailView>();
		PagerInformation pageInfo = new PagerInformation();
		pager.setPagerInfo(pageInfo);
		pageInfo.setCurrentPage(form.getCurrentPage());
		pageInfo.setPageSize(10);
		List<GroupDetailView> groupList = dictDao.listGroup(form, pager.getPagerInfo());
		pager.setDatas(groupList);
		
		int recordCount = dictDao.getGroupDetailCountByConditions(form);
		pageInfo.setRecordCount(recordCount);
		form.setRecordCount(recordCount);
		
		return pager;
	}
	
	@Override
	public List<GroupDetailView> listGroupsForExcel(DictSearchForm form) {
		return dictDao.listGroupsForExcel(form);
	}


	@Override
	public Pager<PrivilegeDetailView> getPrivilegeDetailList(DictSearchForm form) {
		Pager<PrivilegeDetailView> pager = new Pager<PrivilegeDetailView>();
		PagerInformation pageInfo = new PagerInformation();
		pager.setPagerInfo(pageInfo);
		pageInfo.setCurrentPage(form.getCurrentPage());
		pageInfo.setPageSize(10);
		List<PrivilegeDetailView> privilegeDetailList = dictDao.getPrivilegeDetailList(form, pager.getPagerInfo());
		pager.setDatas(privilegeDetailList);
		
		int recordCount = dictDao.getPrivilegeDetailCountByConditions(form);
		pageInfo.setRecordCount(recordCount);
		form.setRecordCount(recordCount);
		
		return pager;
	}

	@Override
	public String getJsonByName(String type,String name) {
		
		List<T> list = dictDao.listOrg(type,name);
		String jsonStr = new Gson().toJson(list);
		
		//System.out.println("the return json is: " + jsonStr);
		return jsonStr;
	}

	@Override
	public List<GroupMemberDetailView> getGroupMemberByGroupId(Integer groupId,Integer memberType) {
		
		List<GroupMemberDetailView> list = dictDao.getGroupMemberByGroupId(groupId,memberType);
		return list;
	}
	
	@Override
	public GroupDetailView getGroupById(Integer groupId) {
		
		return dictDao.getGroupById(groupId);
	}

	@Override
	public List<KeyNameObject> getCompanyList() {
		
		return dictDao.getCompanyList();
	}
	
	@Override
	public List<KeyNameObject> getBuList() {
		
		return dictDao.getBuList();
	}

	@Override
	public List<CompanyDetailView> queryCompanyByConditions(String companyName) {
		return dictDao.queryCompanyByConditions(companyName);
	}
	
	@Override
	public List<BuDetailView>  queryBuByConditions(String compId,String buName) {
		return dictDao.queryBuByConditions(compId,buName);
	}
	
	@Override
	public List<DepartmentDetailView>  queryDepByConditions(String compId,String buId,String depName) {
		return dictDao.queryDepByConditions(compId,buId,depName);
	}
	
	@Override
	public List<UserDetailView>  queryUserByConditions(String companyName,String buName,String depName,String userName) {
		return dictDao.queryUserByConditions(companyName,buName,depName,userName);
	}
}
