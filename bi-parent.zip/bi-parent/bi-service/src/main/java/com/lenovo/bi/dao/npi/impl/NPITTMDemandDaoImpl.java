package com.lenovo.bi.dao.npi.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.npi.NPITTMDemandDao;
import com.lenovo.bi.dto.TTMDemand;
import com.lenovo.bi.dto.TTMDemandDetail;
/**
 * 
 * 
 * @author henry_lian
 *
 */
@Repository
public class NPITTMDemandDaoImpl extends HibernateBaseDaoImplDw implements NPITTMDemandDao {

	@Override
	public Integer getTTMTargetDemandByWaveId(int pmsWaveId) {
		StringBuffer sql = new StringBuffer("select sum(t.demand) from ")
		.append(" (select f.NPIWaveKey, MTMKey, MIN(Quantity) as demand from FactTTMDemandInGlobalCVFormat f ")
		.append(" inner join DimNPIWave nw on f.NPIWaveKey = nw.NPIWaveKey where nw.PMSWaveIDAlternateKey = ? ")
		.append(" group by f.MTMKey, f.NPIWaveKey) t group by t.NPIWaveKey ");
	
		Query query = getSession().createSQLQuery(sql.toString());
		query.setParameter(0, pmsWaveId);
		Integer result =  (Integer) query.uniqueResult();
		return result == null? 0:result;
	}

	@Override
	public List<TTMDemand> getTTMDemandListByWaveId(int pmsWaveId) {
		StringBuilder sql = new StringBuilder();
		sql.append("select nw.PMSWaveIDAlternateKey as pmsWaveId, f.GlobalCVKey as cvKey, sum(f.Quantity) as demand from FactTTMDemandInGlobalCVFormat f ")
		.append(" inner join DimNPIWave nw on f.NPIWaveKey = nw.NPIWaveKey ")
		.append(" inner join Dimmtm dm on dm.MTMKey = f.MTMKey ")
		.append(" where nw.PMSWaveIDAlternateKey = ? ")
		.append(" group by PMSWaveIDAlternateKey , f.GlobalCVKey  ");
		
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(TTMDemand.class));
		query.setParameter(0, pmsWaveId);
		return query.list();
	}

	@Override
	public List<TTMDemandDetail> getTTMDemandDetailListById(int pmsWaveId) {
		StringBuilder sql = new StringBuilder();
		//sql.append("select nw.PMSWaveIDAlternateKey as pmsWaveId, dm.BOMNumberAlternateKey as bomNumber, f.GlobalCVKey as cvKey, f.Quantity as demand, ct.CommodityType as c, gc.CommodityValue as v, pt.PurchaseType as purchaseType from FactTTMDemandInGlobalCVFormat f ")
		
		sql.append("select nw.PMSWaveIDAlternateKey as pmsWaveId, f.GlobalCVKey as cvKey, sum(f.Quantity) as demand, ct.CommodityType as c, gc.CommodityValue as v, pt.PurchaseType as purchaseType from FactTTMDemandInGlobalCVFormat f ")
		.append(" inner join DimNPIWave nw on f.NPIWaveKey = nw.NPIWaveKey ")
		.append(" inner join Dimmtm dm on dm.MTMKey = f.MTMKey ")
		.append(" inner join DimGlobalCV gc on gc.GlobalCVKey = f.GlobalCVKey ")
		.append(" inner join DimPurchaseType pt on pt.PurchaseTypeKey = gc.PurchaseTypeKey ")
		.append(" inner join DimCommodityType ct on gc.CommodityTypeKey = ct.CommodityTypeKey ")
		.append(" where nw.IsCurrent <> 0 ")
		.append(" and nw.PMSWaveIDAlternateKey = ? ")
		.append(" group by  nw.PMSWaveIDAlternateKey, f.GlobalCVKey, ct.CommodityType, gc.CommodityValue,pt.PurchaseType ");
		
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(TTMDemandDetail.class));
		query.setParameter(0, pmsWaveId);
		return query.list();
	}

}
