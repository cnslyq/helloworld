package com.lenovo.bi.engine;

import java.util.Date;

import com.lenovo.bi.model.ProjectSummary;

/**
 * 
 * 
 * @author henry_lian
 *
 */
public interface NPIKPIProcessor {
	
	public void process(ProjectSummary ps, Date versionDate);
}
