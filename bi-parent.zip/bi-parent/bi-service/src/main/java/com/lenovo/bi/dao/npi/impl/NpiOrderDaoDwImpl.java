package com.lenovo.bi.dao.npi.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BooleanType;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.npi.NpiOrderDaoDw;
import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.dto.DimMtm;
import com.lenovo.bi.dto.DimODM;
import com.lenovo.bi.dto.DimOrderForDetractor;
import com.lenovo.bi.dto.DimOrderForNPIExclude;
import com.lenovo.bi.dto.GeoData;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.form.npi.ttv.SearchOutlookDataForm;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.model.DimDetractor;
import com.lenovo.bi.view.npi.ttv.PoNumberAndPoItem;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;

@SuppressWarnings("rawtypes")
@Repository
public class NpiOrderDaoDwImpl extends HibernateBaseDaoImplDw implements NpiOrderDaoDw {

	@SuppressWarnings("unchecked")
	@Override
	public List<PieDivider> getDetractorMainDivider(SearchOutlookDataForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select dimDetractor.Level1 as level1Name,count(dimOrder.OrderKey) as level1Num ").append(" from DimOrder dimOrder")
				.append(" inner join DimTime dimTime on dimOrder.FGReadyDateKey = dimTime.TimeKey")
				.append(" left join DimMTM dimMTM on dimOrder.MTMKey = dimMTM.MTMKey")
				.append(" inner join DimProduct dimProduct on dimMTM.ProductKey = dimProduct.ProductKey")
				.append(" inner join DimNPIProject dimNPIProject on dimProduct.ProductKey = dimNPIProject.ProductKey")
				.append(" inner join DimNPIWave dimNPIWave on dimNPIProject.NPIProjectKey = dimNPIWave.NPIProjectKey")
				.append(" left join DimDetractor dimDetractor on dimOrder.DetractorKey = dimDetractor.DetractorKey")
				.append(" where datediff(day, ?, dimTime.FullDateAlternateKey) >= 0 ").append(" and datediff(day, ?, dimTime.FullDateAlternateKey) <= 0 ")
				.append(" and dimNPIWave.IsCurrent = 1 and dimNPIProject.IsCurrent = 1 and dimNPIWave.PMSWaveIDAlternateKey = ? ")
				.append(" group by dimDetractor.Level1 having dimDetractor.Level1 is not null");

		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("level1Name", StringType.INSTANCE).addScalar("level1Num", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PieDivider.class));
		query.setParameter(0, form.getStartDate());
		query.setParameter(1, form.getEndDate());
		query.setParameter(2, form.getWaveId());
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DimOrderForDetractor> getDetractorMainUnknownDivider(SearchOutlookDataForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select dimOrder.OrderKey as orderKey  ").append(" from DimOrder dimOrder")
				.append(" inner join DimTime dimTime on dimOrder.FGReadyDateKey = dimTime.TimeKey")
				.append(" left join DimMTM dimMTM on dimOrder.MTMKey = dimMTM.MTMKey")
				.append(" inner join DimProduct dimProduct on dimMTM.ProductKey = dimProduct.ProductKey")
				.append(" inner join DimNPIProject dimNPIProject on dimProduct.ProductKey = dimNPIProject.ProductKey")
				.append(" inner join DimNPIWave dimNPIWave on dimNPIProject.NPIProjectKey = dimNPIWave.NPIProjectKey")
				.append(" where datediff(day, ?, dimTime.FullDateAlternateKey) >= 0 ").append(" and datediff(day, ?, dimTime.FullDateAlternateKey) <= 0 ")
				.append(" and dimNPIWave.IsCurrent = 1 and dimNPIProject.IsCurrent = 1 and dimNPIWave.PMSWaveIDAlternateKey = ? ")
				.append(" and dimOrder.DetractorKey is null");
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("orderKey", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(DimOrderForDetractor.class));
		query.setParameter(0, form.getStartDate());
		query.setParameter(1, form.getEndDate());
		query.setParameter(2, form.getWaveId());
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PieDivider> getDetractorSubDivider(SearchOutlookDataForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select dimDetractor.Level2 as level2Name,count(dimOrder.OrderKey) as level2Num ").append(" from DimOrder dimOrder")
				.append(" left join DimTime dimTime on dimOrder.OrderDateKey = dimTime.TimeKey")
				.append(" left join FactDailyPSD factDailyPSD on dimOrder.OrderKey = factDailyPSD.OrderKey")
				.append(" left join DimDetractor dimDetractor on dimOrder.DetractorKey = dimDetractor.DetractorKey")
				.append(" where datediff(day, ?, dimTime.FullDateAlternateKey) >= 0 ").append("and datediff(day, ?, dimTime.FullDateAlternateKey) <= 0 ")
				.append(" and dimDetractor.Level1 = '").append(form.getParentType()).append("' group by dimDetractor.Level2")
				.append(" having dimDetractor.Level2 != 'null'");
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("level2Name", StringType.INSTANCE).addScalar("level2Num", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PieDivider.class));
		query.setParameter(0, form.getStartDate());
		query.setParameter(1, form.getEndDate());
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TtvGridDetractorCodeView> getDetractorCodeDataGrid(SearchOutlookDataForm form) {

		// product: TODO
		// fpsd: TODO
		// Target Date: TODO
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select dimODM.ODMEnglishName as odm,")
				.append("tableDimGeography.geoName as geo,")
				.append("tableDimGeography.regionName as region,")
				.append("tableDimGeography.countryName as country,")
				.append("dimMTM.BOMNumberAlternateKey as pn,")
				.append("dimMTM.MTMEnglishDescription as itemDesc,")
				.append("dimOrder.OrderNumber as orderNo,")
				.append("dimOrder.POItem as itemNo,")
				.append("dimOrder.Quantity as qty,")
				.append("orderdate.FullDateAlternateKey as orderDate,")
				.append("rsddate.FullDateAlternateKey as rsd,")
				.append("shipdate.FullDateAlternateKey as shippedDate,")
				.append("psd.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ")
				.append(" from DimOrder dimOrder")
				.append(" left join DimTime orderdate on orderdate.TimeKey =  dimOrder.OrderDateKey")
				.append(" left join DimTime rsddate on rsddate.TimeKey =  dimOrder.RSDDateKey")
				.append(" inner join DimTime fgdate on fgdate.TimeKey =  dimOrder.FGReadyDateKey ")
				.append(" left join DimMTM dimMTM on dimOrder.MTMKey = dimMTM.MTMKey")
				.append(" inner join DimProduct dimProduct on dimMTM.ProductKey = dimProduct.ProductKey ")
				.append(" inner join DimNPIProject dimNPIProject on dimProduct.ProductKey = dimNPIProject.ProductKey ")
				.append(" inner join DimNPIWave dimNPIWave on dimNPIProject.NPIProjectKey = dimNPIWave.NPIProjectKey ")
				.append(" left join DimODM dimODM on dimOrder.ODMKey = dimODM.ODMKey")
				.append(" left join FactDailyPSD psd on psd.OrderKey = dimOrder.OrderKey")
				.append(" left join DimTime shipdate on shipdate.TimeKey =  psd.ShipDateKey ")
				.append(" left join DimDetractor dimDetractor on dimOrder.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join (SELECT country.GeographyKey,geo.GeographyName geoName,region.GeographyName regionName,")
				.append(" country.GeographyName countryName,region.ParentGeographyKey,geo.CreatedDate,geo.LastModifiedDate")
				.append(" FROM DimGeography geo")
				.append(" left join DimGeography region on region.ParentGeographyKey = geo.GeographyKey")
				.append(" left join DimGeography country on country.ParentGeographyKey = region.GeographyKey")
				.append(" ) tableDimGeography on dimOrder.GeographyKey = tableDimGeography.GeographyKey")
				.append(" where datediff(day, ?, fgdate.FullDateAlternateKey) >= 0 ")
				.append(" and datediff(day, ?, fgdate.FullDateAlternateKey) <= 0 and dimNPIWave.IsCurrent = 1 and dimNPIProject.IsCurrent = 1 and dimNPIWave.PMSWaveIDAlternateKey = ?");

		if (!"all".equals(form.getParentType())) {
			String sqlParentType = " and dimDetractor.Level1 = '" + form.getParentType() + "'";
			String sqlChildType = " and dimDetractor.Level2= '" + form.getChildType() + "'";
			if (!"all".equals(form.getChildType())) {
				sBuffer.append(sqlParentType);
				sBuffer.append(sqlChildType);
			} else {
				sBuffer.append(sqlParentType);
			}
		}
		if (form.getSortColumn() != null && form.getSortType() != null) {
			String sortSql = " order by " + form.getSortColumn() + " " + form.getSortType();
			sBuffer.append(sortSql);
		}

		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("pn", StringType.INSTANCE)
				.addScalar("itemDesc", StringType.INSTANCE).addScalar("orderNo", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				// .addScalar("targetDate", DateType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		// DetractorCode detractorCode;//C,Level 3
		query.setParameter(0, form.getStartDate());
		query.setParameter(1, form.getEndDate());
		query.setParameter(2, form.getWaveId());
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PieDivider> getOdmMainDivider(SearchOutlookDataForm form) {
		String sql = "select dimDetractor.Level1 as level1Name,count(dimOrder.OrderKey) as level1Num " + " from DimOrder dimOrder"
				+ " left join DimTime dimTime on dimOrder.OrderDateKey = dimTime.TimeKey"
				+ " left join FactDailyPSD factDailyPSD on dimOrder.OrderKey = factDailyPSD.OrderKey"
				+ " left join DimDetractor dimDetractor on dimOrder.DetractorKey = dimDetractor.DetractorKey"
				+ " where datediff(day, ?, dimTime.FullDateAlternateKey) >= 0 " + " and datediff(day, ?, dimTime.FullDateAlternateKey) <= 0 "
				+ "' group by dimDetractor.Level1 having dimDetractor.Level1 != 'null'";

		Query query = getSession().createSQLQuery(sql.toString()).addScalar("level1Name", StringType.INSTANCE).addScalar("level1Num", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PieDivider.class));
		query.setParameter(0, form.getStartDate());
		query.setParameter(1, form.getEndDate());
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Defect> getDefectsList(SearchOutlookDataForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select dimDefect.TDMSDefectIDAlternateKey as defectNo,").append("dimDefect.Category as category,")
				.append("dimDefect.DefectDescription as defectDesc,").append("dimDefect.DefectFailRate as failRate,")
				.append("dimDefect.FPYImpact as impactFPY,").append("dimDefect.IsCurrent as status,").append("dimDefect.DefectOwner as owner,")
				.append("dimDefect.CreatedDate as reportDate").append(" from DimDefect dimDefect")
				.append(" where dimDefect.ProductKey = " + form.getProductId());

		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("defectNo", StringType.INSTANCE).addScalar("category", StringType.INSTANCE)
				.addScalar("defectDesc", StringType.INSTANCE).addScalar("failRate", StringType.INSTANCE).addScalar("impactFPY", StringType.INSTANCE)
				// .addScalar("targetDate", DateType.INSTANCE)
				.addScalar("status", StringType.INSTANCE).addScalar("owner", StringType.INSTANCE)
				// .addScalar("reportBy", StringType.INSTANCE)
				.addScalar("reportDate", DateType.INSTANCE).setResultTransformer(Transformers.aliasToBean(Defect.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GeoData> getGeoIdAndName() {
		String sql = "select geo.GeographyKey, geo.GeographyName from DimGeography geo where geo.GeographyType=:type";
		Query query = getSession().createSQLQuery(sql).addScalar("geographyKey", IntegerType.INSTANCE).addScalar("geographyName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GeoData.class)).setString("type", "Geo");
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GeoData> getRegionIdAndName(Integer geoId) {

		StringBuilder sql = new StringBuilder();
		sql.append(" select max(geo.GeographyKey) as GeographyKey, geo.GeographyName from DimGeography geo ");
		sql.append(" where geo.GeographyType=:type");
		if (null != geoId && geoId > 0) {
			sql.append(" and geo.ParentGeographyKey=:geoId ");
		}
		sql.append(" group by  geo.GeographyName order by geo.GeographyName ");
		Query query = getSession().createSQLQuery(sql.toString()).addScalar("geographyKey", IntegerType.INSTANCE)
				.addScalar("geographyName", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(GeoData.class)).setString("type", "Region");

		if (null != geoId && geoId > 0) {
			query.setInteger("geoId", geoId);
		}

		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public DimODM getODMById(Integer odmId) {

		StringBuilder sql = new StringBuilder();
		sql.append(" select odm.ODMKey as odmKey, odm.ODMEnglishName as odmEnglishName ,odm.ODMChineseName as odmChineseName from DimODM odm ");
		sql.append(" where odm.ODMKey = :odmId ");

		Query query = getSession().createSQLQuery(sql.toString()).addScalar("odmKey", IntegerType.INSTANCE).addScalar("odmEnglishName", StringType.INSTANCE)
				.addScalar("odmChineseName", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(DimODM.class));

		query.setInteger("odmId", odmId);

		List<DimODM> list = query.list();
		if (CollectionUtils.isNotEmpty(list)) {
			return list.get(0);
		} else {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public GeoData getRegionById(Integer geoId) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select geo.GeographyKey, geo.GeographyName,geo.ParentGeographyKey as parentGeo,geo.GeographyType from DimGeography geo ");
		if (null != geoId && geoId > 0) {
			sql.append(" where geo.GeographyKey=:geoId ");
		}

		Query query = getSession().createSQLQuery(sql.toString()).addScalar("geographyKey", IntegerType.INSTANCE)
				.addScalar("geographyName", StringType.INSTANCE).addScalar("parentGeo", StringType.INSTANCE).addScalar("geographyType", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GeoData.class));

		if (null != geoId && geoId > 0) {
			query.setInteger("geoId", geoId);
		}

		List<GeoData> geoList = query.list();
		if (CollectionUtils.isNotEmpty(geoList)) {
			return geoList.get(0);
		} else {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public DimMtm getMtmById(int mtmKey) {
		StringBuilder sql = new StringBuilder();
		sql.append("select mtmKey,bomNumberAlternateKey,mtmEnglishName,mtmEnglishDescription,productKey,isCTO,mtmChineseName,mtmChineseDescription from dimMtm mtm ");
		sql.append("where MTMKey = :MTMKey");
		Query query = getSession().createSQLQuery(sql.toString()).addScalar("mtmKey", IntegerType.INSTANCE)
				.addScalar("bomNumberAlternateKey", StringType.INSTANCE).addScalar("mtmEnglishName", StringType.INSTANCE)
				.addScalar("mtmEnglishDescription", StringType.INSTANCE).addScalar("productKey", IntegerType.INSTANCE).addScalar("isCTO", BooleanType.INSTANCE)
				.addScalar("mtmChineseName", StringType.INSTANCE).addScalar("mtmChineseDescription", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(DimMtm.class));
		query.setInteger("MTMKey", mtmKey);
		List<DimMtm> mtmList = query.list();
		if (CollectionUtils.isNotEmpty(mtmList)) {
			return mtmList.get(0);
		} else {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PoNumberAndPoItem> getPoNumberAndPoItemByConditions(Integer geoId, Integer regionId, List<String> mtms) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select dimOrder.poNumber, dimOrder.poItem ");
		sql.append(" from DimOrder dimOrder ");
		sql.append(" right join DimMTM dimMTM on dimOrder.MTMKey = dimMTM.MTMKey ");
		sql.append(" right join (SELECT country.[GeographyKey] countryId ");
		sql.append("  ,regin.GeographyKey regionId ");
		sql.append(" ,geo.GeographyKey geoId ");
		sql.append("  ,geo.[GeographyName] geoName ");
		sql.append("  ,regin.GeographyName reginName ");
		sql.append("  ,country.GeographyName countryName ");
		sql.append("  ,regin.[ParentGeographyKey] ");
		sql.append(" FROM [LenovoDW].[dbo].[DimGeography] country ");
		sql.append(" left join [LenovoDW].[dbo].[DimGeography] regin ");
		sql.append("  on country.ParentGeographyKey = regin.GeographyKey ");
		sql.append(" left join [LenovoDW].[dbo].[DimGeography] geo ");
		sql.append(" on regin.ParentGeographyKey = geo.GeographyKey) tableGeo  ");
		sql.append(" on dimOrder.GeographyKey = tableGeo.countryId  ");
		sql.append("where 1=1 ");

		if (null != geoId && geoId > 0) {
			sql.append(" and  tableGeo.geoId= :geoId ");
		}
		if (null != regionId && regionId > 0) {
			sql.append(" and tableGeo.regionId= :regionId ");

		}
		if (null != mtms && mtms.size() > 0) {
			sql.append(" and dimMTM.BOMNumberAlternateKey in (:mtm) ");
		}

		Query query = getSession().createSQLQuery(sql.toString()).addScalar("poNumber", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PoNumberAndPoItem.class));

		if (null != geoId && geoId > 0) {
			query.setInteger("geoId", geoId);
		}
		if (null != regionId && regionId > 0) {
			query.setInteger("regionId", regionId);
		}
		if (null != mtms && mtms.size() > 0) {
			query.setParameterList("mtm", mtms);
		}

		return query.list();
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getDetractorCodeDataByOrderkeys(Date beginDate, Date endDate, List<String> orderKeyList) {
		// TODO top 10
		StringBuffer orderKeys = null;
		String orderKeyStrs;
		if (CollectionUtils.isNotEmpty(orderKeyList)) {
			orderKeys = new StringBuffer();
			for (String orderKey : orderKeyList) {
				orderKeys.append("'");
				orderKeys.append(orderKey);
				orderKeys.append("'");
				orderKeys.append(",");
			}
			orderKeyStrs = orderKeys.toString();
			if (StringUtils.isNotBlank(orderKeyStrs) && orderKeyStrs.length() > 1) {
				orderKeyStrs = orderKeyStrs.substring(0, orderKeyStrs.length() - 1);
				StringBuffer sBuffer = new StringBuffer();
				sBuffer.append("select  top 10 dimODM.ODMEnglishName as odm,").append("tableDimGeography.geoName as geo,")
						.append("tableDimGeography.regionName as region,").append("tableDimGeography.countryName as country,")
						.append("dimProduct.ProductEnglishName as product,").append("dimMTM.BOMNumberAlternateKey as pn,")
						.append("dimMTM.MTMEnglishDescription as itemDesc,").append("dimOrder.PONumber as poNumber,")
						.append("dimOrder.OrderNumber as orderNo,").append("dimOrder.POItem as itemNo,").append("dimOrder.Quantity as qty,")
						.append("orderdate.FullDateAlternateKey as orderDate,").append("rsddate.FullDateAlternateKey as rsd,")
						.append("fpsddate.FullDateAlternateKey as fpsd,").append("shipdate.FullDateAlternateKey as shippedDate,")
						.append("psd.IsShipped as shipped,").append("dimDetractor.Level1 as level1,").append("dimDetractor.Level2 as level2 ,")
						.append("dimOrder.LateReason2 as level3 ").append(" from DimOrder dimOrder")
						.append(" left join DimTime orderdate on orderdate.TimeKey =  dimOrder.OrderDateKey")
						.append(" left join DimTime rsddate on rsddate.TimeKey =  dimOrder.RSDDateKey")
						.append(" left join DimTime fgdate on fgdate.TimeKey =  dimOrder.FGReadyDateKey ")
						.append(" left join DimMTM dimMTM on dimOrder.MTMKey = dimMTM.MTMKey")
						.append(" left join DimProduct dimProduct on dimMTM.ProductKey = dimProduct.ProductKey ")
						.append(" left join DimNPIProject dimNPIProject on dimProduct.ProductKey = dimNPIProject.ProductKey  and dimNPIProject.IsCurrent = 1 ")
						.append(" left join DimNPIWave dimNPIWave on dimNPIProject.NPIProjectKey = dimNPIWave.NPIProjectKey  and DimNPIWave.isCurrent = 1 ")
						.append(" left join DimODM dimODM on dimOrder.ODMKey = dimODM.ODMKey")
						.append(" left join FactDailyPSD psd on psd.OrderKey = dimOrder.OrderKey")
						.append(" left join DimTime fpsddate on fpsddate.TimeKey =  dimOrder.FPSDDateKey ")
						.append(" left join DimTime shipdate on shipdate.TimeKey =  dimOrder.ShipDateKey ")
						.append(" left join DimDetractor dimDetractor on dimOrder.DetractorKey = dimDetractor.DetractorKey")
						.append(" left join (SELECT country.GeographyKey,geo.GeographyName geoName,region.GeographyName regionName,")
						.append(" country.GeographyName countryName,region.ParentGeographyKey,geo.CreatedDate,geo.LastModifiedDate")
						.append(" FROM DimGeography geo").append(" left join DimGeography region on region.ParentGeographyKey = geo.GeographyKey")
						.append(" left join DimGeography country on country.ParentGeographyKey = region.GeographyKey")
						.append(" ) tableDimGeography on dimOrder.GeographyKey = tableDimGeography.GeographyKey").append(" where  dimorder.IsCurrent = 1 ")
						.append(" and dimNPIWave.IsCurrent = 1 and dimNPIProject.IsCurrent = 1 ")
						.append(" where datediff(day, ?, fgdate.FullDateAlternateKey) >= 0 ") 
						.append(" and datediff(day, ?, fgdate.FullDateAlternateKey) <= 0 and dimNPIWave.IsCurrent = 1 and dimNPIProject.IsCurrent = 1 ")
						.append("and dimOrder.orderKey in(").append(orderKeyStrs).append(")").append(" order by orderNo");
				        Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
						.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
						.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
						.addScalar("orderNo", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE).addScalar("qty", StringType.INSTANCE)
						.addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE).addScalar("fpsd", StringType.INSTANCE)
						.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
						.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE)
						.setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
				        // DetractorCode detractorCode;//C,Level 3
				        query.setParameter(0, beginDate); query.setParameter(1, endDate);
				 
				return query.list();
			}
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getDetractorCodeDataByOrderkeys(Date beginDate, Date endDate, List<String> orderKeyList, String sortColumn,
			String sortType) {
		// TODO top 10
		StringBuffer orderKeys = null;
		String orderKeyStrs;
		if (CollectionUtils.isNotEmpty(orderKeyList)) {
			orderKeys = new StringBuffer();
			for (String orderKey : orderKeyList) {
				orderKeys.append("'");
				orderKeys.append(orderKey);
				orderKeys.append("'");
				orderKeys.append(",");
			}
			orderKeyStrs = orderKeys.toString();
			if (StringUtils.isNotBlank(orderKeyStrs) && orderKeyStrs.length() > 1) {
				orderKeyStrs = orderKeyStrs.substring(0, orderKeyStrs.length() - 1);
				StringBuffer sBuffer = new StringBuffer();
				sBuffer.append("select  top 10 dimODM.ODMEnglishName as odm,").append("tableDimGeography.geoName as geo,")
						.append("tableDimGeography.regionName as region,").append("tableDimGeography.countryName as country,")
						.append("dimProduct.ProductEnglishName as product,").append("dimMTM.BOMNumberAlternateKey as pn,")
						.append("dimMTM.MTMEnglishDescription as itemDesc,").append("dimOrder.PONumber as poNumber,")
						.append("dimOrder.OrderNumber as orderNo,").append("dimOrder.POItem as itemNo,").append("dimOrder.Quantity as qty,")
						.append("orderdate.FullDateAlternateKey as orderDate,").append("rsddate.FullDateAlternateKey as rsd,")
						.append("fpsddate.FullDateAlternateKey as fpsd,").append("shipdate.FullDateAlternateKey as shippedDate,")
						.append("psd.IsShipped as shipped,").append("dimDetractor.Level1 as level1,").append("dimDetractor.Level2 as level2 ,")
						.append("dimOrder.LateReason2 as level3 ").append(" from DimOrder dimOrder")
						.append(" left join DimTime orderdate on orderdate.TimeKey =  dimOrder.OrderDateKey")
						.append(" left join DimTime rsddate on rsddate.TimeKey =  dimOrder.RSDDateKey")
						.append(" left join DimTime fgdate on fgdate.TimeKey =  dimOrder.FGReadyDateKey ")
						.append(" left join DimMTM dimMTM on dimOrder.MTMKey = dimMTM.MTMKey")
						.append(" left join DimProduct dimProduct on dimMTM.ProductKey = dimProduct.ProductKey ")
						.append(" left join DimNPIProject dimNPIProject on dimProduct.ProductKey = dimNPIProject.ProductKey  and dimNPIProject.IsCurrent = 1 ")
						.append(" left join DimNPIWave dimNPIWave on dimNPIProject.NPIProjectKey = dimNPIWave.NPIProjectKey  and DimNPIWave.isCurrent = 1 ")
						.append(" left join DimODM dimODM on dimOrder.ODMKey = dimODM.ODMKey")
						.append(" left join FactDailyPSD psd on psd.OrderKey = dimOrder.OrderKey")
						.append(" left join DimTime fpsddate on fpsddate.TimeKey =  dimOrder.FPSDDateKey ")
						.append(" left join DimTime shipdate on shipdate.TimeKey =  dimOrder.ShipDateKey ")
						.append(" left join DimDetractor dimDetractor on dimOrder.DetractorKey = dimDetractor.DetractorKey")
						.append(" left join (SELECT country.GeographyKey,geo.GeographyName geoName,region.GeographyName regionName,")
						.append(" country.GeographyName countryName,region.ParentGeographyKey,geo.CreatedDate,geo.LastModifiedDate")
						.append(" FROM DimGeography geo").append(" left join DimGeography region on region.ParentGeographyKey = geo.GeographyKey")
						.append(" left join DimGeography country on country.ParentGeographyKey = region.GeographyKey")
						.append(" ) tableDimGeography on dimOrder.GeographyKey = tableDimGeography.GeographyKey").append(" where  dimorder.IsCurrent = 1 ")
						.append("and dimOrder.orderKey in(").append(orderKeyStrs).append(")");
				if (StringUtils.isNotBlank(sortColumn)) {
					sBuffer.append(" order by ").append(sortColumn).append(" ").append(sortType);
				} else {
					sBuffer.append(" order by orderNo");
				}
				Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
						.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
						.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
						.addScalar("orderNo", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE).addScalar("qty", StringType.INSTANCE)
						.addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE).addScalar("fpsd", StringType.INSTANCE)
						.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
						.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE)
						.setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
				return query.list();
			}
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getDetractorCodeDataByOrderkeys(Date beginDate, Date endDate, List<String> orderKeyList, SearchOtsForm form) {
		StringBuffer orderKeys = null;
		String orderKeyStrs;
		if (CollectionUtils.isNotEmpty(orderKeyList)) {
			orderKeys = new StringBuffer();
			for (String orderKey : orderKeyList) {
				orderKeys.append("'");
				orderKeys.append(orderKey);
				orderKeys.append("'");
				orderKeys.append(",");
			}
			orderKeyStrs = orderKeys.toString();
			if (StringUtils.isNotBlank(orderKeyStrs) && orderKeyStrs.length() > 1) {
				orderKeyStrs = orderKeyStrs.substring(0, orderKeyStrs.length() - 1);
				StringBuffer sBuffer = new StringBuffer();
				sBuffer.append("select * from ");
				sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
				sBuffer.append("(select  top ").append(form.getEndRow()).append(" dimODM.ODMEnglishName as odm,").append("tableDimGeography.geoName as geo,")
						.append("tableDimGeography.regionName as region,").append("tableDimGeography.countryName as country,")
						.append("dimProduct.ProductEnglishName as product,").append("dimMTM.BOMNumberAlternateKey as pn,")
						.append("dimMTM.MTMEnglishDescription as itemDesc,").append("dimOrder.PONumber as poNumber,")
						.append("dimOrder.OrderNumber as orderNo,").append("dimOrder.POItem as itemNo,").append("dimOrder.Quantity as qty,")
						.append("orderdate.FullDateAlternateKey as orderDate,").append("rsddate.FullDateAlternateKey as rsd,")
						.append("fpsddate.FullDateAlternateKey as fpsd,").append("shipdate.FullDateAlternateKey as shippedDate,")
						.append("psd.IsShipped as shipped,").append("dimDetractor.Level1 as level1,").append("dimDetractor.Level2 as level2 ,")
						.append("dimOrder.LateReason2 as level3 ").append(" from DimOrder dimOrder")
						.append(" left join DimTime orderdate on orderdate.TimeKey =  dimOrder.OrderDateKey")
						.append(" left join DimTime rsddate on rsddate.TimeKey =  dimOrder.RSDDateKey")
						.append(" left join DimTime fgdate on fgdate.TimeKey =  dimOrder.FGReadyDateKey ")
						.append(" left join DimMTM dimMTM on dimOrder.MTMKey = dimMTM.MTMKey")
						.append(" left join DimProduct dimProduct on dimMTM.ProductKey = dimProduct.ProductKey ")
						.append(" left join DimNPIProject dimNPIProject on dimProduct.ProductKey = dimNPIProject.ProductKey  and dimNPIProject.IsCurrent = 1 ")
						.append(" left join DimNPIWave dimNPIWave on dimNPIProject.NPIProjectKey = dimNPIWave.NPIProjectKey  and DimNPIWave.isCurrent = 1 ")
						.append(" left join DimODM dimODM on dimOrder.ODMKey = dimODM.ODMKey")
						.append(" left join FactDailyPSD psd on psd.OrderKey = dimOrder.OrderKey")
						.append(" left join DimTime fpsddate on fpsddate.TimeKey =  dimOrder.FPSDDateKey ")
						.append(" left join DimTime shipdate on shipdate.TimeKey =  dimOrder.ShipDateKey ")
						.append(" left join DimDetractor dimDetractor on dimOrder.DetractorKey = dimDetractor.DetractorKey")
						.append(" left join (SELECT country.GeographyKey,geo.GeographyName geoName,region.GeographyName regionName,")
						.append(" country.GeographyName countryName,region.ParentGeographyKey,geo.CreatedDate,geo.LastModifiedDate")
						.append(" FROM DimGeography geo").append(" left join DimGeography region on region.ParentGeographyKey = geo.GeographyKey")
						.append(" left join DimGeography country on country.ParentGeographyKey = region.GeographyKey")
						.append(" ) tableDimGeography on dimOrder.GeographyKey = tableDimGeography.GeographyKey").append(" where  dimorder.IsCurrent = 1 ")
						.append("and dimOrder.orderKey in(").append(orderKeyStrs).append(")");
				if (StringUtils.isNotBlank(form.getSortColumn())) {
					sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType()).append(", orderNo ")
							.append(form.getSortType()).append(" ) t");
				} else {
					sBuffer.append(" order by orderNo ").append(form.getSortType()).append(" ) t");
				}
				if (StringUtils.isNotBlank(form.getSortColumn())) {
					sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType()).append(", orderNo ")
							.append(form.getReversalSortType()).append(" ) tt");
				} else {
					sBuffer.append(" order by orderNo ").append(form.getReversalSortType()).append(" ) tt");
				}
				if (StringUtils.isNotBlank(form.getSortColumn())) {
					sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType()).append(", orderNo ")
							.append(form.getSortType());
				} else {
					sBuffer.append(" order by orderNo ").append(form.getSortType());
				}
				Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
						.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
						.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
						.addScalar("orderNo", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE).addScalar("qty", StringType.INSTANCE)
						.addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE).addScalar("fpsd", StringType.INSTANCE)
						.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
						.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE)
						.setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
				return query.list();
			}
		}
		return null;
	}

	@Override
	public int getDetractorCodeCountByOrderkeys(Date beginDate, Date endDate, List<String> orderKeyList, SearchOtsForm form) {
		StringBuffer orderKeys = null;
		String orderKeyStrs;
		if (CollectionUtils.isNotEmpty(orderKeyList)) {
			orderKeys = new StringBuffer();
			for (String orderKey : orderKeyList) {
				orderKeys.append("'");
				orderKeys.append(orderKey);
				orderKeys.append("'");
				orderKeys.append(",");
			}
			orderKeyStrs = orderKeys.toString();
			if (StringUtils.isNotBlank(orderKeyStrs) && orderKeyStrs.length() > 1) {
				orderKeyStrs = orderKeyStrs.substring(0, orderKeyStrs.length() - 1);
				StringBuffer sBuffer = new StringBuffer();
				sBuffer.append("select  count(dimOrder.Quantity) as totalCount").append(" from DimOrder dimOrder")
						.append(" left join DimTime orderdate on orderdate.TimeKey =  dimOrder.OrderDateKey")
						.append(" left join DimTime rsddate on rsddate.TimeKey =  dimOrder.RSDDateKey")
						.append(" left join DimTime fgdate on fgdate.TimeKey =  dimOrder.FGReadyDateKey ")
						.append(" left join DimMTM dimMTM on dimOrder.MTMKey = dimMTM.MTMKey")
						.append(" left join DimProduct dimProduct on dimMTM.ProductKey = dimProduct.ProductKey ")
						.append(" left join DimNPIProject dimNPIProject on dimProduct.ProductKey = dimNPIProject.ProductKey  and dimNPIProject.IsCurrent = 1 ")
						.append(" left join DimNPIWave dimNPIWave on dimNPIProject.NPIProjectKey = dimNPIWave.NPIProjectKey  and DimNPIWave.isCurrent = 1 ")
						.append(" left join DimODM dimODM on dimOrder.ODMKey = dimODM.ODMKey")
						.append(" left join FactDailyPSD psd on psd.OrderKey = dimOrder.OrderKey")
						.append(" left join DimTime fpsddate on fpsddate.TimeKey =  dimOrder.FPSDDateKey ")
						.append(" left join DimTime shipdate on shipdate.TimeKey =  dimOrder.ShipDateKey ")
						.append(" left join DimDetractor dimDetractor on dimOrder.DetractorKey = dimDetractor.DetractorKey")
						.append(" left join (SELECT country.GeographyKey,geo.GeographyName geoName,region.GeographyName regionName,")
						.append(" country.GeographyName countryName,region.ParentGeographyKey,geo.CreatedDate,geo.LastModifiedDate")
						.append(" FROM DimGeography geo").append(" left join DimGeography region on region.ParentGeographyKey = geo.GeographyKey")
						.append(" left join DimGeography country on country.ParentGeographyKey = region.GeographyKey")
						.append(" ) tableDimGeography on dimOrder.GeographyKey = tableDimGeography.GeographyKey").append(" where  dimorder.IsCurrent = 1 ")
						.append("and dimOrder.orderKey in(").append(orderKeyStrs).append(")");
				Query query = getSession().createSQLQuery(sBuffer.toString());
				return (Integer) query.uniqueResult();
			}
		}
		return 0;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DimOrderForNPIExclude> getDimOrderByWaveId(int waveId, Date weekDate, Date sgaDate) {
		Query query = getSession().createSQLQuery("{CALL dw_sp_retrieveSGAOrdersBeforeWeekaddside(?,?,?)}").addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("orderNo", StringType.INSTANCE).addScalar("mtmKey", IntegerType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE).addScalar("quantity", IntegerType.INSTANCE).addScalar("odmKey", IntegerType.INSTANCE)
				.addScalar("regionKey", IntegerType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsdDate", DateType.INSTANCE)
				.addScalar("fpsdDate", DateType.INSTANCE).addScalar("fgDate", DateType.INSTANCE).addScalar("shipDate", DateType.INSTANCE)
				.addScalar("isShipped", BooleanType.INSTANCE).addScalar("mot", StringType.INSTANCE).addScalar("detractorKey", IntegerType.INSTANCE)
				.addScalar("lateReason2", StringType.INSTANCE).addScalar("shortageDescription", StringType.INSTANCE).addScalar("flag",StringType.INSTANCE)
				.addScalar("bomNumberAlternateKey", StringType.INSTANCE)
				.addScalar("mtmEnglishDescription", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("odmEnglishName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(DimOrderForNPIExclude.class)).setParameter(0, waveId).setParameter(1, weekDate)
				.setParameter(2, sgaDate);
		return query.list();

	}
	@SuppressWarnings("unchecked")
	@Override
	public List<DimOrderForNPIExclude> getSleDimOrderByWaveId(int waveId, Date weekDate, Date sgaDate) {
		Query query = getSession().createSQLQuery("{CALL dw_sp_retrieveSLEOrdersBeforeWeekaddside(?,?)}").addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("orderNo", StringType.INSTANCE).addScalar("mtmKey", IntegerType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE).addScalar("quantity", IntegerType.INSTANCE).addScalar("odmKey", IntegerType.INSTANCE)
				.addScalar("regionKey", IntegerType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsdDate", DateType.INSTANCE)
				.addScalar("fpsdDate", DateType.INSTANCE).addScalar("fgDate", DateType.INSTANCE).addScalar("shipDate", DateType.INSTANCE)
				.addScalar("isShipped", BooleanType.INSTANCE).addScalar("mot", StringType.INSTANCE).addScalar("detractorKey", IntegerType.INSTANCE)
				.addScalar("lateReason2", StringType.INSTANCE).addScalar("shortageDescription", StringType.INSTANCE).addScalar("flag",StringType.INSTANCE)
				.addScalar("bomNumberAlternateKey", StringType.INSTANCE)
				.addScalar("mtmEnglishDescription", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("odmEnglishName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(DimOrderForNPIExclude.class)).setParameter(0, waveId).setParameter(1, weekDate);
		return query.list();

	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<DimOrderForNPIExclude> getSgaDimOrderByWaveIdInWeek(int waveId, Date weekDate, Date sgaDate) {
		Query query = getSession().createSQLQuery("{CALL dw_sp_retrieveSGAOrdersInWeek(?,?,?)}").addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("orderNo", StringType.INSTANCE).addScalar("mtmKey", IntegerType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE).addScalar("quantity", IntegerType.INSTANCE).addScalar("odmKey", IntegerType.INSTANCE)
				.addScalar("regionKey", IntegerType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsdDate", DateType.INSTANCE)
				.addScalar("fpsdDate", DateType.INSTANCE).addScalar("fgDate", DateType.INSTANCE).addScalar("shipDate", DateType.INSTANCE)
				.addScalar("isShipped", BooleanType.INSTANCE).addScalar("mot", StringType.INSTANCE).addScalar("detractorKey", IntegerType.INSTANCE)
				.addScalar("lateReason2", StringType.INSTANCE).addScalar("shortageDescription", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(DimOrderForNPIExclude.class)).setParameter(0, waveId).setParameter(1, weekDate)
				.setParameter(2, sgaDate);
		return query.list();

	}
	@SuppressWarnings("unchecked")
	@Override
	public List<DimOrderForNPIExclude> getSleDimOrderByWaveIdInWeek(int waveId, Date weekDate, Date sgaDate) {
		Query query = getSession().createSQLQuery("{CALL dw_sp_retrieveSLEOrdersInWeek(?,?)}").addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("orderNo", StringType.INSTANCE).addScalar("mtmKey", IntegerType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE).addScalar("quantity", IntegerType.INSTANCE).addScalar("odmKey", IntegerType.INSTANCE)
				.addScalar("regionKey", IntegerType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsdDate", DateType.INSTANCE)
				.addScalar("fpsdDate", DateType.INSTANCE).addScalar("fgDate", DateType.INSTANCE).addScalar("shipDate", DateType.INSTANCE)
				.addScalar("isShipped", BooleanType.INSTANCE).addScalar("mot", StringType.INSTANCE).addScalar("detractorKey", IntegerType.INSTANCE)
				.addScalar("lateReason2", StringType.INSTANCE).addScalar("shortageDescription", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(DimOrderForNPIExclude.class)).setParameter(0, waveId).setParameter(1, weekDate);
		return query.list();

	}

	@SuppressWarnings("unchecked")
	@Override
	public DimDetractor getDetractorById(Integer detractorKey) {
		String hql = "from DimDetractor where detractorKey = :detractorKey and isCurrent = 1";
		Query q = getSession().createQuery(hql);
		q.setInteger("detractorKey", detractorKey);
		List<DimDetractor> detractors = q.list();
		if(CollectionUtils.isNotEmpty(detractors)){
			return detractors.get(0);
		}else{
			return null;
		}
	}
	
}
