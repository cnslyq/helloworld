package com.lenovo.bi.dao.npi;

import java.util.Date;

import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnProduct;

public interface NpiWeeklyComponentCommitmentOnProductDao {
	
	public void saveComponentCommitmentOnProduct(
			NpiWeeklyComponentCommitmentOnProduct obj);

	public void deleteComponentCommitmentOnProduct(Date versionDate);
}
