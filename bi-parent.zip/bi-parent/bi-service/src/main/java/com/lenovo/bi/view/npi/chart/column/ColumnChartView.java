package com.lenovo.bi.view.npi.chart.column;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;

public class ColumnChartView {
	private ColumnChartInformation chartInfo;
	
	private Categories categories;
	
	private List<DataSetParent> dataSetList;
	
	public List<DataSetParent> getDataSetList() {
		return dataSetList;
	}
	
	@JsonProperty("dataset")
	public void setDataSetList(List<DataSetParent> dataSetList) {
		this.dataSetList = dataSetList;
	}

	public Categories getCategories() {
		return categories;
	}
	
	@JsonProperty("categories")
	public void setCategories(Categories categories) {
		this.categories = categories;
	}
	
	public ColumnChartInformation getChartInfo() {
		return chartInfo;
	}
	
	@JsonProperty("chart")
	public void setChartInfo(ColumnChartInformation chartInfo) {
		this.chartInfo = chartInfo;
	}
	
	public ColumnChartView(){
		chartInfo = new ColumnChartInformation();
	}
}
