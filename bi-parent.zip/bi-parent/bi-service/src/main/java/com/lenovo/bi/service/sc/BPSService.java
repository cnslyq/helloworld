package com.lenovo.bi.service.sc;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.form.sc.bps.SearchBpsForm;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;
import com.lenovo.bi.view.sc.bps.BPSDetailView;

public interface BPSService {
	//public SearchBpsForm getBPSKpiMonitor(SearchBpsForm form) throws ParseException;
	public float calOverViewBpsRateByMonth(String month);
	public ColumnChartView getOverviewChart(SearchBpsForm form) throws ParseException;
	
	public ColumnChartView getOverviewRemarkChart(SearchBpsForm form) throws ParseException;
	
	public String getOverviewRemarkTotal(SearchBpsForm form) throws ParseException;
	
	public PieChartView getOverviewPieChart(SearchBpsForm form) throws ParseException;
	
	public ColumnChartView getDashboardOverviewChart(SearchBpsForm form) throws ParseException;
	
	public Map<String,Object> getBpsSumOrderDetail(SearchBpsForm form) throws ParseException ;
	
	public  Map<String,Object> getBpsSumFactDetail(SearchBpsForm form);
	
	public ColumnChartView getCrossMonthDashboardOverviewChart(SearchBpsForm form)	throws ParseException;
	
	public List<TtvGridDetractorCodeView> getBpsAgingAnglysisOrderDetail(SearchBpsForm form) throws ParseException;
	
	public List<BPSDetailView> getBpsDetail(SearchBpsForm form);
	
	public long getBpsDetailCount(SearchBpsForm form);
	
	public ColumnChartView getDaysOfOverDue(SearchBpsForm form) throws ParseException;
	
	public List<TtvGridDetractorCodeView> getExportBpsOrderDetail(SearchBpsForm form) throws ParseException;
}
