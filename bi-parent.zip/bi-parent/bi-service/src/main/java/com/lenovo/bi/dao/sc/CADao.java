package com.lenovo.bi.dao.sc;


import java.util.List;

import com.lenovo.bi.dto.CaKeyNameObject;
import com.lenovo.bi.dto.sc.CARemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.form.sc.ca.SearchCaForm;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;
import com.lenovo.bi.view.sc.ca.CaDetailGridView;

public interface CADao {

	public List<ScOverViewChartData> fetchCaOverViewChartData(SearchCaForm form);
	
	public List<CARemarkChartData> fetchDimensionRemarkDataList(SearchCaForm form);
	
	public CaKeyNameObject fetchOverviewCaTargetAndCtp(SearchCaForm form);
	
	public CaKeyNameObject fetchCrossMonthCaTargetAndCtp(SearchCaForm form);
	
	public CaKeyNameObject fetchDashboardCaTargetAndCtp(SearchCaForm form);
	
	public Integer fetchBoh(SearchCaForm form);
	
	public Integer fetchOverviewBoh(SearchCaForm form);
	
	public Integer fetchCrossMonthBoh(SearchCaForm form);
	
	public Integer fetchDashboardBoh(SearchCaForm form);
	
	public Integer fetchOverviewOdmCommitment(SearchCaForm form);
	
	public Integer fetchCrossMonthOdmCommitment(SearchCaForm form);
	
	public Integer fetchDashboardOdmCommitment(SearchCaForm form);
	
	public Integer fetchRemarkOdmCommitment(CARemarkChartData caRemarkChartData,SearchCaForm form);
	
	public Integer fetchRemarkCaTarget(CARemarkChartData caRemarkChartData,SearchCaForm form);
	
	public Integer fetchRemarkBoh(CARemarkChartData caRemarkChartData,SearchCaForm form);
	
	public List<CaKeyNameObject> fetchDimensions(SearchCaForm form);
	
	public List<ScOverViewChartData> fetchCaDashboardOverViewChartData(SearchCaForm form);

	public List<ScOverViewChartData> fetchCaCrossMonthOverviewChartData(SearchCaForm form);
	
	public List<ScOverViewChartData> getOverviewOverall(SearchCaForm form);
	
	public List<ScOverViewChartData> fetchCaDataByDimKeys(SearchCaForm form);
	
	public List<CaDetailGridView> fetchMfgCaDetail(SearchCaForm form);
	
	public List<CaDetailGridView> fetchSalesCaDetail(SearchCaForm form);
	
	//Mfg overview order detail
	public List<TtvGridDetractorCodeView> getOverviewOrderDetail(SearchCaForm form);
	public List<TtvGridDetractorCodeView> getCrossMonthOrderDetail(SearchCaForm form);
	public List<TtvGridDetractorCodeView> getDashboardOrderDetail(SearchCaForm form);
	public List<TtvGridDetractorCodeView> getRemarkOrderDetail(SearchCaForm form);
	
	//Sales overview order detail
	public List<TtvGridDetractorCodeView> getSalesOverviewOrderDetail(SearchCaForm form);
	public List<TtvGridDetractorCodeView> getSalesCrossMonthOrderDetail(SearchCaForm form);
	public List<TtvGridDetractorCodeView> getSalesDashboardOrderDetail(SearchCaForm form);
	public List<TtvGridDetractorCodeView> getSalesRemarkOrderDetail(SearchCaForm form);
	
	//order detail count
	public int getOverviewOrderDetailCount(SearchCaForm form);
	public int getCrossMonthOrderDetailCount(SearchCaForm form);
	public int getDashboardOrderDetailCount(SearchCaForm form);
	public int getRemarkOrderDetailCount(SearchCaForm form);
}
