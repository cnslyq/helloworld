package com.lenovo.bi.dao.sc.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.CADao;
import com.lenovo.bi.dto.CaKeyNameObject;
import com.lenovo.bi.dto.sc.CARemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.enumobj.CAStatusEnum;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.form.sc.ca.SearchCaForm;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;
import com.lenovo.bi.view.sc.ca.CaDetailGridView;
import com.lenovo.common.model.PagerInformation;

@SuppressWarnings("rawtypes")
@Repository
public class CADaoImpl extends HibernateBaseDaoImplDw implements CADao {

	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchCaOverViewChartData(SearchCaForm form) {
		
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select sum(mfg.OrderQuantity) as orderNum,case when status.CAStatus is null then 'Unknown' else status.CAStatus end as scStatusName");
		if(!form.isShowSalesOverview())
			sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
		else
			sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
		   	sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
		   		.append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
		   		.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   		.append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
		   		.append(" left join (")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		if(form.isShowGeoOverview()) {
			sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
			
		}
		else {
			sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
		   		   .append(form.getStartDate())
		   		   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where mfg.Year*100 + mfg.Month between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		    		.append(" and mfg.Month = ").append(form.getMonth());
			}
		}
		
		
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(")
			.append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		sBuffer.append(" group by status.CAStatus order by status.CAStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CARemarkChartData> fetchDimensionRemarkDataList(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append("select DBO.AggregateRegionId(SUB.dimensionName) as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.CAStatus='Committed Backlog' then SUB.OrderQuantity else 0 end) as committed,")
					.append("sum(case when SUB.CAStatus='Risk order' then SUB.OrderQuantity else 0 end) as risk,")
					.append("sum(case when SUB.CAStatus='Shipment' then SUB.OrderQuantity else 0 end) as shipment,")
					.append("sum(case when SUB.CAStatus='Future order' then SUB.OrderQuantity else 0 end) as future,")
					.append("sum(SUB.OrderQuantity) as total,")
					.append(" 'Region' as remarkType")
					.append(" from (select mfg.*,status.CAStatus,geography.GeographyName as dimensionName ");
			if(!form.isShowSalesOverview())
				sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
			else
				sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
			   	sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
			   		.append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
			   		.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
			   		.append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			   		.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
			}
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
				form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
			    sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   		   .append(form.getStartDate())
			   		   .append(" and ").append(form.getEndDate());
			}
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
					form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
					form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			    	sBuffer.append(" where mfg.Year*100 + mfg.Month between '")
						   .append(form.getQuarterFrom()).append("'")
						   .append(" and '").append(form.getQuarterTo()).append("'");
				}
				//month
				else {
			    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
			    		.append(" and mfg.Month = ").append(form.getMonth());
				}
			}
			
			
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
			
			if(!"-1".equals(form.getDashboardTypeKey())) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and mfg.RegionKey in( ").append(form.getDashboardTypeKey()).append(") ");
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and mfg.ProductKey = ").append(form.getDashboardTypeKey());
				else if("Family".equals(form.getDashboardType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
				else if("Portfolio".equals(form.getDashboardType()))
					sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getDashboardTypeKey());
			}
			
			if(!"-1".equals(form.getCrossMonthTypeKey())) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and mfg.RegionKey in( ").append(form.getCrossMonthTypeKey()).append(") ");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mfg.ProductKey = ").append(form.getCrossMonthTypeKey());
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey());
				else if("Portfolio".equals(form.getCrossMonthType()))
					sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(!"-1".equals(form.getDashboardTypeKey())) 
					sBuffer.append(" and geoRegion.geoKey in( ").append(form.getDashboardTypeKey()).append(") ");
			}
			
			sBuffer.append(")SUB group by SUB.dimensionName having SUB.dimensionName <> '' order by SUB.dimensionName");
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Family".equals(form.getDimension())) {
			sBuffer.append("select SUB.familyKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.CAStatus='Committed Backlog' then SUB.OrderQuantity else 0 end) as committed,")
					.append("sum(case when SUB.CAStatus='Risk order' then SUB.OrderQuantity else 0 end) as risk,")
					.append("sum(case when SUB.CAStatus='Shipment' then SUB.OrderQuantity else 0 end) as shipment,")
					.append("sum(case when SUB.CAStatus='Future order' then SUB.OrderQuantity else 0 end) as future,")
					.append("sum(SUB.OrderQuantity) as total,")
					.append(" 'Family' as remarkType")
					.append(" from (select mfg.*,status.CAStatus,productFamily.familyKey,productFamily.ProductFamilyEnglishName as dimensionName ");
			 if(!form.isShowSalesOverview())
				sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
			 else
				sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
			   	sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
			   		.append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
			   		.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
			   		.append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			   		.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
			}
			else {
				sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
			}
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
				form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
			    sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   		   .append(form.getStartDate())
			   		   .append(" and ").append(form.getEndDate());
			}
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
					form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
					form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			    	sBuffer.append(" where mfg.Year*100 + mfg.Month between '")
						   .append(form.getQuarterFrom()).append("'")
						   .append(" and '").append(form.getQuarterTo()).append("'");
				}
				//month
				else {
			    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
			    		.append(" and mfg.Month = ").append(form.getMonth());
				}
			}
			
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
			
			if(!"-1".equals(form.getDashboardTypeKey())) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and mfg.RegionKey in( ").append(form.getDashboardTypeKey()).append(") ");
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and mfg.ProductKey = ").append(form.getDashboardTypeKey());
				else if("Family".equals(form.getDashboardType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
				else if("Portfolio".equals(form.getDashboardType()))
					sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getDashboardTypeKey());
			}
			
			if(!"-1".equals(form.getCrossMonthTypeKey())) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and mfg.RegionKey in( ").append(form.getCrossMonthTypeKey()).append(") ");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mfg.ProductKey = ").append(form.getCrossMonthTypeKey());
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey());
				else if("Portfolio".equals(form.getCrossMonthType()))
					sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(!"-1".equals(form.getDashboardTypeKey())) 
					sBuffer.append(" and geoRegion.geoKey in( ").append(form.getDashboardTypeKey()).append(") ");
			} 
			
			sBuffer.append(")SUB group by SUB.familyKey,SUB.dimensionName having SUB.dimensionName <> '' order by SUB.familyKey");
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append("select SUB.ProductKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.CAStatus='Committed Backlog' then SUB.OrderQuantity else 0 end) as committed,")
					.append("sum(case when SUB.CAStatus='Risk order' then SUB.OrderQuantity else 0 end) as risk,")
					.append("sum(case when SUB.CAStatus='Shipment' then SUB.OrderQuantity else 0 end) as shipment,")
					.append("sum(case when SUB.CAStatus='Future order' then SUB.OrderQuantity else 0 end) as future,")
					.append("sum(SUB.OrderQuantity) as total,")
					.append(" 'Product' as remarkType")
					.append(" from (select mfg.*,status.CAStatus,product.ProductEnglishName as dimensionName ");
			if(!form.isShowSalesOverview())
				sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
			else
				sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
				sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
			   		.append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
			   		.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
			   		.append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			   		.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
			}
			else {
				sBuffer.append(" left join  View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
			}
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
				form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
			    sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   		   .append(form.getStartDate())
			   		   .append(" and ").append(form.getEndDate());
			}
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
					form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
					form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			    	sBuffer.append(" where mfg.Year*100 + mfg.Month between '")
						   .append(form.getQuarterFrom()).append("'")
						   .append(" and '").append(form.getQuarterTo()).append("'");
				}
				//month
				else {
			    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
			    		.append(" and mfg.Month = ").append(form.getMonth());
				}
			}
			
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
			
			if(!"-1".equals(form.getDashboardTypeKey())) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and mfg.RegionKey in( ").append(form.getDashboardTypeKey()).append(") ");
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and mfg.ProductKey = ").append(form.getDashboardTypeKey());
				else if("Family".equals(form.getDashboardType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
				else if("Portfolio".equals(form.getDashboardType()))
					sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getDashboardTypeKey());
			}
			
			if(!"-1".equals(form.getCrossMonthTypeKey())) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and mfg.RegionKey in( ").append(form.getCrossMonthTypeKey()).append(") ");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mfg.ProductKey = ").append(form.getCrossMonthTypeKey());
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey());
				else if("Portfolio".equals(form.getCrossMonthType()))
					sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(!"-1".equals(form.getDashboardTypeKey())) 
					sBuffer.append(" and geoRegion.geoKey in( ").append(form.getDashboardTypeKey()).append(") ");
			} 
			
			sBuffer.append(")SUB group by SUB.ProductKey,SUB.dimensionName having SUB.dimensionName <> '' order by SUB.ProductKey");
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Portfolio".equals(form.getDimension())) {
			//sBuffer.append("select SUB.DetractorKey as dimensionKey,SUB.dimensionName as dimensionName,")
			sBuffer.append("select SUB.PortofolioKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.CAStatus='Committed Backlog' then SUB.OrderQuantity else 0 end) as committed,")
					.append("sum(case when SUB.CAStatus='Risk order' then SUB.OrderQuantity else 0 end) as risk,")
					.append("sum(case when SUB.CAStatus='Shipment' then SUB.OrderQuantity else 0 end) as shipment,")
					.append("sum(case when SUB.CAStatus='Future order' then SUB.OrderQuantity else 0 end) as future,")
					.append("sum(SUB.OrderQuantity) as total,")
					.append(" 'Portfolio' as remarkType")
					.append(" from (select mfg.*,status.CAStatus,dimPortofolio.PortofolioKey, dimPortofolio.PortofolioEnglishName as dimensionName ");
	   		if(!form.isShowSalesOverview())
	   			sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
			else
				sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
				sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
			   		.append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
			   		.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
			   		.append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			   		.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
			}
			else {
				sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
			} 
			
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
				form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
			    sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   		   .append(form.getStartDate())
			   		   .append(" and ").append(form.getEndDate());
			}
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
					form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
					form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			    	sBuffer.append(" where mfg.Year*100 + mfg.Month between '")
						   .append(form.getQuarterFrom()).append("'")
						   .append(" and '").append(form.getQuarterTo()).append("'");
				}
				//month
				else {
			    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
			    		.append(" and mfg.Month = ").append(form.getMonth());
				}
			}
			
			
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
			
			if(!"-1".equals(form.getDashboardTypeKey())) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and mfg.RegionKey in( ").append(form.getDashboardTypeKey()).append(") ");
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and mfg.ProductKey = ").append(form.getDashboardTypeKey());
				else if("Family".equals(form.getDashboardType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
				else if("Portfolio".equals(form.getDashboardType()))
					sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getDashboardTypeKey());
			}
			
			if(!"-1".equals(form.getCrossMonthTypeKey())) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and mfg.RegionKey in( ").append(form.getCrossMonthTypeKey()).append(") ");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mfg.ProductKey = ").append(form.getCrossMonthTypeKey());
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey());
				else if("Portfolio".equals(form.getCrossMonthType()))
					sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(!"-1".equals(form.getDashboardTypeKey())) 
					sBuffer.append(" and geoRegion.geoKey in( ").append(form.getDashboardTypeKey()).append(") ");
			}
			
			//group by mfg.RegionKey, mfg.CAStatusKey having mfg.RegionKey <> '' order by mfg.RegionKey,mfg.CAStatusKey
			sBuffer.append(")SUB group by SUB.PortofolioKey,SUB.dimensionName having SUB.dimensionName <> '' order by SUB.PortofolioKey");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
								.addScalar("dimensionKey", StringType.INSTANCE)
								.addScalar("dimensionName", StringType.INSTANCE)
								.addScalar("committed", IntegerType.INSTANCE)
								.addScalar("risk", IntegerType.INSTANCE)
								.addScalar("shipment", IntegerType.INSTANCE)
								.addScalar("future", IntegerType.INSTANCE)
								.addScalar("total", IntegerType.INSTANCE)
								.addScalar("remarkType", StringType.INSTANCE)
								.setResultTransformer(Transformers.aliasToBean(CARemarkChartData.class));
		
		return query.list();
	}
	
	@Override
	public Integer fetchRemarkOdmCommitment(CARemarkChartData caRemarkChartData,SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(CMT) as odmCommitment")
		   		.append(" from FactMonthlySummaryofODMCommitment odmCommit");
		
		sBuffer.append(" left join(")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on odmCommit.ProductKey = productFamily.ProductKey");
		
		sBuffer.append(" left join FactProductPortofolioMapping productPortofolioMapping on odmCommit.ProductKey = productPortofolioMapping.ProductKey")
				.append(" left join DimPortofolio dimPortofolio on productPortofolioMapping.PortofolioKey = dimPortofolio.PortofolioKey");
		
		if(form.isShowGeoOverview()) {
			sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on odmCommit.regionkey = geoRegion.regionKey");
			
		}
		else {
			sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = odmCommit.RegionKey");
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where  odmCommit.Year*100 + odmCommit.Month between ")
	    	.append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  odmCommit.Year*100 + odmCommit.Month between ")
				   .append(form.getQuarterFrom())
				   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where odmCommit.Year = ").append(form.getYear())
		    		.append(" and odmCommit.Month = ").append(form.getMonth());
			}
		}
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and odmCommit.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and odmCommit.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if("Product".equals(form.getDimension())) {
			sBuffer.append(" and odmCommit.ProductKey = ").append(caRemarkChartData.getDimensionKey());
			//sBuffer.append(" group by odmCommit.Year,odmCommit.Month,odmCommit.ProductKey");
		}
			
		if("Family".equals(form.getDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(caRemarkChartData.getDimensionKey());
			//sBuffer.append(" group by odmCommit.Year,odmCommit.Month,productFamily.familyKey");
		}
			
		if("Portfolio".equals(form.getDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(caRemarkChartData.getDimensionKey());
			//sBuffer.append(" group by odmCommit.Year,odmCommit.Month,dimPortofolio.PortofolioKey");
		}
		
		if("Region".equals(form.getDimension())) {
			if(form.isShowGeoOverview()) {
				sBuffer.append(" and geoRegion.geoKey in( ").append(form.getSubDimensionKey()).append(") ");
				//sBuffer.append(" group by odmCommit.Year,odmCommit.Month,geoRegion.geoKey");
			}
			else {
				//sBuffer.append(" and odmCommit.RegionKey = ").append(form.getSubDimensionKey());
				sBuffer.append(" and odmCommit.RegionKey in( ").append(caRemarkChartData.getDimensionKey()).append(") ");
				//sBuffer.append(" group by odmCommit.Year,odmCommit.Month,odmCommit.RegionKey");
			}
		}
		if(!"-1".equals(form.getDashboardTypeKey())) {
			if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
				sBuffer.append(" and odmCommit.RegionKey in( ").append(form.getDashboardTypeKey()).append(")");
			else if("Product".equals(form.getDashboardType()))
				sBuffer.append(" and odmCommit.ProductKey = ").append(form.getDashboardTypeKey());
			else if("Family".equals(form.getDashboardType()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
			else if("Portfolio".equals(form.getDashboardType()))
				sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getDashboardTypeKey());
		}
		
		if(!"-1".equals(form.getCrossMonthTypeKey())) {
			if("Region".equals(form.getCrossMonthType()))
				sBuffer.append(" and odmCommit.RegionKey in( ").append(form.getCrossMonthTypeKey()).append(")");
			else if("Product".equals(form.getCrossMonthType()))
				sBuffer.append(" and odmCommit.ProductKey = ").append(form.getCrossMonthTypeKey());
			else if("Family".equals(form.getCrossMonthType()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey());
			else if("Portfolio".equals(form.getCrossMonthType()))
				sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getCrossMonthTypeKey());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchRemarkCaTarget(CARemarkChartData caRemarkChartData,SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(TargetQty) as caTarget")
   				.append(" from FactCATarget caTarget");
		
		/*if(form.isShowGeoOverview()) {
			sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on caTarget.GeographyKey = geoRegion.regionKey");
			
		}
		else {*/
			sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = caTarget.GeographyKey");
		//}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where  caTarget.FiscalYear*100 + caTarget.CalendarMonth between ")
	    	.append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  caTarget.FiscalYear*100 + caTarget.CalendarMonth between ")
				   .append(form.getQuarterFrom())
				   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where caTarget.FiscalYear = ").append(form.getYear())
		    		.append(" and caTarget.CalendarMonth = ").append(form.getMonth());
			}
		}
		
		/*if("Region".equals(form.getDimension())) {
			if(form.isShowGeoOverview()) {
				sBuffer.append(" and geoRegion.geoKey = ").append(form.getSubDimensionKey());
				sBuffer.append(" group by caTarget.FiscalYear,caTarget.CalendarMonth,geoRegion.geoKey");
			}
			else {
				sBuffer.append(" and caTarget.RegionKey = ").append(form.getSubDimensionKey());
				sBuffer.append(" group by caTarget.FiscalYear,caTarget.CalendarMonth,caTarget.GeographyKey");
			}
		}*/
		
		//sBuffer.append(" and caTarget.GeographyKey = ").append(caRemarkChartData.getDimensionKey());
		sBuffer.append(" and geography.GeographyName = '").append(caRemarkChartData.getDimensionName()).append("'");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchBoh(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(prcBoh.BOH) as boh")
				.append(" from FactPRCBOH prcBoh ");
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where prcBoh.Year*100 + prcBoh.Month between ")
			    	.append(form.getStartDate())
					.append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where prcBoh.Year*100 + prcBoh.Month between ")
				    	.append(form.getQuarterFrom())
						.append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where prcBoh.Year = ").append(form.getYear())
    					.append(" and prcBoh.Month = ").append(form.getMonth());
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchOverviewBoh(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(prcBoh.BOH) as boh")
				.append(" from FactMonthlySummaryofMFGCA mfg ")
   				.append(" join FactPRCBOH prcBoh")
   				.append(" on mfg.MTMKey = prcBoh.MTMKey and mfg.ProductKey = prcBoh.ProductKey and mfg.ODMKey = prcBoh.ODMKey");
		sBuffer.append(" left join(")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		sBuffer.append(" left join FactProductPortofolioMapping productPortofolioMapping on mfg.ProductKey = productPortofolioMapping.ProductKey")
				.append(" left join DimPortofolio dimPortofolio on productPortofolioMapping.PortofolioKey = dimPortofolio.PortofolioKey");

		sBuffer.append(" left join View_DimGeography geo on mfg.RegionKey = geo.GeographyKey");
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where  mfg.Year*100 + mfg.Month between ")
			    	.append(form.getStartDate())
					.append(" and ").append(form.getEndDate());
	    	sBuffer.append(" and prcBoh.Year*100 + prcBoh.Month between ")
			    	.append(form.getStartDate())
					.append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  mfg.Year*100 + mfg.Month between ")
					   .append(form.getQuarterFrom())
					   .append(" and ").append(form.getQuarterTo());
		    	sBuffer.append(" and prcBoh.Year*100 + prcBoh.Month between ")
				    	.append(form.getQuarterFrom())
						.append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		    			.append(" and mfg.Month = ").append(form.getMonth());
		    	sBuffer.append(" and prcBoh.Year = ").append(form.getYear())
    					.append(" and prcBoh.Month = ").append(form.getMonth());
			}
		}
		
		sBuffer.append(" and geo.GeographyName = 'PRC' ");
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchCrossMonthBoh(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(prcBoh.BOH) as boh")
				.append(" from FactMonthlySummaryofMFGCA mfg ")
   				.append(" join FactPRCBOH prcBoh")
   				.append(" on mfg.MTMKey = prcBoh.MTMKey and mfg.ProductKey = prcBoh.ProductKey and mfg.ODMKey = prcBoh.ODMKey");
		sBuffer.append(" left join(")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		sBuffer.append(" left join FactProductPortofolioMapping productPortofolioMapping on mfg.ProductKey = productPortofolioMapping.ProductKey")
				.append(" left join DimPortofolio dimPortofolio on productPortofolioMapping.PortofolioKey = dimPortofolio.PortofolioKey");

		sBuffer.append(" left join View_DimGeography geo on mfg.RegionKey = geo.GeographyKey");
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where  mfg.Year*100 + mfg.Month between ")
			    	.append(form.getStartDate())
					.append(" and ").append(form.getEndDate());
	    	sBuffer.append(" and prcBoh.Year*100 + prcBoh.Month between ")
			    	.append(form.getStartDate())
					.append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  mfg.Year*100 + mfg.Month between ")
					   .append(form.getQuarterFrom())
					   .append(" and ").append(form.getQuarterTo());
		    	sBuffer.append(" and prcBoh.Year*100 + prcBoh.Month between ")
		    			.append(form.getQuarterFrom())
		    			.append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		    			.append(" and mfg.Month = ").append(form.getMonth());
		    	sBuffer.append(" and prcBoh.Year = ").append(form.getYear())
						.append(" and prcBoh.Month = ").append(form.getMonth());
			}
		}
		
		sBuffer.append(" and geo.GeographyName = 'PRC' ");
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if("Product".equals(form.getDimension())) {
			sBuffer.append(" and mfg.ProductKey = ").append(form.getSubDimensionKey());
		}
			
		if("Family".equals(form.getDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getSubDimensionKey());
		}
			
		if("Portfolio".equals(form.getDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getSubDimensionKey());
		}
		
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and mfg.RegionKey in( ").append(form.getSubDimensionKey()).append(") ");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchDashboardBoh(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(prcBoh.BOH) as boh")
				.append(" from FactMonthlySummaryofMFGCA mfg ")
   				.append(" join FactPRCBOH prcBoh")
   				.append(" on mfg.MTMKey = prcBoh.MTMKey and mfg.ProductKey = prcBoh.ProductKey and mfg.ODMKey = prcBoh.ODMKey");
		sBuffer.append(" left join(")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		sBuffer.append(" left join FactProductPortofolioMapping productPortofolioMapping on mfg.ProductKey = productPortofolioMapping.ProductKey")
			   .append(" left join DimPortofolio dimPortofolio on productPortofolioMapping.PortofolioKey = dimPortofolio.PortofolioKey");
		
		if(form.isShowGeoOverview()) {
			sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,region.GeographyName,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
			
		}
		else {
			sBuffer.append(" left join View_DimGeography geoRegion on mfg.RegionKey = geoRegion.GeographyKey");
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where  mfg.Year*100 + mfg.Month between ")
			    	.append(form.getStartDate())
					.append(" and ").append(form.getEndDate());
	    	sBuffer.append(" and prcBoh.Year*100 + prcBoh.Month between ")
			    	.append(form.getStartDate())
					.append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  mfg.Year*100 + mfg.Month between ")
					   .append(form.getQuarterFrom())
					   .append(" and ").append(form.getQuarterTo());
		    	sBuffer.append(" and prcBoh.Year*100 + prcBoh.Month between ")
				    	.append(form.getQuarterFrom())
						.append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		    			.append(" and mfg.Month = ").append(form.getMonth());
		    	sBuffer.append(" and prcBoh.Year = ").append(form.getYear())
						.append(" and prcBoh.Month = ").append(form.getMonth());
			}
		}
		
		sBuffer.append(" and geoRegion.GeographyName = 'PRC' ");
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if("Product".equals(form.getDimension())) {
			sBuffer.append(" and mfg.ProductKey = ").append(form.getSubDimensionKey());
		}
			
		if("Family".equals(form.getDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getSubDimensionKey());
		}
			
		if("Portfolio".equals(form.getDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getSubDimensionKey());
		}
		
		if("Region".equals(form.getDimension())) {
			if(form.isShowGeoOverview()) {
				sBuffer.append(" and geoRegion.geoKey in( ").append(form.getSubDimensionKey()).append(") ");
			}
			else {
				sBuffer.append(" and mfg.RegionKey in( ").append(form.getSubDimensionKey()).append(") ");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	/*@Override
	public Integer fetchRemarkBoh(CARemarkChartData caRemarkChartData,SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(prcBoh.BOH) as boh")
				.append(" from FactMonthlySummaryofMFGCA mfg ")
   				.append(" join FactPRCBOH prcBoh")
   				.append(" on mfg.MTMKey = prcBoh.MTMKey and mfg.ProductKey = prcBoh.ProductKey and mfg.ODMKey = prcBoh.ODMKey");
		
		if("Family".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		if("Portfolio".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
	   				.append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey");
	    
		sBuffer.append(" left join View_DimGeography geo on mfg.RegionKey = geo.GeographyKey");
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where  mfg.Year*100 + mfg.Month between ")
			    	.append(form.getStartDate())
					.append(" and ").append(form.getEndDate());
	    	sBuffer.append(" and prcBoh.Year*100 + prcBoh.Month between ")
			    	.append(form.getStartDate())
					.append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  mfg.Year*100 + mfg.Month between ")
					   .append(form.getQuarterFrom())
					   .append(" and ").append(form.getQuarterTo());
		    	sBuffer.append(" and prcBoh.Year*100 + prcBoh.Month between ")
		    			.append(form.getQuarterFrom())
		    			.append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		    			.append(" and mfg.Month = ").append(form.getMonth());
		    	sBuffer.append(" and prcBoh.Year = ").append(form.getYear())
						.append(" and prcBoh.Month = ").append(form.getMonth());
			}
		}
		
		sBuffer.append(" and geo.GeographyName = 'PRC' ");
		if("Region".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" and mfg.RegionKey =  ").append(caRemarkChartData.getDimensionKey());
		else if("Family".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" and productFamily.familyKey =  ").append(caRemarkChartData.getDimensionKey());
		else if("Product".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" and mfg.ProductKey =  ").append(caRemarkChartData.getDimensionKey());
		else if("Portfolio".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" and dimPortofolio.PortofolioKey =  ").append(caRemarkChartData.getDimensionKey());
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}*/
	
	@Override
	public Integer fetchRemarkBoh(CARemarkChartData caRemarkChartData,SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if("Region".equals(caRemarkChartData.getRemarkType())) {
			if("PRC".equalsIgnoreCase(caRemarkChartData.getDimensionName())) 
				sBuffer.append("select sum(prcBoh.BOH) as boh from FactPRCBOH prcBoh");
			else 
				return null;
		}
		else {
			sBuffer.append("select sum(prcBoh.BOH) as boh")
					.append(" from (select distinct ProductKey,RegionKey from FactMonthlySummaryofMFGCA mfgca");
			if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
				form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
				form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    	sBuffer.append(" where mfgca.Year*100 + mfgca.Month between ")
				    	.append(form.getStartDate())
						.append(" and ").append(form.getEndDate());
			}
			else {
				//quarter
				if(form.isShowQuarterOverview()) {
					form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
					form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			    	sBuffer.append(" where  mfgca.Year*100 + mfgca.Month between ")
						   .append(form.getQuarterFrom())
						   .append(" and ").append(form.getQuarterTo());
				}
				//month
				else {
			    	sBuffer.append(" where mfgca.Year = ").append(form.getYear())
			    			.append(" and mfgca.Month = ").append(form.getMonth());
				}
			}
			
			if("Product".equals(caRemarkChartData.getRemarkType()))
				sBuffer.append(" and mfgca.ProductKey =  ").append(caRemarkChartData.getDimensionKey());
			
			sBuffer.append(")mfg ");
			
			sBuffer.append(" join FactPRCBOH prcBoh")
						.append(" on mfg.ProductKey = prcBoh.ProductKey");
			sBuffer.append(" left join View_DimGeography geo on mfg.RegionKey = geo.GeographyKey");
		}
		if("Family".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" left join (")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		if("Portfolio".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey = factProductPortofolioMapping.ProductKey ")
	   				.append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey = dimPortofolio.PortofolioKey");
	    
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where prcBoh.Year*100 + prcBoh.Month between ")
			    	.append(form.getStartDate())
					.append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where prcBoh.Year*100 + prcBoh.Month between ")
		    			.append(form.getQuarterFrom())
		    			.append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where prcBoh.Year = ").append(form.getYear())
						.append(" and prcBoh.Month = ").append(form.getMonth());
			}
		}
		if("Family".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" and productFamily.familyKey =  ").append(caRemarkChartData.getDimensionKey());
		else if("Portfolio".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" and dimPortofolio.PortofolioKey =  ").append(caRemarkChartData.getDimensionKey());
		if(!"Region".equals(caRemarkChartData.getRemarkType()))
			sBuffer.append(" and geo.GeographyName = 'PRC' ");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public CaKeyNameObject fetchOverviewCaTargetAndCtp(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(CTPTarget) as ctp,sum(TargetQty) as caTarget")
		   		.append(" from FactCATarget caTarget");
		
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on caTarget.GeographyKey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = caTarget.GeographyKey");
			}
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where caTarget.FiscalYear*100 + caTarget.CalendarMonth between ")
	    			.append(form.getStartDate())
	    			.append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  caTarget.FiscalYear*100 + caTarget.CalendarMonth between ")
					   .append(form.getQuarterFrom())
					   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where caTarget.FiscalYear = ").append(form.getYear())
		    		.append(" and caTarget.CalendarMonth = ").append(form.getMonth());
			}
		}
		
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and caTarget.GeographyKey in(").append(form.getGeoIds()).append(")");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("ctp", IntegerType.INSTANCE)
				.addScalar("caTarget", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(CaKeyNameObject.class));

		return (CaKeyNameObject)query.uniqueResult();
	}
	
	@Override
	public CaKeyNameObject fetchCrossMonthCaTargetAndCtp(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(CTPTarget) as ctp,sum(TargetQty) as caTarget")
		   		.append(" from FactCATarget caTarget");
		
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on caTarget.GeographyKey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = caTarget.GeographyKey");
			}
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where caTarget.FiscalYear*100 + caTarget.CalendarMonth between ")
	    			.append(form.getStartDate())
	    			.append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  caTarget.FiscalYear*100 + caTarget.CalendarMonth between ")
					   .append(form.getQuarterFrom())
					   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where caTarget.FiscalYear = ").append(form.getYear())
		    		.append(" and caTarget.CalendarMonth = ").append(form.getMonth());
			}
		}
		
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and caTarget.GeographyKey in( ").append(form.getSubDimensionKey()).append(")");
		}
		
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and caTarget.GeographyKey in(").append(form.getGeoIds()).append(")");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("ctp", IntegerType.INSTANCE)
				.addScalar("caTarget", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(CaKeyNameObject.class));

		return (CaKeyNameObject)query.uniqueResult();
	}
	
	@Override
	public CaKeyNameObject fetchDashboardCaTargetAndCtp(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(CTPTarget) as ctp,sum(TargetQty) as caTarget")
		   		.append(" from FactCATarget caTarget");
		
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on caTarget.GeographyKey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = caTarget.GeographyKey");
			}
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where caTarget.FiscalYear*100 + caTarget.CalendarMonth between ")
	    			.append(form.getStartDate())
	    			.append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  caTarget.FiscalYear*100 + caTarget.CalendarMonth between ")
					   .append(form.getQuarterFrom())
					   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where caTarget.FiscalYear = ").append(form.getYear())
		    		.append(" and caTarget.CalendarMonth = ").append(form.getMonth());
			}
		}
		
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and caTarget.GeographyKey in( ").append(form.getSubDimensionKey()).append(") ");
		}
		
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and caTarget.GeographyKey in(").append(form.getGeoIds()).append(")");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("ctp", IntegerType.INSTANCE)
				.addScalar("caTarget", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(CaKeyNameObject.class));

		return (CaKeyNameObject)query.uniqueResult();
	}
	
	@Override
	public Integer fetchOverviewOdmCommitment(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(CMT) as odmCommitment")
		   		.append(" from FactMonthlySummaryofODMCommitment odmCommit");
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" left join(")
					.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey") 
					.append(" from DimProduct product")
					.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					.append(")productFamily on odmCommit.ProductKey = productFamily.ProductKey");
		}
		/*if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" left join DimProduct product on odmCommit.ProductKey = product.ProductKey");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = odmCommit.RegionKey");
			}
		}*/
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" left join FactProductPortofolioMapping productPortofolioMapping on odmCommit.ProductKey = productPortofolioMapping.ProductKey")
					.append(" left join DimPortofolio dimPortofolio on productPortofolioMapping.PortofolioKey = dimPortofolio.PortofolioKey");
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where odmCommit.Year*100 + odmCommit.Month between ")
	    	.append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  odmCommit.Year*100 + odmCommit.Month between ")
				   .append(form.getQuarterFrom())
				   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where odmCommit.Year = ").append(form.getYear())
		    		.append(" and odmCommit.Month = ").append(form.getMonth());
			}
		}
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and odmCommit.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and odmCommit.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchCrossMonthOdmCommitment(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(CMT) as odmCommitment")
		   		.append(" from FactMonthlySummaryofODMCommitment odmCommit");
		
		sBuffer.append(" left join(")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on odmCommit.ProductKey = productFamily.ProductKey");
		
		sBuffer.append(" left join FactProductPortofolioMapping productPortofolioMapping on odmCommit.ProductKey = productPortofolioMapping.ProductKey")
				.append(" left join DimPortofolio dimPortofolio on productPortofolioMapping.PortofolioKey = dimPortofolio.PortofolioKey");
	
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where odmCommit.Year*100 + odmCommit.Month between ")
	    	.append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  odmCommit.Year*100 + odmCommit.Month between ")
				   .append(form.getQuarterFrom())
				   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where odmCommit.Year = ").append(form.getYear())
		    		.append(" and odmCommit.Month = ").append(form.getMonth());
			}
		}
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and odmCommit.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and odmCommit.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if("Product".equals(form.getDimension())) {
			sBuffer.append(" and odmCommit.ProductKey = ").append(form.getSubDimensionKey());
			sBuffer.append(" group by odmCommit.Year,odmCommit.Month,odmCommit.ProductKey");
		}
			
		if("Family".equals(form.getDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getSubDimensionKey());
			sBuffer.append(" group by odmCommit.Year,odmCommit.Month,productFamily.familyKey");
		}
			
		if("Portfolio".equals(form.getDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getSubDimensionKey());
			sBuffer.append(" group by odmCommit.Year,odmCommit.Month,dimPortofolio.PortofolioKey");
		}
		
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and odmCommit.RegionKey in( ").append(form.getSubDimensionKey()).append(") ");
			sBuffer.append(" group by odmCommit.Year,odmCommit.Month,odmCommit.RegionKey");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchDashboardOdmCommitment(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select sum(CMT) as odmCommitment")
		   		.append(" from FactMonthlySummaryofODMCommitment odmCommit");
		
		sBuffer.append(" left join(")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on odmCommit.ProductKey = productFamily.ProductKey");
		
		sBuffer.append(" left join FactProductPortofolioMapping productPortofolioMapping on odmCommit.ProductKey = productPortofolioMapping.ProductKey")
				.append(" left join DimPortofolio dimPortofolio on productPortofolioMapping.PortofolioKey = dimPortofolio.PortofolioKey");
		
		if(form.isShowGeoOverview()) {
			sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on odmCommit.regionkey = geoRegion.regionKey");
			
		}
		else {
			sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = odmCommit.RegionKey");
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    	sBuffer.append(" where odmCommit.Year*100 + odmCommit.Month between ")
	    	.append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where  odmCommit.Year*100 + odmCommit.Month between ")
				   .append(form.getQuarterFrom())
				   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where odmCommit.Year = ").append(form.getYear())
		    		.append(" and odmCommit.Month = ").append(form.getMonth());
			}
		}
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and odmCommit.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and odmCommit.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if("Product".equals(form.getDimension())) {
			sBuffer.append(" and odmCommit.ProductKey = ").append(form.getSubDimensionKey());
			sBuffer.append(" group by odmCommit.Year,odmCommit.Month,odmCommit.ProductKey");
		}
			
		if("Family".equals(form.getDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getSubDimensionKey());
			sBuffer.append(" group by odmCommit.Year,odmCommit.Month,productFamily.familyKey");
		}
			
		if("Portfolio".equals(form.getDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getSubDimensionKey());
			sBuffer.append(" group by odmCommit.Year,odmCommit.Month,dimPortofolio.PortofolioKey");
		}
		
		if("Region".equals(form.getDimension())) {
			if(form.isShowGeoOverview()) {
				sBuffer.append(" and geoRegion.geoKey in( ").append(form.getSubDimensionKey()).append(") ");
				sBuffer.append(" group by odmCommit.Year,odmCommit.Month,geoRegion.geoKey");
			}
			else {
				sBuffer.append(" and odmCommit.RegionKey in( ").append(form.getSubDimensionKey()).append(") ");
				sBuffer.append(" group by odmCommit.Year,odmCommit.Month,odmCommit.RegionKey");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CaKeyNameObject> fetchDimensions(SearchCaForm form){
		form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
		form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		PagerInformation pagerInfo = form.getPagerInfo();
		StringBuffer sBuffer = new StringBuffer();
		if("Region".equals(form.getDashboardType())){
			if(!form.isShowGeoOverview()) {
				 sBuffer.append("select DBO.AggregateRegionId(geography.GeographyName) as objKey,geography.GeographyName as objName,'Region' as type");
			}
			else {
				sBuffer.append("select DBO.AggregateRegionId(parentGeography.GeographyName) as objKey,parentGeography.GeographyName as objName,'Region' as type");
			}
			
			if(!form.isShowSalesOverview()){
				sBuffer.append(" from FactMonthlySummaryofMFGCA mfg");
			}
			else {
				sBuffer.append(" from FactMonthlySummaryofSalesCA mfg");
			}
			
			sBuffer.append(" left join DimProduct product on product.ProductKey = mfg.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			
			sBuffer.append(" left join View_DimGeography geography on mfg.RegionKey = geography.GeographyKey");
			
			if(form.isShowGeoOverview()){
				sBuffer.append(" left join View_DimGeography parentGeography on parentGeography.GeographyKey = geography.parentGeographyKey");
			}
			
			if(StringUtils.isNotBlank(form.getPortfolioIds())){
				sBuffer.append(" left join FactProductPortofolioMapping pp on mfg.ProductKey=pp.ProductKey");
				if("Portfolio".equals(form.getDashboardType())){
					sBuffer.append(" inner join DimPortofolio p on pp.PortofolioKey=p.PortofolioKey");
				}
			}
			
	    	sBuffer.append(" where mfg.Year * 100 + mfg.Month between ").append(form.getQuarterFrom())
	    			.append(" and  ").append(form.getQuarterTo());
	    	
	    	if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getPortfolioIds())){
				sBuffer.append(" and pp.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				if(!form.isShowSalesOverview()){
					sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
				}
			}
			
			//show geo or region overview 
			if(!form.isShowGeoOverview()) {
				sBuffer.append(" group by geography.GeographyName having geography.GeographyName <> ''");
			}
			else{
				sBuffer.append(" group by parentgeography.geographyname having parentgeography.geographyname <> '' ");
			}
			
			sBuffer.append(" order by sum(mfg.OrderQuantity) desc");
		}
		//for Family overview chart
		else if("Family".equals(form.getDashboardType())){
			sBuffer.append("select family.ProductFamilyKey as objKey,family.ProductFamilyEnglishName as objName,'Family' as type");
			
			if(!form.isShowSalesOverview()){
				sBuffer.append(" from FactMonthlySummaryofMFGCA mfg");
			}
			else {
				sBuffer.append(" from FactMonthlySummaryofSalesCA mfg");
			}
			sBuffer.append(" left join DimProduct product on product.ProductKey = mfg.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			
			if(StringUtils.isNotBlank(form.getPortfolioIds())){
				sBuffer.append(" inner join FactProductPortofolioMapping pp on mfg.ProductKey=pp.ProductKey");
				if("Portfolio".equals(form.getDashboardType())){
					sBuffer.append(" inner join DimPortofolio p on pp.PortofolioKey=p.PortofolioKey");
				}
			}
			
			sBuffer.append(" where mfg.Year * 100 + mfg.Month between ").append(form.getQuarterFrom())
					.append(" and  ").append(form.getQuarterTo());
	    	
	    	if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getPortfolioIds())){
				sBuffer.append(" and pp.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				if(!form.isShowSalesOverview()){
					sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
				}
			}
			
			sBuffer.append(" group by family.ProductFamilyKey,family.ProductFamilyEnglishName having family.ProductFamilyKey <> ''");
			sBuffer.append(" order by sum(mfg.OrderQuantity) desc");
		}
		
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())){
			sBuffer.append("select product.ProductKey as objKey,product.ProductEnglishName as objName,'Product' as type");
			
			if(!form.isShowSalesOverview()){
				sBuffer.append(" from FactMonthlySummaryofMFGCA mfg");
			}
			else {
				sBuffer.append(" from FactMonthlySummaryofSalesCA mfg");
			}
			sBuffer.append(" left join DimProduct product on product.ProductKey = mfg.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			
			if(StringUtils.isNotBlank(form.getPortfolioIds())){
				sBuffer.append(" left join FactProductPortofolioMapping pp on mfg.ProductKey=pp.ProductKey");
				if("Portfolio".equals(form.getDashboardType())){
					sBuffer.append(" left join DimPortofolio p on pp.PortofolioKey=p.PortofolioKey");
				}
			}
			
			sBuffer.append(" where mfg.Year * 100 + mfg.Month between ").append(form.getQuarterFrom())
					.append(" and  ").append(form.getQuarterTo());
	    	
	    	if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getPortfolioIds())){
				sBuffer.append(" and pp.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				if(!form.isShowSalesOverview()){
					sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
				}
			}
			
			sBuffer.append(" group by product.ProductKey,product.ProductEnglishName having product.ProductKey <> ''");
			sBuffer.append(" order by sum(mfg.OrderQuantity) desc");
		}
		//for Portfolio overview chart
		else if("Portfolio".equals(form.getDashboardType())){
			sBuffer.append("select p.PortofolioKey as objKey,p.PortofolioEnglishName as objName,'Portfolio' as type");
			
			if(!form.isShowSalesOverview()){
				sBuffer.append(" from FactMonthlySummaryofMFGCA mfg");
			}
			else {
				sBuffer.append(" from FactMonthlySummaryofSalesCA mfg");
			}
			
			sBuffer.append(" left join DimProduct product on product.ProductKey = mfg.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			
			sBuffer.append(" left join FactProductPortofolioMapping pp on mfg.ProductKey=pp.ProductKey")
					.append(" left join DimPortofolio p on pp.PortofolioKey=p.PortofolioKey");
			
			sBuffer.append(" where mfg.Year * 100 + mfg.Month between ").append(form.getQuarterFrom())
					.append(" and  ").append(form.getQuarterTo());
	    	
	    	if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getPortfolioIds())){
				sBuffer.append(" and pp.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				if(!form.isShowSalesOverview()){
					sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
				}
			}
			
			sBuffer.append(" group by p.PortofolioKey,p.PortofolioEnglishName having p.PortofolioKey <> ''");
			sBuffer.append(" order by sum(mfg.OrderQuantity) desc");
		}
		
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", StringType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(CaKeyNameObject.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchCaDashboardOverViewChartData(SearchCaForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select sum(mfg.OrderQuantity) as orderNum,case when status.CAStatus is null then 'Unknown' else status.CAStatus end as scStatusName");
		if(!form.isShowSalesOverview())
			sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
		else
			sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
		   	sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
		   		.append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
		   		.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   		.append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
		   		.append(" left join (")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
	   	if(form.isShowGeoOverview()) {
			sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
			
		}
		else {
			sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
		}
		
	   	if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
		   		   .append(form.getStartDate())
		   		   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where mfg.Year*100 + mfg.Month between '")
					   .append(form.getQuarterFrom()).append("'")
					   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		    		.append(" and mfg.Month = ").append(form.getMonth());
			}
		}
	   	
	   	//for Region dashboard overview chart
		if("Region".equals(form.getDimension())) {
			if(form.isShowGeoOverview()){
				sBuffer.append(" and geoRegion.geoKey in (").append(form.getSubDimensionKey()).append(")");
			}
			else{
				sBuffer.append(" and mfg.RegionKey in( ").append(form.getSubDimensionKey()).append(")");
			}
		}
		//for Family dashboard overview chart
		else if("Family".equals(form.getDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getSubDimensionKey());
		}
		//for Product dashboard overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and mfg.ProductKey = ").append(form.getSubDimensionKey());
		}
		//for Portfolio dashboard overview chart
		else if("Portfolio".equals(form.getDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getPortfolioIds())){
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(!form.isShowSalesOverview()){
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
	   	
		sBuffer.append(" group by status.CAStatus order by status.CAStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchCaCrossMonthOverviewChartData(SearchCaForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select sum(mfg.OrderQuantity) as orderNum,case when status.CAStatus is null then 'Unknown' else status.CAStatus end as scStatusName");
		if(!form.isShowSalesOverview())
			sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
		else
			sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
		   	sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
		   		.append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
		   		.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   		.append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
		   		.append(" left join (")
				.append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
				.append(" from DimProduct product")
				.append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				.append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		
		sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
		   		   .append(form.getStartDate())
		   		   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    	sBuffer.append(" where mfg.Year*100 + mfg.Month between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		    		.append(" and mfg.Month = ").append(form.getMonth());
			}
		}
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if("Product".equals(form.getDimension())) {
			sBuffer.append(" and mfg.ProductKey = ").append(form.getSubDimensionKey());
		}
			
		if("Family".equals(form.getDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getSubDimensionKey());
		}
			
		if("Portfolio".equals(form.getDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getSubDimensionKey());
		}
		
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and mfg.RegionKey in( ").append(form.getSubDimensionKey()).append(") ");
		}
		
		sBuffer.append(" group by status.CAStatus order by status.CAStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> getOverviewOverall(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		sBuffer.append("select count(fpsd.OrderKey) as orderNum,status.FPSDStatus as scStatusName")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" inner join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
			   .append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		if(form.getOrderTypeId() != -1)
			sBuffer.append(" and fpsd.OrderTypeKey = ").append(form.getOrderTypeId());
		//crossmonth overview chart:Region or Odm or Porduct
		if(!"-1".equals(form.getCrossMonthTypeKey())) {
			if("Region".equals(form.getCrossMonthType()))
				sBuffer.append(" and fpsd.RegionKey in( ").append(form.getCrossMonthTypeKey()).append(") ");
			else if("Odm".equals(form.getCrossMonthType()))
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
			else if("Product".equals(form.getCrossMonthType()))
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
		}
		
		sBuffer.append(" group by status.FPSDStatus having status.FPSDStatus <> '' order by status.FPSDStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchCaDataByDimKeys(SearchCaForm form) {
		form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select sum(mfg.OrderQuantity) as orderNum,case when status.CAStatus is null then 'Unknown' else status.CAStatus end as scStatusName");
		if(!form.isShowSalesOverview()){
			sBuffer.append(" from FactMonthlySummaryofMFGCA mfg");
		}else{
			sBuffer.append(" from FactMonthlySummaryofSalesCA mfg");
		}
		 sBuffer.append(" inner join ")
		 .append(" DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey");
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sBuffer.append(" inner join DimProduct product on product.ProductKey = mfg.ProductKey");
		}
		if(StringUtils.isNotBlank(form.getPortfolioIds())){
			sBuffer.append(" inner join FactProductPortofolioMapping pp on mfg.ProductKey=pp.ProductKey");
		}
		sBuffer.append(" where mfg.Year*100 +  mfg.Month between ")
		   		.append(form.getStartDate())
		   		.append(" and ").append(form.getEndDate());
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sBuffer.append(" and product.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getPortfolioIds())){
			sBuffer.append(" and pp.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		
		sBuffer.append(" group by status.CAStatus order by status.CAStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CaDetailGridView> fetchMfgCaDetail(SearchCaForm form) {
		//System.out.println("sum mfg ca detail");
		StringBuffer sb = new StringBuffer();
		sb.append("select max(geographyParent.GeographyName) as Geo,isNull(max(geography.GeographyName),'Unknown') as Region,")
			.append("max(product.ProductEnglishName) as Product,sum(isnull(mfg.OrderQuantity,0)) as orderQTY,")
			.append("sum(case status.CaStatus when 'Shipment' then mfg.OrderQuantity else 0 end ) as shipmentOrder,")
			.append("sum(case status.CaStatus when 'Committed Backlog' then mfg.OrderQuantity else 0 end ) as committedOrder,")
			.append("sum(case status.CaStatus when 'Risk order' then mfg.OrderQuantity else 0 end ) as riskOrder,")
			.append("isNull(factCaTarget.caTarget,0) as caTarget,")
			.append("isNull(mfg.odmCommitment,0) as commitment");
		sb.append(" from (")
		.append("select m.CAStatusKey, isnull(m.RegionKey,c.RegionKey) as RegionKey,isnull(m.ProductKey,c.ProductKey) as ProductKey, ")
		.append("isnull(m.year,c.year) as year,isnull(m.month,c.month) as month, ")
		.append("m.OrderQuantity,c.odmCommitment  ")
		.append("from (select * from FactMonthlySummaryofMFGCA) m ")
		.append("full join ( ")
		.append("select ")
		.append("sum(CMT) as odmCommitment, ")
		.append("odmCommit.ProductKey as productKey, ")
		.append("odmCommit.RegionKey as regionKey, ")
		.append("year, ")
		.append("month ")
		.append("from FactMonthlySummaryofODMCommitment odmCommit ")
		.append("group by productKey,regionKey,year,month ")
		.append(")c on m.RegionKey = c.regionKey and m.ProductKey = c.productKey and m.year = c.year and m.month = c.month ")
		.append(") mfg");
		sb.append(" left join DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey");
		sb.append(" left join View_DimGeography geography on mfg.RegionKey = geography.GeographyKey");
		sb.append(" left join View_DimGeography geographyParent on geographyParent.GeographyKey = geography.ParentGeographyKey");
		sb.append(" left join DimProduct product on product.ProductKey = mfg.ProductKey");
		sb.append(" left join FactProductPortofolioMapping pp on mfg.ProductKey=pp.ProductKey");
		sb.append(" left join (select sum(TargetQty) as caTarget,caTarget.GeographyKey as geographyKey from FactCATarget caTarget")
			.append(" where caTarget.FiscalYear*100 + caTarget.CalendarMonth between ")
			.append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			.append("  and  ")
			.append(CalendarUtil.yearMonthConvert(form.getEndDate()))
			.append(" group by caTarget.GeographyKey")
			.append(")factCaTarget on mfg.RegionKey = factCaTarget.geographyKey");
		/*sb.append(" left join (select sum(CMT) as odmCommitment,odmCommit.ProductKey as productKey,odmCommit.RegionKey as regionKey from FactMonthlySummaryofODMCommitment odmCommit")
			.append(" where odmCommit.year*100 + odmCommit.month between ")
			.append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			.append("  and  ")
			.append(CalendarUtil.yearMonthConvert(form.getEndDate()))
			.append(" group by productKey,regionKey")
			.append(")factOdmCommitment on mfg.RegionKey = factOdmCommitment.regionKey and mfg.ProductKey = factOdmCommitment.productKey");*/
		
		sb.append(" where mfg.year*100 + mfg.month between ")
			.append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			.append("  and  ")
			.append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey())) {
				if(form.isShowGeoOverview())//geo overview
					sb.append(" and geographyParent.GeographyKey in( ").append(form.getOverViewSubDimensionKey()).append(") ");
				else 
					sb.append(" and mfg.RegionKey in( ").append(form.getOverViewSubDimensionKey()).append(") ");
			}
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sb.append(" and product.ProductFamilyKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sb.append(" and mfg.ProductKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Portfolio overview chart
		if("Portfolio".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sb.append(" and pp.PortofolioKey = ").append(form.getOverViewSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sb.append(" and geographyParent.GeographyKey in( ").append(form.getGeoIds()).append(")");
			else
				sb.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sb.append(" and product.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getPortfolioIds())){
			sb.append(" and pp.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getScStatus())){
			sb.append(" and status.caStatus = '").append(form.getScStatus()).append("'");
		}
		
		sb.append(" group by mfg.ProductKey,mfg.RegionKey,factCaTarget.caTarget,mfg.odmCommitment");
		sb.append(" order by mfg.RegionKey");
		
		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("Geo", StringType.INSTANCE)
				.addScalar("Region", StringType.INSTANCE)
				.addScalar("Product", StringType.INSTANCE)
				.addScalar("orderQTY", IntegerType.INSTANCE)
				.addScalar("shipmentOrder", IntegerType.INSTANCE)
				.addScalar("committedOrder", IntegerType.INSTANCE)
				.addScalar("riskOrder", IntegerType.INSTANCE)
				.addScalar("caTarget", IntegerType.INSTANCE)
				.addScalar("commitment", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(CaDetailGridView.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CaDetailGridView> fetchSalesCaDetail(SearchCaForm form) {
		StringBuffer sb = new StringBuffer();
		sb.append("select max(geographyParent.GeographyName) as Geo,isNull(max(geography.GeographyName),'Unknown') as Region,")
			.append("max(product.ProductEnglishName) as Product,")
			.append("sum(case status.CaStatus when 'Shipment' then mfg.OrderQuantity else 0 end ) as shipmentOrder,")
			.append("isNull(factCaTarget.caTarget,0) as caTarget");
		sb.append(" from FactMonthlySummaryofSalesCA mfg");
		sb.append(" left join DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey");
		sb.append(" left join View_DimGeography geography on mfg.RegionKey = geography.GeographyKey");
		sb.append(" left join View_DimGeography geographyParent on geographyParent.GeographyKey = geography.ParentGeographyKey");
		sb.append(" left join DimProduct product on product.ProductKey = mfg.ProductKey");
		sb.append(" left join FactProductPortofolioMapping pp on mfg.ProductKey=pp.ProductKey");
		
		sb.append(" left join (select sum(TargetQty) as caTarget,caTarget.GeographyKey as geographyKey from FactCATarget caTarget")
			.append(" where caTarget.FiscalYear*100 + caTarget.CalendarMonth between ")
			.append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			.append("  and  ")
			.append(CalendarUtil.yearMonthConvert(form.getEndDate()))
			.append(" group by caTarget.GeographyKey")
			.append(")factCaTarget on mfg.RegionKey = factCaTarget.geographyKey");
		
		sb.append(" where mfg.year*100 + mfg.month between ")
			.append(CalendarUtil.yearMonthConvert(form.getStartDate()))
			.append("  and  ")
			.append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey())) {
				if(form.isShowGeoOverview())//geo overview
					sb.append(" and geographyParent.GeographyKey in( ").append(form.getOverViewSubDimensionKey()).append(") ");
				else 
					sb.append(" and mfg.RegionKey in( ").append(form.getOverViewSubDimensionKey()).append(") ");
			}
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sb.append(" and product.ProductFamilyKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sb.append(" and mfg.ProductKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Portfolio overview chart
		if("Portfolio".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sb.append(" and pp.PortofolioKey = ").append(form.getOverViewSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sb.append(" and geographyParent.GeographyKey in( ").append(form.getGeoIds()).append(")");
			else
				sb.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sb.append(" and product.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getPortfolioIds())){
			sb.append(" and pp.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getScStatus())){
			sb.append(" and status.caStatus = '").append(form.getScStatus()).append("'");
		}
		sb.append(" group by mfg.ProductKey,mfg.RegionKey,factCaTarget.caTarget");
		sb.append(" order by mfg.RegionKey");
		
		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("Geo", StringType.INSTANCE)
				.addScalar("Region", StringType.INSTANCE)
				.addScalar("Product", StringType.INSTANCE)
				.addScalar("shipmentOrder", IntegerType.INSTANCE)
				.addScalar("caTarget", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(CaDetailGridView.class));
		
		return query.list();
	}
	
	@Override
	public int getRemarkOrderDetailCount(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(mfg.CAStatusKey) as orderNum ");
		if(!form.isShowSalesOverview())
			sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
		else
			sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
		   	sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
			   .append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
			   .append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	   .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			   .append(" left join (")
			   .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			   .append(" from DimProduct product")
			   .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			   .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
	
		if(form.isShowGeoOverview()) {
			sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
		}
		else {
			sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
		}
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
	    	sBuffer.append(" where mfg.Year = ").append(form.getYear())
	    			.append(" and mfg.Month = ").append(form.getMonth());
	    }
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");

		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
				sBuffer.append(" and geography.GeographyName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		else if("Family".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and productFamily.ProductFamilyEnglishName = '"	+ form.getSubDimension().toUpperCase()+ "' ");
		}
		else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and product.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		else if("Portfolio".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and dimPortofolio.PortofolioEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer) query.uniqueResult();
	}
	
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getRemarkOrderDetail(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		if(form.isShowAllRemarkOrder()){
			sBuffer.append("(select top ").append(form.getRowCount() + form.getOrderNumber()).append(" * from ");
		}else{
			sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		}
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("mfg.POItem as poItem,")
				.append("mfg.PONumber as poNumber,")
				.append("mfg.POItem as itemNo,")
				.append("mfg.OrderQuantity as qty,")
				.append("mfg.OrderDate as orderDate,")
				.append("mfg.RSDDate as rsd,")
				.append("mfg.FPSDDate as fpsd,")
				.append("mfg.ShipDate as shippedDate,")
				.append("mfg.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("mfg.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofMFGCA mfg")
				.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
				.append(" left join DimProduct dimProduct on mfg.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on mfg.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on mfg.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on mfg.MTMKey = mtm.MTMKey")
				.append(" left join View_DimGeography region on mfg.RegionKey = region.GeographyKey")
				.append(" left join View_DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join View_DimGeography country on mfg.CountryKey = country.GeographyKey")
				.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	    .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			    .append(" left join (")
			    .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			    .append(" from DimProduct product")
			    .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			    .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		}
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and region.GeographyName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		else if("Family".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and productFamily.ProductFamilyEnglishName = '"	+ form.getSubDimension().toUpperCase()+ "' ");
		}
		else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and product.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		else if("Portfolio".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and dimPortofolio.PortofolioEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getSalesRemarkOrderDetail(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		if(form.isShowAllRemarkOrder()){
			sBuffer.append("(select top ").append(form.getRowCount() + form.getOrderNumber()).append(" * from ");
		}else{
			sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		}
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" '' as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("'' as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("'' as poItem,")
				.append("'' as poNumber,")
				.append("'' as itemNo,")
				.append("mfg.OrderQuantity as qty,")
				.append("'' as orderDate,")
				.append("'' as rsd,")
				.append("'' as fpsd,")
				.append("'' as shippedDate,")
				.append("'' as shipped,")
				.append("'' as level1,")
				.append("'' as level2 ,")
				.append("'' as level3 ")
				.append(" from FactMonthlySummaryofSalesCA mfg")
				.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
				.append(" left join DimProduct dimProduct on mfg.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimMTM mtm on mfg.MTMKey = mtm.MTMKey")
				.append(" left join View_DimGeography region on mfg.RegionKey = region.GeographyKey")
				.append(" left join View_DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	    .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			    .append(" left join (")
			    .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			    .append(" from DimProduct product")
			    .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			    .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		}
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and region.GeographyName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		else if("Family".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and productFamily.ProductFamilyEnglishName = '"	+ form.getSubDimension().toUpperCase()+ "' ");
		}
		else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and product.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		else if("Portfolio".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append(" and dimPortofolio.PortofolioEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	
	@Override
	public int getOverviewOrderDetailCount(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(mfg.CAStatusKey) as orderNum");
			if(!form.isShowSalesOverview())
				sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
			else
				sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
			   	sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
		   	   .append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
		   	   .append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	   .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			   .append(" left join (")
			   .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			   .append(" from DimProduct product")
			   .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			   .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		if(form.isShowGeoOverview()) {
			sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
		}
		else {
			sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
		}
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		 }
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getOverviewOrderDetail(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("mfg.POItem as poItem,")
				.append("mfg.PONumber as poNumber,")
				.append("mfg.POItem as itemNo,")
				.append("mfg.OrderQuantity as qty,")
				.append("mfg.OrderDate as orderDate,")
				.append("mfg.RSDDate as rsd,")
				.append("mfg.FPSDDate as fpsd,")
				.append("mfg.ShipDate as shippedDate,")
				.append("mfg.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("mfg.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofMFGCA mfg")
				.append(" left join DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
				.append(" left join DimProduct dimProduct on mfg.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on mfg.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on mfg.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on mfg.MTMKey = mtm.MTMKey")
				.append(" left join View_DimGeography region on mfg.RegionKey = region.GeographyKey")
				.append(" left join View_DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join View_DimGeography country on mfg.CountryKey = country.GeographyKey")
				.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	    .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			    .append(" left join (")
			    .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			    .append(" from DimProduct product")
			    .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			    .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
				
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		 }
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getSalesOverviewOrderDetail(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" '' as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("'' as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("'' as poItem,")
				.append("'' as poNumber,")
				.append("'' as itemNo,")
				.append("mfg.OrderQuantity as qty,")
				.append("'' as orderDate,")
				.append("'' as rsd,")
				.append("'' as fpsd,")
				.append("'' as shippedDate,")
				.append("'' as shipped,")
				.append("'' as level1,")
				.append("'' as level2 ,")
				.append("'' as level3 ")
				.append(" from FactMonthlySummaryofSalesCA mfg")
				.append(" left join DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
				.append(" left join DimProduct dimProduct on mfg.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimMTM mtm on mfg.MTMKey = mtm.MTMKey")
				.append(" left join View_DimGeography region on mfg.RegionKey = region.GeographyKey")
				.append(" left join View_DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	    .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			    .append(" left join (")
			    .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			    .append(" from DimProduct product")
			    .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			    .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
				
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		 }
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getPortfolioIds())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	public int getCrossMonthOrderDetailCount(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(mfg.CAStatusKey) as orderNum");
			if(!form.isShowSalesOverview())
				sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
			else
				sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
			   	sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
		   	   .append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
		   	   .append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	   .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			   .append(" left join (")
			   .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			   .append(" from DimProduct product")
			   .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			   .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		if(form.isShowGeoOverview()) {
			sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
		}
		else {
			sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
		}
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		 }
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.RegionKey in( ").append(form.getOverViewSubDimensionKey()).append(") ");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Portfolio overview chart
		if("Portfolio".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.RegionKey in( ").append(form.getRemarkSubDimensionKey()).append(") ");
		}
		//for Family remark chart
		else if("Family".equals(form.getRemarkDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Portfolio remark chart
		else if("Portfolio".equals(form.getRemarkDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getRemarkSubDimensionKey());
		}
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getCrossMonthOrderDetail(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("mfg.POItem as poItem,")
				.append("mfg.PONumber as poNumber,")
				.append("mfg.POItem as itemNo,")
				.append("mfg.OrderQuantity as qty,")
				.append("mfg.OrderDate as orderDate,")
				.append("mfg.RSDDate as rsd,")
				.append("mfg.FPSDDate as fpsd,")
				.append("mfg.ShipDate as shippedDate,")
				.append("mfg.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("mfg.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofMFGCA mfg")
				.append(" left join DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
				.append(" left join DimProduct dimProduct on mfg.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on mfg.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on mfg.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on mfg.MTMKey = mtm.MTMKey")
				.append(" left join View_DimGeography region on mfg.RegionKey = region.GeographyKey")
				.append(" left join View_DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join View_DimGeography country on mfg.CountryKey = country.GeographyKey")
				.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	    .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			    .append(" left join (")
			    .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			    .append(" from DimProduct product")
			    .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			    .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		 }
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.RegionKey in( ").append(form.getOverViewSubDimensionKey()).append(") ");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Portfolio overview chart
		if("Portfolio".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.RegionKey in( ").append(form.getRemarkSubDimensionKey()).append(") ");
		}
		//for Family remark chart
		else if("Family".equals(form.getRemarkDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Portfolio remark chart
		else if("Portfolio".equals(form.getRemarkDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getRemarkSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getSalesCrossMonthOrderDetail(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" '' as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("'' as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("'' as poItem,")
				.append("'' as poNumber,")
				.append("'' as itemNo,")
				.append("mfg.OrderQuantity as qty,")
				.append("'' as orderDate,")
				.append("'' as rsd,")
				.append("'' as fpsd,")
				.append("'' as shippedDate,")
				.append("'' as shipped,")
				.append("'' as level1,")
				.append("'' as level2 ,")
				.append("'' as level3 ")
				.append(" from FactMonthlySummaryofSalesCA mfg")
				.append(" left join DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
				.append(" left join DimProduct dimProduct on mfg.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimMTM mtm on mfg.MTMKey = mtm.MTMKey")
				.append(" left join View_DimGeography region on mfg.RegionKey = region.GeographyKey")
				.append(" left join View_DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	    .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			    .append(" left join (")
			    .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			    .append(" from DimProduct product")
			    .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			    .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		 }
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.RegionKey in( ").append(form.getOverViewSubDimensionKey()).append(") ");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Portfolio overview chart
		if("Portfolio".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.RegionKey in( ").append(form.getRemarkSubDimensionKey()).append(") ");
		}
		//for Family remark chart
		else if("Family".equals(form.getRemarkDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Portfolio remark chart
		else if("Portfolio".equals(form.getRemarkDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getRemarkSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	public int getDashboardOrderDetailCount(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(mfg.CAStatusKey) as orderNum");
		if(!form.isShowSalesOverview())
			sBuffer.append(" from FactMonthlySummaryofMFGCA mfg ");
		else
			sBuffer.append(" from FactMonthlySummaryofSalesCA mfg ");
			sBuffer.append(" left join  DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
		   	   .append(" left join DimProduct product on mfg.ProductKey = product.ProductKey")
		   	   .append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	   .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			   .append(" left join (")
			   .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			   .append(" from DimProduct product")
			   .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			   .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		if(form.isShowGeoOverview()) {
			sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from View_DimGeography geo join View_DimGeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on mfg.regionkey = geoRegion.regionKey");
		}
		else {
			sBuffer.append(" left join View_DimGeography geography on geography.GeographyKey = mfg.RegionKey");
		}
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		 }
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.RegionKey in( ").append(form.getOverViewSubDimensionKey()).append(") ");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Portfolio overview chart
		if("Portfolio".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.RegionKey in( ").append(form.getRemarkSubDimensionKey()).append(") ");
		}
		//for Family remark chart
		else if("Family".equals(form.getRemarkDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Portfolio remark chart
		else if("Portfolio".equals(form.getRemarkDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getRemarkSubDimensionKey());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getDashboardOrderDetail(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("mfg.POItem as poItem,")
				.append("mfg.PONumber as poNumber,")
				.append("mfg.POItem as itemNo,")
				.append("mfg.OrderQuantity as qty,")
				.append("mfg.OrderDate as orderDate,")
				.append("mfg.RSDDate as rsd,")
				.append("mfg.FPSDDate as fpsd,")
				.append("mfg.ShipDate as shippedDate,")
				.append("mfg.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("mfg.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofMFGCA mfg")
				.append(" left join DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
				.append(" left join DimProduct dimProduct on mfg.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on mfg.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on mfg.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on mfg.MTMKey = mtm.MTMKey")
				.append(" left join View_DimGeography region on mfg.RegionKey = region.GeographyKey")
				.append(" left join View_DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join View_DimGeography country on mfg.CountryKey = country.GeographyKey")
				.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	    .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			    .append(" left join (")
			    .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			    .append(" from DimProduct product")
			    .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			    .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		 }
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.RegionKey in( ").append(form.getOverViewSubDimensionKey()).append(") ");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Portfolio overview chart
		if("Portfolio".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.RegionKey in( ").append(form.getRemarkSubDimensionKey()).append(") ");
		}
		//for Family remark chart
		else if("Family".equals(form.getRemarkDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Portfolio remark chart
		else if("Portfolio".equals(form.getRemarkDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getRemarkSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getSalesDashboardOrderDetail(SearchCaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" '' as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("'' as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("'' as poItem,")
				.append("'' as poNumber,")
				.append("'' as itemNo,")
				.append("mfg.OrderQuantity as qty,")
				.append("'' as orderDate,")
				.append("'' as rsd,")
				.append("'' as fpsd,")
				.append("'' as shippedDate,")
				.append("'' as shipped,")
				.append("'' as level1,")
				.append("'' as level2 ,")
				.append("'' as level3 ")
				.append(" from FactMonthlySummaryofSalesCA mfg")
				.append(" left join DimCAStatus status on mfg.CAStatusKey = status.CAStatusKey")
				.append(" left join DimProduct dimProduct on mfg.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimMTM mtm on mfg.MTMKey = mtm.MTMKey")
				.append(" left join View_DimGeography region on mfg.RegionKey = region.GeographyKey")
				.append(" left join View_DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join FactProductPortofolioMapping factProductPortofolioMapping on mfg.ProductKey=factProductPortofolioMapping.ProductKey ")
		   	    .append(" left join DimPortofolio dimPortofolio on factProductPortofolioMapping.PortofolioKey=dimPortofolio.PortofolioKey")
			    .append(" left join (")
			    .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			    .append(" from DimProduct product")
			    .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			    .append(")productFamily on mfg.ProductKey = productFamily.ProductKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where mfg.Year*100 + mfg.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where mfg.Year = ").append(form.getYear())
		 			.append(" and mfg.Month = ").append(form.getMonth());
		 }
		
		if(!CAStatusEnum.Total.getTypeName().equals(form.getScStatus()))
			sBuffer.append(" and status.CAStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.RegionKey in( ").append(form.getOverViewSubDimensionKey()).append(") ");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Family overview chart
		else if("Family".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and mfg.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		//for Portfolio overview chart
		if("Portfolio".equals(form.getOverViewDimension())) {
			if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey()))
				sBuffer.append(" and productFamily.familyKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and productFamily.familyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and mfg.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and mfg.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getPortfolioIds())) {
				sBuffer.append(" and dimPortofolio.PortofolioKey in(").append(form.getPortfolioIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.RegionKey in( ").append(form.getRemarkSubDimensionKey()).append(") ");
		}
		//for Family remark chart
		else if("Family".equals(form.getRemarkDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and mfg.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Portfolio remark chart
		else if("Portfolio".equals(form.getRemarkDimension())) {
			sBuffer.append(" and dimPortofolio.PortofolioKey = ").append(form.getRemarkSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}
		else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
}
