package com.lenovo.bi.view.npi.chart.column;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lenovo.bi.view.npi.chart.common.DataSet;

public class MSColumnChartView {
	private ColumnChartInformation chartInfo;
	
	private Categories categories;
	
	private List<DataSet> dataSetList;
	
	private List<LineSet> lineSetList;
	
	public List<DataSet> getDataSetList() {
		return dataSetList;
	}
	
	@JsonProperty("dataset")
	public void setDataSetList(List<DataSet> dataSetList) {
		this.dataSetList = dataSetList;
	}

	public Categories getCategories() {
		return categories;
	}
	
	@JsonProperty("categories")
	public void setCategories(Categories categories) {
		this.categories = categories;
	}
	
	public ColumnChartInformation getChartInfo() {
		return chartInfo;
	}
	
	@JsonProperty("chart")
	public void setChartInfo(ColumnChartInformation chartInfo) {
		this.chartInfo = chartInfo;
	}
	
	public List<LineSet> getLineSetList() {
		return lineSetList;
	}

	@JsonProperty("lineset")
	public void setLineSetList(List<LineSet> lineSetList) {
		this.lineSetList = lineSetList;
	}

	public MSColumnChartView(){
		chartInfo = new ColumnChartInformation();
	}
}
