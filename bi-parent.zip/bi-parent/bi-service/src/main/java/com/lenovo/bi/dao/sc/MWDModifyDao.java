package com.lenovo.bi.dao.sc;

import java.util.List;
import java.util.Map;

import com.lenovo.bi.form.sc.mwd.SearchMWDForm;
import com.lenovo.bi.view.sc.mwd.MWDModifyDetailView;

public interface MWDModifyDao {
	public List<MWDModifyDetailView> getMWDModifyDetail(SearchMWDForm form);
	public int getMWDModifyDetailCount(SearchMWDForm form);
	public void updateMWD(Map<String, Object> map);
}
