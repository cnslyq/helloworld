package com.lenovo.bi.dao.sc.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.FloatType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.BPSDao;
import com.lenovo.bi.dto.BpsCrossMonth;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.enumobj.GeographyType;
import com.lenovo.bi.form.sc.bps.SearchBpsForm;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.sc.bps.BPSDetailView;
import com.lenovo.bi.view.sc.bps.FactDetailView;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;

@Repository
public class BPSDaoImpl extends HibernateBaseDaoImplDw<Object> implements BPSDao {
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getUnshippedOrderQty4Remark(SearchBpsForm form, List<BpsCrossMonth> bpsOrderList){
		String sql = generateUnshippedRemarkSql(form, bpsOrderList);
		Query query = null;
		query = getSession().createSQLQuery(sql)
				.addScalar("unshippedOrder", FloatType.INSTANCE)
				.addScalar("yearMonthDay", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<ScOverViewChartData> fetchBpsOverViewChartData(SearchBpsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(!form.isShowMonthOverview()){
			sBuffer.append("SELECT 'Unshipped' as scStatusName,isnull(sum(UnshippedBacklog),0) as orderNum ")
				   .append("FROM factdailysummaryofbps " )
				   .append("where versionDate = ' ")
				   .append(form.getVersionDate())
				   .append("' AND  type = 2 group by versiondate ")
				   .append("union all ")
				   .append("select 'BPS' as scStatusName,isnull(sum(bps),0) as orderNum ")
				   .append("from (select ProductFamily,max(bps) as bps,versiondate ")
				   .append("from (select bps.ProductFamily, ")
				   .append("SUM(bps) OVER (PARTITION BY bps.Commodity,bps.ProductFamily,bps.versionDate) as bps, ")
				   .append("bps.versiondate ")
				   .append("from factdailysummaryofbps bps ")
				  // .append("inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
				//   .append("left join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
				   .append("where versiondate = ' ")
				   .append(form.getVersionDate())
				   .append("' and type= 2 ")
				   .append(") bps ")
				   .append("group by ProductFamily,versiondate) as maxbps ")
				   .append("group by versiondate ");
		}
		else{
			sBuffer.append("SELECT 'Unshipped' as scStatusName,isnull(sum(UnshippedBacklog),0) as orderNum ")
			   .append("FROM factdailysummaryofbps " )
			   .append("where year  =  ")
			   .append(form.getVersionDate().substring(0,4))
			   .append(" and Month =")
			   .append(form.getVersionDate().substring(5,7))
			   .append(" AND  type = 2 group by year,Month  ")
			   .append("union all ")
			   .append("select 'BPS' as scStatusName,isnull(sum(bps),0) as orderNum ")
			   .append("from (select ProductFamily,max(bps) as bps,year,Month  ")
			   .append("from (select bps.ProductFamily, ")
			   .append("SUM(bps) OVER (PARTITION BY bps.Commodity,bps.ProductFamily,bps.year,Month) as bps, ")
			   .append("year,Month ")
			   .append("from factdailysummaryofbps bps ")
			 //  .append("inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
			//   .append("left join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
			   .append("where year  =  ")
			   .append(form.getVersionDate().substring(0,4))
			   .append(" and Month =")
			   .append(form.getVersionDate().substring(5,7))
			   .append(" and type= 2 ")
			   .append(") bps ")
			   .append("group by ProductFamily,year,Month) as maxbps ")
			   .append("group by year,Month ");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		return query.list();
	}
	
	
	@SuppressWarnings("unchecked")
	public List<ScOverViewChartData> fetchBpsOverViewCrossMonthChartDataRegion(SearchBpsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(!form.isShowMonthOverview()){
			sBuffer.append("SELECT scStatusName, orderNum FROM(SELECT isnull(sum(BPS),0) as BPS, isnull(sum(UnshippedBacklog),0) as Unshipped  FROM factdailysummaryofbps bps inner join DimGeography region on region.GeographyKey = bps.regionkey where versionDate = '").
			append(form.getVersionDate()).
			append("' and region.GeographyName = '").
			append(form.getKeyValue()).
			append("'").
			append(this.getBpsRemarkWhereCondition1(form)).
			append("and type = 1 group by versiondate)").
			append(" AS p UNPIVOT (orderNum FOR scStatusName IN (BPS, Unshipped))AS P");
		}
		else{
			sBuffer.append("SELECT scStatusName, orderNum FROM(SELECT year,Month, isnull(sum(BPS),0) as BPS, isnull(sum(UnshippedBacklog),0) as Unshipped FROM factdailysummaryofbps bps inner join DimGeography region on region.GeographyKey = bps.regionkey where year = ").
			append(form.getVersionDate().substring(0,4)).
			append(" and Month =").
			append(form.getVersionDate().substring(5,7)).
			append(" and region.GeographyName = '").
			append(form.getKeyValue()).
			append("'").
			append(this.getBpsRemarkWhereCondition1(form)).
			append("and type = 1 group by year,Month) AS p UNPIVOT (orderNum FOR scStatusName IN (BPS, Unshipped))AS P");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<ScOverViewChartData> fetchBpsOverViewCrossMonthChartDataODM(SearchBpsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(!form.isShowMonthOverview()){
			sBuffer.append("SELECT 'Unshipped' as scStatusName,isnull(sum(UnshippedBacklog),0) as orderNum ")
			   .append("FROM factdailysummaryofbps  as bps " )
			   .append("where versionDate = ' ")
			   .append(form.getVersionDate())
			   .append("' AND  type = 2 ")
			   .append(this.getBpsRemarkWhereCondition1(form))
			   .append(" AND  ODMkey = '")
			   .append(form.getKeyValue())
			   .append("'")
			   .append(" group by versiondate ")
			   .append("union all ")
			   .append("select 'BPS' as scStatusName,isnull(sum(bps),0) as orderNum ")
			   .append("from (select ProductFamily,max(bps) as bps,versiondate ")
			   .append("from (select bps.ProductFamily, ")
			   .append("SUM(bps) OVER (PARTITION BY bps.Commodity,bps.ProductFamily,bps.versionDate) as bps, ")
			   .append("bps.versiondate ")
			   .append("from factdailysummaryofbps bps ")
			  // .append("inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
	//		   .append("left join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
			   .append("where versiondate = ' ")
			   .append(form.getVersionDate())
			   .append("' and type= 2 ")
			   .append(this.getBpsRemarkWhereCondition1(form))
			   .append(" and bps.odmkey = ' ")
			   .append(form.getKeyValue())
			   .append("'")
			   .append(") bps ")
			   .append("group by ProductFamily,versiondate) as maxbps ")
			   .append("group by versiondate ");
		}
		else{
			sBuffer.append("SELECT 'Unshipped' as scStatusName,isnull(sum(UnshippedBacklog),0) as orderNum ")
			   .append("FROM factdailysummaryofbps as bps " )
			   .append("where year  =  ")
			   .append(form.getVersionDate().substring(0,4))
			   .append(" and Month =")
			   .append(form.getVersionDate().substring(5,7))
			   .append(" AND  type = 2 ")
			   .append(this.getBpsRemarkWhereCondition1(form))
			   .append(" AND  ODMkey = '")
			   .append(form.getKeyValue())
			   .append("'")
			   .append("group by year,Month ")
			   .append("union all ")
			   .append("select 'BPS' as scStatusName,isnull(sum(bps),0) as orderNum ")
			   .append("from (select ProductFamily,max(bps) as bps,year,Month ")
			   .append("from (select bps.ProductFamily, ")
			   .append("SUM(bps) OVER (PARTITION BY bps.Commodity,bps.ProductFamily,year,Month) as bps, ")
			   .append("year,Month ")
			   .append("from factdailysummaryofbps bps ")
			//   .append("inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
		//	   .append("left join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
			   .append("where year  =  ")
			   .append(form.getVersionDate().substring(0,4))
			   .append(" and Month =")
			   .append(form.getVersionDate().substring(5,7))
			   .append(this.getBpsRemarkWhereCondition1(form))
			   .append(" AND  type = 2 ")
			   .append(" AND  ODMkey = '")
			   .append(form.getKeyValue())
			   .append("'")
			   .append(") bps ")
			   .append("group by ProductFamily,year,Month) as maxbps ")
			   .append("group by year,Month ");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<ScOverViewChartData> fetchBpsOverViewCrossMonthChartDataProduct(SearchBpsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(!form.isShowMonthOverview()){
			sBuffer.append("SELECT 'Unshipped' as scStatusName,isnull(sum(UnshippedBacklog),0) as orderNum ")
			   .append("FROM factdailysummaryofbps  as bps " )
			   .append("where versionDate = ' ")
			   .append(form.getVersionDate())
			   .append("' AND  type = 2 ")
			   .append(this.getBpsRemarkWhereCondition1(form))
			   .append(" AND  productKey = '")
			   .append(form.getKeyValue())
			   .append("'")
			   .append(" group by versiondate ")
			   .append("union all ")
			   .append("select 'BPS' as scStatusName,isnull(sum(bps),0) as orderNum ")
			   .append("from (select productkey,max(bps) as bps,versiondate ")
			   .append("from (select bps.productkey, ")
			   .append("SUM(bps) OVER (PARTITION BY bps.Commodity,bps.productkey,bps.versionDate) as bps, ")
			   .append("bps.versiondate ")
			   .append("from factdailysummaryofbps bps ")
			//   .append("inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
		//	   .append("left join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
			   .append("where versiondate = ' ")
			   .append(form.getVersionDate()).append("'")
			   .append(this.getBpsRemarkWhereCondition1(form))
			   .append(" and type= 2 ")
			   .append(" and bps.productKey = '")
			   .append(form.getKeyValue())
			   .append("'")
			   .append(") bps ")
			   .append("group by productkey,versiondate) as maxbps ")
			   .append("group by versiondate ");
		}
		else{
			sBuffer.append("SELECT 'Unshipped' as scStatusName,isnull(sum(UnshippedBacklog),0) as orderNum ")
			   .append("FROM factdailysummaryofbps  as bps " )
			   .append("where year  =  ")
			   .append(form.getVersionDate().substring(0,4))
			   .append(" and Month =")
			   .append(form.getVersionDate().substring(5,7))
			   .append(" AND  type = 2 ")
			   .append(this.getBpsRemarkWhereCondition1(form))
			   .append(" AND  productKey = '")
			   .append(form.getKeyValue())
			   .append("'")
			   .append("group by year,Month ")
			   .append("union all ")
			   .append("select 'BPS' as scStatusName,isnull(sum(bps),0) as orderNum ")
			   .append("from (select productkey,max(bps) as bps,year,Month ")
			   .append("from (select bps.productkey, ")
			   .append("SUM(bps) OVER (PARTITION BY bps.Commodity,bps.productkey,year,Month) as bps, ")
			   .append("year,Month ")
			   .append("from factdailysummaryofbps bps ")
		//	   .append("inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
		//	   .append("left join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
			   .append("where year  =  ")
			   .append(form.getVersionDate().substring(0,4))
			   .append(" and Month =")
			   .append(form.getVersionDate().substring(5,7))
			   .append(this.getBpsRemarkWhereCondition1(form))
			   .append(" AND  type = 2 ")
			   .append(" AND  productKey = '")
			   .append(form.getKeyValue())
			   .append("'")
			   .append(") bps ")
			   .append("group by productkey,year,Month) as maxbps ")
			   .append("group by year,Month ");
		}
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		return query.list();
	}
	
	/**
	 * Get unshipped order according to bpsOrder to calculate bps rate
	 * @param form
	 * @return
	 */
	private String generateUnshippedRemarkSql(SearchBpsForm form, List<BpsCrossMonth> bpsOrderList){
		StringBuilder sql = new StringBuilder();
		StringBuilder subSql = new StringBuilder();
		for(BpsCrossMonth bpsOrder: bpsOrderList){
			subSql.append(bpsOrder.getRowValue() + " , ");
		}
		if(bpsOrderList.size() > 0){
			subSql.deleteCharAt(subSql.lastIndexOf(","));
		}
		if(form.isDetail()){
			sql.append("SELECT TOP 10 bps.orderKey as orderKey ");
		}else{
			if (form.isKpiFlg()){
				sql.append("SELECT isnull(sum(bps.OrderQuantity),0) as unshippedOrder ");
			}else{
				if(form.getFrequency().equals("Month")){
					sql.append("SELECT isnull(sum(bps.OrderQuantity),0) AS unshippedOrder, CONVERT(varchar(7), t.FullDateAlternateKey, 23) as yearMonthDay ");
				}else{
					
					sql.append("SELECT isnull(sum(bps.OrderQuantity),0) as unshippedOrder, CONVERT(varchar(10), t.FullDateAlternateKey, 23) as yearMonthDay ");
				}
				if(("region".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
						|| (!"region".equals(form.getDimension()) && "region".equals(form.getSubDimension()))){
					sql.append(",geo.GeographyKey as rowValue,geo.GeographyName as rowName ");
				}else if(("geo".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
						|| (!"geo".equals(form.getDimension()) && "geo".equals(form.getSubDimension()))){
					sql.append(",g1.GeographyKey as rowValue,g1.GeographyName as rowName ");
				}else if(("odm".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
						|| (!"odm".equals(form.getDimension()) && "odm".equals(form.getSubDimension()))){
					sql.append(",odm.ODMKey as rowValue,odm.ODMEnglishName as rowName ");
				}else if(("product".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
						|| (!"product".equals(form.getDimension()) && "product".equals(form.getSubDimension()))){
					sql.append(",pro.ProductKey as rowValue,pro.ProductEnglishName as rowName ");
				}
			}
		}
		if(form.getFrequency().equals("Day")){
			sql.append("FROM FactDailySummaryofBPS bps ");
		}else{
			sql.append("FROM FactMonthlySummaryofBPS bps ");
		}
//		sql.append("INNER JOIN DimOrder od on bps.OrderKey = od.OrderKey ");
		sql.append("INNER JOIN View_OrderDetail od on bps.OrderKey = od.OrderNo ");
//		sql.append("INNER JOIN DimTime t on bps.TargetDateKey = t.TimeKey ");
		if(("region".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
				|| (!"region".equals(form.getDimension()) && "region".equals(form.getSubDimension()))){
			sql.append("INNER JOIN DimGeography geo on bps.RegionKey = geo.GeographyKey and geo.GeographyType = '" + GeographyType.Region.name() +"' ");
			if(subSql.length()>0){
				
				sql.append("AND bps.RegionKey in ( ");
				sql.append(subSql.toString());
				sql.append(" ) ");
			}
		}else if(("geo".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
				|| (!"geo".equals(form.getDimension()) && "geo".equals(form.getSubDimension()))){
			sql.append("INNER JOIN DimGeography geo on bps.RegionKey = geo.GeographyKey ");
			sql.append("inner join DimGeography g1 on geo.ParentGeographyKey=g1.GeographyKey ");
			if(subSql.length()>0){
				
				sql.append("AND bps.RegionKey in ( ");
				sql.append(subSql.toString());
				sql.append(" ) ");
			}
		}else if(("odm".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
				|| (!"odm".equals(form.getDimension()) && "odm".equals(form.getSubDimension()))){
			sql.append("INNER JOIN DimODM odm on bps.ODMKey = odm.ODMKey ");
			if(subSql.length()>0){
				
				sql.append("AND bps.ODMKey in ( ");
				sql.append(subSql.toString());
				sql.append(" ) ");
			}
		}else if(("product".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
				|| (!"product".equals(form.getDimension()) && "product".equals(form.getSubDimension()))){
			sql.append("INNER JOIN DimProduct pro on bps.ProductKey = pro.ProductKey ");
			if(subSql.length()>0){
				
				sql.append("AND bps.ProductKey in ( ");
				sql.append(subSql.toString());
				sql.append(" ) ");
			}
		}
		
		if("region".equals(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append("INNER JOIN DimGeography geo on bps.RegionKey = geo.GeographyKey and geo.GeographyType = '" + GeographyType.Region.name() +"' ");
		}else if("geo".equals(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append("INNER JOIN DimGeography geo on bps.RegionKey = geo.GeographyKey ");
			sql.append("inner join DimGeography g1 on geo.ParentGeographyKey=g1.GeographyKey ");
		}else if("odm".equals(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append("INNER JOIN DimODM odm on bps.ODMKey = odm.ODMKey ");
		}else if("product".equals(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append("INNER JOIN DimProduct pro on bps.ProductKey = pro.ProductKey ");
		}
		
		sql.append("WHERE t.FullDateAlternateKey >= CAST('" + form.getStartDate() + "' AS datetime) ");
		sql.append("AND t.FullDateAlternateKey <= CAST('" + form.getEndDate() + "' AS datetime) ");
		
		if(form.getOrderTypeId().equals("1")) {
			if(!form.getOrderSubTypeId().equals("-1")) {
				sql.append(" and bps.OrderTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sql.append(" and bps.OrderTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId().equals("2")) {
			if(!form.getOrderSubTypeId().equals("-1")) {
				sql.append(" and bps.OrderTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sql.append(" and bps.OrderTypeKey in (3,4,5,6)");
			}
		}
		if(!StringUtil.isEmpty(form.getKeyValue())){
			if(("region".equals(form.getDimension()) && !"region".equals(form.getSubDimension()))){
				sql.append("AND bps.RegionKey = '" + form.getKeyValue() +"' ");
			}else if("odm".equals(form.getDimension()) && !"odm".equals(form.getSubDimension())){
				sql.append("AND bps.ODMKey = '" + form.getKeyValue() +"' ");
			}else if("product".equals(form.getDimension()) && !"product".equals(form.getSubDimension())){
				sql.append("AND bps.ProductKey = '" + form.getKeyValue() +"' ");
			}else if("geo".equals(form.getDimension()) && !"geo".equals(form.getSubDimension())){
				sql.append("AND g1.GeographyKey = '" + form.getKeyValue() +"' ");
			}
		}
		if (!StringUtil.isEmpty(form.getGeoIds()))
			sql.append("AND bps.RegionKey in (" + form.getGeoIds() +") ");
		if (!StringUtil.isEmpty(form.getOdmIds()))
			sql.append("AND bps.ODMKey in (" + form.getOdmIds() +") ");
		if (!StringUtil.isEmpty(form.getProductIds()))
			sql.append("AND bps.ProductKey in (" + form.getProductIds() +") ");
		if (!form.isKpiFlg() && !form.isDetail()){
			if(form.getFrequency().equals("Month")){
				sql.append("GROUP BY CONVERT(varchar(7), t.FullDateAlternateKey, 23) ");
			}else{
				sql.append("GROUP BY t.FullDateAlternateKey ");
			}
			if(("region".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
					|| (!"region".equals(form.getDimension()) && "region".equals(form.getSubDimension()))){
				sql.append(",geo.GeographyKey,geo.GeographyName ");
			}else if(("geo".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
					|| (!"geo".equals(form.getDimension()) && "geo".equals(form.getSubDimension()))){
				sql.append(",g1.GeographyKey,g1.GeographyName ");
			}else if(("odm".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
					|| (!"odm".equals(form.getDimension()) && "odm".equals(form.getSubDimension()))){
				sql.append(",odm.ODMKey,odm.ODMEnglishName ");
			}else if(("product".equals(form.getDimension()) && StringUtil.isEmpty(form.getSubDimension()))
					|| (!"product".equals(form.getDimension()) && "product".equals(form.getSubDimension()))){
				sql.append(",pro.ProductKey,pro.ProductEnglishName ");
			}
			if (form.getSubDimension() != null){
				sql.append("ORDER BY rowValue desc ");
			}else{
				if(form.getFrequency().equals("Month")){
					sql.append("ORDER BY CONVERT(varchar(7), t.FullDateAlternateKey, 23) ");
				}else{
					
					sql.append("ORDER BY t.FullDateAlternateKey ");
				}
			}
		}
		return sql.toString();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsOrderQty4Remark(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select  sum(impactorderQuantity) as bpsOrder,")
		.append("sum(cvshortagequantity) as unshippedOrder,")
//		.append("case cvshortagequantity when 0 then 1 else round(isnull(impactorderQuantity,0)*1000/isnull(cvshortagequantity,1)/1000.0,2) end as bpsRate,")
		.append("region.GeographyName as rowName,")
		.append("max(region.GeographyKey) as rowValue ")
		.append("from factdailysummaryofbps bps ")
		.append("inner join DimGeography region on region.GeographyKey = bps.regionkey ")
//		.append("where datediff(day, '"+form.getStartDate()+"', bps.versiondate) >= 0 ")
//		.append("and datediff(day, bps.versiondate, '"+form.getEndDate()+"') >= 0 ")
		.append("group by region.GeographyName ")
		.append("order by sum(impactorderQuantity)/sum(cvshortagequantity) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsDashboardRegion(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select  isnull(sum(BPS),0) as bpsOrder,isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case sum(UnshippedBacklog) when 0 then 1 else round(isnull(sum(BPS),0)*1.0/isnull(sum(UnshippedBacklog),1),3) end as bpsRate,");
		
		if(form.isShowGeo()==true){
			sql.append("geo.GeographyName as rowName,");
		}else{
			sql.append("region.GeographyName as rowName,");
		}
		sql.append("max(region.GeographyKey) as rowValue ")
		.append("from factdailysummaryofbps bps ")
		.append("inner join DimGeography region on region.GeographyKey = bps.regionkey ");
		if(form.isShowGeo()==true){
			sql.append("inner join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey ");
		}
		if("Day".equals(form.getFrequency())){
			sql.append(" where datediff(day, bps.versiondate, '"+form.getEndDate()+"') = 0 ");
		}else{
			sql.append(" where bps.Year*100+bps.Month between ")
			   .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
			   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		}
		sql.append(this.getBpsRemarkWhereCondition1(form))
			.append("and bps.type = 1");
		if(form.isShowGeo()==true){
			sql.append("group by geo.GeographyName ");
		}else{
			sql.append("group by region.GeographyName ");
		}
		
		sql.append("order by sum(BPS)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getUnshippedDashboardOverview(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select  isnull(sum(BPS),0) as bpsOrder,isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case sum(UnshippedBacklog) when 0 then 1 else round(isnull(sum(BPS),0)*1.0/isnull(sum(UnshippedBacklog),1),3) end as bpsRate,")
		.append("region.GeographyName as rowName,")
		.append("max(region.GeographyKey) as rowValue ")
		.append("from factdailysummaryofbps bps ")
		.append("inner join DimGeography region on region.GeographyKey = bps.regionkey ");
		if("Day".equals(form.getFrequency())){
			sql.append(" where datediff(day, bps.versiondate, '"+form.getEndDate()+"') = 0 ");
		}else{
			sql.append(" where bps.Year*100+bps.Month between ")
			   .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
			   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		}
		sql.append(this.getBpsRemarkWhereCondition1(form)).append("and bps.type = 1");
		sql.append("group by region.GeographyName ");
		sql.append("order by sum(BPS)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsDashboardODM(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select maxbps.odmKey as rowValue,max(odm.ODMEnglishName) as rowName,isnull(sum(bps),0) as bpsOrder from (select odmKey,ProductFamily,max(bps) as bps ")
		.append(" from (select bps.ProductFamily,SUM(bps) OVER (PARTITION BY bps.Commodity,bps.ProductFamily,bps.odmKey) as bps,bps as bpsOrder,bps.odmKey ")
		.append(" from factdailysummaryofbps bps ");
		   if("Day".equals(form.getFrequency())){
			   sql.append(" where bps.versiondate = '"+form.getEndDate()+"'");
		   }else{
			   sql.append(" where bps.Year*100+bps.Month between ")
				  .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
				  .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		   }
		   sql.append(this.getBpsRemarkWhereCondition1(form));
		   sql.append(" and type= 2 ) bps group by ProductFamily,odmKey) as maxbps ")
		   .append(" inner join dimodm odm on odm.odmkey = maxbps.odmkey ")
		   .append(" group by maxbps.odmKey ");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getUnshippedDashboardODM(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(BPS),0) as bpsOrder,isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		   .append("case sum(UnshippedBacklog) when 0 then 1 else round(isnull(sum(BPS),0)*1.0/isnull(sum(UnshippedBacklog),1),3) end as bpsRate,")
		   .append("ODM.ODMEnglishName as rowName,max(ODM.odmKey) as rowValue from factdailysummaryofbps bps ")
		   .append("inner join DimODM ODM on ODM.ODMKey = bps.ODMkey ");
		if("Day".equals(form.getFrequency())){
			sql.append(" where datediff(day, bps.versiondate, '"+form.getEndDate()+"') = 0 ");
		}else{
			sql.append(" where bps.Year*100+bps.Month between ")
			   .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
			   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		}
		sql.append(this.getBpsRemarkWhereCondition1(form)).append("and bps.type = 2");
		sql.append("group by ODM.ODMEnglishName ");
		sql.append("order by sum(BPS)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsDashboardProduct(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(bps.productkey,0) as rowValue,max(ProductEnglishName) as rowName,isnull(max(bps),0) as bpsOrder from (select bps.productkey,SUM(bps) OVER (PARTITION BY bps.Commodity,bps.productkey) as bps, bps as bpsOrder from factdailysummaryofbps bps ");
		  // .append("inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ");
		   if("Day".equals(form.getFrequency())){
			   sql.append(" where bps.versiondate = '"+form.getEndDate()+"'");
		   }else{
			   sql.append(" where bps.Year*100+bps.Month between ")
			      .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
			      .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		   }
		   sql.append(this.getBpsRemarkWhereCondition1(form));
		   sql.append(" and type= 2 ) bps inner join dimproduct p on p.productKey = bps.productkey group by bps.productkey");
		   
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getUnshippedDashboardProduct(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(BPS),0) as bpsOrder,isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(BPS),0)*1.0/isnull(sum(UnshippedBacklog),1),3) end as bpsRate,")
		.append("pro.productEnglishName as rowName,max(pro.productKey) as rowValue from factdailysummaryofbps bps ")
		.append("inner join dimproduct pro on pro.productKey = bps.productkey ");
		if("Day".equals(form.getFrequency())){
			sql.append(" where datediff(day, bps.versiondate, '"+form.getEndDate()+"') = 0 ");
		}else{
			sql.append(" where bps.Year*100+bps.Month between ")
			   .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
			   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		}
		sql.append(this.getBpsRemarkWhereCondition1(form)).append("and bps.type = 2");
		sql.append(" group by pro.productEnglishName ");
		sql.append("order by sum(BPS)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}

	private String getBpsRemarkWhereCondition(SearchBpsForm form){
		StringBuffer sb = new StringBuffer();
		if("Day".equalsIgnoreCase(form.getFrequency())){
			sb.append(" where datediff(day, '"+form.getStartDate()+"', bps.versiondate) >= 0 ")
			.append("and datediff(day, bps.versiondate, '"+form.getEndDate()+"') >= 0 ");
		}else{
			sb.append(" where bps.Year*100+bps.Month between ")
			   .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
			   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		}
		if(StringUtils.isNotBlank(form.getRegionIds())){
			sb.append(" and bps.regionkey in (")
			.append("select GeographyKey from DimGeography where GeographyName in (").append(form.getRegionIds()).append(")) ");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and bps.regionkey in (")
			.append(" select r.GeographyKey from DimGeography r")
			.append(" inner join DimGeography g on r.ParentGeographyKey = g.GeographyKey where g.GeographyName in (").append(form.getGeoIds()).append(")) ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and bps.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and bps.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductFamilyIds())){
			sb.append(" and bps.ProductFamily in (").append(form.getProductFamilyIds()).append(") ");
		}
		if("region".equals(form.getDimension()) || "geo".equals(form.getDimension())){
			sb.append(" and bps.type = 1 ");
		}else if(StringUtils.isBlank(form.getDimension()) && "region".equals(form.getSubDimension())){
			sb.append(" and bps.type = 1 ");
		}else{
			sb.append(" and bps.type = 2 ");
		}
		return sb.toString();
	}
	
	private String getBpsRemarkWhereCondition1(SearchBpsForm form){
		StringBuffer sb = new StringBuffer();
		if(StringUtils.isNotBlank(form.getRegionIds())){
			sb.append(" and bps.regionkey in (")
			.append("select GeographyKey from DimGeography where GeographyName in (").append(form.getRegionIds()).append(")) ");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and bps.regionkey in (")
			.append(" select r.GeographyKey from DimGeography r")
			.append(" inner join DimGeography g on r.ParentGeographyKey = g.GeographyKey where g.GeographyName in (").append(form.getGeoIds()).append(")) ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and bps.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and bps.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductFamilyIds())){
			sb.append(" and bps.ProductFamily in (").append(form.getProductFamilyIds()).append(") ");
		}
		return sb.toString();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsOrderQty4RemarkByRegion(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(bps),0) as bpsOrder,")
		.append("isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(bps),0) when 0 then 0 else case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(bps),0)*1.0/isnull(sum(UnshippedBacklog),1),2) end end as bpsRate,")
		.append("region.GeographyName as rowName,")
		.append("max(region.GeographyKey) as rowValue ")
		.append("from factdailysummaryofbps bps ")
		.append("inner join DimGeography region on region.GeographyKey = bps.regionkey ")
		.append(this.getBpsRemarkWhereCondition(form))
		.append("group by region.GeographyName ");
		sql.append("order by sum(bps)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsOrderQty4RemarkByODM(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(bps),0) as bpsOrder,")
		.append("isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(bps),0) when 0 then 0 else case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(bps),0)*1.0/isnull(sum(UnshippedBacklog),1),2) end end as bpsRate,")
		.append("odm.odmEnglishName as rowName,")
		.append("max(odm.ODMKey) as rowValue ")
		.append("from factdailysummaryofbps bps ")
		.append("inner join DimODM odm on odm.ODMKey = bps.ODMKey ")
		.append(this.getBpsRemarkWhereCondition(form))
		.append("group by odm.odmEnglishName ");
		sql.append("order by sum(bps)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsOrderQty4RemarkByProduct(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(bps),0) as bpsOrder,")
		.append("isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(bps),0) when 0 then 0 else case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(bps),0)*1.0/isnull(sum(UnshippedBacklog),1),2) end end as bpsRate,")
		.append("product.productEnglishName as rowName,")
		.append("max(product.productKey) as rowValue ")
		.append("from factdailysummaryofbps bps ")
		.append("inner join dimproduct product on product.productKey = bps.productKey ")
		.append(this.getBpsRemarkWhereCondition(form))
		.append("group by product.productEnglishName ");
		sql.append("order by sum(bps)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsOrderQty4RemarkByProductFamily(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(bps),0) as bpsOrder,")
		.append("isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(bps),0) when 0 then 0 else case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(bps),0)*1.0/isnull(sum(UnshippedBacklog),1),2) end end as bpsRate,")
		.append("bps.ProductFamily as rowName ")
		//.append("bps.ProductFamily as rowValue ")
		.append("from factdailysummaryofbps bps ")
		.append(this.getBpsRemarkWhereCondition(form))
		.append(" and bps.ProductFamily is not null ")
		.append("group by bps.ProductFamily ");
		sql.append("order by sum(bps)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				//.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsOrderQty4PieByCVPurchaseType(
			SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(bps),0) as bpsOrder,")
		.append("isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(bps),0) when 0 then 0 else case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(bps),0)*1.0/isnull(sum(UnshippedBacklog),1),2) end end as bpsRate,")
		.append("pt.PurchaseType as rowName,")
		.append("max(pt.PurchaseTypeKey) as rowValue ")
		.append("from (")
		.append("select isnull(cv.PurchaseTypeKey,bps.BPSPurchaseTypeKey) as purchaseTypeKey,bps as bps,UnshippedBacklog as UnshippedBacklog ")
		.append("from factdailysummaryofbps bps ").append(" left join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
		.append(this.getBpsRemarkWhereCondition(form))
		.append(" and (cv.PurchaseTypeKey is not null or bps.BPSPurchaseTypeKey is not null )")
		.append(") bps ")
		.append("inner join DimPurchaseType pt on pt.PurchaseTypeKey = bps.PurchaseTypeKey ")
		.append("group by pt.PurchaseType ");
		sql.append("order by sum(bps)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsOrderQty4PieByPurchaseType(
			SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(bps),0) as bpsOrder,")
		.append("isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(bps),0) when 0 then 0 else case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(bps),0)*1.0/isnull(sum(UnshippedBacklog),1),2) end end as bpsRate,")
		.append("bps.PurchaseType as rowName ")
		.append("from factdailysummaryofbps bps ")
		.append(this.getBpsRemarkWhereCondition(form))
		.append(" and bps.PurchaseType is not null and bps.PurchaseType != '' ")
		.append("group by bps.PurchaseType ");
		sql.append("order by sum(bps)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsOrderQty4PieByParts(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(bps),0) as bpsOrder,")
		.append("isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(bps),0) when 0 then 0 else case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(bps),0)*1.0/isnull(sum(UnshippedBacklog),1),2) end end as bpsRate,")
		.append("parts.CommodityType as rowName,")
		.append("max(parts.CommodityTypeKey) as rowValue, ")
		.append("'parts' as type ")
		.append("from factdailysummaryofbps bps ")
		.append("inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
		.append("inner join DimCommodityType parts on parts.CommodityTypeKey = cv.CommodityTypeKey ")
		.append(this.getBpsRemarkWhereCondition(form));
		if(StringUtils.isNotBlank(form.getFilterPurchaseTypeId())){
			if("region".equals(form.getDimension())){
				sql.append(" and bps.PurchaseType in (select PurchaseType from DimPurchaseType  where PurchaseTypeKey = ").append(form.getFilterPurchaseTypeId()).append(")");
			}else{
				sql.append(" and cv.PurchaseTypeKey = ").append(form.getFilterPurchaseTypeId());
			}
			
		}
		sql.append(" group by parts.CommodityType ");
		sql.append("order by sum(bps)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsOrderQty4PieByBpsPurchaseType(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(bps),0) as bpsOrder,")
		.append("isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(bps),0) when 0 then 0 else case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(bps),0)*1.0/isnull(sum(UnshippedBacklog),1),2) end end as bpsRate,")
		.append("pt.PurchaseType as rowName,")
		.append("max(pt.PurchaseTypeKey) as rowValue, ")
		.append("'purchaseType' as type ")
		.append("from factdailysummaryofbps bps ")
		.append("inner join DimPurchaseType pt on pt.PurchaseTypeKey = bps.BPSPurchaseTypeKey ")
		.append(this.getBpsRemarkWhereCondition(form));
		sql.append(" and bps.globalCVKey is null ");
		if(StringUtils.isNotBlank(form.getFilterPurchaseTypeId())){
			sql.append(" and bps.BPSPurchaseTypeKey = ").append(form.getFilterPurchaseTypeId());
		}
		sql.append(" group by pt.PurchaseType ");
		sql.append("order by sum(bps)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getBpsOrderQty4PieBySubParts(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(bps),0) as bpsOrder,")
		.append("isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(bps),0) when 0 then 0 else case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(bps),0)*1.0/isnull(sum(UnshippedBacklog),1),2) end end as bpsRate,")
		.append("cv.CommodityValue as rowName,")
		.append("max(cv.GlobalCVKey) as rowValue ")
		.append("from factdailysummaryofbps bps ")
		.append("inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey ")
		.append(this.getBpsRemarkWhereCondition(form));
		sql.append(" and cv.CommodityTypeKey = ").append(form.getPartsId()).append(" ");
		if(StringUtils.isNotBlank(form.getFilterPurchaseTypeId())){
			if("region".equals(form.getDimension())){
				sql.append(" and bps.PurchaseType in (select PurchaseType from DimPurchaseType  where PurchaseTypeKey = ").append(form.getFilterPurchaseTypeId()).append(")");
			}else{
				sql.append(" and cv.PurchaseTypeKey = ").append(form.getFilterPurchaseTypeId());
			}
		}
		sql.append(" group by cv.CommodityValue ");
		sql.append("order by sum(bps)/sum(UnshippedBacklog) desc");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public BpsCrossMonth getTotalBpsOrderQty4Remark(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select isnull(sum(bps),0) as bpsOrder,")
		.append("isnull(sum(UnshippedBacklog),0) as unshippedOrder,")
		.append("case isnull(sum(bps),0) when 0 then 0 else case isnull(sum(UnshippedBacklog),0) when 0 then 1 else round(isnull(sum(bps),0)*1.0/isnull(sum(UnshippedBacklog),1),2) end end as bpsRate,")
		.append("from factdailysummaryofbps bps ")
		.append("where datediff(day, '"+form.getStartDate()+"', bps.versiondate) >= 0 ")
		.append("and datediff(day, bps.versiondate, '"+form.getEndDate()+"') >= 0 ");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("unshippedOrder", IntegerType.INSTANCE)
				.addScalar("bpsRate", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		List<BpsCrossMonth> bpsList = query.list();
		if(CollectionUtils.isNotEmpty(bpsList)){
			return bpsList.get(0);
		}else{
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getMaxProductBpsOrderQty4RemarkByRegion(
			SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select r.GeographyName as rowName,isnull(sum(bps),0) as bpsOrder from (");
		sql.append(" select regionkey,productkey,max(bps) as bps");
		sql.append(" from (");
		sql.append(" select bps.productkey,");
		sql.append(" SUM(bps) OVER (PARTITION BY bps.Commodity,bps.productkey,bps.regionkey) as bps, ");
		sql.append(" bps.regionkey");
		sql.append(" from factdailysummaryofbps bps");
		//sql.append(" inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey");
		sql.append(this.getBpsRemarkWhereCondition(form));
		sql.append(" ) bps");
		sql.append(" group by productkey,regionkey");
		sql.append(" ) as maxbps");
		sql.append(" inner join dimGeography r on r.GeographyKey = maxbps.regionkey");
		sql.append(" group by r.GeographyName");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getMaxProductFamilyBpsOrderQty4RemarkByRegion(
			SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select r.GeographyName as rowName,isnull(sum(bps),0) as bpsOrder from (");
		sql.append(" select regionkey,ProductFamily,max(bps) as bps");
		sql.append(" from (");
		sql.append(" select bps.ProductFamily,");
		sql.append(" SUM(bps) OVER (PARTITION BY bps.Commodity,bps.ProductFamily,bps.regionkey) as bps, ");
		sql.append(" bps.regionkey");
		sql.append(" from factdailysummaryofbps bps");
		//sql.append(" inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey");
		sql.append(this.getBpsRemarkWhereCondition(form));
		sql.append(" ) bps");
		sql.append(" group by ProductFamily,regionkey");
		sql.append(" ) as maxbps");
		sql.append(" inner join dimGeography r on r.GeographyKey = maxbps.regionkey");
		sql.append(" group by r.GeographyName");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getMaxProductBpsOrderQty4RemarkByODM(
			SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select isnull(odmKey,0) as rowValue,isnull(sum(bps),0) as bpsOrder from (");
//		sql.append(" select odmKey,productkey,max(bps) as bps");
		sql.append(" select odmKey,productFamily,max(bps) as bps");
		sql.append(" from (");
//		sql.append(" select bps.productkey,");
		sql.append(" select bps.productFamily,");
//		sql.append(" SUM(bps) OVER (PARTITION BY bps.Commodity,bps.productkey,bps.odmKey) as bps, ");
		sql.append(" SUM(bps) OVER (PARTITION BY bps.Commodity,bps.productFamily,bps.odmKey) as bps, ");
		sql.append(" bps.odmKey");
		sql.append(" from factdailysummaryofbps bps");
		//sql.append(" inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey");
		
		sql.append(this.getBpsRemarkWhereCondition(form));
		sql.append(" ) bps");
//		sql.append(" group by productkey,odmKey");
		sql.append(" group by productFamily,odmKey");
		sql.append(" ) as maxbps");
		sql.append(" group by odmKey");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getMaxProductBpsOrderQty4RemarkByProduct(
			SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select isnull(productkey,0) as rowValue,isnull(max(bps),0) as bpsOrder from (");
		sql.append(" select bps.productkey,");
		sql.append(" SUM(bps) OVER (PARTITION BY bps.Commodity,bps.productkey) as bps,");
		sql.append(" bps as bpsOrder");
		sql.append(" from factdailysummaryofbps bps");
		//sql.append(" inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey");
		sql.append(this.getBpsRemarkWhereCondition(form)).append(" and bps.ProductFamily is not null ");
		sql.append(" ) bps");
		sql.append(" group by productkey");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("rowValue", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BpsCrossMonth> getMaxProductFamilyBpsOrderQty4RemarkByProductFamily(
			SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select isnull(ProductFamily,0) as rowName,isnull(max(bps),0) as bpsOrder from (");
		sql.append(" select bps.ProductFamily,");
		sql.append(" SUM(bps) OVER (PARTITION BY bps.Commodity,bps.ProductFamily) as bps,");
		sql.append(" bps as bpsOrder");
		sql.append(" from factdailysummaryofbps bps");
		//sql.append(" inner join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey");
		sql.append(this.getBpsRemarkWhereCondition(form)).append(" and bps.ProductFamily is not null ");
		sql.append(" ) bps");
		sql.append(" group by ProductFamily");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("bpsOrder", IntegerType.INSTANCE)
				.addScalar("rowName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BpsCrossMonth.class));
		return query.list();
	}
	
	private StringBuilder generateBpsDetailFromAndWhereSql(SearchBpsForm form){
		StringBuilder sql = new StringBuilder();
		sql.append(" from FactDailyBPS bps");
		if(!"Day".equalsIgnoreCase(form.getFrequency())){
			sql.append(" inner join DimTime dt on bps.versiondate  = dt.FullDateAlternateKey");
		}
		sql.append(" left join DimODM dimODM on bps.ODMKey = dimODM.ODMKey");
		//sql.append(" left join DimMTM mtm on bps.MTMKey = mtm.MTMKey");
		sql.append(" left join DimProduct dimProduct on bps.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimGlobalCV cv on cv.GlobalCVKey = bps.globalCVKey");
		sql.append(" left join DimPurchaseType pt on pt.PurchaseTypeKey = cv.PurchaseTypeKey");
		sql.append(" left join DimPurchaseType bpsPt on bpsPt.PurchaseTypeKey = bps.BPSPurchaseTypeKey");
		sql.append(" left join DimCommodityType parts on parts.CommodityTypeKey = cv.CommodityTypeKey");
		sql.append(" left join DimGeography region on bps.RegionKey = region.GeographyKey");
		sql.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey");
		//sql.append(" left join DimGeography country on bps.CountryKey = country.GeographyKey");
		if("Day".equalsIgnoreCase(form.getFrequency())){
			sql.append(" where datediff(day, '"+form.getStartDate()+"', bps.versiondate) >= 0 ")
			.append("and datediff(day, bps.versiondate, '"+form.getEndDate()+"') >= 0 ");
		}else{
			sql.append(" where dt.bizYear*100+dt.bizMonth between ")
			   .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
			   .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		}
		if(StringUtils.isNotBlank(form.getRegionIds())){
			sql.append(" and bps.regionkey in (")
			.append("select GeographyKey from DimGeography where GeographyName in (").append(form.getRegionIds()).append(")) ");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sql.append(" and bps.regionkey in (")
			.append(" select r.GeographyKey from DimGeography r")
			.append(" inner join DimGeography g on r.ParentGeographyKey = g.GeographyKey where g.GeographyName in (").append(form.getGeoIds()).append(")) ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sql.append(" and bps.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sql.append(" and bps.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductFamilyIds())){
			sql.append(" and bps.ProductFamily in (").append(form.getProductFamilyIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getSubPartsId())){
			sql.append(" and bps.globalCVKey = ").append(form.getSubPartsId()).append(" ");
		}
		if(StringUtils.isNotBlank(form.getPurchaseTypeId())){
			sql.append(" and (cv.PurchaseTypeKey = ").append(form.getPurchaseTypeId());
			sql.append(" or (cv.PurchaseTypeKey is null and bps.BPSPurchaseTypeKey = ").append(form.getPurchaseTypeId()).append(")) ");
		}
		if(StringUtils.isNotBlank(form.getFilterPurchaseTypeId())){
			sql.append(" and (cv.PurchaseTypeKey = ").append(form.getFilterPurchaseTypeId()).append(" ");
			sql.append(" or (cv.PurchaseTypeKey is null and bps.BPSPurchaseTypeKey = ").append(form.getFilterPurchaseTypeId()).append(")) ");
		}
		if(StringUtils.isNotBlank(form.getPartsId())){
			sql.append(" and cv.PurchaseTypeKey is null and bps.BPSPurchaseTypeKey = ").append(form.getPartsId()).append(" ");
		}
		return sql;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BPSDetailView> getBpsDetail(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append("(select top ").append(form.getRowCount()).append(" * from ");
		sql.append("(select  top ").append(form.getEndRow());
		sql.append(" bps.id as id,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" geo.GeographyName as geo,");
		sql.append(" region.GeographyName as region,");
		//sql.append(" country.GeographyName as country,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		sql.append(" parts.CommodityType as parts,");
		sql.append(" cv.CommodityValue as commodity,");
		sql.append(" bps.PN as pn,");
		sql.append(" bps.Description as description,");
		sql.append(" bps.CVShortage as cvShortage,");
		sql.append(" bps.Classification as classification,");
		sql.append(" bps.supply as supply,");
		sql.append(" isnull(pt.PurchaseType,bpsPt.PurchaseType) as purchaseType ");
		//sql.append(" mtm.BOMNumberAlternateKey as pn,");
		//sql.append(" mtm.MTMEnglishDescription as itemDesc,");
		/*sql.append(" bps.POItem as poItem,");
		sql.append(" bps.PONumber as poNumber,");
		sql.append(" bps.POItem as itemNo,");
		sql.append(" bps.ImpactOrderQuantity as impactOrderQuantity,");
		sql.append(" bps.CVShortageQuantity as cvShortageQuantity");*/
		sql.append(this.generateBpsDetailFromAndWhereSql(form));
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(", id ").append(form.getSortType()).append(" ) t");
		}else{
			sql.append(" order by cvShortage ").append(form.getSortType());
			sql.append(" , id ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(", id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sql.append(" order by cvShortage ").append(form.getReversalSortType());
			sql.append(" , id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
				.append(", id ").append(form.getSortType());
		}else{
			sql.append(" order by cvShortage ").append(form.getSortType());
			sql.append(" , id ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("parts", StringType.INSTANCE)
				.addScalar("commodity", StringType.INSTANCE)
				.addScalar("purchaseType", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("cvShortage", StringType.INSTANCE)
				.addScalar("classification", StringType.INSTANCE)
				.addScalar("supply", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(BPSDetailView.class));
		return query.list();
	}
	
	@Override
	public long getBpsDetailCount(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(bps.id)");
		sql.append(this.generateBpsDetailFromAndWhereSql(form));
		Query query = getSession().createSQLQuery(sql.toString());
		Object result = query.uniqueResult();
		if(result != null){
			return Long.parseLong(result.toString());
		}else{
			return 0;
		}
	}
	
	@Override
	public long getUnshippedDetailCount(SearchBpsForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select  count(bps.id) ");
		sql.append(this.getOrderDetailFromAndWhere(form));
		Query query = getSession().createSQLQuery(sql.toString());
		Object result = query.uniqueResult();
		if(result != null){
			return Long.parseLong(result.toString());
		}else{
			return 0;
		}
	}
	private StringBuffer getOrderDetailFromAndWhere(SearchBpsForm form){
		StringBuffer sb = new StringBuffer();
		if("unshipped".equals(form.getSeriesName())){
			sb.append(" from FactDailyPSD bps  ");
		}else{
			sb.append(" from FactDailyOrderBPS bps  ");
		}
		    sb.append("inner join DimTime dt on bps.versiondate  = dt.FullDateAlternateKey ")
			  .append("left join DimODM dimODM on bps.ODMKey = dimODM.ODMKey  ")
			  .append("left join DimDetractor dimDetractor on bps.DetractorKey = dimDetractor.DetractorKey ")
			  .append("left join DimMTM mtm on bps.MTMKey = mtm.MTMKey  ")
			  .append("left join DimProduct dimProduct on mtm.ProductKey = dimProduct.ProductKey ")
			  .append("left join DimGeography region on bps.RegionKey = region.GeographyKey ")
			  .append("left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey ")
			  .append("left join DimGeography country on bps.CountryKey = country.GeographyKey ")
			  .append("where (bps.ShipDate>bps.VersionDate OR bps.ShipDate IS NULL) ");
		if("Day".equalsIgnoreCase(form.getFrequency())){
			sb.append("and bps.versiondate ='  ")
			  .append(form.getEndDate()+"'");
		}else{
			sb.append(" and dt.bizYear*100+dt.bizMonth between ")
			  .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
			  .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and geo.GeographyName in(").append(form.getGeoIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getRegionIds())){
			sb.append(" and region.GeographyName in(").append(form.getRegionIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and mtm.ProductKey in(").append(form.getProductIds()).append(") ");
		}
		//TODO 
		/*if(StringUtils.isNotBlank(form.getProductFamilyIds())){
			sb.append(" and bps.ProductFamily in(").append(form.getProductFamilyIds()).append(") ");
		}*/
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and bps.ODMKey in(").append(form.getOdmIds()).append(") ");
		}
		
		
		if(StringUtils.isNotBlank(form.getSubDimension())&& "region".equalsIgnoreCase(form.getSubDimension())){
			sb.append(" and region.GeographyName = '");
			sb.append(form.getSubDimensionKey()).append("'");
		}
		if(StringUtils.isNotBlank(form.getSubDimensionKey())&& "odm".equalsIgnoreCase(form.getSubDimension())){
			sb.append(" and bps.ODMKey = '");
			sb.append(form.getSubDimensionKey()).append("'");
		}
		if(StringUtils.isNotBlank(form.getSubDimensionKey())&& "product".equalsIgnoreCase(form.getSubDimension())){
			sb.append(" and mtm.ProductKey = '");
			sb.append(form.getSubDimensionKey()).append("'");
		}
		if(!"unshipped".equals(form.getSeriesName())){
			if(StringUtils.isNotBlank(form.getSubDimensionKey())&& "purchase".equalsIgnoreCase(form.getSubDimension())){
				if("region".equals(form.getDimension()) || "geo".equals(form.getDimension())){
					sb.append(" and bps.PurchaseType = '");
					sb.append(form.getSubDimensionKey()).append("' ");
				}else{
					sb.append(" and bps.GlobalCVKey in (select cv.GlobalCVKey from DimGlobalCV cv where cv.PurchaseTypeKey = '");
					sb.append(form.getSubDimensionKey()).append("') ");
				}
			}
			if(StringUtils.isNotBlank(form.getSubDimensionKey())&& "subParts".equalsIgnoreCase(form.getSubDimension())){
				sb.append(" and bps.GlobalCVKey = '");
				sb.append(form.getSubDimensionKey()).append("' ");
			}
		}
		return sb;
	}
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getOverviewOrderDetail(SearchBpsForm form) {
		StringBuffer sb = new StringBuffer();
		sb.append("select * from  ");
		sb.append("(select top ").append(form.getRowCount()).append(" * from ");
		sb.append("(select  top ").append(form.getEndRow());
		sb.append("	bps.id as id,dimODM.ODMEnglishName as odm,geo.GeographyName as geo,region.GeographyName as region,country.GeographyName as country, ");
		sb.append("dimProduct.ProductEnglishName as product, ")
		  .append("mtm.BOMNumberAlternateKey as pn,mtm.MTMEnglishDescription as itemDesc,bps.POItem as poItem,bps.PONumber as poNumber,bps.POItem as itemNo,bps.Quantity as qty, ")
		  .append("bps.OrderDate as orderDate,bps.RSDDate as rsd,bps.FPSDDate as fpsd,bps.ShipDate as shippedDate,bps.IsShipped as shipped, ")
		  .append("dimDetractor.Level1 as level1,dimDetractor.Level2 as level2 ,bps.LateReason2 as level3  ");
		sb.append(this.getOrderDetailFromAndWhere(form));
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sb.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(", id ").append(form.getSortType()).append(" ) t");
		}else{
			sb.append(" order by poNumber ").append(form.getSortType());
			sb.append(" , poItem ").append(form.getSortType());
			sb.append(" , id ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sb.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(", id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sb.append(" order by poNumber ").append(form.getReversalSortType());
			sb.append(" , poItem ").append(form.getReversalSortType());
			sb.append(" , id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sb.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
				.append(", id ").append(form.getSortType());
		}else{
			sb.append(" order by poNumber ").append(form.getSortType());
			sb.append(" , poItem ").append(form.getSortType());
			sb.append(" , id ").append(form.getSortType());
		}

		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("country", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE)
				.addScalar("itemDesc", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE)
				.addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE)
				.addScalar("orderDate", DateType.INSTANCE)
				.addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE)
				.addScalar("shipped", StringType.INSTANCE)
				.addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE)
				.addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FactDetailView> getOverviewFactDetail(SearchBpsForm form) {

		StringBuffer sb = new StringBuffer();
		sb.append("select * from  ");
		sb.append("(select top ").append(form.getRowCount()).append(" * from ");
		sb.append("(select  top ").append(form.getEndRow());
		sb.append("	id,isnull(bps.version,'') as version, isnull(bps.site,'') as site,isnull(bps.classification,'') as classification,")
		.append("isnull(bps.project1,'') as project1,isnull(bps.project2,'') as project2,isnull(bps.commodity,'') as commodity,")
		.append("isnull(bps.description,'') as description,isnull(bps.[p/n],'') as pn,isnull(bps.real_Order_Shortage,'') as realOrderShortage,")
		.append("isnull(bps.lastModifiedDate,'') as lastModifiedDate,isnull(bps.supply,'') as supply ");
		//sb.append(this.getOrderDetailFromAndWhere(form));
		sb.append(" from FactDailySourceBPS bps  ");
		if("Day".equalsIgnoreCase(form.getFrequency())){
			sb.append(" where bps.version ='  ")
			  .append(form.getEndDate()+"'");
		}else{
			sb.append("inner join DimTime dt on bps.version  = dt.FullDateAlternateKey ");
			sb.append(" where dt.bizYear*100+dt.bizMonth between ")
			  .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
			  .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sb.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(", id ").append(form.getSortType()).append(" ) t");
		}else{
			sb.append(" order by version ").append(form.getSortType());
			sb.append(" , id ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sb.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(", id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sb.append(" order by version ").append(form.getReversalSortType());
			sb.append(" , id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sb.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
				.append(", id ").append(form.getSortType());
		}else{
			sb.append(" order by version ").append(form.getSortType());
			sb.append(" , id ").append(form.getSortType());
		}

		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("version", StringType.INSTANCE)
				.addScalar("site", StringType.INSTANCE)
				.addScalar("classification", StringType.INSTANCE)
				.addScalar("project1", StringType.INSTANCE)
				.addScalar("project2", StringType.INSTANCE)
				.addScalar("commodity", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE)
				.addScalar("realOrderShortage", StringType.INSTANCE)
				.addScalar("lastModifiedDate", StringType.INSTANCE)
				.addScalar("supply", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FactDetailView.class));
		return query.list();
	
	}

	@Override
	public long getOverviewFactDetailCount(SearchBpsForm form) {
		StringBuffer sb = new StringBuffer();
		sb.append("select count(id) ");
		sb.append(" from FactDailySourceBPS bps  ");
		if("Day".equalsIgnoreCase(form.getFrequency())){
			sb.append(" where bps.version ='  ")
			  .append(form.getEndDate()+"'");
		}else{
			sb.append("inner join DimTime dt on bps.version  = dt.FullDateAlternateKey ");
			sb.append(" where dt.bizYear*100+dt.bizMonth between ")
			  .append(CalendarUtil.yearMonthConvert(form.getStartDate().substring(0, 7)))
			  .append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate().substring(0,7))).append(" ");
		}
		Query query = getSession().createSQLQuery(sb.toString());
		Object result = query.uniqueResult();
		if(result != null){
			return Long.parseLong(result.toString());
		}else{
			return 0;
		}
	}
}
