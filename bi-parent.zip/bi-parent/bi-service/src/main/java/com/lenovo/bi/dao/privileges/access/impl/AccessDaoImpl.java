package com.lenovo.bi.dao.privileges.access.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.dao.privileges.access.AccessDao;
import com.lenovo.bi.dto.privilege.PrivilegeTree;
import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.system.GroupPrivilege;
import com.lenovo.bi.model.system.RolePrivilege;
import com.lenovo.bi.view.system.access.GroupPrivilegeDetailView;
import com.lenovo.bi.view.system.access.RolesDetailView;
import com.lenovo.bi.view.system.dictionary.GroupDetailView;
import com.lenovo.bi.view.system.dictionary.PrivilegeDetailView;
import com.lenovo.common.model.PagerInformation;

@Repository
public class AccessDaoImpl extends HibernateBaseDaoImplBi implements AccessDao  {

	@SuppressWarnings("unchecked")
	@Override
	public List<PrivilegeTree> getRolePrivilegeTreeList(String roleId) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select privilege.id as id,")
			   .append("rp.roleId as roleId,")
			   .append("privilege.Code as resourceKey,")
			   .append("privilege.Name as name,")
			   .append("privilege.Type as type,")
			   .append("privilege.Description as description,")
			   .append("privilege.url as suburl,")
			   .append("privilege.ParentId as pId,")
			   .append("privilege.location as location,")
			   .append("privilege.layer as layer,")
			   .append("privilege.isModule as isModule")
			   .append(" from BI_Privilege privilege")
			   .append(" left join (")
			   .append("select rolePrivilege.BiPrivilegeId as privilegeId,rolePrivilege.PmsRoleId as roleId")
			   .append(" from BI_Role_Privilege rolePrivilege")
			   .append(" join BI_Role role on role.id = rolePrivilege.PmsRoleId")
			   .append(" where role.id = ").append(roleId).append(")rp")
			   .append(" on privilege.id = rp.privilegeId")
			   .append(" where type = 1 order by name");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE).addScalar("resourceKey", StringType.INSTANCE)
				.addScalar("name", StringType.INSTANCE).addScalar("type", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("roleId", StringType.INSTANCE)
				.addScalar("suburl", StringType.INSTANCE)
				.addScalar("pId", IntegerType.INSTANCE)
				.addScalar("location", IntegerType.INSTANCE)
				.addScalar("layer", IntegerType.INSTANCE)
				.addScalar("isModule", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PrivilegeTree.class));
		return query.list();
	}
	
	@Override
	public List<RolesDetailView> listRoles(DictSearchForm form, PagerInformation pagerInfo) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biRole.id as id,")
			   .append("biRole.Name as name,")
			   .append("biRole.description as description,")
			   .append("biRole.isBuiltIn as isBuiltIn,")
			   .append("biRole.CreatedBy as createdBy,")
			   .append("biRole.CreatedDate as createdDate")
			   .append( " from BI_Role biRole");
		if(form.getSearchBy() != null) {
			sBuffer.append(" where biRole.Name like '%").append(form.getSearchBy()).append("%'");
		}
		
		if(form.getSortColumn() != null && form.getSortType() != null) {
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("isBuiltIn", StringType.INSTANCE)
				.addScalar("createdBy", StringType.INSTANCE)
				.addScalar("createdDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(RolesDetailView.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}
	
	@Override
	public List<RolesDetailView> listRoles() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biRole.id as id,")
			   .append("biRole.Name as name,")
			   .append("biRole.description as description,")
			   .append("biRole.isBuiltIn as isBuiltIn,")
			   .append("biRole.CreatedBy as createdBy,")
			   .append("biRole.CreatedDate as createdDate")
			   .append( " from BI_Role biRole");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("isBuiltIn", StringType.INSTANCE)
				.addScalar("createdBy", StringType.INSTANCE)
				.addScalar("createdDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(RolesDetailView.class));
		
		return query.list();
	}

	
	@Override
	public int getRoleDetailCountByConditions(DictSearchForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(name)")
			   .append( " from BI_Role biRole");
		if(form.getSearchBy() != null) {
			sBuffer.append(" where biRole.Name like '%").append(form.getSearchBy()).append("%'");
		}
		Query query = getSession().createSQLQuery(sBuffer.toString());
		List<Integer> rs = query.list(); 
		if (rs.size() == 0){
			return 0;
		} else{
			return rs.get(0).intValue(); 
		}
	}

	@Override
	public void saveRolePrivilege(RolePrivilege[] rolePrivilegeArr) {
		
		deleteRolePrivilegeByRole(rolePrivilegeArr[0].getRoleId());
		for(int i=0; i<rolePrivilegeArr.length; i++) {
			this.getSession().save(rolePrivilegeArr[i]);
		}
		
	}
	
	@Override
	public void savePrivilegesForRole(Integer privilegeId,List<RolePrivilege> rolePrivilegeList) {

		deleteRolePrivilegeByPrivilege(privilegeId);
		for(RolePrivilege rolePrivilege : rolePrivilegeList) {
			this.getSession().save(rolePrivilege);
		}
	}

	@Override
	public List<RolePrivilege> listRolePrivilege(Integer roleId) {
		StringBuffer hql = new StringBuffer("from RolePrivilege where roleId = :roleId");
		Query query = getSession().createQuery(hql.toString());
		query.setInteger("roleId", roleId);
		List<RolePrivilege> list = query.list();
		
		return list;
	}
	
	@Override
	public List<RolePrivilege> listRolePrivileges() {
		StringBuffer hql = new StringBuffer("from RolePrivilege");
		Query query = getSession().createQuery(hql.toString());
		List<RolePrivilege> list = query.list();
		
		return list;
	}


	@Override
	public void deleteRolePrivilegeByRole(Integer roleId) {

		StringBuffer sql = new StringBuffer("delete from RolePrivilege rp where rp.roleId = " + roleId);
		Query q = getSession().createQuery(sql.toString());
		q.executeUpdate();
	}
	
	@Override
	public void deleteRolePrivilegeByPrivilege(Integer privilegeId) {

		StringBuffer sql = new StringBuffer("delete from RolePrivilege rp where rp.privilegeId = " + privilegeId);
		Query q = getSession().createQuery(sql.toString());
		q.executeUpdate();
	}

	@Override
	public List<PrivilegeDetailView> listPrivilegeDetailList(DictSearchForm form, PagerInformation pagerInfo) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select privilege.id as id,")
			   .append("privilege.Name as name,")
			   .append("parent.Name as category,")
			   .append("privilege.Code as code,")
			   .append("privilege.Type as type,")
			   .append("privilege.Description as description,")
			   .append("privilege.url as url,")
			   .append("privilege.ParentId as parentId")
			   .append( " from BI_Privilege privilege")
			   .append( " left join BI_Privilege parent")
			   .append( " on privilege.ParentId = parent.id")
			   .append(" where privilege.type= ").append(form.getType())
			   .append(" and parent.code != 'RolePrivileges'");
		if(form.getSearchBy() != null) {
			sBuffer.append(" and privilege.Name like '%").append(form.getSearchBy()).append("%'");
		}
		sBuffer.append(" order by privilege.Name");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("category", StringType.INSTANCE)
				.addScalar("code", StringType.INSTANCE)
				.addScalar("type", IntegerType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("url", StringType.INSTANCE)
				.addScalar("parentId", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PrivilegeDetailView.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}

	@Override
	public List<PrivilegeDetailView> listPrivilegesForRole() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select privilege.id as id,")
			   .append("privilege.Name as name,")
			   .append("parent.Name as category,")
			   .append("privilege.Code as code,")
			   .append("privilege.Type as type,")
			   .append("privilege.Description as description,")
			   .append("privilege.url as url,")
			   .append("privilege.ParentId as parentId")
			   .append( " from BI_Privilege privilege")
			   .append( " left join BI_Privilege parent")
			   .append( " on privilege.ParentId = parent.id")
			   .append(" where privilege.type=1 and parent.code != 'RolePrivileges'");
		
		sBuffer.append(" order by privilege.Name");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("category", StringType.INSTANCE)
				.addScalar("code", StringType.INSTANCE)
				.addScalar("type", IntegerType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("url", StringType.INSTANCE)
				.addScalar("parentId", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PrivilegeDetailView.class));
		
		return query.list();
	}

	
	@Override
	public int getPrivilegeDetailCountByConditions(DictSearchForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(privilege.code)")
			   .append( " from BI_Privilege privilege")
			   .append( " left join BI_Privilege parent")
			   .append( " on privilege.ParentId = parent.id")
			   .append(" where privilege.type=2 and parent.code != 'RolePrivileges'");
		if(form.getSearchBy() != null) {
			sBuffer.append(" and privilege.Name like '%").append(form.getSearchBy()).append("%'");
		}
		Query query = getSession().createSQLQuery(sBuffer.toString());
		List<Integer> rs = query.list(); 
		if (rs.size() == 0){
			return 0;
		} else{
			return rs.get(0).intValue(); 
		}
	}

	@Override
	public List<RolesDetailView> listRolesForPrivilege(Integer privilegeId) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biRole.id as id,")
			   .append("rp.privilegeName as hasThisPrivilege,")
			   .append("biRole.Name as name,")
			   .append("biRole.description as description,")
			   .append("biRole.isBuiltIn as isBuiltIn,")
			   .append("biRole.CreatedBy as createdBy,")
			   .append("biRole.CreatedDate as createdDate")
			   .append( " from BI_Role biRole")
			   .append(" left join (")
			   .append("select rolePrivilege.PmsRoleId as roleId,privilege.Name as privilegeName")
			   .append(" from BI_Role_Privilege rolePrivilege")
			   .append(" join BI_Privilege privilege on privilege.id = rolePrivilege.BiPrivilegeId")
			   .append(" where privilege.id = ").append(privilegeId).append(")rp")
			   .append(" on biRole.id = rp.roleId")
			   .append(" order by biRole.name")
			   ;
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("isBuiltIn", StringType.INSTANCE)
				.addScalar("createdBy", StringType.INSTANCE)
				.addScalar("createdDate", DateType.INSTANCE)
				.addScalar("hasThisPrivilege", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(RolesDetailView.class));
		
		return query.list();
	}

	@Override
	public List<PrivilegeTree> getGroupPrivilegeTreeList(String groupId) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select privilege.id as id,")
			   .append("gp.groupId as groupId,")
			   .append("privilege.Code as resourceKey,")
			   .append("privilege.Name as name,")
			   .append("privilege.Type as type,")
			   .append("privilege.Description as description,")
			   .append("privilege.url as suburl,")
			   .append("privilege.ParentId as pId,")
			   .append("privilege.location as location,")
			   .append("privilege.layer as layer,")
			   .append("privilege.isModule as isModule")
			   .append(" from BI_Privilege privilege")
			   .append(" left join (")
			   .append("select distinct groupPrivilege.BiPrivilegeId as privilegeId,groupPrivilege.GroupId as groupId")
			   .append(" from BI_Group_Privilege groupPrivilege")
			   .append(" join BI_Group biGroup on biGroup.id = groupPrivilege.GroupId")
			   .append(" where biGroup.id = ").append(groupId).append(")gp")
			   .append(" on privilege.id = gp.privilegeId")
			   .append(" where type = 2 order by name");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE).addScalar("resourceKey", StringType.INSTANCE)
				.addScalar("name", StringType.INSTANCE).addScalar("type", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("groupId", StringType.INSTANCE)
				.addScalar("suburl", StringType.INSTANCE)
				.addScalar("pId", IntegerType.INSTANCE)
				.addScalar("location", IntegerType.INSTANCE)
				.addScalar("layer", IntegerType.INSTANCE)
				.addScalar("isModule", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PrivilegeTree.class));
		return query.list();
	}
	
	@Override
	public List<PrivilegeTree> getUserPrivilegeTreeList(String userId) {
		StringBuffer sBuffer = new StringBuffer();
		//user privilege
		sBuffer.append("select privilege.id as id,")
			   .append("gp.groupId as groupId,")
			   .append("privilege.Code as resourceKey,")
			   .append("privilege.Name as name,")
			   .append("privilege.Type as type,")
			   .append("privilege.Description as description,")
			   .append("privilege.url as suburl,")
			   .append("privilege.ParentId as pId,")
			   .append("privilege.location as location,")
			   .append("privilege.layer as layer,")
			   .append("privilege.isModule as isModule")
			   .append(" from BI_Privilege privilege")
			   .append(" join (")
			   .append("select distinct groupPrivilege.BiPrivilegeId as privilegeId,groupPrivilege.GroupId as groupId")
			   .append(" from BI_Group_Privilege groupPrivilege")
			   .append(" join BI_Group biGroup on biGroup.id = groupPrivilege.GroupId")
			   .append(" join BI_Group_Member biGroupMember on biGroup.id = biGroupMember.GroupId")
			   .append(" join PASSPORT_User passportUser on passportUser.id = biGroupMember.MemberId")
			   .append(" where passportUser.userId = '").append(userId).append("')gp")
			   .append(" on privilege.id = gp.privilegeId")
			   .append(" where type = 2");
		sBuffer.append(" union ");
		//department privilege
		sBuffer.append("select privilege.id as id,")
			   .append("gp.groupId as groupId,")
			   .append("privilege.Code as resourceKey,")
			   .append("privilege.Name as name,")
			   .append("privilege.Type as type,")
			   .append("privilege.Description as description,")
			   .append("privilege.url as suburl,")
			   .append("privilege.ParentId as pId,")
			   .append("privilege.location as location,")
			   .append("privilege.layer as layer,")
			   .append("privilege.isModule as isModule")
			   .append(" from BI_Privilege privilege")
			   .append(" join (")
			   .append("select distinct groupPrivilege.BiPrivilegeId as privilegeId,groupPrivilege.GroupId as groupId")
			   .append(" from BI_Group_Privilege groupPrivilege")
			   .append(" join BI_Group biGroup on biGroup.id = groupPrivilege.GroupId")
			   .append(" join BI_Group_Member biGroupMember on biGroup.id = biGroupMember.GroupId")
			   .append(" join PASSPORT_Department department on department.id = biGroupMember.MemberId and biGroupMember.MemberType=2")
			   .append(" join PASSPORT_Department_User departmentUser on departmentUser.DepartmentId = department.id")
			   .append(" join PASSPORT_User passportUser on passportUser.id = departmentUser.UserId")
			   .append(" where passportUser.userId = '").append(userId).append("')gp")
			   .append(" on privilege.id = gp.privilegeId")
			   .append(" where type = 2");
		sBuffer.append(" union ");
		//business unit privilege
		sBuffer.append("select privilege.id as id,")
			   .append("gp.groupId as groupId,")
			   .append("privilege.Code as resourceKey,")
			   .append("privilege.Name as name,")
			   .append("privilege.Type as type,")
			   .append("privilege.Description as description,")
			   .append("privilege.url as suburl,")
			   .append("privilege.ParentId as pId,")
			   .append("privilege.location as location,")
			   .append("privilege.layer as layer,")
			   .append("privilege.isModule as isModule")
			   .append(" from BI_Privilege privilege")
			   .append(" join (")
			   .append("select distinct groupPrivilege.BiPrivilegeId as privilegeId,groupPrivilege.GroupId as groupId")
			   .append(" from BI_Group_Privilege groupPrivilege")
			   .append(" join BI_Group biGroup on biGroup.id = groupPrivilege.GroupId")
			   .append(" join BI_Group_Member biGroupMember on biGroup.id = biGroupMember.GroupId")
			   .append(" join PASSPORT_BusinessUnit bu on bu.id = biGroupMember.MemberId and biGroupMember.MemberType=1")
			   .append(" join PASSPORT_Department department on department.BusinessUnitId = bu.id")
			   .append(" join PASSPORT_Department_User departmentUser on departmentUser.DepartmentId = department.id")
			   .append(" join PASSPORT_User passportUser on passportUser.id = departmentUser.UserId")
			   .append(" where passportUser.userId = '").append(userId).append("')gp")
			   .append(" on privilege.id = gp.privilegeId")
			   .append(" where type = 2");
		sBuffer.append(" union ");
		//company privilege
		sBuffer.append("select privilege.id as id,")
			   .append("gp.groupId as groupId,")
			   .append("privilege.Code as resourceKey,")
			   .append("privilege.Name as name,")
			   .append("privilege.Type as type,")
			   .append("privilege.Description as description,")
			   .append("privilege.url as suburl,")
			   .append("privilege.ParentId as pId,")
			   .append("privilege.location as location,")
			   .append("privilege.layer as layer,")
			   .append("privilege.isModule as isModule")
			   .append(" from BI_Privilege privilege")
			   .append(" join (")
			   .append("select distinct groupPrivilege.BiPrivilegeId as privilegeId,groupPrivilege.GroupId as groupId")
			   .append(" from BI_Group_Privilege groupPrivilege")
			   .append(" join BI_Group biGroup on biGroup.id = groupPrivilege.GroupId")
			   .append(" join BI_Group_Member biGroupMember on biGroup.id = biGroupMember.GroupId")
			   .append(" join PASSPORT_Company company on company.id = biGroupMember.MemberId and biGroupMember.MemberType=0")
			   .append(" join PASSPORT_BusinessUnit bu on bu.CompanyId = company.id")
			   .append(" join PASSPORT_Department department on department.BusinessUnitId = bu.id")
			   .append(" join PASSPORT_Department_User departmentUser on departmentUser.DepartmentId = department.id")
			   .append(" join PASSPORT_User passportUser on passportUser.id = departmentUser.UserId")
			   .append(" where passportUser.userId = '").append(userId).append("')gp")
			   .append(" on privilege.id = gp.privilegeId")
			   .append(" where type = 2");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE).addScalar("resourceKey", StringType.INSTANCE)
				.addScalar("name", StringType.INSTANCE).addScalar("type", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("groupId", StringType.INSTANCE)
				.addScalar("suburl", StringType.INSTANCE)
				.addScalar("pId", IntegerType.INSTANCE)
				.addScalar("location", IntegerType.INSTANCE)
				.addScalar("layer", IntegerType.INSTANCE)
				.addScalar("isModule", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PrivilegeTree.class));
		return query.list();
	}

	@Override
	public void saveGroupPrivilege(GroupPrivilege[] groupPrivilegeArr,String groupId) {
		
		if(groupPrivilegeArr.length > 0)
			deleteGroupPrivilegeByGroup(groupPrivilegeArr[0].getGroupId());
		else
			deleteGroupPrivilegeByGroup(Integer.parseInt(groupId));
		for(int i=0; i<groupPrivilegeArr.length; i++) {
			this.getSession().save(groupPrivilegeArr[i]);
		}
		
	}
	
	@Override
	public void deleteGroupPrivilegeByGroup(Integer groupId) {

		StringBuffer sql = new StringBuffer("delete from GroupPrivilege gp where gp.groupId = " + groupId);
		Query q = getSession().createQuery(sql.toString());
		q.executeUpdate();
	}

	@Override
	public List<GroupDetailView> listGroups() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biGroup.id as id,")
			   .append("biGroup.Name as name,")
			   .append("biGroup.description as description,")
			   .append("biGroup.IsActive as isActive,")
			   .append("biGroup.CreatedBy as createdBy,")
			   .append("biGroup.CreatedDate as createdDate")
			   .append( " from BI_Group biGroup");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("isActive", StringType.INSTANCE)
				.addScalar("createdBy", StringType.INSTANCE)
				.addScalar("createdDate", DateType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GroupDetailView.class));
		
		return query.list();
	}
	
	@Override
	public List<String> listGroupsForExcel() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biGroup.Name as name")
			   .append( " from BI_Group biGroup");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return query.list();
	}

	@Override
	public List<GroupPrivilege> listGroupPrivileges() {
		StringBuffer hql = new StringBuffer("from GroupPrivilege");
		Query query = getSession().createQuery(hql.toString());
		List<GroupPrivilege> list = query.list();
		
		return list;
	}
	
	@Override
	public List<GroupPrivilegeDetailView> listGroupPrivilegesForExcel(DictSearchForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biGroup.id as id,")
			   .append("rp.privilegeName as hasThisPrivilege,")
			   .append("rp.privilegeName as privilegeName,")
			   .append("biGroup.Name as groupName,")
			   .append("biGroup.description as description")
			   .append( " from BI_Group biGroup")
			   .append(" left join (")
			   .append("select groupPrivilege.GroupId as groupId,privilege.Name as privilegeName")
			   .append(" from BI_Group_Privilege groupPrivilege")
			   .append(" left join BI_Privilege privilege on privilege.id = groupPrivilege.BiPrivilegeId").append(")rp")
			   .append(" on biGroup.id = rp.groupId")
			   .append(" order by biGroup.name")
			   ;
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("privilegeName", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("groupName", StringType.INSTANCE)
				.addScalar("hasThisPrivilege", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GroupPrivilegeDetailView.class));
		
		return query.list();
	}

	@Override
	public List<PrivilegeDetailView> listPrivilegesForGroup() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select privilege.id as id,")
			   .append("privilege.Name as name,")
			   .append("parent.Name as category,")
			   .append("privilege.Code as code,")
			   .append("privilege.Type as type,")
			   .append("privilege.Description as description,")
			   .append("privilege.url as url,")
			   .append("privilege.ParentId as parentId")
			   .append( " from BI_Privilege privilege")
			   .append( " left join BI_Privilege parent")
			   .append( " on privilege.ParentId = parent.id")
			   .append(" where privilege.type=2 and parent.code != 'DepartmentPrivileges'");
		
		sBuffer.append(" order by privilege.Name");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("category", StringType.INSTANCE)
				.addScalar("code", StringType.INSTANCE)
				.addScalar("type", IntegerType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("url", StringType.INSTANCE)
				.addScalar("parentId", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PrivilegeDetailView.class));
		
		return query.list();
	}
	
	@Override
	public List<GroupDetailView> listGroupsForPrivilege(Integer privilegeId) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biGroup.id as id,")
			   .append("rp.privilegeName as hasThisPrivilege,")
			   .append("biGroup.Name as name,")
			   .append("biGroup.description as description,")
			   .append("biGroup.isActive as isActive,")
			   .append("biGroup.CreatedBy as createdBy,")
			   .append("biGroup.CreatedDate as createdDate")
			   .append( " from BI_Group biGroup")
			   .append(" left join (")
			   .append("select groupPrivilege.GroupId as groupId,privilege.Name as privilegeName")
			   .append(" from BI_Group_Privilege groupPrivilege")
			   .append(" join BI_Privilege privilege on privilege.id = groupPrivilege.BiPrivilegeId")
			   .append(" where privilege.id = ").append(privilegeId).append(")rp")
			   .append(" on biGroup.id = rp.groupId")
			   .append(" order by biGroup.name")
			   ;
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("isActive", StringType.INSTANCE)
				.addScalar("createdBy", StringType.INSTANCE)
				.addScalar("createdDate", DateType.INSTANCE)
				.addScalar("hasThisPrivilege", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GroupDetailView.class));
		
		return query.list();
	}
	
	@Override
	public void savePrivilegesForGroup(Integer privilegeId,List<GroupPrivilege> groupPrivilegeList) {

		deleteRolePrivilegeByPrivilege(privilegeId);
		for(GroupPrivilege groupPrivilege : groupPrivilegeList) {
			this.getSession().save(groupPrivilege);
		}
	}
	
	@Override
	public void deleteGroupPrivilegeByPrivilege(Integer privilegeId) {

		StringBuffer sql = new StringBuffer("delete from GroupPrivilege gp where gp.privilegeId = " + privilegeId);
		Query q = getSession().createQuery(sql.toString());
		q.executeUpdate();
	}

}
