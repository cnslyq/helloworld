package com.lenovo.bi.view.npi.chart.line;

public class LineChartConfig {
	
    private String yaxisname;
	private String bgcolor;
	private String numvdivlines;
	private String divlinealpha;
	private String labelpadding;
	private String yaxisvaluespadding;
	private String showvalues;
	private String rotatevalues;
	private String valueposition;
	private String canvaspadding;
	private String showAlternateHGridColor;
	private String numbersuffix;
	private String vDivLineIsDashed;
	
	public LineChartConfig(){
		this.yaxisname =  "Units";
		this.bgcolor="F7F7F7, E9E9E9";
		//this.numvdivlines="7";
		this.divlinealpha="30";
		this.labelpadding = "10";
		this.yaxisvaluespadding= "10";
		this.showvalues="1";
		this.rotatevalues="0";
		this.valueposition="Below";
		this.canvaspadding="10";
	}

	public String getYaxisname() {
		return yaxisname;
	}

	public void setYaxisname(String yaxisname) {
		this.yaxisname = yaxisname;
	}

	public String getBgcolor() {
		return bgcolor;
	}

	public void setBgcolor(String bgcolor) {
		this.bgcolor = bgcolor;
	}

	public String getNumvdivlines() {
		return numvdivlines;
	}

	public void setNumvdivlines(String numvdivlines) {
		this.numvdivlines = numvdivlines;
	}

	public String getDivlinealpha() {
		return divlinealpha;
	}

	public void setDivlinealpha(String divlinealpha) {
		this.divlinealpha = divlinealpha;
	}

	public String getLabelpadding() {
		return labelpadding;
	}

	public void setLabelpadding(String labelpadding) {
		this.labelpadding = labelpadding;
	}

	public String getYaxisvaluespadding() {
		return yaxisvaluespadding;
	}

	public void setYaxisvaluespadding(String yaxisvaluespadding) {
		this.yaxisvaluespadding = yaxisvaluespadding;
	}

	public String getShowvalues() {
		return showvalues;
	}

	public void setShowvalues(String showvalues) {
		this.showvalues = showvalues;
	}

	public String getRotatevalues() {
		return rotatevalues;
	}

	public void setRotatevalues(String rotatevalues) {
		this.rotatevalues = rotatevalues;
	}

	public String getValueposition() {
		return valueposition;
	}

	public void setValueposition(String valueposition) {
		this.valueposition = valueposition;
	}

	public String getCanvaspadding() {
		return canvaspadding;
	}

	public void setCanvaspadding(String canvaspadding) {
		this.canvaspadding = canvaspadding;
	}

	public String getShowAlternateHGridColor() {
		return showAlternateHGridColor;
	}

	public void setShowAlternateHGridColor(String showAlternateHGridColor) {
		this.showAlternateHGridColor = showAlternateHGridColor;
	}

	public String getNumbersuffix() {
		return numbersuffix;
	}

	public void setNumbersuffix(String numbersuffix) {
		this.numbersuffix = numbersuffix;
	}

	public String getvDivLineIsDashed() {
		return vDivLineIsDashed;
	}

	public void setvDivLineIsDashed(String vDivLineIsDashed) {
		this.vDivLineIsDashed = vDivLineIsDashed;
	}
	
}
