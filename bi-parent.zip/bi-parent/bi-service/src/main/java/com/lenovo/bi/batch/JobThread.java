package com.lenovo.bi.batch;

import java.util.Date;

import com.lenovo.bi.util.CalendarUtil;

/**
 * 
 * 
 * @author henry_lian
 *
 */
public class JobThread extends Thread {

	private AdhocTtvWeeklyBatch adhocTtvWeeklyBatch;
	
	private Date versionDate;
	
	@Override
	public void run() {
		//adhocTtvWeeklyBatch.setVersionDate(versionDate);
		//adhocTtvWeeklyBatch.runBatch();
		Date thisMonday = CalendarUtil.getMonday();
		while(versionDate.compareTo(thisMonday) <= 0){
			adhocTtvWeeklyBatch.setVersionDate(versionDate);
			adhocTtvWeeklyBatch.runBatch();
			versionDate = CalendarUtil.getMondayDateByWeeks(versionDate, 1);
		}
		super.run();
	}

	public JobThread(AdhocTtvWeeklyBatch adhocTtvWeeklyBatch, Date versionDate) {
		super();
		this.adhocTtvWeeklyBatch = adhocTtvWeeklyBatch;
		this.versionDate = versionDate;
	}

}
