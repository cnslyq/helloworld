package com.lenovo.bi.service.sc;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FaOverViewChartData;
import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.sc.fa.LTFCDetailView;


public interface LTFCService {
	public ColumnChartView getOverviewChart(SearchFaForm form) throws ParseException;
	
	public List<FaOverViewChartData> getOverviewOverall(SearchOtsForm form);
	
	public ColumnChartView getRemarkChart(SearchFaForm form) throws ParseException;
	
	public List<KeyNameObject> fetchTop15SubDimensions(SearchOtsForm form);
	
	public PieChartView getOverviewPieChart(SearchFaForm form) throws ParseException;
	//dashboard orderDetail
	public Map<String,Object> getOverviewOrderDetail(SearchFaForm form) throws ParseException;
	
	public List<LTFCDetailView> getFADetailView(SearchFaForm form);
	
	public Map<String,Object> getLTFCRemarkOrderDetail(SearchFaForm form) throws ParseException;
	
	public String getPoorProduct(SearchFaForm form) throws ParseException;
	
	public PieChartView getCrossMonthPieChart(SearchFaForm form) throws ParseException;

	PieChartView getDashboardPieChart(SearchFaForm form) throws ParseException;
}
