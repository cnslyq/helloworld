package com.lenovo.bi.dao.sc;

import java.util.List;
import java.util.Map;

import com.lenovo.bi.form.sc.sbb.SearchSBBForm;
import com.lenovo.bi.view.sc.sbb.SBBDetailView;

public interface SBBDao {
	public List<SBBDetailView> getSBBDetail(SearchSBBForm form);
	public int getSBBDetailCount(SearchSBBForm form);
	public void updateSBB(Map<String, Object> map);
	public List<SBBDetailView> getSBBDetailExport(SearchSBBForm form);
}
