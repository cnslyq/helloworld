package com.lenovo.bi.service.common.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.npi.UserDao;
import com.lenovo.bi.model.User;
import com.lenovo.bi.service.common.UserService;
@Service
public class UserServiceImpl implements UserService {
	@Inject
	private UserDao userDao;
	
	@Override
	public User getUserById(String userId) {
		return userDao.getUserById(userId);
	}

}
