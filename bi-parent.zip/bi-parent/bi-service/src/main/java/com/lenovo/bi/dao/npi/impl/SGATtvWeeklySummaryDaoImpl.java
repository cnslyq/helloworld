package com.lenovo.bi.dao.npi.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.model.SGATtvWeeklySummary;
import com.lenovo.bi.util.CalendarUtil;

@Repository
public class SGATtvWeeklySummaryDaoImpl extends HibernateBaseDaoImplBi<SGATtvWeeklySummary> {

	public List<SGATtvWeeklySummary> getNpiWeeklySummary(int pmsWaveId) {
		return list("from SGATtvWeeklySummary where pmsWaveId = :pmsWaveId order by targetDate", "pmsWaveId", new Integer[] { pmsWaveId });
	}

	@SuppressWarnings("unchecked")
	public List<SGATtvWeeklySummary> getNpiWeeklySummary(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		StringBuffer hql = new StringBuffer("from SGATtvWeeklySummary where pmsWaveId = :pmsWaveId and datediff(day, :startDate, targetDate) >= 0 ");
		if (versionDate == null) {
			versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins());
		}
		hql.append("and :versionDate = versionDate ");
		hql.append("and datediff(day, targetDate, :endDate) >= 0 order by targetDate ");
		Query query = getSession().createQuery(hql.toString());
		if (versionDate != null)
			query.setParameter("versionDate", versionDate);
		query.setParameter("pmsWaveId", pmsWaveId);
		query.setParameter("startDate", startDate);
		query.setParameter("endDate", endDate);

		return (List<SGATtvWeeklySummary>) query.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<SGATtvWeeklySummary> getLastNpiWeeklySummary(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		StringBuffer hql = new StringBuffer("from SGATtvWeeklySummary s where pmsWaveId = :pmsWaveId and datediff(day, :startDate, targetDate) >= 0 ");
		if (versionDate == null) {
			versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins());
		}
		hql.append(" and versionDate in (select max(versionDate) from SGATtvWeeklySummary where s.targetDate = targetDate and s.pmsWaveId = pmsWaveId ")
		.append(" and datediff(day, :versionDate, versionDate) <= 0) ");

		hql.append("and datediff(day, targetDate, :endDate) >= 0 order by targetDate ");
		Query query = getSession().createQuery(hql.toString());
		if (versionDate != null)
			query.setParameter("versionDate", versionDate);
		query.setParameter("pmsWaveId", pmsWaveId);
		query.setParameter("startDate", startDate);
		query.setParameter("endDate", endDate);

		return (List<SGATtvWeeklySummary>) query.list();
	}

	public void deleteTtvWeeklySummaryAfter(int pmsWaveId, Date targetDate) {
		targetDate = CalendarUtil.adjustTimeToMidnight(targetDate);

		StringBuffer hql = new StringBuffer("delete from SGATtvWeeklySummary where pmsWaveId = :pmsWaveId ");

		if (targetDate != null) {
			hql.append("and targetDate >= :targetDate");
		}

		Query query = getSession().createQuery(hql.toString());
		query.setParameter("pmsWaveId", pmsWaveId);

		if (targetDate != null) {
			query.setParameter("targetDate", targetDate);
		}

		query.executeUpdate();
	}

	public void deleteSgaTtvWeeklySummaryByWaveId(int pmsWaveId, Date versionDate){
		StringBuffer hql = new StringBuffer("delete from SGATtvWeeklySummary where pmsWaveId = :pmsWaveId ");
		hql.append(" and datediff(day, versionDate, :versionDate) = 0");
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("pmsWaveId", pmsWaveId);
		query.setParameter("versionDate", versionDate);
		query.executeUpdate();
	}
	public void deleteTtvWeeklySummaryForVersionDate(Date versionDate) {
		deleteDataForVersionDate("SGATtvWeeklySummary", versionDate);
	}
	@Deprecated
	public void clearTtvWeeklySummary() {
		getSession().createQuery("delete from SGATtvWeeklySummary ").executeUpdate();
	}

	public SGATtvWeeklySummary getPreviousWeeklySummary(int pmsWaveId, Date targetDate) {
		StringBuffer hql = new StringBuffer("from SGATtvWeeklySummary where pmsWaveId = :pmsWaveId and datediff(week, targetDate, :targetDate) = 1 ");

		Query query = getSession().createQuery(hql.toString());
		query.setParameter("pmsWaveId", pmsWaveId);
		query.setParameter("targetDate", targetDate);

		@SuppressWarnings("unchecked")
		List<SGATtvWeeklySummary> list = query.list();

		if (list.size() > 0) {
			return list.get(0);
		}

		return null;
	}

}
