package com.lenovo.bi.dao.npi;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.NPIWaveInfo;
import com.lenovo.bi.dto.ProductKeyPmsWaveId;
/**
 * the dao is meant to get project wave related info from Data warehouse
 * 
 * @author henry_lian
 *
 */
public interface NPIProjectWaveDao {

	public List<ProductKeyPmsWaveId> getProductKeyPmsWaveIdList();
	
	public String getProductKeyByPmsWaveId(Integer waveId);
	
	public List<NPIWaveInfo> getProjectDetail(Date versionDate);
}
