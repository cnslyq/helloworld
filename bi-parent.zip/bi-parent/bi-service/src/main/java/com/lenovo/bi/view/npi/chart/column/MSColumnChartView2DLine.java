package com.lenovo.bi.view.npi.chart.column;

import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;

public class MSColumnChartView2DLine {
	private ColumnChartInformation chartInfo;
	
	private Categories categories;
	
	private List dataSet;
	
	//private List<DataSetParent> dataSetList;
	
	public Categories getCategories() {
		return categories;
	}
	
	public List getDataSet() {
		return dataSet;
	}

	@JsonProperty("dataset")
	public void setDataSet(List dataSet) {
		this.dataSet = dataSet;
	}

	@JsonProperty("categories")
	public void setCategories(Categories categories) {
		this.categories = categories;
	}
	
	public ColumnChartInformation getChartInfo() {
		return chartInfo;
	}
	
	@JsonProperty("chart")
	public void setChartInfo(ColumnChartInformation chartInfo) {
		this.chartInfo = chartInfo;
	}
	
	public MSColumnChartView2DLine(){
		chartInfo = new ColumnChartInformation();
	}
}
