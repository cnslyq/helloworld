package com.lenovo.bi.view.npi.chart.pie;

import com.lenovo.bi.util.SysConfig;

public class PieChartInformation {
	private String basefontsize;
	private String startingAngle;
	private String use3DLighting;
	private String pieYScale;
	private String pieRadius;
	private String pieSliceDepth;
	private String enableSmartLabels;
	private String showPercentValues;
	private String showLabels;
	private String labelDistance;
	private String showLegend;
	private String legendPosition;
	private String reverseLegend;
	private String interactiveLegend;
	private String legendIconScale;
	private String slicingDistance;
	private String manageLabelOverflow;
	private String useEllipsesWhenOverflow;
	private String decimals;
	private String showPercentInToolTip;
	private String showValues;
	private String skipOverlapLabels;
	private String numbersuffix;
	public PieChartInformation() {
		this.basefontsize = SysConfig.PIE_CHART_BASEFONTSIZE;
		this.startingAngle = SysConfig.PIE_CHART_STARTINGANGLE;
		this.use3DLighting = SysConfig.PIE_CHART_USE3DLIGHTING;
		this.pieYScale = SysConfig.PIE_CHART_PIEYSCALE;
		this.pieRadius = SysConfig.PIE_CHART_PIERADIUS;
		this.pieSliceDepth = SysConfig.PIE_CHART_PIESLICEDEPTH;
		this.enableSmartLabels = SysConfig.PIE_CHART_ENABLESMARTLABELS;
		this.showPercentValues = SysConfig.PIE_CHART_SHOWPERCENTVALUES;
		this.showLabels = SysConfig.PIE_CHART_SHOWLABELS;
		this.labelDistance = SysConfig.PIE_CHART_LABELDISTANCE;
		this.showLegend = SysConfig.PIE_CHART_SHOWLEGEND;
		this.legendPosition = SysConfig.PIE_CHART_LEGENDPOSITION;
		this.reverseLegend = SysConfig.PIE_CHART_REVERSELEGEND;
		this.interactiveLegend = SysConfig.PIE_CHART_INTERACTIVELEGEND;
		this.legendIconScale = SysConfig.PIE_CHART_LEGENDICONSCALE;
		this.slicingDistance = SysConfig.PIE_CHART_SLICINGDISTANCE;
		this.manageLabelOverflow = SysConfig.PIE_CHART_MANAGELABELOVERFLOW;
		this.useEllipsesWhenOverflow = "1";
		this.decimals = "2";
		this.showPercentInToolTip = "1";
		this.showValues = "1";
		this.skipOverlapLabels = "1";
		this.numbersuffix = "";
	}
	public String getNumbersuffix() {
		return numbersuffix;
	}


	public void setNumbersuffix(String numbersuffix) {
		this.numbersuffix = numbersuffix;
	}


	public String getDecimals() {
		return decimals;
	}


	public void setDecimals(String decimals) {
		this.decimals = decimals;
	}


	public String getBasefontsize() {
		return basefontsize;
	}

	public void setBasefontsize(String basefontsize) {
		this.basefontsize = basefontsize;
	}

	public String getStartingAngle() {
		return startingAngle;
	}

	public void setStartingAngle(String startingAngle) {
		this.startingAngle = startingAngle;
	}

	public String getUse3DLighting() {
		return use3DLighting;
	}

	public void setUse3DLighting(String use3dLighting) {
		use3DLighting = use3dLighting;
	}

	public String getPieYScale() {
		return pieYScale;
	}

	public void setPieYScale(String pieYScale) {
		this.pieYScale = pieYScale;
	}

	public String getPieRadius() {
		return pieRadius;
	}

	public void setPieRadius(String pieRadius) {
		this.pieRadius = pieRadius;
	}

	public String getPieSliceDepth() {
		return pieSliceDepth;
	}

	public void setPieSliceDepth(String pieSliceDepth) {
		this.pieSliceDepth = pieSliceDepth;
	}

	public String getEnableSmartLabels() {
		return enableSmartLabels;
	}

	public void setEnableSmartLabels(String enableSmartLabels) {
		this.enableSmartLabels = enableSmartLabels;
	}

	public String getShowPercentValues() {
		return showPercentValues;
	}

	public void setShowPercentValues(String showPercentValues) {
		this.showPercentValues = showPercentValues;
	}

	public String getShowLabels() {
		return showLabels;
	}

	public void setShowLabels(String showLabels) {
		this.showLabels = showLabels;
	}

	public String getLabelDistance() {
		return labelDistance;
	}

	public void setLabelDistance(String labelDistance) {
		this.labelDistance = labelDistance;
	}

	public String getShowLegend() {
		return showLegend;
	}

	public void setShowLegend(String showLegend) {
		this.showLegend = showLegend;
	}

	public String getLegendPosition() {
		return legendPosition;
	}

	public void setLegendPosition(String legendPosition) {
		this.legendPosition = legendPosition;
	}

	public String getReverseLegend() {
		return reverseLegend;
	}

	public void setReverseLegend(String reverseLegend) {
		this.reverseLegend = reverseLegend;
	}

	public String getInteractiveLegend() {
		return interactiveLegend;
	}

	public void setInteractiveLegend(String interactiveLegend) {
		this.interactiveLegend = interactiveLegend;
	}

	public String getLegendIconScale() {
		return legendIconScale;
	}

	public void setLegendIconScale(String legendIconScale) {
		this.legendIconScale = legendIconScale;
	}

	public String getSlicingDistance() {
		return slicingDistance;
	}

	public void setSlicingDistance(String slicingDistance) {
		this.slicingDistance = slicingDistance;
	}

	public String getManageLabelOverflow() {
		return manageLabelOverflow;
	}

	public void setManageLabelOverflow(String manageLabelOverflow) {
		this.manageLabelOverflow = manageLabelOverflow;
	}

	public String getUseEllipsesWhenOverflow() {
		return useEllipsesWhenOverflow;
	}

	public void setUseEllipsesWhenOverflow(String useEllipsesWhenOverflow) {
		this.useEllipsesWhenOverflow = useEllipsesWhenOverflow;
	}


	public String getShowPercentInToolTip() {
		return showPercentInToolTip;
	}


	public void setShowPercentInToolTip(String showPercentInToolTip) {
		this.showPercentInToolTip = showPercentInToolTip;
	}


	public String getShowValues() {
		return showValues;
	}


	public void setShowValues(String showValues) {
		this.showValues = showValues;
	}


	public String getSkipOverlapLabels() {
		return skipOverlapLabels;
	}


	public void setSkipOverlapLabels(String skipOverlapLabels) {
		this.skipOverlapLabels = skipOverlapLabels;
	}
}
