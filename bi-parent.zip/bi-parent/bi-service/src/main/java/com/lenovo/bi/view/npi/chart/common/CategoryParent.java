package com.lenovo.bi.view.npi.chart.common;

public class CategoryParent {

	
}
