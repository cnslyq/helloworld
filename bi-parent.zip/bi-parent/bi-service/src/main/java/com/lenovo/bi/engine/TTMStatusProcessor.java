package com.lenovo.bi.engine;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.service.common.MasterDataService;
@Component 
@Order(1)
public class TTMStatusProcessor implements TTMKPIProcessor {

	@Autowired
	private MasterDataService masterDataService;
	
	@Override
	public void process(ProjectSummary ps, Date versionDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String todayStr = sdf.format(new Date())  ;
		Date today = null;
		try {
			today = sdf.parse(todayStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int grace = masterDataService.getThresholdByName(Threshold.TTM_STATUS_GRACE.name()).intValue();
		if (ps.getPhaseNumber() == null || ps.getTtmTargetDate() == null){
			ps.setTtmStatus(Status.NA.name());
		} else if (ps.getTtmSignOffDate() != null){
			if(Days.daysBetween(new DateTime(ps.getTtmTargetDate()), new DateTime(ps.getTtmSignOffDate())).getDays() <= grace){
				ps.setTtmStatus(Status.Success.name());
			} else{
				ps.setTtmStatus(Status.Fail.name());
			}
		} else{
			if(Days.daysBetween(new DateTime(ps.getTtmTargetDate()), new DateTime(today)).getDays() <= grace){
				ps.setTtmStatus(Status.In_Progress.name());
			} else{
				ps.setTtmStatus(Status.Fail.name());
			}
		}
	}

}
