package com.lenovo.bi.service.system;

import com.lenovo.bi.view.BINavigationView;

public interface NavigationService {

	public BINavigationView getBINavigationView();
}
