package com.lenovo.bi.dao.sc;

import java.util.List;

import com.lenovo.bi.dto.BpsCrossMonth;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.form.sc.bps.SearchBpsForm;
import com.lenovo.bi.view.sc.bps.BPSDetailView;
import com.lenovo.bi.view.sc.bps.FactDetailView;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;


public interface BPSDao {
	
	public List<BpsCrossMonth> getUnshippedOrderQty4Remark(SearchBpsForm form, List<BpsCrossMonth> bpsOrderList);
	
	public List<BpsCrossMonth> getBpsOrderQty4Remark(SearchBpsForm form);
	
	public BpsCrossMonth getTotalBpsOrderQty4Remark(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsOrderQty4RemarkByRegion(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsOrderQty4RemarkByODM(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsOrderQty4RemarkByProduct(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsOrderQty4RemarkByProductFamily(SearchBpsForm form);
	
	public List<BpsCrossMonth> getMaxProductBpsOrderQty4RemarkByRegion(SearchBpsForm form);
	
	public List<BpsCrossMonth> getMaxProductFamilyBpsOrderQty4RemarkByRegion(SearchBpsForm form);
	
	public List<BpsCrossMonth> getMaxProductBpsOrderQty4RemarkByODM(SearchBpsForm form);
	
	public List<BpsCrossMonth> getMaxProductBpsOrderQty4RemarkByProduct(SearchBpsForm form);
	
	public List<BpsCrossMonth> getMaxProductFamilyBpsOrderQty4RemarkByProductFamily(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsOrderQty4PieByPurchaseType(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsOrderQty4PieByCVPurchaseType(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsOrderQty4PieByParts(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsOrderQty4PieByBpsPurchaseType(SearchBpsForm form);

	public List<BpsCrossMonth> getBpsOrderQty4PieBySubParts(SearchBpsForm form);

	public List<ScOverViewChartData> fetchBpsOverViewChartData(SearchBpsForm form);
	
	public List<ScOverViewChartData> fetchBpsOverViewCrossMonthChartDataRegion(SearchBpsForm form);
	
	public List<ScOverViewChartData> fetchBpsOverViewCrossMonthChartDataODM(SearchBpsForm form);
	
	public List<ScOverViewChartData> fetchBpsOverViewCrossMonthChartDataProduct(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsDashboardRegion(SearchBpsForm form);
	
	public List<BpsCrossMonth> getUnshippedDashboardOverview(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsDashboardODM(SearchBpsForm form);
	
	public List<BpsCrossMonth> getUnshippedDashboardODM(SearchBpsForm form);
	
	public List<BpsCrossMonth> getBpsDashboardProduct(SearchBpsForm form);
	
	public List<BpsCrossMonth> getUnshippedDashboardProduct(SearchBpsForm form);
	
	public List<BPSDetailView> getBpsDetail(SearchBpsForm form);
	
	public long getBpsDetailCount(SearchBpsForm form);
	
	public long getUnshippedDetailCount(SearchBpsForm form);
	
	public List<TtvGridDetractorCodeView> getOverviewOrderDetail(SearchBpsForm form);
	
	public List<FactDetailView> getOverviewFactDetail(SearchBpsForm form);
	
	public long getOverviewFactDetailCount(SearchBpsForm form);
}
