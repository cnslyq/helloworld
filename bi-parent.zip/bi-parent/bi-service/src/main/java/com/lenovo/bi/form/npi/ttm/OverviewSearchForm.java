package com.lenovo.bi.form.npi.ttm;

import java.util.List;

import com.lenovo.bi.enumobj.FailProductType;
import com.lenovo.bi.enumobj.NAType;
import com.lenovo.bi.enumobj.NPIPhase;
import com.lenovo.bi.enumobj.Risk;
import com.lenovo.bi.enumobj.SortType;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.enumobj.Success;
import com.lenovo.bi.enumobj.TTMGridColumns;
import com.lenovo.bi.enumobj.TTVGridColumns;
import com.lenovo.bi.form.npi.SearchBase;


/**
 * This class is a condition object for search grid base on left menu entrance: my projects, overview all, search product
 * @author coris_zhao
 *
 */
public class OverviewSearchForm extends SearchBase{
	private Status gridType;//ttm overview/in progress/fail/success/NA
	private NAType naType;
	private FailProductType failProductType;
	private Risk risk;//risk
	private Success success;
	private Integer successDelay;
	private TTMGridColumns ttmSortColumn;
	private TTVGridColumns ttvSortColumn;
	private SortType sortType;
	private int currentPage;
	private List<String> npi;
	private NPIPhase phase;
	
	private Status sgaGridType;
	private Risk sgaRisk;
	
	public List<String> getNpi() {
		return npi;
	}
	public void setNpi(List<String> npi) {
		this.npi = npi;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	
	public FailProductType getFailProductType() {
		return failProductType;
	}
	public void setFailProductType(FailProductType failProductType) {
		this.failProductType = failProductType;
	}
	public NAType getNaType() {
		return naType;
	}
	public void setNaType(NAType naType) {
		this.naType = naType;
	}
	public Integer getSuccessDelay() {
		return successDelay;
	}
	public void setSuccessDelay(Integer successDelay) {
		this.successDelay = successDelay;
	}
	public Success getSuccess() {
		return success;
	}
	public void setSuccess(Success success) {
		this.success = success;
	}
	public SortType getSortType() {
		return sortType;
	}
	public void setSortType(SortType sortType) {
		this.sortType = sortType;
	}
	public TTMGridColumns getTtmSortColumn() {
		return ttmSortColumn;
	}
	public void setTtmSortColumn(TTMGridColumns ttmSortColumn) {
		this.ttmSortColumn = ttmSortColumn;
	}
	public TTVGridColumns getTtvSortColumn() {
		return ttvSortColumn;
	}
	public void setTtvSortColumn(TTVGridColumns ttvSortColumn) {
		this.ttvSortColumn = ttvSortColumn;
	}
	public Status getGridType() {
		return gridType;
	}
	public void setGridType(Status gridType) {
		this.gridType = gridType;
	}
	public Risk getRisk() {
		return risk;
	}
	public void setRisk(Risk risk) {
		this.risk = risk;
	}
	public NPIPhase getPhase() {
		return phase;
	}
	public void setPhase(NPIPhase phase) {
		this.phase = phase;
	}
	public Status getSgaGridType() {
		return sgaGridType;
	}
	public void setSgaGridType(Status sgaGridType) {
		this.sgaGridType = sgaGridType;
	}
	public Risk getSgaRisk() {
		return sgaRisk;
	}
	public void setSgaRisk(Risk sgaRisk) {
		this.sgaRisk = sgaRisk;
	}
}
