package com.lenovo.bi.dao.common.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.Product;

@Repository
public class ProductDaoImpl extends HibernateBaseDaoImplDw {
	public List<Product> getAllEolProductsInWeek(Date targetDate, boolean justLastWeek) {
		StringBuilder sql = new StringBuilder("select fep.productKey, t.FullDateAlternateKey as eolDate ")
			.append("from FactEOLProduct fep, DimTime t ")
			.append("where fep.EOLDateKey = t.TimeKey ")
			.append("and datediff(day, t.FullDateAlternateKey, ?) > 0 ");
				
		if (justLastWeek) {
			sql.append("and datediff(day, t.FullDateAlternateKey, ?) <= 7 ");
		}
		
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(Product.class));
		query.setParameter(0, targetDate);
		
		if (justLastWeek) {
			query.setParameter(1, targetDate);
		}
		
		@SuppressWarnings("unchecked")
		List<Product> products = query.list();
		
		return products;
	}
}
