package com.lenovo.bi.dao.system.console.impl;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.system.console.ConsoleMonitorForRestartJobDao;

@Repository
public class ConsoleMonitorForRestartJobDaoImpl extends HibernateBaseDaoImplDw implements ConsoleMonitorForRestartJobDao  {

	@Override
	public void restartFailedJobs(String pathName,String packageName) {
		//System.out.println("pathname is: " + pathName + "   packageName is: " + packageName);
		SQLQuery sqlQuery = (SQLQuery)getSession().createSQLQuery("{call dw_sp_executePackage(?,?)}");
		sqlQuery.setString(0, pathName);
		sqlQuery.setString(1, packageName + ".dtsx");
		
		sqlQuery.executeUpdate();
	}
}
