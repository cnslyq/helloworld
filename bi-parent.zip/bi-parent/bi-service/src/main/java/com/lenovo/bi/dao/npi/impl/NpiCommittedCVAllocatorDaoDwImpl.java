package com.lenovo.bi.dao.npi.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.formula.functions.T;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.ForecastDetailDto;
import com.lenovo.bi.dto.OrderDetailDto;

@Repository
@SuppressWarnings("unchecked")
public class NpiCommittedCVAllocatorDaoDwImpl extends HibernateBaseDaoImplDw<T> {

	/**
	 * get SLE order list
	 * @param versionDate
	 * @param financeEndDate
	 * @param productKey
	 * @param productNotInSet
	 * @return
	 */
	public List<OrderDetailDto> getSLEOrderList(Date versionDate, Date financeEndDate, int productKey, Set<Integer> productNotInSet){
		Query query = getOrderQuery(versionDate, financeEndDate, productKey, productNotInSet, "RSDDate");
		return query.list();
	}
	
	/**
	 * get SGA order list
	 * @param versionDate
	 * @param financeEndDate
	 * @param productKey
	 * @param productNotInSet
	 * @return
	 */
	public List<OrderDetailDto> getSGAOrderList(Date versionDate, Date financeEndDate, int productKey, Set<Integer> productNotInSet){
		Query query = getOrderQuery(versionDate, financeEndDate, productKey, productNotInSet, "orderDate");
		return query.list();
	}
	
	/**
	 * get forecast list
	 * @param versionDate
	 * @param targetDate
	 * @param dnsVersionDate
	 * @param initDate
	 * @param financeEndDate
	 * @param productKey
	 * @param productNotInSet
	 * @return
	 */
	public List<ForecastDetailDto> getForecastList(Date versionDate, Date targetDate, Date dnsVersionDate, 
			Date initDate, Date financeEndDate, int productKey, Set<Integer> productNotInSet){
		
		StringBuffer sql = new StringBuffer();
		sql.append(" select cast(cast(vf.versionDateKey as varchar) as date) as versionDate, ");
		sql.append(" cast(cast(vf.targetDateKey as varchar) as date) as targetDate, ");
		sql.append(" pmw.productKey as productKey, ");
		sql.append(" nw.PMSWaveIDAlternateKey as waveKey, ");
		sql.append(" vf.MTMKey as mtmKey, ");
		sql.append(" vf.quantity as quantity, ");
		sql.append(" vf.geographyKey as geographyKey, ");
		sql.append(" dg.geographyName as geographyName, ");
		sql.append(" dm.BOMNumberAlternateKey as bomNumber, ");
		sql.append(" vf.ODMKey as odmKey, ");
		sql.append(" do.ODMEnglishName as odmName ");
		sql.append(" from View_factweeklyforecast_forUI vf, FactProductMTMWave pmw, DimGeography dg, DimODM do, DimMTM dm, DimNPIWave nw ");
		sql.append(" where 1=1 ");
		sql.append(" and pmw.NPIWaveKey = nw.NPIWaveKey ");
		sql.append(" and vf.MTMKey = pmw.MTMKey ");
		sql.append(" and vf.MTMKey = dm.MTMKey ");
		sql.append(" and vf.geographyKey = dg.geographyKey ");
		sql.append(" and vf.ODMKey = do.ODMKey ");
		sql.append(" and vf.quantity <> 0 ");
		//sql.append(" and pmw.dateVersion = (select max(dateVersion) from FactProductMTMWave t where vf.MTMKey = t.MTMKey and vf.targetDateKey >= t.dateVersion) ");
		//sql.append(" and vf.versionDateKey = :versionDate ");
		sql.append(" and pmw.dateVersion = (select max(dateVersion) from FactProductMTMWave t where vf.MTMKey = t.MTMKey and t.dateVersion <= :versionDate) ");
		sql.append(" and vf.versionDateKey = :dnsVersionDate ");
		if(targetDate != null){
			sql.append(" and vf.targetDateKey = :targetDate ");
		}
		if(initDate != null && financeEndDate != null){
			sql.append(" and vf.targetDateKey between :initDate and :financeEndDate ");
		}
		if(productKey != -1){
			sql.append(" and pmw.productKey = :productKey ");
		}
		if(productNotInSet != null && productNotInSet.size() > 0){
			sql.append(" and pmw.productKey not in (:productNotInSet) ");
		}
		sql.append(" order by pmw.productKey, vf.targetDateKey, vf.quantity, vf.MTMKey");
		
		Query query=getSession().createSQLQuery(sql.toString()).addScalar("versionDate", DateType.INSTANCE)
				.addScalar("targetDate", DateType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE)
				.addScalar("waveKey", IntegerType.INSTANCE)
				.addScalar("mtmKey", IntegerType.INSTANCE)
				.addScalar("bomNumber", StringType.INSTANCE)
				.addScalar("quantity", IntegerType.INSTANCE)
				.addScalar("geographyKey", IntegerType.INSTANCE)
				.addScalar("geographyName", StringType.INSTANCE)
				.addScalar("odmKey", IntegerType.INSTANCE)
				.addScalar("odmName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ForecastDetailDto.class));
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		query.setParameter("versionDate", sdf.format(versionDate));
		query.setParameter("dnsVersionDate", sdf.format(dnsVersionDate));
		if(targetDate != null){
			query.setParameter("targetDate", sdf.format(targetDate));
		}
		if(initDate != null && financeEndDate != null){
			query.setParameter("initDate", sdf.format(initDate));
			query.setParameter("financeEndDate", sdf.format(financeEndDate));
		}
		if(productKey != -1){
			query.setParameter("productKey", productKey);
		}
		if(productNotInSet != null && productNotInSet.size() > 0){
			query.setParameterList("productNotInSet", productNotInSet);
		}
		
		return query.list();
	}
	
	/**
	 * get CV mapping for per MTM
	 * @param mtmKey
	 * @return
	 */
	public Map<Integer, Integer> getCvMapping4Mtm(int mtmKey){
		Map<Integer, Integer> cvMap4Mtm = new HashMap<Integer, Integer>();
		
		StringBuffer sql = new StringBuffer();
		sql.append(" select pmc.globalCVKey, dc.quantity ");
		sql.append(" from FactProductMTMCV pmc, DimGlobalCV dc ");
		sql.append(" where pmc.globalCVKey = dc.globalCVKey ");
		sql.append(" and pmc.MTMKey = :mtmKey ");
		
		Query query = getSession().createSQLQuery(sql.toString());
		query.setParameter("mtmKey", mtmKey);
		List<Object[]> list = query.list();
		for(Object[] obj : list){
			cvMap4Mtm.put(Integer.parseInt(obj[0].toString()), Integer.parseInt(obj[1].toString()));
		}
		return cvMap4Mtm;
	}
	
	/**
	 * get order query
	 * @param versionDate
	 * @param financeEndDate
	 * @param productKey
	 * @param productNotInSet
	 * @param dateType
	 * @return
	 */
	private Query getOrderQuery(Date versionDate, Date financeEndDate, int productKey, Set<Integer> productNotInSet, String dateType){
		StringBuffer sql = new StringBuffer();
		sql.append(" select :versionDate as versionDate, ");
		sql.append(" vod.orderDate as orderDate, ");
		sql.append(" vod.RSDDate as rsdDate, ");
		//sql.append(" dateadd(day, 2 - datepart(weekday, vod." + dateType + "), vod." + dateType + ") as targetDate, ");
		//sql.append(" dateadd(day, 2 - (datepart(weekday, vod." + dateType + ") + (8 - datepart(weekday, vod." + dateType + "))/7*7), vod." + dateType + ") as targetDate, ");
		sql.append(" dbo.GetMondayFor(vod." + dateType + ") as targetDate, ");
		sql.append(" vod.PoItem as poItem, ");
		sql.append(" vod.PoNumber as poNumber, ");
		sql.append(" vod.productKey as productKey, ");
		sql.append(" nw.PMSWaveIDAlternateKey as waveKey, ");
		sql.append(" vod.MTMKey as mtmKey, ");
		sql.append(" dm.BOMNumberAlternateKey as bomNumber, ");
		sql.append(" vod.quantity as quantity, ");
		sql.append(" vod.regionKey as regionKey, ");
		sql.append(" dg.geographyName as geographyName, ");
		sql.append(" vod.ODMKey as odmKey, ");
		sql.append(" do.ODMEnglishName as odmName ");
		sql.append(" from View_OrderDetail vod, DimGeography dg, DimODM do, FactProductMTMWave pmw, DimMTM dm, DimNPIWave nw ");
		sql.append(" where 1=1 ");
		sql.append(" and pmw.NPIWaveKey = nw.NPIWaveKey ");
		sql.append(" and vod.isShipped = 'false' ");
		sql.append(" and vod.quantity <> 0 ");
		//sql.append(" and pmw.dateVersion = (select max(dateVersion) from FactProductMTMWave t where vod.MTMKey = t.MTMKey and vod." + dateType + " >= t.dateVersion) ");
		sql.append(" and pmw.dateVersion = (select max(dateVersion) from FactProductMTMWave t where vod.MTMKey = t.MTMKey and t.dateVersion <= :versionDate) ");
		sql.append(" and vod.regionKey = dg.geographyKey ");
		sql.append(" and vod.ODMKey = do.ODMKey ");
		sql.append(" and vod.MTMKey = pmw.MTMKey ");
		sql.append(" and vod.MTMKey = dm.MTMKey ");
		sql.append(" and vod.productKey is not null ");
		sql.append(" and datediff(day, vod." + dateType + ", :financeEndDate) >= -6 ");
		if(productKey != -1){
			sql.append(" and vod.productKey = :productKey ");
		}
		if(productNotInSet != null && productNotInSet.size() > 0){
			sql.append(" and vod.productKey not in (:productNotInSet) ");
		}
		sql.append(" order by vod.productKey, vod." + dateType + ", vod.quantity, vod.MTMKey ");
		
		Query query=getSession().createSQLQuery(sql.toString()).addScalar("versionDate", DateType.INSTANCE)
				.addScalar("orderDate", DateType.INSTANCE)
				.addScalar("rsdDate", DateType.INSTANCE)
				.addScalar("targetDate", DateType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE)
				.addScalar("waveKey", IntegerType.INSTANCE)
				.addScalar("mtmKey", IntegerType.INSTANCE)
				.addScalar("bomNumber", StringType.INSTANCE)
				.addScalar("quantity", IntegerType.INSTANCE)
				.addScalar("regionKey", IntegerType.INSTANCE)
				.addScalar("geographyName", StringType.INSTANCE)
				.addScalar("odmKey", IntegerType.INSTANCE)
				.addScalar("odmName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(OrderDetailDto.class));
		
		query.setParameter("versionDate", versionDate);
		query.setParameter("financeEndDate", financeEndDate);
		if(productKey != -1){
			query.setParameter("productKey", productKey);
		}
		if(productNotInSet != null && productNotInSet.size() > 0){
			query.setParameterList("productNotInSet", productNotInSet);
		}
		
		return query;
	}
	
	/**
	 * get finance end date
	 * @param initDate
	 * @return
	 */
	public Date getFinanceEndDate(Date initDate){
		StringBuffer sql = new StringBuffer();
		//get date from FactBizCalendarMapping
		/*
		sql.append(" select cast(cast(max(shipDateKey) as varchar) as date) from FactBizCalendarMapping a, ");
		sql.append(" (select bizYear, bizMonth from FactBizCalendarMapping where shipDateKey = ");
		sql.append(" (select max(shipDateKey) from FactBizCalendarMapping where shipDateKey <= convert(varchar(8), :initDate, 112))) b ");
		sql.append(" where a.bizYear = b.bizYear + (b.bizMonth + 1)/12 ");
		sql.append(" and a.bizMonth = (b.bizMonth + 1)%12 + 1 ");
		*/
		
		//get date from DimTime
		sql.append(" select cast(cast(max(timeKey) as varchar) as date) from DimTime a, ");
		sql.append(" (select bizYear, bizMonth from DimTime where timeKey = convert(varchar(8), :initDate, 112)) b ");
		sql.append(" where a.bizYear = b.bizYear + (b.bizMonth + 1)/12 ");
		sql.append(" and a.bizMonth = (b.bizMonth + 1)%12 + 1 ");
		sql.append(" and a.dayNumberOfWeek = 1 ");
		
		Query query = getSession().createSQLQuery(sql.toString());
		query.setParameter("initDate", initDate);
		return (Date) query.uniqueResult();
	}
	
}
