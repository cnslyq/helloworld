package com.lenovo.bi.service.npi.helper;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.impl.WeeklyComponentCommitmentOnMtmCtoDaoImpl;
import com.lenovo.bi.dao.npi.NPITTMDemandDao;
import com.lenovo.bi.dto.TTMDemand;
import com.lenovo.bi.dto.TTMDemandDetail;
import com.lenovo.bi.dto.WeeklyComponentCommitment;
import com.lenovo.bi.dto.WeeklyComponentCommitment;
import com.lenovo.bi.dto.WeeklyComponentCommitment;

/**
 * 
 * 
 * @author henry_lian
 *
 */
@Service
public class NPIDOIHelper {
	
	@Autowired
	private NPITTMDemandDao nPITTMDemandDao;
	
	@Autowired
	private WeeklyComponentCommitmentOnMtmCtoDaoImpl weeklyComponentCommitmentOnMtmCtoDaoImpl;
	@Transactional("dw")
	public Integer getTTMTargetDemandByWaveId(int pmsWaveId){
		return nPITTMDemandDao.getTTMTargetDemandByWaveId(pmsWaveId);
	}
	@Transactional("dw")
	public List<TTMDemand> getTTMDemandListByWaveId(int pmsWaveId){
		return nPITTMDemandDao.getTTMDemandListByWaveId(pmsWaveId);
	}
	@Transactional("dw")
	public List<TTMDemandDetail> getTTMDemandDetailListById(int pmsWaveId){
		return nPITTMDemandDao.getTTMDemandDetailListById(pmsWaveId);
	}
	@Transactional("bi")
	public List<WeeklyComponentCommitment> getCommitmentByTargetDate(Date targetDate, Date versionDate,Integer waveId){
		return weeklyComponentCommitmentOnMtmCtoDaoImpl.getCommitmentByTargetDate(targetDate, versionDate,waveId);
	}
}
