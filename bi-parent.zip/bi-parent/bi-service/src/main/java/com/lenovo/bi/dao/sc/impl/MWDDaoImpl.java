package com.lenovo.bi.dao.sc.impl;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.FloatType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.MWDDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.MWDChartData;
import com.lenovo.bi.form.sc.mwd.SearchMWDForm;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.view.sc.mwd.MWDDetailView;
import com.lenovo.common.model.PagerInformation;

@SuppressWarnings("rawtypes")
@Repository
public class MWDDaoImpl extends HibernateBaseDaoImplDw implements MWDDao {
 
	@SuppressWarnings("unchecked")
	@Override
	public List<MWDChartData> fetchMWDOverViewChartData(
			SearchMWDForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append(" select sum(price) as price ,mwdSummary.year,mwdSummary.month,mwdSummary.purchaseTypeKey,pur.PurchaseType")
			   .append(" from FactWeeklySummaryofMWD mwdSummary ")
			   .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwdSummary.month=d.month and mwdSummary.year=d.year and mwdSummary.StandardVersion=d.versionDate ")
			   .append(" join  DimPurchaseType pur on mwdSummary.purchaseTypeKey = pur.purchaseTypeKey ");
		sBuffer.append(" where mwdSummary.Year*100+mwdSummary.Month between '")
			   .append(formatDate(form.getStartDate())).append("'")
               .append(" and '").append(formatDate(form.getEndDate())).append("'");
		
		if(form.getPurchaseTypeKey()!=-1) {//以后有可能是in
			sBuffer.append(" and mwdSummary.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
		}
		
		if(!"-1".equals(form.getEol())) {
			sBuffer.append(" and mwdSummary.EOL = '").append(form.getEol()+"'");
		}
		sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
		
		sBuffer.append(" group by mwdSummary.YEAR, mwdSummary.MONTH,mwdSummary.purchaseTypeKey,pur.PurchaseType ");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("year", IntegerType.INSTANCE)
				.addScalar("month", IntegerType.INSTANCE)
				.addScalar("price", FloatType.INSTANCE)
				.addScalar("purchaseType", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(MWDChartData.class));
		
		return query.list();
	}

	private String formatDate(String date){
		StringBuffer sb=new StringBuffer(date);
		sb.deleteCharAt(sb.indexOf("-"));
		return sb.toString();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MWDChartData> fetchDimensionRemarkDataList(SearchMWDForm form) {
		StringBuffer sBuffer=new StringBuffer();
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" select mwdSummary.regionKey as dimensionKey,geography.regionName as dimensionName,sum(price) as price ,mwdSummary.year,mwdSummary.month,mwdSummary.purchaseTypeKey,pur.PurchaseType ")
		       .append(" from FactWeeklySummaryofMWD mwdSummary ")
		       .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwdSummary.month=d.month and mwdSummary.year=d.year and mwdSummary.StandardVersion=d.versionDate ")
		       .append(" join  DimPurchaseType pur on mwdSummary.purchaseTypeKey = pur.purchaseTypeKey ");
			 
			sBuffer.append(" left join DimProduct product on mwdSummary.ProductKey = product.ProductKey")
	   		       .append(" left join (")
			       .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			       .append(" from DimProduct product")
		           .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			       .append(")productFamily on mwdSummary.ProductKey = productFamily.ProductKey");
			
			sBuffer.append(" left join DimODM odm on mwdSummary.ODMKey=odm.ODMKey ");
			
			sBuffer.append(" left join ( ")
			       .append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
		           .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
			       .append(" on  mwdSummary.regionKey=geography.regionKey ");
			
			sBuffer.append(" where mwdSummary.Year="+form.getYear()+" and mwdSummary.Month="+form.getMonth());
			
			if(form.getPurchaseTypeKey()!=-1) {//以后有可能是in
				sBuffer.append(" and mwdSummary.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwdSummary.EOL = '").append(form.getEol()+"'");
			}
			
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwdSummary.regionKey in ( ").append(form.getGeoIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwdSummary.odmKey in ( ").append(form.getOdmIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and productFamily.familyKey in ( ").append(form.getFamilyIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwdSummary.ProductKey in ( ").append(form.getProductIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwdSummary.Commodity in ( ").append(getComponents(form.getComponents())+")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				}else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				}else if("Family".equals(form.getDashboardType())){
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				}else if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Region'");
				}else if("Component".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Region'");
				}
			}
			
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Detail'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getCrossMonthTypeKey())
					   	   .append(" aNd mwdSummary.GroupByType = 'Detail'");
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey())
					   	   .append(" aNd mwdSummary.GroupByType = 'Detail'");
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getCrossMonthTypeKey())
					   	   .append(" aNd mwdSummary.GroupByType = 'Region'");
				else if("Component".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'")
					   	   .append(" aNd mwdSummary.GroupByType = 'Region'");
			}
			if((form.getDashboardTypeKey() == -1) && (form.getCrossMonthTypeKey() == -1) ){
				//sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				sBuffer.append(" aNd mwdSummary.GroupByType = 'Region'");
			}
			sBuffer.append(" group by mwdSummary.YEAR, mwdSummary.MONTH,mwdSummary.purchaseTypeKey,pur.PurchaseType,mwdSummary.regionKey,geography.regionName having geography.regionName <> ''");
			
		}
		
		if("Odm".equals(form.getDimension())) {
			sBuffer.append(" select mwdSummary.odmKey as dimensionKey,odm.ODMEnglishName as dimensionName,sum(price) as price ,mwdSummary.year,mwdSummary.month,mwdSummary.purchaseTypeKey,pur.PurchaseType ")
		       .append(" from FactWeeklySummaryofMWD mwdSummary ")
		       .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwdSummary.month=d.month and mwdSummary.year=d.year and mwdSummary.StandardVersion=d.versionDate ")
		       .append(" join  DimPurchaseType pur on mwdSummary.purchaseTypeKey = pur.purchaseTypeKey ");
			 
			sBuffer.append(" left join DimProduct product on mwdSummary.ProductKey = product.ProductKey")
	   		       .append(" left join (")
			       .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			       .append(" from DimProduct product")
		           .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			       .append(")productFamily on mwdSummary.ProductKey = productFamily.ProductKey");
			
			sBuffer.append(" left join DimODM odm on mwdSummary.ODMKey=odm.ODMKey ");
			
			sBuffer.append(" left join ( ")
			       .append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
		           .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
			       .append(" on  mwdSummary.regionKey=geography.regionKey ");
			
			sBuffer.append(" where mwdSummary.Year="+form.getYear()+" and mwdSummary.Month="+form.getMonth());
			
			if(form.getPurchaseTypeKey()!=-1) {//以后有可能是in
				sBuffer.append(" and mwdSummary.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwdSummary.EOL = '").append(form.getEol()+"'");
			}
			
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwdSummary.regionKey in ( ").append(form.getGeoIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwdSummary.odmKey in ( ").append(form.getOdmIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and productFamily.familyKey in ( ").append(form.getFamilyIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwdSummary.ProductKey in ( ").append(form.getProductIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwdSummary.Commodity in ( ").append(getComponents(form.getComponents())+")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Region'");
				}else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Family".equals(form.getDashboardType())){
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				}else if("Component".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
				}
			}
			
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Region'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Detail'");
				else if("Component".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'CV'");
			}
			
			if((form.getDashboardTypeKey() == -1) && (form.getCrossMonthTypeKey() == -1) ){
				//sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
			}
			sBuffer.append(" group by mwdSummary.YEAR, mwdSummary.MONTH,mwdSummary.purchaseTypeKey,pur.PurchaseType,mwdSummary.odmKey,odm.ODMEnglishName having odm.ODMEnglishName<>'' ");
			
		}
		
		if("Family".equals(form.getDimension())) {
			sBuffer.append(" select productFamily.familyKey as dimensionKey,productFamily.ProductFamilyEnglishName as dimensionName,sum(price) as price ,mwdSummary.year,mwdSummary.month,mwdSummary.purchaseTypeKey,pur.PurchaseType ")
		       .append(" from FactWeeklySummaryofMWD mwdSummary ")
		       .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwdSummary.month=d.month and mwdSummary.year=d.year and mwdSummary.StandardVersion=d.versionDate ")
		       .append(" join  DimPurchaseType pur on mwdSummary.purchaseTypeKey = pur.purchaseTypeKey ");
			 
			sBuffer.append(" left join DimProduct product on mwdSummary.ProductKey = product.ProductKey")
	   		       .append(" left join (")
			       .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			       .append(" from DimProduct product")
		           .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			       .append(")productFamily on mwdSummary.ProductKey = productFamily.ProductKey");
			
			sBuffer.append(" left join DimODM odm on mwdSummary.ODMKey=odm.ODMKey ");
			
			sBuffer.append(" left join ( ")
			       .append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
		           .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
			       .append(" on  mwdSummary.regionKey=geography.regionKey ");
			
			sBuffer.append(" where mwdSummary.Year="+form.getYear()+" and mwdSummary.Month="+form.getMonth());
			
			if(form.getPurchaseTypeKey()!=-1) {//以后有可能是in
				sBuffer.append(" and mwdSummary.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwdSummary.EOL = '").append(form.getEol()+"'");
			}
			
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwdSummary.regionKey in ( ").append(form.getGeoIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwdSummary.odmKey in ( ").append(form.getOdmIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and productFamily.familyKey in ( ").append(form.getFamilyIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwdSummary.ProductKey in ( ").append(form.getProductIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwdSummary.Commodity in ( ").append(getComponents(form.getComponents())+")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				}else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Family".equals(form.getDashboardType())){
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				}else if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Component".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}
			}
			
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Detail'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Detail'");
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Component".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
			}
			if((form.getDashboardTypeKey() == -1) && (form.getCrossMonthTypeKey() == -1) ){
				//sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
			}
			sBuffer.append(" group by mwdSummary.YEAR, mwdSummary.MONTH,mwdSummary.purchaseTypeKey,pur.PurchaseType,productFamily.familyKey,productFamily.ProductFamilyEnglishName having productFamily.ProductFamilyEnglishName<>'' ");
			
		}
		
		if("Product".equals(form.getDimension())) {
			sBuffer.append(" select mwdSummary.ProductKey as dimensionKey,product.ProductEnglishName as dimensionName,sum(price) as price ,mwdSummary.year,mwdSummary.month,mwdSummary.purchaseTypeKey,pur.PurchaseType ")
		       .append(" from FactWeeklySummaryofMWD mwdSummary ")
		       .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwdSummary.month=d.month and mwdSummary.year=d.year and mwdSummary.StandardVersion=d.versionDate ")
		       .append(" join  DimPurchaseType pur on mwdSummary.purchaseTypeKey = pur.purchaseTypeKey ");
			 
			sBuffer.append(" left join DimProduct product on mwdSummary.ProductKey = product.ProductKey")
	   		       .append(" left join (")
			       .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			       .append(" from DimProduct product")
		           .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			       .append(")productFamily on mwdSummary.ProductKey = productFamily.ProductKey");
			
			sBuffer.append(" left join DimODM odm on mwdSummary.ODMKey=odm.ODMKey ");
			
			sBuffer.append(" left join ( ")
			       .append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
		           .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
			       .append(" on  mwdSummary.regionKey=geography.regionKey ");
			
			sBuffer.append(" where mwdSummary.Year="+form.getYear()+" and mwdSummary.Month="+form.getMonth());
			
			if(form.getPurchaseTypeKey()!=-1) {//以后有可能是in
				sBuffer.append(" and mwdSummary.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwdSummary.EOL = '").append(form.getEol()+"'");
			}
			
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwdSummary.regionKey in ( ").append(form.getGeoIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwdSummary.odmKey in ( ").append(form.getOdmIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and productFamily.familyKey in ( ").append(form.getFamilyIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwdSummary.ProductKey in ( ").append(form.getProductIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwdSummary.Commodity in ( ").append(getComponents(form.getComponents())+")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				}else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				}else if("Family".equals(form.getDashboardType())){
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Component".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}
			}
			
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Detail'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Detail'");
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Component".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
			}
			
			if((form.getDashboardTypeKey() == -1) && (form.getCrossMonthTypeKey() == -1) ){
				//sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
			}
			sBuffer.append(" group by mwdSummary.YEAR, mwdSummary.MONTH,mwdSummary.purchaseTypeKey,pur.PurchaseType,mwdSummary.ProductKey,product.ProductEnglishName ");
			sBuffer.append(" having mwdSummary.ProductKey is not null and product.ProductEnglishName is not null ");
			
		}
		
		if("Component".equals(form.getDimension())) {
			sBuffer.append(" select isnull(com.CommodityTypeKey,-2) as dimensionKey,mwdSummary.Commodity as dimensionName,sum(price) as price ,mwdSummary.year,mwdSummary.month,mwdSummary.purchaseTypeKey,pur.PurchaseType ")
			       .append(" from FactWeeklySummaryofMWD mwdSummary ")
			       .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwdSummary.month=d.month and mwdSummary.year=d.year and mwdSummary.StandardVersion=d.versionDate ")
			       .append(" join  DimPurchaseType pur on mwdSummary.purchaseTypeKey = pur.purchaseTypeKey ");
			 
			sBuffer.append(" left join DimProduct product on mwdSummary.ProductKey = product.ProductKey")
	   		       .append(" left join (")
			       .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			       .append(" from DimProduct product")
		           .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			       .append(")productFamily on mwdSummary.ProductKey = productFamily.ProductKey");
			
			sBuffer.append(" left join DimODM odm on mwdSummary.ODMKey=odm.ODMKey ");
			sBuffer.append(" left join DimCommodityType com on mwdSummary.Commodity=com.CommodityType ");
			sBuffer.append(" left join ( ")
			       .append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
		           .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
			       .append(" on  mwdSummary.regionKey=geography.regionKey ");
			
			sBuffer.append(" where mwdSummary.Year="+form.getYear()+" and mwdSummary.Month="+form.getMonth());
			
			if(form.getPurchaseTypeKey()!=-1) {//以后有可能是in
				sBuffer.append(" and mwdSummary.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwdSummary.EOL = '").append(form.getEol()+"'");
			}
			
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwdSummary.regionKey in ( ").append(form.getGeoIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwdSummary.odmKey in ( ").append(form.getOdmIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and productFamily.familyKey in ( ").append(form.getFamilyIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwdSummary.ProductKey in ( ").append(form.getProductIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwdSummary.Commodity in ( ").append(getComponents(form.getComponents())+")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Region'");
				}else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Family".equals(form.getDashboardType())){
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
				}else if("Component".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				}
			}
			
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Region'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'CV'");
				else if("Component".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Detail'");
			}
			if((form.getDashboardTypeKey() == -1) && (form.getCrossMonthTypeKey() == -1) ){
				//sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
			}
			sBuffer.append(" group by mwdSummary.YEAR, mwdSummary.MONTH,mwdSummary.purchaseTypeKey,pur.PurchaseType,mwdSummary.Commodity,com.CommodityTypeKey ");
			sBuffer.append(" having mwdSummary.Commodity<>'' and com.CommodityTypeKey <>'' ");
			
		}
		
		if("w2w".equals(form.getDimension())) {
			sBuffer.append(" select '1' as dimensionKey,'This_Week' as dimensionName,sum(price) as price ,mwdSummary.year,mwdSummary.month,mwdSummary.purchaseTypeKey,pur.PurchaseType ")
			       .append(" from FactWeeklySummaryofMWD mwdSummary ")
			       .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwdSummary.month=d.month and mwdSummary.year=d.year and mwdSummary.StandardVersion=d.versionDate ")
			       .append(" join  DimPurchaseType pur on mwdSummary.purchaseTypeKey = pur.purchaseTypeKey ");
			 
			sBuffer.append(" left join DimProduct product on mwdSummary.ProductKey = product.ProductKey")
	   		       .append(" left join (")
			       .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			       .append(" from DimProduct product")
		           .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			       .append(")productFamily on mwdSummary.ProductKey = productFamily.ProductKey");
			
			sBuffer.append(" left join DimODM odm on mwdSummary.ODMKey=odm.ODMKey ");
			
			sBuffer.append(" left join ( ")
			       .append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
		           .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
			       .append(" on  mwdSummary.regionKey=geography.regionKey ");
			
			sBuffer.append(" where mwdSummary.Year="+form.getYear()+" and mwdSummary.Month="+form.getMonth());
			
			if(form.getPurchaseTypeKey()!=-1) {//以后有可能是in
				sBuffer.append(" and mwdSummary.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwdSummary.EOL = '").append(form.getEol()+"'");
			}
			
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwdSummary.regionKey in ( ").append(form.getGeoIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwdSummary.odmKey in ( ").append(form.getOdmIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and productFamily.familyKey in ( ").append(form.getFamilyIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwdSummary.ProductKey in ( ").append(form.getProductIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwdSummary.Commodity in ( ").append(getComponents(form.getComponents())+")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Region'");
				}else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Family".equals(form.getDashboardType())){
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
				}else if("Component".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
				}
			}
			
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Region'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'CV'");
				else if("Component".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'CV'");
			}
			if((form.getDashboardTypeKey() == -1) && (form.getCrossMonthTypeKey() == -1) ){
				//sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
			}
			sBuffer.append(" group by mwdSummary.YEAR, mwdSummary.MONTH,mwdSummary.purchaseTypeKey,pur.PurchaseType ");
			
			sBuffer.append(" union ");
			
			sBuffer.append(" select '2' as dimensionKey,'Last_Week' as dimensionName,sum(price) as price ,mwdSummary.year,mwdSummary.month,mwdSummary.purchaseTypeKey,pur.PurchaseType ")
		       .append(" from FactWeeklySummaryofMWD mwdSummary ")
		       .append(" join  DimPurchaseType pur on mwdSummary.purchaseTypeKey = pur.purchaseTypeKey ");
			 
			sBuffer.append(" left join DimProduct product on mwdSummary.ProductKey = product.ProductKey")
	   		       .append(" left join (")
			       .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			       .append(" from DimProduct product")
		           .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			       .append(")productFamily on mwdSummary.ProductKey = productFamily.ProductKey");
			
			sBuffer.append(" left join DimODM odm on mwdSummary.ODMKey=odm.ODMKey ");
			
			sBuffer.append(" left join ( ")
			       .append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
		           .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
			       .append(" on  mwdSummary.regionKey=geography.regionKey ");
			
			String maxVersion=" ( select max(StandardVersion) from FactWeeklySummaryofMWD w where w.year="+form.getYear()+" and w.month="+form.getMonth()+" )";
			
			sBuffer.append(" where mwdSummary.StandardVersion=("
					+ "	select max(m.StandardVersion) from FactWeeklySummaryofMWD m where m.year="+form.getYear()+"and m.month="+form.getMonth()+" and m.StandardVersion<"+maxVersion
					+ ")");
			
			if(form.getPurchaseTypeKey()!=-1) {//以后有可能是in
				sBuffer.append(" and mwdSummary.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwdSummary.EOL = '").append(form.getEol()+"'");
			}
			
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwdSummary.regionKey in ( ").append(form.getGeoIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwdSummary.odmKey in ( ").append(form.getOdmIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and productFamily.familyKey in ( ").append(form.getFamilyIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwdSummary.ProductKey in ( ").append(form.getProductIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwdSummary.Commodity in ( ").append(getComponents(form.getComponents())+")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Region'");
				}else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Family".equals(form.getDashboardType())){
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
				}else if("Component".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
				}
			}
			
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Region'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'CV'");
				else if("Component".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'CV'");
			}
			if((form.getDashboardTypeKey() == -1) && (form.getCrossMonthTypeKey() == -1) ){
				//sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
			}
			sBuffer.append(" group by mwdSummary.YEAR, mwdSummary.MONTH,mwdSummary.purchaseTypeKey,pur.PurchaseType ");
			
			sBuffer.append(" union ");
			
			sBuffer.append(" select '3' as dimensionKey,'Last_Week' as dimensionName,sum(price) as price ,mwdSummary.year,mwdSummary.month,mwdSummary.purchaseTypeKey,pur.PurchaseType ")
		       .append(" from FactWeeklySummaryofMWD mwdSummary ")
		       .append(" join  DimPurchaseType pur on mwdSummary.purchaseTypeKey = pur.purchaseTypeKey ");
			 
			sBuffer.append(" left join DimProduct product on mwdSummary.ProductKey = product.ProductKey")
	   		       .append(" left join (")
			       .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
			       .append(" from DimProduct product")
		           .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			       .append(")productFamily on mwdSummary.ProductKey = productFamily.ProductKey");
			
			sBuffer.append(" left join DimODM odm on mwdSummary.ODMKey=odm.ODMKey ");
			
			sBuffer.append(" left join ( ")
			       .append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
		           .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
			       .append(" on  mwdSummary.regionKey=geography.regionKey ");
			
			String date="";
			
			try {
				date=CalendarUtil.getYearMonthByMonths(form.getYear()+"-"+form.getMonth(), -1);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			int year=Integer.valueOf(date.substring(0, date.indexOf("-")));
			
			int month=Integer.valueOf(date.substring(date.indexOf("-")+1));
			
			String secondMaxVersion=" ( select max(StandardVersion) from FactWeeklySummaryofMWD w where w.year="+year+" and w.month="+month+" )";
			
			sBuffer.append(" where mwdSummary.StandardVersion="+secondMaxVersion);
					
			
			if(form.getPurchaseTypeKey()!=-1) {//以后有可能是in
				sBuffer.append(" and mwdSummary.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwdSummary.EOL = '").append(form.getEol()+"'");
			}
			
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwdSummary.regionKey in ( ").append(form.getGeoIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwdSummary.odmKey in ( ").append(form.getOdmIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and productFamily.familyKey in ( ").append(form.getFamilyIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwdSummary.ProductKey in ( ").append(form.getProductIds()+")");
			}
			
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwdSummary.Commodity in ( ").append(getComponents(form.getComponents())+")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Region'");
				}else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Family".equals(form.getDashboardType())){
					sBuffer.append(" and productFamily.familyKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'Product'");
				}else if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getDashboardTypeKey());
					sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
				}else if("Component".equals(form.getDashboardType())){
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'");
					sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
				}
			}
			
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and geography.regionName = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'Region'");
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Family".equals(form.getCrossMonthType()))
					sBuffer.append(" and productFamily.familyKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'Product'");
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.odmKey = ").append(form.getCrossMonthTypeKey())
						   .append(" aNd mwdSummary.GroupByType = 'CV'");
				else if("Component".equals(form.getCrossMonthType()))
					sBuffer.append(" and mwdSummary.commodity = '").append(form.getSubDimension()+"'")
						   .append(" aNd mwdSummary.GroupByType = 'CV'");
			}
			if((form.getDashboardTypeKey() == -1) && (form.getCrossMonthTypeKey() == -1) ){
				//sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
				sBuffer.append(" aNd mwdSummary.GroupByType = 'CV'");
			}
			sBuffer.append(" group by mwdSummary.YEAR, mwdSummary.MONTH,mwdSummary.purchaseTypeKey,pur.PurchaseType ");
			
		}
		
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("year", IntegerType.INSTANCE)
				.addScalar("month", IntegerType.INSTANCE)
				.addScalar("price", FloatType.INSTANCE)
				.addScalar("purchaseType", StringType.INSTANCE)
				.addScalar("dimensionKey", IntegerType.INSTANCE)
				.addScalar("dimensionName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(MWDChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchDimensions(SearchMWDForm form){
		PagerInformation pagerInfo = form.getPagerInfo();
		StringBuffer sBuffer = new StringBuffer();
		if("Region".equals(form.getDashboardType())) {
		    sBuffer.append("select top 12 sum(price) as price,geography.geographyKey as objKey, geography.GeographyName as objName, 'Region' as type")
			       .append(" from FactWeeklySummaryofMWD mwd")
			       .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwd.month=d.month and mwd.year=d.year and mwd.StandardVersion=d.versionDate ")
			       .append(" left join  DimPurchaseType pur on mwd.purchaseTypeKey = pur.purchaseTypeKey ")
		    	   .append(" left join DimProduct product on mwd.productKey = product.productKey")
		    	   .append(" left join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey")
		    	   .append(" left join DimCommodityType com on mwd.Commodity = com.CommodityType")
		    	   .append(" inner join DimGeography geography on geography.GeographyKey = mwd.regionKey");
		    
		    sBuffer.append(" where mwd.Year = ").append(form.getYear())
    			   .append(" and mwd.Month = ").append(form.getMonth());
		    if(form.getPurchaseTypeKey()!=-1) {
				sBuffer.append(" and mwd.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwd.EOL = '").append(form.getEol()+"'");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwd.regionKey in ( ").append(form.getGeoIds()+")");
			}
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwd.odmKey in ( ").append(form.getOdmIds()+")");
			}
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and product.ProductFamilyKey in ( ").append(form.getFamilyIds()+")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwd.ProductKey in ( ").append(form.getProductIds()+")");
			}
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwd.Commodity in ( ").append(form.getComponents()+")");
			}
			sBuffer.append(" aNd mwd.GroupByType = 'Region'");
			sBuffer.append(" group by geography.GeographyName,geography.geographyKey");
		}
		else if("Odm".equals(form.getDashboardType())) {
		    sBuffer.append("select top 12 sum(price) as price,mwd.ODMKey as objKey,odm.ODMEnglishName as objName,'Odm' as type")
			       .append(" from FactWeeklySummaryofMWD mwd")
			       .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwd.month=d.month and mwd.year=d.year and mwd.StandardVersion=d.versionDate ")
			       .append(" left join  DimPurchaseType pur on mwd.purchaseTypeKey = pur.purchaseTypeKey ")
		    	   .append(" left join DimProduct product on mwd.productKey = product.productKey")
		    	   .append(" left join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey")
		    	   .append(" left join DimCommodityType com on mwd.Commodity = com.CommodityType")
		    	   .append(" inner join DimODM odm on mwd.ODMKey = odm.ODMKey");
		    
			sBuffer.append(" where mwd.Year = ").append(form.getYear())
    			   .append(" and mwd.Month = ").append(form.getMonth());
			if(form.getPurchaseTypeKey()!=-1) {
				sBuffer.append(" and mwd.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwd.EOL = '").append(form.getEol()+"'");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwd.regionKey in ( ").append(form.getGeoIds()+")");
			}
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwd.odmKey in ( ").append(form.getOdmIds()+")");
			}
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and product.ProductFamilyKey in ( ").append(form.getFamilyIds()+")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwd.ProductKey in ( ").append(form.getProductIds()+")");
			}
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwd.Commodity in ( ").append(form.getComponents()+")");
			}
			sBuffer.append(" aNd mwd.GroupByType = 'CV'");
			sBuffer.append(" group by mwd.ODMKey,odm.ODMEnglishName having mwd.ODMKey <> ''");
		}
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append("select top 12 sum(price) as price,mwd.ProductKey as objKey, product.ProductEnglishName as objName, 'Product' as type")
				   .append(" from FactWeeklySummaryofMWD mwd")
			       .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwd.month=d.month and mwd.year=d.year and mwd.StandardVersion=d.versionDate ")
			       .append(" left join  DimPurchaseType pur on mwd.purchaseTypeKey = pur.purchaseTypeKey ")
		    	   .append(" inner join DimProduct product on mwd.productKey = product.productKey")
		    	   .append(" left join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey")
		    	   .append(" left join DimCommodityType com on mwd.Commodity = com.CommodityType");
			
	    	sBuffer.append(" where mwd.Year = ").append(form.getYear())
	    		   .append(" and mwd.Month = ").append(form.getMonth());
	    	if(form.getPurchaseTypeKey()!=-1) {
				sBuffer.append(" and mwd.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwd.EOL = '").append(form.getEol()+"'");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwd.regionKey in ( ").append(form.getGeoIds()+")");
			}
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwd.odmKey in ( ").append(form.getOdmIds()+")");
			}
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and product.ProductFamilyKey in ( ").append(form.getFamilyIds()+")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwd.ProductKey in ( ").append(form.getProductIds()+")");
			}
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwd.Commodity in ( ").append(form.getComponents()+")");
			}
			sBuffer.append(" aNd mwd.GroupByType = 'Product'");
			sBuffer.append(" group by mwd.ProductKey,product.ProductEnglishName having mwd.ProductKey <> ''");
		}
		else if("Family".equals(form.getDashboardType())) {
			sBuffer.append("select  sum(price) as price,family.ProductFamilyKey as objKey, Family.ProductFamilyEnglishName as objName, 'Family' as type")
				   .append(" from FactWeeklySummaryofMWD mwd")
				   .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwd.month=d.month and mwd.year=d.year and mwd.StandardVersion=d.versionDate ")
			       .append(" left join DimPurchaseType pur on mwd.purchaseTypeKey = pur.purchaseTypeKey ")
		    	   .append(" left join DimProduct product on mwd.productKey = product.productKey")
		    	   .append(" inner join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey")
		    	   .append(" left join DimCommodityType com on mwd.Commodity = com.CommodityType");
			
	    	sBuffer.append(" where mwd.Year = ").append(form.getYear())
	    		   .append(" and mwd.Month = ").append(form.getMonth());
	    	if(form.getPurchaseTypeKey()!=-1) {
				sBuffer.append(" and mwd.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwd.EOL = '").append(form.getEol()+"'");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwd.regionKey in ( ").append(form.getGeoIds()+")");
			}
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwd.odmKey in ( ").append(form.getOdmIds()+")");
			}
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and product.ProductFamilyKey in ( ").append(form.getFamilyIds()+")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwd.ProductKey in ( ").append(form.getProductIds()+")");
			}
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwd.Commodity in ( ").append(form.getComponents()+")");
			}
			sBuffer.append(" aNd mwd.GroupByType = 'Product'");
			sBuffer.append(" group by family.ProductFamilyEnglishName,family.ProductFamilyKey ,mwd.purchaseTypeKey,pur.PurchaseType having family.ProductFamilyKey <> ''");
		}
		else if("Component".equals(form.getDashboardType())) {
			sBuffer.append("select  sum(price) as price,com.CommodityTypeKey as objKey, com.CommodityType as objName, 'Component' as type")
				   .append(" from FactWeeklySummaryofMWD mwd")
				   .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwd.month=d.month and mwd.year=d.year and mwd.StandardVersion=d.versionDate ")
			       .append(" left join DimPurchaseType pur on mwd.purchaseTypeKey = pur.purchaseTypeKey ")
		    	   .append(" left join DimProduct product on mwd.productKey = product.productKey")
		    	   .append(" left join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey")
		    	   .append(" inner join DimCommodityType com on mwd.Commodity = com.CommodityType");
			
	    	sBuffer.append(" where mwd.Year = ").append(form.getYear())
	    		   .append(" and mwd.Month = ").append(form.getMonth());
	    	if(form.getPurchaseTypeKey()!=-1) {
				sBuffer.append(" and mwd.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwd.EOL = '").append(form.getEol()+"'");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwd.regionKey in ( ").append(form.getGeoIds()+")");
			}
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwd.odmKey in ( ").append(form.getOdmIds()+")");
			}
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and product.ProductFamilyKey in ( ").append(form.getFamilyIds()+")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwd.ProductKey in ( ").append(form.getProductIds()+")");
			}
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwd.Commodity in ( ").append(form.getComponents()+")");
			}
			sBuffer.append(" aNd mwd.GroupByType = 'CV'");
			sBuffer.append(" group by com.CommodityType,com.CommodityTypeKey");
		}
		else if("w2w".equals(form.getDashboardType())) {
			//no dashboard
		}
		sBuffer.append(" order by sum(price) desc");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<MWDChartData> fetchMWDDashboardChartData(SearchMWDForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if("Region".equals(form.getDashboardType())) {
			sBuffer.append(" select sum(price) as price,mwd.purchaseTypeKey,pur.PurchaseType,geography.GeographyName as subDimesnionName")
				   .append(" from FactWeeklySummaryofMWD mwd ")
				   .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwd.month=d.month and mwd.year=d.year and mwd.StandardVersion=d.versionDate ")
				   .append(" inner join  DimPurchaseType pur on mwd.purchaseTypeKey = pur.purchaseTypeKey ")
				   .append(" left join DimProduct product on mwd.productKey = product.productKey")
				   .append(" left join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey")
				   .append(" left join DimCommodityType com on mwd.Commodity = com.CommodityType");
			sBuffer.append(" left join DimGeography geography on geography.GeographyKey = mwd.regionKey");
			sBuffer.append(" where geography.GeographyName = '").append(form.getSubDimension()).append("'");
			sBuffer.append(" and mwd.Year*100+mwd.Month = '").append(formatDate(form.getSelectMonth())).append("'");
			if(form.getPurchaseTypeKey()!=-1) {
				sBuffer.append(" and mwd.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwd.EOL = '").append(form.getEol()+"'");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwd.regionKey in ( ").append(form.getGeoIds()+")");
			}
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwd.odmKey in ( ").append(form.getOdmIds()+")");
			}
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and product.ProductFamilyKey in ( ").append(form.getFamilyIds()+")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwd.ProductKey in ( ").append(form.getProductIds()+")");
			}
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwd.Commodity in ( ").append(form.getComponents()+")");
			}
			sBuffer.append(" aNd mwd.GroupByType = 'Region'");
			sBuffer.append(" group by geography.GeographyName,geography.geographyKey,mwd.purchaseTypeKey,pur.PurchaseType ");
		}
		else if("Odm".equals(form.getDashboardType())) {
			sBuffer.append(" select sum(price) as price,mwd.purchaseTypeKey,pur.PurchaseType,odm.OdmEnglishName as subDimesnionName")
				   .append(" from FactWeeklySummaryofMWD mwd ")
				   .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwd.month=d.month and mwd.year=d.year and mwd.StandardVersion=d.versionDate ")
				   .append(" inner join DimPurchaseType pur on mwd.purchaseTypeKey = pur.purchaseTypeKey ")
				   .append(" left join DimProduct product on mwd.productKey = product.productKey")
				   .append(" left join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey")
				   .append(" left join DimCommodityType com on mwd.Commodity = com.CommodityType");
			
			sBuffer.append(" left join DimODM odm on mwd.ODMKey=odm.ODMKey ");
			sBuffer.append(" where mwd.ODMKey = '").append(form.getSubDimensionKey()).append("'");
			sBuffer.append(" and mwd.Year*100+mwd.Month = '").append(formatDate(form.getSelectMonth())).append("'");
			if(form.getPurchaseTypeKey()!=-1) {
				sBuffer.append(" and mwd.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwd.EOL = '").append(form.getEol()+"'");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwd.regionKey in ( ").append(form.getGeoIds()+")");
			}
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwd.odmKey in ( ").append(form.getOdmIds()+")");
			}
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and product.ProductFamilyKey in ( ").append(form.getFamilyIds()+")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwd.ProductKey in ( ").append(form.getProductIds()+")");
			}
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwd.Commodity in ( ").append(form.getComponents()+")");
			}
			sBuffer.append(" aNd mwd.GroupByType = 'CV'");
			sBuffer.append(" group by odm.OdmEnglishName,odm.ODMKey,mwd.purchaseTypeKey,pur.PurchaseType ");
		}
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append(" select sum(price) as price,mwd.purchaseTypeKey,pur.PurchaseType,product.productEnglishName as subDimesnionName")
				   .append(" from FactWeeklySummaryofMWD mwd ")
				   .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwd.month=d.month and mwd.year=d.year and mwd.StandardVersion=d.versionDate ")
				   .append(" inner join DimPurchaseType pur on mwd.purchaseTypeKey = pur.purchaseTypeKey ")
				   .append(" left join DimProduct product on mwd.productKey = product.productKey")
				   .append(" left join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey")
				   .append(" left join DimCommodityType com on mwd.Commodity = com.CommodityType");
		
			sBuffer.append(" where product.ProductKey = '").append(form.getSubDimensionKey()).append("'");
			sBuffer.append(" and mwd.Year*100+mwd.Month = '").append(formatDate(form.getSelectMonth())).append("'");
			if(form.getPurchaseTypeKey()!=-1) {
				sBuffer.append(" and mwd.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwd.EOL = '").append(form.getEol()+"'");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwd.regionKey in ( ").append(form.getGeoIds()+")");
			}
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwd.odmKey in ( ").append(form.getOdmIds()+")");
			}
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and product.ProductFamilyKey in ( ").append(form.getFamilyIds()+")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwd.ProductKey in ( ").append(form.getProductIds()+")");
			}
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwd.Commodity in ( ").append(form.getComponents()+")");
			}
			sBuffer.append(" aNd mwd.GroupByType = 'Product'");
			sBuffer.append(" group by product.productEnglishName,product.ProductKey,mwd.purchaseTypeKey,pur.PurchaseType ");
		}
		else if("Family".equals(form.getDashboardType())) {
			sBuffer.append(" select sum(price) as price,mwd.purchaseTypeKey,pur.PurchaseType,family.productFamilyEnglishName as subDimesnionName")
				   .append(" from FactWeeklySummaryofMWD mwd ")
				   .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwd.month=d.month and mwd.year=d.year and mwd.StandardVersion=d.versionDate ")
				   .append(" inner join DimPurchaseType pur on mwd.purchaseTypeKey = pur.purchaseTypeKey ")
				   .append(" left join DimProduct product on mwd.productKey = product.productKey")
				   .append(" left join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey")
				   .append(" left join DimCommodityType com on mwd.Commodity = com.CommodityType");
			
			sBuffer.append(" where family.ProductFamilyKey = '").append(form.getSubDimensionKey()).append("'");
			sBuffer.append(" and mwd.Year*100+mwd.Month = '").append(formatDate(form.getSelectMonth())).append("'");
			if(form.getPurchaseTypeKey()!=-1) {
				sBuffer.append(" and mwd.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwd.EOL = '").append(form.getEol()+"'");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwd.regionKey in ( ").append(form.getGeoIds()+")");
			}
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwd.odmKey in ( ").append(form.getOdmIds()+")");
			}
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and product.ProductFamilyKey in ( ").append(form.getFamilyIds()+")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwd.ProductKey in ( ").append(form.getProductIds()+")");
			}
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwd.Commodity in ( ").append(form.getComponents()+")");
			}
			sBuffer.append(" aNd mwd.GroupByType = 'Product'");
			sBuffer.append(" group by family.productFamilyEnglishName,family.ProductFamilyKey,mwd.purchaseTypeKey,pur.PurchaseType ");
		}
		else if("Component".equals(form.getDashboardType())) {
			sBuffer.append(" select sum(price) as price,mwd.purchaseTypeKey,pur.PurchaseType,com.CommodityType as subDimesnionName")
				   .append(" from FactWeeklySummaryofMWD mwd ")
				   .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwd.month=d.month and mwd.year=d.year and mwd.StandardVersion=d.versionDate ")
				   .append(" inner join DimPurchaseType pur on mwd.purchaseTypeKey = pur.purchaseTypeKey ")
				   .append(" left join DimProduct product on mwd.productKey = product.productKey")
				   .append(" left join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey")
				   .append(" left join DimCommodityType com on mwd.Commodity = com.CommodityType");
			
			sBuffer.append(" where com.CommodityType = '").append(form.getSubDimension()).append("'");
			sBuffer.append(" and mwd.Year*100+mwd.Month = '").append(formatDate(form.getSelectMonth())).append("'");
			if(form.getPurchaseTypeKey()!=-1) {
				sBuffer.append(" and mwd.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
			}
			if(!"-1".equals(form.getEol())) {
				sBuffer.append(" and mwd.EOL = '").append(form.getEol()+"'");
			}
			if(StringUtils.isNotBlank(form.getGeoIds())){
				sBuffer.append(" and mwd.regionKey in ( ").append(form.getGeoIds()+")");
			}
			if(StringUtils.isNotBlank(form.getOdmIds())){
				sBuffer.append(" and mwd.odmKey in ( ").append(form.getOdmIds()+")");
			}
			if(StringUtils.isNotBlank(form.getFamilyIds())){
				sBuffer.append(" and product.ProductFamilyKey in ( ").append(form.getFamilyIds()+")");
			}
			if(StringUtils.isNotBlank(form.getProductIds())){
				sBuffer.append(" and mwd.ProductKey in ( ").append(form.getProductIds()+")");
			}
			if(StringUtils.isNotBlank(form.getComponents())){
				sBuffer.append(" and mwd.Commodity in ( ").append(form.getComponents()+")");
			}
			sBuffer.append(" aNd mwd.GroupByType = 'CV'");
			sBuffer.append(" group by com.CommodityType,mwd.purchaseTypeKey,pur.PurchaseType ");
		}
		
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("subDimesnionName", StringType.INSTANCE)
				.addScalar("price", FloatType.INSTANCE)
				.addScalar("purchaseType", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(MWDChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MWDChartData> fetchMWDCrossMonthOverviewChartData(
			SearchMWDForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append(" select sum(price) as price ,mwdSummary.year,mwdSummary.month,mwdSummary.purchaseTypeKey,pur.PurchaseType")
			   .append(" from FactWeeklySummaryofMWD mwdSummary ")
		       .append(" join ( select year,month, max(StandardVersion) as versionDate from FactWeeklySummaryofMWD  group by year,month) d  on  mwdSummary.month=d.month and mwdSummary.year=d.year and mwdSummary.StandardVersion=d.versionDate ")
		       .append(" join  DimPurchaseType pur on mwdSummary.purchaseTypeKey = pur.purchaseTypeKey ");
			 
		sBuffer.append(" left join DimProduct product on mwdSummary.ProductKey = product.ProductKey")
		       .append(" left join (")
		       .append("select product.ProductKey as productKey,family.ProductFamilyKey as familyKey,family.ProductFamilyEnglishName") 
		       .append(" from DimProduct product")
	           .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
		       .append(")productFamily on mwdSummary.ProductKey = productFamily.ProductKey");
		
		sBuffer.append(" left join DimODM odm on mwdSummary.ODMKey=odm.ODMKey ");
	
		sBuffer.append(" left join ( ")
        	   .append(" select region.geographyname as regionName,region.GeographyKey as regionKey ,geography.NormalizedGeo as geoName from DimGeography region ")
               .append("	left join FactGeoListMapping geography on region.geographyname=geography.NormalizedSubgeo where region.GeographyType='Region' ) geography ")
               .append(" on  mwdSummary.regionKey=geography.regionKey ");	
	
		sBuffer.append(" where mwdSummary.Year*100+mwdSummary.Month between '")
		       .append(formatDate(form.getStartDate())).append("'")
               .append(" and '").append(formatDate(form.getEndDate())).append("'");	   
		
		if(form.getPurchaseTypeKey()!=-1) {//以后有可能是in
			sBuffer.append(" and mwdSummary.purchaseTypeKey = ").append(form.getPurchaseTypeKey());
		}
		
		if(!"-1".equals(form.getEol())) {
			sBuffer.append(" and mwdSummary.EOL = '").append(form.getEol()+"'");
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sBuffer.append(" and mwdSummary.regionKey in ( ").append(form.getGeoIds()+")");
		}
		
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sBuffer.append(" and mwdSummary.odmKey in ( ").append(form.getOdmIds()+")");
		}
		
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sBuffer.append(" and productFamily.familyKey in ( ").append(form.getFamilyIds()+")");
		}
		
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and mwdSummary.ProductKey in ( ").append(form.getProductIds()+")");
		}
		
		if(StringUtils.isNotBlank(form.getComponents())){
			sBuffer.append(" and mwdSummary.Commodity in ( ").append(getComponents(form.getComponents())+")");
		}
		
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and geography.RegionName = '").append(form.getSubDimension()+"'");
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and mwdSummary.ODMKey = ").append(form.getSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and mwdSummary.ProductKey = ").append(form.getSubDimensionKey());
		}
		
		else if("Component".equals(form.getDimension())) {
			sBuffer.append(" and mwdSummary.Commodity = '").append(form.getSubDimension()+"'");
		}
		
		else if("Family".equals(form.getDimension())) {
			sBuffer.append(" and productFamily.familyKey = ").append(form.getSubDimensionKey());
		}
		
		sBuffer.append(" aNd mwdSummary.GroupByType = 'Detail'");
		sBuffer.append(" group by mwdSummary.YEAR, mwdSummary.MONTH,mwdSummary.purchaseTypeKey,pur.PurchaseType ");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("year", IntegerType.INSTANCE)
				.addScalar("month", IntegerType.INSTANCE)
				.addScalar("price", FloatType.INSTANCE)
				.addScalar("purchaseType", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(MWDChartData.class));
		
		return query.list();
	}

	private StringBuilder generateMWDDetailFromAndWhereSql(SearchMWDForm form){
		String year = form.getStartDate().substring(0, 4);
		String month = form.getStartDate().substring(5, 7);
		if(month.startsWith("0")){
			month = month.substring(1);
		}
		
		StringBuilder sb  = new StringBuilder(" from FactWeeklySummaryofMWD m ");
		sb.append("left join dimodm odm on odm.ODMKey = m.ODMKey ")
		.append("left join dimproduct p on p.ProductKey = m.Productkey ")
		.append("left join DimProductFamily f on f.ProductFamilyKey = p.ProductFamilyKey ")
		.append("left join dimPurchaseType pt on pt.PurchaseTypeKey = m.PurchaseTypeKey ")
		.append("left join DimGeography r on r.GeographyKey = m.RegionKey ")
		.append("left join FactGeoListMapping g on r.geographyname=g.NormalizedSubgeo ")
		.append("where ")
		.append(" pt.PurchaseType='").append(form.getPurchaseType()).append("' ");
		if(StringUtils.isNotBlank(form.getEol())){
			sb.append(" and m.eol='").append(form.getEol()).append("' ");
		}
		if(StringUtils.isNotBlank(form.getDimension())&&StringUtils.isNotBlank(form.getDimensionKey())){
				if("Region".equals(form.getDimension())){
					sb.append(" and r.GeographyName ='").append(form.getDimensionKey()).append("' ");
					sb.append(" aNd m.GroupByType = 'Detail'");
				}
				else if("Odm".equals(form.getDimension())){
					sb.append(" and ODMEnglishName='").append(form.getDimensionKey()).append("' ");	
					sb.append(" aNd m.GroupByType = 'Detail'");
				}
				else if("Product".equals(form.getDimension())){
					sb.append(" and ProductEnglishName='").append(form.getDimensionKey()).append("' ");
					sb.append(" aNd m.GroupByType = 'Detail'");
				}
				else if("Component".equals(form.getDimension())){
					sb.append(" and m.Commodity='").append(form.getDimensionKey()).append("' ");
					sb.append(" aNd m.GroupByType = 'Detail'");
				}
				else if("Family".equals(form.getDimension())){
					sb.append(" and f.ProductFamilyEnglishName='").append(form.getDimensionKey()).append("' ");
					sb.append(" aNd m.GroupByType = 'Detail'");
				}
				
		}
		if(StringUtils.isNotBlank(form.getSubDimension())&&StringUtils.isNotBlank(form.getSubKey())){
			if("w2w".equals(form.getSubDimension()) && "Last_Week".equals(form.getSubKey())){
				sb.append(" and m.StandardVersion =(select max(StandardVersion) from FactWeeklySummaryofMWD where StandardVersion<(select max(StandardVersion) from FactWeeklySummaryofMWD ")
				.append(" where year =  ").append(year).append(" and month = ").append(month).append(" ))")
				.append(" and m.year = ").append(year).append(" and m.month=").append(month);
				
				sb.append(" aNd m.GroupByType = 'Detail'");
			}else{
				sb.append(" and m.StandardVersion = (select max(StandardVersion) from FactWeeklySummaryofMWD ")
				.append("where year =  ").append(year).append(" and month = ").append(month).append(" ) ")
				.append(" and m.year = ").append(year).append(" and m.month=").append(month);
				if("Region".equals(form.getSubDimension())){
					sb.append(" and r.GeographyName ='").append(form.getSubKey()).append("' ");
				}
				else if("Odm".equals(form.getSubDimension())){
					sb.append(" and ODMEnglishName='").append(form.getSubKey()).append("' ");	
				}
				else if("Product".equals(form.getSubDimension())){
					sb.append(" and ProductEnglishName='").append(form.getSubKey()).append("' ");
				}
				else if("Component".equals(form.getSubDimension())){
					sb.append(" and m.Commodity='").append(form.getSubKey()).append("' ");
				}
				else if("Family".equals(form.getSubDimension())){
					sb.append(" and f.ProductFamilyEnglishName='").append(form.getSubKey()).append("' ");
				}
				sb.append(" aNd m.GroupByType = 'Detail'");
			}
		}else{
			sb.append(" and m.StandardVersion = (select max(StandardVersion) from FactWeeklySummaryofMWD ")
			.append("where year =  ").append(year).append(" and month = ").append(month)
			.append(" ) ")
			.append(" and m.year = ").append(year).append(" and m.month=").append(month);
			
//			if(StringUtils.isNotBlank(form.getDimension()) && StringUtils.isNotBlank(form.getDimensionKey())){
//				sb.append(" aNd m.GroupByType = 'CV'");
//			}else{
//				sb.append(" aNd m.GroupByType = 'Detail'");
//			}
			
			//TODO
			//comments modified on 2015-10-28 4:48pm
			//reasion: can not display all the detail records
			/*
			if(StringUtils.isNotBlank(form.getDimension()) && StringUtils.isNotBlank(form.getDimensionKey())){
//				sb.append(" aNd B.LenovoCommodityValue is null ");
				sb.append("aNd m.odmmwdkey in (select id from  FactWeeklyODMMWD  where LenovoCommodityValue is null)");
			}else{
//				sb.append(" aNd B.LenovoCommodityValue is not null ");
				sb.append("aNd m.odmmwdkey in (select id from  FactWeeklyODMMWD  where LenovoCommodityValue is not null)");
			}
			*/
			sb.append(" aNd m.GroupByType = 'Detail'");
			
		}
		if(StringUtils.isNotBlank(form.getComponents())){
			sb.append(" and m.Commodity in(").append(form.getComponents()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sb.append(" and p.ProductFamilyKey in(").append(form.getFamilyIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and m.ODMKey in(").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and m.RegionKey in(").append(form.getGeoIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and m.Productkey in(").append(form.getProductIds()).append(") ");
		}
		return sb;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<MWDDetailView> getMWDDetail(SearchMWDForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append("(select top ").append(form.getRowCount()).append(" * from ");
		sql.append("(select  top ").append(form.getEndRow());
		sql.append(" ODMEnglishName as odm,r.GeographyName as region,g.NormalizedGeo as geo,ProductEnglishName as product,pt.PurchaseType as  purchaseType,");
		sql.append(" m.Commodity as commodity,m.CommodityValue as description,m.EOL as eol,m.StandardHighlightTime as highLightDate,");
		sql.append(" m.Aging as aging,m.Price as mwd,m.Remark as remark ");
		sql.append(this.generateMWDDetailFromAndWhereSql(form));
		
		/*
		if(StringUtils.isNotBlank(form.getSortColumn()) && !"MWD".equalsIgnoreCase(form.getSortColumn())){
			sql.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(", mwd ").append(form.getSortType()).append(" ) t");
		}else{
			sql.append(" order by mwd ").append(form.getSortType());
			sql.append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn()) && !"MWD".equalsIgnoreCase(form.getSortColumn())){
			sql.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(", mwd ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sql.append(" order by mwd ").append(form.getReversalSortType());
			sql.append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn()) && !"MWD".equalsIgnoreCase(form.getSortColumn())){
			sql.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
				.append(", mwd ").append(form.getSortType());
		}else{
			sql.append(" order by mwd ").append(form.getSortType());
		}
		 */
		String sortSql = getSortSql(form.getSortColumn(), form.getSortType());
		if(StringUtils.isBlank(form.getSortColumn())){
			form.setReversalSortType("desc");
		}
		String reversalSortSql = getSortSql(form.getSortColumn(), form.getReversalSortType());
		sql.append(sortSql);
		sql.append(" ) t");
		sql.append(reversalSortSql);
		sql.append(" ) tt");
		sql.append(sortSql);
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("commodity", StringType.INSTANCE)
				.addScalar("purchaseType", StringType.INSTANCE)
				.addScalar("eol", StringType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.addScalar("highLightDate", DateType.INSTANCE)
				.addScalar("aging", StringType.INSTANCE)
				.addScalar("remark", StringType.INSTANCE)
				.addScalar("mwd", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(MWDDetailView.class));
		return query.list();
	}

	private String getSortSql(String sortColumn, String sortType){
		StringBuilder sortSql = new StringBuilder();
		sortSql.append(" order by ");
		if(StringUtils.isNotBlank(sortColumn)){
			sortSql.append(sortColumn).append(" ").append(sortType).append(",");
		}
		String[] sortColumns = {"odm", "geo", "region", "product", "commodity", "description"};
		for(String column : sortColumns){
			if(sortColumn.equalsIgnoreCase(column)){
				continue;
			}else{
				sortSql.append(column).append(" ").append(sortType).append(",");
			}
		}
		return sortSql.toString().substring(0, sortSql.length()-1);
	}
	
	@Override
	public long getMWDDetailCount(SearchMWDForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(*) ");
		sql.append(this.generateMWDDetailFromAndWhereSql(form));
		Query query = getSession().createSQLQuery(sql.toString());
		Object result = query.uniqueResult();
		if(result != null){
			return Long.parseLong(result.toString());
		}else{
			return 0;
		}
	}
	
	public static String getComponents(String str){
		String[]arr=str.split(",");
		for(int i=0;i<arr.length;i++){
			arr[i]="'"+arr[i]+"'";
		}
		List<String>list=Arrays.asList(arr);
		String con=list.toString();
		return con.substring(1, con.length()-1);
	}
	
	@Override
	public Date getMRPRunTime() {
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append(" select MAX(StandardVersion) from FactWeeklySummaryofMWD ");
		Query q=getSession().createSQLQuery(sBuffer.toString());
		return (Date) q.uniqueResult();
	}
}
