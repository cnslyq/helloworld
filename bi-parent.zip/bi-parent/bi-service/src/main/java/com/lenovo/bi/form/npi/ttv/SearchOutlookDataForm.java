package com.lenovo.bi.form.npi.ttv;

import java.util.Date;

import com.lenovo.bi.enumobj.TimeFrequencyEnum;
import com.lenovo.bi.form.npi.SearchBase;

public class SearchOutlookDataForm extends SearchBase {

	private Date startDate;
	private Date endDate;
	private String fpy;
	private TimeFrequencyEnum frequency;
	private int waveId;
	private String parentType; // Detractor
								// type:Supply,Over_SP,Fulfillment,Other,Future
	private String childType; // it is the child type from above

	private String ttvTargetDate;
	private String ttvSignOffDate;
	private String ttmTargetDate;
	private String ttmSignOffDate;

	private boolean isSignOff;
	private int productId;

	private String sortColumn;
	private String sortType;

	private Date versionDate;
	private boolean showSgaOrSle;
	private String sgaOrSle;
	private String detractorCodeType;

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public TimeFrequencyEnum getFrequency() {
		return frequency;
	}

	public void setFrequency(TimeFrequencyEnum frequency) {
		this.frequency = frequency;
	}

	public int getWaveId() {
		return waveId;
	}

	public void setWaveId(int waveId) {
		this.waveId = waveId;
	}

	public String getFpy() {
		return fpy;
	}

	public void setFpy(String fpy) {
		this.fpy = fpy;
	}

	public String getParentType() {
		return parentType;
	}

	public void setParentType(String parentType) {
		this.parentType = parentType;
	}

	public String getChildType() {
		return childType;
	}

	public void setChildType(String childType) {
		this.childType = childType;
	}

	public String getTtvTargetDate() {
		return ttvTargetDate;
	}

	public void setTtvTargetDate(String ttvTargetDate) {
		this.ttvTargetDate = ttvTargetDate;
	}

	public String getTtvSignOffDate() {
		return ttvSignOffDate;
	}

	public void setTtvSignOffDate(String ttvSignOffDate) {
		this.ttvSignOffDate = ttvSignOffDate;
	}

	public boolean isSignOff() {
		return isSignOff;
	}

	public void setSignOff(boolean isSignOff) {
		this.isSignOff = isSignOff;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getTtmTargetDate() {
		return ttmTargetDate;
	}

	public void setTtmTargetDate(String ttmTargetDate) {
		this.ttmTargetDate = ttmTargetDate;
	}

	public String getTtmSignOffDate() {
		return ttmSignOffDate;
	}

	public void setTtmSignOffDate(String ttmSignOffDate) {
		this.ttmSignOffDate = ttmSignOffDate;
	}

	public boolean isShowSgaOrSle() {
		return showSgaOrSle;
	}

	public void setShowSgaOrSle(boolean showSgaOrSle) {
		this.showSgaOrSle = showSgaOrSle;
	}

	public String getSgaOrSle() {
		return sgaOrSle;
	}

	public void setSgaOrSle(String sgaOrSle) {
		this.sgaOrSle = sgaOrSle;
	}

	public String getDetractorCodeType() {
		return detractorCodeType;
	}

	public void setDetractorCodeType(String detractorCodeType) {
		this.detractorCodeType = detractorCodeType;
	}
}
