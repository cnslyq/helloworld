package com.lenovo.bi.form.sc.fa;

import org.apache.commons.lang.StringUtils;

import com.lenovo.common.model.PagerInformation;

public class SearchFaForm {
	private int year;
	private int month;
	private String startDate;
	private String endDate;
	private String selectMonth;
	private String componentTypes; // Mps,GrossForecast, outlook
	private String geoIds;

	private String dimension;
	private int dimensionKey = -1;
	private String subDimension;
	private int subDimensionKey = -1;
	private int geoKey = -1;// switch dashboard chart between geo and region

	private String durationFrom;
	private String durationTo;

	private String chartType;// overview,dashboard,crossmonth
	private PagerInformation pagerInfo;
	
	private String purchaseTypeId;
	private String cType;
	private String vValue;
	
	private String faComponentType;
	private String faType;
	private String orderTypeName;
	
	private String ltfcType;
	
	private String dashboardType;
	private int dashboardTypeKey = -1;
	private String crossMonthType;
	private int crossMonthTypeKey = -1;
	
	private boolean showGeoOverview;// or region overview
	
	private String odmIds;
	private String productIds;
	private String familyIds;
	private String regionIds;
	
	private String pageType;
	private String reversalSortType;
	private String versionDate;
	
	private String ltfcVersion;
	private String mpsVersion;
	private String sortColumn;
	private String sortType;
	
	private String remarkDimension;
	private String overViewDimension;
	private String remarkSubDimension;
	private int remarkSubDimensionKey=-1;
	private int overViewSubDimensionKey=-1; 
	private int endRow;
	private long rowCount;
	private int currentPage;
	private boolean showOverall;
	private String rootCause;
	private String keyValue;
	private String componentIds;
	private String GEO;
	private String crossMonthTypeValue;
	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public String getFaComponentType() {
		return faComponentType;
	}

	public void setFaComponentType(String faComponentType) {
		this.faComponentType = faComponentType;
	}

	public PagerInformation getPagerInfo() {
		return pagerInfo;
	}

	public void setPagerInfo(PagerInformation pagerInfo) {
		this.pagerInfo = pagerInfo;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getSelectMonth() {
		return selectMonth;
	}

	public void setSelectMonth(String selectMonth) {
		this.selectMonth = selectMonth;
	}

	public String getComponentTypes() {
		return componentTypes;
	}

	public void setComponentTypes(String componentTypes) {
		this.componentTypes = componentTypes;
	}

	public String getGeoIds() {
		return geoIds;
	}

	public void setGeoIds(String geoIds) {
		this.geoIds = geoIds;
	}

	public String getDimension() {
		return dimension;
	}

	public void setDimension(String dimension) {
		this.dimension = dimension;
	}

	public int getDimensionKey() {
		return dimensionKey;
	}

	public void setDimensionKey(int dimensionKey) {
		this.dimensionKey = dimensionKey;
	}

	public String getSubDimension() {
		return subDimension;
	}

	public void setSubDimension(String subDimension) {
		this.subDimension = subDimension;
	}

	public int getSubDimensionKey() {
		return subDimensionKey;
	}

	public void setSubDimensionKey(int subDimensionKey) {
		this.subDimensionKey = subDimensionKey;
	}

	public int getGeoKey() {
		return geoKey;
	}

	public void setGeoKey(int geoKey) {
		this.geoKey = geoKey;
	}

	public String getDurationFrom() {
		return durationFrom;
	}

	public void setDurationFrom(String durationFrom) {
		this.durationFrom = durationFrom;
	}

	public String getDurationTo() {
		return durationTo;
	}

	public void setDurationTo(String durationTo) {
		this.durationTo = durationTo;
	}

	public String getChartType() {
		return chartType;
	}

	public void setChartType(String chartType) {
		this.chartType = chartType;
	}

	public String getPurchaseTypeId() {
		return purchaseTypeId;
	}

	public void setPurchaseTypeId(String purchaseTypeId) {
		this.purchaseTypeId = purchaseTypeId;
	}

	public String getcType() {
		return cType;
	}

	public void setcType(String cType) {
		this.cType = cType;
	}

	public String getvValue() {
		return vValue;
	}

	public void setvValue(String vValue) {
		this.vValue = vValue;
	}

	public String getFaType() {
		return faType;
	}

	public void setFaType(String faType) {
		this.faType = faType;
	}

	public String getOrderTypeName() {
		return orderTypeName;
	}

	public void setOrderTypeName(String orderTypeName) {
		this.orderTypeName = orderTypeName;
	}

	public String getDashboardType() {
		return dashboardType;
	}

	public void setDashboardType(String dashboardType) {
		this.dashboardType = dashboardType;
	}

	public int getDashboardTypeKey() {
		return dashboardTypeKey;
	}

	public void setDashboardTypeKey(int dashboardTypeKey) {
		this.dashboardTypeKey = dashboardTypeKey;
	}

	public String getCrossMonthType() {
		return crossMonthType;
	}

	public void setCrossMonthType(String crossMonthType) {
		this.crossMonthType = crossMonthType;
	}

	public int getCrossMonthTypeKey() {
		return crossMonthTypeKey;
	}

	public void setCrossMonthTypeKey(int crossMonthTypeKey) {
		this.crossMonthTypeKey = crossMonthTypeKey;
	}

	public boolean isShowGeoOverview() {
		return showGeoOverview;
	}

	public void setShowGeoOverview(boolean showGeoOverview) {
		this.showGeoOverview = showGeoOverview;
	}

	public String getOdmIds() {
		return odmIds;
	}

	public void setOdmIds(String odmIds) {
		this.odmIds = odmIds;
	}

	public String getProductIds() {
		return productIds;
	}

	public void setProductIds(String productIds) {
		this.productIds = productIds;
	}

	public String getFamilyIds() {
		return familyIds;
	}

	public void setFamilyIds(String familyIds) {
		this.familyIds = familyIds;
	}

	public String getRegionIds() {
		return regionIds;
	}

	public void setRegionIds(String regionIds) {
		this.regionIds = regionIds;
	}

	public String getPageType() {
		return pageType;
	}

	public void setPageType(String pageType) {
		this.pageType = pageType;
	}

	public void setReversalSortType(String reversalSortType) {
		this.reversalSortType = reversalSortType;
	}

	public String getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(String versionDate) {
		this.versionDate = versionDate;
	}
	

	public String getLtfcType() {
		return ltfcType;
	}

	public void setLtfcType(String ltfcType) {
		this.ltfcType = ltfcType;
	}

	public String getLtfcVersion() {
		return ltfcVersion;
	}

	public void setLtfcVersion(String ltfcVersion) {
		this.ltfcVersion = ltfcVersion;
	}

	public String getMpsVersion() {
		return mpsVersion;
	}

	public void setMpsVersion(String mpsVersion) {
		this.mpsVersion = mpsVersion;
	}

	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public int getEndRow() {
		return endRow;
	}

	public void setEndRow(int endRow) {
		this.endRow = endRow;
	}

	public long getRowCount() {
		return rowCount;
	}

	public void setRowCount(long rowCount) {
		this.rowCount = rowCount;
	}

	public String getRemarkDimension() {
		return remarkDimension;
	}

	public void setRemarkDimension(String remarkDimension) {
		this.remarkDimension = remarkDimension;
	}

	public String getOverViewDimension() {
		return overViewDimension;
	}

	public void setOverViewDimension(String overViewDimension) {
		this.overViewDimension = overViewDimension;
	}

	public int getOverViewSubDimensionKey() {
		return overViewSubDimensionKey;
	}

	public void setOverViewSubDimensionKey(int overViewSubDimensionKey) {
		this.overViewSubDimensionKey = overViewSubDimensionKey;
	}

	public String getRemarkSubDimension() {
		return remarkSubDimension;
	}

	public void setRemarkSubDimension(String remarkSubDimension) {
		this.remarkSubDimension = remarkSubDimension;
	}

	public int getRemarkSubDimensionKey() {
		return remarkSubDimensionKey;
	}

	public void setRemarkSubDimensionKey(int remarkSubDimensionKey) {
		this.remarkSubDimensionKey = remarkSubDimensionKey;
	}
	
	public String getReversalSortType() {
		if(StringUtils.isNotBlank(this.sortType)){
			if("asc".equals(this.sortType.toLowerCase())){
				return "desc";
			}else{
				return "asc";
			}
		}else{
			return "desc";
		}
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public boolean isShowOverall() {
		return showOverall;
	}

	public void setShowOverall(boolean showOverAll) {
		this.showOverall = showOverAll;
	}

	public String getRootCause() {
		return rootCause;
	}

	public void setRootCause(String rootCause) {
		this.rootCause = rootCause;
	}

	public String getKeyValue() {
		return keyValue;
	}

	public void setKeyValue(String keyValue) {
		this.keyValue = keyValue;
	}

	public String getComponentIds() {
		return componentIds;
	}

	public void setComponentIds(String componentIds) {
		this.componentIds = componentIds;
	}

	public String getGEO() {
		return GEO;
	}

	public void setGEO(String gEO) {
		GEO = gEO;
	}

	public String getCrossMonthTypeValue() {
		return crossMonthTypeValue;
	}

	public void setCrossMonthTypeValue(String crossMonthTypeValue) {
		this.crossMonthTypeValue = crossMonthTypeValue;
	}
	
}
