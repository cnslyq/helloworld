package com.lenovo.bi.form.simulation;

public class CVSupply {
	private int globalCVKey;
	private int commitment;
	public int getGlobalCVKey() {
		return globalCVKey;
	}
	public void setGlobalCVKey(int globalCVKey) {
		this.globalCVKey = globalCVKey;
	}
	public int getCommitment() {
		return commitment;
	}
	public void setCommitment(int commitment) {
		this.commitment = commitment;
	}
}
