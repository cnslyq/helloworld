package com.lenovo.bi.service.npi.impl;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.npi.NPIDefectDao;
import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.service.npi.NPIDefectService;
/**
 * 
 * 
 * @author henry_lian
 *
 */
@Service
@Transactional("dw")
public class NPIDefectServiceImpl implements NPIDefectService{

	@Inject
	private NPIDefectDao nPIDefectDao;
	
	@Override
	public List<Defect> getGatingDefectsByProductWave(int waveId,
			Date targetDate, Date versionDate) {
		
		return nPIDefectDao.getGatingDefectsByProductWave(waveId, targetDate, versionDate);
	}

	@Override
	public List<Defect> getOOBDefectsByProductWave(int waveId, Date targetDate,
			Date versionDate) {
		
		return nPIDefectDao.getOOBDefectsByProductWave(waveId, targetDate, versionDate);
	}

	@Override
	public List<Defect> getNonOOBDefectsByProductWave(int waveId,
			Date targetDate, Date versionDate) {
		
		return nPIDefectDao.getNonOOBDefectsByProductWave(waveId, targetDate, versionDate);
	}

	@Override
	public List<Defect> getGatingDefectsByProductWave(int waveId, Date targetDate) {
		
		return nPIDefectDao.getGatingDefectsByProductWave(waveId, targetDate);
	}

	@Override
	public List<Defect> getOOBDefectsByProductWave(int waveId, Date targetDate) {
		
		return nPIDefectDao.getOOBDefectsByProductWave(waveId, targetDate);
	}

	@Override
	public List<Defect> getNonOOBDefectsByProductWave(int waveId, Date targetDate) {
		
		return nPIDefectDao.getNonOOBDefectsByProductWave(waveId, targetDate);
	}

}
