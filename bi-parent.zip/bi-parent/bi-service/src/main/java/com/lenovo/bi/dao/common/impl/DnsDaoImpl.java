package com.lenovo.bi.dao.common.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.DnsEntry;
import com.lenovo.bi.dto.NpiDnsEntry;

@Repository
public class DnsDaoImpl extends HibernateBaseDaoImplDw {
	public List<DnsEntry> getAllDnsEntriesInWeekForVersionDate(Date targetDate,
			Date versionDate) {
		// ENGINE

		StringBuilder sql = new StringBuilder(
				"select fwd.GlobalCVKey as cvKey, fsds.Code as shortageCode,")
				.append("case when fwd.DemandQty is null then 0 else fwd.DemandQty end as demand,")
				.append("case when fwd.SupplyQty is null then 0 else fwd.SupplyQty end as supply,")
				.append("case when fwd.NormalQty is null then 0 else fwd.NormalQty end as normalQuantity,")
				.append("case when fwd.UpsideQty is null then 0 else fwd.UpsideQty end as upsideQuantity ")
				.append("from FactWeeklyDNS fwd, FactSummaryOfDNSShortage fsds, DimTime t1, DimTime t2, DimTime t3, DimTime t4, ")
				.append("(select MAX(VersionDateKey) as versiondate from FactSummaryofDNSShortage fsd, DimTime t1 ")
				.append("where t1.TimeKey = fsd.VersionDateKey and datediff(day, t1.FullDateAlternateKey, ?) >= 0) d")
				.append(" where fwd.GlobalCVKey = fsds.GlobalCVKey ")
				.append(" and fwd.VersionDateKey = fsds.VersionDateKey ")
				.append(" and fsds.VersionDateKey = d.versiondate ")
				.append("and fwd.TargetDateKey = t1.TimeKey ")
				.append("and fwd.VersionDateKey = t2.TimeKey ")
				.append("and fsds.TargetMonthKey = t3.TimeKey ")
				.append("and fsds.VersionDateKey = t4.TimeKey ")
				.append("and datediff(day, t1.FullDateAlternateKey, ?) = 0 ")
				.append("and t1.CalendarYear = t3.CalendarYear ")
				.append("and t1.CalendarMonth = t3.CalendarMonth ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(DnsEntry.class));
		query.setParameter(0, versionDate);
		query.setParameter(1, targetDate);
		@SuppressWarnings("unchecked")
		List<DnsEntry> dnsEntryList = query.list();

		return dnsEntryList;
	}

	public List<NpiDnsEntry> getDnsList(Date versionDate, Integer cvKey) {

		// TODO Auto-generated method stub
		StringBuilder sql = new StringBuilder("  select ")
				.append(" fwd.GlobalCVKey as cvKey,fwd.DemandQty as demand,fwd.SupplyQty as supply ,fwd.DeltaQty as delta , asd.BizMonth as bizMonth,asd.BizWeek  as bizWeek ,asd.BizYear  as bizYear,fwd.versionDateKey as versionDateKey ,fwd.targetDateKey as targetDateKey from FactWeeklyDNS")
				.append(" fwd")
				.append(" inner join ")
				.append(" (select top 13 * from FactBizCalendarMapping where ID > =")
				.append(" (select top 1 id from FactBizCalendarMapping calen join ")
				.append(" (select bizmonth,bizyear from FactBizCalendarMapping where ShipDateKey=:versionDate) calen2")
				.append(" on calen.bizyear = calen2.bizyear and calen.bizmonth = calen2.bizmonth")
				.append("  )")
				.append(" ) as asd")
				.append(" on fwd.TargetDateKey = asd.ShipDateKey")
				.append(" where fwd.VersionDateKey=:versionDate")
				.append(" and fwd.GlobalCVKey = :cvKey")
				.append(" order by asd.BizYear,asd.BizMonth,asd.BizWeek");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(NpiDnsEntry.class));
		// query.setString("versionDate", "20121112");
		query.setInteger("cvKey", cvKey);
		query.setString("versionDate",
				new SimpleDateFormat("yyyyMMdd").format(versionDate));
		@SuppressWarnings("unchecked")
		List<NpiDnsEntry> dnsEntryList = query.list();
		return dnsEntryList;
	}

	public List<Integer> getDnsCvKeyList(Date versionDate) {
		// TODO Auto-generated method stub
		StringBuilder sql = new StringBuilder("	select ")
				.append(" distinct fwd.GlobalCVKey  from FactWeeklyDNS")
				.append(" fwd")
				.append(" inner join ")
				.append(" (select top 13 * from FactBizCalendarMapping where ID > =")
				.append(" (select top 1 id from FactBizCalendarMapping calen join ")
				.append(" (select bizmonth,bizyear from FactBizCalendarMapping where ShipDateKey=:versionDate) calen2")
				.append(" on calen.bizyear = calen2.bizyear and calen.bizmonth = calen2.bizmonth")
				.append("  )")
				.append(" ) as asd")
				.append(" on fwd.TargetDateKey = asd.ShipDateKey")
				.append(" where fwd.VersionDateKey=:versionDate");
		Query query = getSession().createSQLQuery(sql.toString());
		// query.setString("versionDate", "20121112");
		query.setString("versionDate",
				new SimpleDateFormat("yyyyMMdd").format(versionDate));
		@SuppressWarnings("unchecked")
		List<Integer> cvKeyList = query.list();
		return cvKeyList;
	}
	
	public Date getDnsVersionDate(Date versionDate){
		StringBuffer sql = new StringBuffer();
		sql.append(" select cast(cast(max(VersionDateKey) as varchar) as date) from FactWeeklyDNS ");
		sql.append(" where VersionDateKey <= :versionDate ");
		Query query = getSession().createSQLQuery(sql.toString());
		query.setString("versionDate", new SimpleDateFormat("yyyyMMdd").format(versionDate));
		return (Date) query.uniqueResult();
	}
	
}
