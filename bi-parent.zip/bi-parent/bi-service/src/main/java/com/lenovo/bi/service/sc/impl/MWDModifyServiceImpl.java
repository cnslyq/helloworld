package com.lenovo.bi.service.sc.impl;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.sc.MWDModifyDao;
import com.lenovo.bi.form.sc.mwd.SearchMWDForm;
import com.lenovo.bi.service.sc.MWDModifyService;
import com.lenovo.bi.view.sc.mwd.MWDModifyDetailView;

@Service
@Transactional("bi")
public class MWDModifyServiceImpl  implements MWDModifyService {
	
	@Inject
	private MWDModifyDao mwdModifyDao;

	@Override
	public List<MWDModifyDetailView> getMWDModifyDetail(SearchMWDForm form) {
		List<MWDModifyDetailView>list=mwdModifyDao.getMWDModifyDetail(form);
		return list;
	}

	@Override
	public int getMWDModifyDetailCount(SearchMWDForm form) {
		return mwdModifyDao.getMWDModifyDetailCount(form);
	}

	@Override
	public void updateMWD(Map<String, Object> map) {
		mwdModifyDao.updateMWD(map);
	}
	
}
