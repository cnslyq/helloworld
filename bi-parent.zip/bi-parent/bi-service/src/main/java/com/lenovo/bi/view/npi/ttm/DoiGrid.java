package com.lenovo.bi.view.npi.ttm;

/**
 * 
 * 
 * @author henry_lian
 *
 */
public class DoiGrid {
	private String cValue;
	private String vValue;
	private String purchaseType;
	private Integer requiredQty;
	private Integer shortage;
	
	public String getcValue() {
		return cValue;
	}
	public void setcValue(String cValue) {
		this.cValue = cValue;
	}
	public String getvValue() {
		return vValue;
	}
	public void setvValue(String vValue) {
		this.vValue = vValue;
	}
	public String getPurchaseType() {
		return purchaseType;
	}
	public void setPurchaseType(String purchaseType) {
		this.purchaseType = purchaseType;
	}
	public Integer getRequiredQty() {
		return requiredQty;
	}
	public void setRequiredQty(Integer requiredQty) {
		this.requiredQty = requiredQty;
	}
	public Integer getShortage() {
		return shortage;
	}
	public void setShortage(Integer shortage) {
		this.shortage = shortage;
	}
	
}
