package com.lenovo.bi.dao.sc;


import java.util.List;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FaOverViewChartData;
import com.lenovo.bi.dto.sc.LTFCRemarkChartData;
import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.view.sc.fa.LTFCDetailView;

public interface LtfcDao {

	public List<FaOverViewChartData> fetchLtfcOverViewChartData(SearchFaForm form);
	
	public List<KeyNameObject> fetchTop15SubDimensions(SearchOtsForm form);
	
	public List<KeyNameObject> fetchSelectedSubDimensions(SearchOtsForm form);
	
	public List<KeyNameObject> fetchDimensions(SearchFaForm form);
	
	public List<LTFCRemarkChartData> fetchLtfcRemarkChartData(SearchFaForm form);
	
	public List<FaOverViewChartData> fetchLtfcDashboardOverViewChartData(SearchFaForm form);

	public List<FaOverViewChartData> fetchLtfcCrossMonthOverviewChartData(SearchFaForm form);
	
	public List<FaOverViewChartData> getOverviewOverall(SearchOtsForm form);
	
	public Integer fetchToltalDimensionFAData(SearchOtsForm form);
	
	public List<FaOverViewChartData> getFaPieChart(SearchFaForm form);
	

	public int getDashboardOrderDetailCount(SearchFaForm form);
	
	public List<LTFCDetailView> getDashboardOrderDetail(SearchFaForm form);
	
	public List<LTFCDetailView> getAllOrderDetail(SearchFaForm form);
	
	public int getRemarkOrderDetailCount(SearchFaForm form);
	
	public List<LTFCDetailView> getRemarkOrderDetail(SearchFaForm form);
	
	public List<String>getPoorProducts(SearchFaForm form,int target);
	
	public List<FaOverViewChartData> getFaCrossMonthPieChart(SearchFaForm form);

	List<FaOverViewChartData> getFaDashboardPieChart(SearchFaForm form);
}
