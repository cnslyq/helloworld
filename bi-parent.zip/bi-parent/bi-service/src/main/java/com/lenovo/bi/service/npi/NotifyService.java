package com.lenovo.bi.service.npi;

public interface NotifyService {
	void sendNotification();
}
