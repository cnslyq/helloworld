package com.lenovo.bi.engine;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.NpiDnsEntry;
import com.lenovo.bi.dto.NpiForecast;
import com.lenovo.bi.enumobj.DnsShortageCodeEnum;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnProduct;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.SysConstants;
import com.lenovo.common.logging.Logger;
import com.lenovo.common.logging.LoggerFactory;

public class NpiComponentAllocator {

	private static Logger LOGGER = LoggerFactory
			.getLogger(SysConstants.LOG_WEEKLY_BATCH_CATALOG);

	private List<Date> targetDates;
	private Date versionDate;
	private Date dnsVersionDate;

	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	private TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper;

	public NpiComponentAllocator() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NpiComponentAllocator(Date versionDate, Date dnsVersionDate) {
		super();
		this.versionDate = versionDate;
		this.dnsVersionDate = dnsVersionDate;
	}

	public TTVOutlookServiceDwHelper getTtvOutlookServiceDwHelper() {
		return ttvOutlookServiceDwHelper;
	}

	public void setTtvOutlookServiceDwHelper(
			TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper) {
		this.ttvOutlookServiceDwHelper = ttvOutlookServiceDwHelper;
	}

	public TTVOutlookServiceBiHelper getTtvOutlookServiceBiHelper() {
		return ttvOutlookServiceBiHelper;
	}

	public void setTtvOutlookServiceBiHelper(
			TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper) {
		this.ttvOutlookServiceBiHelper = ttvOutlookServiceBiHelper;
	}

	public static Logger getLOGGER() {
		return LOGGER;
	}

	public static void setLOGGER(Logger lOGGER) {
		LOGGER = lOGGER;
	}

	public List<Date> getTargetDates() {
		return targetDates;
	}

	public void setTargetDates(List<Date> targetDates) {
		this.targetDates = targetDates;
	}

	public Date getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	public Date getDnsVersionDate() {
		return dnsVersionDate;
	}

	public void setDnsVersionDate(Date dnsVersionDate) {
		this.dnsVersionDate = dnsVersionDate;
	}

	public void run() {

		NpiComponentPool npiComponentPool = new NpiComponentPool(
				ttvOutlookServiceDwHelper, versionDate);
		
		long start = System.currentTimeMillis();
		long end = 0;
		LOGGER.info("Init data start ... ");
		//initialize data
		npiComponentPool.initializePool(dnsVersionDate);
		end = System.currentTimeMillis();
		LOGGER.info("Init data end ... Cost : " + (end - start) + "ms");
		start = end;

		LOGGER.info("Calculate shortcode start ... ");
		// calculator shortCode

		calShortCode(npiComponentPool);
		end = System.currentTimeMillis();
		LOGGER.info("Calculate shortcode end ... Cost : " + (end - start) + "ms");
		start = end;

		LOGGER.info("Allocate CV on product start ... ");
		//allocate CV on product
		allocateOnProduct(npiComponentPool);
		end = System.currentTimeMillis();
		LOGGER.info("Allocate CV on product end ... Cost : " + (end - start) + "ms");

		//System.out.println("done");
	}

	/**
	 * 根据shortCode进行不同的分货逻辑
	 * */
	private void allocateOnProduct(NpiComponentPool npiComponentPool) {
		Map<Integer, List<NpiDnsEntry>> dnsMap = npiComponentPool.getDnsMap();
		List<Integer> cvkeyList = npiComponentPool.getCvKeyList();
		Map<Integer, Map<Integer, DnsShortageCodeEnum>> cvKeyShortageMap = npiComponentPool
				.getShortageMap();
		Integer dnsversion = Integer.parseInt(new SimpleDateFormat("yyyyMMdd").format(dnsVersionDate)) ;
		for (Integer cvkey : cvkeyList) {
			List<NpiDnsEntry> dnsList = dnsMap.get(cvkey);
			for (NpiDnsEntry  dns : dnsList) {
				DnsShortageCodeEnum shortegeCode = cvKeyShortageMap.get(cvkey)
						.get(dns.getBizMonth());
				List<NpiForecast> forecastList = null;
				if (shortegeCode.equals(DnsShortageCodeEnum.NO_SHORTAGE)) {
					// no_shortage不进行计算
				} else if (shortegeCode
						.equals(DnsShortageCodeEnum.TIMING_ISSUE)) {
					allocate(dns, 0);//timing_issue的分货逻辑
					
				} else if (shortegeCode.equals(DnsShortageCodeEnum.SHORTAGE)) {//SHORTAGE的分货逻辑
					Integer dnsyear = dns.getBizYear();
					Integer dnsmonth = dns.getBizMonth();
					Integer month_1 = null;// 一个财月前
					Integer year_1 = null;
					String shortegeCode_1 = "";
					Integer month_2 = null;// 二个财月前
					Integer year_2 = null;
					String shortegeCode_2 = "";
					if (dnsmonth > 2) {
						month_1 = dnsmonth - 1;
						year_1 = dnsyear;
						month_2 = dnsmonth - 2;
						year_2 = dnsyear;
					} else if (dnsmonth > 1) {
						month_1 = 1;
						year_1 = dnsyear;
						month_2 = 12;
						year_2 = dnsyear - 1;
					} else if (dnsmonth == 1) {
						month_1 = 12;
						year_1 = dnsyear - 1;
						month_2 = 11;
						year_2 = dnsyear - 1;
					}
					//一周前的shortegeCode
					shortegeCode_1 = cvKeyShortageMap.get(cvkey).get(month_1) == null ? ""
							: cvKeyShortageMap.get(cvkey).get(month_1)
									.getValue();
					//二周前的shortegeCode
					shortegeCode_2 = cvKeyShortageMap.get(cvkey).get(month_2) == null ? ""
							: cvKeyShortageMap.get(cvkey).get(month_2)
									.getValue();
					
					Integer forecastDate = ttvOutlookServiceDwHelper
							.get2MonthsAgoMondayOfMonthkDate(dns
									.getTargetDateKey());
					if (!ttvOutlookServiceDwHelper
							.getForecastByVersionDate(forecastDate)) {
						forecastDate = ttvOutlookServiceDwHelper
								.get3MonthsAgo4WeeksMondayOfMonthkDate(dns
										.getTargetDateKey());
					}
					if (dns.getMonthno() == 1) {//判断当月是3个月中的第几个月
						
						forecastList = ttvOutlookServiceDwHelper
								.getForecastRateMonthone(month_1, month_2,
										year_1, year_2, dns, forecastDate,dnsversion);

					} else if (dns.getMonthno() == 2) {//判断当月是3个月中的第几个月
						forecastList = ttvOutlookServiceDwHelper
								.getForecastRateMonthtwo(month_1, month_2,
										year_1, year_2, shortegeCode_1, dns,
										forecastDate,dnsversion);
					} else if (dns.getMonthno() == 3) {//判断当月是3个月中的第几个月
						forecastList = ttvOutlookServiceDwHelper
								.getForecastRateMonththree(month_1, month_2,
										year_1, year_2, shortegeCode_1,
										shortegeCode_2, dns, forecastDate,dnsversion);
					}
					int total = 0;
					long commitment = 0;
					boolean flag = false;
					if (forecastList != null && forecastList.size() > 0) {
						for (int j = 0; j < forecastList.size(); j++) {
							if (forecastList.get(j).getQuantity() > 0) {
								total += forecastList.get(j).getQuantity();
								flag = true;
							}
						}
						if (total > 0) {
							if (flag) {
								for (int k = 0; k < forecastList.size(); k++) {
									// TODO
									if (forecastList.get(k).getQuantity() < 0) {
										commitment = 0;
									} else {
										// commitment = dns.getSupply()
										// * forecastList.get(k).getQuantity()
										// / total;
										double supply = dns.getSupply();
										double quantity = forecastList.get(k)
												.getQuantity();
										double tt = total;
										double commit = supply * quantity / tt;
										BigDecimal b = new BigDecimal(commit);
										commitment = b.setScale(0,
												BigDecimal.ROUND_HALF_UP)
												.intValue();
									}
									NpiWeeklyComponentCommitmentOnProduct obj = new NpiWeeklyComponentCommitmentOnProduct();
									obj.setCommitment(commitment);
									obj.setVersionDate(Integer.valueOf(new SimpleDateFormat("yyyyMMdd").format(versionDate)));
									obj.setGlobalCVKey(dns.getCvKey());
									obj.setProductKey(forecastList.get(k)
											.getProductKey());
									obj.setTargetDate(dns.getTargetDateKey());
									ttvOutlookServiceBiHelper
											.saveNpiWeeklyComponentCommitmentOnProduct(obj);
								}
							} else {
								allocate(dns, 0);
							}
						}
					}

				}
			}
		}
	}

	/**
	 * @param weeks
	 * @param dns
	 *            根据DNS对象进行product粒度分货
	 * */
	private void allocate(NpiDnsEntry dns, Integer weeks) {
		List<NpiForecast> forecastList = ttvOutlookServiceDwHelper
				.getNpiForecastByTargetDate(dns.getCvKey(),
					Integer.parseInt(new SimpleDateFormat("yyyyMMdd").format(dnsVersionDate) )	 , dns.getTargetDateKey(), weeks);
		int total = 0;
		long commitment = 0;
		for (int j = 0; j < forecastList.size(); j++) {
			if (forecastList.get(j).getQuantity() > 0) {
				total += forecastList.get(j).getQuantity();
			}
		}
		if (total > 0) {
			for (int k = 0; k < forecastList.size(); k++) {
				if (forecastList.get(k).getQuantity() < 0) {
					commitment = 0;
				} else {
					// commitment = dns.getSupply()
					// * forecastList.get(k).getQuantity() / total;
					double supply = dns.getSupply();
					double quantity = forecastList.get(k).getQuantity();
					double tt = total;
					double commit = supply * quantity / tt;
					BigDecimal b = new BigDecimal(commit);
					commitment = b.setScale(0, BigDecimal.ROUND_HALF_UP)
							.intValue();
				}
				NpiWeeklyComponentCommitmentOnProduct obj = new NpiWeeklyComponentCommitmentOnProduct();
				obj.setCommitment(commitment);
				obj.setVersionDate(Integer.valueOf(new SimpleDateFormat("yyyyMMdd").format(versionDate)));
				obj.setGlobalCVKey(dns.getCvKey());
				obj.setProductKey(forecastList.get(k).getProductKey());
				obj.setTargetDate(dns.getTargetDateKey());
				ttvOutlookServiceBiHelper
						.saveNpiWeeklyComponentCommitmentOnProduct(obj);
			}
		}
	}

	/**
	 * 计算DNS的13周中每个月的shortcode
	 * @param npiComponentPool
	 *            set shortCode Map
	 * */
	private void calShortCode(NpiComponentPool npiComponentPool) {

		Map<Integer, List<NpiDnsEntry>> dnsMap = npiComponentPool.getDnsMap();
		List<Integer> cvkeyList = npiComponentPool.getCvKeyList();
		Map<Integer, Map<Integer, DnsShortageCodeEnum>> cvKeyShortageMap = new HashMap<Integer, Map<Integer, DnsShortageCodeEnum>>();
		String shortCode = "";
		for (Integer cvkey : cvkeyList) {
			Map<Integer, DnsShortageCodeEnum> monthShortageMap = new HashMap<Integer, DnsShortageCodeEnum>();
			List<NpiDnsEntry> dnsList = dnsMap.get(cvkey);
			Integer month;
			Long delta;
			Integer nextMonth;
			boolean sameMonth = false;
			Integer monthno = 1;
			for (int i = 0; i < dnsList.size(); i++) {
				if (monthno == 4) {
					break;
				}
				month = dnsList.get(i).getBizMonth();
				dnsList.get(i).setMonthno(monthno);
				try {
					nextMonth = dnsList.get(i + 1).getBizMonth();
					if (month.equals(nextMonth)) {
						sameMonth = true;
					} else {
						sameMonth = false;
					}
				} catch (IndexOutOfBoundsException e) {
					sameMonth = false;

				}
				// demand += dnsList.get(i).getDemand();
				// supply += dnsList.get(i).getSupply();
				// delta = supply - demand;
				delta = dnsList.get(i).getDelta();
				if (delta < 0) {
					shortCode = "TIMING_ISSUE";
				}
				if (sameMonth == false) {

					if (delta < 0) {
						// dnsList.get(i).setShortageCode(
						// DnsShortageCodeEnum.SHORTAGE);
						monthShortageMap.put(dnsList.get(i).getBizMonth(),
								DnsShortageCodeEnum.SHORTAGE);
					} else {
						if (shortCode.equals("TIMING_ISSUE") && delta >= 0) {
							// dnsList.get(i).setShortageCode(
							// DnsShortageCodeEnum.TIMING_ISSUE);
							monthShortageMap.put(dnsList.get(i).getBizMonth(),
									DnsShortageCodeEnum.TIMING_ISSUE);
						} else if (delta >= 0) {
							// dnsList.get(i).setShortageCode(
							// DnsShortageCodeEnum.NO_SHORTAGE);
							monthShortageMap.put(dnsList.get(i).getBizMonth(),
									DnsShortageCodeEnum.NO_SHORTAGE);
						}
					}
					shortCode = "";
					cvKeyShortageMap.put(cvkey, monthShortageMap);
					monthno++;
				}
			}
			dnsMap.put(cvkey, dnsList);
		}
		npiComponentPool.setShortageMap(cvKeyShortageMap);
	}

}
