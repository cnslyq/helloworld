package com.lenovo.bi.dao.npi.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.DimTime;

@Repository
public class NPIToolingDaoImpl extends HibernateBaseDaoImplDw {
	public List<DimTime> getFactNPIToolingTracking() {
		String sql = "select timeKey, dayNumberofWeek, dayNumberofMonth, dayNumberofYear from DimTime where timeKey = ?";
		Query query = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(DimTime.class));
		query.setParameter(0, 1);
		List<DimTime> list = (List<DimTime>)query.list();
		
		return list;
	}
}
