package com.lenovo.bi.form.npi;



public class SearchProductsFormForPopUp extends SearchBase{
	private String level;//my projects(默认不选中)
//	private String type;//ttm overview/in progress/fail/success/NA
	private String productName;
	private String npiName;
	private String familyName;
	
	public String getNpiName() {
		return npiName;
	}
	public void setNpiName(String npiName) {
		this.npiName = npiName;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getFamilyName() {
		return familyName;
	}
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

}
