package com.lenovo.bi.dao.sc.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.formula.functions.T;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.DoubleType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.SBBDao;
import com.lenovo.bi.form.sc.sbb.SearchSBBForm;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.sc.sbb.SBBDetailView;

@Repository
@SuppressWarnings("unchecked")
public class SBBDaoImpl extends HibernateBaseDaoImplDw<T> implements SBBDao {

	public List<SBBDetailView> getSBBDetail(SearchSBBForm form) {
		Query query = getQuery(form);
		query.setFirstResult((form.getCurrentPage()-1)*SysConfig.NUMBER_OF_ROW_COUNT);//SysConfig.NUMBER_OF_ROW_COUNT
		query.setMaxResults(SysConfig.NUMBER_OF_ROW_COUNT);
		return query.list();
	}

	@Override
	public int getSBBDetailCount(SearchSBBForm form) {
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append(" select count(*) ");
		sBuffer.append(" from factweeklysbbtracking sbbt where 1=1 ");
		sBuffer.append(" and (case when left_to_build + pre_lock < 0 then 0 else left_to_build + pre_lock END - Open_Qty > 0 or datediff(DAY, Eol_Date, getdate()) <= 90) ");
		
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and sbbt.Product in ( ").append(getStrs(form.getProductIds())).append(")");
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sBuffer.append(" and sbbt.Region in ( ").append(form.getGeoIds()).append(")");
		}
		
		if(StringUtils.isNotBlank(form.getSbbType())){
			sBuffer.append(" and sbbt.SBB like upper('%").append(form.getSbbType()).append("%')");
		}
		
		if(StringUtils.isNotBlank(form.getDemandStatus())){
			if("N".equals(form.getDemandStatus())){
				sBuffer.append(" and sbbt.Left_To_Build > 0 ");
			}else if("E".equals(form.getDemandStatus())){
				sBuffer.append(" and sbbt.Left_To_Build <= 0 ");
			}
		}
		
		Query q=getSession().createSQLQuery(sBuffer.toString());
		return (Integer) q.uniqueResult();
	}

	@Override
	public void updateSBB(Map<String, Object> map) {
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append(" update factweeklysbbtracking set Pre_Lock=:value where ID=:key ");
		for(Entry<String,Object>entry:map.entrySet()){
			Query q=getSession().createSQLQuery(sBuffer.toString());
			q.setParameter("key", Integer.parseInt(entry.getKey()));
			String value=(String)entry.getValue();
			if(StringUtils.isNotBlank(value)){
				q.setParameter("value", Integer.parseInt(value));
			}else{
				q.setParameter("value", null);
			}
			
			q.executeUpdate();
		}
		getSession().flush();
	}
	
	@Override
	public List<SBBDetailView> getSBBDetailExport(SearchSBBForm form) {
		return getQuery(form).list();
	}

	private Query getQuery(SearchSBBForm form) {
		StringBuffer sBuffer=new StringBuffer();
		sBuffer.append(" select ID, Eol_Date, SBB, Product, Region, Fcst_Value, Pre_Lock, Act_Input, Open_Qty, "); 
        sBuffer.append(" isnull(Week_0, 0) Week_0, isnull(Week_1, 0) Week_1, isnull(Week_2, 0) Week_2, isnull(Week_3, 0) Week_3, isnull(Week_4, 0) Week_4, ");
        sBuffer.append(" isnull(Week_5, 0) Week_5, isnull(Week_6, 0) Week_6, isnull(Week_7, 0) Week_7, isnull(Week_8, 0) Week_8, isnull(Week_9, 0) Week_9, ");
        sBuffer.append(" isnull(Week_10, 0) Week_10, isnull(Week_11, 0) Week_11, isnull(Week_12, 0) Week_12, isnull(Week_13, 0) Week_13, ");
        sBuffer.append(" (Fcst_Value + Pre_lock) AS Final_Liability, ");
        sBuffer.append(" case when Left_To_Build + Pre_lock < 0 then 0 else (Left_To_Build + Pre_lock) end AS Left_To_Build, ");
        sBuffer.append(" case when case when left_to_build + pre_lock < 0 then 0 else left_to_build + pre_lock END - Open_Qty < 0 then 0 else (case when left_to_build + pre_lock < 0 then 0 else left_to_build + pre_lock END - Open_Qty) end AS Left_To_Sell, ");
        sBuffer.append(" getdate() AS Curr_Date, ");
        //sBuffer.append(" case datediff(DAY, dateadd(day, 2-datepart(weekday,Eol_Date),Eol_Date), getdate()) when 0 then 0 ");
        sBuffer.append(" case datediff(DAY, Eol_Date, getdate()) when 0 then 0 ");
        //sBuffer.append(" else (Act_Input + Open_Qty) * 1.0 / datediff(DAY, dateadd(day, 2-datepart(weekday,Eol_Date),Eol_Date), getdate()) end AS Daily_Running_Rate, ");
        sBuffer.append(" else (Act_Input + Open_Qty) * 1.0 / datediff(DAY, Eol_Date, getdate()) end AS Daily_Running_Rate, ");
        sBuffer.append(" case when Act_Input + Open_Qty = 0 then getdate() ");
        sBuffer.append("      when case when left_to_build + pre_lock < 0 then 0 else left_to_build + pre_lock END - Open_Qty <= 0 then getdate() ");
        //sBuffer.append("      when ((case when left_to_build + pre_lock < 0 then 0 else left_to_build + pre_lock END - Open_Qty) * datediff(DAY, dateadd(day, 2-datepart(weekday,Eol_Date),Eol_Date), getdate())) / (Act_Input + Open_Qty) > datediff(DAY, getdate(), '9999-12-31') then '9999-12-31' ");
        sBuffer.append("      when ((case when left_to_build + pre_lock < 0 then 0 else left_to_build + pre_lock END - Open_Qty) * datediff(DAY, Eol_Date, getdate())) / (Act_Input + Open_Qty) > datediff(DAY, getdate(), '9999-12-31') then '9999-12-31' ");
        //sBuffer.append("      else DATEADD(DAY, CEILING((case when left_to_build + pre_lock < 0 then 0 else left_to_build + pre_lock END - Open_Qty) * datediff(DAY, dateadd(day, 2-datepart(weekday,Eol_Date),Eol_Date), getdate()) * 1.0 / (Act_Input + Open_Qty)), getdate()) end AS Projected_Cons_Date, ");
        sBuffer.append("      else DATEADD(DAY, CEILING((case when left_to_build + pre_lock < 0 then 0 else left_to_build + pre_lock END - Open_Qty) * datediff(DAY, Eol_Date, getdate()) * 1.0 / (Act_Input + Open_Qty)), getdate()) end AS Projected_Cons_Date, ");
        sBuffer.append(" (Act_Input - Week_Sum) AS Psd_Shipment_Rest, ");
        sBuffer.append(" Week_Sum AS Psd_Shipment_Last13wk, ");
        sBuffer.append(" case when Left_To_Build > 0 then 'N' else 'E' end AS Demand_Status ");
		sBuffer.append(" from factweeklysbbtracking sbbt where 1=1 ");
		sBuffer.append(" and (case when left_to_build + pre_lock < 0 then 0 else left_to_build + pre_lock END - Open_Qty > 0 or datediff(DAY, Eol_Date, getdate()) <= 90) ");
		
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and sbbt.Product in ( ").append(getStrs(form.getProductIds())).append(")");
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sBuffer.append(" and sbbt.Region in ( ").append(form.getGeoIds()).append(")");
		}
		
		if(StringUtils.isNotBlank(form.getSbbType())){
			sBuffer.append(" and sbbt.SBB like upper('%").append(form.getSbbType()).append("%')");
		}
		
		if(StringUtils.isNotBlank(form.getDemandStatus())){
			if("N".equals(form.getDemandStatus())){
				sBuffer.append(" and sbbt.Left_To_Build > 0 ");
			}else if("E".equals(form.getDemandStatus())){
				sBuffer.append(" and sbbt.Left_To_Build <= 0 ");
			}
		}
		
		Query query=getSession().createSQLQuery(sBuffer.toString()).addScalar("ID", StringType.INSTANCE)
					.addScalar("Eol_Date", DateType.INSTANCE)
					.addScalar("SBB", StringType.INSTANCE)
					.addScalar("Product", StringType.INSTANCE)
					.addScalar("Region", StringType.INSTANCE)
					.addScalar("Fcst_Value", IntegerType.INSTANCE)
					.addScalar("Pre_Lock", IntegerType.INSTANCE)
					.addScalar("Act_Input", IntegerType.INSTANCE)
					.addScalar("Open_Qty", IntegerType.INSTANCE)
					.addScalar("Left_To_Build", IntegerType.INSTANCE)
					.addScalar("Left_To_Sell", IntegerType.INSTANCE)
					.addScalar("Week_0", IntegerType.INSTANCE)
					.addScalar("Week_1", IntegerType.INSTANCE)
					.addScalar("Week_2", IntegerType.INSTANCE)
					.addScalar("Week_3", IntegerType.INSTANCE)
					.addScalar("Week_4", IntegerType.INSTANCE)
					.addScalar("Week_5", IntegerType.INSTANCE)
					.addScalar("Week_6", IntegerType.INSTANCE)
					.addScalar("Week_7", IntegerType.INSTANCE)
					.addScalar("Week_8", IntegerType.INSTANCE)
					.addScalar("Week_9", IntegerType.INSTANCE)
					.addScalar("Week_10", IntegerType.INSTANCE)
					.addScalar("Week_11", IntegerType.INSTANCE)
					.addScalar("Week_12", IntegerType.INSTANCE)
					.addScalar("Week_13", IntegerType.INSTANCE)
					.addScalar("Final_Liability", IntegerType.INSTANCE)
					.addScalar("Curr_Date", DateType.INSTANCE)
					.addScalar("Daily_Running_Rate", DoubleType.INSTANCE)
					.addScalar("Projected_Cons_Date", DateType.INSTANCE)
					.addScalar("Psd_Shipment_Rest", IntegerType.INSTANCE)
					.addScalar("Psd_Shipment_Last13wk", IntegerType.INSTANCE)
					.addScalar("Demand_Status", StringType.INSTANCE)
					.setResultTransformer(Transformers.aliasToBean(SBBDetailView.class));
		
		return query;
	}
	
	private static String getStrs(String str){
		String[]arr=str.split(",");
		for(int i=0;i<arr.length;i++){
			arr[i]="'"+arr[i].trim()+"'";
		}
		List<String>list=Arrays.asList(arr);
		String con=list.toString();
		return con.substring(1, con.length()-1);
	}
	
}

