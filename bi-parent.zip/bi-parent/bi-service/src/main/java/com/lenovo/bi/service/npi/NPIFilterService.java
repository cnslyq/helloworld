package com.lenovo.bi.service.npi;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.ProductDataForPopup;
import com.lenovo.bi.model.NPIFilter;

public interface NPIFilterService {
	public List<NPIFilter> getNPIFilter(String userId, String phase, String scope);
	public List<NPIFilter> getNPIFilterByFilterId(String userId, String phase, String scope, String filterId);
	public List<ProductDataForPopup> getNPIFilterDetailByFilterId(String filterId);
	public int deleteFilter(String filterId);
	public String saveFilter(NPIFilter npiFilter,List<Integer> waveIds);
	public String saveLastUsedFilter(String scope, String phase, List<Integer> waveIds, Date durationForm, Date durationTo, String userId);
}
