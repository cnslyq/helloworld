package com.lenovo.bi.dao.common.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.common.MasterDataDao;
import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.GeoData;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.privilege.GeoTree;
import com.lenovo.bi.enumobj.GeographyType;

@SuppressWarnings("rawtypes")
@Repository
@Transactional("dw")
public class MasterDataDaoImpl extends HibernateBaseDaoImplDw implements MasterDataDao {
	
	@SuppressWarnings("unchecked")
	private List<GeoData> getGeographyByType(GeographyType geographyType){
		
		StringBuilder sql = new StringBuilder();
		sql.append(" select dg.GeographyKey as geographyKey, dg.GeographyName as geographyName, dg.GeographyType as geographyType, dg1.GeographyName as parentGeo from View_DimGeography dg inner join View_DimGeography dg1 on dg.ParentGeographyKey = dg1.GeographyKey ");
		sql.append(" where dg.GeographyType=:type ");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(GeoData.class))
				.setString("type", geographyType.name());
		
		return query.list();
	}

	@Override
	public List<GeoData> getRegions() {
		
		return getGeographyByType(GeographyType.Region);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getOrderType() {
		
		StringBuilder sql = new StringBuilder();
		sql.append(" select OTSType from DimOTSType ");
		
		Query query = getSession().createSQLQuery(sql.toString());
				
		return query.list();
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getOdmList() {
		StringBuilder sql = new StringBuilder();
		sql.append(" select distinct ODMEnglishName from DimODM ");
		
		Query query = getSession().createSQLQuery(sql.toString());
				
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getProductFamily() {
		StringBuilder sql = new StringBuilder();
		sql.append(" select distinct ProductFamilyEnglishName from DimProductFamily ");
		
		Query query = getSession().createSQLQuery(sql.toString());
				
		return query.list();
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getProductList() {
		StringBuilder sql = new StringBuilder();
		sql.append(" select distinct ProductEnglishName from DimProduct ");
		
		Query query = getSession().createSQLQuery(sql.toString());
				
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GeoTree> getRegionTreeList() {
		/*StringBuffer sBuffer = new StringBuffer("select * from (select ROW_NUMBER()OVER(partition by geography.GeographyType,geography.GeographyName Order by geography.GeographyKey)as rn,");
		sBuffer.append("geography.GeographyKey as id,")
			   .append("geography.GeographyName as name,")
			   .append("case when geography.ParentGeographyKey is null then 0")
			   .append(" else geography.ParentGeographyKey")
			   .append(" end as pId,")
			   .append("geography.GeographyType as type")
			   .append(" from View_DimGeography geography")
			   //defect 10695 2014-08-18
			   .append(" where (geography.GeographyType='Geo' or geography.GeographyType='Region')")
			   .append(")t where rn=1")
			   .append(" order by name");*/
		StringBuffer sBuffer = new StringBuffer("select DBO.AggregateRegionId(GeographyName)as id,GeographyName as name,isnull(max(ParentGeographyKey),0) as pId ");
		sBuffer.append(" from View_DimGeography where GeographyType in('Geo','Region') group by GeographyName ");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", StringType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				.addScalar("pId", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GeoTree.class));
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> getOrderSubTypes(Integer orderType) {
		StringBuffer sBuffer = new StringBuffer();
			   sBuffer.append("select otsType.OTSTypeKey as objKey,otsType.OTSType as objName")
			   		.append(" from DimOTSType otsType");
		if(orderType == 1)	   
			sBuffer.append(" where otsType.OTSTypeKey in(1,2)");
		else if(orderType == 2)
			sBuffer.append(" where otsType.OTSTypeKey in(3,4,5,6)");
		else 
			sBuffer.append("");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> getOdms() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select odm.ODMKey as objKey,odm.ODMEnglishName as objName")
			   .append(" from DimODM odm order by odm.ODMEnglishName asc");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> getProducts() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select product.ProductKey as objKey,product.ProductEnglishName as objName")
		   .append(" from DimProduct product order by product.ProductEnglishName asc");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> getComponents() {
		StringBuffer sBuffer = new StringBuffer();
		//sBuffer.append(" select CommodityTypeKey as objKey, CommodityType as objName from DimCommodityType order by CommodityType");
		sBuffer.append(" select distinct Commodity as type, Commodity as objName from FactWeeklyCVMWD ");
		sBuffer.append(" where StandardMrpRunTime = (select MAX(StandardMrpRunTime) from FactWeeklyODMMWD) ");
		sBuffer.append(" and Commodity is not null ");
		sBuffer.append(" order by Commodity");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				//.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> getFamilyList() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select family.ProductFamilyKey as objKey,family.ProductFamilyEnglishName as objName")
		   .append(" from DimProductFamily family order by family.ProductFamilyEnglishName asc");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> getPortfolioList() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select portfolio.PortofolioKey as objKey,portfolio.PortofolioEnglishName as objName")
		   .append(" from DimPortofolio portfolio order by portfolio.PortofolioEnglishName asc");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> getPurchaseTypeList() {
		
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select purchaseType.PurchaseTypeKey as objKey,purchaseType.PurchaseType as objName")
		   .append(" from DimPurchaseType purchaseType order by purchaseType.PurchaseType asc");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> getProductFamilys() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select distinct ProductFamily as objName")
		   .append(" from factdailysummaryofbps where ProductFamily is not null order by ProductFamily ");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				//.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		return query.list();
	}
	
	@Override
	public String getCurrentRolMonth() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select CONVERT(varchar(10),BizYear)+'-'+CONVERT(varchar(10),BizMonth) as currentDate")
		   		.append(" from DimTime where FullDateAlternateKey=CONVERT(varchar(100), GETDATE(), 23) ");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (String)query.uniqueResult();
	}

	@Override
	public List<KeyNameObject> getComponentValues() {
		StringBuffer sBuffer = new StringBuffer();
		/*
		sBuffer.append(" select distinct cv.CommodityTypeKey as objKey, cv.CommodityValue as objName from DimGlobalCV cv ");
		sBuffer.append(" where  cv.CommodityValue is not null ");
		sBuffer.append(" order by cv.CommodityValue  ");
		*/
		sBuffer.append(" select distinct Commodity as type, CommodityValue as objName from FactWeeklyCVMWD ");
		sBuffer.append(" where StandardMrpRunTime = (select MAX(StandardMrpRunTime) from FactWeeklyODMMWD) ");
		sBuffer.append(" and CommodityValue is not null ");
		sBuffer.append(" order by CommodityValue");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				//.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		
		return query.list();
	}
}
