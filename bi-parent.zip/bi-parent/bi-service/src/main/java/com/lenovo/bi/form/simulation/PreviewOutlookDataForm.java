package com.lenovo.bi.form.simulation;


import java.util.List;

import com.lenovo.bi.form.npi.ttv.SearchOutlookDataForm;

//for preview outlookchart and shortbar chart,save npi simulation detail
public class PreviewOutlookDataForm {
	private SearchOutlookDataForm chartForm;
	private List<NPISimulationPreviewData> perviewDataList;
	private String sgaOrSle;
	public SearchOutlookDataForm getChartForm() {
		return chartForm;
	}
	public void setChartForm(SearchOutlookDataForm chartForm) {
		this.chartForm = chartForm;
	}
	public List<NPISimulationPreviewData> getPerviewDataList() {
		return perviewDataList;
	}
	public void setPerviewDataList(List<NPISimulationPreviewData> perviewDataList) {
		this.perviewDataList = perviewDataList;
	}
	public String getSgaOrSle() {
		return sgaOrSle;
	}
	public void setSgaOrSle(String sgaOrSle) {
		this.sgaOrSle = sgaOrSle;
	}
}
