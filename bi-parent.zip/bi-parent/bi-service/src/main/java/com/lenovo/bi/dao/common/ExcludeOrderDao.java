package com.lenovo.bi.dao.common;

import java.util.List;

import com.lenovo.bi.model.ExcludeOrder;
import com.lenovo.common.model.PagerInformation;

public interface ExcludeOrderDao {

	void deleteExcudeOrder(String month);
	
	void batchSaveExcludeOrder(List<ExcludeOrder> excludeOrders);
	
	List<ExcludeOrder> getExcludeOrdersByCondition(String selMonth, PagerInformation pagerInfo);
	
	String getPoNumberItemOrderNoByMonth(String selMonth , String quarterFrom, String quarterTo);
	
	int getExcludeOrderCountByMonth(String month);
}
