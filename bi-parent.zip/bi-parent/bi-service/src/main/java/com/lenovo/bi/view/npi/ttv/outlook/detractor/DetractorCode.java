package com.lenovo.bi.view.npi.ttv.outlook.detractor;

import java.util.List;

public class DetractorCode {

	private List<String> levelList;

	public List<String> getLevelList() {
		return levelList;
	}

	public void setLevelList(List<String> levelList) {
		this.levelList = levelList;
	}
	
	
}
