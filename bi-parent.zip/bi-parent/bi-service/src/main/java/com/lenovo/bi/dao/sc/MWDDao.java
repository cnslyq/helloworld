package com.lenovo.bi.dao.sc;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.MWDChartData;
import com.lenovo.bi.form.sc.mwd.SearchMWDForm;
import com.lenovo.bi.view.sc.mwd.MWDDetailView;


public interface MWDDao {
	
	public List<MWDChartData> fetchMWDOverViewChartData(SearchMWDForm form);
	
	public List<MWDChartData> fetchDimensionRemarkDataList(SearchMWDForm form);
	
	public List<MWDChartData> fetchMWDDashboardChartData(SearchMWDForm form);
	
	public List<KeyNameObject> fetchDimensions(SearchMWDForm form);

	public List<MWDChartData> fetchMWDCrossMonthOverviewChartData(SearchMWDForm form);
	
	public List<MWDDetailView> getMWDDetail(SearchMWDForm form);
	
	public long getMWDDetailCount(SearchMWDForm form);
	
	public Date getMRPRunTime();
}
