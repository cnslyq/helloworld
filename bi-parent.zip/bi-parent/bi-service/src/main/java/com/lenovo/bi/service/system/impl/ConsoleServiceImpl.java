package com.lenovo.bi.service.system.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.system.console.ConsoleDao;
import com.lenovo.bi.dao.system.console.ConsoleMonitorDao;
import com.lenovo.bi.dao.system.console.ConsoleMonitorForRestartJobDao;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.BiWeeklyProcessStatus;
import com.lenovo.bi.model.system.ThresholdDetail;
import com.lenovo.bi.service.common.MasterDataService;
import com.lenovo.bi.service.system.ConsoleService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.system.console.BiWeeklyProcessStatusView;
import com.lenovo.bi.view.system.console.FailedJobDetailView;
import com.lenovo.bi.view.system.console.ThresholdDetailView;
import com.lenovo.common.model.Pager;
import com.lenovo.common.model.PagerInformation;

@Service
public class ConsoleServiceImpl implements ConsoleService {

	@Inject
	private ConsoleDao adminDao;
	
	@Inject
	private ConsoleMonitorDao consoleMonitorDao;
	
	@Inject
	private ConsoleMonitorForRestartJobDao consoleMonitorForRestartJobDao;
	
	@Inject
	private MasterDataService masterDataService;
	
	@Override
	public ThresholdDetail findThresholdById(Integer thresholdId) {
		return adminDao.findThresholdById(thresholdId);
	}

	
	@Override
	public void saveThreshold(ThresholdDetail thresholdDetail) {
		adminDao.saveThreshold(thresholdDetail);
		masterDataService.refreshMaps();
	}
	
	@Override
	public void saveEditedThreshold(ThresholdDetail thresholdDetail) {
		adminDao.saveEditedThreshold(thresholdDetail);
		masterDataService.refreshMaps();
	}
	
	@Override
	public void deleteThresholds(String thresholdIds) {
		adminDao.deleteThresholds(thresholdIds);
		masterDataService.refreshMaps();
	}

	@Override
	public Pager<ThresholdDetailView> listThresholds(DictSearchForm form) {
		Pager<ThresholdDetailView> pager = new Pager<ThresholdDetailView>();
		PagerInformation pageInfo = new PagerInformation();
		pager.setPagerInfo(pageInfo);
		pageInfo.setCurrentPage(form.getCurrentPage());
		pageInfo.setPageSize(masterDataService.getThresholdByName(Threshold.PAGE_SIZE.name()).intValue());
		
		List<ThresholdDetail> rawList = adminDao.listThreshold(form, pager.getPagerInfo());
		List<ThresholdDetailView> thresholdList = convert2Pojo(rawList);
		pager.setDatas(thresholdList);
		
		int recordCount = adminDao.getThresholdDetailCountByConditions(form);
		pageInfo.setRecordCount(recordCount);
		form.setRecordCount(recordCount);
		
		return pager;
	}
	
	@Override
	public Pager<FailedJobDetailView> listFailedJobs(DictSearchForm form,String jobStatus) {
		Pager<FailedJobDetailView> pager = new Pager<FailedJobDetailView>();
		PagerInformation pageInfo = new PagerInformation();
		pager.setPagerInfo(pageInfo);
		pageInfo.setCurrentPage(form.getCurrentPage());
		pageInfo.setPageSize(masterDataService.getThresholdByName(Threshold.PAGE_SIZE.name()).intValue());
		
		List<FailedJobDetailView> rawList = consoleMonitorDao.listFailedJobs(form, pager.getPagerInfo());
		List<FailedJobDetailView> filterRawList = new ArrayList<FailedJobDetailView>();
		int recordCount = 0;
		//if(!"All".equals(jobStatus)) {
			for(int i=0; i<rawList.size(); i++) {
				FailedJobDetailView failedJobDetailView = rawList.get(i);
				if(jobStatus.equals(failedJobDetailView.getStatus()+""))
					filterRawList.add(failedJobDetailView);
			}
			List<FailedJobDetailView> filterSameNameList = convertListByMap(filterRawList);
			pager.setDatas(filterSameNameList);
			recordCount = filterSameNameList.size();
		//}
		/*else {
			List<FailedJobDetailView> filterSameNameList = convertListByMap(rawList);
			pager.setDatas(filterSameNameList);
			recordCount = filterSameNameList.size();
		}*/
		
		pageInfo.setRecordCount(recordCount);
		form.setRecordCount(recordCount);
		
		return pager;
	}
	
	@Override
	public void restartFailedJobs(String packageName) {
		
		String pathName = null;
		int index = packageName.indexOf("_");
		String pathType = packageName.substring(0,index);
		if("DW".equals(pathType))
			pathName = SysConfig.MONITOR_RESTARTJOB_DW_PATH;
		else 
			pathName = SysConfig.MONITOR_RESTARTJOB_STAGING_PATH;
		consoleMonitorForRestartJobDao.restartFailedJobs(pathName, packageName);
	}
	
	@Override
	public List<FailedJobDetailView> listFailedJobDetails(String startDate, String packageName) {
		
		List<FailedJobDetailView> rawList = consoleMonitorDao.listFailedJobs(startDate);
		List<FailedJobDetailView> filterRawList = new ArrayList<FailedJobDetailView>();
	
		for(int i=0; i<rawList.size(); i++) {
			FailedJobDetailView failedJobDetailView = rawList.get(i);
			if(packageName.equals(failedJobDetailView.getPackageName()+""))
				filterRawList.add(failedJobDetailView);
		}
		int recordCount = filterRawList.size();
		
		
		return filterRawList;
	}
	
	private List<FailedJobDetailView> convertListByMap(List<FailedJobDetailView> list) {
		List<FailedJobDetailView> resultList = new ArrayList<FailedJobDetailView>();
		Map<String,FailedJobDetailView> map = new HashMap<String,FailedJobDetailView>();
		for(FailedJobDetailView faildJobDetailView : list) {
			map.put(faildJobDetailView.getPackageName(), faildJobDetailView);
		}
		
		for(Map.Entry<String, FailedJobDetailView> entry : map.entrySet()) {
			resultList.add(entry.getValue());
		}
		
		return resultList;
		
	}
	
	private List<ThresholdDetailView> convert2Pojo(List<ThresholdDetail> rawList) {
		List<ThresholdDetailView> list = new ArrayList<ThresholdDetailView>();
		for(ThresholdDetail td:rawList){
			ThresholdDetailView tdv = new ThresholdDetailView();
			tdv.setId(td.getId());
			tdv.setName(td.getName());
			tdv.setDescription(td.getDescription());
			Threshold threshold = Threshold.valueOf(td.getName());
			if(threshold.getType().equals(Integer.class)){
				tdv.setValue(String.valueOf(td.getValue().intValue()));
			} else if (threshold.getType().equals(Float.class)){
				tdv.setValue(String.valueOf(td.getValue()));
			}
			list.add(tdv);
		}
		return list;
	}


	@Override
	public ThresholdDetailView getThresholdById(Integer thresholdId) {
		ThresholdDetail td = adminDao.getThresholdById(thresholdId);
		ThresholdDetailView tdv = new ThresholdDetailView();
		tdv.setId(td.getId());
		tdv.setName(td.getName());
		tdv.setDescription(td.getDescription());
		Threshold threshold = Threshold.valueOf(td.getName());
		if(threshold.getType().equals(Integer.class)){
			tdv.setValue(String.valueOf(td.getValue().intValue()));
		} else if (threshold.getType().equals(Float.class)){
			tdv.setValue(String.valueOf(td.getValue()));
		}
		return tdv;
	}


	@Override
	public List<BiWeeklyProcessStatusView> getEngineStatusHistory() {
		List<BiWeeklyProcessStatus> rawList = adminDao.getEngineStatusHistory();
		List<BiWeeklyProcessStatusView> list = new ArrayList<BiWeeklyProcessStatusView>();
		for(BiWeeklyProcessStatus bps:rawList){
			BiWeeklyProcessStatusView bpsv = new BiWeeklyProcessStatusView();
			try {
				bpsv.setVersionDate(CalendarUtil.date2String(bps.getVersionDate()));
				bpsv.setProcessDate(CalendarUtil.timestamp2String(bps.getProcessDate()));
				bpsv.setLastModifiedDate(CalendarUtil.timestamp2String(bps.getLastModifiedDate()));
			} catch (ParseException e) {
			}
			bpsv.setJobStatus(bps.getJobStatus().name());
			bpsv.setStacktrace(bps.getStacktrace());
			list.add(bpsv);
		}
		return list;
	}

}
