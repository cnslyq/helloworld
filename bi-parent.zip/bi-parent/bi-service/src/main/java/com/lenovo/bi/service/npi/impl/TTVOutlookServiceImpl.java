package com.lenovo.bi.service.npi.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.npi.NPIProductSummaryDao;
import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.dto.Forecast;
import com.lenovo.bi.dto.TTVOutlookChartData;
import com.lenovo.bi.dto.TTVOutlookDetractorCode;
import com.lenovo.bi.engine.ProductKeyPmsWaveIdMap;
import com.lenovo.bi.enumobj.CausesCategory;
import com.lenovo.bi.enumobj.ForecastComparisonTypeEnum;
import com.lenovo.bi.enumobj.TTVCause;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.enumobj.TimeFrequencyEnum;
import com.lenovo.bi.exception.BusinessException;
import com.lenovo.bi.form.simulation.NPISimulationPreviewData;
import com.lenovo.bi.model.ForecastData;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.model.OrderData;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.model.SGATtvWeeklyDetail;
import com.lenovo.bi.model.SGATtvWeeklySummary;
import com.lenovo.bi.model.TtvDailyDetail;
import com.lenovo.bi.model.TtvDailySummary;
import com.lenovo.bi.model.TtvWeeklyDetail;
import com.lenovo.bi.model.TtvWeeklySummary;
import com.lenovo.bi.service.npi.RampCommitService;
import com.lenovo.bi.service.npi.TTVOutlookService;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.MathUtil;
import com.lenovo.bi.view.npi.ForecastCompare;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.Capacity;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.ForecastCause;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.OrderCause;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.Quality;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.TtvGridTrackingCauses;

@Service("TTVOutlookServiceImpl")
@Profile("production")
public class TTVOutlookServiceImpl implements TTVOutlookService {
	@Autowired
	private TTVOutlookServiceBiHelper biHelper;

	@Autowired
	private TTVOutlookServiceDwHelper dwHelper;

	@Autowired
	private ProductKeyPmsWaveIdMap productKeyPmsWaveIdMap;

	@Autowired
	private RampCommitService rampCommitService;

	@Inject
	private NPIProductSummaryDao nPIProductSummaryDao;
	
	@Override
	public List<TTVOutlookChartData> getChartData(int waveId, Date startDate, Date endDate, TimeFrequencyEnum timeFrequency, boolean odmFpy, Date versionDate,
			boolean isShowSGA, boolean isSnapshort) {
		if (timeFrequency == TimeFrequencyEnum.WEEKLY) {
			Date startMonday = CalendarUtil.getMondayDateByDate(startDate);
			Date endMonday = CalendarUtil.getMondayDateByDate(endDate);

			// Get lists ordered by target date
			List<TtvWeeklyDetail> details = biHelper.getLastNpiWeeklyDetail(waveId, startMonday, endMonday, versionDate);
			List<NpiOrder> excludeOrders;
			if(isSnapshort){
				excludeOrders = biHelper.getTTVExcludedOrder(waveId, TTVPhase.sle, versionDate != null ? versionDate : CalendarUtil.getTodayWithoutMins());
			}else{
				excludeOrders = biHelper.getTTVExcludedOrder(waveId, TTVPhase.sle, CalendarUtil.getTodayWithoutMins());
			}
			if (CollectionUtils.isNotEmpty(excludeOrders)) {
				biHelper.excludeOrders(details, excludeOrders);
			}
			List<TtvWeeklySummary> summaries = biHelper.getLastNpiWeeklySummary(waveId, startMonday, endMonday, versionDate);
			List<SGATtvWeeklySummary> sgaSummaries = null;
			if (isShowSGA) {
				sgaSummaries = biHelper.getLastSgaNpiWeeklySummary(waveId, startMonday, endMonday, versionDate);
			}

			List<TTVOutlookChartData> dataList = mapWeeklyDataToChartData(summaries, details, odmFpy, sgaSummaries);
			return dataList;
		} else {
			// Get lists ordered by target date
			List<TtvDailyDetail> details = biHelper.getNpiDailyDetail(waveId, startDate, endDate);
			List<TtvDailySummary> summaries = biHelper.getNpiDailySummary(waveId, startDate, endDate);

			List<TTVOutlookChartData> dataList = mapDailyDataToChartData(summaries, details, odmFpy);
			return dataList;
		}
	}

	@Override
	public List<TTVOutlookChartData> getSgaChartData(int waveId, Date startDate, Date endDate, TimeFrequencyEnum timeFrequency, boolean odmFpy,
			Date versionDate, boolean isShowSle, boolean isSnapshort) throws BusinessException {
		if (timeFrequency == TimeFrequencyEnum.WEEKLY) {			
			// fetch wave info
			ProjectSummary ps = nPIProductSummaryDao.getProductInfoByWaveId(waveId, null);
			//Date ssDate = CalendarUtil.getMondayDateByDate(ps.getTtmTargetDate());
			Date ssDate = null;
			if(null != ps.getTtmTargetDate()){
				ssDate = CalendarUtil.getMondayDateByDate(ps.getTtmTargetDate());
			}
			Date startMonday = CalendarUtil.getMondayDateByDate(startDate);
			Date endMonday = CalendarUtil.getMondayDateByDate(endDate);
//			Date currentMonday = CalendarUtil.getMondayDateByDate(Calendar.getInstance().getTime());

			// Get lists ordered by target date
			List<SGATtvWeeklyDetail> details = biHelper.getLastSgaNpiWeeklyDetail(waveId, ssDate, startMonday, endMonday, versionDate);
			List<NpiOrder> excludeOrders;
			if(isSnapshort){
				excludeOrders = biHelper.getTTVExcludedOrder(waveId, TTVPhase.sga, versionDate != null ? versionDate : CalendarUtil.getTodayWithoutMins());
			}else{
				excludeOrders = biHelper.getTTVExcludedOrder(waveId, TTVPhase.sga, CalendarUtil.getTodayWithoutMins());
			}
			if (CollectionUtils.isNotEmpty(excludeOrders)) {
				biHelper.excludeOrders(details, excludeOrders);
			}
			List<SGATtvWeeklySummary> summaries = biHelper.getLastSgaNpiWeeklySummary(waveId, startMonday, endMonday, versionDate);
			if(CollectionUtils.isEmpty(summaries)){
				//throw new BusinessException("No Forecast Or RampCommit");
				Map<Long, Integer> rampCommitMap = dwHelper.getRampCommitByWaveId(waveId);
				Map<Date, Integer> forecastMap = dwHelper.getSGAForecastByWaveId(waveId);
				if(rampCommitMap.isEmpty() && forecastMap.isEmpty()){
					throw new BusinessException("No Forecast And RampCommit");
				}else if(rampCommitMap.isEmpty()){
					throw new BusinessException("No RampCommit");
				}else if(forecastMap.isEmpty()){
					throw new BusinessException("No Forecast");
				}else{
					throw new BusinessException("No SGA Data For Start Week : " + new SimpleDateFormat("yyyy-MM-dd").format(startDate));
				}
				/*
				boolean forecastFlag = false;
				boolean rampCommitFlag = false;
				for(SGATtvWeeklyDetail detail : details){
					if(detail.getForecast() != null){
						forecastFlag = true;
						break;
					}
				}
				for(SGATtvWeeklyDetail detail : details){
					if(detail.getRampCommit() != null){
						rampCommitFlag = true;
						break;
					}
				}
				if(!forecastFlag && !rampCommitFlag){
					throw new BusinessException("No Forecast And RampCommit");
				}else if(!forecastFlag){
					throw new BusinessException("No Forecast");
				}else if(!rampCommitFlag){
					throw new BusinessException("No RampCommit");
				}
				 */
			}
//			List<SGATtvWeeklyDetail> previousDetails = biHelper.getLastSgaNpiWeeklyDetail(waveId, null, currentMonday, versionDate);
			List<TtvWeeklySummary> sleSummaries = null;
			if (isShowSle) {
				sleSummaries = biHelper.getLastNpiWeeklySummary(waveId, startMonday, endMonday, versionDate);
			}

//			int demandRolling = 0;
//			if (previousDetails != null) {
//				for (SGATtvWeeklyDetail weeklyDetail : previousDetails) {
//					demandRolling += (weeklyDetail.getOrderQuantity() - weeklyDetail.getFgQuantity());
//				}
//			}

			return mapWeeklySgaDataToChartData(summaries, details, odmFpy, sleSummaries);
		} else {
			return null;
		}
	}
	@Override
	public List<TTVOutlookChartData> simulationSLEPreview(int waveId,boolean odmFpy,Date versionDate,Date startDate,Date endDate,boolean isShowSga,Map<String,NPISimulationPreviewData> previewDataMap){
		List<TtvWeeklyDetail> npiWeeklyDetails = biHelper.getNpiWeeklyDetail(waveId, null, null, versionDate);
		/*List<NpiOrder> excludeOrders = biHelper.getTTVExcludedOrder(waveId, TTVPhase.sle, versionDate != null ? versionDate : CalendarUtil.getTodayWithoutMins());
		if (CollectionUtils.isNotEmpty(excludeOrders)) {
			biHelper.excludeOrders(npiWeeklyDetails, excludeOrders);
		}*/
		if(previewDataMap != null && CollectionUtils.isNotEmpty(npiWeeklyDetails)){
			NPISimulationPreviewData previewData = null;
			for(TtvWeeklyDetail detail : npiWeeklyDetails){
				try {
					previewData = previewDataMap.get(CalendarUtil.date2String(detail.getTargetDate()));
				} catch (ParseException e) {
					previewData = null;
					e.printStackTrace();
				}
				if(previewData != null){
					if(previewData.getCoverA()>0){
						detail.setCoverA(previewData.getCoverA());
					}
					if(previewData.getCoverB()>0){
						detail.setCoverB(previewData.getCoverB());
					}
					if(previewData.getCoverC()>0){
						detail.setCoverC(previewData.getCoverC());			
					}
					if(previewData.getCoverD()>0){
						detail.setCoverD(previewData.getCoverD());
					}
					if(previewData.getSupplyCommit()>0){
						detail.setSupplyCommit(previewData.getSupplyCommit());
					}
					if(previewData.getOdmOutPut()>0){
						if(odmFpy){
							detail.setOdmFpyCapacity(previewData.getOdmOutPut());
							detail.setOdmRpyCapacity(previewData.getOdmOutPut());
						}else{
							detail.setTdmsFpyCapacity(previewData.getOdmOutPut());
							detail.setTdmsRpyCapacity(previewData.getOdmOutPut());
						}
					}
				}
			}
		}
		List<NpiOrder> excludedOrders = biHelper.getTTVExcludedOrder(waveId, TTVPhase.sle, versionDate);
		List<TtvWeeklySummary> ttvWeeklySummaries = biHelper.calculateTtvWeeklySummary(versionDate, true, npiWeeklyDetails,null,excludedOrders);
		List<SGATtvWeeklySummary> sgaSummaries = null;
		if (isShowSga) {
			sgaSummaries = biHelper.getLastSgaNpiWeeklySummary(waveId, startDate, endDate, versionDate);
		}
		List<TTVOutlookChartData> dataList = mapWeeklyDataToChartData(ttvWeeklySummaries, npiWeeklyDetails, odmFpy, sgaSummaries);
		return dataList;
	}
	@Override
	public List<TTVOutlookChartData> excludeOrderPreview(int waveId, Date startDate, Date endDate, TimeFrequencyEnum timeFrequency, boolean odmFpy,
			Date versionDate, boolean isShowSGA, List<NpiOrder> orders) {
		Date startMonday = CalendarUtil.getMondayDateByDate(startDate);
		Date endMonday = CalendarUtil.getMondayDateByDate(endDate);
		List<TtvWeeklyDetail> npiWeeklyDetails = biHelper.getNpiWeeklyDetail(waveId, null, null, versionDate);

		/*List<NpiOrder> excludedOrders = biHelper.getTTVExcludedOrder(waveId, TTVPhase.sle, versionDate);*/

		List<TtvWeeklySummary> ttvWeeklySummaries = biHelper.calculateSLETTVWeeklySummary(versionDate, npiWeeklyDetails, orders);
		List<SGATtvWeeklySummary> sgaSummaries = null;

		if (isShowSGA) {
			sgaSummaries = biHelper.getSgaNpiWeeklySummary(waveId, startMonday, endMonday, versionDate);
		}

		List<TTVOutlookChartData> dataList = mapWeeklyDataToChartData(ttvWeeklySummaries, npiWeeklyDetails, odmFpy, sgaSummaries);
		return dataList;
	}

	@Override
	public List<TTVOutlookChartData> excludeSGAOrderPreview(int waveId, Date startDate, Date endDate, TimeFrequencyEnum timeFrequency, boolean odmFpy,
			Date versionDate, boolean isShowSLE, List<NpiOrder> orders) {
		Date startMonday = CalendarUtil.getMondayDateByDate(startDate);
		Date endMonday = CalendarUtil.getMondayDateByDate(endDate);
//		Date currentMonday = CalendarUtil.getMondayDateByDate(Calendar.getInstance().getTime());
		List<SGATtvWeeklyDetail> npiWeeklyDetails = biHelper.getSgaNpiWeeklyDetail(waveId, null, null, versionDate);
		if (CollectionUtils.isNotEmpty(orders)) {
			biHelper.excludeOrders(npiWeeklyDetails, orders);
		}
		biHelper.setToGoOrder(npiWeeklyDetails);

		List<SGATtvWeeklySummary> ttvWeeklySummaries = dwHelper.calculateSGATtvWeeklySummary(waveId, npiWeeklyDetails);
		List<TtvWeeklySummary> sleSummaries = null;

		if (isShowSLE) {
			sleSummaries = biHelper.getNpiWeeklySummary(waveId, startMonday, endMonday, versionDate);
		}
//		int demandRolling = 0;
//		List<SGATtvWeeklyDetail> previousDetails = biHelper.getSgaNpiWeeklyDetail(waveId, null, currentMonday, versionDate);
//		if (previousDetails != null) {
//			for (SGATtvWeeklyDetail weeklyDetail : previousDetails) {
//				demandRolling += (weeklyDetail.getOrderQuantity() - weeklyDetail.getFgQuantity());
//			}
//		}
		// filter target dates

		return mapWeeklySgaDataToChartData(ttvWeeklySummaries, npiWeeklyDetails, odmFpy, sleSummaries);

	}

	@Override
	public void calculateChartData(int waveId) {

	}

	/* (non-Javadoc)
	 * 计算所有的cause
	 * @see com.lenovo.bi.service.npi.TTVOutlookService#getCause(int, java.util.Date, com.lenovo.bi.enumobj.TimeFrequencyEnum, boolean, java.util.Date)
	 */
	@Override
	public TtvGridTrackingCauses getCause(int waveId, Date startDate, TimeFrequencyEnum timeFrequency, boolean odmFpy, Date versionDate) {

		TtvGridTrackingCauses ttv = new TtvGridTrackingCauses();
		String key = String.valueOf(waveId);
		// calculate capacity causes
//		versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins());
		List<TTVOutlookChartData> tTVOutlookChartDataList = this.getChartData(waveId, startDate, startDate, timeFrequency, odmFpy, versionDate, false,false);
		if (CollectionUtils.isNotEmpty(tTVOutlookChartDataList)) {
			ttv.setCapacityList(transFormCapacityData(tTVOutlookChartDataList));
			versionDate = tTVOutlookChartDataList.get(0).getVersionDate();
		}
		// calculate order causes
		List<NpiWeeklyComponentCommitmentOnOrder> orders = biHelper.getOrderByProduct(key, versionDate, startDate, TTVPhase.sle);
		if (CollectionUtils.isNotEmpty(orders)) {
			ttv.setOrderList(transFormOrderData(orders));
		}
		// calculate forecast causes
		List<NpiWeeklyComponentCommitmentOnForecast> forecastList = biHelper.getForecastDataByProductKey(String.valueOf(waveId), startDate, versionDate, TTVPhase.sle);
		if (!forecastList.isEmpty()) {
				ttv.setForecastList(transFormForecastData(forecastList));
		}
		// calculate quality causes
		if (!odmFpy) {
			List<Defect> defects = dwHelper.getGatingDefectsByProductWave(waveId, startDate, versionDate);
			if (!defects.isEmpty()) {
				List<Quality> qualityList = new ArrayList<Quality>();

				for (Defect defect : defects) {
					Quality q = new Quality();
					q.setDefectCategory(CausesCategory.DEFECT.name());
					q.setDefectNo(defect.getDefectNo());
					q.setDescription(defect.getDefectTitle());
					q.setGating("Yes");
					q.setFailRate(String.valueOf(defect.getFailRate()));
					q.setStatus(defect.getIsOpen() ? "Open" : "Closed");
					q.setOwner(defect.getOwner());
					try {
						q.setTargetDate(CalendarUtil.date2String(defect.getTargetDate()));
						q.setReportDate(CalendarUtil.date2String(defect.getCreateDate()));
					} catch (ParseException e) {

					}
					qualityList.add(q);
				}

				ttv.setQualityList(qualityList);
			}
		}
		return ttv;
	}

	@SuppressWarnings("unused")
	private List<OrderCause>  c (List<NpiWeeklyComponentCommitmentOnOrder> orderList) {
		List<OrderCause> list = new ArrayList<OrderCause>();
		long upsideValue = 0;
		long offsetValue = 0;
		long forecastQuantity = 0;
		for (NpiWeeklyComponentCommitmentOnOrder od : orderList) {
			if (ForecastComparisonTypeEnum.UPSIDE.name() .equalsIgnoreCase(od.getOrderLabel()) ) {
				upsideValue += od.getAbnormalQuantity();
				forecastQuantity += od.getQuantity();
			} else if (ForecastComparisonTypeEnum.OFFSET.name().equalsIgnoreCase(od.getOrderLabel()) ) {
				offsetValue += od.getAbnormalQuantity();
			}
		}

		if (offsetValue > 0) {
			OrderCause offset = new OrderCause();
			offset.setCausesCategory(CausesCategory.DEMAND.getCause());
			offset.setCauses(TTVCause.order_offset.getCause());
			offset.setUnit(TTVCause.order_offset.getUnit());
			offset.setForecastQuantity(0);
			offset.setOrderQuantity(offsetValue);
			offset.setGap(offsetValue);
			list.add(offset);
		}

		if (upsideValue > 0) {
			OrderCause upside = new OrderCause();
			upside.setCausesCategory(CausesCategory.DEMAND.getCause());
			upside.setCauses(TTVCause.order_upside.getCause());
			upside.setUnit(TTVCause.order_upside.getUnit());
			upside.setForecastQuantity(forecastQuantity);
			upside.setOrderQuantity(upsideValue);
			upside.setGap(upside.getOrderQuantity() - upside.getForecastQuantity());
			list.add(upside);
		}

		return list.isEmpty() ? null : list;
	}

	private List<ForecastCause> transFormForecastData(List<NpiWeeklyComponentCommitmentOnForecast> forecastList) {

		List<ForecastCause> list = new ArrayList<ForecastCause>();
		long upsideValue = 0;
		long offsetValue = 0;
		long forecastQuantity = 0;
		for (NpiWeeklyComponentCommitmentOnForecast fd : forecastList) {
			if (ForecastComparisonTypeEnum.UPSIDE.name() .equalsIgnoreCase( fd.getForecastLabel())) {
				upsideValue += fd.getAbnormalQuantity();
				forecastQuantity += fd.getQuantity();
			} else if (ForecastComparisonTypeEnum.OFFSET.name() .equalsIgnoreCase(  fd.getForecastLabel())) {
				offsetValue += fd.getAbnormalQuantity();
			}
		}
		if (offsetValue > 0) {
			ForecastCause offset = new ForecastCause();
			offset.setCausesCategory(CausesCategory.DEMAND.getCause());
			offset.setCauses(TTVCause.forecast_offset.getCause());
			offset.setUnit(TTVCause.forecast_offset.getUnit());
			offset.setPrevForecastQuantity(0);
			offset.setCurForecastQuantity(offsetValue);
			offset.setGap(offsetValue);
			list.add(offset);
		}

		if (upsideValue > 0) {
			ForecastCause upside = new ForecastCause();
			upside.setCausesCategory(CausesCategory.DEMAND.getCause());
			upside.setCauses(TTVCause.forecast_upside.getCause());
			upside.setUnit(TTVCause.forecast_upside.getUnit());
			upside.setPrevForecastQuantity(forecastQuantity - upsideValue);
			upside.setCurForecastQuantity(forecastQuantity);
			upside.setGap(upsideValue);
			list.add(upside);
		}
		return list.isEmpty() ? null : list;
	}
	private List<OrderCause> transFormOrderData(List<NpiWeeklyComponentCommitmentOnOrder> forecastList) {

		List<OrderCause> list = new ArrayList<OrderCause>();
		long upsideValue = 0;
		long offsetValue = 0;
		long orderQuantity = 0;
		for (NpiWeeklyComponentCommitmentOnOrder fd : forecastList) {
			if (ForecastComparisonTypeEnum.UPSIDE.name().equalsIgnoreCase(fd.getOrderLabel())) {
				upsideValue += fd.getAbnormalQuantity();
				orderQuantity += fd.getQuantity();
			} else if (ForecastComparisonTypeEnum.OFFSET.name().equalsIgnoreCase(fd.getOrderLabel())) {
				offsetValue += fd.getAbnormalQuantity();
			}
		}
		if (offsetValue > 0) {
			OrderCause offset = new OrderCause();
			offset.setCausesCategory(CausesCategory.DEMAND.getCause());
			offset.setCauses(TTVCause.order_offset.getCause());
			offset.setUnit(TTVCause.order_offset.getUnit());
			offset.setForecastQuantity(0);
			offset.setOrderQuantity(offsetValue);
			offset.setGap(offsetValue);
			list.add(offset);
		}

		if (upsideValue > 0) {
			OrderCause upside = new OrderCause();
			upside.setCausesCategory(CausesCategory.DEMAND.getCause());
			upside.setCauses(TTVCause.order_upside.getCause());
			upside.setUnit(TTVCause.order_upside.getUnit());
			upside.setForecastQuantity(orderQuantity - upsideValue);
			upside.setOrderQuantity(orderQuantity);
			upside.setGap(upsideValue);
			list.add(upside);
		}
		return list.isEmpty() ? null : list;
	}
	private List<Capacity> transFormCapacityData(List<TTVOutlookChartData> tTVOutlookChartDataList) {

		List<Capacity> capacitylist = new ArrayList<Capacity>();

		long toolingCapacity = 0;
		long odmCapacity = 0;
		long supplyCapacity = 0;
		long demand = 0;
		for (TTVOutlookChartData tTVOutlookChartData : tTVOutlookChartDataList) {
			if(tTVOutlookChartData.getOdm() != null){
				odmCapacity = tTVOutlookChartData.getOdm();
			}
			if(tTVOutlookChartData.getTooling() != null){
				toolingCapacity = tTVOutlookChartData.getTooling();
			}
			if(tTVOutlookChartData.getSupply() != null){
				supplyCapacity = tTVOutlookChartData.getSupply();
			}
			demand = (tTVOutlookChartData.getFutureForecast() == null ? 0 : tTVOutlookChartData.getFutureForecast()) 
					+ (tTVOutlookChartData.getFutureOrder() == null ? 0 : tTVOutlookChartData.getFutureOrder()); // todo:
																										// confirm
																										// with
																										// hanying
			if (odmCapacity > 0 && odmCapacity < demand) {
				Capacity capacity = new Capacity();
				capacity.setCauses(TTVCause.odm.getCause());
				capacity.setCausesCategory(CausesCategory.ODM_CAPACITY.getCause());
				capacity.setEstimatedCapacity(odmCapacity);
				capacity.setUnit(TTVCause.odm.getUnit());
				capacity.setDemand(demand);
				capacity.setGap(demand - capacity.getEstimatedCapacity());
				capacitylist.add(capacity);
			}
			if (supplyCapacity >0 && supplyCapacity < demand) {
				Capacity capacity = new Capacity();
				capacity.setCauses(TTVCause.supply.getCause());
				capacity.setCausesCategory(CausesCategory.SUPPLY_CAPACITY.getCause());
				capacity.setEstimatedCapacity(supplyCapacity);
				capacity.setUnit(TTVCause.supply.getUnit());
				capacity.setDemand(demand);
				capacity.setGap(demand - capacity.getEstimatedCapacity());
				capacitylist.add(capacity);
			}
			if (toolingCapacity >0 && toolingCapacity < demand) {
				Capacity capacity = new Capacity();
				capacity.setCauses(TTVCause.tooling.getCause());
				capacity.setCausesCategory(CausesCategory.TOOLING_CAPACITY.getCause());
				capacity.setEstimatedCapacity(toolingCapacity);
				capacity.setUnit(TTVCause.tooling.getUnit());
				capacity.setDemand(demand);
				capacity.setGap(demand - capacity.getEstimatedCapacity());
				capacitylist.add(capacity);
			}
		}
		return capacitylist.isEmpty() ? null : capacitylist;
	}

	private List<Capacity> transFormSgaCapacityData(List<TTVOutlookChartData> tTVOutlookChartDataList, int rampCommit) {

		List<Capacity> capacitylist = new ArrayList<Capacity>();

		long toolingCapacity = 0;
		long odmCapacity = 0;
		long supplyCapacity = 0;
		long demand = 0;
		for (TTVOutlookChartData tTVOutlookChartData : tTVOutlookChartDataList) {
			odmCapacity = tTVOutlookChartData.getOdm();
			toolingCapacity = tTVOutlookChartData.getTooling();
			supplyCapacity = tTVOutlookChartData.getSupply();
			if(rampCommit>0){
				demand = Math.min(tTVOutlookChartData.getForecast(), rampCommit);
			}else{
				demand = tTVOutlookChartData.getForecast();
			}
			if (odmCapacity > 0 && odmCapacity < demand) {
				Capacity capacity = new Capacity();
				capacity.setCauses(TTVCause.odm.getCause());
				capacity.setCausesCategory(CausesCategory.ODM_CAPACITY.getCause());
				capacity.setEstimatedCapacity(odmCapacity);
				capacity.setUnit(TTVCause.odm.getUnit());
				capacity.setDemand(demand);
				capacity.setGap(demand - capacity.getEstimatedCapacity());
				capacitylist.add(capacity);
			}
			if (supplyCapacity >0 && supplyCapacity < demand) {
				Capacity capacity = new Capacity();
				capacity.setCauses(TTVCause.supply.getCause());
				capacity.setCausesCategory(CausesCategory.SUPPLY_CAPACITY.getCause());
				capacity.setEstimatedCapacity(supplyCapacity);
				capacity.setUnit(TTVCause.supply.getUnit());
				capacity.setDemand(demand);
				capacity.setGap(demand - capacity.getEstimatedCapacity());
				capacitylist.add(capacity);
			}
			if (toolingCapacity > 0 && toolingCapacity < demand) {
				Capacity capacity = new Capacity();
				capacity.setCauses(TTVCause.tooling.getCause());
				capacity.setCausesCategory(CausesCategory.TOOLING_CAPACITY.getCause());
				capacity.setEstimatedCapacity(toolingCapacity);
				capacity.setUnit(TTVCause.tooling.getUnit());
				capacity.setDemand(demand);
				capacity.setGap(demand - capacity.getEstimatedCapacity());
				capacitylist.add(capacity);
			}
		}
		return capacitylist.isEmpty() ? null : capacitylist;
	}

	@Override
	public List<TTVOutlookDetractorCode> getDetractorCode(int waveId, Date startDate, TimeFrequencyEnum timeFrequency) {
		return null;
	}

	private List<TTVOutlookChartData> mapWeeklyDataToChartData(List<TtvWeeklySummary> ttvWeeklySummaries, List<TtvWeeklyDetail> ttvWeeklyDetails,
			boolean odmFpy, List<SGATtvWeeklySummary> sgaTtvWeeklySummaries) {

		List<TTVOutlookChartData> dataList = new ArrayList<TTVOutlookChartData>();
		// covert list to map so that it would be easier to grab the object
		// based on target date
		Map<Date, TtvWeeklyDetail> map = new HashMap<Date, TtvWeeklyDetail>();
		for (TtvWeeklyDetail td : ttvWeeklyDetails) {
			map.put(td.getTargetDate(), td);
		}

		Map<Date, SGATtvWeeklySummary> sgaSummaryMap = new HashMap<Date, SGATtvWeeklySummary>();
		if (CollectionUtils.isNotEmpty(sgaTtvWeeklySummaries)) {
			for (SGATtvWeeklySummary td : sgaTtvWeeklySummaries) {
				sgaSummaryMap.put(td.getTargetDate(), td);
			}
		}

		for (int i = 0; i < ttvWeeklySummaries.size(); i++) {
			TtvWeeklySummary summary = ttvWeeklySummaries.get(i);

			Date targetDate = summary.getTargetDate();
			TtvWeeklyDetail detail = map.get(targetDate);
			if (detail == null) {
				continue;
			}
			SGATtvWeeklySummary sgaSummary = sgaSummaryMap.get(targetDate);

			Date thisMonday = CalendarUtil.adjustTimeToMidnight(CalendarUtil.getMondayDateByDate(summary.getVersionDate()));
			TTVOutlookChartData data = new TTVOutlookChartData();
			data.setVersionDate(summary.getVersionDate());
			data.setDate(targetDate);
			data.setOdmCommit(detail.getOdmCommit());
			if(odmFpy){
				data.setDemand(summary.getAccumulatedDemand() - summary.getAccumulatedCapacityOdm()+summary.getWeeklyCapacityOdm());
			} else{
				data.setDemand(summary.getAccumulatedDemand() - summary.getAccumulatedCapacityTdms()+summary.getWeeklyCapacityTdms());
			}
			
			if (targetDate.before(thisMonday)) {
				data.setOrder(detail.getOrderQuantity());
				//data.setShipment(detail.getShipQuantity());
				data.setShipment(detail.getFgQuantity());
			} else {
				data.setFutureOrder(detail.getFutureOrderQuantity());
				data.setFutureForecast(detail.getFutureForecastQuantity());
				// supply commit
				data.setSupply(detail.getSupplyCommit());
				// tooling capacity
				data.setTooling(MathUtil.min(detail.getCoverA(), detail.getCoverB(), detail.getCoverC(), detail.getCoverD()));

				if (odmFpy) {
					data.setCapacity(summary.getWeeklyCapacityOdm());
					data.setOdm(detail.getOdmRpyCapacity());
				} else {
					data.setCapacity(summary.getWeeklyCapacityTdms());
					data.setOdm(detail.getTdmsRpyCapacity());
				}
			}

			if (odmFpy) {
				data.setGap(summary.getWeeklyGapOdm() >= 0 ? summary.getWeeklyGapOdm() : 0);
				data.setTotalGap(summary.getTotalWeeklyGapOdm());
				data.setTtv(summary.getTtvOdm());
				if (sgaSummary != null) {
					data.setSgaTTV(sgaSummary.getTtvOdm());
				} else {
					data.setSgaTTV(0f);
				}
			} else {
				data.setGap(summary.getWeeklyCapacityTdms() >= 0 ? summary.getWeeklyCapacityTdms() : 0);
				data.setTotalGap(summary.getTotalWeeklyGapTdms());
				data.setTtv(summary.getTtvTdms());
				if (sgaSummary != null) {
					data.setSgaTTV(sgaSummary.getTtvTdms());
				} else {
					data.setSgaTTV(0f);
				}
			}
			dataList.add(data);
		}

		return dataList;
	}

	private List<TTVOutlookChartData> mapWeeklySgaDataToChartData(List<SGATtvWeeklySummary> ttvWeeklySummaries, List<SGATtvWeeklyDetail> ttvWeeklyDetails,
			boolean odmFpy, List<TtvWeeklySummary> sleTtvWeeklySummaries) {

		List<TTVOutlookChartData> dataList = new ArrayList<TTVOutlookChartData>();
		// covert list to map so that it would be easier to grab the object
		// based on target date
		Map<Date, SGATtvWeeklyDetail> map = new HashMap<Date, SGATtvWeeklyDetail>();
		for (SGATtvWeeklyDetail td : ttvWeeklyDetails) {
			map.put(td.getTargetDate(), td);
		}

		Map<Date, TtvWeeklySummary> sleSummaryMap = new HashMap<Date, TtvWeeklySummary>();
		if (CollectionUtils.isNotEmpty(sleTtvWeeklySummaries)) {
			for (TtvWeeklySummary td : sleTtvWeeklySummaries) {
				sleSummaryMap.put(td.getTargetDate(), td);
			}
		}
		if (CollectionUtils.isEmpty(ttvWeeklySummaries)) {
			return null;
		}
		for (int i = 0; i < ttvWeeklySummaries.size(); i++) {
			SGATtvWeeklySummary summary = ttvWeeklySummaries.get(i);

			Date targetDate = summary.getTargetDate();
			SGATtvWeeklyDetail detail = map.get(targetDate);
			// in case the detail object is null
			if (detail == null) {
				continue;
			}
			TtvWeeklySummary sleSummary = sleSummaryMap.get(targetDate);

			TTVOutlookChartData data = new TTVOutlookChartData();
			data.setDate(targetDate);
//			data.setDemandRolling(demandRolling);
			data.setTooling(MathUtil.min(detail.getCoverA(), detail.getCoverB(), detail.getCoverC(), detail.getCoverD()));
			data.setShipment(detail.getFgQuantity());
			data.setFutureOrder(detail.getFutureOrderQuantity());
			data.setFutureForecast(detail.getFutureForecastQuantity());
			data.setSupply(detail.getSupplyCommit());
			data.setOdmCommit(detail.getRampCommit());
			data.setRampCommit(detail.getRampCommit());
			data.setForecast(detail.getForecast());
			data.setOrder(detail.getOrderQuantity());
			if(odmFpy){
				data.setDemand(summary.getAccumulatedDemand() - summary.getAccumulatedCapacityOdm()+summary.getWeeklyCapacityOdm());
			} else{
				data.setDemand(summary.getAccumulatedDemand() - summary.getAccumulatedCapacityTdms()+summary.getWeeklyCapacityTdms());
			}
			
			if (sleSummary != null) {
				data.setTtv(sleSummary.getTtvTdms());
			} else {
				data.setTtv(0f);
			}
			if (odmFpy) {
				data.setCapacity(summary.getWeeklyCapacityOdm());
				data.setGap(summary.getWeeklyGapOdm());
				data.setTotalGap(summary.getTotalWeeklyGapOdm());
				data.setOdm(detail.getOdmRpyCapacity());
				data.setSgaTTV(summary.getTtvOdm());
			} else {
				data.setCapacity(summary.getWeeklyCapacityTdms());
				data.setGap(summary.getWeeklyGapTdms());
				data.setTotalGap(summary.getTotalWeeklyGapTdms());
				data.setOdm(detail.getTdmsRpyCapacity());
				data.setSgaTTV(summary.getTtvTdms());
			}
			dataList.add(data);
		}

		return dataList;
	}

	private List<TTVOutlookChartData> mapDailyDataToChartData(List<TtvDailySummary> ttvDailySummaries, List<TtvDailyDetail> ttvDailyDetails, boolean odmFpy) {
		List<TTVOutlookChartData> dataList = new ArrayList<TTVOutlookChartData>();

		for (int i = 0; i < ttvDailySummaries.size(); i++) {
			TtvDailySummary summary = ttvDailySummaries.get(i);
			if (i >= ttvDailyDetails.size()) {
				break;
			}
			TtvDailyDetail detail = ttvDailyDetails.get(i);
			Date targetDate = summary.getTargetDate();

			Date todayMidnight = CalendarUtil.adjustTimeToMidnight(new Date());
			TTVOutlookChartData data = new TTVOutlookChartData();

			data.setDate(targetDate);
			data.setOdmCommit(detail.getOdmCommit());
			if (targetDate.before(todayMidnight)) {
				data.setOrder(detail.getOrderQuantity());
				data.setShipment(detail.getShipQuantity());
			} else {
				data.setFutureOrder(detail.getFutureDemandQuantity());
				data.setDemand(summary.getAccumulatedDemand());
				if (odmFpy) {
					data.setCapacity(summary.getDailyCapacityOdm());
				} else {
					data.setCapacity(summary.getDailyCapacityTdms());
				}
			}

			if (odmFpy) {
				data.setGap(summary.getDailyGapOdm() >= 0 ? summary.getDailyGapOdm() : 0);
				data.setTotalGap(summary.getTotalDailyGapOdm());
				data.setTtv(summary.getTtvOdm());
			} else {
				data.setGap(summary.getDailyCapacityTdms() >= 0 ? summary.getDailyCapacityTdms() : 0);
				data.setTotalGap(summary.getTotalDailyGapTdms());
				data.setTtv(summary.getTtvTdms());
			}

			dataList.add(data);
		}
		return dataList;
	}

	@Override
	public Map<Date, List<Forecast>> getForecastVersions(int waveId, Date targetDate, Date versionDate, int versionCount,boolean showGeo) {
		Date versionEndWeek = CalendarUtil.getMondayDateByWeeks(versionDate, versionCount);//-8周之后的
		return dwHelper.getForecastByRange(waveId, targetDate, versionEndWeek, versionDate,showGeo);
	}

	@Override
	public List<ForecastCompare> getForecastComparison(int waveId, Date targetDate,Date comparedDate,Date compareDate,String region) {
//		String productKey=dwHelper.getProductKeyByPmsWaveId(waveId);
		
		List<ForecastCompare> list=dwHelper.getForecastByDates(String.valueOf(waveId),targetDate,comparedDate,CalendarUtil.getMondayDateByDate(compareDate),region);
		
		for(int k=0;k<list.size();k++){
			ForecastCompare f=list.get(k);
			if(f.getComparedFcst()==0&&f.getFcst()>0){
				f.setOffset(f.getFcst());
			}else if(f.getComparedFcst()!=0&&f.getComparedFcst()>f.getFcst()){
				f.setDownside(f.getComparedFcst()-f.getFcst());
			}else if(f.getComparedFcst()!=0&&f.getFcst()>f.getComparedFcst()){
				f.setUpside(f.getFcst()-f.getComparedFcst());
			}
		}
		return list;
	}

	@Override
	public TtvGridTrackingCauses getSGACause(int waveId, Date startDate, TimeFrequencyEnum timeFrequency, boolean odmFpy, Date versionDate) {
		//Date currentMonday = CalendarUtil.getMondayDateByDate(Calendar.getInstance().getTime());
		Date startMonday = CalendarUtil.getMondayDateByDate(startDate);
		if (!startMonday.before(versionDate)) {
			TtvGridTrackingCauses ttv = new TtvGridTrackingCauses();
			// calculate order causes
//			String key = productKeyPmsWaveIdMap.getProductKeyFromPmsWaveId(String.valueOf(waveId));
//			List<Order> orders = dwHelper.getSGAOrdersInWeekByProduct(startDate, currentMonday,key);
//			if (!orders.isEmpty()) {
//				List<String> poItemNumber = new ArrayList<String>();
//				for (Order order : orders) {
//					poItemNumber.add(order.getPoItem() + order.getPoNumber());
//				}
//				List<OrderData> orderList = biHelper.getOrderDataByProductKey(poItemNumber);
//				if (!orderList.isEmpty()) {
//					ttv.setOrderList(transFormOrderData(orderList));
//				}
//			}
			// calculate capacity causes
//			versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins());
			List<TTVOutlookChartData> tTVOutlookChartDataList = null;
			try {
				tTVOutlookChartDataList = this.getSgaChartData(waveId, startDate, startDate, timeFrequency, odmFpy, versionDate, false,false);
			} catch (BusinessException e1) {
				e1.printStackTrace();
			}
			if (tTVOutlookChartDataList != null && !tTVOutlookChartDataList.isEmpty()) {
				int rampCommit = rampCommitService.getRampCommitQty(waveId, startDate);
				ttv.setCapacityList(transFormSgaCapacityData(tTVOutlookChartDataList, rampCommit));
			}
			// calculate quality causes
			if (!odmFpy) {
				List<Defect> defects = dwHelper.getGatingDefectsByProductWave(waveId, startDate, null);
				if (!defects.isEmpty()) {
					List<Quality> qualityList = new ArrayList<Quality>();
					for (Defect defect : defects) {
						Quality q = new Quality();
						q.setDefectCategory(CausesCategory.DEFECT.name());
						q.setDefectNo(defect.getDefectNo());
						q.setDescription(defect.getDefectTitle());
						q.setGating("Yes");
						q.setFailRate(String.valueOf(defect.getFailRate()));
						q.setStatus(defect.getIsOpen() ? "Open" : "Closed");
						q.setOwner(defect.getOwner());
						try {
							q.setTargetDate(CalendarUtil.date2String(defect.getTargetDate()));
							q.setReportDate(CalendarUtil.date2String(defect.getCreateDate()));
						} catch (ParseException e) {

						}
						qualityList.add(q);
					}
					ttv.setQualityList(qualityList);
				}
			}
			return ttv;
		} else {
			return null;
		}
	}

	@Override
	public List<TTVOutlookChartData> simulationSGAPreview(int waveId,
			Date startDate, Date endDate, TimeFrequencyEnum weekly,
			boolean odmFpy, Date versionDate, boolean showSle,
			Map<String, NPISimulationPreviewData> previewDataMap) {
		Date startMonday = CalendarUtil.getMondayDateByDate(startDate);
		Date endMonday = CalendarUtil.getMondayDateByDate(endDate);
		List<SGATtvWeeklyDetail> npiWeeklyDetails = biHelper.getSgaNpiWeeklyDetail(waveId, null, null, versionDate);
		//excludeOrder
		List<NpiOrder> excludeOrders;
		excludeOrders = biHelper.getTTVExcludedOrder(waveId, TTVPhase.sga, CalendarUtil.getTodayWithoutMins());
		if (CollectionUtils.isNotEmpty(excludeOrders)) {
			biHelper.excludeOrders(npiWeeklyDetails, excludeOrders);
		}
		if(previewDataMap != null && CollectionUtils.isNotEmpty(npiWeeklyDetails)){
			NPISimulationPreviewData previewData = null;
			for(SGATtvWeeklyDetail detail : npiWeeklyDetails){
				try {
					previewData = previewDataMap.get(CalendarUtil.date2String(detail.getTargetDate()));
				} catch (ParseException e) {
					previewData = null;
					e.printStackTrace();
				}
				if(previewData != null){
					if(previewData.getCoverA()>0){
						detail.setCoverA(previewData.getCoverA());
					}
					if(previewData.getCoverB()>0){
						detail.setCoverB(previewData.getCoverB());
					}
					if(previewData.getCoverC()>0){
						detail.setCoverC(previewData.getCoverC());			
					}
					if(previewData.getCoverD()>0){
						detail.setCoverD(previewData.getCoverD());
					}
					if(previewData.getSupplyCommit()>0){
						detail.setSupplyCommit(previewData.getSupplyCommit());
					}
					if(previewData.getOdmOutPut()>0){
						if(odmFpy){
							detail.setOdmFpyCapacity(previewData.getOdmOutPut());
							detail.setOdmRpyCapacity(previewData.getOdmOutPut());
						}else{
							detail.setTdmsFpyCapacity(previewData.getOdmOutPut());
							detail.setTdmsRpyCapacity(previewData.getOdmOutPut());
						}
					}
					if(previewData.getRampCommit()>0){
						detail.setRampCommit(previewData.getRampCommit());
					}
				}
			}
		}
		//set output
		biHelper.setOutput(npiWeeklyDetails, versionDate);
		List<SGATtvWeeklySummary> ttvWeeklySummaries = dwHelper.calculateSGATtvWeeklySummary(waveId, npiWeeklyDetails);
		List<TtvWeeklySummary> sleSummaries = null;
		if (showSle) {
			sleSummaries = biHelper.getNpiWeeklySummary(waveId, startMonday, endMonday, versionDate);
		}
		return mapWeeklySgaDataToChartData(ttvWeeklySummaries, npiWeeklyDetails, odmFpy, sleSummaries);
	}
}
