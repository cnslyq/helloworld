package com.lenovo.bi.view.npi.ttv;

import org.apache.commons.lang.StringUtils;

public class ExcludeOrderView {
	/**
	 * o GEO o Region o Country o Order Number o Order Item o MTM o Description
	 * o Quantity: Unit is PCS o Big Order (Y/N): Order type Big Order (hide it
	 * in v1.0 because business is not ready) o Late Order (Y/N): Order Type of
	 * Late Order o Offset Order (Y/N): Order Type of Offsite Order o Upside
	 * Order (Y/N): Order Type of Upside Order o Order Date: it is PO date in
	 * PSD o RSD o FPSD o Ship Date o Ship Status o TTV Target Date: it is SGA
	 * plan date from PMS
	 */

	private String excludedOrderId;
	private String odm;
	private String geo;
	private String region;
	private String country;
	private String orderNumber;
	private String orderItem;
	private String mtm;
	private String description;
	private Integer quantity;
	private String lateOrder = "";
	private String offsetOrder = "";
	private String upsideOrder = "";
	private String orderDate;
	private String rsd;
	private String fgrd;
	private String fpsd;
	private String shipDate;
	private String shipStatus;
	private String ttvTargetDate;
	private String isExcluded;
	private Integer mtmKey;
	private Integer geoKey;
	private Integer regionKey;
	private String fgDate;

	public String getIsExcluded() {
		return isExcluded;
	}

	public void setIsExcluded(String isExcluded) {
		this.isExcluded = isExcluded;
	}

	public String getExcludedOrderId() {
		return excludedOrderId;
	}

	public void setExcludedOrderId(String excludedOrderId) {
		this.excludedOrderId = excludedOrderId;
	}

	public String getGeo() {
		return geo;
	}

	public void setGeo(String geo) {
		this.geo = geo;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(String orderItem) {
		this.orderItem = orderItem;
	}

	public String getMtm() {
		return mtm;
	}

	public void setMtm(String mtm) {
		this.mtm = mtm;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getRsd() {
		return rsd;
	}

	public void setRsd(String rsd) {
		this.rsd = rsd;
	}

	public String getFpsd() {
		return fpsd;
	}

	public void setFpsd(String fpsd) {
		this.fpsd = fpsd;
	}

	public String getShipDate() {
		return shipDate;
	}

	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}

	public String getLateOrder() {
		return lateOrder;
	}

	public void setLateOrder(String lateOrder) {
		this.lateOrder = lateOrder;
	}

	public String getOffsetOrder() {
		return offsetOrder;
	}

	public void setOffsetOrder(String offsetOrder) {
		this.offsetOrder = offsetOrder;
	}

	public String getUpsideOrder() {
		return upsideOrder;
	}

	public void setUpsideOrder(String upsideOrder) {
		this.upsideOrder = upsideOrder;
	}

	public String getShipStatus() {
		return shipStatus;
	}

	public void setShipStatus(String shipStatus) {
		this.shipStatus = shipStatus;
	}

	public String getTtvTargetDate() {
		return ttvTargetDate;
	}

	public void setTtvTargetDate(String ttvTargetDate) {
		this.ttvTargetDate = ttvTargetDate;
	}

	public String getOdm() {
		return odm;
	}

	public void setOdm(String odm) {
		this.odm = odm;
	}

	public String getFgrd() {
		return fgrd;
	}

	public void setFgrd(String fgrd) {
		this.fgrd = fgrd;
	}

	public Integer getMtmKey() {
		return mtmKey;
	}

	public void setMtmKey(Integer mtmKey) {
		this.mtmKey = mtmKey;
	}

	public Integer getGeoKey() {
		return geoKey;
	}

	public void setGeoKey(Integer geoKey) {
		this.geoKey = geoKey;
	}

	public Integer getRegionKey() {
		return regionKey;
	}

	public void setRegionKey(Integer regionKey) {
		this.regionKey = regionKey;
	}

	public String getFgDate() {
		return fgDate;
	}

	public void setFgDate(String fgDate) {
		this.fgDate = fgDate;
	}

	@Override
	public int hashCode() {
		return excludedOrderId.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		ExcludeOrderView other = (ExcludeOrderView) obj;
		return this.isStringEquals(excludedOrderId, other.getExcludedOrderId());
	}

	private boolean isStringEquals(String str1, String str2) {
		if (StringUtils.isNotBlank(str1)) {
			return str1.equals(str2);
		} else {
			if (StringUtils.isBlank(str2)) {
				return true;
			} else {
				return false;
			}
		}
	}

}
