package com.lenovo.bi.engine;

import java.util.Comparator;

import com.lenovo.bi.dto.Order;
import com.lenovo.bi.util.CalendarUtil;

public class OrderDateQuantityComparator implements Comparator<Order> {

	@Override
	public int compare(Order o1, Order o2) {
		if (CalendarUtil.isSameDay(o1.getOrderDate(), o2.getOrderDate())) {
			return o1.getQuantity() - o2.getQuantity();
		}
		else {
			if (o1.getOrderDate().before(o2.getOrderDate())) {
				return -1;
			}
			else {
				return 1;
			}
		}
	}


}
