package com.lenovo.bi.dao.npi.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.dao.npi.UserDao;
import com.lenovo.bi.model.User;
/**
 * 
 * 
 * @author Henry_Lian
 *
 */
@Repository
public class UserDaoImpl extends HibernateBaseDaoImplBi<User> implements UserDao {

	@Override
	public User getUserById(String userId) {
		String hql = "from User where userId = :userid";
		Query q=getSession().createQuery(hql.toString());
		q.setString("userid", userId);
		List<User> list =  q.list();
		if (!list.isEmpty()){
			return list.get(0);
		} else{
			return null;
		}
	}

}
