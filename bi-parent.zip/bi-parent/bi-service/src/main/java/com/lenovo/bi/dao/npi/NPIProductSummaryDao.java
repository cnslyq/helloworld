package com.lenovo.bi.dao.npi;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.NPI;
import com.lenovo.bi.enumobj.NPIPhase;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.model.User;

/**
 * 
 * 
 * @author Henry_Lian
 * 
 */
public interface NPIProductSummaryDao {

	public List<ProjectSummary> getProductInfoByWaveId(List<Integer> waveId, Date versionDate);

	public List<ProjectSummary> getProductInfoByProjectId(int projectId,int waveId, Date versionDate);
	
	public Date getOldestVersionDateByWaveIdAndTTMStatus(int waveId, String ttmStatus);

	public Map<Integer, List<NPI>> getNPIByWaveIds(Integer[] waveIds);

	public Map<Integer, List<String>> getNPIByWaveIds(List<Integer> waveIds);

	public List<String> getNPIByConditions(OverviewSearchForm form, NPIPhase phase);

	public void saveProductSummary(List<ProjectSummary> projectSummaries);

	public void deleteProductSummaryByVersionDate(Date versionDate);

	public User getUser(String userId);

	public ProjectSummary getProductInfoByWaveId(Integer pmsWaveId, Date versionDate);
	@Deprecated
	public List<ProjectSummary> getProductByStatus(List<String> status, Date versionDate);
	
	/**
	 * return the projects that are still open in npi phase.
	 * 
	 * @param status either success or fail
	 * @param versionDate
	 * @return
	 */
	public List<ProjectSummary> getPrevSummary(Date versionDate);
	public boolean isTheProductNpi(String userId,String pmsProductId);
}
