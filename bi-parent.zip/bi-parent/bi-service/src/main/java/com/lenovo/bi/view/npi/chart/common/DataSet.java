package com.lenovo.bi.view.npi.chart.common;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DataSet {

	private List<DataSetParent> dataSetList;
	
	public List<DataSetParent> getDataSetList() {
		return dataSetList;
	}
	
	@JsonProperty("dataset")
	public void setDataSetList(List<DataSetParent> dataSetList) {
		this.dataSetList = dataSetList;
	}
}
