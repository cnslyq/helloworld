package com.lenovo.bi.dao.common.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.common.ToolingCapacityDao;
import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.ToolingCapacity;
import com.lenovo.bi.dto.ToolingCapacityDetail;

@Repository
@Transactional("dw")
@SuppressWarnings("unchecked")
public class ToolingCapacityDaoImpl extends HibernateBaseDaoImplDw<Object> implements ToolingCapacityDao {
	 @Override
	public List<ToolingCapacity> getToolingCapacityInWeek(Date targetDate, Date versionDate) {
		// ENGINE
		StringBuffer sql = new StringBuffer("select w.PMSWaveIDAlternateKey as pmsWaveId, cover, SUM(Capacity) as capacity, SUM(BOH) as boh ")
			.append("from FactWeeklySummaryofToolingCapacity f, DimToolingPlan p, DimNPIWave w, DimTime t1, DimTime t2 ")
			.append("where f.ToolingPlanKey = p.ToolingPlanKey ")
			.append("and p.NPIWaveKey = w.NPIWaveKey ")
			.append("and f.TargetDateKey = t1.TimeKey ")
			.append("and f.VersionDateKey = t2.TimeKey ")
			.append("and DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0 ")
			.append("and DATEDIFF(day, t2.FullDateAlternateKey, ?) = 0 ")
			.append("group by w.PMSWaveIDAlternateKey, Cover ");
		
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(ToolingCapacity.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, versionDate);
		return query.list();
	 }

	@Override
	public List<ToolingCapacityDetail> getDetailToolingCapacityByTargetDate(
			int pmsWaveId, Date targetDate, Date versionDate) {
		StringBuffer sql = new StringBuffer("select w.PMSWaveIDAlternateKey as pmsWaveId, p.SupplierName as supply,  t3.FullDateAlternateKey as signOff, p.Technology as tech, p.cover,  f.capacity, f.boh ")
		.append("from FactWeeklySummaryofToolingCapacity f, DimToolingPlan p, DimNPIWave w, DimTime t1, DimTime t2, DimTime t3 ")
		.append("where f.ToolingPlanKey = p.ToolingPlanKey ")
		.append("and p.NPIWaveKey = w.NPIWaveKey ")
		.append("and f.TargetDateKey = t1.TimeKey ")
		.append("and f.VersionDateKey = t2.TimeKey ")
		.append("and p.MPSignOffDateKey = t3.TimeKey ")
		.append("and DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0 ")
		//use the latest version instead of the current version
		.append("and DATEDIFF(day, t2.FullDateAlternateKey, ?) = 0 ")
		//.append("and f.VersionDateKey = (select max(tc.VersionDateKey) from FactWeeklySummaryofToolingCapacity tc where f.ToolingPlanKey = tc.ToolingPlanKey and f.TargetDateKey = tc.TargetDateKey)")
		.append("and w.PMSWaveIDAlternateKey = ? and w.IsCurrent=1 ");
	
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(ToolingCapacityDetail.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, versionDate);
		query.setParameter(2, pmsWaveId);
		//query.setParameter(1, pmsWaveId);
		return query.list();
	}

	@Override
	public List<ToolingCapacity> getToolingCapacityByWave(int pmsWaveId,
			Date targetDate, Date versionDate) {
		StringBuffer sql = new StringBuffer("select w.PMSWaveIDAlternateKey as pmsWaveId, cover, SUM(Capacity) as capacity, SUM(BOH) as boh ")
		.append("from FactWeeklySummaryofToolingCapacity f, DimToolingPlan p, DimNPIWave w, DimTime t1, DimTime t2 ")
		.append("where f.ToolingPlanKey = p.ToolingPlanKey ")
		.append("and p.NPIWaveKey = w.NPIWaveKey ")
		.append("and f.TargetDateKey = t1.TimeKey ")
		.append("and f.VersionDateKey = t2.TimeKey ")
		.append("and DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0 ")
		//use the latest version instead of the current version
		.append("and DATEDIFF(day, t2.FullDateAlternateKey, ?) = 0 ")
		//.append("and f.VersionDateKey = (select max(tc.VersionDateKey) from FactWeeklySummaryofToolingCapacity tc where f.ToolingPlanKey = tc.ToolingPlanKey and f.TargetDateKey = tc.TargetDateKey)")
		.append("and w.PMSWaveIDAlternateKey = ? ")
		.append("group by Cover,w.PMSWaveIDAlternateKey ");		
	
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(ToolingCapacity.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, versionDate);
		query.setParameter(2, pmsWaveId);
		//query.setParameter(1, pmsWaveId);
		return query.list();
	}
	
	@Override
	public List<ToolingCapacity> getToolingCapacityByWave(int pmsWaveId, Date versionDate) {
		StringBuffer sql = new StringBuffer("select w.PMSWaveIDAlternateKey as pmsWaveId, t1.FullDateAlternateKey as targetDate, cover, SUM(Capacity) as capacity, SUM(BOH) as boh ")
		.append("from FactWeeklySummaryofToolingCapacity f, DimToolingPlan p, DimNPIWave w, DimTime t1, DimTime t2 ")
		.append("where f.ToolingPlanKey = p.ToolingPlanKey ")
		.append("and p.NPIWaveKey = w.NPIWaveKey ")
		.append("and f.TargetDateKey = t1.TimeKey ")
		.append("and f.VersionDateKey = t2.TimeKey ")
		.append("and DATEDIFF(day, t2.FullDateAlternateKey, ?) = 0 ")
		.append("and w.PMSWaveIDAlternateKey = ? ")
		.append("group by Cover,w.PMSWaveIDAlternateKey, t1.FullDateAlternateKey ");		
	
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(ToolingCapacity.class));
		query.setParameter(0, versionDate);
		query.setParameter(1, pmsWaveId);
		return query.list();
	}

	@Override
	public List<ToolingCapacityDetail> getToolingItems(String pmsWaveId,
			String versionDate, String startDate, String endDate) {
		StringBuffer sql = new StringBuffer();
		sql.append(" select                                                         ")
		.append(" p.cover ,                                                         ")
		.append(" p.Technology as tech,                                              ")
		.append(" ToolingLineName as tooling,                                       ")
		.append(" p.SupplierName as supply,                                         ")
		.append(" t1.FullDateAlternateKey as targetDate,                            ")
		.append(" f.capacity                                                        ")
		.append(" from FactWeeklySummaryofToolingCapacity f,                        ")
		.append(" DimToolingPlan p,                                                 ")
		.append(" DimNPIWave w,                                                     ")
		.append(" DimTime t1,                                                       ")
		.append(" DimTime t2,                                                       ")
		.append(" DimTime t3                                                        ")
		.append(" where f.ToolingPlanKey = p.ToolingPlanKey                         ")
		.append(" and p.NPIWaveKey = w.NPIWaveKey                                   ")
		.append(" and f.TargetDateKey = t1.TimeKey                                  ")
		.append(" and f.VersionDateKey = t2.TimeKey                                 ")
		.append(" and p.MPSignOffDateKey = t3.TimeKey                               ")
		.append(" and w.IsCurrent=1                                                 ")
		.append(" and t2.FullDateAlternateKey=?                                     ")
		.append(" and t1.FullDateAlternateKey>=?                                     ")
		.append(" and t1.FullDateAlternateKey<=?                                     ")
		.append(" and w.PMSWaveIDAlternateKey = ?                                   ");
		
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(ToolingCapacityDetail.class));
//		query.setParameter(0, "2014-11-03");//versionDate
//		query.setParameter(1, "2014-11-10");//startDate
//		query.setParameter(2, "2015-01-12");//endDate
//		query.setParameter(3, 210);//waveId
		
		query.setParameter(0, versionDate);//versionDate
		query.setParameter(1, startDate);//startDate
		query.setParameter(2, endDate);//endDate
		query.setParameter(3, pmsWaveId);//waveId
		return query.list();
	}
}
