package com.lenovo.bi.service.npi;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.RampCommitDTO;

/**
 * ramp commit 
 * 
 * @author henry_lian
 *
 */
public interface RampCommitService {

	public List<RampCommitDTO> getRampCommitByWaveId(int waveId);
	
	public int getRampCommitQty(int waveId,Date startDate);
	
	public List<RampCommitDTO> getRampCommitByWaveIdAndTargetDate(String waveId,String startDate,String endDate);
}
