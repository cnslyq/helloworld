package com.lenovo.bi.service.sc.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.sc.MWDDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.MWDChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.PurchaseTypeEnum;
import com.lenovo.bi.form.sc.mwd.SearchMWDForm;
import com.lenovo.bi.service.common.CommonService;
import com.lenovo.bi.service.sc.MWDService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSet;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.sc.mwd.MWDDetailView;

@Service
@Transactional("dw")
public class MWDServiceImpl implements MWDService{
	 
	@Inject
	CommonService commonService;
	
	@Inject
	MWDDao mwdDao;

	@Override
	public MSColumnChartView getOverviewChart(SearchMWDForm form)
			throws ParseException {
		MSColumnChartView columnChartView = new MSColumnChartView();
		setOverviewChartInfomation(columnChartView);
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
				|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
			String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
				if (form.getEndDate()!=null && yearMonth.compareTo(form.getEndDate()) > 0) 
					break;
				Category category = new Category();
				category.setName(yearMonth);
				categoryList.add(category);
			}	
			
		}
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		//dataset list and lineset list
		List<DataSet> dataSetList = new ArrayList<DataSet>();
		//List<LineSet> lineSetList = new ArrayList<LineSet>();
		
		//dataset
		DataSet mwdDataSet = new DataSet();
		
		/*LineSet makeRateLineSet = new LineSet();
		makeRateLineSet.setSeriesName("Make Rate");
		makeRateLineSet.setColor("009966");
		makeRateLineSet.setShowValues("0");
		makeRateLineSet.setLineThickness("2");
		
		LineSet targetLineSet = new LineSet();
		targetLineSet.setSeriesName("Target");
		targetLineSet.setColor("FF0099");
		targetLineSet.setShowValues("0");
		targetLineSet.setLineThickness("2");*/
		
		//dataset:seriesName
		List<DataSetParent> mwdDataSetList = new ArrayList<DataSetParent>();
		
		DataSetColumn assignDataSetColumn = new DataSetColumn();
		assignDataSetColumn.setSeriesName(PurchaseTypeEnum.ASSIGN.getTypeName());
		assignDataSetColumn.setColor("F73809");//00CC00;CCFF99;66FF33;999999
		
		List<ColumnData> asssignCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn dbDataSetColumn = new DataSetColumn();
		dbDataSetColumn.setSeriesName(PurchaseTypeEnum.DB.getTypeName());
		dbDataSetColumn.setColor("F7C709");//FF0000;CCFF99;FFCC00;CCCCCC
		List<ColumnData> dbCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn bsDataSetColumn = new DataSetColumn();
		bsDataSetColumn.setSeriesName(PurchaseTypeEnum.B_S.getTypeName());
		bsDataSetColumn.setColor("B3B34D");//FFCC00;CCFFCC;66FFCC;AAAAAA
		List<ColumnData> bsCloumnDataList = new ArrayList<ColumnData>();
		
		/*List<ColumnData> makeRateColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();*/
		
		LinkedHashMap<Object, List<MWDChartData>> mwdOverviewMap = null;
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			mwdOverviewMap = fetchMWDOverViewChartData(form);//fetchOtsOverViewChartData(form);
		}
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			mwdOverviewMap = fetchMWDCrossMonthOverViewChartData(form);//fetchOtsCrossMonthOverviewChartData(form);
		}
		else{
			mwdOverviewMap = fetchMWDDashboardOverViewChartData(form);
		}
		int i=0;
		for(Entry<Object, List<MWDChartData>> entry : mwdOverviewMap.entrySet()) {
			String name = ((KeyNameObject)entry.getKey()).getObjName();
			int key = -1;
			if(((KeyNameObject)entry.getKey()).getObjKey() != null)
				key = ((KeyNameObject)entry.getKey()).getObjKey();
			List<MWDChartData> chartDataList = entry.getValue();
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				Category category = new Category();
				category.setName(name);
				categoryList.add(category);
			}
			
			ColumnData assign = new ColumnData();
			
			ColumnData DB = new ColumnData();
			
			ColumnData BS = new ColumnData();
			
			//Map<String,Integer> dataMap = new HashMap<String,Integer>();
			
			StringBuffer valueBuffer = new StringBuffer("[{");
			Category category = (Category)(categoryList.get(i));
			for(MWDChartData mwdOverViewChartData : chartDataList) {
				if(mwdOverViewChartData.getPurchaseType().equals(PurchaseTypeEnum.ASSIGN.getTypeName())) {
					setMWDOverviewColumnLink(assign,name,key);
					assign.setValue(mwdOverViewChartData.getPrice());
					assign.setTooltext("ASSIGN,"+category.getName()+","+mwdOverViewChartData.getPrice());
					valueBuffer.append("assign:");
				}
				else if(mwdOverViewChartData.getPurchaseType().equals(PurchaseTypeEnum.DB.getTypeName())) {
					setMWDOverviewColumnLink(DB,name,key);
					DB.setValue(mwdOverViewChartData.getPrice());
					DB.setTooltext("DB,"+category.getName()+","+mwdOverViewChartData.getPrice());
					valueBuffer.append("DB:");
					//dataMap.put(OTSStatusEnum.FAIL.getTypeName(), mwdOverViewChartData.getOrderNum());
				}
				else if(mwdOverViewChartData.getPurchaseType().equals(PurchaseTypeEnum.B_S.getTypeName())) {
					setMWDOverviewColumnLink(BS,name,key);
					BS.setValue(mwdOverViewChartData.getPrice());
					BS.setTooltext("B&S,"+category.getName()+","+mwdOverViewChartData.getPrice());
					valueBuffer.append("BS:");
					//dataMap.put(OTSStatusEnum.ToBeMake.getTypeName(), mwdOverViewChartData.getOrderNum());
				}
				valueBuffer.append(mwdOverViewChartData.getPrice()).append(",");
			}
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				valueBuffer.append("subDimensionName:");
				valueBuffer.append("'" + name + "'").append(",");
			}
			
			valueBuffer.append(" color:123 ");
			
			valueBuffer.append("}").append("]");
			//System.out.println("----------KPI:" + valueBuffer.toString());
			
			category.setValues(valueBuffer.toString());
			asssignCloumnDataList.add(assign);
			dbCloumnDataList.add(DB);
			bsCloumnDataList.add(BS);
			//Target
			/*ColumnData target = new ColumnData();
			float targetValue = 0;
			Float thresholdValue = masterDataService.getThresholdByName(Threshold.SC_OTS_OTS_TARGET.name());
			if(thresholdValue != null)
				targetValue = thresholdValue.floatValue();
			target.setValue(targetValue);
			targetCloumnDataList.add(target);*/
			i++;
		}
		
		bsDataSetColumn.setDataList(bsCloumnDataList);
		mwdDataSetList.add(bsDataSetColumn);
		
		dbDataSetColumn.setDataList(dbCloumnDataList);
		mwdDataSetList.add(dbDataSetColumn);
		
		
		assignDataSetColumn.setDataList(asssignCloumnDataList);
		mwdDataSetList.add(assignDataSetColumn);
		
		mwdDataSet.setDataSetList(mwdDataSetList);
		
		/*makeRateLineSet.setDataList(makeRateColumnDataList);
		targetLineSet.setDataList(targetCloumnDataList);*/
		
		dataSetList.add(mwdDataSet);
		/*lineSetList.add(makeRateLineSet);
		lineSetList.add(targetLineSet);*/
		
		columnChartView.setDataSetList(dataSetList);
		//columnChartView.setLineSetList(lineSetList);
		
		return columnChartView;
	}
	
	private LinkedHashMap<Object, List<MWDChartData>> fetchMWDCrossMonthOverViewChartData (	SearchMWDForm form) throws ParseException{
		LinkedHashMap<Object,List<MWDChartData>> mwdOverviewMap = new LinkedHashMap<Object,List<MWDChartData>>();
		String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
		List<MWDChartData>chartData=mwdDao.fetchMWDCrossMonthOverviewChartData(form);
		//String yearMonth = "";
		for(int i=0; i<12; i++) {
			String date = CalendarUtil.getYearMonthByMonths(startDate, i);
			if (date.compareTo(form.getEndDate()) > 0) 
				break;
			KeyNameObject keyNameObject = new KeyNameObject();
			keyNameObject.setObjName(date);
			int year = Integer.parseInt(date.substring(0,4));
			int month = Integer.parseInt(date.substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			//yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
			mwdOverviewMap.put(keyNameObject,getListByDimension(chartData,year+","+month));
		}	
		return mwdOverviewMap;
	}

	private void setOverviewChartInfomation(MSColumnChartView mSColumnChartView) {
		mSColumnChartView.getChartInfo().setCaption("");
		mSColumnChartView.getChartInfo().setNumdivlines("9");
		mSColumnChartView.getChartInfo().setyAxisMinValue("0");
		mSColumnChartView.getChartInfo().setyAxisMaxValue("160");
	/*	mSColumnChartView.getChartInfo().setsYAxisMinValue("0");
		mSColumnChartView.getChartInfo().setsYAxisMaxValue("100");*/
		mSColumnChartView.getChartInfo().setFormatNumberScale("0");
		mSColumnChartView.getChartInfo().setLegendIconScale("1");
		mSColumnChartView.getChartInfo().setShowBorder("1");
		mSColumnChartView.getChartInfo().setCanvasBorderThickness("1");
		mSColumnChartView.getChartInfo().setShowZeroPlaneValue("1");
		mSColumnChartView.getChartInfo().setCanvasBorderAlpha("60");
		mSColumnChartView.getChartInfo().setPlotSpacePercent("70");
		mSColumnChartView.getChartInfo().setBgalpha("0,0");
		mSColumnChartView.getChartInfo().setLegendPosition("");
		mSColumnChartView.getChartInfo().setShowBorder("0");
		mSColumnChartView.getChartInfo().setShowPlotBorder("0");
		mSColumnChartView.getChartInfo().setShowValues("0");
		mSColumnChartView.getChartInfo().setUseroundedges("0");
		mSColumnChartView.getChartInfo().setShowsum("0");
	}
	
	public LinkedHashMap<Object,List<MWDChartData>> fetchMWDOverViewChartData(SearchMWDForm form) throws ParseException {
		LinkedHashMap<Object,List<MWDChartData>> mwdOverviewMap = new LinkedHashMap<Object,List<MWDChartData>>();
		List<MWDChartData>chartData=mwdDao.fetchMWDOverViewChartData(form);
		//String yearMonth = "";
		for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
			String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
			if (date.compareTo(form.getEndDate()) > 0) 
				break;
			KeyNameObject keyNameObject = new KeyNameObject();
			keyNameObject.setObjName(date);
			int year = Integer.parseInt(date.substring(0,4));
			int month = Integer.parseInt(date.substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			//yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
			mwdOverviewMap.put(keyNameObject,getListByDimension(chartData,year+","+month));//从list中根据年月取子list
		}
		return mwdOverviewMap;
	}
	
	public LinkedHashMap<Object,List<MWDChartData>> fetchMWDDashboardOverViewChartData(SearchMWDForm form) throws ParseException {
		LinkedHashMap<Object,List<MWDChartData>> MWDDashboardMap = new LinkedHashMap<Object,List<MWDChartData>>();
//		List<MWDChartData> chartData = mwdDao.fetchMWDDashboardChartData(form);
		//String yearMonth = "";
		
		List<KeyNameObject> dimensionList = mwdDao.fetchDimensions(form);
		for(KeyNameObject keyNameObject : dimensionList) {
			form.setSubDimensionKey(keyNameObject.getObjKey());
			form.setSubDimension(keyNameObject.getObjName());
			MWDDashboardMap.put(keyNameObject, mwdDao.fetchMWDDashboardChartData(form));
		}
		
		
//		for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
//			String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
//			if (date.compareTo(form.getEndDate()) > 0) 
//				break;
//			KeyNameObject keyNameObject = new KeyNameObject();
//			keyNameObject.setObjName(date);
//			int year = Integer.parseInt(date.substring(0,4));
//			int month = Integer.parseInt(date.substring(5,7));
//			form.setYear(year);
//			form.setMonth(month);
//			yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
////			MWDDashboardMap.put(keyNameObject,getListByDimension(chartData,year+","+month));
//		}
		return MWDDashboardMap;
	}
	
	
	private List<MWDChartData> getListByDimension(List<MWDChartData>chartData,String dimension){
		List<MWDChartData>finalList=new ArrayList<MWDChartData>();
		int year;
		int month;
		if(dimension.indexOf(",")!=-1){
			year=Integer.parseInt(dimension.substring(0, dimension.indexOf(",")));
			month=Integer.parseInt(dimension.substring(dimension.indexOf(",")+1));
			for(MWDChartData data:chartData){
				if(year==data.getYear()&&month==data.getMonth()){
					finalList.add(data);
				}
			}
		}
		return finalList;
	}
	
	public void setMWDOverviewColumnLink(ColumnData cloumnData,String name, int key) {
		cloumnData.setLink("j-refreshRemark-" + name + "," + key);
	}

	@Override
	public ColumnChartView getRemarkChart(SearchMWDForm form)
			throws ParseException {
		ColumnChartView columnChartView = setMWDRemarkChartInfomation();
		
		//dataset:seriesName
		List<DataSetParent> mwdDimensionDataSetList = new ArrayList<DataSetParent>();
		
		DataSetColumn assignDataSetColumn = new DataSetColumn();
		assignDataSetColumn.setSeriesName(PurchaseTypeEnum.ASSIGN.getTypeName());
		assignDataSetColumn.setColor("F73809");
		
		List<ColumnData> asssignCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn dbDataSetColumn = new DataSetColumn();
		dbDataSetColumn.setSeriesName(PurchaseTypeEnum.DB.getTypeName());
		dbDataSetColumn.setColor("F7C709");
		List<ColumnData> dbCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn bsDataSetColumn = new DataSetColumn();
		bsDataSetColumn.setSeriesName(PurchaseTypeEnum.B_S.getTypeName());
		bsDataSetColumn.setColor("B3B34D");
		List<ColumnData> bsCloumnDataList = new ArrayList<ColumnData>();
		
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		List<MWDChartData> list  = fetchMWDRemarkChartData(form);
		
		if("w2w".equals(form.getDimension())) {
			List<MWDChartData> removeList = new ArrayList<MWDChartData>();
			if(haveLastWeekData(list)){
				//删除3
				for(MWDChartData data:list){
					if(data.getDimensionKey()==3){
						//list.remove(data);
						removeList.add(data);
					}
				}
			}else{
				for(MWDChartData data:list){
					if(data.getDimensionKey()==2){
						//list.remove(data);
						removeList.add(data);
					}
				}
			}
			list.removeAll(removeList);
		}
		Map<String,List<MWDChartData>>dataMap=convertToMap(list);
		
		List<Entry<String,List<MWDChartData>>>sortList=new ArrayList<Entry<String,List<MWDChartData>>>(dataMap.entrySet());
		
		if(!"w2w".equals(form.getDimension())){
			
			Collections.sort(sortList, new Comparator<Entry<String,List<MWDChartData>>>() {

				@Override
				public int compare(Entry<String, List<MWDChartData>> o1,
						Entry<String, List<MWDChartData>> o2) {
					float sum1=0;
					float sum2=0;
					List<MWDChartData>data1=o1.getValue();
					List<MWDChartData>data2=o2.getValue();
					for(MWDChartData d1:data1){
						if(d1.getPrice()!=null){
							sum1+=d1.getPrice();
						}
					}
					for(MWDChartData d2:data2){
						if(d2.getPrice()!=null){
							sum2+=d2.getPrice();
						}
					}
					return sum1-sum2==0?0:sum1-sum2>0?-1:1;
				}
				
			});
		}else{
			
			Collections.sort(sortList, new Comparator<Entry<String,List<MWDChartData>>>() {

				@Override
				public int compare(Entry<String, List<MWDChartData>> o1,
						Entry<String, List<MWDChartData>> o2) {
					return o2.getKey().charAt(0)-o1.getKey().charAt(0);
				}
				
			});
		}
		
		for(int i=0; i<sortList.size(); i++) {
			if(i == 15) break;
			List<MWDChartData> mwdRemarkChartData = sortList.get(i).getValue();
			String name = mwdRemarkChartData.get(0).getDimensionName();
			int value = mwdRemarkChartData.get(0).getDimensionKey();
			
			Category category = new Category();
			category.setName(name);
			category.setValue(value);
			categoryList.add(category);
			
			String dimensionInfo = form.getDimension()+ "," + name;
			
			ColumnData assign = new ColumnData();
			//setRemarkColumnLink(dimensionInfo,fail,form);
			
			ColumnData DB = new ColumnData();
		//	setRemarkColumnLink(dimensionInfo,toBeFail,form);
			
			ColumnData BS = new ColumnData();
			//	setRemarkColumnLink(dimensionInfo,toBeFail,form);
			
			//setRemarkColumnLink(dimensionInfo+","+ PurchaseTypeEnum.ASSIGN.getTypeName(),assign,form);
			
			for(MWDChartData data:mwdRemarkChartData){
				if(PurchaseTypeEnum.ASSIGN.getTypeName().equals(data.getPurchaseType())){
					assign.setValue(data.getPrice());
					assign.setTooltext(PurchaseTypeEnum.ASSIGN.getTypeName()+","+name+","+data.getPrice());
					assign.setLink( "j-showRemarkMwdDetail-"+"ASSIGN,"+dimensionInfo );
				}
				if(PurchaseTypeEnum.DB.getTypeName().equals(data.getPurchaseType())){
					DB.setValue(data.getPrice());
					DB.setTooltext(PurchaseTypeEnum.DB.getTypeName()+","+name+","+data.getPrice());
					DB.setLink( "j-showRemarkMwdDetail-"+"DB,"+dimensionInfo );
				}
				if(PurchaseTypeEnum.B_S.getTypeName().equals(data.getPurchaseType())){
					BS.setValue(data.getPrice());
					BS.setTooltext(PurchaseTypeEnum.B_S.getTypeName()+","+name+","+data.getPrice());
					BS.setLink( "j-showRemarkMwdDetail-"+"B&S,"+dimensionInfo );
				}
			}
			
			//fail.setTooltext(OTSStatusEnum.FAIL.getTypeName() +", " + name + ", "+ mwdRemarkChartData.getFailRate() + "%");
		
			//setRemarkColumnLink(dimensionInfo+","+ OTSStatusEnum.ToBeFail.getTypeName(),DB,form);
			
		//	toBeFail.setTooltext(OTSStatusEnum.ToBeFail.getTypeName() +", " + name + ", "+ mwdRemarkChartData.getToBeFailRate() + "%");
			
			if(assign.getValue()!=null&&assign.getValue().intValue() != 0){ 
				asssignCloumnDataList.add(assign);
			}else{
				asssignCloumnDataList.add(null);
			}
			
			if(DB.getValue()!=null&&DB.getValue().intValue() != 0){
				dbCloumnDataList.add(DB);
			}else{
				dbCloumnDataList.add(null);
			}
			
			if(BS.getValue()!=null&&BS.getValue().intValue() != 0){
				bsCloumnDataList.add(BS);
			}else{
				bsCloumnDataList.add(null);
			}
			
		}
		Categories categories = new Categories();
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		bsDataSetColumn.setDataList(bsCloumnDataList);
		mwdDimensionDataSetList.add(bsDataSetColumn);
		
		dbDataSetColumn.setDataList(dbCloumnDataList);
		mwdDimensionDataSetList.add(dbDataSetColumn);
		
		assignDataSetColumn.setDataList(asssignCloumnDataList);
		mwdDimensionDataSetList.add(assignDataSetColumn);
		
		columnChartView.setDataSetList(mwdDimensionDataSetList);
		
		return columnChartView;
	
	}
		
	private ColumnChartView setMWDRemarkChartInfomation() {
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumdivlines("10");
		columnChartView.getChartInfo().setShowValues("1");
		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setShowBorder("0");
		
		/*columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		columnChartView.getChartInfo().setFormatNumber("%");*/
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		//columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");
		columnChartView.getChartInfo().setUseroundedges("0");
		columnChartView.getChartInfo().setShowValues("0");
		
		return columnChartView;
	}

	public List<MWDChartData> fetchMWDRemarkChartData(SearchMWDForm form) throws ParseException {
		String yearMonth = form.getStartDate();
		String yearStr = yearMonth.substring(0,4);
		String monthStr = yearMonth.substring(5,7);
		int year = Integer.parseInt(yearStr);
		int month = Integer.parseInt(monthStr);
		form.setYear(year);
		form.setMonth(month);
		List<MWDChartData> mwdRemarkChartDataList = mwdDao.fetchDimensionRemarkDataList(form);
		//mwdRemarkChartDataList=sortList(mwdRemarkChartDataList);
		return mwdRemarkChartDataList;
	}
	
	//bs db assign
	private Map<String,List<MWDChartData>> convertToMap(List<MWDChartData> mwdRemarkChartDataList){
		Map<String,List<MWDChartData>> map=new HashMap<String,List<MWDChartData>>();
		for(MWDChartData data:mwdRemarkChartDataList){
			if(map.get(data.getDimensionName())!=null){
				map.get(data.getDimensionName()).add(data);
			}else{
				List<MWDChartData>list=new ArrayList<MWDChartData>();
				list.add(data);
				map.put(data.getDimensionName(), list);
			}
		}
		return map;
	}

	@Override
	public Map<String, Object> getMWDDetail(SearchMWDForm form)
			throws ParseException {
		List<MWDDetailView> grid = new ArrayList<MWDDetailView>();
		long totalCount = 0;
		
		totalCount = mwdDao.getMWDDetailCount(form);
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			grid = mwdDao.getMWDDetail(form);
		}else{
			if("w2w".equals(form.getSubDimension()) && "Last_Week".equals(form.getSubKey())){//如果查询不到本月上一版本数据则查询上本版本上一月数据
				form.setStartDate(this.getLastMonth(form.getStartDate().substring(0,7)));
				form.setSubKey("This_Week");
				totalCount = mwdDao.getMWDDetailCount(form);
				if(totalCount > 0){
					if(form.getEndRow() > totalCount){
						form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
					}
					grid = mwdDao.getMWDDetail(form);
				}
			}
		}
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	private String getLastMonth(String yearMonth){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
	    try {  
	        Date date = sdf.parse(yearMonth+"-01");  
	        Calendar c = Calendar.getInstance();  
	        c.setTime(date);  
	        Calendar lastDate = (Calendar) c.clone();  
	        lastDate.add(Calendar.MONTH, -1);  
	        return sdf.format(lastDate.getTime()).substring(0, 7);  
	    } catch (ParseException e) {  
	       return null;
	    }  
	}
	private boolean haveLastWeekData(List<MWDChartData> list){
		for(MWDChartData data:list){
			if(data.getDimensionKey()==2){
				if(data.getPrice()!=null){
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public Date getMRPRunTime() {
		return mwdDao.getMRPRunTime();
	}
	
}
