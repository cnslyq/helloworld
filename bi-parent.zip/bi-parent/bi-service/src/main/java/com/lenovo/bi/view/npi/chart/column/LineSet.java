package com.lenovo.bi.view.npi.chart.column;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;

public class LineSet extends DataSetParent {

	private String color;
	private String parentYAxis;
	private List<ColumnData> dataList;

	private String showValues;
	private String lineThickness;


	public String getParentYAxis() {
		return parentYAxis;
	}

	public void setParentYAxis(String parentYAxis) {
		this.parentYAxis = parentYAxis;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public List<ColumnData> getDataList() {
		return dataList;
	}

	@JsonProperty("data")
	public void setDataList(List<ColumnData> dataList) {
		this.dataList = dataList;
	}

	public String getShowValues() {
		return showValues;
	}

	public void setShowValues(String showValues) {
		this.showValues = showValues;
	}

	public String getLineThickness() {
		return lineThickness;
	}

	public void setLineThickness(String lineThickness) {
		this.lineThickness = lineThickness;
	}

}
