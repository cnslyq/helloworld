package com.lenovo.bi.view.npi.ttv.outlook.tracking;

public class ForecastCause {
	private String causesCategory;//Demand
	private String causes;//Forecast Offside,Forecast Upside
	private long prevForecastQuantity;//if(Offside) then 0; else if(Upside) then Quantity of Previous Version Forecast
	private long curForecastQuantity;//Quantity of Current Version Forecast
	private long gap;//Current Forecast Quantity - Previous Forecast Quantity
	private String unit;//"pcs"

	public String getCausesCategory() {
		return causesCategory;
	}

	public void setCausesCategory(String causesCategory) {
		this.causesCategory = causesCategory;
	}

	public String getCauses() {
		return causes;
	}

	public void setCauses(String causes) {
		this.causes = causes;
	}

	public long getPrevForecastQuantity() {
		return prevForecastQuantity;
	}

	public void setPrevForecastQuantity(long prevForecastQuantity) {
		this.prevForecastQuantity = prevForecastQuantity;
	}

	public long getCurForecastQuantity() {
		return curForecastQuantity;
	}

	public void setCurForecastQuantity(long curForecastQuantity) {
		this.curForecastQuantity = curForecastQuantity;
	}

	public long getGap() {
		return gap;
	}

	public void setGap(long gap) {
		this.gap = gap;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}


}
