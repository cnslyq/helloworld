package com.lenovo.bi.dao.sc.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.FloatType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.FaComponentDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FaOverViewChartData;
import com.lenovo.bi.dto.sc.GeoFA;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.enumobj.FaTypeEnum;
import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.sc.fa.FADetailView;

@SuppressWarnings("rawtypes")
@Repository
public class FaComponentDaoImpl extends HibernateBaseDaoImplDw implements FaComponentDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> fetchFaComponentOverViewChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		if(FaTypeEnum.Mps.getTypeName().equalsIgnoreCase(form.getComponentTypes())) {
			sBuffer.append("select isnull(sum([60DaysForecastQty]*1.0),0) as FAValue,")
				   .append(" isnull(sum(OrderQty*1.0),0) as OrderQty,")
				   .append(" isnull(round(sum(case when isNull(OrderQty*1.0,0) > isNull([60DaysForecastQty]*1.0,0) then isNull([60DaysForecastQty]*1.0,0) else isNull(OrderQty*1.0,0) end)*1.0/nullIf(sum(case when isNull(OrderQty*1.0,0) < isNull([60DaysForecastQty]*1.0,0) then isNull([60DaysForecastQty]*1.0,0) else isNull(OrderQty*1.0,0) end),0),4),0) ")
				   .append(" as FARate,")
				   .append("'Mps' as typeName");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equalsIgnoreCase(form.getComponentTypes())) {
			sBuffer.append("select isnull(sum([60DaysGrossForecastQty]*1.0),0) as FAValue,")
				   .append(" isnull(sum(OrderQty*1.0),0) as OrderQty,")
			       .append(" isnull(round(sum(case when isNull(OrderQty*1.0,0) > isNull([60DaysGrossForecastQty]*1.0,0) then isNull([60DaysGrossForecastQty]*1.0,0) else isNull(OrderQty*1.0,0) end)*1.0/nullIf(sum(case when isNull(OrderQty*1.0,0) < isNull([60DaysGrossForecastQty]*1.0,0) then isNull([60DaysGrossForecastQty]*1.0,0) else isNull(OrderQty*1.0,0) end),0),2),0) ")
			       .append(" as FARate,")
			       .append("'grossForecast' as typeName");
			       
		}
			sBuffer.append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,GlobalCVKey) fa")
				   .append(" where Year = ").append(form.getYear())
				   .append(" and Month = ").append(form.getMonth());
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("typeName", StringType.INSTANCE)
				.addScalar("FAValue", IntegerType.INSTANCE)
				.addScalar("FARate", FloatType.INSTANCE)
				.addScalar("OrderQty", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchFaComponentRemarkChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append("select top 15 case when sum([60DaysForecastQty]) is null then 0")
				   .append(" else sum([60DaysForecastQty]) end as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append("select top 15 case when sum([60DaysGrossForecastQty]) is null then 0")
				   .append(" else sum([60DaysGrossForecastQty]) end as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" 1 as subDimensionKey,")
				   .append(" fa.GeographyName as subDimensionName")
				   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,GlobalCVKey) fa");
				   //.append(" left join DimGeography geography on fa.GeographyName = geography.GeographyName");
	
			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth())
				   .append(" group by fa.GeographyName having fa.GeographyName <> ''");
		}
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append("case when fa.ODMKey is null then 0 else fa.ODMKey end as subDimensionKey,")
				   .append(" odm.ODMEnglishName as subDimensionName")
				   
				   .append(" from (select YEAR, MONTH,'others' as GeographyName,-1 as productKey,OdmKey, m.GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') group by YEAR,MONTH,OdmKey,m.GlobalCVKey")
				   .append(" Union all ")
				   .append(" select YEAR, MONTH,GeographyName,productKey,OdmKey,m.GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,m.GlobalCVKey) fa")
				   
//				   .append(" from ( select YEAR, MONTH,GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA)  group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,m.GlobalCVKey) fa")
				   
				   .append(" left join DimODM odm on fa.ODMKey=odm.ODMKey");
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
			sBuffer.append(" group by fa.ODMKey,odm.ODMEnglishName having odm.ODMEnglishName <> ''");
		}
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" case when fa.productKey is null then 0 else fa.productKey end as subDimensionKey,")
				   .append(" pro.productEnglishName as subDimensionName")
				   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,GlobalCVKey) fa")
				   .append(" left join dimproduct pro on fa.productkey = pro.productkey");

			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth());
			sBuffer.append(" group by fa.productkey,pro.productEnglishName having pro.productEnglishName <> ''");
		}
		else if("Component".equals(form.getDimension())) {
			sBuffer.append(" isnull(cv.CommodityTypeKey,0) as subDimensionKey,")
				   .append(" cv.CommodityType as subDimensionName")
				   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,GlobalCVKey) fa")
				   .append(" left join (")
				   .append(" select cv.GlobalCVKey, dct.CommodityType, dct.CommodityTypeKey")
				   .append(" from DimCommodityType dct join dimglobalcv cv on cv.CommodityTypeKey = dct.CommodityTypeKey")
				   .append(")cv  on fa.GlobalCVKey = cv.GlobalCVKey");
			
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
			sBuffer.append(" group by cv.CommodityType,cv.CommodityTypeKey having cv.CommodityType <> ''");
		}
		sBuffer.append(" order by faRate desc");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("subDimensionName", StringType.INSTANCE)
				.addScalar("subDimensionValue", IntegerType.INSTANCE)
				.addScalar("subDimensionKey", IntegerType.INSTANCE)
				.addScalar("faRate", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		return query.list();
	}
	
	//TODO
	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchDimensions(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		//for Product dashboard overview chart
		if("Region".equals(form.getDashboardType())) {
		    sBuffer.append("select top 15 1 as objKey,fa.GeographyName as objName,'Region' as type")
			       .append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofcomponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,GlobalCVKey,OdmKey) fa ")
		    	   .append(" left join DimProduct product on fa.productKey = product.productKey ");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
		    sBuffer.append(" where fa.Year = ").append(form.getYear())
    			   .append(" and fa.Month = ").append(form.getMonth());
		    if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.GeographyName having fa.GeographyName <> ''");
		}
		//for Odm dashboard overview chart
		else if("Odm".equals(form.getDashboardType())) {
		    sBuffer.append("select top 15 fa.ODMKey as objKey,odm.ODMEnglishName as objName,'Odm' as type")
		    	   
		    	   .append(" from (select YEAR, MONTH,'others' as GeographyName,-1 as productKey,m.OdmKey, m.GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
		    	   .append(" left join DimProduct product on m.productKey = product.productKey ")
				   .append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
		    	   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
		    	   .append(" and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
		    	   if(!StringUtil.isEmpty(form.getFamilyIds())) {
						sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getGeoIds())) {
						sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getProductIds())) {
						sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
					}
			sBuffer.append( "group by YEAR,MONTH,m.OdmKey,m.GlobalCVKey")
				   .append(" Union all ")
				   .append(" select YEAR, MONTH,GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
				   .append(" left join DimProduct product on m.productKey = product.productKey ")
				   .append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
				   .append(" and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
				   if(!StringUtil.isEmpty(form.getFamilyIds())) {
						sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getGeoIds())) {
						sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getProductIds())) {
						sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
					}
			sBuffer.append(" group by YEAR,MONTH,dg.GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey) fa")
				   
//			       .append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofcomponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,GlobalCVKey,OdmKey) fa ")
			       
			       .append(" left join DimODM odm on fa.ODMKey = odm.ODMKey");
//		    	   .append(" left join DimProduct product on fa.productKey = product.productKey ");
//			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
			sBuffer.append(" where fa.Year = ").append(form.getYear())
    			   .append(" and fa.Month = ").append(form.getMonth());
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
//			if(!StringUtil.isEmpty(form.getFamilyIds())) {
//				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
//			}
//			if(!StringUtil.isEmpty(form.getGeoIds())) {
//				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
//			}
//			if(!StringUtil.isEmpty(form.getProductIds())) {
//				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
//			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.ODMKey,odm.ODMEnglishName having fa.ODMKey <> ''");
		}
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append("select fa.ProductKey as objKey,")
				   .append(" product.ProductEnglishName as objName,")
				   .append(" 'Product' as type")
				   .append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofcomponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,GlobalCVKey,OdmKey) fa")
				   .append(" left join DimProduct product on fa.ProductKey = product.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
			
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
			
	    	if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.ProductKey,product.ProductEnglishName having fa.ProductKey <> ''");
		}
		else if("Component".equals(form.getDashboardType())) {
			sBuffer.append("select c.CommodityTypeKey as objKey, c.CommodityType as objName, 'Component' as type")
				   .append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofcomponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,GlobalCVKey,OdmKey) fa")
				   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
				   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
				   .append(" left join DimProduct product on fa.productKey = product.productKey ");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" where fa.Year = ").append(form.getYear())
			   	   .append(" and fa.Month = ").append(form.getMonth());
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by c.CommodityTypeKey,c.CommodityType having c.CommodityType <> ''");
		}
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append(" order by sum(fa.[60DaysForecastQty]) desc");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append(" order by sum(fa.[60DaysGrossForecastQty]) desc");
		}
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		return query.list();
	}

	//TODO
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> fetchFaDashboardOverViewChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append("select isnull(sum(fa.[60DaysForecastQty]),0) as FAValue,")
				   .append(" isnull(sum(OrderQty),0) as OrderQty,")
				   .append("'Mps' as typeName,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),2),0) ")
				   .append(" as FARate");
		}
		else{
			sBuffer.append("select isnull(sum(fa.[60DaysGrossForecastQty]), 0) as FAValue,")
				   .append(" isnull(sum(OrderQty),0) as OrderQty,")
				   .append("'GrossForecast' as typeName,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),2),0) ")
				   .append(" as FARate");
		}
		 if("Region".equals(form.getDimension())) {
			sBuffer.append(" from (select YEAR,MONTH,GeographyName,productKey,globalcvkey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa");
			//sBuffer.append(" join factGEOListMapping region on fa.GeographyName = region.NormalizedSubgeo ");
			//sBuffer.append(" left join DimGeography geography on fa.GeographyName = geography.GeographyName");
			sBuffer.append(" left join DimProduct product on fa.productKey = product.productKey ");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
			sBuffer.append(" where fa.GeographyName = '").append(form.getSubDimension());
			sBuffer.append("' and fa.Year = ").append(form.getYear())
			   	   .append(" and fa.Month = ").append(form.getMonth());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.GeographyName having fa.GeographyName <> ''");
			
		}
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" from (select YEAR, MONTH,'others' as GeographyName,-1 as productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey, SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ");
			sBuffer.append(" left join DimProduct product on m.productKey = product.productKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
				   .append(" and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
				   if(!StringUtil.isEmpty(form.getFamilyIds())) {
						sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getGeoIds())) {
						sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getProductIds())) {
						sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
					}
			sBuffer.append(" group by YEAR,MONTH,m.OdmKey,m.GlobalCVKey")
				   .append(" Union all ")
				   .append(" select YEAR, MONTH,GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ");
			sBuffer.append(" left join DimProduct product on m.productKey = product.productKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
				   .append(" and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
				   if(!StringUtil.isEmpty(form.getFamilyIds())) {
						sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getGeoIds())) {
						sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
					}
					if(!StringUtil.isEmpty(form.getProductIds())) {
						sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
					}
			sBuffer.append(" group by YEAR,MONTH,dg.GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey) fa")
			
//			sBuffer.append(" from ( select YEAR, MONTH,GeographyName,productKey,OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,m.GlobalCVKey) fa")
			
				   .append(" left join DIMODM ODM on ODM.ODMkey = fa.ODMkey");
			sBuffer.append(" left join DimProduct product on fa.productKey = product.productKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
			sBuffer.append(" where fa.ODMKey = ").append(form.getSubDimensionKey());
			sBuffer.append(" and fa.Year = ").append(form.getYear())
			   	   .append(" and fa.Month = ").append(form.getMonth());
			
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.ODMKey,ODM.ODMEnglishName having fa.ODMKey <> ''");
		}
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" from (select YEAR,MONTH,GeographyName,productKey,globalcvkey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa");
			sBuffer.append(" left join (")
			       .append(" select product.ProductKey from DimProduct product")
			       .append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
			       .append(" where family.ProductFamilyKey = ").append(form.getSubDimensionKey())
			       .append(" )productFamily on fa.ProductKey = productFamily.ProductKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
			sBuffer.append(" where fa.productKey = ").append(form.getSubDimensionKey());
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" and fa.Year = ").append(form.getYear())
			   	   .append(" and fa.Month = ").append(form.getMonth());
			sBuffer.append(" group by fa.ProductKey having fa.ProductKey <> ''");
		}
		else if("Component".equals(form.getDimension())) {
			sBuffer.append(" from (select YEAR,MONTH,GeographyName,productKey,globalcvkey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa");
			sBuffer.append(" left join DimProduct product on fa.productKey = product.productKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
			sBuffer.append(" where c.CommodityTypeKey = '").append(form.getSubDimensionKey()).append("'");
			sBuffer.append(" and fa.Year = ").append(form.getYear())
		   	   	   .append(" and fa.Month = ").append(form.getMonth());
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getRegionIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getRegionIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by c.CommodityTypeKey,c.CommodityType having c.CommodityType <> ''");
		}
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append(" order by sum(fa.[60DaysForecastQty]) desc");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append(" order by sum(fa.[60DaysGrossForecastQty]) desc");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("typeName", StringType.INSTANCE)
				.addScalar("FAValue", IntegerType.INSTANCE)
				.addScalar("FARate", FloatType.INSTANCE)
				.addScalar("OrderQty", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		
		return query.list();
		
	}

	//TODO
	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchFaComponentDashboardRemarkChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append("select top 15 isnull(sum([60DaysForecastQty]),0) as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append("select top 15 isnull(sum([60DaysGrossForecastQty]),0) as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		
		if("Region".equals(form.getDimension())) {
			if("Odm".equals(form.getDashboardType())){
				sBuffer.append(" 1 as subDimensionKey,")
					   .append("fa.GeographyName as subDimensionName")
//					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")

					   .append(" from (select YEAR, MONTH,dg.GeographyName,-1 as productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey, SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,m.OdmKey,m.GlobalCVKey,dg.GeographyName")
					   .append(" Union all ")
					   .append(" select YEAR, MONTH,dg.GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
					   	sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
					   }
					   if(!StringUtil.isEmpty(form.getFamilyIds())) {
					   	sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
					   }
					   if(!StringUtil.isEmpty(form.getProductIds())) {
					   	sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
					   }
				sBuffer.append(" group by YEAR,MONTH,dg.GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}else if("component".equalsIgnoreCase(form.getDashboardType()) || "Product".equals(form.getDashboardType())){
				sBuffer.append(" 1 as subDimensionKey,")
					   .append("fa.GeographyName as subDimensionName")
					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}
			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth());
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and fa.ODMKey = ").append(form.getDashboardTypeKey());
				}
				else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and fa.ProductKey = ").append(form.getDashboardTypeKey());
				}
				else if("component".equals(form.getDashboardType())){
					sBuffer.append(" and c.CommodityTypeKey = ").append(form.getDashboardTypeKey());
				}
			}
			if(!StringUtil.isEmpty(form.getGeoIds()) && !"Odm".equals(form.getDashboardType())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			
			if(!StringUtil.isEmpty(form.getFamilyIds()) && !"Odm".equals(form.getDashboardType())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds()) && !"Odm".equals(form.getDashboardType())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.GeographyName having fa.GeographyName <> ''");
		}
		//for Odm remark chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" case when fa.ODMKey is null then 0 else fa.ODMKey end as subDimensionKey,")
				   .append(" odm.ODMEnglishName as subDimensionName")
				   
//				   .append(" from (select YEAR, MONTH,'others' as GeographyName,-1 as productKey,OdmKey,m.GlobalCVKey as GlobalCVKey, SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') group by YEAR,MONTH,OdmKey,m.GlobalCVKey")
//				   .append(" Union all ")
//				   .append(" select YEAR, MONTH,GeographyName,productKey,OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,m.GlobalCVKey) fa")
				   
				   .append(" from ( select YEAR, MONTH,GeographyName,productKey,OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,m.GlobalCVKey) fa")
				   
				   .append(" left join DimODM odm on fa.ODMKey=odm.ODMKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
				   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
				   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
	    	if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
				}
				else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and fa.ProductKey = ").append(form.getDashboardTypeKey());
				}
				else if("component".equals(form.getDashboardType())){
					sBuffer.append(" and c.CommodityTypeKey = ").append(form.getDashboardTypeKey());
				}
			}
	    	if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.ODMKey,odm.ODMEnglishName having odm.ODMEnglishName <> ''");
		}
		else if("Product".equals(form.getDimension())) {
			if("Odm".equals(form.getDashboardType())){
				sBuffer.append(" case when fa.productKey is null then 0 else fa.productKey end as subDimensionKey,")
			       	   .append(" pro.productEnglishName as subDimensionName")
//					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")

					   .append(" from (select YEAR, MONTH,'others' as GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey, SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,m.OdmKey,m.productKey,m.GlobalCVKey")
					   .append(" Union all ")
					   .append(" select YEAR, MONTH,GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,dg.GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}else if("Region".equals(form.getDashboardType()) || "component".equalsIgnoreCase(form.getDashboardType())){
				sBuffer.append(" case when fa.productKey is null then 0 else fa.productKey end as subDimensionKey,")
			       	   .append(" pro.productEnglishName as subDimensionName")
					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}
			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth());
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
				}
				if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and fa.ODMKey = ").append(form.getDashboardTypeKey());
				}
				else if("component".equals(form.getDashboardType())){
					sBuffer.append(" and c.CommodityTypeKey = ").append(form.getDashboardTypeKey());
				}
			}
			if(!StringUtil.isEmpty(form.getGeoIds()) && !"Odm".equals(form.getDashboardType())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds()) && !"Odm".equals(form.getDashboardType())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds()) && !"Odm".equals(form.getDashboardType())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.productkey,pro.productEnglishName having pro.productEnglishName <> ''");
		}
		
		//for Family remark chart, and overview chart maybe ODM or Region
		else if("Component".equals(form.getDimension())) {
			if("Odm".equals(form.getDashboardType())){
				sBuffer.append(" isnull(c.CommodityTypeKey,0) as subDimensionKey,")
					   .append(" c.CommodityType as subDimensionName")
//					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")

					   .append(" from (select YEAR, MONTH,'others' as GeographyName,-1 as productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey, SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,m.OdmKey,m.GlobalCVKey")
					   .append(" Union all ")
					   .append(" select YEAR, MONTH,GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,dg.GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}else if("Region".equals(form.getDashboardType()) || "Product".equals(form.getDashboardType())){
				sBuffer.append(" isnull(c.CommodityTypeKey,0) as subDimensionKey,")
				   	   .append(" c.CommodityType as subDimensionName")
					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}
			
			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth());
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
				}
				else if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and fa.ODMKey = ").append(form.getDashboardTypeKey());
				}
				else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and fa.ProductKey = ").append(form.getDashboardTypeKey());
				}
			}
			if(!StringUtil.isEmpty(form.getGeoIds()) && !"Odm".equals(form.getDashboardType())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds()) && !"Odm".equals(form.getDashboardType())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds()) && !"Odm".equals(form.getDashboardType())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by c.CommodityTypeKey,c.CommodityType having c.CommodityType <> ''");
		}
		
		sBuffer.append(" order by faRate desc");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("subDimensionName", StringType.INSTANCE)
				.addScalar("subDimensionValue", IntegerType.INSTANCE)
				.addScalar("subDimensionKey", IntegerType.INSTANCE)
				.addScalar("faRate", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}
	
	//TODO
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> fetchFaCrossMonthOverviewChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append("select isnull(sum([60DaysForecastQty]),0) as FAValue,")
				   .append(" isnull(sum(OrderQty),0) as OrderQty,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),4),0) ")
				   .append(" as FARate,")
				   .append("'Mps' as typeName");
		}
		else {
			sBuffer.append("select isnull(sum([60DaysGrossForecastQty]),0) as FAValue,")
				   .append(" isnull(sum(OrderQty),0) as OrderQty,")
			       .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),4),0) ")
			       .append(" as FARate,")
			       .append("'grossForecast' as typeName");
		}
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa");
//			sBuffer.append(" join DimGeography region on region.GeographyName = fa.GeographyName ");
			sBuffer.append(" left join DimProduct product on fa.productKey = product.productKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
			sBuffer.append(" where fa.GeographyName = '").append(form.getSubDimension()).append("'");
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
//			if(!StringUtil.isEmpty(form.getGeoIds()) && !"undefined".equals(form.getGeoIds())) {
//				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
//			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
		}
		else if("Odm".equals(form.getDimension())) {
				sBuffer.append(" from (select YEAR, MONTH,'others' as GeographyName,-1 as productKey,m.OdmKey, m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
				       .append(" left join DimProduct product on m.productKey = product.productKey");
				sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,m.OdmKey,m.GlobalCVKey")
					   .append(" Union all ")
					   .append(" select YEAR, MONTH,GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct product on m.productKey = product.productKey")
					   .append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				       .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
				       .append(" and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
				       if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,dg.GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey) fa")
					   
//				sBuffer.append(" from ( select YEAR, MONTH,GeographyName,productKey,OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,m.GlobalCVKey) fa")
				       
				       .append(" left join DimProduct product on fa.productKey = product.productKey");
				sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
				sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
				sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
				sBuffer.append(" where fa.ODMKey = ").append(form.getSubDimensionKey());
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
//			if(!StringUtil.isEmpty(form.getGeoIds()) && !"undefined".equals(form.getGeoIds())) {
//				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
//			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
		}
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa");
			sBuffer.append(" left join DimProduct product on fa.ProductKey = product.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
				   .append(" where fa.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
//			if(!StringUtil.isEmpty(form.getGeoIds()) && !"undefined".equals(form.getGeoIds())) {
//				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
//			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
		}
		if("Component".equals(form.getDimension())) {
			sBuffer.append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa");
			sBuffer.append(" left join DimProduct product on fa.ProductKey = product.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
			sBuffer.append(" where c.CommodityTypeKey = '").append(form.getSubDimensionKey()).append("'");
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
//			if(!StringUtil.isEmpty(form.getGeoIds()) && !"undefined".equals(form.getGeoIds())) {
//				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
//			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
		}
		sBuffer.append(" and fa.Year = ").append(form.getYear())
			   .append(" and fa.Month = ").append(form.getMonth());
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("typeName", StringType.INSTANCE)
				.addScalar("FAValue", IntegerType.INSTANCE)
				.addScalar("FARate", FloatType.INSTANCE)
				.addScalar("OrderQty", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		
		return query.list();
	}

	//TODO
	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchFaComponentCrossMonthRemarkChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append("select top 15 case when sum([60DaysForecastQty]) is null then 0")
				   .append(" else sum([60DaysForecastQty]) end as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append("select top 15 case when sum([60DaysGrossForecastQty]) is null then 0")
				   .append(" else sum([60DaysGrossForecastQty]) end as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		
		//for Region remark chart, and overview chart maybe ODM or Family
		if("Region".equals(form.getDimension())) {
			if("Odm".equals(form.getCrossMonthType())){
				sBuffer.append(" 1 as subDimensionKey,")
					   .append("fa.GeographyName as subDimensionName")
//					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")

					   .append(" from (select YEAR, MONTH,dg.GeographyName,-1 as productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey, SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
						   sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,dg.GeographyName,m.OdmKey,m.GlobalCVKey")
					   .append(" Union all ")
					   .append(" select YEAR, MONTH,GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
						   sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,dg.GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}else if("component".equalsIgnoreCase(form.getCrossMonthType()) || "Product".equals(form.getCrossMonthType())){
				sBuffer.append(" 1 as subDimensionKey,")
					   .append(" fa.GeographyName as subDimensionName")
					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}
			
			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth());
			if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			else if("Component".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and c.CommodityTypeKey = ").append(form.getCrossMonthTypeKey());
			}
			if(!StringUtil.isEmpty(form.getGeoIds()) && !"Odm".equals(form.getCrossMonthType())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds()) && !"Odm".equals(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds()) && !"Odm".equals(form.getCrossMonthType())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.GeographyName having fa.GeographyName <> ''");
		}
		//for Odm remark chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" isnull(fa.ODMKey,0) as subDimensionKey,")
				   .append(" odm.ODMEnglishName as subDimensionName");
			
//		    sBuffer.append(" from (select YEAR, MONTH,'others' as GeographyName,-1 as productKey,OdmKey, m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') group by YEAR,MONTH,OdmKey,m.GlobalCVKey")
//				   .append(" Union all ")
//				   .append(" select YEAR, MONTH,GeographyName,productKey,OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,m.GlobalCVKey) fa")
				   
			sBuffer.append(" from ( select YEAR, MONTH,GeographyName,productKey,OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,m.GlobalCVKey) fa")
				   
				   .append(" left join DimODM odm on fa.ODMKey=odm.ODMKey");
		    sBuffer.append(" left join DimProduct product on fa.ProductKey = product.ProductKey");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
			sBuffer.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
			if("Region".equals(form.getCrossMonthType()))
				sBuffer.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
			else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			else if("Component".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and c.CommodityTypeKey = ").append(form.getCrossMonthTypeKey());
			}
			
	    	if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
//			if(!StringUtil.isEmpty(form.getGeoIds()) && !"undefined".equals(form.getGeoIds())) {
//				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
//			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.ODMKey,odm.ODMEnglishName having odm.ODMEnglishName <> ''");
		}
		else if("Product".equals(form.getDimension())) {
			if("Odm".equals(form.getCrossMonthType())){
				sBuffer.append(" case when fa.productKey is null then 0 else fa.productKey end as subDimensionKey,")
			       	   .append(" pro.productEnglishName as subDimensionName")
//					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")

					   .append(" from (select YEAR, MONTH,'others' as GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey, SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
						   sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,m.OdmKey,m.productKey,m.GlobalCVKey")
					   .append(" Union all ")
					   .append(" select YEAR, MONTH,GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					    if(!StringUtil.isEmpty(form.getGeoIds())) {
						   sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,dg.GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey) fa");
				sBuffer.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}else if("Region".equals(form.getCrossMonthType()) || "component".equalsIgnoreCase(form.getCrossMonthType())){
				sBuffer.append(" case when fa.productKey is null then 0 else fa.productKey end as subDimensionKey,")
			       	   .append(" pro.productEnglishName as subDimensionName")
					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}
			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth());
			
			if("Region".equals(form.getCrossMonthType()))
				sBuffer.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
			else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
			else if("Component".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and c.CommodityTypeKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(!StringUtil.isEmpty(form.getGeoIds()) && !"Odm".equals(form.getCrossMonthType())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds()) && !"Odm".equals(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds()) && !"Odm".equals(form.getCrossMonthType())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by fa.productkey,pro.productEnglishName having pro.productEnglishName <> ''");
		}
		
		else if("Component".equals(form.getDimension())) {
			if("Odm".equals(form.getCrossMonthType())){
				sBuffer.append(" isnull(c.CommodityTypeKey,0) as subDimensionKey,")
					   .append(" c.CommodityType as subDimensionName")
//					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")

					   .append(" from (select YEAR, MONTH,'others' as GeographyName,-1 as productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey, SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
						   sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,m.OdmKey,m.GlobalCVKey")
					   .append(" Union all ")
					   .append(" select YEAR, MONTH,GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey as GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey inner Join DimGlobalCV v on v.GlobalCVKey = m.GlobalCVKey inner join DimCommodityType c on v.CommodityTypeKey = c.CommodityTypeKey ")
					   .append(" left join DimProduct pro on m.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey")
					   .append(" where m.versionDateKey = (select  max(versionDateKey) from FactMonthlySummaryofComponentFA) ")
					   .append(" and c.CommodityType not in('HDD', 'Memory' , 'Vram' , 'Camera' ,'Wlan' , 'Adepter') ");
					   if(!StringUtil.isEmpty(form.getGeoIds())) {
						sBuffer.append(" and dg.GeographyName in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and m.ProductKey in(").append(form.getProductIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getFamilyIds())) {
							sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
						}
				sBuffer.append(" group by YEAR,MONTH,dg.GeographyName,m.productKey,m.OdmKey,m.GlobalCVKey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}else if("Region".equals(form.getCrossMonthType()) || "Product".equals(form.getCrossMonthType())){
				sBuffer.append(" isnull(c.CommodityTypeKey,0) as subDimensionKey,")
				   	   .append(" c.CommodityType as subDimensionName")
					   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,globalcvkey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey,globalcvkey) fa")
					   .append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey")
					   .append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey")
					   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
					   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			}
			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth());
			
			if("Region".equals(form.getCrossMonthType()))
				sBuffer.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
			else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(!StringUtil.isEmpty(form.getGeoIds()) && !"Odm".equals(form.getCrossMonthType())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds()) && !"Odm".equals(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds()) && !"Odm".equals(form.getCrossMonthType())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getComponentIds())) {
				sBuffer.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
			sBuffer.append(" group by c.CommodityTypeKey,c.CommodityType having c.CommodityType <> ''");
		}
		sBuffer.append(" order by faRate desc");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("subDimensionName", StringType.INSTANCE)
				.addScalar("subDimensionValue", IntegerType.INSTANCE)
				.addScalar("subDimensionKey", IntegerType.INSTANCE)
				.addScalar("faRate", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}
	 
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> getcomponentFaPieChart(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60DaysForecastQty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60DaysForecastQty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60DaysForecastQty],0) then 1 else 0 end) as equal_plan ")
			   .append("from (select YEAR,MONTH,[60DaysForecastQty] as [60DaysForecastQty], OrderQty as OrderQty from FactMonthlySummaryofcomponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,[60DaysForecastQty],OrderQty,odmkey,productkey,GlobalCVKey) fa ");
		}
		else{
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60daysgrossforecastqty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60daysgrossforecastqty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60daysgrossforecastqty],0) then 1 else 0 end) as equal_plan ")
			   .append("from (select YEAR,MONTH,[60daysgrossforecastqty] as [60daysgrossforecastqty],OrderQty as OrderQty from FactMonthlySummaryofcomponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,[60daysgrossforecastqty],OrderQty,odmkey,productkey,GlobalCVKey) fa ");
		}
		sql.append(" where fa.Year = ").append(form.getYear())
	   	   .append(" and fa.Month = ").append(form.getMonth());
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
			
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and isnull(fa.[60DaysGrossForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
			/*if(!StringUtil.isEmpty(form.getRegionIds())) {
				sql.append(" and fa.GeographyName in(").append(form.getRegionIds()).append(")");
			}
	   	    if(!StringUtil.isEmpty(form.getOdmIds())) {
		    	sql.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
	    	if(!StringUtil.isEmpty(form.getProductIds())) {
	    		sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}*/
	    	sql.append(") p ")
			   .append("UNPIVOT (value for rowname in(over_plan,under_plan,equal_plan)) p");
		
		Query query = getSession().createSQLQuery(sql.toString())
			.addScalar("value", IntegerType.INSTANCE)
			.addScalar("rowName", StringType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> getcomponentFaDashboardPieChart(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60DaysForecastQty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60DaysForecastQty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60DaysForecastQty],0) then 1 else 0 end) as equal_plan ");
		}
		else{
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60daysgrossforecastqty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60daysgrossforecastqty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60daysgrossforecastqty],0) then 1 else 0 end) as equal_plan ");
		}
		sql.append("from (select YEAR,MONTH,m.odmkey as odmkey,m.productkey,dg.GeographyName as GeographyName,GlobalCVKey,[60DaysForecastQty] as [60DaysForecastQty],[60daysgrossforecastqty] as [60daysgrossforecastqty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,[60DaysForecastQty],[60daysgrossforecastqty],OrderQty,odmkey,productkey,GlobalCVKey) fa ");
		sql.append(" left join DimProduct product on fa.productKey = product.productKey");
		sql.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
		sql.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
		sql.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
		sql.append(" where fa.Year = ").append(form.getYear())
 	   	   .append(" and fa.Month = ").append(form.getMonth());
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and isnull(fa.[60DaysGrossForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		
		if(form.getDashboardTypeKey() != -1) {
			if("Region".equals(form.getDashboardType())){
				sql.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
			}
			else if("Odm".equals(form.getDashboardType())){
				sql.append(" and fa.ODMKey = ").append(form.getDashboardTypeKey());
			}
			else if("Product".equals(form.getDashboardType())){
				sql.append(" and fa.ProductKey = ").append(form.getDashboardTypeKey());
			}
			else if("component".equals(form.getDashboardType())){
				sql.append(" and c.CommodityTypeKey = ").append(form.getDashboardTypeKey());
			}
		}
		
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
 	   	    if(!StringUtil.isEmpty(form.getOdmIds())) {
		    	sql.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
	    	if(!StringUtil.isEmpty(form.getProductIds())) {
	    		sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
	    	if(!StringUtil.isEmpty(form.getComponentIds())) {
	    		sql.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
			}
	    	sql.append(") p ")
		       .append("UNPIVOT (value for rowname in(over_plan,under_plan,equal_plan)) p");
		
		Query query = getSession().createSQLQuery(sql.toString())
			.addScalar("value", IntegerType.INSTANCE)
			.addScalar("rowName", StringType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		return query.list();
	}
	 
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> getcomponentFaCrossmonthPieChart(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60DaysForecastQty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60DaysForecastQty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60DaysForecastQty],0) then 1 else 0 end) as equal_plan ");
		}
		else{
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60daysgrossforecastqty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60daysgrossforecastqty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60daysgrossforecastqty],0) then 1 else 0 end) as equal_plan ");
		}
		sql.append("from (select YEAR,MONTH,m.odmkey as odmkey,m.productkey,dg.GeographyName as GeographyName,GlobalCVKey,[60DaysForecastQty] as [60DaysForecastQty],[60daysgrossforecastqty] as [60daysgrossforecastqty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,[60DaysForecastQty],[60daysgrossforecastqty],OrderQty,odmkey,productkey,GlobalCVKey) fa ");
		sql.append(" left join DimProduct product on fa.productKey = product.productKey");
		sql.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
		sql.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
		sql.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
		sql.append(" where fa.Year = ").append(form.getYear())
 	   	   .append(" and fa.Month = ").append(form.getMonth());
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and isnull(fa.[60DaysGrossForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
		}
   	    if(!StringUtil.isEmpty(form.getOdmIds())) {
	    	sql.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
    	if(!StringUtil.isEmpty(form.getProductIds())) {
    		sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
		}
    	if(!StringUtil.isEmpty(form.getComponentIds())) {
    		sql.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
		}
    	
    	if(!StringUtil.isEmpty(form.getCrossMonthType())){
			if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.GeographyName = '").append(form.getCrossMonthTypeValue()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}else if("component".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and c.CommodityTypeKey = ").append(form.getCrossMonthTypeKey());
			}
		}
	    	
	    	sql.append(") p ")
		       .append("UNPIVOT (value for rowname in(over_plan,under_plan,equal_plan)) p");
		
		Query query = getSession().createSQLQuery(sql.toString())
			.addScalar("value", IntegerType.INSTANCE)
			.addScalar("rowName", StringType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		return query.list();
	}
	
	@Override
	public List<String> getLackProduct(SearchFaForm form, int target) {
//		StringBuffer sBuffer=new StringBuffer();
//		
//		sBuffer.append("select lack.product from (")
//			   .append(" select dimProduct.ProductEnglishName as product, dimProduct.ProductKey,");
//		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())){
//			sBuffer.append(" isnull(sum(fa.[60DaysForecastQty]),0) as mps,");
//		}else{
//			sBuffer.append(" isnull(sum(fa.[60DaysGrossForecastQty]),0) as mps,");
//		}
//		sBuffer.append(" isnull(sum(fa.OrderQty),0) as Qty")
//			   .append(" from FactMonthlySummaryofComponentFA fa")
//			   .append(" join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey")
//			   .append(" where Year = ").append(form.getYear())
//			   .append(" and Month = ").append(form.getMonth())
//			   .append(" group by dimProduct.ProductKey, dimProduct.ProductEnglishName");
//			   
//	   if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())){
//			sBuffer.append(" having isnull(sum(fa.OrderQty),0) *100 / isnull(sum(fa.[60DaysForecastQty]),1) < 90 ) lack");
//	   }else{
//			sBuffer.append(" having isnull(sum(fa.OrderQty),0) *100 / isnull(sum(fa.[60DaysGrossForecastQty]),1) < 90 ) lack");
//	   }
//		   
//	   Query query = getSession().createSQLQuery(sBuffer.toString());
//	   return query.list();
	   return new ArrayList<String>();
	}
	
	@Override
	public List<String> getLackRegion(SearchFaForm form, int target) {
		
//		StringBuffer sBuffer=new StringBuffer();
//		
//		sBuffer.append("select lack.region from (")
//			   .append(" select region.GeographyName as region, region.GeographyKey,");
//		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())){
//			sBuffer.append(" isnull(sum(fa.[60DaysForecastQty]),0) as mps,");
//		}else{
//			sBuffer.append(" isnull(sum(fa.[60DaysGrossForecastQty]),0) as mps,");
//		}
//		sBuffer.append(" isnull(sum(fa.OrderQty),0) as Qty")
//			   .append(" from FactMonthlySummaryofComponentFA fa")
//			   .append(" join DimGeography region on fa.regionKey = region.GeographyKey")
//			   .append(" where Year = ").append(form.getYear())
//			   .append(" and Month = ").append(form.getMonth())
//			   .append(" group by region.GeographyName,region.GeographyKey");
//			   
//	   if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())){
//			sBuffer.append(" having isnull(sum(fa.OrderQty),0) *100 / isnull(sum(fa.[60DaysForecastQty]),1) < 90 ) lack");
//	   }else{
//			sBuffer.append(" having isnull(sum(fa.OrderQty),0) *100 / isnull(sum(fa.[60DaysGrossForecastQty]),1) < 90 ) lack");
//	   }
//		   
//	Query query = getSession().createSQLQuery(sBuffer.toString());
	   return new ArrayList<String>();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<GeoFA> getGeoFa(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select geo.geo as geo,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append(" isnull(sum(fa.[60DaysForecastQty]),0) as FAValue,");
			sBuffer.append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),4),0) as FARate");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sBuffer.append(" isnull(sum(fa.[60DaysGrossForecastQty]),0) as FAValue,");
			sBuffer.append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),4),0) as FARate");
		}
		sBuffer.append(" from (select YEAR,MONTH,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty ,dg.GeographyName GeographyName")
			   .append(" from FactMonthlySummaryofComponentFA m inner join DimGeography dg")
			   .append(" on dg.GeographyKey = m.RegionKey")
			   .append(" where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA)")
			   .append(" group by YEAR,MONTH,dg.GeographyName,productKey,odmKey,GlobalCVKey) fa")
			   .append(" inner join factGEOListMapping geo on fa.GeographyName = geo.NormalizedSubgeo");
			   
		sBuffer.append(" where Year = ").append(form.getYear())
			   .append(" and Month = ").append(form.getMonth())
			   .append(" group by geo.geo");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("Geo", StringType.INSTANCE)
				.addScalar("FAValue", FloatType.INSTANCE)
				.addScalar("FARate", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GeoFA.class));
		List<GeoFA> result = query.list();
		return result;
	}
	 
	@Override
	public long getComponentFaDetailCount(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(fa.id)");
		sql.append(" from (select max(id) as id,YEAR,MONTH,m.odmkey as odmkey,m.productkey,dg.GeographyName as GeographyName,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60daysgrossforecastqty]) as [60daysgrossforecastqty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,odmkey,productkey,GlobalCVKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
		sql.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getOdmIds())) {
			sql.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
//		if(!StringUtil.isEmpty(form.getGeoIds()) && !"undefined".equals(form.getGeoIds())) {
//			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
//		}
		if(!StringUtil.isEmpty(form.getComponentIds())) {
			sql.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
		}
		
		if(!StringUtil.isEmpty(form.getCrossMonthType())){
			if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.GeographyName = '").append(form.getCrossMonthTypeValue()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}else if("component".equalsIgnoreCase(form.getCrossMonthType())) {
			sql.append(" and c.CommodityTypeKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and fa.GeographyName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("component".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and c.CommodityType = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0) ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0) ");
		}
		
		Query query = getSession().createSQLQuery(sql.toString());
		Object result = query.uniqueResult();
		if(result != null){
			return Long.parseLong(result.toString());
		}else{
			return 0;
		}
	}
	 
	@Override
	public long getComponentFaDashboardDetailCount(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(fa.id)");
		sql.append(" from (select max(id) as id,YEAR,MONTH,m.odmkey as odmkey,m.productkey,dg.GeographyName as GeographyName,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60daysgrossforecastqty]) as [60daysgrossforecastqty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,odmkey,productkey,GlobalCVKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
//		sql.append(" left join DimGeography region on fa.RegionKey = region.GeographyKey");
		sql.append(" left join factGEOListMapping geo on fa.GeographyName = geo.NormalizedSubgeo");
		sql.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
		sql.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getOdmIds())) {
			sql.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getGeoIds()) && !"undefined".equals(form.getGeoIds())) {
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getComponentIds())) {
			sql.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
		}
		
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and fa.GeographyName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("component".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and c.CommodityType = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0) ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0) ");
		}
		
		Query query = getSession().createSQLQuery(sql.toString());
		Object result = query.uniqueResult();
		if(result != null){
			return Long.parseLong(result.toString());
		}else{
			return 0;
		}
	}
	  
	@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getComponentFaDetail(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append("(select top ").append(form.getRowCount());
		sql.append(" * from ");
		sql.append("(select  top ").append(form.getEndRow());
		sql.append(" fa.id as id,");
		sql.append(" fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" geo.Normalizedgeo as geo,");
		sql.append(" fa.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		sql.append(" c.CommodityType as component,");
		sql.append(" v.CommodityValue as CV,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" isnull(fa.[60DaysForecastQty],0) as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" isnull(fa.[60DaysGrossForecastQty],0) as MPSForecast,");
		}
		sql.append(" isnull(fa.OrderQty,0) as OrderQty,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" case when isnull(fa.[60DaysForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" case when isnull(fa.[60DaysGrossForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysGrossForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysGrossForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		sql.append(" from (select max(id) as id,YEAR,MONTH,m.odmkey as odmkey,m.productkey,dg.GeographyName as GeographyName,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60daysgrossforecastqty]) as [60daysgrossforecastqty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,odmkey,productkey,GlobalCVKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping geo on fa.GeographyName = geo.NormalizedSubgeo");
		sql.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
		sql.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		
		if(StringUtils.isNotBlank(form.getGEO())){
			sql.append(" and geo.NormalizedGeo = '").append(form.getGEO()).append("'");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sql.append(" and fa.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sql.append(" and fa.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getComponentIds())){
			sql.append(" and c.CommodityTypeKey in (").append(form.getComponentIds()).append(") ");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		
		if(!StringUtil.isEmpty(form.getCrossMonthType())){
			if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.GeographyName = '").append(form.getCrossMonthTypeValue()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}else if("component".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and c.CommodityTypeKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and fa.GeographyName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("component".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and c.CommodityType = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0) ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0) ");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType()).append(" ) t");
		}else{
			sql.append(" order by ")
			   .append("  id ").append(form.getSortType()).append(" ) t");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(" ,id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sql.append(" order by id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType());
		}else{
			   sql.append(" order by id ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("component", StringType.INSTANCE)
				.addScalar("CV", StringType.INSTANCE)
				.addScalar("MPSForecast", LongType.INSTANCE)
				.addScalar("OrderQty", LongType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}
	
	@Override
	public long getComponentFaGEODetailCount(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(fa.id)");
		sql.append(" from (select max(id) as id,YEAR,MONTH,m.odmkey as odmkey,m.productkey,dg.GeographyName as GeographyName,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60daysgrossforecastqty]) as [60daysgrossforecastqty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,odmkey,productkey,GlobalCVKey) fa");
//		sql.append(" left join DimGeography region on fa.GeographyName = region.GeographyName");
//		sql.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey");
		sql.append(" left join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		   
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0) ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0) ");
		}
		sql.append(" and v.Geo = '").append(form.getGEO()).append("'");
			
		Query query = getSession().createSQLQuery(sql.toString());
		Object result = query.uniqueResult();
		if(result != null){
			return Long.parseLong(result.toString());
		}else{
			return 0;
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getComponentFaGEODetail(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append("(select top ").append(form.getRowCount());
		sql.append(" * from ");
		sql.append("(select  top ").append(form.getEndRow());
		sql.append(" fa.id as id,");
		sql.append(" fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" geo.NormalizedGeo as geo,");
		sql.append(" fa.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		sql.append(" c.CommodityType as component,");
		sql.append(" v.CommodityValue as CV,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" isnull(fa.[60DaysForecastQty],0) as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" isnull(fa.[60DaysGrossForecastQty],0) as MPSForecast,");
		}
		sql.append(" isnull(fa.OrderQty,0) as OrderQty,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" case when isnull(fa.[60DaysForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysForecastQty],0) < isnull(fa.orderQty,0) then 'under plan'  else '' end as RootCause");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" case when isnull(fa.[60DaysGrossForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysGrossForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysGrossForecastQty],0) < isnull(fa.orderQty,0) then 'under plan'  else '' end as RootCause");
		}
		sql.append(" from (select max(id) as id,YEAR,MONTH,m.odmkey as odmkey,m.productkey,dg.GeographyName as GeographyName,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60daysgrossforecastqty]) as [60daysgrossforecastqty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,odmkey,productkey,GlobalCVKey)  fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping geo on fa.GeographyName = geo.NormalizedSubgeo");
		sql.append(" left join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
		sql.append(" left join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		
		if(StringUtils.isNotBlank(form.getGEO())){
			sql.append(" and geo.NormalizedGeo = '").append(form.getGEO()).append("'");
		}
		/*if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and fa.GeographyName =  '" + form.getSubDimension().toUpperCase()+ "' ");
		}*/
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0) ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0) ");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType()).append(" ) t");
		}else{
			sql.append(" order by ")
			   .append("  id ").append(form.getSortType()).append(" ) t");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(" ,id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sql.append(" order by id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType());
		}else{
			   sql.append(" order by id ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("component", StringType.INSTANCE)
				.addScalar("CV", StringType.INSTANCE)
				.addScalar("MPSForecast", LongType.INSTANCE)
				.addScalar("OrderQty", LongType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getComponentFaPieDetail(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append("(select top ").append(form.getRowCount());
		sql.append(" * from ");
		sql.append("(select  top ").append(form.getEndRow());
		sql.append(" fa.id as id,");
		sql.append(" fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" geo.Normalizedgeo as geo,");
		sql.append(" fa.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		sql.append(" c.CommodityType as component,");
		sql.append(" v.CommodityValue as CV,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" isnull(fa.[60DaysForecastQty],0) as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" isnull(fa.[60DaysGrossForecastQty],0) as MPSForecast,");
		}
		sql.append(" isnull(fa.OrderQty,0) as OrderQty,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" case when isnull(fa.[60DaysForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" case when isnull(fa.[60DaysGrossForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysGrossForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysGrossForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		sql.append(" from (select max(id) as id,YEAR,MONTH,m.odmkey as odmkey,m.productkey,dg.GeographyName as GeographyName,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60daysgrossforecastqty]) as [60daysgrossforecastqty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,odmkey,productkey,GlobalCVKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping geo on fa.GeographyName = geo.NormalizedSubgeo");
		sql.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
		sql.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sql.append(" and fa.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sql.append(" and fa.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getComponentIds())){
			sql.append(" and c.CommodityTypeKey in (").append(form.getComponentIds()).append(") ");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		
		//>||<||=
		if("over_plan".equals(form.getSubDimension())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],0)> isnull(fa.orderQty,0) ");
		}else if("equal_plan".equals(form.getSubDimension())) {
			sql.append(" and fa.[60DaysForecastQty] = fa.orderQty ");
		}else if("under_plan".equals(form.getSubDimension())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],0)< isnull(fa.orderQty,0) ");
		}
				
		if(!StringUtil.isEmpty(form.getCrossMonthType())){
			if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.GeographyName = '").append(form.getCrossMonthTypeValue()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}else if("component".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and c.CommodityTypeKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and fa.GeographyName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("component".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and c.CommodityType = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0) ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0) ");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType()).append(" ) t");
		}else{
			sql.append(" order by ")
			   .append("  id ").append(form.getSortType()).append(" ) t");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(" ,id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sql.append(" order by id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType());
		}else{
			   sql.append(" order by id ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("component", StringType.INSTANCE)
				.addScalar("CV", StringType.INSTANCE)
				.addScalar("MPSForecast", LongType.INSTANCE)
				.addScalar("OrderQty", LongType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}
	 
	@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getComponentFADetailExport(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select fa.id as id,");
		sql.append(" fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" geo.Normalizedgeo as geo,");
		sql.append(" fa.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		sql.append(" c.CommodityType as component,");
		sql.append(" v.CommodityValue as CV,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" isnull(fa.[60DaysForecastQty],0) as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" isnull(fa.[60DaysGrossForecastQty],0) as MPSForecast,");
		}
		sql.append(" isnull(fa.OrderQty,0) as OrderQty,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" case when isnull(fa.[60DaysForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" case when isnull(fa.[60DaysGrossForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysGrossForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysGrossForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		sql.append(" from (select max(id) as id,YEAR,MONTH,m.odmkey as odmkey,m.productkey,dg.GeographyName as GeographyName,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60daysgrossforecastqty]) as [60daysgrossforecastqty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,odmkey,productkey,GlobalCVKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping geo on fa.GeographyName = geo.NormalizedSubgeo");
		sql.append(" join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
		sql.append(" join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		
		if(StringUtils.isNotBlank(form.getGEO())){
			sql.append(" and geo.NormalizedGeo = '").append(form.getGEO()).append("'");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sql.append(" and fa.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sql.append(" and fa.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getComponentIds())) {
			sql.append(" and c.CommodityTypeKey in(").append(form.getComponentIds()).append(")");
		}
		
		if(!StringUtil.isEmpty(form.getCrossMonthType())){
			if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.GeographyName = '").append(form.getCrossMonthTypeValue()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}else if("component".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and c.CommodityTypeKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and fa.GeographyName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("component".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and c.CommodityType = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if("over_plan".equals(form.getSubDimension())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],0)> isnull(fa.orderQty,0) ");
		}else if("equal_plan".equals(form.getSubDimension())) {
			sql.append(" and fa.[60DaysForecastQty] = fa.orderQty ");
		}else if("under_plan".equals(form.getSubDimension())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],0)< isnull(fa.orderQty,0) ");
		}
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0) ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0) ");
		}
		
		sql.append(" order by id");
		
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("component", StringType.INSTANCE)
				.addScalar("CV", StringType.INSTANCE)
				.addScalar("MPSForecast", LongType.INSTANCE)
				.addScalar("OrderQty", LongType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getComponentFAGEODetailExport(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select fa.id as id,");
		sql.append(" fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" geo.NormalizedGeo as geo,");
		sql.append(" fa.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		sql.append(" c.CommodityType as component,");
		sql.append(" v.CommodityValue as CV,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" isnull(fa.[60DaysForecastQty],0) as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" isnull(fa.[60DaysGrossForecastQty],0) as MPSForecast,");
		}
		sql.append(" isnull(fa.OrderQty,0) as OrderQty,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" case when isnull(fa.[60DaysForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysForecastQty],0) < isnull(fa.orderQty,0) then 'under plan'  else '' end as RootCause");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" case when isnull(fa.[60DaysGrossForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysGrossForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysGrossForecastQty],0) < isnull(fa.orderQty,0) then 'under plan'  else '' end as RootCause");
		}
		sql.append(" from (select max(id) as id,YEAR,MONTH,m.odmkey as odmkey,m.productkey,dg.GeographyName as GeographyName,GlobalCVKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60daysgrossforecastqty]) as [60daysgrossforecastqty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofComponentFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofComponentFA) group by YEAR,MONTH,dg.GeographyName,odmkey,productkey,GlobalCVKey)  fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping geo on fa.GeographyName = geo.NormalizedSubgeo");
		sql.append(" left join dimglobalcv v on fa.GlobalCVKey = v.GlobalCVKey");
		sql.append(" left join DimCommodityType c on c.CommodityTypeKey = v.CommodityTypeKey");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth())
		   .append(" and geo.Geo = '").append(form.getGEO()).append("'");
		/*if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and region.GeographyName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(StringUtils.isNotBlank(form.getRegionIds())){
			sql.append(" and region.GeographyName in(").append(form.getRegionIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sql.append(" and fa.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sql.append(" and fa.productKey in (").append(form.getProductIds()).append(") ");
		}*/
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0) ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getComponentTypes())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0) ");
		}
		sql.append(" order by id ");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("component", StringType.INSTANCE)
				.addScalar("CV", StringType.INSTANCE)
				.addScalar("MPSForecast", LongType.INSTANCE)
				.addScalar("OrderQty", LongType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}
}
