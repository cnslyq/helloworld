package com.lenovo.bi.dao.npi.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.dao.npi.NpiOrderDaoBi;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.util.CalendarUtil;

@Repository
@SuppressWarnings("unchecked")
public class NpiOrderDaoBiImpl extends HibernateBaseDaoImplBi<NpiOrder> implements NpiOrderDaoBi {

	@Override
	public List<NpiOrder> getTTVExcludedOrder(int pmsWaveId,TTVPhase ttvPhase, Date versionDate) {
		StringBuffer sql =  new StringBuffer("select o.pmsWaveId, o.BomNumber as mtm,")
		.append(" o.quantity, o.rsdDate, o.excludedOn, o.excludedBy, o.poItem, o.poNumber, o.shipDate, o.isShipped, o.ttvPhase, o.orderDate, o.region")
		.append(" from BI_NPIOrder o, (select max(excludedOn) as versiondate from BI_NPIOrder")
		.append(" where datediff(day, excludedOn, ?) >=0 ) d ")
		.append("where d.versiondate = o.excludedOn and o.ttvPhase = ? and o.pmsWaveId = ? ");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(NpiOrder.class));
		query.setParameter(0, versionDate);
		query.setParameter(1, ttvPhase.name());
		query.setParameter(2, pmsWaveId);
		return query.list();
	}
	
	@Override
	public List<NpiOrder> getTTVAllExcludedOrders(TTVPhase ttvPhase, Date versionDate) {
		return getAllExcludedOrders(ttvPhase,versionDate );
	}

	private List<NpiOrder> getAllExcludedOrders(TTVPhase ttvPhase, Date versionDate) {
		
		StringBuffer sql =  new StringBuffer("select o.pmsWaveId, o.BomNumber as mtm,")
		.append(" o.quantity, o.rsdDate, o.excludedOn, o.excludedBy, o.poItem, o.poNumber, o.shipDate, o.isShipped, o.ttvPhase, o.orderDate, o.region")
		.append(" from BI_NPIOrder o, (select max(excludedOn) as versiondate from BI_NPIOrder")
		.append(" where datediff(day, excludedOn, ?) >=0 ) d ")
		.append("where d.versiondate = o.excludedOn and o.ttvPhase = ?");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(NpiOrder.class));
		query.setParameter(0, versionDate);
		query.setParameter(1, ttvPhase.name());
		return query.list();
	}

	@Override
	public List<NpiOrder> getTTVExcludedOrderInWeek(Date targetDate,Date versionDate, TTVPhase ttvPhase) {
		return getExcludedOrderInWeek(targetDate,versionDate, ttvPhase);
	}

	private List<NpiOrder> getExcludedOrderInWeek(Date targetDate, Date versionDate, TTVPhase ttvPhase) {
		
		StringBuffer sql =  new StringBuffer("select o.pmsWaveId, o.BomNumber as mtm,")
		.append(" o.quantity, o.rsdDate, o.excludedOn, o.excludedBy, o.poItem, o.poNumber, o.shipDate, o.isShipped, o.ttvPhase, o.orderDate, o.region")
		.append(" from BI_NPIOrder o, (select max(excludedOn) as versiondate from BI_NPIOrder")
		.append(" where datediff(day, excludedOn, ?) >=0 ) d ")
		.append("where d.versiondate = o.ExcludedOn and o.ttvPhase = ?")
		.append(" and datediff(day, ?, o.orderDate) >=0  ")
		.append(" and datediff(day, ?, o.orderDate) <=0  ");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(NpiOrder.class));
		query.setParameter(0, versionDate);
		query.setParameter(1, ttvPhase.name());
		query.setParameter(2, targetDate);
		query.setParameter(3, CalendarUtil.getSundayDateByDate(targetDate));
		return query.list();
	}

	@Override
	public void updateExcludeOrder(List<NpiOrder> orders, Integer waveId, Date versionDate,TTVPhase ttvPhase) {
		/**
		 * æ²¡æœ‰å‹¾é€‰çš„exclude orderæ—¶ï¼Œä¸�éœ€è¦�æ‰§è¡Œ
		 */
		// delete
		StringBuilder sql = new StringBuilder("delete from BI_NPIOrder where pmsWaveId = :pmsWaveId and ttvPhase = :ttvPhase");
		SQLQuery q = getSession().createSQLQuery(sql.toString());
		q.setInteger("pmsWaveId", waveId);
		q.setString("ttvPhase", ttvPhase.name());
		q.executeUpdate();
		if(CollectionUtils.isNotEmpty(orders)){
			for(NpiOrder order : orders){
				getSession().save(order);
			}
		}
		// insert TODO
//		if (selectedNpiOrderIds != null && !selectedNpiOrderIds.isEmpty()) {
//			for (PoNumberAndPoItem po : selectedNpiOrderIds) {
//				NpiOrder npiOrder = new NpiOrder();
//				npiOrder.setExcludedBy(userName);
//				npiOrder.setExcludedOn(new Date());
//				npiOrder.setLastModifiedDate(new Date());
//				npiOrder.setPoNumber(po.getPoNumber());
//				npiOrder.setPoItem(po.getPoItem());
//				npiOrder.setPmsWaveId(pmsWaveId);
//				getSession().save(npiOrder);
//			}
//		}
		
		
		// Date currentDate = new Date();
		// if(!CollectionUtils.isEmpty(selectedNpiOrderIds)){
		//
		// final String hqlIsExclude =
		// "update NpiOrder n set n.isExcluded=:isExcluded, n.excludedOn=:excludedOnDate, "
		// + " n.lastModifiedDate=:lastModifiedDate, n.excludedBy=:excludedBy "
		// + " where n.npiOrderKey in(:ids)";
		// Query query = getSession().createQuery(hqlIsExclude);
		// query.setBoolean("isExcluded", true);
		// query.setDate("excludedOnDate", currentDate);
		// query.setDate("lastModifiedDate", currentDate);
		// query.setString("excludedBy", userName);
		// query.setParameterList("ids", selectedNpiOrderIds);
		// query.executeUpdate();
		// }
		//
		//
		// StringBuilder hqlNotExclude = new StringBuilder();
		// hqlNotExclude.append(" update NpiOrder n set n.isExcluded=:isExcluded, n.excludedOn=:excludedOnDate, ");
		// hqlNotExclude.append(" n.lastModifiedDate=:lastModifiedDate, n.excludedBy=:excludedBy ");
		// hqlNotExclude.append(" where n.pmsWaveId = :pmsWaveId ");
		//
		// if(!CollectionUtils.isEmpty(selectedNpiOrderIds)){
		// hqlNotExclude.append(" and  n.npiOrderKey not in (:list) ");
		// }
		//
		// Query query2 = getSession().createQuery(hqlNotExclude.toString());
		// query2.setBoolean("isExcluded", false);
		// query2.setDate("excludedOnDate", currentDate);
		// query2.setDate("lastModifiedDate", currentDate);
		// query2.setString("excludedBy", userName);
		// query2.setInteger("pmsWaveId", pmsWaveId);
		//
		// if(!CollectionUtils.isEmpty(selectedNpiOrderIds)){
		// query2.setParameterList("list", selectedNpiOrderIds);
		// }
		//
		// query2.executeUpdate();
	}

	@Override
	public List<NpiOrder> getNpiOrderByWaveId(int waveId) {
		// +
		// " where convert(varchar(10),dimOrder.poNumber)+convert(varchar(10),dimOrder.poItem) "
		// + " in ("+poNumberAndPoItemKeys+")";

		StringBuilder sql = new StringBuilder();
		sql.append(" from NpiOrder ");
		sql.append(" where pmsWaveId = :pmsWaveId ");
		sql.append(" and isCurrent <> 0 ");
		Query query = getSession().createQuery(sql.toString());
		query.setInteger("pmsWaveId", waveId);
		return query.list();
	}
	
	@Override
	public List<NpiOrder> getNpiOrderByWaveId(int waveId, Date versionDate,TTVPhase ttvPhase) {
		StringBuffer sql =  new StringBuffer("select o.pmsWaveId as pmsWaveId, o.BomNumber as mtm,")
		.append(" o.quantity, o.rsdDate, o.excludedOn, o.excludedBy, o.poItem, o.poNumber, o.shipDate, o.isShipped, o.ttvPhase, o.orderDate, o.region")
		.append(" from BI_NPIOrder o, (select max(excludedOn) as versiondate from BI_NPIOrder");
		if(versionDate != null){
			sql.append(" where datediff(day, excludedOn, :versionDate) >=0 ");
		}
		sql.append(" ) d ")
		.append("where d.versiondate = o.excludedOn  and o.pmsWaveId = :waveId and o.ttvPhase = :ttvPhase");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(NpiOrder.class));
		if(versionDate != null){
			query.setDate("versionDate", versionDate);
		}
		query.setInteger("waveId", waveId);
		query.setString("ttvPhase", ttvPhase.name());
		return query.list();
	}
	
	@Override
	public List<NpiOrder> getNegativeNpiOrderByWaveId(int waveId, Date versionDate,TTVPhase ttvPhase) {
		StringBuffer sql =  new StringBuffer("select o.pmsWaveId as pmsWaveId, o.BomNumber as mtm,")
		.append(" -o.quantity as quantity, o.rsdDate, o.excludedOn, o.excludedBy, o.poItem, o.poNumber, o.shipDate, o.isShipped, o.ttvPhase, o.orderDate, o.region")
		.append(" from BI_NPIOrder o, (select max(excludedOn) as versiondate from BI_NPIOrder");
		if(versionDate != null){
			sql.append(" where datediff(day, excludedOn, :versionDate) >=0 ");
		}
		sql.append(" ) d ")
		.append("where d.versiondate = o.excludedOn  and o.pmsWaveId = :waveId and o.ttvPhase = :ttvPhase");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(NpiOrder.class));
		if(versionDate != null){
			query.setDate("versionDate", versionDate);
		}
		query.setInteger("waveId", waveId);
		query.setString("ttvPhase", ttvPhase.name());
		return query.list();
	}

	@Override
	public List<NpiOrder> getAllExcludedOrdersByNpiOrderIds(List<Integer> npiOrderIds) {

		String hql = "from NpiOrder " + "where isExcluded <> 0 and isCurrent <> 0 and npiOrderKey in (:npiOrderIds) " + "order by rsdDate";

		Query query = getSession().createQuery(hql);
		query.setParameterList("npiOrderIds", npiOrderIds);

		return query.list();

	}

}
