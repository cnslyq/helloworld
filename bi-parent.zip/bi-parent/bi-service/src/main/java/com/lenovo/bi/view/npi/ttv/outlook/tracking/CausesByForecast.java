package com.lenovo.bi.view.npi.ttv.outlook.tracking;


public class CausesByForecast {

	private String odm;
	private String geo;
	private String region;
	private String mtm;
	private String mtmDesc;
	private String quantity;
	private String shortage;
	private String offset;
	private String upside;

	public String getOdm() {
		return odm;
	}

	public void setOdm(String odm) {
		this.odm = odm;
	}

	public String getGeo() {
		return geo;
	}

	public void setGeo(String geo) {
		this.geo = geo;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getMtm() {
		return mtm;
	}

	public void setMtm(String mtm) {
		this.mtm = mtm;
	}

	public String getMtmDesc() {
		return mtmDesc;
	}

	public void setMtmDesc(String mtmDesc) {
		this.mtmDesc = mtmDesc;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getShortage() {
		return shortage;
	}

	public void setShortage(String shortage) {
		this.shortage = shortage;
	}

	public String getOffset() {
		return offset;
	}

	public void setOffset(String offset) {
		this.offset = offset;
	}

	public String getUpside() {
		return upside;
	}

	public void setUpside(String upside) {
		this.upside = upside;
	}


}
