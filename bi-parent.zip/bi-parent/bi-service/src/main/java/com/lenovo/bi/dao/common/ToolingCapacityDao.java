package com.lenovo.bi.dao.common;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.ToolingCapacity;
import com.lenovo.bi.dto.ToolingCapacityDetail;

/**
 * 
 * 
 * @author henry_lian
 *
 */
public interface ToolingCapacityDao {

	public List<ToolingCapacity> getToolingCapacityInWeek(Date targetDate, Date versionDate);
	
	public List<ToolingCapacity> getToolingCapacityByWave(int pmsWaveId, Date targetDate, Date versionDate);
	
	public List<ToolingCapacity> getToolingCapacityByWave(int pmsWaveId, Date versionDate);
	
	public List<ToolingCapacityDetail> getDetailToolingCapacityByTargetDate(int pmsWaveId, Date targetDate, Date versionDate);
	
	public List<ToolingCapacityDetail> getToolingItems(String pmsWaveId, String versionDate, String startDate, String endDate);
}
