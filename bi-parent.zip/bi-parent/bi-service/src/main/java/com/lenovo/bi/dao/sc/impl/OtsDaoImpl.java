package com.lenovo.bi.dao.sc.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.OTSDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.dto.sc.OtsRemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.GeographyType;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;
import com.lenovo.common.model.PagerInformation;

@Repository
public class OtsDaoImpl extends HibernateBaseDaoImplDw implements OTSDao {
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchOtsOverViewChartData(SearchOtsForm form) {
		
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum,status.OTSStatus as scStatusName")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" left join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}else {
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    			.append(" and ots.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for SC overview:ots
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		
		sBuffer.append(" group by status.OTSStatus having status.OTSStatus <> '' order by status.OTSStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchScOtsOverViewChartData(SearchOtsForm form) {
		
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum,status.OTSStatus as scStatusName")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" left join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}else {
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    			.append(" and ots.Month = ").append(form.getMonth());
	    }
		
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		
		sBuffer.append(" group by status.OTSStatus having status.OTSStatus <> '' order by status.OTSStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<OtsRemarkChartData> fetchDimensionRemarkDataList(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append("select SUB.RegionKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.OTSStatus='Make' then SUB.OrderQuantity else 0 end) as make,")
					.append("sum(case when SUB.OTSStatus='Fail' then SUB.OrderQuantity else 0 end) as fail,")
					.append("sum(case when SUB.OTSStatus='To-be Make' then SUB.OrderQuantity else 0 end) as toBeMake,")
					.append("sum(case when SUB.OTSStatus='To-be Fail' then SUB.OrderQuantity else 0 end) as toBeFail,")
					.append("sum(SUB.OrderQuantity) as total")
					.append(" from (select ots.*,status.OTSStatus,geography.GeographyName as dimensionName ")
			   		.append(" from FactMonthlySummaryofOTS ots ")
			   		.append(" left join  DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on ots.regionkey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join DimGeography geography on geography.GeographyKey = ots.RegionKey");
			}
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where ots.Year = ").append(form.getYear())
	    			   .append(" and ots.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			
			sBuffer.append(" and ots.OTSStatusKey in (1,2,3,4)");
			
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				sBuffer.append(" and geography.geographyname = 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				sBuffer.append(" and geography.geographyname <> 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:ODM or Product
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			}
			
			sBuffer.append(")SUB group by SUB.RegionKey,SUB.dimensionName order by SUB.RegionKey");
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append("select SUB.ODMKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.OTSStatus='Make' then SUB.OrderQuantity else 0 end) as make,")
					.append("sum(case when SUB.OTSStatus='Fail' then SUB.OrderQuantity else 0 end) as fail,")
					.append("sum(case when SUB.OTSStatus='To-be Make' then SUB.OrderQuantity else 0 end) as toBeMake,")
					.append("sum(case when SUB.OTSStatus='To-be Fail' then SUB.OrderQuantity else 0 end) as toBeFail,")
					.append("sum(SUB.OrderQuantity) as total")
					.append(" from (select ots.*,status.OTSStatus,odm.ODMEnglishName as dimensionName ")
			   		.append(" from FactMonthlySummaryofOTS ots ")
			   		.append(" left join  DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
			   		.append(" left join DimODM odm on ots.ODMKey = odm.ODMKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on ots.regionkey = geoRegion.regionKey");
				
			}
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where ots.Year = ").append(form.getYear())
	    			   .append(" and ots.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			sBuffer.append(" and ots.OTSStatusKey in (1,2,3,4)");
			
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:Region or Product
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			} 
			
			sBuffer.append(")SUB group by SUB.ODMKey,SUB.dimensionName order by SUB.ODMKey");
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append("select SUB.ProductKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.OTSStatus='Make' then SUB.OrderQuantity else 0 end) as make,")
					.append("sum(case when SUB.OTSStatus='Fail' then SUB.OrderQuantity else 0 end) as fail,")
					.append("sum(case when SUB.OTSStatus='To-be Make' then SUB.OrderQuantity else 0 end) as toBeMake,")
					.append("sum(case when SUB.OTSStatus='To-be Fail' then SUB.OrderQuantity else 0 end) as toBeFail,")
					.append("sum(SUB.OrderQuantity) as total")
					.append(" from (select ots.*,status.OTSStatus,product.ProductEnglishName as dimensionName ")
			   		.append(" from FactMonthlySummaryofOTS ots ")
			   		.append(" join  DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
			   		.append(" join DimProduct product on ots.ProductKey = product.ProductKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on ots.regionkey = geoRegion.regionKey");
				
			}
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where ots.Year = ").append(form.getYear())
	    			   .append(" and ots.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			sBuffer.append(" and ots.OTSStatusKey in (1,2,3,4)");
			
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:Region or Odm
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			} 
			
			sBuffer.append(")SUB group by SUB.ProductKey,SUB.dimensionName order by SUB.ProductKey");
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			//sBuffer.append("select SUB.DetractorKey as dimensionKey,SUB.dimensionName as dimensionName,")
			sBuffer.append("select 0 as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.OTSStatus='Make' then SUB.OrderQuantity else 0 end) as make,")
					.append("sum(case when SUB.OTSStatus='Fail' then SUB.OrderQuantity else 0 end) as fail,")
					.append("sum(case when SUB.OTSStatus='To-be Make' then SUB.OrderQuantity else 0 end) as toBeMake,")
					.append("sum(case when SUB.OTSStatus='To-be Fail' then SUB.OrderQuantity else 0 end) as toBeFail,")
					.append("sum(SUB.OrderQuantity) as total")
					.append(" from (select ots.*,status.OTSStatus,isNull(detractor.Level1,'UNKNOWN') as dimensionName ")
			   		.append(" from FactMonthlySummaryofOTS ots ")
			   		.append(" left join  DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
			   		.append(" left join DimDetractor detractor on ots.DetractorKey = detractor.DetractorKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on ots.regionkey = geoRegion.regionKey");
				
			} 
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where ots.Year = ").append(form.getYear())
	    			   .append(" and ots.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			sBuffer.append(" and ots.OTSStatusKey in (1,2,3,4)");
			//sBuffer.append(" and ots.DetractorKey is not null");
			
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:Region or Odm or Porduct
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			}
			
			//group by ots.RegionKey, ots.OTSStatusKey having ots.RegionKey <> '' order by ots.RegionKey,ots.OTSStatusKey
			sBuffer.append(" )SUB group by SUB.dimensionName");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
								.addScalar("dimensionKey", IntegerType.INSTANCE)
								.addScalar("dimensionName", StringType.INSTANCE)
								.addScalar("make", IntegerType.INSTANCE)
								.addScalar("fail", IntegerType.INSTANCE)
								.addScalar("toBeMake", IntegerType.INSTANCE)
								.addScalar("toBeFail", IntegerType.INSTANCE)
								.addScalar("total", IntegerType.INSTANCE)
								.setResultTransformer(Transformers.aliasToBean(OtsRemarkChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchGeoDimensions(SearchOtsForm form) {
		PagerInformation pagerInfo = form.getPagerInfo();
		StringBuffer sBuffer = new StringBuffer();
		
		//for Geo overview chart
		if("Region".equals(form.getDashboardType())) {
		    sBuffer.append("select geoRegion.geoKey as objkey,geoRegion.geoName as objname,'Geo' as type")
		    	   .append(" from FactMonthlySummaryofOTS ots ")
		    	   .append(" left join ")
		    	   .append("(")
		    	   .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
		    	   .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
		    	   .append(")")
		    	   .append(" as geoRegion on ots.regionkey = geoRegion.regionKey");
		    	   
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    		.append(" and ots.Month = ").append(form.getMonth());
			
	    	if(form.getOrderTypeId() == 1) {
	    		sBuffer.append(" and geoRegion.geoName = 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				sBuffer.append(" and geoRegion.geoName <> 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			sBuffer.append(" group by geoRegion.geoKey,geoRegion.geoName having geoRegion.geoKey <> '' order by count(ots.OTSStatusKey) desc");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchDimensions(SearchOtsForm form) {
		PagerInformation pagerInfo = form.getPagerInfo();
		StringBuffer sBuffer = new StringBuffer();
		
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
		    sBuffer.append("select ots.RegionKey as objKey,geography.GeographyName as objName,'Region' as type")
		    .append(" from FactMonthlySummaryofOTS ots ")
		    .append(" left join DimGeography geography on ots.RegionKey = geography.GeographyKey");
		
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    		.append(" and ots.Month = ").append(form.getMonth());
	    	
	    	if(form.getOrderTypeId() == 1) {
	    		sBuffer.append(" and geography.geographyname = 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				sBuffer.append(" and geography.geographyname <> 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			//show geo or region overview 
			if(!form.isShowGeoOverview()) 
				sBuffer.append(" and geography.GeographyType = 'Region'");
			else
				sBuffer.append(" and geography.GeographyType = 'Geo'");
			
			sBuffer.append(" group by ots.RegionKey,geography.GeographyName having ots.RegionKey <> '' order by count(ots.OTSStatusKey) desc");
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
		    sBuffer.append("select ots.ODMKey as objKey,odm.ODMEnglishName as objName,'Odm' as type")
		    .append(" from FactMonthlySummaryofOTS ots ")
		    .append(" left join DimODM odm on ots.ODMKey = odm.ODMKey");
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    		.append(" and ots.Month = ").append(form.getMonth());
			
	    	if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			sBuffer.append(" group by ots.ODMKey,odm.ODMEnglishName having ots.ODMKey <> '' order by count(ots.OTSStatusKey) desc");
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
		    sBuffer.append("select ots.ProductKey as objKey,product.ProductEnglishName as objName,'Product' as type")
		    .append(" from FactMonthlySummaryofOTS ots ")
		    .append(" left join DimProduct product on ots.ProductKey = product.ProductKey");
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    		.append(" and ots.Month = ").append(form.getMonth());
			
	    	if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			sBuffer.append(" group by ots.ProductKey,product.ProductEnglishName having ots.ProductKey <> '' order by count(ots.OTSStatusKey) desc");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchOtsRemarkChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum,status.OTSStatus as scStatusName")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" left join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    sBuffer.append(" where ots.Year*100 + ots.Month between ")
		   		   .append(form.getStartDate())
		   		   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
		    	sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where ots.Year = ").append(form.getYear())
		    		.append(" and ots.Month = ").append(form.getMonth());
			}
		}
		
		sBuffer.append(" and ots.OTSStatusKey in (2,4)");
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())) {
				sBuffer.append(" and ots.DetractorKey is null");
			}
			else {
				sBuffer.append(" and ots.DetractorKey in (")
						.append(" select detractorKey from dimDetractor where level1 = '")
						.append(form.getSubDimension()).append("')");
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		sBuffer.append(" group by status.OTSStatus having status.OTSStatus <> '' order by status.OTSStatus");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchOtsGeoRemarkChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum,status.OTSStatus as scStatusName")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" left join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		
		if(form.getDashboardTypeKey() != -1) {
			if("Region".equals(form.getDashboardType())) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on ots.regionkey = geoRegion.regionKey");
			}
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    sBuffer.append(" where ots.Year*100 + ots.Month between ")
		   		   .append(form.getStartDate())
		   		   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
		    	sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where ots.Year = ").append(form.getYear())
		    		.append(" and ots.Month = ").append(form.getMonth());
			}
		}
		
		sBuffer.append(" and ots.OTSStatusKey in (2,4)");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			sBuffer.append(" and ots.DetractorKey in (")
			.append(" select detractorKey from dimDetractor where level1 = '")
			.append(form.getSubDimension()).append("')");
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		if(form.getDashboardTypeKey() != -1)
			sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
		sBuffer.append(" group by status.OTSStatus having status.OTSStatus <> '' order by status.OTSStatus");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}

	public Integer fetchTotalFailValue(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum")
			   .append(" from FactMonthlySummaryofOTS ots");
			   //.append(" left join ")
			   //.append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    sBuffer.append(" where ots.Year*100 + ots.Month between ")
		   		   .append(form.getStartDate())
		   		   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
		    	sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where ots.Year = ").append(form.getYear())
		    		.append(" and ots.Month = ").append(form.getMonth());
			}
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		sBuffer.append(" and ots.OTSStatusKey in (2,4)");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			//sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			//sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			//sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			//sBuffer.append(" and ots.DetractorKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//sBuffer.append(" group by status.OTSStatus having status.OTSStatus != '' order by status.OTSStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	public Integer fetchTotalGeoFailValue(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum")
			   .append(" from FactMonthlySummaryofOTS ots");
			   //.append(" left join ")
			   //.append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		
		if(form.getDashboardTypeKey() != -1) {
			if("Region".equals(form.getDashboardType())) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on ots.regionkey = geoRegion.regionKey");
			}
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    sBuffer.append(" where ots.Year*100 + ots.Month between ")
		   		   .append(form.getStartDate())
		   		   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
		    	sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where ots.Year = ").append(form.getYear())
		    		.append(" and ots.Month = ").append(form.getMonth());
			}
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		sBuffer.append(" and ots.OTSStatusKey in (2,4)");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			//sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			//sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			//sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			//sBuffer.append(" and ots.DetractorKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
		//sBuffer.append(" group by status.OTSStatus having status.OTSStatus != '' order by status.OTSStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchTotalDimensionOtsData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum")
			   .append(" from FactMonthlySummaryofOTS ots");
			   //.append(" left join ")
			   //.append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    sBuffer.append(" where ots.Year*100 + ots.Month between ")
		   		   .append(form.getStartDate())
		   		   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
		    	sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where ots.Year = ").append(form.getYear())
		    		.append(" and ots.Month = ").append(form.getMonth());
			}
		}
		
		sBuffer.append(" and ots.OTSStatusKey in (2,3,5,6)");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			//sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			//sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			//sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			//sBuffer.append(" and ots.DetractorKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//sBuffer.append(" group by status.OTSStatus having status.OTSStatus != '' order by status.OTSStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchTotalGeoDimensionOtsData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum")
			   .append(" from FactMonthlySummaryofOTS ots");
			   //.append(" left join ")
			   //.append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		
		if(form.getDashboardTypeKey() != -1) {
			if("Region".equals(form.getDashboardType())) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on ots.regionkey = geoRegion.regionKey");
			}
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		    sBuffer.append(" where ots.Year*100 + ots.Month between ")
		   		   .append(form.getStartDate())
		   		   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
		    	sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
				   .append(form.getQuarterFrom()).append("'")
				   .append(" and '").append(form.getQuarterTo()).append("'");
			}
			//month
			else {
		    	sBuffer.append(" where ots.Year = ").append(form.getYear())
		    		.append(" and ots.Month = ").append(form.getMonth());
			}
		}
		
		sBuffer.append(" and ots.OTSStatusKey in (2,3,5,6)");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			//sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			//sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			//sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			//sBuffer.append(" and ots.DetractorKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
		//sBuffer.append(" group by status.OTSStatus having status.OTSStatus != '' order by status.OTSStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchOtsDashboardOverViewChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum,status.OTSStatus as scStatusName")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" left join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
			   .append(" where ots.Year = ").append(form.getYear())
			   .append(" and ots.Month = ").append(form.getMonth());
		
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		sBuffer.append(" group by status.OTSStatus having status.OTSStatus <> '' order by status.OTSStatus");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchOtsGeoDashboardOverViewChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum,status.OTSStatus as scStatusName")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" left join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
			   .append(" left join ")
		       .append("(")
		       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
		       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
		       .append(")")
		       .append(" as geoRegion on ots.regionkey = geoRegion.regionKey")
			   .append(" where ots.Year = ").append(form.getYear())
			   .append(" and ots.Month = ").append(form.getMonth())
			   .append(" and geoRegion.geoKey = ").append(form.getGeoKey());
		
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
			//sBuffer.append(" and ots.RegionKey = ").append(form.getGeoKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		sBuffer.append(" group by status.OTSStatus having status.OTSStatus <> '' order by status.OTSStatus");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchOtsCrossMonthOverviewChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum,status.OTSStatus as scStatusName")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" left join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}else {
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    		.append(" and ots.Month = ").append(form.getMonth());
	    }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		sBuffer.append(" group by status.OTSStatus having status.OTSStatus <> '' order by status.OTSStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> getOverviewOverall(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum,status.OTSStatus as scStatusName")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" left join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
	    form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
	    form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
	    sBuffer.append(" where ots.Year*100 + ots.Month between ")
	   		   .append(form.getStartDate())
	   		   .append(" and ").append(form.getEndDate());
			  
	    if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
	    
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//crossmonth overview chart:Region or Odm or Porduct
		/*if(form.getCrossMonthTypeKey() != -1) {
			if("Region".equals(form.getCrossMonthType()))
				sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
			else if("Odm".equals(form.getCrossMonthType()))
				sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
			else if("Product".equals(form.getCrossMonthType()))
				sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
		}*/
		
		//for Region overview chart
		if("Region".equals(form.getCrossMonthType())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getCrossMonthTypeKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getCrossMonthType())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getCrossMonthTypeKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getCrossMonthType())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getCrossMonthTypeKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}		
		
		sBuffer.append(" group by status.OTSStatus having status.OTSStatus <> '' order by status.OTSStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchOtsOverViewOrderDetailData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  ots.OrderKey as orderKey ")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" inner join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}else {
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    			.append(" and ots.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchOtsOverViewRemarkOrderDetailData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select ots.OrderKey as orderKey ")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" inner join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey ");
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimGeography geo on ots.RegionKey = geo.GeographyKey and geo.GeographyType = '"
					+ GeographyType.Region.name()
					+ "' and geo.GeographyName = '"
					+ form.getSubDimension().toUpperCase()+ "' ");
		}else if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimODM odm on ots.ODMKey = odm.ODMKey and odm.ODMEnglishName = '"
					+ form.getSubDimension().toUpperCase() + "' ");
		}else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimProduct pro on ots.ProductKey = pro.ProductKey and pro.ProductEnglishName = '"
					+ form.getSubDimension().toUpperCase() + "' ");
		}else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append("INNER JOIN DimDetractor detractor on ots.DetractorKey = detractor.DetractorKey and upper(detractor.Level1) = '"
					+ form.getSubDimension().toUpperCase() + "' ");
		}
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}else {
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    			.append(" and ots.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchOtsDashboardOrderDetailData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  ots.OrderKey as orderKey ")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" inner join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
			   .append(" where ots.Year = ").append(form.getYear())
			   .append(" and ots.Month = ").append(form.getMonth());
		
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchOtsCrossMonthOrderDetailData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  ots.OrderKey as orderKey ")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" inner join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}else {
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    		.append(" and ots.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		
		return query.list();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchOtsOrderKeysByDims(SearchOtsForm form) {
		StringBuffer sb = new StringBuffer();
		sb.append("select ots.OrderKey from FactMonthlySummaryofOTS ots");
		if(StringUtils.isNotBlank(form.getLevel1Detractor()) || StringUtils.isNotBlank(form.getLevel2Detractor())){
			sb.append(" inner join dimdetractor d on d.detractorKey = ots.detractorKey");
		}
		sb.append(" where ots.year*100 + ots.month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and  ots.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and  ots.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and  ots.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sb.append(" and  ots.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor())){
			sb.append(" and upper(d.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor())){
			sb.append(" and upper(d.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PieDivider> getDetractorMainDivider(SearchOtsForm form) {
		StringBuffer sb = new StringBuffer();
		if(form.getLevel() == 2){
			sb.append("select ISNULL(upper(rtrim(ltrim(d.Level2))),'UNKNOWN') as level2Name,count(ots.OTSStatusKey) as level2Num ");
		}else{
			sb.append("select ISNULL(upper(rtrim(ltrim(d.Level1))),'UNKNOWN') as level1Name,count(ots.OTSStatusKey) as level1Num ");
		}
		sb.append(" from FactMonthlySummaryofOts ots")
			.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
			.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
			;
		sb.append(" left join dimdetractor d on d.detractorkey = ots.detractorkey ");
		sb.append(" where ots.year*100 + ots.month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sb.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sb.append(form.getPoNumberItemOrderNo());
			sb.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sb.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sb.append(" and  ots.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and  ots.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and  ots.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sb.append(" and  ots.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor())){
			sb.append(" and upper(d.Level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(form.getLevel() == 2){
			sb.append(" group by d.Level2 ");
		}else{
			sb.append(" group by d.Level1 ");
		}
		Query query;
		if(form.getLevel() == 2){
			query = getSession().createSQLQuery(sb.toString())
					.addScalar("level2Name", StringType.INSTANCE)
					.addScalar("level2Num", IntegerType.INSTANCE)
					.setResultTransformer(Transformers.aliasToBean(PieDivider.class));
		}else{
			query = getSession().createSQLQuery(sb.toString())
					.addScalar("level1Name", StringType.INSTANCE)
					.addScalar("level1Num", IntegerType.INSTANCE)
					.setResultTransformer(Transformers.aliasToBean(PieDivider.class));
		}
		return query.list();
	}
	
	@Override
	public int getOverviewOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum")
		   .append(" from FactMonthlySummaryofOTS ots")
		   .append(" left join ")
		   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where ots.Year = ").append(form.getYear())
		 			.append(" and ots.Month = ").append(form.getMonth());
		 }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	public int getCrossMonthOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum")
		   		.append(" from FactMonthlySummaryofOTS ots")
		   		.append(" left join ")
		   		.append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
				.append(" left join DimDetractor dimDetractor on ots.DetractorKey =  dimDetractor.DetractorKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where ots.Year = ").append(form.getYear())
		 			.append(" and ots.Month = ").append(form.getMonth());
		 }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	public int getDashboardOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum")
		   		.append(" from FactMonthlySummaryofOTS ots")
		   		.append(" left join ")
		   		.append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
		   		.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
		   		.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimDetractor dimDetractor on ots.DetractorKey =  dimDetractor.DetractorKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where ots.Year = ").append(form.getYear())
		 			.append(" and ots.Month = ").append(form.getMonth());
		 }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey = ").append(form.getRemarkSubDimensionKey());
			else 
				sBuffer.append(" and ots.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getOverviewOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ots.POItem as poItem,")
				.append("ots.PONumber as poNumber,")
				.append("ots.POItem as itemNo,")
				.append("ots.OrderQuantity as qty,")
				.append("ots.OrderDate as orderDate,")
				.append("ots.RSDDate as rsd,")
				.append("ots.FPSDDate as fpsd,")
				.append("ots.ShipDate as shippedDate,")
				.append("ots.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ots.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofOTS ots")
				.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
				.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ots.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where ots.Year = ").append(form.getYear())
		 			.append(" and ots.Month = ").append(form.getMonth());
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
		};
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(" , poItem ").append(form.getReversalSortType());
			sBuffer.append(" , qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getCrossMonthOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ots.POItem as poItem,")
				.append("ots.PONumber as poNumber,")
				.append("ots.POItem as itemNo,")
				.append("ots.OrderQuantity as qty,")
				.append("ots.OrderDate as orderDate,")
				.append("ots.RSDDate as rsd,")
				.append("ots.FPSDDate as fpsd,")
				.append("ots.ShipDate as shippedDate,")
				.append("ots.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ots.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofOTS ots")
				.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
				.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ots.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where ots.Year = ").append(form.getYear())
		 			.append(" and ots.Month = ").append(form.getMonth());
		 }
		
		if(("region".equalsIgnoreCase(form.getOverViewDimension()) && form.getOverViewSubDimensionKey() != -1)){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyKey = '"+ form.getOverViewSubDimensionKey()+ "' ");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(" , poItem ").append(form.getReversalSortType());
			sBuffer.append(" , qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getDashboardOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ots.POItem as poItem,")
				.append("ots.PONumber as poNumber,")
				.append("ots.POItem as itemNo,")
				.append("ots.OrderQuantity as qty,")
				.append("ots.OrderDate as orderDate,")
				.append("ots.RSDDate as rsd,")
				.append("ots.FPSDDate as fpsd,")
				.append("ots.ShipDate as shippedDate,")
				.append("ots.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ots.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofOTS ots")
				.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
				.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ots.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where ots.Year = ").append(form.getYear())
		 			.append(" and ots.Month = ").append(form.getMonth());
		 }
		
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
			
			/*if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}*/
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey = ").append(form.getRemarkSubDimensionKey());
			else 
				sBuffer.append(" and ots.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(" , poItem ").append(form.getReversalSortType());
			sBuffer.append(" , qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	public int getRemarkOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum ")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" inner join ")
			   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey ");
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimGeography geo on ots.RegionKey = geo.GeographyKey and geo.GeographyType = '"
					+ GeographyType.Region.name()
					+ "' ");
		}else if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimODM odm on ots.ODMKey = odm.ODMKey ");
		}else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimProduct pro on ots.ProductKey = pro.ProductKey ");
		}else if("Detractor".equalsIgnoreCase(form.getDimension())	&& !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
				sBuffer.append(" INNER JOIN DimDetractor detractor on ots.DetractorKey = detractor.DetractorKey ");
			}
			else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append("INNER JOIN DimDetractor detractor on ots.DetractorKey = detractor.DetractorKey ");
			}
		}
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where ots.Year = ").append(form.getYear())
    			   .append(" and ots.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		if(form.isShowAllRemarkOrder()){
			sBuffer.append(" and status.OTSStatusKey in(").append(form.getScStatus()).append(")");
		}
		else{
			sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		}
		
		if("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and geo.GeographyName in(" +  form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append(" and geo.GeographyName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
			
			
		}else if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and odm.ODMEnglishName in(" +  form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append(" and odm.ODMEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
			
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and pro.ProductEnglishName in(" +  form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append(" and pro.ProductEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
			
		}else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
				sBuffer.append(" and upper(detractor.Level1)  in(" +  form.getSubDimension() + ") ");
			}
			else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append(" and upper(detractor.Level1) = '" + form.getSubDimension().toUpperCase() + "' ");
			}
			else if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				//for Region overview chart
				if("Region".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
						sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());				
				}
				//for Odm overview chart
				else if("Odm".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
						sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());			
				}
				//for Product overview chart
				else if("Product".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
						sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());			
				}
				
				sBuffer.append(" and ots.DetractorKey is null");
			 }
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getRemarkOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		if(form.isShowAllRemarkOrder()){
			sBuffer.append("(select top ").append(form.getRowCount() + form.getOrderNumber()).append(" * from ");
		}else{
			sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		}
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ots.POItem as poItem,")
				.append("ots.PONumber as poNumber,")
				.append("ots.POItem as itemNo,")
				.append("ots.OrderQuantity as qty,")
				.append("ots.OrderDate as orderDate,")
				.append("ots.RSDDate as rsd,")
				.append("ots.FPSDDate as fpsd,")
				.append("ots.ShipDate as shippedDate,")
				.append("ots.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ots.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofOTS ots")
				.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
				.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ots.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
		
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where ots.Year = ").append(form.getYear())
    			   .append(" and ots.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "'");
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and region.GeographyName in ("+ form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append(" and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
			}
			
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if(form.isShowAllRemarkOrder()){
			sBuffer.append(" and status.OTSStatusKey in(").append(form.getScStatus()).append(")");
		}
		else{
			sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		}
		
		if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and dimODM.ODMEnglishName in(" +  form.getSubDimension() + ")");
			}
			else{
				sBuffer.append(" and dimODM.ODMEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and dimProduct.ProductEnglishName in(" +  form.getSubDimension() + ")");
			}
			else{
				sBuffer.append(" and dimProduct.ProductEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
				sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
				
				sBuffer.append(" union all ");
				sBuffer.append("select  top ").append(form.getOrderNumber());
				sBuffer.append(" dimODM.ODMEnglishName as odm,")
						.append("geo.GeographyName as geo,")
						.append("region.GeographyName as region,")
						.append("country.GeographyName as country,")
						.append("dimProduct.ProductEnglishName as product,")
						.append("mtm.BOMNumberAlternateKey as pn,")
						.append("mtm.MTMEnglishDescription as itemDesc,")
						.append("ots.POItem as poItem,")
						.append("ots.PONumber as poNumber,")
						.append("ots.POItem as itemNo,")
						.append("ots.OrderQuantity as qty,")
						.append("ots.OrderDate as orderDate,")
						.append("ots.RSDDate as rsd,")
						.append("ots.FPSDDate as fpsd,")
						.append("ots.ShipDate as shippedDate,")
						.append("ots.IsShipped as shipped,")
						.append("'' as level1,")
						.append("'' as level2 ,")
						.append("ots.LateReason2 as level3 ")
						.append(" from FactMonthlySummaryofOTS ots")
						.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
						.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
						.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
						.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
						.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
						.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
						.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
				
				
				if(form.isShowQuarterOverview()){
					form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
					form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
					sBuffer.append(" where ots.Year*100 + ots.Month between ")
					   .append(form.getQuarterFrom())
					   .append(" and ").append(form.getQuarterTo());
				}
				else {
				 	sBuffer.append(" where ots.Year = ").append(form.getYear())
				 			.append(" and ots.Month = ").append(form.getMonth());
				 }
				
				if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
					sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
					sBuffer.append(form.getPoNumberItemOrderNo());
					sBuffer.append(")");
				}
				
				if(form.getOrderTypeId() == 1) {
					if(form.getOrderSubTypeId() != -1) {
						sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
					}
					else {
						sBuffer.append(" and ots.OTSTypeKey in (1,2)");
					}
				}
				
				if(form.getOrderTypeId() == 2) {
					if(form.getOrderSubTypeId() != -1) {
						sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
					}
					else {
						sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
					}
				}
				
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and status.OTSStatusKey in(").append(form.getScStatus()).append(")");
				}
				else{
					sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
				}
				sBuffer.append(" and ots.DetractorKey is null");
			}
			else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getSubDimension().toUpperCase() + "' ");
			}else if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append(" and ots.DetractorKey is null");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", orderNo ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(" , poItem ").append(form.getReversalSortType());
			sBuffer.append(" , qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

	@Override
	public Integer fetchUnshippedBacklog(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OrderNo) as orderNum")
			   .append(" from FactMonthlySummaryofOTS ots");
		
		form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
		form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		sBuffer.append(" where datediff(second,ots.RSDDate,getdate()) < 0");
		sBuffer.append(" and ots.IsShipped = '0'");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchCurrentUnshippedOrderItems(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OrderNo) as orderNum")
			   .append(" from FactMonthlySummaryofOTS ots");
		
		form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
		form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		sBuffer.append(" where datediff(second,ots.RSDDate,getdate()) = 0");
		sBuffer.append(" and ots.IsShipped = '0'");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchFutureOrderItems(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OrderNo) as orderNum")
			   .append(" from FactMonthlySummaryofOTS ots");
		
		form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
		form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		sBuffer.append(" where datediff(second,ots.RSDDate,getdate()) > 0");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and ots.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and ots.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and ots.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public int getDetractorOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum ")
			   .append(" from FactMonthlySummaryofOTS ots")
			   .append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
			   .append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
			   .append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey");
		
		if(!"UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())) {
			if(StringUtils.isNotBlank(form.getLevel1Detractor()) || StringUtils.isNotBlank(form.getLevel2Detractor())){
				sBuffer.append(" inner join dimdetractor d on d.detractorKey = ots.detractorKey");
			}
		}
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}else {
	    	sBuffer.append(" where ots.Year = ").append(form.getYear())
	    			.append(" and ots.Month = ").append(form.getMonth());
	    }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sBuffer.append(" and  ots.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sBuffer.append(" and  ots.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and  ots.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sBuffer.append(" and  ots.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		
		if(StringUtils.isNotBlank(form.getLevel1Detractor())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())) 
				sBuffer.append(" and ots.DetractorKey is null");
			else
				sBuffer.append(" and upper(d.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())) 
				sBuffer.append(" and ots.DetractorKey is null");
			else
				sBuffer.append(" and upper(d.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		
		sBuffer.append(" and status.OTSStatus in ('Fail','To-be Fail')");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer) query.uniqueResult();
	}

	@Override
	public List<TtvGridDetractorCodeView> getDetractorOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ots.POItem as poItem,")
				.append("ots.PONumber as poNumber,")
				.append("ots.POItem as itemNo,")
				.append("ots.OrderQuantity as qty,")
				.append("ots.OrderDate as orderDate,")
				.append("ots.RSDDate as rsd,")
				.append("ots.FPSDDate as fpsd,")
				.append("ots.ShipDate as shippedDate,")
				.append("ots.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ots.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofOTS ots")
				.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
				.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ots.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where ots.Year = ").append(form.getYear())
		 			.append(" and ots.Month = ").append(form.getMonth());
		 }
		
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sBuffer.append(" and  ots.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sBuffer.append(" and  ots.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and  ots.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sBuffer.append(" and  ots.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())){
			sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel2Detractor())){
			sBuffer.append(" and upper(dimDetractor.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		
		if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase() + "' ");
		}
		else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and dimProduct.ProductEnglishName = '"+ form.getSubDimension().toUpperCase() + "' ");
		}
		else if("Detractor".equalsIgnoreCase(form.getDimension())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor()) || "UNKNOWN".equalsIgnoreCase(form.getSubDimension())) 
				sBuffer.append(" and ots.DetractorKey is null");
			else
				sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getLevel1Detractor().toUpperCase() + "' ");
		}
		
		sBuffer.append(" and status.OTSStatus in ('Fail','To-be Fail')");
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(" , poItem ").append(form.getReversalSortType());
			sBuffer.append(" , qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	public List<TtvGridDetractorCodeView> getAllOrderDetail(
			SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ots.POItem as poItem,")
				.append("ots.PONumber as poNumber,")
				.append("ots.POItem as itemNo,")
				.append("ots.OrderQuantity as qty,")
				.append("ots.OrderDate as orderDate,")
				.append("ots.RSDDate as rsd,")
				.append("ots.FPSDDate as fpsd,")
				.append("ots.ShipDate as shippedDate,")
				.append("ots.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ots.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofOTS ots")
				.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
				.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ots.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
		
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where ots.Year = ").append(form.getYear())
    			   .append(" and ots.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if(form.isShowAllRemarkOrder()){
			sBuffer.append(" and status.OTSStatusKey in(").append(form.getScStatus()).append(")");
		}
		else{
			sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		}
		if(form.getChartType().equals("remark")){
			if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
				sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "'");
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and region.GeographyName in ("+ form.getSubDimension() + ") ");
				}
				else{
					sBuffer.append(" and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
				}
			}else if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and dimODM.ODMEnglishName in(" +  form.getSubDimension() + ")");
				}
				else{
					sBuffer.append(" and dimODM.ODMEnglishName = '"
							+ form.getSubDimension().toUpperCase()+ "' ");
				}
			}else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and dimProduct.ProductEnglishName in(" +  form.getSubDimension() + ")");
				}
				else{
					sBuffer.append(" and dimProduct.ProductEnglishName = '"
							+ form.getSubDimension().toUpperCase()+ "' ");
				}
			}else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
				if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
					sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
					
					if(form.getOrderNumber() > 0){
						sBuffer.append(" union all ");
						sBuffer.append("select  top ").append(form.getOrderNumber());
						sBuffer.append(" dimODM.ODMEnglishName as odm,")
								.append("geo.GeographyName as geo,")
								.append("region.GeographyName as region,")
								.append("country.GeographyName as country,")
								.append("dimProduct.ProductEnglishName as product,")
								.append("mtm.BOMNumberAlternateKey as pn,")
								.append("mtm.MTMEnglishDescription as itemDesc,")
								.append("ots.POItem as poItem,")
								.append("ots.PONumber as poNumber,")
								.append("ots.POItem as itemNo,")
								.append("ots.OrderQuantity as qty,")
								.append("ots.OrderDate as orderDate,")
								.append("ots.RSDDate as rsd,")
								.append("ots.FPSDDate as fpsd,")
								.append("ots.ShipDate as shippedDate,")
								.append("ots.IsShipped as shipped,")
								.append("'' as level1,")
								.append("'' as level2 ,")
								.append("ots.LateReason2 as level3 ")
								.append(" from FactMonthlySummaryofOTS ots")
								.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
								.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
								.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
								.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
								.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
								.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
								.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
						
						
						if(form.isShowQuarterOverview()){
							form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
							form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
							sBuffer.append(" where ots.Year*100 + ots.Month between ")
							   .append(form.getQuarterFrom())
							   .append(" and ").append(form.getQuarterTo());
						}
						else {
						 	sBuffer.append(" where ots.Year = ").append(form.getYear())
						 			.append(" and ots.Month = ").append(form.getMonth());
						 }
						
						if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
							sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
							sBuffer.append(form.getPoNumberItemOrderNo());
							sBuffer.append(")");
						}
						
						if(form.getOrderTypeId() == 1) {
							if(form.getOrderSubTypeId() != -1) {
								sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
							}
							else {
								sBuffer.append(" and ots.OTSTypeKey in (1,2)");
							}
						}
						
						if(form.getOrderTypeId() == 2) {
							if(form.getOrderSubTypeId() != -1) {
								sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
							}
							else {
								sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
							}
						}
						
						if(form.isShowAllRemarkOrder()){
							sBuffer.append(" and status.OTSStatusKey in(").append(form.getScStatus()).append(")");
						}
						else{
							sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
						}
						sBuffer.append(" and ots.DetractorKey is null");
					}
				}
				else{
					if("UNKNOWN".equalsIgnoreCase(form.getSubDimension()))
						sBuffer.append(" and ots.DetractorKey is null ");
					else
						sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getSubDimension().toUpperCase() + "' ");
				}
			}
			
		}else if(ChartTypeEnum.Dashboard.getTypeName().equals(form.getChartType())  
				|| ChartTypeEnum.CrossMonth.getTypeName().equals(form.getChartType())){
			//for Region overview chart
			if("Region".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1) {
					if(form.isShowGeoOverview())//geo overview
						sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
					else 
						sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());
				}
				
				if(!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
				}
			}
			//for Odm overview chart
			else if("Odm".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());
				
				if(!StringUtil.isEmpty(form.getGeoIds())) {
					sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
				}
			}
			//for Product overview chart
			else if("Product".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());
				
				if(!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getGeoIds())) {
					sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
				}
			}
			
			//for Region remark chart
			if("Region".equals(form.getRemarkDimension())) {
				if(form.isShowDashBoradCrossMonth()){
					sBuffer.append(" and region.GeographyName in(").append(form.getSubDimension()).append(")");
				}
				else{
					if(form.isShowGeoOverview())//geo overview
						sBuffer.append(" and geo.GeographyKey = ").append(form.getRemarkSubDimensionKey());
					else 
						sBuffer.append(" and ots.RegionKey = ").append(form.getRemarkSubDimensionKey());
				}
			}
			//for Odm remark chart
			else if("Odm".equals(form.getRemarkDimension())) {
				if(form.isShowDashBoradCrossMonth()){
					sBuffer.append(" and dimODM.ODMEnglishName in(").append(form.getSubDimension()).append(")");
				}else{
					sBuffer.append(" and ots.ODMKey = ").append(form.getRemarkSubDimensionKey());
				}
				
			}
			//for Product remark chart
			else if("Product".equals(form.getRemarkDimension())) {
				if(form.isShowDashBoradCrossMonth()){
					sBuffer.append(" and dimProduct.ProductEnglishName in(").append(form.getSubDimension()).append(")");
				}else{
					sBuffer.append(" and ots.ProductKey = ").append(form.getRemarkSubDimensionKey());
				}
			}
			//for Detractor remark chart
			else if("Detractor".equals(form.getRemarkDimension())) {
				if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
					sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
					
					if(form.getOrderNumber() > 0){
						sBuffer.append(" union all ");
						sBuffer.append("select  top ").append(form.getOrderNumber());
						sBuffer.append(" dimODM.ODMEnglishName as odm,")
								.append("geo.GeographyName as geo,")
								.append("region.GeographyName as region,")
								.append("country.GeographyName as country,")
								.append("dimProduct.ProductEnglishName as product,")
								.append("mtm.BOMNumberAlternateKey as pn,")
								.append("mtm.MTMEnglishDescription as itemDesc,")
								.append("ots.POItem as poItem,")
								.append("ots.PONumber as poNumber,")
								.append("ots.POItem as itemNo,")
								.append("ots.OrderQuantity as qty,")
								.append("ots.OrderDate as orderDate,")
								.append("ots.RSDDate as rsd,")
								.append("ots.FPSDDate as fpsd,")
								.append("ots.ShipDate as shippedDate,")
								.append("ots.IsShipped as shipped,")
								.append("'' as level1,")
								.append("'' as level2 ,")
								.append("ots.LateReason2 as level3 ")
								.append(" from FactMonthlySummaryofOTS ots")
								.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
								.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
								.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
								.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
								.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
								.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
								.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
						
						
						if(form.isShowQuarterOverview()){
							form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
							form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
							sBuffer.append(" where ots.Year*100 + ots.Month between ")
							   .append(form.getQuarterFrom())
							   .append(" and ").append(form.getQuarterTo());
						}
						else {
						 	sBuffer.append(" where ots.Year = ").append(form.getYear())
						 			.append(" and ots.Month = ").append(form.getMonth());
						 }
						
						if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
							sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
							sBuffer.append(form.getPoNumberItemOrderNo());
							sBuffer.append(")");
						}
						
						if(form.getOrderTypeId() == 1) {
							if(form.getOrderSubTypeId() != -1) {
								sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
							}
							else {
								sBuffer.append(" and ots.OTSTypeKey in (1,2)");
							}
						}
						
						if(form.getOrderTypeId() == 2) {
							if(form.getOrderSubTypeId() != -1) {
								sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
							}
							else {
								sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
							}
						}
						
						if(form.isShowAllRemarkOrder()){
							sBuffer.append(" and status.OTSStatusKey in(").append(form.getScStatus()).append(")");
						}
						else{
							sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
						}
						
						if(("region".equalsIgnoreCase(form.getOverViewDimension()) && form.getOverViewSubDimensionKey() != -1)){
							sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyKey = '"+ form.getOverViewSubDimensionKey()+ "' ");
						}
			
						//for Region overview chart
						if("Region".equals(form.getOverViewDimension())) {
							if(form.getOverViewSubDimensionKey() != -1) {
								if(form.isShowGeoOverview())//geo overview
									sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
								else 
									sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());
							}
				
							if(!StringUtil.isEmpty(form.getOdmIds())) {
								sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
							}
							if(!StringUtil.isEmpty(form.getProductIds())) {
								sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
							}
						}
						//for Odm overview chart
						else if("Odm".equals(form.getOverViewDimension())) {
							if(form.getOverViewSubDimensionKey() != -1)
								sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());
				
							if(!StringUtil.isEmpty(form.getGeoIds())) {
								sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
							}
							if(!StringUtil.isEmpty(form.getProductIds())) {
								sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
							}
						}
						//for Product overview chart
						else if("Product".equals(form.getOverViewDimension())) {
							if(form.getOverViewSubDimensionKey() != -1)
								sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());
				
							if(!StringUtil.isEmpty(form.getOdmIds())) {
								sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
							}
							if(!StringUtil.isEmpty(form.getGeoIds())) {
								sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
							}
						}
			
						sBuffer.append(" and ots.DetractorKey is null");
					}
				}
				else{
					if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension()))
						sBuffer.append(" and ots.DetractorKey is null ");
					else
						sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getRemarkSubDimension() + "' ");
				}
			}
		}else if(ChartTypeEnum.OverView.getTypeName().equals(form.getChartType())){
			if("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
				sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

	@Override
	public List<TtvGridDetractorCodeView> getDashCrossRemarkOrderDetail(
			SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		if(form.isShowAllRemarkOrder()){
			sBuffer.append("(select top ").append(form.getRowCount() + form.getOrderNumber()).append(" * from ");
		}else{
			sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		}
		sBuffer.append("(select  top ").append(form.getEndRow());
		if("Detractor".equals(form.getRemarkDimension())){
			sBuffer.append(" sum.odm,sum.geo,sum.region,sum.country,sum.product,sum.pn,sum.itemDesc,sum.poItem,sum.poNumber,")
					.append("sum.itemNo,sum.qty,sum.orderDate,sum.rsd,sum.fpsd,sum.shippedDate,sum.shipped,")
					.append("sum.level1,sum.level2,sum.level3 from (select ");
		}
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ots.POItem as poItem,")
				.append("ots.PONumber as poNumber,")
				.append("ots.POItem as itemNo,")
				.append("ots.OrderQuantity as qty,")
				.append("ots.OrderDate as orderDate,")
				.append("ots.RSDDate as rsd,")
				.append("ots.FPSDDate as fpsd,")
				.append("ots.ShipDate as shippedDate,")
				.append("ots.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ots.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofOTS ots")
				.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
				.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ots.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where ots.Year = ").append(form.getYear())
    			   .append(" and ots.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if(form.isShowAllRemarkOrder()){
			sBuffer.append(" and status.OTSStatusKey in(").append(form.getScStatus()).append(")");
		}
		else{
			sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		}
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}		
		//for Odm overview chart
		if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}		
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and region.GeographyName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ots.RegionKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and dimODM.ODMEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ots.ODMKey = ").append(form.getRemarkSubDimensionKey());
			}
			
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and dimProduct.ProductEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ots.ProductKey = ").append(form.getRemarkSubDimensionKey());
			}
		}		
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
				sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
				
				if(form.getOrderNumber() > 0){
					sBuffer.append(" union all ");
					sBuffer.append("select  top ").append(form.getOrderNumber());
					sBuffer.append(" dimODM.ODMEnglishName as odm,")
							.append("geo.GeographyName as geo,")
							.append("region.GeographyName as region,")
							.append("country.GeographyName as country,")
							.append("dimProduct.ProductEnglishName as product,")
							.append("mtm.BOMNumberAlternateKey as pn,")
							.append("mtm.MTMEnglishDescription as itemDesc,")
							.append("ots.POItem as poItem,")
							.append("ots.PONumber as poNumber,")
							.append("ots.POItem as itemNo,")
							.append("ots.OrderQuantity as qty,")
							.append("ots.OrderDate as orderDate,")
							.append("ots.RSDDate as rsd,")
							.append("ots.FPSDDate as fpsd,")
							.append("ots.ShipDate as shippedDate,")
							.append("ots.IsShipped as shipped,")
							.append("'' as level1,")
							.append("'' as level2 ,")
							.append("ots.LateReason2 as level3 ")
							.append(" from FactMonthlySummaryofOTS ots")
							.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
							.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
							.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
							.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
							.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
							.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
							.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
					
					
					if(form.isShowQuarterOverview()){
						form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
						form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
						sBuffer.append(" where ots.Year*100 + ots.Month between ")
						   .append(form.getQuarterFrom())
						   .append(" and ").append(form.getQuarterTo());
					}
					else {
					 	sBuffer.append(" where ots.Year = ").append(form.getYear())
					 			.append(" and ots.Month = ").append(form.getMonth());
					 }
					
					if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
						sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
						sBuffer.append(form.getPoNumberItemOrderNo());
						sBuffer.append(")");
					}
					
					if(form.getOrderTypeId() == 1) {
						if(form.getOrderSubTypeId() != -1) {
							sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
						}
						else {
							sBuffer.append(" and ots.OTSTypeKey in (1,2)");
						}
					}
					
					if(form.getOrderTypeId() == 2) {
						if(form.getOrderSubTypeId() != -1) {
							sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
						}
						else {
							sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
						}
					}
					
					if(form.isShowAllRemarkOrder()){
						sBuffer.append(" and status.OTSStatusKey in(").append(form.getScStatus()).append(")");
					}
					else{
						sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
					}
					
					if(("region".equalsIgnoreCase(form.getOverViewDimension()) && form.getOverViewSubDimensionKey() != -1)){
						sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyKey = '"+ form.getOverViewSubDimensionKey()+ "' ");
					}
		
					//for Region overview chart
					if("Region".equals(form.getOverViewDimension())) {
						if(form.getOverViewSubDimensionKey() != -1)
							sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
						if(!StringUtil.isEmpty(form.getOdmIds())) {
							sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
						}
					}
					//for Odm overview chart
					else if("Odm".equals(form.getOverViewDimension())) {
						if(form.getOverViewSubDimensionKey() != -1)
							sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
						if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
						}
					}
					//for Product overview chart
					else if("Product".equals(form.getOverViewDimension())) {
						if(form.getOverViewSubDimensionKey() != -1)
							sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
						if(!StringUtil.isEmpty(form.getOdmIds())) {
							sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
						}
					}
		
					sBuffer.append(" and ots.DetractorKey is null");
					
				}
				sBuffer.append(")sum");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", orderNo ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(" , poItem ").append(form.getReversalSortType());
			sBuffer.append(" , qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

	@Override
	public int getDashCrossRemarkOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(ots.OTSStatusKey) as orderNum")
		   .append(" from FactMonthlySummaryofOTS ots")
		   .append(" left join ")
		   .append(" DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
		   .append(" left join DimDetractor dimDetractor on ots.DetractorKey =  dimDetractor.DetractorKey")
		   .append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
		   .append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
		   .append(" left join  DimProduct product on ots.ProductKey = product.ProductKey");
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where ots.Year = ").append(form.getYear())
    			   .append(" and ots.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), ots.Year)+'-'+CONVERT(nvarchar(20), ots.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if(form.isShowAllRemarkOrder()){
			sBuffer.append(" and status.OTSStatusKey in(").append(form.getScStatus()).append(")");
		}
		else{
			sBuffer.append(" and status.OTSStatus = '").append(form.getScStatus()).append("'");
		}
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and ots.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and ots.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and ots.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and region.GeographyName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ots.RegionKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and dimODM.ODMEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ots.ODMKey = ").append(form.getRemarkSubDimensionKey());
			}
			
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and product.ProductEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and ots.ProductKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and upper(dimDetractor.level1) in(").append(form.getSubDimension()).append(")");
			}else{
				if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
					sBuffer.append(" and dimDetractor.level1 is null ");
				}else{
					sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getRemarkSubDimension() + "' ");
				}
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	public List<TtvGridDetractorCodeView> getAllDetractorOrder(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("ots.POItem as poItem,")
				.append("ots.PONumber as poNumber,")
				.append("ots.POItem as itemNo,")
				.append("ots.OrderQuantity as qty,")
				.append("ots.OrderDate as orderDate,")
				.append("ots.RSDDate as rsd,")
				.append("ots.FPSDDate as fpsd,")
				.append("ots.ShipDate as shippedDate,")
				.append("ots.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("ots.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofOTS ots")
				.append(" left join DimOTSStatus status on ots.OTSStatusKey = status.OTSStatusKey")
				.append(" left join DimProduct dimProduct on ots.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on ots.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on ots.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on ots.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on ots.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on ots.CountryKey = country.GeographyKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where ots.Year*100 + ots.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where ots.Year = ").append(form.getYear())
		 			.append(" and ots.Month = ").append(form.getMonth());
		 }
		
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(ots.PONumber as nvarchar)+'_'+cast(ots.POItem as nvarchar)+'_'+cast(isnull(ots.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and ots.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and ots.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and ots.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ODMKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and ots.ProductKey = ").append(form.getOverViewSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sBuffer.append(" and  ots.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sBuffer.append(" and  ots.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and  ots.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sBuffer.append(" and  ots.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())){
			sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel2Detractor())){
			sBuffer.append(" and upper(dimDetractor.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		
		if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase() + "' ");
		}
		else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and dimProduct.ProductEnglishName = '"+ form.getSubDimension().toUpperCase() + "' ");
		}
		else if("Detractor".equalsIgnoreCase(form.getDimension())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor()) || "UNKNOWN".equalsIgnoreCase(form.getSubDimension())) 
				sBuffer.append(" and ots.DetractorKey is null");
			else
				sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getLevel1Detractor().toUpperCase() + "' ");
		}
		
		sBuffer.append(" and status.OTSStatus in ('Fail','To-be Fail')");
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(" , poItem ").append(form.getSortType());
			sBuffer.append(" , qty ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poNumber", StringType.INSTANCE)
				.addScalar("poItem", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

}
