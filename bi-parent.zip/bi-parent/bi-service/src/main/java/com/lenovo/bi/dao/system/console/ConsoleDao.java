package com.lenovo.bi.dao.system.console;

import java.util.List;

import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.BiWeeklyProcessStatus;
import com.lenovo.bi.model.system.ThresholdDetail;
import com.lenovo.bi.view.system.console.FailedJobDetailView;
import com.lenovo.common.model.PagerInformation;

public interface ConsoleDao{

	public ThresholdDetail findThresholdById(Integer thresholdId);
	
	public List<ThresholdDetail> listThreshold(DictSearchForm form, PagerInformation pagerInfo);
	
	public int getThresholdDetailCountByConditions(DictSearchForm form);
	
	public void saveThreshold(ThresholdDetail thresholdDetail);
	
	public void saveEditedThreshold(ThresholdDetail thresholdDetail);
	
	public void deleteThresholds(String thresholdIds);
	
	public ThresholdDetail getThresholdById(Integer thresholdId);
	
	public List<BiWeeklyProcessStatus> getEngineStatusHistory();
}
