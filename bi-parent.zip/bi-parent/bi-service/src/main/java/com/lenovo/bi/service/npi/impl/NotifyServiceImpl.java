package com.lenovo.bi.service.npi.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.npi.NPIOverviewDao;
import com.lenovo.bi.dao.npi.NPIProductSummaryDao;
import com.lenovo.bi.dto.NPI;
import com.lenovo.bi.dto.TTMProduct;
import com.lenovo.bi.enumobj.Risk;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.enumobj.Success;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
import com.lenovo.bi.model.User;
import com.lenovo.bi.service.common.MasterDataService;
import com.lenovo.bi.service.npi.NotifyService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.CommonUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.ttm.TtmGridProduct;
import com.lenovo.common.email.NotificationFacade;
import com.lenovo.common.email.NotificationMessage;

@Transactional("bi")
@Service("notifyService")
public class NotifyServiceImpl implements NotifyService {

	@Inject
	private NotificationFacade notification;

	@Inject
	private NPIOverviewDao nPIOverviewDao;

	@Inject
	public NPIProductSummaryDao nPIProductSummaryDao;

	@Inject
	private MasterDataService masterDataService;

	public void sendNotification() {

		OverviewSearchForm form = new OverviewSearchForm();
		form.setGridType(Status.In_Progress);
		List<TTMProduct> ttmProducts = nPIOverviewDao.getRedTTMProductsByConditions(form);

		if (ttmProducts != null && !ttmProducts.isEmpty()) {
			List<TtmGridProduct> list = convert2Pojo(ttmProducts);

			for (TtmGridProduct product : list) {

				String subject = null;
				String content = null;

				if ("RED".equalsIgnoreCase(product.getDoiLight()) && "RED".equalsIgnoreCase(product.getGatingDefectsLight())) {
					subject = "[BI]{" + product.getProductName() + "}:DOI and Gating defect light is red reminder";
					content = "The DOI and Gating defect light is red at the TTM phase of product " + product.getProductName()
							+ ". please speed it up to catch up the project goal and update the related data at system.";
				} else if ("RED".equalsIgnoreCase(product.getDoiLight()) && !"RED".equalsIgnoreCase(product.getGatingDefectsLight())) {
					subject = "[BI]{" + product.getProductName() + "}:DOI defect light is red reminder";
					content = "The DOI defect light is red at the TTM phase of product " + product.getProductName()
							+ ". please speed it up to catch up the project goal and update the related data at system.";
				} else if (!"RED".equalsIgnoreCase(product.getDoiLight()) && "RED".equalsIgnoreCase(product.getGatingDefectsLight())) {
					subject = "[BI]{" + product.getProductName() + "}:Gating defect light is red reminder";
					content = "The Gating defect light is red at the TTM phase of product " + product.getProductName()
							+ ". please speed it up to catch up the project goal and update the related data at system.";
				}

				try {
					if (CalendarUtil.addDays(CalendarUtil.getTodayWithoutMins(), SysConfig.TTM_NOTIFICATION_PREDAYS).after(
							CalendarUtil.stringT2Date(product.getTtmTargetDate()))) {

						NotificationMessage message = new MailNotificationMessage();

						message.setTo((String[]) product.getNpiOwnerMails().toArray(new String[] {}));
						if (product.getPmOwnerMail() != null) {
							message.setCc(new String[] { product.getPmOwnerMail() });
						}
						message.getParameters().put("mail_subject", subject);
						message.getParameters().put("mail_content", content);
						message.getParameters().put("mail_sayHiTo", product.getNpiOwner());
						message.getParameters().put("mail_link", SysConfig.HOME_URL);

						notification.send(message);
					}
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private List<TtmGridProduct> convert2Pojo(List<TTMProduct> rawList) {

		List<TtmGridProduct> list = new ArrayList<TtmGridProduct>();
		List<Integer> waveIds = new ArrayList<Integer>();

		for (TTMProduct ttmProduct : rawList) {
			TtmGridProduct tp = new TtmGridProduct();
			waveIds.add(ttmProduct.getNpiWaveId());
			tp.setWaveId(ttmProduct.getNpiWaveId());
			tp.setProductId(ttmProduct.getProjectId());
			tp.setWaveName(ttmProduct.getWaveName());
			tp.setProductName(ttmProduct.getProductName());
			tp.setDoiLight(ttmProduct.getDoi());
			tp.setGatingDefectsLight(ttmProduct.getDefects());
			tp.setOdmLight(ttmProduct.getOdm());
			tp.setFpyLight(ttmProduct.getFpy());
			tp.setToolingLight(ttmProduct.getTooling());
			tp.setCurrentPhase(ttmProduct.getCurrentPhase());
			tp.setPmOwner(ttmProduct.getPm());
			User pm = nPIProductSummaryDao.getUser(ttmProduct.getPm());
			if (pm != null) {
				tp.setPmOwnerMail(pm.getEmail());
			}
			try {
				tp.setStartDate(CalendarUtil.date2String(ttmProduct.getStartDate()));
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Status s = null;
			if (ttmProduct.getTtmStatus() != null) {
				s = Status.valueOf(ttmProduct.getTtmStatus());
				tp.setStatusColor(s.getLabelColor());
				tp.setStatus(s.toString());
				if (s == Status.In_Progress) {
					if (ttmProduct.isRisk()) {
						tp.setRisk(Risk.Risk.toString());
						tp.setRiskColor(Risk.Risk.getLabelColor());
					} else {
						tp.setRisk(Risk.No_Risk.toString());
						tp.setRiskColor(Risk.No_Risk.getLabelColor());
					}
				}
			}
			if (s == Status.Success) {
				int delay = masterDataService.getThresholdByName(Threshold.TTM_SUCCESS_THRESHOLD.name()).intValue();
				if (ttmProduct.getSuccessDelays() <= 0) {
					tp.setSuccessStatus(Success.On_Schedule.toString());
					tp.setSuccessColor(Success.On_Schedule.getLabelColor());
				} else if (ttmProduct.getSuccessDelays() > delay) {
					tp.setSuccessStatus(CommonUtil.SuccessStatusReplace(Success.Delay_Greater_than_NUM_Days, delay));
					tp.setSuccessColor(Success.Delay_Greater_than_NUM_Days.getLabelColor());
				} else {
					tp.setSuccessStatus(CommonUtil.SuccessStatusReplace(Success.Delay_Less_than_NUM_Days, delay));
					tp.setSuccessColor(Success.Delay_Less_than_NUM_Days.getLabelColor());
				}
			}

			try {
				if (ttmProduct.getTtmTargetDate() != null) {
					tp.setTtmTargetDate(CalendarUtil.date2String(ttmProduct.getTtmTargetDate()));
				}

				if (ttmProduct.getTtmSignOffDate() != null) {
					tp.setTtmSignOffDate(CalendarUtil.date2String(ttmProduct.getTtmSignOffDate()));
				}

				if (ttmProduct.getTtmTargetDate() != null && ttmProduct.getTtmSignOffDate() != null) {
					if (ttmProduct.getTtmTargetDate().before(ttmProduct.getTtmSignOffDate())
							|| CalendarUtil.isSameDay(ttmProduct.getTtmTargetDate(), ttmProduct.getTtmSignOffDate())) {
						tp.setTargetDatePassed(true);
					}

					if (!CalendarUtil.isSameDay(ttmProduct.getTtmTargetDate(), ttmProduct.getTtmSignOffDate())) {
						tp.setShowSignedSnapshot(true);
					}
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
			list.add(tp);
		}

		if (!waveIds.isEmpty()) {
			Map<Integer, List<NPI>> npiMap = nPIProductSummaryDao.getNPIByWaveIds((Integer[]) waveIds.toArray(new Integer[] {}));

			if (npiMap != null) {

				Map<Integer, List<String>> npiUserIds = new HashMap<Integer, List<String>>();
				Map<Integer, List<String>> npiUserMails = new HashMap<Integer, List<String>>();

				Iterator<Integer> it = npiMap.keySet().iterator();
				while (it.hasNext()) {
					Integer waveId = it.next();
					List<NPI> npis = npiMap.get(waveId);
					if (npis != null && !npis.isEmpty()) {
						List<String> userIds = new ArrayList<String>();
						List<String> userMails = new ArrayList<String>();
						for (NPI npi : npis) {
							userIds.add(npi.getUserId());
							userMails.add(npi.getUserMail());
						}
						if (npiUserIds.get(waveId) == null) {
							List<String> l = new ArrayList<String>();
							l.addAll(userIds);
							npiUserIds.put(waveId, l);
						} else {
							npiUserIds.get(waveId).addAll(userIds);
						}
						if (npiUserMails.get(waveId) == null) {
							List<String> l = new ArrayList<String>();
							l.addAll(userMails);
							npiUserMails.put(waveId, l);
						} else {
							npiUserMails.get(waveId).addAll(userMails);
						}
					}

				}

				for (TtmGridProduct t : list) {
					if (npiUserIds.get(t.getWaveId()) != null) {
						t.setNpiOwner(CommonUtil.npiNameString(npiUserIds.get(t.getWaveId())));
					}
					if (npiUserMails.get(t.getWaveId()) != null) {
						t.setNpiOwnerMails(npiUserMails.get(t.getWaveId()));
					}
				}
			}
		}

		return list;
	}
}
