package com.lenovo.bi.service.npi.helper;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.npi.impl.NpiCommittedCVAllocatorDaoDwImpl;
import com.lenovo.bi.dto.ForecastDetailDto;
import com.lenovo.bi.dto.OrderDetailDto;

@Service
@Transactional("dw")
public class NpiCommittedCVAllocatorDwHelper {

	@Autowired
	private NpiCommittedCVAllocatorDaoDwImpl allocatorDaoDw;
	
	public NpiCommittedCVAllocatorDaoDwImpl getAllocatorDaoDw() {
		return allocatorDaoDw;
	}

	public void setAllocatorDaoDw(NpiCommittedCVAllocatorDaoDwImpl allocatorDaoDw) {
		this.allocatorDaoDw = allocatorDaoDw;
	}

	/**
	 * get SLE order list
	 * @param versionDate
	 * @param financeEndDate
	 * @param productKey
	 * @param productNotInSet
	 * @return
	 */
	public List<OrderDetailDto> getSLEOrderList(Date versionDate, Date financeEndDate, int productKey, Set<Integer> productNotInSet){
		return allocatorDaoDw.getSLEOrderList(versionDate, financeEndDate, productKey, productNotInSet);
	}
	
	/**
	 * get SGA order list
	 * @param versionDate
	 * @param financeEndDate
	 * @param productKey
	 * @param productNotInSet
	 * @return
	 */
	public List<OrderDetailDto> getSGAOrderList(Date versionDate, Date financeEndDate, int productKey, Set<Integer> productNotInSet){
		return allocatorDaoDw.getSGAOrderList(versionDate, financeEndDate, productKey, productNotInSet);
	}
	
	/**
	 * get forecast list
	 * @param versionDate
	 * @param targetDate
	 * @param dnsVersionDate
	 * @param initDate
	 * @param financeEndDate
	 * @param productKey
	 * @param productNotInSet
	 * @return
	 */
	public List<ForecastDetailDto> getForecastList(Date versionDate, Date targetDate, Date dnsVersionDate, Date initDate, Date financeEndDate, int productKey, Set<Integer> productNotInSet){
		//return allocatorDaoDw.getForecastList(versionDate, targetDate, initDate, financeEndDate, productKey, productNotInSet);
		return allocatorDaoDw.getForecastList(versionDate, targetDate, dnsVersionDate, initDate, financeEndDate, productKey, productNotInSet);
	}
	
	/**
	 * get CV mapping for per MTM
	 * @param mtmKey
	 * @return
	 */
	public Map<Integer, Integer> getCvMapping4Mtm(int mtmKey){
		return allocatorDaoDw.getCvMapping4Mtm(mtmKey);
	}
	
	/**
	 * get finance end date
	 * @param initDate
	 * @return
	 */
	public Date getFinanceEndDate(Date initDate){
		return allocatorDaoDw.getFinanceEndDate(initDate);
	}
	
}
