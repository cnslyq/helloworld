package com.lenovo.bi.dao.sc.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.FloatType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.FADao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FaOverViewChartData;
import com.lenovo.bi.dto.sc.GeoFA;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.enumobj.FaTypeEnum;
import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.sc.fa.FADetailView;

@SuppressWarnings("rawtypes")
@Repository
public class FADaoImpl extends HibernateBaseDaoImplDw implements FADao {

	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> fetchFaOverViewChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sBuffer.append("select isnull(sum([60DaysForecastQty]),0) as mpsValue,")
				   .append(" isnull(sum(OrderQty),0) as OrderQty,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),4),0) ")
				   .append(" as typeValue,")
				   .append("'Mps' as typeName")
				   .append(" from (select YEAR,MONTH,dg.GeographyName,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sBuffer.append("select isnull(sum([60DaysGrossForecastQty]),0) as mpsValue,")
				   .append(" isnull(sum(OrderQty),0) as OrderQty,")
			       .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),2),0) ")
			       .append(" as typeValue,")
			       .append("'grossForecast' as typeName")
			       .append(" from (select YEAR,MONTH,dg.GeographyName,SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		}
		sBuffer.append(" where Year = ").append(form.getYear())
			   .append(" and Month = ").append(form.getMonth());
		
		//for SC overview:fa
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
		}
				
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("typeName", StringType.INSTANCE)
				.addScalar("typeValue", FloatType.INSTANCE)
				.addScalar("mpsValue", FloatType.INSTANCE)
				.addScalar("OrderQty", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		List<FaOverViewChartData> result = query.list();
		return result;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchFaRemarkChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sBuffer.append("select top 15 isnull(sum([60DaysForecastQty]),0) as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sBuffer.append("select top 15 isnull(sum([60DaysGrossForecastQty]),0) as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" GeographyName as subDimensionName, 1 as subDimensionKey ")
				   .append(" from (select YEAR,MONTH,dg.GeographyName,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM(OrderQty) as OrderQty,SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty] from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
	
			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth())
				   .append(" and isnull(GeographyName,'') <> ''")
			   	   .append(" group by GeographyName ");
		}
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append("case when fa.ODMKey is null then 0 else fa.ODMKey end as subDimensionKey,")
				   .append("odm.ODMEnglishName as subDimensionName")
				   .append(" from (select YEAR,MONTH,odmkey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM(OrderQty) as OrderQty,SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty] from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,odmkey,dg.GeographyName,productKey,odmKey) fa")
				   .append(" left join DimODM odm on fa.ODMKey=odm.ODMKey");
	
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth())
				   .append(" group by fa.ODMKey,odm.ODMEnglishName having odm.ODMEnglishName <> ''");
		}
		else if("Product".equals(form.getDimension())) {
			sBuffer.append("case when fa.productKey is null then 0 else fa.productKey end as subDimensionKey,")
				   .append(" product.productEnglishName as subDimensionName ")
				   .append(" from (select YEAR,MONTH,productKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM(OrderQty) as OrderQty,SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty] from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,productKey,dg.GeographyName,productKey,odmKey) fa")
				   .append(" left join DimProduct  product on fa.productKey = product.productKey ");
			
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
			sBuffer.append(" group by fa.productKey,product.productEnglishName having product.productEnglishName <> ''");
		}
		sBuffer.append(" order by faRate desc");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("subDimensionName", StringType.INSTANCE)
				.addScalar("subDimensionValue", IntegerType.INSTANCE)
				.addScalar("subDimensionKey", IntegerType.INSTANCE)
				.addScalar("faRate", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchDimensions(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		//for Region dashboard overview chart
		if("Region".equals(form.getDashboardType())) {
		    sBuffer.append("select top 15 1 as objKey,fa.GeographyName as objName,'Region' as type")
			       .append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa ");
			       //.append(" left join DimGeography geography on geography.GeographyName = fa.GeographyName");
		    
		    if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" left join (")
					   .append(" select product.ProductKey from DimProduct product")
					   .append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				       .append(" where family.ProductFamilyKey in (").append(form.getFamilyIds()).append(")")
				       .append(")productFamily on fa.ProductKey = productFamily.ProductKey");
			}
		    sBuffer.append(" where fa.Year = ").append(form.getYear())
    			   .append(" and fa.Month = ").append(form.getMonth());
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			sBuffer.append(" group by fa.GeographyName having fa.GeographyName <> ''");
		}
		//for Odm dashboard overview chart
		else if("Odm".equals(form.getDashboardType())) {
		    sBuffer.append("select top 15 fa.ODMKey as objKey,odm.ODMEnglishName as objName,'Odm' as type")
			       .append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa ")
			       .append(" left join DimODM odm on fa.ODMKey = odm.ODMKey");
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" left join (")
					   .append(" select product.ProductKey from DimProduct product")
				       .append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
					   .append(" where family.ProductFamilyKey in (").append(form.getFamilyIds()).append(")")
					   .append(")productFamily on fa.ProductKey = productFamily.ProductKey");
			}
			sBuffer.append(" where fa.Year = ").append(form.getYear())
    			   .append(" and fa.Month = ").append(form.getMonth());
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			sBuffer.append(" group by fa.ODMKey,odm.ODMEnglishName having fa.ODMKey <> ''");
		}
		//for Product dashboard overview chart
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append("select  fa.ProductKey as objKey,")
				   .append(" product.ProductEnglishName as objName,")
				   .append(" 'Product' as type")
				   .append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa")
				   .append(" left join DimProduct product on fa.ProductKey = product.ProductKey");
			
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
	    	if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			sBuffer.append(" group by fa.ProductKey,product.ProductEnglishName having fa.ProductKey <> ''");
		}
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sBuffer.append(" order by sum(fa.[60DaysForecastQty]) desc");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sBuffer.append(" order by sum(fa.[60DaysGrossForecastQty]) desc");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> fetchFaDashboardOverViewChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		//此处dashboard的chart加上了group 对原来的结果没有影响
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sBuffer.append("select isnull(sum(fa.[60DaysForecastQty]),0) as mpsValue,")
				   .append(" isnull(sum(OrderQty),0) as OrderQty,")
				   .append("'Mps' as typeName,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),2),0)  ")
				   .append(" as typeValue")
				   .append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa");
		}
		else{
			sBuffer.append("select isnull(sum(fa.[60DaysGrossForecastQty]),0) mpsValue,")
				   .append(" isnull(sum(OrderQty),0) as OrderQty,")
			    	.append("'GrossForecast' as typeName,")
			    	.append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),2),0) ")
			        .append(" as typeValue")
			    	.append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa");
		}
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" left join DimProduct product on fa.productKey = product.productKey ");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
//			sBuffer.append(" left join DimGeography geography on geography.GeographyName = fa.GeographyName");
			sBuffer.append(" where fa.GeographyName = '").append(form.getSubDimension());
			sBuffer.append("' and fa.Year = ").append(form.getYear())
			   	   .append(" and fa.Month = ").append(form.getMonth());
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			sBuffer.append(" group by fa.GeographyName");
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" left join (")
				   .append(" select product.ProductKey from DimProduct product")
				   .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				   .append(" where family.ProductFamilyKey = ").append(form.getSubDimensionKey())
				   .append(" )productFamily on fa.ProductKey = productFamily.ProductKey");
			sBuffer.append(" where fa.productKey = ").append(form.getSubDimensionKey());
//			if(!StringUtil.isEmpty(form.getFamilyIds())) {
//				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
//			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			sBuffer.append(" and");
			sBuffer.append(" fa.Year = ").append(form.getYear())
			   	   .append(" and fa.Month = ").append(form.getMonth());
			sBuffer.append(" group by fa.ProductKey having fa.ProductKey <> ''");
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" left join DimProduct product on fa.productKey = product.productKey ");
			sBuffer.append(" left join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey");
			sBuffer.append(" left join DIMODM ODM on ODM.ODMkey = fa.ODMkey");
			sBuffer.append(" where fa.ODMKey = ").append(form.getSubDimensionKey());
			
			sBuffer.append(" and");
			sBuffer.append(" fa.Year = ").append(form.getYear())
			   	   .append(" and fa.Month = ").append(form.getMonth());
			
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			sBuffer.append(" group by fa.ODMKey,ODM.ODMEnglishName having fa.ODMKey <> ''");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("typeName", StringType.INSTANCE)
				.addScalar("mpsValue", IntegerType.INSTANCE)
				.addScalar("typeValue", FloatType.INSTANCE)
				.addScalar("OrderQty", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchFaDashboardRemarkChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sBuffer.append("select top 15 isnull(sum([60DaysForecastQty]),0) as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sBuffer.append("select top 15 isnull(sum([60DaysGrossForecastQty]),0) as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		
		//for Region remark chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" 1 as subDimensionKey,")
				   .append(" fa.GeographyName as subDimensionName")
				   .append(" from (select YEAR,MONTH,dg.GeographyName as GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa")
//				   .append(" left join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo")
				   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
				   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
	
			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth());
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and fa.ODMKey = ").append(form.getDashboardTypeKey());
				}
				else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and fa.ProductKey = ").append(form.getDashboardTypeKey());
				}
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			sBuffer.append(" group by fa.GeographyName having fa.GeographyName <> ''");
		}
		//for Odm remark chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append("case when fa.ODMKey is null then 0 else fa.ODMKey end as subDimensionKey,")
				   .append("odm.ODMEnglishName as subDimensionName")
				   .append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa")
				   .append(" left join DimODM odm on fa.ODMKey=odm.ODMKey")
				   .append(" left join DimProduct pro on fa.productKey = pro.productKey")
				   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
	    	if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
				}
				else if("Product".equals(form.getDashboardType())){
					sBuffer.append(" and fa.ProductKey = ").append(form.getDashboardTypeKey());
				}
			}
	    	if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			
			sBuffer.append(" group by fa.ODMKey,odm.ODMEnglishName having odm.ODMEnglishName <> ''");
		}
		//Product
		else if("Product".equals(form.getDimension())) {
			sBuffer.append("isnull(fa.productKey,0) as subDimensionKey,")
				   .append("product.productEnglishName as subDimensionName ")
				   .append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa")
				   .append(" left join DimProduct  product on fa.productKey = product.productKey ")
				   .append(" left join DimProductFamily family on product.ProductFamilyKey = family.ProductFamilyKey");
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
	    	if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType())){
					sBuffer.append(" and fa.OdmKey = ").append(form.getDashboardTypeKey());
				}
				else if("Region".equals(form.getDashboardType())){
					sBuffer.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
				}
			}
	    	if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			sBuffer.append(" group by fa.productKey,product.productEnglishName having product.productEnglishName <> ''");
		}
		
		sBuffer.append(" order by faRate desc");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("subDimensionName", StringType.INSTANCE)
				.addScalar("subDimensionValue", IntegerType.INSTANCE)
				.addScalar("subDimensionKey", IntegerType.INSTANCE)
				.addScalar("faRate", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}
	 
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> getFaPieChart(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60DaysForecastQty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60DaysForecastQty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60DaysForecastQty],0) then 1 else 0 end) as equal_plan ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())){
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60daysgrossforecastqty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60daysgrossforecastqty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60daysgrossforecastqty],0) then 1 else 0 end) as equal_plan ");
		}
		sql.append("from (select YEAR,MONTH,GeographyName,productKey,odmKey,sum([60DaysForecastQty]) as [60DaysForecastQty], sum([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],sum(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		sql.append(" where fa.Year = ").append(form.getYear())
	       .append(" and fa.Month = ").append(form.getMonth());
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and isnull(fa.[60DaysGrossForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		
		/*if(!StringUtil.isEmpty(form.getRegionIds())) {
			sql.append(" and fa.GeographyName in(").append(form.getRegionIds()).append(")");
		}
	    if(!StringUtil.isEmpty(form.getOdmIds())) {
	    	sql.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
    	if(!StringUtil.isEmpty(form.getProductIds())) {
    		sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
		}*/
    	sql.append(") p ")
		   .append("UNPIVOT (value for rowname in(over_plan,under_plan,equal_plan)) p");
		
		
		Query query = getSession().createSQLQuery(sql.toString())
			.addScalar("value", IntegerType.INSTANCE)
			.addScalar("rowName", StringType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		return query.list();
	}	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> getFaDashboardPieChart(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60DaysForecastQty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60DaysForecastQty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60DaysForecastQty],0) then 1 else 0 end) as equal_plan ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())){
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60daysgrossforecastqty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60daysgrossforecastqty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60daysgrossforecastqty],0) then 1 else 0 end) as equal_plan ");
		}
		sql.append("from (select YEAR,MONTH,GeographyName,productKey,odmKey,sum([60DaysForecastQty]) as [60DaysForecastQty], sum([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],sum(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" where fa.Year = ").append(form.getYear())
	       .append(" and fa.Month = ").append(form.getMonth());
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and isnull(fa.[60DaysGrossForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getOdmIds())) {
			sql.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		if("Region".equals(form.getDashboardType())) {
			if(!StringUtil.isEmpty(form.getSubDimension())) {
				sql.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
			}
		}else if("Odm".equals(form.getDashboardType())) {
		    if(form.getDashboardTypeKey()!=-1) {
		    	sql.append(" and fa.OdmKey = ").append(form.getDashboardTypeKey());
		    }
		}else if("Product".equals(form.getDashboardType())) {
			if(form.getDashboardTypeKey()!=-1) {
				sql.append(" and fa.ProductKey = ").append(form.getDashboardTypeKey());
			}
		}
		sql.append(") p ")
		   .append("UNPIVOT (value for rowname in(over_plan,under_plan,equal_plan)) p");
		
		
		Query query = getSession().createSQLQuery(sql.toString())
			.addScalar("value", IntegerType.INSTANCE)
			.addScalar("rowName", StringType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> getFaCrossmonthPieChart(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60DaysForecastQty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60DaysForecastQty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60DaysForecastQty],0)then 1 else 0 end) as equal_plan ");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())){
			sql.append("select rowname,value from")
			   .append("(select sum(case when isnull(orderqty,0) < isnull([60daysgrossforecastqty],0) then 1 else 0 end) as over_plan,")
			   .append("sum(case when isnull(orderqty,0) > isnull([60daysgrossforecastqty],0) then 1 else 0 end) as under_plan,")
			   .append("sum(case when isnull(orderqty,0) = isnull([60daysgrossforecastqty],0) then 1 else 0 end) as equal_plan ");
		}
		sql.append("from (select YEAR,MONTH,GeographyName,productKey,odmKey,sum([60DaysForecastQty]) as [60DaysForecastQty], sum([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],sum(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" where fa.Year = ").append(form.getYear())
	       .append(" and fa.Month = ").append(form.getMonth());
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and isnull(fa.[60DaysGrossForecastQty],fa.orderQty) is not null");
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getOdmIds())) {
			sql.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getProductIds())) {
			sql.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		
		if(!StringUtil.isEmpty(form.getCrossMonthType())){
			if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.GeographyName = '").append(form.getCrossMonthTypeValue()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}/*else if("component".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and c.CommodityTypeKey = ").append(form.getCrossMonthTypeKey());
			}*/
		}
		sql.append(") p ")
		   .append("UNPIVOT (value for rowname in(over_plan,under_plan,equal_plan)) p");
		
		
		Query query = getSession().createSQLQuery(sql.toString())
			.addScalar("value", IntegerType.INSTANCE)
			.addScalar("rowName", StringType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FaOverViewChartData> fetchFaCrossMonthOverviewChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sBuffer.append("select isnull(sum(fa.[60DaysForecastQty]),0) as mpsValue,")
				   	.append(" isnull(sum(OrderQty),0) as OrderQty,")
					.append("'Mps' as typeName,")
					.append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),4),0) ")
				    .append(" as typeValue");
		}
		else{
			sBuffer.append("select isnull(sum(fa.[60DaysGrossForecastQty]),0) as mpsValue,")
			    	.append(" isnull(sum(OrderQty),0) as OrderQty,")
			    	.append("'GrossForecast' as typeName,")
			    	.append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),4),0) ")
			        .append(" as typeValue");
		}
		if("Region".equals(form.getDimension())){
			sBuffer.append(" from (select YEAR,MONTH,GeographyName,productKey,odmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa inner join DimGeography region on region.GeographyName = fa.GeographyName");
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" join (")
					   .append(" select product.ProductKey from DimProduct product")
					   .append(" join DimProductFamily family on family.ProductFamilyKey = product.ProductFamilyKey")
				       .append(" where family.ProductFamilyKey in (").append(form.getFamilyIds()).append(")")
				       .append(")productFamily on fa.ProductKey = productFamily.ProductKey");
			}
			sBuffer.append(" where region.GeographyName = '").append(form.getSubDimension()).append("'");
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds()) && !"undefined".equals(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
		}
		else if("Odm".equals(form.getDimension())){
			sBuffer.append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa");
			sBuffer.append(" left join DimProduct pro on fa.productKey = pro.productKey")
				   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			sBuffer.append(" where fa.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
		}
		else if("Product".equals(form.getDimension())){
			sBuffer.append(" from (select YEAR,MONTH,dg.GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa");
			sBuffer.append(" left join DimProduct product");
			sBuffer.append(" on fa.ProductKey = product.ProductKey");
			sBuffer.append(" where fa.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
		}
					
			sBuffer.append(" and fa.Year = ").append(form.getYear())
			   	   .append(" and fa.Month = ").append(form.getMonth())
//				   .append(this.getRemarkWhereCondition(form))
				   ;
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("typeName", StringType.INSTANCE)
				.addScalar("mpsValue", IntegerType.INSTANCE)
				.addScalar("typeValue", FloatType.INSTANCE)//rate
				.addScalar("OrderQty", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FaOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchFaCrossMonthRemarkChartData(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sBuffer.append("select top 15 case when sum([60DaysForecastQty]) is null then 0")
					.append(" else sum([60DaysForecastQty]) end as subDimensionValue,")
					.append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sBuffer.append("select top 15 case when sum([60DaysGrossForecastQty]) is null then 0")
				   .append(" else sum([60DaysGrossForecastQty]) end as subDimensionValue,")
				   .append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),2),0) as faRate,");
		}
		
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" 1 as subDimensionKey,")
				   .append(" fa.GeographyName as subDimensionName")
				   .append(" from (select YEAR,MONTH,GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa");
//				   .append(" left join DimGeography geography on fa.GeographyName = geography.GeographyName");
			sBuffer.append(" left join DimProduct pro on fa.productKey = pro.productKey")
		   	   	   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
			sBuffer.append(" where fa.Year = ").append(form.getYear())
				   .append(" and fa.Month = ").append(form.getMonth());
			
			/**
			 * hi-technology
			 * 
			 */
//			sBuffer.append(this.getWhereCondition(form));
			
			
			if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			sBuffer.append(" group by fa.GeographyName having fa.GeographyName <> ''");
		}
		//for Odm remark chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append("case when fa.ODMKey is null then 0 else fa.ODMKey end as subDimensionKey,")
				   .append("odm.ODMEnglishName as subDimensionName")
				   .append(" from (select YEAR,MONTH,dg.GeographyName as GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa")
				   .append(" left join DimODM odm on fa.ODMKey=odm.ODMKey");
			sBuffer.append(" left join DimProduct pro on fa.productKey = pro.productKey")
			   	   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
	    	if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
	    	if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
	    	if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			sBuffer.append(" group by fa.ODMKey,odm.ODMEnglishName having odm.ODMEnglishName <> ''");
		}
	
		//Product
		else if("Product".equals(form.getDimension())) {
			sBuffer.append("case when fa.productKey is null then 0 else fa.productKey end as subDimensionKey,")
				   .append("product.productEnglishName as subDimensionName ")
				   .append(" from (select YEAR,MONTH,dg.GeographyName as GeographyName,productKey,OdmKey,SUM([60DaysForecastQty]) as [60DaysForecastQty], SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty],SUM(OrderQty) as OrderQty from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,OdmKey) fa")
				   .append(" left join DimProduct  product on fa.productKey = product.productKey ");
			sBuffer.append(" left join DimProduct pro on fa.productKey = pro.productKey")
		   	   	   .append(" left join DimProductFamily family on pro.ProductFamilyKey = family.ProductFamilyKey");
	    	sBuffer.append(" where fa.Year = ").append(form.getYear())
	    		   .append(" and fa.Month = ").append(form.getMonth());
	    	if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.GeographyName = '").append(form.getSubDimension()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sBuffer.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
	    	if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(")");
			}
	    	if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fa.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getFamilyIds())) {
				sBuffer.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fa.ProductKey in(").append(form.getProductIds()).append(")");
			}
	    		sBuffer.append(" group by fa.productKey,product.productEnglishName having product.productEnglishName <> ''");
		}
		
		sBuffer.append(" order by faRate desc");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("subDimensionName", StringType.INSTANCE)
				.addScalar("subDimensionValue", IntegerType.INSTANCE)
				.addScalar("subDimensionKey", IntegerType.INSTANCE)
				.addScalar("faRate", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}
	
	@Override
	public long getFaDetailCount(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(*)");
		sql.append(" from (select YEAR,MONTH,ODMKey,ProductKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty ,dg.GeographyName as GeographyName from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey ) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		//sql.append(" left join DimGeography region on fa.RegionKey = region.GeographyKey");
//		sql.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo");
		
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		if(StringUtils.isNotBlank(form.getGEO())){
			sql.append(" and v.NormalizedGeo = '").append(form.getGEO()).append("'");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sql.append(" and fa.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sql.append(" and fa.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		
		if(!StringUtil.isEmpty(form.getCrossMonthType())){
			if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and v.NormalizedSubgeo = '").append(form.getCrossMonthTypeValue()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and fa.GeographyName =  '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		
		Query query = getSession().createSQLQuery(sql.toString());
		Object result = query.uniqueResult();
		if(result != null){
			return Long.parseLong(result.toString());
		}else{
			return 0;
		}
	}
	
	@Override
	public long getFaGEODetailCount(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(fa.id)");
		sql.append(" from (select YEAR,MONTH,Max(id) AS ID,ODMKey,ProductKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty ,dg.GeographyName as GeographyName from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		//sql.append(" left join DimGeography region on fa.RegionKey = region.GeographyKey");
		//sql.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey");
		sql.append(" left join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		sql.append(" and v.NormalizedGeo = '").append(form.getGEO()).append("'");
//		if("OTHERS".equals(form.getGEO())){
//			sql.append(" and v.NormalizedGeo  is null");
//		}else{
//			sql.append(" and v.NormalizedGeo = '").append(form.getGEO()).append("'");
//		}
		Query query = getSession().createSQLQuery(sql.toString());
		Object result = query.uniqueResult();
		if(result != null){
			return Long.parseLong(result.toString());
		}else{
			return 0;
		}
	}
	
	@Override
	public long getFaPieDetailCount(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(fa.id)");
		sql.append(" from (select YEAR,MONTH,Max(id) AS ID,ODMKey,ProductKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty ,dg.GeographyName as GeographyName from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		sql.append(" and v.NormalizedGeo = '").append(form.getGEO()).append("'");
		Query query = getSession().createSQLQuery(sql.toString());
		Object result = query.uniqueResult();
		if(result != null){
			return Long.parseLong(result.toString());
		}else{
			return 0;
		}
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getFaDetail(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append("(select top ").append(form.getRowCount());
		sql.append(" * from ");
		sql.append("(select  top ").append(form.getEndRow());
		sql.append(" fa.id as id,");
		sql.append(" fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" v.Normalizedgeo as geo,");
		sql.append(" fa.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" isnull(fa.[60DaysForecastQty],0) as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" isnull(fa.[60DaysGrossForecastQty],0) as MPSForecast,");
		}
		sql.append(" isnull(fa.OrderQty,0) as OrderQty,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" case when isnull(fa.[60DaysForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" case when isnull(fa.[60DaysGrossForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysGrossForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysGrossForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		sql.append(" from (select YEAR,MONTH,Max(id) AS ID,ODMKey,ProductKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty ,dg.GeographyName as GeographyName from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo");
		
		
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		
		if(StringUtils.isNotBlank(form.getGEO())){
			sql.append(" and v.NormalizedGeo = '").append(form.getGEO()).append("'");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sql.append(" and fa.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sql.append(" and fa.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		
		if(!StringUtil.isEmpty(form.getCrossMonthType())){
			if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and v.NormalizedSubgeo = '").append(form.getCrossMonthTypeValue()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and fa.GeographyName =  '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType()).append(" ) t");
		}else{
			sql.append(" order by ")
			   .append("  id ").append(form.getSortType()).append(" ) t");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(" ,id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sql.append(" order by id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType());
		}else{
			   sql.append(" order by id ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("MPSForecast", LongType.INSTANCE)
				.addScalar("OrderQty", LongType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
//		query.setFirstResult((form.getCurrentPage()-1)*SysConfig.NUMBER_OF_ROW_COUNT);
//		query.setMaxResults(SysConfig.NUMBER_OF_ROW_COUNT);
		return query.list();
	}
	
	/*@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getFaCrossmonthDetail(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append("(select top ").append(form.getRowCount());
		sql.append(" * from ");
		sql.append("(select  top ").append(form.getEndRow());
		sql.append(" fa.id as id,");
		sql.append(" fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" v.Normalizedgeo as geo,");
		sql.append(" v.NormalizedSubgeo as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" fa.[60DaysForecastQty] as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" fa.[60DaysGrossForecastQty] as MPSForecast,");
		}
		sql.append(" fa.OrderQty as OrderQty,");
		sql.append(" case when fa.[60DaysForecastQty] > fa.orderQty  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  fa.[60DaysForecastQty] < fa.orderQty then 'under plan' when fa.[60DaysForecastQty]  = 0 then 'under plan' else '' end as RootCause");
		sql.append(" from (select YEAR,MONTH,Max(id) AS ID,ODMKey,ProductKey,RegionKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty ,dg.GeographyName as GeographyName from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey,RegionKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join DimGeography region on fa.RegionKey = region.GeographyKey");
		sql.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey");
		sql.append(" join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo");
		
		
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		
		if(StringUtils.isNotBlank(form.getGEO())){
			sql.append(" and geo.GeographyName = '").append(form.getGEO()).append("'");
		}
		if(StringUtils.isNotBlank(form.getRegionIds())){
			sql.append(" and region.GeographyName in(").append(form.getRegionIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sql.append(" and fa.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sql.append(" and fa.productKey in (").append(form.getProductIds()).append(") ");
		}
//		//for Region remark chart
//		if("Region".equals(form.getDimension())) {
//			sql.append(" and fa.RegionKey = ").append(form.getSubDimensionKey());
//		}
//		//for Odm remark chart
//		else if("Odm".equals(form.getDimension())) {
//			sql.append(" and fa.ODMKey = ").append(form.getSubDimensionKey());
//		}
//		//for Product remark chart
//		else if("Product".equals(form.getDimension())) {
//			sql.append(" and fa.ProductKey = ").append(form.getSubDimensionKey());
//		}
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and region.GeographyName =  '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType()).append(" ) t");
		}else{
			sql.append(" order by ")
			   .append("  id ").append(form.getSortType()).append(" ) t");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(" ,id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sql.append(" order by id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType());
		}else{
			   sql.append(" order by id ").append(form.getSortType());
		}
		
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("MPSForecast", StringType.INSTANCE)
				.addScalar("OrderQty", StringType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}*/
	
	/*@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getFaDashboardDetail(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append("(select top ").append(form.getRowCount());
		sql.append(" * from ");
		sql.append("(select  top ").append(form.getEndRow());
		sql.append(" fa.id as id,");
		sql.append(" fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" geo.GeographyName as geo,");
		sql.append(" region.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		sql.append(" fa.[60DaysForecastQty] as MPSForecast,");
		sql.append(" fa.OrderQty as OrderQty");
		sql.append(" from FactMonthlySummaryofProductFA fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join DimGeography region on fa.RegionKey = region.GeographyKey");
		sql.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey");
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType()).append(" ) t");
		}else{
			sql.append(" order by ")
			   .append("  id ").append(form.getSortType()).append(" ) t");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(" ,id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sql.append(" order by id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType());
		}else{
			   sql.append(" order by id ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("MPSForecast", StringType.INSTANCE)
				.addScalar("OrderQty", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}*/
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getFADetailExport(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select fa.id as id,");
		sql.append(" fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" v.Normalizedgeo as geo,");
		sql.append(" fa.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" isnull(fa.[60DaysForecastQty],0) as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" isnull(fa.[60DaysGrossForecastQty],0) as MPSForecast,");
		}
		sql.append(" isnull(fa.OrderQty,0) as OrderQty,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" case when isnull(fa.[60DaysForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" case when isnull(fa.[60DaysGrossForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysGrossForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysGrossForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		sql.append(" from (select YEAR,MONTH,Max(id) AS ID,ODMKey,ProductKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty ,dg.GeographyName as GeographyName from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo");
		
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		
		if(StringUtils.isNotBlank(form.getGEO())){
			sql.append(" and v.NormalizedGeo = '").append(form.getGEO()).append("'");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sql.append(" and fa.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sql.append(" and fa.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		
		if(!StringUtil.isEmpty(form.getCrossMonthType())){
			if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.GeographyName = '").append(form.getCrossMonthTypeValue()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and fa.GeographyName =  '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		
		if("over_plan".equals(form.getSubDimension())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],0)> isnull(fa.orderQty,0) ");
		}else if("equal_plan".equals(form.getSubDimension())) {
			sql.append(" and fa.[60DaysForecastQty] = fa.orderQty ");
		}else if("under_plan".equals(form.getSubDimension())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],0)< isnull(fa.orderQty,0) ");
		}
		sql.append(" order by id");
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("MPSForecast", LongType.INSTANCE)
				.addScalar("OrderQty", LongType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getFAGEODetailExport(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select fa.id as id,");
		sql.append(" fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" v.NormalizedGeo as geo,");
		sql.append(" fa.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" isnull(fa.[60DaysForecastQty],0) as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" isnull(fa.[60DaysGrossForecastQty],0) as MPSForecast,");
		}
		sql.append(" isnull(fa.OrderQty,0) as OrderQty,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" case when isnull(fa.[60DaysForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" case when isnull(fa.[60DaysGrossForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysGrossForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysGrossForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		sql.append(" from (select YEAR,MONTH,Max(id) AS ID,ODMKey,ProductKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty ,dg.GeographyName as GeographyName from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo");
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		
		if(StringUtils.isNotBlank(form.getGEO())){
			sql.append(" and v.NormalizedGeo = '").append(form.getGEO()).append("'");
		}
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("MPSForecast", LongType.INSTANCE)
				.addScalar("OrderQty", LongType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getFaGEODetail(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append("(select top ").append(form.getRowCount());
		sql.append(" * from ");
		sql.append("(select  top ").append(form.getEndRow());
		sql.append(" id,fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" v.NormalizedGeo as geo,");
		sql.append(" fa.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" isnull(fa.[60DaysForecastQty],0) as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" isnull(fa.[60DaysGrossForecastQty],0) as MPSForecast,");
		}
		sql.append(" isnull(fa.OrderQty,0) as OrderQty,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" case when isnull(fa.[60DaysForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" case when isnull(fa.[60DaysGrossForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysGrossForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysGrossForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		sql.append(" from (select YEAR,MONTH,Max(id) AS ID,ODMKey,ProductKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty ,dg.GeographyName as GeographyName from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo");
		
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		
		if(StringUtils.isNotBlank(form.getGEO())){
			sql.append(" and v.NormalizedGeo = '").append(form.getGEO()).append("'");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType()).append(" ) t");
		}else{
			sql.append(" order by ")
			   .append("  id ").append(form.getSortType()).append(" ) t");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(" ,id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sql.append(" order by id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType());
		}else{
			   sql.append(" order by id ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("MPSForecast", LongType.INSTANCE)
				.addScalar("OrderQty", LongType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FADetailView> getFaPieDetail(SearchFaForm form) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append("(select top ").append(form.getRowCount());
		sql.append(" * from ");
		sql.append("(select  top ").append(form.getEndRow());
		sql.append(" id,fa.month as month,");
		sql.append(" family.ProductFamilyEnglishName as family,");
		sql.append(" v.NormalizedGeo as geo,");
		sql.append(" fa.GeographyName as region,");
		sql.append(" dimODM.ODMEnglishName as odm,");
		sql.append(" dimProduct.ProductEnglishName as product,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" isnull(fa.[60DaysForecastQty],0) as MPSForecast,");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" isnull(fa.[60DaysGrossForecastQty],0) as MPSForecast,");
		}
		sql.append(" isnull(fa.OrderQty,0) as OrderQty,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" case when isnull(fa.[60DaysForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" case when isnull(fa.[60DaysGrossForecastQty],0) > isnull(fa.orderQty,0)  then 'over plan' when fa.[60DaysGrossForecastQty] = fa.orderQty then 'equal plan' when  isnull(fa.[60DaysGrossForecastQty],0) < isnull(fa.orderQty,0) then 'under plan' else '' end as RootCause");
		}
		sql.append(" from (select YEAR,MONTH,Max(id) AS ID,ODMKey,ProductKey,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty ,dg.GeographyName as GeographyName from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,productKey,odmKey) fa");
		sql.append(" left join DimODM dimODM on fa.ODMKey = dimODM.ODMKey");
		sql.append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey");
		sql.append(" left join DimProductfamily family on dimProduct.ProductFamilyKey = family.ProductFamilyKey");
		sql.append(" left join factGEOListMapping v on fa.GeographyName = v.NormalizedSubgeo");
		
		sql.append(" where fa.Year = ").append(form.getYear())
		   .append(" and fa.Month = ").append(form.getMonth());
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysForecastQty]>0 or fa.orderQty>0)");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sql.append(" and (fa.[60DaysGrossForecastQty]>0 or fa.orderQty>0)");
		}
		
		//>||<||=
		if("over_plan".equals(form.getSubDimension())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],0)> isnull(fa.orderQty,0) ");
		}else if("equal_plan".equals(form.getSubDimension())) {
			sql.append(" and fa.[60DaysForecastQty] = fa.orderQty ");
		}else if("under_plan".equals(form.getSubDimension())) {
			sql.append(" and isnull(fa.[60DaysForecastQty],0)< isnull(fa.orderQty,0) ");
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sql.append(" and fa.GeographyName in(").append(form.getGeoIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sql.append(" and fa.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sql.append(" and fa.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(!StringUtil.isEmpty(form.getFamilyIds())) {
			sql.append(" and family.ProductFamilyKey in(").append(form.getFamilyIds()).append(")");
		}
		
		if(!StringUtil.isEmpty(form.getCrossMonthType())){
			if("Region".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and v.NormalizedSubgeo = '").append(form.getCrossMonthTypeValue()).append("'");
			}else if("Odm".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ODMKey = ").append(form.getCrossMonthTypeKey());
			}else if("Product".equalsIgnoreCase(form.getCrossMonthType())) {
				sql.append(" and fa.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		
		if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and dimProduct.ProductEnglishName = '" + form.getSubDimension().toUpperCase()+ "' ");
		}else if("Region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sql.append(" and fa.GeographyName =  '" + form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType()).append(" ) t");
		}else{
			sql.append(" order by ")
			   .append("  id ").append(form.getSortType()).append(" ) t");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
			   .append(" ,id ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			form.setReversalSortType("desc");
			sql.append(" order by id ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sql.append(" order by ")
			   .append(form.getSortColumn()).append(" ").append(form.getSortType())
			   .append(" ,id ").append(form.getSortType());
		}else{
			   sql.append(" order by id ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("month", StringType.INSTANCE)
				.addScalar("odm", StringType.INSTANCE)
				.addScalar("family", StringType.INSTANCE)
				.addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE)
				.addScalar("product", StringType.INSTANCE)
				.addScalar("MPSForecast", LongType.INSTANCE)
				.addScalar("OrderQty", LongType.INSTANCE)
				.addScalar("RootCause", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(FADetailView.class));
		return query.list();
	}
	
	@Override
	public List<String> getLackRegion(SearchFaForm form, int target) {/*
		StringBuffer sBuffer=new StringBuffer();
		
		sBuffer.append("select lack.region from (")
			   .append(" select region.GeographyName as region, region.GeographyKey,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())){
			sBuffer.append(" isnull(sum(fa.[60DaysForecastQty]),0) as mps,");
		}else{
			sBuffer.append(" isnull(sum(fa.[60DaysGrossForecastQty]),0) as mps,");
		}
		sBuffer.append(" isnull(sum(fa.OrderQty),0) as Qty")
			   .append(" from FactMonthlySummaryofProductFA fa")
			   .append(" join DimGeography region on fa.regionKey = region.GeographyKey")
			   .append(" where Year = ").append(form.getYear())
			   .append(" and Month = ").append(form.getMonth())
			   .append(" group by region.GeographyName,region.GeographyKey");
			   
	   if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())){
			sBuffer.append(" having isnull(sum(fa.OrderQty),0) *100 / isnull(sum(fa.[60DaysForecastQty]),1) < 90 ) lack");
	   }else{
			sBuffer.append(" having isnull(sum(fa.OrderQty),0) *100 / isnull(sum(fa.[60DaysGrossForecastQty]),1) < 90 ) lack");
	   }
		   
	   Query query = getSession().createSQLQuery(sBuffer.toString());
	   return query.list();
	*/
		return new ArrayList<String>();
	}
	
	@Override
	public List<String> getLackProduct(SearchFaForm form, int target) {
//		StringBuffer sBuffer=new StringBuffer();
//		
//		sBuffer.append("select lack.product from (")
//			   .append(" select dimProduct.ProductEnglishName as product, dimProduct.ProductKey,");
//		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())){
//			sBuffer.append(" isnull(sum(fa.[60DaysForecastQty]),0) as mps,");
//		}else{
//			sBuffer.append(" isnull(sum(fa.[60DaysGrossForecastQty]),0) as mps,");
//		}
//		sBuffer.append(" isnull(sum(fa.OrderQty),0) as Qty")
//			   .append(" from FactMonthlySummaryofProductFA fa")
//			   .append(" left join DimProduct dimProduct on fa.ProductKey = dimProduct.ProductKey")
//			   .append(" where Year = ").append(form.getYear())
//			   .append(" and Month = ").append(form.getMonth())
//			   .append(" group by dimProduct.ProductKey, dimProduct.ProductEnglishName");
//			   
//	   if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())){
//			sBuffer.append(" having isnull(sum(fa.OrderQty),0) *100 / isnull(sum(fa.[60DaysForecastQty]),1) < 90 ) lack");
//	   }else{
//			sBuffer.append(" having isnull(sum(fa.OrderQty),0) *100 / isnull(sum(fa.[60DaysGrossForecastQty]),1) < 90 ) lack");
//	   }
//		   
//	   Query query = getSession().createSQLQuery(sBuffer.toString());
//	   return query.list();
	   return new ArrayList<String>();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<GeoFA> getGeoFa(SearchFaForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select geo.geo as geo,");
//		sBuffer.append("select isnull(geo.geo,'OTHERS') as geo,");
		if(FaTypeEnum.Mps.getTypeName().equals(form.getFaType())) {
			sBuffer.append(" isnull(sum(fa.[60DaysForecastQty]),0) as FAValue,");
			sBuffer.append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysForecastQty],0) then isNull([60DaysForecastQty],0) else isNull(OrderQty,0) end),0),4),0) as FARate");
		}
		else if(FaTypeEnum.GrossForecast.getTypeName().equals(form.getFaType())) {
			sBuffer.append(" isnull(sum(fa.[60DaysGrossForecastQty]),0) as FAValue,");
			sBuffer.append(" isnull(round(sum(case when isNull(OrderQty,0) > isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end)*1.0/nullIf(sum(case when isNull(OrderQty,0) < isNull([60DaysGrossForecastQty],0) then isNull([60DaysGrossForecastQty],0) else isNull(OrderQty,0) end),0),4),0) as FARate");
		}
		sBuffer.append(" from (select YEAR,MONTH,SUM([60DaysForecastQty]) as [60DaysForecastQty],SUM([60DaysGrossForecastQty]) as [60DaysGrossForecastQty], SUM(OrderQty) as OrderQty,dg.GeographyName as GeographyName,odmkey,productKey from FactMonthlySummaryofProductFA m inner join DimGeography dg on dg.GeographyKey = m.RegionKey where m.versionDateKey = (select max(versionDateKey) from FactMonthlySummaryofProductFA) group by YEAR,MONTH,dg.GeographyName,odmkey,productKey) fa");
		sBuffer.append(" join factGEOListMapping geo on fa.GeographyName = geo.NormalizedSubgeo");
//		sBuffer.append(" left join factGEOListMapping geo on fa.GeographyName = geo.NormalizedSubgeo");
		sBuffer.append(" where Year = ").append(form.getYear())
		   	   .append(" and Month = ").append(form.getMonth())
			   .append(" group by geo.geo");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("Geo", StringType.INSTANCE)
				.addScalar("FAValue", FloatType.INSTANCE)
				.addScalar("FARate", FloatType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GeoFA.class));
		List<GeoFA> result = query.list();
		return result;
	}
	
	@SuppressWarnings("unused")
	private String getWhereCondition(SearchFaForm form){
		StringBuffer sb = new StringBuffer();
		if(StringUtils.isNotBlank(form.getRegionIds())){
			sb.append(" and fa.regionkey in (")
			.append("select GeographyKey from DimGeography where GeographyName in (").append(form.getRegionIds()).append(")) ");
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and fa.regionkey in (")
			.append(" select r.GeographyKey from DimGeography r")
			.append(" inner join DimGeography g on r.ParentGeographyKey = g.GeographyKey where g.GeographyName in (").append(form.getGeoIds()).append(")) ");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and fa.ODMKey in (").append(form.getOdmIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and fa.productKey in (").append(form.getProductIds()).append(") ");
		}
		if(StringUtils.isNotBlank(form.getFamilyIds())){
			sb.append(" and fa.ProductFamily in (").append(form.getFamilyIds()).append(") ");
		}
		return sb.toString();
	}
	
}
