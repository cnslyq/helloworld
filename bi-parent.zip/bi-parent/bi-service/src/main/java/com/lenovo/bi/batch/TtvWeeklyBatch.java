package com.lenovo.bi.batch;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.bi.engine.ComponentAllocator;
import com.lenovo.bi.engine.MtmCvConfigMap;
import com.lenovo.bi.engine.ProductKeyPmsWaveIdMap;
import com.lenovo.bi.enumobj.JobStatusEnum;
import com.lenovo.bi.enumobj.PhaseEnum;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.BiWeeklyProcessStatus;
import com.lenovo.bi.model.EtlWeeklyStatus;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.model.SGATtvWeeklyDetail;
import com.lenovo.bi.model.SGATtvWeeklySummary;
import com.lenovo.bi.model.TtvWeeklyDetail;
import com.lenovo.bi.model.TtvWeeklySummary;
import com.lenovo.bi.service.npi.helper.NpiCommittedCVAllocatorBiHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.CollectionUtil;
import com.lenovo.bi.util.SysConstants;
import com.lenovo.common.logging.Logger;
import com.lenovo.common.logging.LoggerFactory;

@Service
public class TtvWeeklyBatch implements BatchRunner {
	@Autowired
	private TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper;

	@Autowired
	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;

	@Autowired
	private NpiCommittedCVAllocatorBiHelper committedCVAllocatorBiHelper;
	
	@Autowired
	private ProductKeyPmsWaveIdMap productKeyPmsWaveIdMap;

	@Autowired
	private MtmCvConfigMap mtmCvConfigMap;

	@Autowired
	private NpiWaveSummaryBatch npiWaveSummaryBatch;

	private static Logger LOGGER = LoggerFactory.getLogger(SysConstants.LOG_WEEKLY_BATCH_CATALOG);

	private static int SLEEP_TIME = 5 * 60 * 1000; // 5 min
	private static int WAIT_TIME = 3 * 60 * 60 * 1000; // 3 hours, use negative
														// number if want to
														// wait forever

	// private static int NUMBER_OF_FUTURE_WEEKS =
	// SysConfig.NUMBER_OF_FUTURE_WEEKS;

	@Override
	public void runBatch() {
		// Version date is never in the future!
		Date versionDate = retrieveVersionDate();

		if (versionDate == null) {
			LOGGER.warn("Cannot retrieve version date.");
			return;
		}

		// Set the process status to incomplete
		BiWeeklyProcessStatus biWeeklyProcessStatus = new BiWeeklyProcessStatus();
		Date now = new Date();
		biWeeklyProcessStatus.setVersionDate(versionDate);
		biWeeklyProcessStatus.setProcessDate(now);
		biWeeklyProcessStatus.setJobStatus(JobStatusEnum.RUNNING);
		biWeeklyProcessStatus.setLastModifiedDate(now);
		ttvOutlookServiceBiHelper.addBiWeeklyProcessStatus(biWeeklyProcessStatus);
		StringWriter sw = null;
		PrintWriter pw = null;
		try {
			cleanUpOldData(versionDate);

			LOGGER.info("Run TTV weekly batch using version date " + versionDate);

			// Process the future portion of this versionDate

			List<Date> targetDates = new ArrayList<Date>();
			Date targetDate = CalendarUtil.getMondayDateByDate(versionDate);
			for (int i = 0; i < 20; i++) {
				targetDates.add(targetDate);
				targetDate = CalendarUtil.getMondayDateByWeeks(targetDate, 1);
			}

			// Run 分货逻辑
			ComponentAllocator componentAllocator = new ComponentAllocator(targetDates, versionDate, mtmCvConfigMap);
			componentAllocator.setTtvOutlookServiceBiHelper(ttvOutlookServiceBiHelper);
			componentAllocator.setTtvOutlookServiceDwHelper(ttvOutlookServiceDwHelper);
			componentAllocator.run();
			
//			NpiCommittedCVAllocator committedCVAllocator = new NpiCommittedCVAllocator();
//			committedCVAllocator.setVersionDate(versionDate);
//			committedCVAllocator.run();
			
			//SGA ttv
			processSGAFutureData(PhaseEnum.NPI, targetDates, versionDate, componentAllocator);
			processSGATTVCaculation(versionDate);
			//Do we ever use this in SC?  -- added by Henry Lian
//			processFutureData(PhaseEnum.SC, targetDates, versionDate, componentAllocator);

			//SLE ttv
			processSLEFutureData(PhaseEnum.NPI, targetDates, versionDate, componentAllocator);
			processSLETtvCaculation(versionDate);
			
			// Run batch for NPI project summary
			npiWaveSummaryBatch.runBatch(versionDate);

			// Set the process status to complete
			biWeeklyProcessStatus.setJobStatus(JobStatusEnum.COMPLETE);
		} catch (Exception e) {
			e.printStackTrace();
			sw = new StringWriter();// modify by Nicolas on Jul 1,2014
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			pw.flush();
			sw.flush();
			biWeeklyProcessStatus.setStacktrace(sw.toString());
			biWeeklyProcessStatus.setJobStatus(JobStatusEnum.FAILED);
		} finally {
			if (sw != null) {
				try {
					sw.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			if (pw != null) {
				pw.close();
			}
			biWeeklyProcessStatus.setLastModifiedDate(new Date());
			ttvOutlookServiceBiHelper.updateBiWeeklyProcessStatus(biWeeklyProcessStatus);
		}
	}

	private void processSLETtvCaculation(Date versionDate) {
		List<Integer> pmsWaveIds = retrievePmsWaveIdsForProcessing(versionDate);
		for (Integer pmsWaveId : pmsWaveIds) {
			processTtvCalculation(pmsWaveId, versionDate);
		}
	}

	private void cleanUpOldData(Date versionDate) {
		ttvOutlookServiceBiHelper.deleteTtvWeeklySummaryForVersionDate(versionDate);
		ttvOutlookServiceBiHelper.clearSGATtvWeeklySummary(versionDate);
		
		ttvOutlookServiceBiHelper.deleteWeeklyComponentCommitmentOnMtmCtoForVersionDate(versionDate);
		ttvOutlookServiceBiHelper.deleteWeeklyComponentCommitmentOnOrderForecastForVersionDate(versionDate);
		ttvOutlookServiceBiHelper.deleteOrderDataForVersionDate(versionDate);
		ttvOutlookServiceBiHelper.deleteForecastDataForVersionDate(versionDate);
	}

	private void processSLEFutureData(PhaseEnum phase, List<Date> targetDates, Date versionDate, ComponentAllocator componentAllocator) {
		for (int i = 0; i < targetDates.size(); i++) {

			Date targetDate = targetDates.get(i);

			LOGGER.info("Process target date " + targetDate);

			List<TtvWeeklyDetail> npiWeeklyDetails = ttvOutlookServiceBiHelper.getNpiWeeklyDetail(targetDate, versionDate);
			
			ttvOutlookServiceBiHelper.cleanUpSLETTVWeeklyDetails(npiWeeklyDetails);
			
			// Calculate ODM capacity available to the product
			/*
			ProductCommittedOdmCapacityCalculator<TtvWeeklyDetail> committedOdmCapacityOnProductCalculator = new SLEProductCommittedOdmCapacityCalculator(
					targetDate, versionDate);
			committedOdmCapacityOnProductCalculator.setTtvOutlookServiceDwHelper(ttvOutlookServiceDwHelper);
			committedOdmCapacityOnProductCalculator.calculate(npiWeeklyDetails);

			Map<String, TtvWeeklyDetail> weeklyDetailMap = new HashMap<String, TtvWeeklyDetail>();
			for (TtvWeeklyDetail detail : npiWeeklyDetails) {
				String productKey = productKeyPmsWaveIdMap.getProductKeyFromPmsWaveId(Integer.toString(detail.getPmsWaveId()));
				weeklyDetailMap.put(productKey, detail);
			}

			// Calculate tooling capacity available to the product
			ProductCommittedToolingCapacityCalculator<TtvWeeklyDetail> committedToolingCapacityOnProductCalculator = new SLEProductCommittedToolingCapacityCalculator(
					targetDate, versionDate, productKeyPmsWaveIdMap);
			committedToolingCapacityOnProductCalculator.setTtvOutlookServiceDwHelper(ttvOutlookServiceDwHelper);
			committedToolingCapacityOnProductCalculator.calculate(weeklyDetailMap);
			*/

			/*
			// Calculate future demand and sort for FIFO
			Map<BomNumberGeographyOdmCvKeyKey, Integer> mtmComponentQuantities = componentAllocator.getMtmComponentQuotas().get(i);
			Map<BomNumberGeographyOdmCvKeyKey, Integer> ctoComponentQuantities = componentAllocator.getCtoComponentQuotas().get(i);

			ComponentQuota mtmComponentQuota = new ComponentQuota(mtmComponentQuantities);
			ComponentQuota ctoComponentQuota = new ComponentQuota(ctoComponentQuantities);

			boolean includeBacklog = i == 0;

			WeeklyFifoSorter weeklyFifoSorter = new SLEWeeklyFifoSorter(weeklyDetailMap, phase, targetDate, versionDate, includeBacklog, mtmComponentQuota,
					ctoComponentQuota, TTVPhase.sle);
			weeklyFifoSorter.setTtvOutlookServiceBiHelper(ttvOutlookServiceBiHelper);
			weeklyFifoSorter.setTtvOutlookServiceDwHelper(ttvOutlookServiceDwHelper);
			weeklyFifoSorter.setMtmCvConfigMap(mtmCvConfigMap);
			weeklyFifoSorter.setProductKeyPmsWaveIdMap(productKeyPmsWaveIdMap);
			weeklyFifoSorter.run();

			List<OrderData> orderDataList = weeklyFifoSorter.getOrderDataList();
			List<ForecastData> forecastDataList = weeklyFifoSorter.getForecastDataList();

			// Allocate supply commit
			SupplyCapabilityAllocator<TtvWeeklyDetail> supplyCapabilityAllocator = new SLESupplyCapabilityAllocator(mtmCvConfigMap, phase, targetDate,
					versionDate, ttvOutlookServiceBiHelper);
			supplyCapabilityAllocator.processOrderData(orderDataList, mtmComponentQuota, weeklyDetailMap);
			supplyCapabilityAllocator.processForecastData(forecastDataList, ctoComponentQuota, weeklyDetailMap);
			*/

			// Make a copy so the diminished ODM and tooling capacities on
			// TtvWeeklyDetail are not flushed to database
			List<TtvWeeklyDetail> copiedNpiWeeklyDetails = CollectionUtil.copyList(npiWeeklyDetails);
			Map<String, TtvWeeklyDetail> copiedWeeklyDetailMap = new HashMap<String, TtvWeeklyDetail>();

			for (TtvWeeklyDetail copiedDetail : copiedNpiWeeklyDetails) {
				String productKey = productKeyPmsWaveIdMap.getProductKeyFromPmsWaveId(Integer.toString(copiedDetail.getPmsWaveId()));
				copiedWeeklyDetailMap.put(productKey, copiedDetail);
			}

			//use new entity for FIFO allocation
/*			List<NpiWeeklyComponentCommitmentOnOrder> orderDataList = 
					committedCVAllocatorBiHelper.getUnfulfilledOrder(versionDate, targetDate, TTVPhase.sle.name());
			List<NpiWeeklyComponentCommitmentOnForecast> forecastDataList = 
					committedCVAllocatorBiHelper.getUnfulfilledForecast(versionDate, targetDate, TTVPhase.sle.name());
			
			// Allocate ODM commit
			OdmCapacityAllocator<TtvWeeklyDetail> odmCapacityAllocator = new SLEOdmCapacityAllocator(copiedWeeklyDetailMap, orderDataList, forecastDataList);
			odmCapacityAllocator.run();

			// Allocate tooling commit
			ToolingCapacityAllocator<TtvWeeklyDetail> toolingCapacityAllocator = new SLEToolingCapacityAllocator(copiedWeeklyDetailMap, orderDataList,
					forecastDataList);
			toolingCapacityAllocator.run();*/

/*			LOGGER.debug("Print order data:");
			//for (OrderData orderData : orderDataList) {
			for (NpiWeeklyComponentCommitmentOnOrder orderData : orderDataList) {
				LOGGER.debug(orderData.toString());
			}

			LOGGER.debug("Print forecast data:");
			//for (ForecastData forecastData : forecastDataList) {
			for (NpiWeeklyComponentCommitmentOnForecast forecastData : forecastDataList) {
				LOGGER.debug(forecastData.toString());
			}

			// Save orderData and forecastData
			//ttvOutlookServiceBiHelper.addOrderData(orderDataList);
			//ttvOutlookServiceBiHelper.addForecastData(forecastDataList);
			committedCVAllocatorBiHelper.saveCommitmentOnOrder(orderDataList);
			committedCVAllocatorBiHelper.saveCommitmentOnForecast(forecastDataList);*/

			// Summarize supply commit of orders and forecasts to products
			// (TtvWeeklyDetail)
//			for (OrderData orderData : orderDataList) {
//				TtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(orderData.getProductKey());
//				if (weeklyDetail != null) // add by nicolas on Jul 1,2014
//					weeklyDetail.setSupplyCommit(weeklyDetail.getSupplyCommit() + orderData.getMaterialCommit());
//			}
//
//			for (ForecastData forecastData : forecastDataList) {
//				TtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(forecastData.getProductKey());
//				if (weeklyDetail != null) // add by nicolas on Jul 1,2014
//					weeklyDetail.setSupplyCommit(weeklyDetail.getSupplyCommit() + forecastData.getMaterialCommit());
//			}

			// Save TtvWeeklyDetail
			ttvOutlookServiceBiHelper.updateNpiWeeklyDetail(npiWeeklyDetails);
		}
	}

	private void processSGAFutureData(PhaseEnum phase, List<Date> targetDates, Date versionDate, ComponentAllocator componentAllocator) {
		for (int i = 0; i < targetDates.size(); i++) {

			Date targetDate = targetDates.get(i);

			LOGGER.info("Process target date " + targetDate);

			List<SGATtvWeeklyDetail> npiWeeklyDetails = ttvOutlookServiceBiHelper.getSGANpiWeeklyDetail(targetDate, versionDate);
			
			ttvOutlookServiceBiHelper.cleanUpSGATTVWeeklyDetails(npiWeeklyDetails);

			// Calculate ODM capacity available to the product
/*			ProductCommittedOdmCapacityCalculator<SGATtvWeeklyDetail> committedOdmCapacityOnProductCalculator = new SGAProductCommittedOdmCapacityCalculator(
					targetDate, versionDate);
			committedOdmCapacityOnProductCalculator.setTtvOutlookServiceDwHelper(ttvOutlookServiceDwHelper);
			committedOdmCapacityOnProductCalculator.calculate(npiWeeklyDetails);

			Map<String, SGATtvWeeklyDetail> weeklyDetailMap = new HashMap<String, SGATtvWeeklyDetail>();
			for (SGATtvWeeklyDetail detail : npiWeeklyDetails) {
				String productKey = productKeyPmsWaveIdMap.getProductKeyFromPmsWaveId(Integer.toString(detail.getPmsWaveId()));
				weeklyDetailMap.put(productKey, detail);
			}

			// Calculate tooling capacity available to the product
			ProductCommittedToolingCapacityCalculator<SGATtvWeeklyDetail> committedToolingCapacityOnProductCalculator = new SGAProductCommittedToolingCapacityCalculator(
					targetDate, versionDate, productKeyPmsWaveIdMap);
			committedToolingCapacityOnProductCalculator.setTtvOutlookServiceDwHelper(ttvOutlookServiceDwHelper);
			committedToolingCapacityOnProductCalculator.calculate(weeklyDetailMap);*/

			/*
			// Calculate future demand and sort for FIFO
			Map<BomNumberGeographyOdmCvKeyKey, Integer> mtmComponentQuantities = componentAllocator.getMtmComponentQuotas().get(i);
			Map<BomNumberGeographyOdmCvKeyKey, Integer> ctoComponentQuantities = componentAllocator.getCtoComponentQuotas().get(i);

			ComponentQuota mtmComponentQuota = new ComponentQuota(mtmComponentQuantities);
			ComponentQuota ctoComponentQuota = new ComponentQuota(ctoComponentQuantities);

			boolean includeBacklog = i == 0;

			WeeklyFifoSorter weeklyFifoSorter = new SGAWeeklyFifoSorter(weeklyDetailMap, phase, targetDate, versionDate, includeBacklog, mtmComponentQuota,
					ctoComponentQuota, TTVPhase.sga);
			weeklyFifoSorter.setTtvOutlookServiceBiHelper(ttvOutlookServiceBiHelper);
			weeklyFifoSorter.setTtvOutlookServiceDwHelper(ttvOutlookServiceDwHelper);
			weeklyFifoSorter.setMtmCvConfigMap(mtmCvConfigMap);
			weeklyFifoSorter.setProductKeyPmsWaveIdMap(productKeyPmsWaveIdMap);
			weeklyFifoSorter.run();

			List<OrderData> orderDataList = weeklyFifoSorter.getOrderDataList();
			List<ForecastData> forecastDataList = weeklyFifoSorter.getForecastDataList();

			// Allocate supply commit
			SupplyCapabilityAllocator<SGATtvWeeklyDetail> supplyCapabilityAllocator = new SGASupplyCapabilityAllocator(mtmCvConfigMap, phase, targetDate,
					versionDate, ttvOutlookServiceBiHelper);
			supplyCapabilityAllocator.processOrderData(orderDataList, mtmComponentQuota, weeklyDetailMap);
			supplyCapabilityAllocator.processForecastData(forecastDataList, ctoComponentQuota, weeklyDetailMap);**
			*/

			// Make a copy so the diminished ODM and tooling capacities on
			// TtvWeeklyDetail are not flushed to database
			List<SGATtvWeeklyDetail> copiedNpiWeeklyDetails = CollectionUtil.copyList(npiWeeklyDetails);
			Map<String, SGATtvWeeklyDetail> copiedWeeklyDetailMap = new HashMap<String, SGATtvWeeklyDetail>();

			for (SGATtvWeeklyDetail copiedDetail : copiedNpiWeeklyDetails) {
				String productKey = productKeyPmsWaveIdMap.getProductKeyFromPmsWaveId(Integer.toString(copiedDetail.getPmsWaveId()));
				copiedWeeklyDetailMap.put(productKey, copiedDetail);
			}

			//use new entity for FIFO allocation
/*			List<NpiWeeklyComponentCommitmentOnOrder> orderDataList = 
					committedCVAllocatorBiHelper.getUnfulfilledOrder(versionDate, targetDate, TTVPhase.sga.name());
			List<NpiWeeklyComponentCommitmentOnForecast> forecastDataList = 
					committedCVAllocatorBiHelper.getUnfulfilledForecast(versionDate, targetDate, TTVPhase.sga.name());
			
			// Allocate ODM commit
			OdmCapacityAllocator<SGATtvWeeklyDetail> odmCapacityAllocator = new SGAOdmCapacityAllocator(copiedWeeklyDetailMap, orderDataList, forecastDataList);
			odmCapacityAllocator.run();

			// Allocate tooling commit
			ToolingCapacityAllocator<SGATtvWeeklyDetail> toolingCapacityAllocator = new SGAToolingCapacityAllocator(copiedWeeklyDetailMap, orderDataList,
					forecastDataList);
			toolingCapacityAllocator.run();

			LOGGER.debug("Print order data:");
			//for (OrderData orderData : orderDataList) {
			for (NpiWeeklyComponentCommitmentOnOrder orderData : orderDataList) {
				LOGGER.debug(orderData.toString());
			}

			LOGGER.debug("Print forecast data:");
			//for (ForecastData forecastData : forecastDataList) {
			for (NpiWeeklyComponentCommitmentOnForecast forecastData : forecastDataList) {
				LOGGER.debug(forecastData.toString());
			}

			// Save orderData and forecastData
			//ttvOutlookServiceBiHelper.addOrderData(orderDataList);
			//ttvOutlookServiceBiHelper.addForecastData(forecastDataList);
			committedCVAllocatorBiHelper.saveCommitmentOnOrder(orderDataList);
			committedCVAllocatorBiHelper.saveCommitmentOnForecast(forecastDataList);
*/
			// Summarize supply commit of orders and forecasts to products
			// (TtvWeeklyDetail)
//			for (OrderData orderData : orderDataList) {
//				SGATtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(orderData.getProductKey());
//				if (weeklyDetail != null) // add by nicolas on Jul 1,2014
//					if(weeklyDetail.getSupplyCommit() == -1){
//						weeklyDetail.setSupplyCommit(orderData.getMaterialCommit());
//					} else{
//						weeklyDetail.setSupplyCommit(weeklyDetail.getSupplyCommit() + orderData.getMaterialCommit());
//					}
//					
//			}
//
//			for (ForecastData forecastData : forecastDataList) {
//				SGATtvWeeklyDetail weeklyDetail = weeklyDetailMap.get(forecastData.getProductKey());
//				if (weeklyDetail != null) // add by nicolas on Jul 1,2014
//					if(weeklyDetail.getSupplyCommit() == -1){
//						weeklyDetail.setSupplyCommit(forecastData.getMaterialCommit());
//					} else{
//						weeklyDetail.setSupplyCommit(weeklyDetail.getSupplyCommit() + forecastData.getMaterialCommit());
//					}
//					
//			}

			// Save TtvWeeklyDetail
			ttvOutlookServiceBiHelper.updateSGANpiWeeklyDetail(npiWeeklyDetails);

		}
	}

	private void processSGATTVCaculation(Date versionDate) {
		List<SGATtvWeeklyDetail> npiWeeklyDetails = ttvOutlookServiceBiHelper.getSGANpiWeeklyDetail(versionDate);
		if (npiWeeklyDetails != null && npiWeeklyDetails.isEmpty())
			return;

		Map<Integer, List<SGATtvWeeklyDetail>> weeklyDetailMap = new HashMap<Integer, List<SGATtvWeeklyDetail>>();
		for (SGATtvWeeklyDetail ttvWeeklyDetail : npiWeeklyDetails) {
			Integer pmsWaveId = ttvWeeklyDetail.getPmsWaveId();
			if (weeklyDetailMap.get(pmsWaveId) == null) {
				weeklyDetailMap.put(pmsWaveId, new ArrayList<SGATtvWeeklyDetail>());
			}
			weeklyDetailMap.get(pmsWaveId).add(ttvWeeklyDetail);
		}

		List<SGATtvWeeklySummary> weeklySummaries = new ArrayList<SGATtvWeeklySummary>();

		Iterator<Integer> keys = weeklyDetailMap.keySet().iterator();
		while (keys.hasNext()) {
			Integer pmsWaveId = keys.next();
			
			//pre validate
			//no ttv calc happens if either rampcommit or forecast is null
			Map<Long, Integer> rampCommitMap = ttvOutlookServiceDwHelper.getRampCommitByWaveId(pmsWaveId);
			Map<Date, Integer> forecastMap = ttvOutlookServiceDwHelper.getSGAForecastByWaveId(pmsWaveId);
			if (rampCommitMap.isEmpty() ||forecastMap.isEmpty() ){
				continue;
			}
			
			List<SGATtvWeeklyDetail> weeklyDetails = weeklyDetailMap.get(pmsWaveId);

			Collections.sort(weeklyDetails, new Comparator<SGATtvWeeklyDetail>() {
				@Override
				public int compare(SGATtvWeeklyDetail o1, SGATtvWeeklyDetail o2) {
					return o1.getTargetDate().compareTo(o2.getTargetDate());
				}
			});

			ttvOutlookServiceDwHelper.setRampCommit(pmsWaveId, weeklyDetails, rampCommitMap);
			ttvOutlookServiceBiHelper.setOutput(weeklyDetails, versionDate);
			ttvOutlookServiceDwHelper.setForecast(pmsWaveId, weeklyDetails, forecastMap);
			ttvOutlookServiceBiHelper.setToGoForecast(weeklyDetails);
			// get all excluded orders for this wave
			//if target version is past, use sunday of the version date
			Date excludeOrderVersionDate = versionDate.before(CalendarUtil.getMonday())?CalendarUtil.getSundayDateByDate(versionDate):CalendarUtil.getTodayWithoutMins();
			List<NpiOrder> excludeOrders = ttvOutlookServiceBiHelper.getTTVExcludedOrder(pmsWaveId, TTVPhase.sga, excludeOrderVersionDate);
			ttvOutlookServiceBiHelper.excludeOrders(weeklyDetails, excludeOrders);
			ttvOutlookServiceBiHelper.setToGoOrder(weeklyDetails);

			List<SGATtvWeeklySummary> ttvWeeklySummaries = ttvOutlookServiceDwHelper.calculateSGATtvWeeklySummary(pmsWaveId, weeklyDetails);
			if (ttvWeeklySummaries != null) {
				weeklySummaries.addAll(ttvWeeklySummaries);
			}
		}
		ttvOutlookServiceBiHelper.updateSGANpiWeeklyDetail(npiWeeklyDetails);
		ttvOutlookServiceBiHelper.addSGANpiWeeklySummary(weeklySummaries);
	}

	private void processTtvCalculation(int pmsWaveId, Date versionDate) {
		LOGGER.info("Process PMS wave Id " + pmsWaveId);

		// Process all TtvWeeklySummary from the full list of TtvWeeklyDetail
		List<TtvWeeklyDetail> details = ttvOutlookServiceBiHelper.getNpiWeeklyDetail(pmsWaveId, versionDate);

		List<NpiOrder> excludedOrders = ttvOutlookServiceBiHelper.getTTVExcludedOrder(pmsWaveId, TTVPhase.sle, versionDate);

		List<TtvWeeklySummary> summaries = ttvOutlookServiceBiHelper.calculateSLETTVWeeklySummary(versionDate, details, excludedOrders);
		ttvOutlookServiceBiHelper.PersistTtvWeeklySummary(summaries);
	}

	private List<Integer> retrievePmsWaveIdsForProcessing(Date versionDate) {
		return ttvOutlookServiceBiHelper.getPmsWaveIdsForWeeklyVersionDate(versionDate);
	}

	@SuppressWarnings("unused")
	private List<Integer> retrieveSGAPmsWaveIdsForProcessing(Date versionDate) {
		return ttvOutlookServiceBiHelper.getSGAPmsWaveIdsForWeeklyVersionDate(versionDate);
	}

	protected Date retrieveVersionDate() {
		long startTime = System.currentTimeMillis();
		while (System.currentTimeMillis() - startTime <= WAIT_TIME || WAIT_TIME < 0) {
			EtlWeeklyStatus latestEtlWeeklyStatus = ttvOutlookServiceBiHelper.getLatestEtlWeeklyStatus();

			if (latestEtlWeeklyStatus == null || !latestEtlWeeklyStatus.getComplete()) {
				try {
					LOGGER.info("Waiting for weekly ETL to complete...");
					Thread.sleep(SLEEP_TIME);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				Date versionDate = latestEtlWeeklyStatus.getVersionDate();
				LOGGER.info("Version date to process: " + versionDate);
				return versionDate;
			}
		}

		LOGGER.warn("ETL is not complete after waiting for 3 hours.");

		return null;
	}

}
