package com.lenovo.bi.dao.common.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.CvQuantity;
import com.lenovo.bi.dto.GlobalCV;
import com.lenovo.bi.dto.MtmCvQuantity;
import com.lenovo.bi.dto.SingleUnitCvConfig;

@Repository
public class MtmDaoImpl extends HibernateBaseDaoImplDw {
	/**
	 * Return CV configuration of a single MTM unit
	 * @param bomNumber
	 * @return
	 */
	public SingleUnitCvConfig getSingleUnitCvConfigOfMtm(String bomNumber) {
		StringBuilder sql = new StringBuilder("select cvf.GlobalCVKey as cvKey, cvf.quantity ")
			.append("from FactPORinGlobalCVFormat cvf ")
			.append("where cvf.MTMBOMNumber = ? ");
		
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(CvQuantity.class));
		query.setParameter(0, bomNumber);
		
		@SuppressWarnings("unchecked")
		List<CvQuantity> cvQuantityList = query.list();
		
		SingleUnitCvConfig config = null;
		if (cvQuantityList.size() > 0) {
			config = new SingleUnitCvConfig();
			for (CvQuantity cq : cvQuantityList) {		
				config.addCv(cq.getCvKey(), cq.getQuantity());
			}
		}
				
		return config;	
	}
	
	/**
	 * Return all the global CV and quantity for all MTMs
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<MtmCvQuantity> getAllMtmCvQuantity() {
		StringBuilder sql = new StringBuilder("select cvf.MTMBOMNumber as bomNumber, cvf.GlobalCVKey as cvKey, cvf.quantity ")
		.append("from FactPORinGlobalCVFormat cvf ");
	
		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(MtmCvQuantity.class));

		return query.list();
	}
	@SuppressWarnings("unchecked")
	public List<GlobalCV> getAllGolobalCV(){
		StringBuilder sql = new StringBuilder("select globalCVKey,parts.CommodityType as c,cv.CommodityValue as v from dimGlobalCV cv ");
		sql.append("left join DimCommodityType parts on parts.CommodityTypeKey = cv.CommodityTypeKey");
		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("globalCVKey", StringType.INSTANCE)
				.addScalar("c", StringType.INSTANCE)
				.addScalar("v", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GlobalCV.class));
		return query.list();
	}
}
