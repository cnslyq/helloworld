package com.lenovo.bi.dao.sc.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.sc.FpsdDao;
import com.lenovo.bi.dto.DimOrderForDetractor;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.dto.sc.FpsdRemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.GeographyType;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;
import com.lenovo.common.model.PagerInformation;

@Repository
public class FpsdDaoImpl extends HibernateBaseDaoImplDw implements FpsdDao {
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchFpsdOverViewChartData(SearchOtsForm form) {
		
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum,status.FPSDStatus as scStatusName")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" left join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey");
		if(form.isShowQuarterOverview()){//modify by Dolly 2014-08-10 Defect #10725
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
	    else {
	    	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
	    			.append(" and fpsd.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		//for SC overview:fpsd
		if(!StringUtil.isEmpty(form.getGeoIds())) {
			sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		
		sBuffer.append(" group by status.FPSDStatus having status.FPSDStatus <> '' order by status.FPSDStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FpsdRemarkChartData> fetchDimensionRemarkDataList(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append("select SUB.RegionKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.FPSDStatus='OK' then SUB.OrderQuantity else 0 end) as ok,")
					.append("sum(case when SUB.FPSDStatus='Early' then SUB.OrderQuantity else 0 end) as early,")
					.append("sum(case when SUB.FPSDStatus='Late' then SUB.OrderQuantity else 0 end) as late,")
					.append("sum(case when SUB.FPSDStatus='To-be OK' then SUB.OrderQuantity else 0 end) as toBeOk,")
					.append("sum(case when SUB.FPSDStatus='To-be Early' then SUB.OrderQuantity else 0 end) as toBeEarly,")
					.append("sum(case when SUB.FPSDStatus='To-be Late' then SUB.OrderQuantity else 0 end) as toBeLate,")
					.append("sum(SUB.OrderQuantity) as total,")
					.append(" 'Region' as remarkType")
					.append(" from (select fpsd.*,status.FPSDStatus,geography.GeographyName as dimensionName ")
			   		.append(" from FactMonthlySummaryofFPSD fpsd ")
			   		.append(" left join  DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey");
			   		
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on fpsd.regionkey = geoRegion.regionKey");
				
			}
			else {
				sBuffer.append(" left join DimGeography geography on geography.GeographyKey = fpsd.RegionKey");
			}
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where fpsd.Year = ").append(form.getYear())
	    			   .append(" and fpsd.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), fpsd.Year)+'-'+CONVERT(nvarchar(20), fpsd.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			sBuffer.append(" and fpsd.FPSDStatusKey in (1,2,3,4,5,6)");
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				sBuffer.append(" and geography.geographyname = 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				sBuffer.append(" and geography.geographyname <> 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:ODM or Product
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			} 
			
			sBuffer.append(")SUB group by SUB.RegionKey,SUB.dimensionName order by SUB.RegionKey");
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append("select SUB.ODMKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.FPSDStatus='OK' then SUB.OrderQuantity else 0 end) as ok,")
					.append("sum(case when SUB.FPSDStatus='Early' then SUB.OrderQuantity else 0 end) as early,")
					.append("sum(case when SUB.FPSDStatus='Late' then SUB.OrderQuantity else 0 end) as late,")
					.append("sum(case when SUB.FPSDStatus='To-be OK' then SUB.OrderQuantity else 0 end) as toBeOk,")
					.append("sum(case when SUB.FPSDStatus='To-be Early' then SUB.OrderQuantity else 0 end) as toBeEarly,")
					.append("sum(case when SUB.FPSDStatus='To-be Late' then SUB.OrderQuantity else 0 end) as toBeLate,")
					.append("sum(SUB.OrderQuantity) as total,")
					.append(" 'Odm' as remarkType")
					.append(" from (select fpsd.*,status.FPSDStatus,odm.ODMEnglishName as dimensionName ")
			   		.append(" from FactMonthlySummaryofFPSD fpsd ")
			   		.append(" left join  DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
			   		.append(" left join DimODM odm on fpsd.ODMKey = odm.ODMKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on fpsd.regionkey = geoRegion.regionKey");
				
			}
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where fpsd.Year = ").append(form.getYear())
	    			   .append(" and fpsd.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), fpsd.Year)+'-'+CONVERT(nvarchar(20), fpsd.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			sBuffer.append(" and fpsd.FPSDStatusKey in (1,2,3,4,5,6)");
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:Region or Product
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			} 
			
			sBuffer.append(")SUB group by SUB.ODMKey,SUB.dimensionName order by SUB.ODMKey");
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append("select SUB.ProductKey as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.FPSDStatus='OK' then SUB.OrderQuantity else 0 end) as ok,")
					.append("sum(case when SUB.FPSDStatus='Early' then SUB.OrderQuantity else 0 end) as early,")
					.append("sum(case when SUB.FPSDStatus='Late' then SUB.OrderQuantity else 0 end) as late,")
					.append("sum(case when SUB.FPSDStatus='To-be OK' then SUB.OrderQuantity else 0 end) as toBeOk,")
					.append("sum(case when SUB.FPSDStatus='To-be Early' then SUB.OrderQuantity else 0 end) as toBeEarly,")
					.append("sum(case when SUB.FPSDStatus='To-be Late' then SUB.OrderQuantity else 0 end) as toBeLate,")
					.append("sum(SUB.OrderQuantity) as total,")
					.append(" 'Product' as remarkType")
					.append(" from (select fpsd.*,status.FPSDStatus,product.ProductEnglishName as dimensionName ")
			   		.append(" from FactMonthlySummaryofFPSD fpsd ")
			   		.append(" join  DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
			   		.append(" join DimProduct product on fpsd.ProductKey = product.ProductKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on fpsd.regionkey = geoRegion.regionKey");
				
			}	
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where fpsd.Year = ").append(form.getYear())
	    			   .append(" and fpsd.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), fpsd.Year)+'-'+CONVERT(nvarchar(20), fpsd.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			sBuffer.append(" and fpsd.FPSDStatusKey in (1,2,3,4,5,6)");
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:Region or Odm
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			} 
			
			sBuffer.append(")SUB group by SUB.ProductKey,SUB.dimensionName order by SUB.ProductKey");
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			//sBuffer.append("select SUB.DetractorKey as dimensionKey,SUB.dimensionName as dimensionName,")
			sBuffer.append("select 0 as dimensionKey,SUB.dimensionName as dimensionName,")
					.append("sum(case when SUB.FPSDStatus='OK' then SUB.OrderQuantity else 0 end) as ok,")
					.append("sum(case when SUB.FPSDStatus='Early' then SUB.OrderQuantity else 0 end) as early,")
					.append("sum(case when SUB.FPSDStatus='Late' then SUB.OrderQuantity else 0 end) as late,")
					.append("sum(case when SUB.FPSDStatus='To-be OK' then SUB.OrderQuantity else 0 end) as toBeOk,")
					.append("sum(case when SUB.FPSDStatus='To-be Early' then SUB.OrderQuantity else 0 end) as toBeEarly,")
					.append("sum(case when SUB.FPSDStatus='To-be Late' then SUB.OrderQuantity else 0 end) as toBeLate,")
					.append("sum(SUB.OrderQuantity) as total,")
					.append(" 'Detractor' as remarkType")
					.append(" from (select fpsd.*,status.FPSDStatus,isNull(detractor.Level1,'UNKNOWN') as dimensionName ")
			   		.append(" from FactMonthlySummaryofFPSD fpsd ")
			   		.append(" left join  DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
			   		.append(" left join DimDetractor detractor on fpsd.DetractorKey = detractor.DetractorKey");
			
			if(form.isShowGeoOverview()) {
				sBuffer.append(" left join ")
			       .append("(")
			       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
			       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
			       .append(")")
			       .append(" as geoRegion on fpsd.regionkey = geoRegion.regionKey");
				
			}   	
			
			if(form.getStartDate().equals(form.getEndDate())){
				sBuffer.append(" where fpsd.Year = ").append(form.getYear())
	    			   .append(" and fpsd.Month = ").append(form.getMonth());
			}else{
				sBuffer.append(" where CONVERT(nvarchar(20), fpsd.Year)+'-'+CONVERT(nvarchar(20), fpsd.Month) between '")
				   .append(form.getStartDate()).append("'")
				   .append(" and '").append(form.getEndDate()).append("'");
			}
			
			sBuffer.append(" and fpsd.FPSDStatusKey in (1,2,3,4,5,6)");
			//sBuffer.append(" and fpsd.DetractorKey is not null");
			
			if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
				sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
				sBuffer.append(form.getPoNumberItemOrderNo());
				sBuffer.append(")");
			}
			
			if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			//dashboard overview chart:Region or Odm or Porduct
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()) && !form.isShowGeoOverview())
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
			
			if(form.isShowGeoOverview()) {
				if(form.getDashboardTypeKey() != -1)
					sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
			} 
			
			//group by fpsd.RegionKey, fpsd.FPSDStatusKey having fpsd.RegionKey <> '' order by fpsd.RegionKey,fpsd.FPSDStatusKey
			sBuffer.append(" )SUB group by SUB.dimensionName");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
								.addScalar("dimensionKey", IntegerType.INSTANCE)
								.addScalar("dimensionName", StringType.INSTANCE)
								.addScalar("ok", IntegerType.INSTANCE)
								.addScalar("early", IntegerType.INSTANCE)
								.addScalar("late", IntegerType.INSTANCE)
								.addScalar("toBeOk", IntegerType.INSTANCE)
								.addScalar("toBeEarly", IntegerType.INSTANCE)
								.addScalar("toBeLate", IntegerType.INSTANCE)
								.addScalar("total", IntegerType.INSTANCE)
								.addScalar("remarkType", StringType.INSTANCE)
								.setResultTransformer(Transformers.aliasToBean(FpsdRemarkChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<KeyNameObject> fetchDimensions(SearchOtsForm form) {
		PagerInformation pagerInfo = form.getPagerInfo();
		StringBuffer sBuffer = new StringBuffer();
		form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
			if(!form.isShowGeoOverview()) {
				 sBuffer.append("select fpsd.RegionKey as objKey,geography.GeographyName as objName,'Region' as type");
			}
			else{
				sBuffer.append("select parentGeography.GeographyKey as objKey,parentGeography.GeographyName as objName,'Region' as type");
			}
			sBuffer.append(" from FactMonthlySummaryofFPSD fpsd ")
		    		.append(" inner join DimGeography geography on fpsd.RegionKey = geography.GeographyKey");
			if(form.isShowGeoOverview()){
				sBuffer.append(" inner join DimGeography parentGeography on parentGeography.GeographyKey = geography.parentGeographyKey");
			}
	    	sBuffer.append(" where fpsd.Year * 100 + fpsd.Month between ").append(form.getStartDate())
	    		.append(" and  ").append(form.getEndDate());
			
	    	if(form.getOrderTypeId() == 1) {
	    		sBuffer.append(" and geography.geographyname = 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				sBuffer.append(" and geography.geographyname <> 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			
			//show geo or region overview 
			if(!form.isShowGeoOverview()) {
				sBuffer.append(" group by fpsd.RegionKey,geography.GeographyName");
			}
			else{
				sBuffer.append(" group by parentgeography.geographykey,parentgeography.geographyname ");
			}
			sBuffer.append(" order by count(fpsd.FPSDStatusKey) desc");
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
		    sBuffer.append("select fpsd.ODMKey as objKey,odm.ODMEnglishName as objName,'Odm' as type")
		    .append(" from FactMonthlySummaryofFPSD fpsd ")
		    .append(" left join DimODM odm on fpsd.ODMKey = odm.ODMKey");
		    sBuffer.append(" where fpsd.Year * 100 + fpsd.Month between ").append(form.getStartDate())
    		.append(" and  ").append(form.getEndDate());
			
	    	if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			sBuffer.append(" group by fpsd.ODMKey,odm.ODMEnglishName having fpsd.ODMKey <> '' order by count(fpsd.FPSDStatusKey) desc");
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
		    sBuffer.append("select fpsd.ProductKey as objKey,product.ProductEnglishName as objName,'Product' as type")
		    .append(" from FactMonthlySummaryofFPSD fpsd ")
		    .append(" left join DimProduct product on fpsd.ProductKey = product.ProductKey");
		    sBuffer.append(" where fpsd.Year * 100 + fpsd.Month between ").append(form.getStartDate())
    		.append(" and  ").append(form.getEndDate());
			
	    	if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			sBuffer.append(" group by fpsd.ProductKey,product.ProductEnglishName having fpsd.ProductKey <> '' order by count(fpsd.FPSDStatusKey) desc");
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objKey", IntegerType.INSTANCE)
				.addScalar("objName", StringType.INSTANCE)
				.addScalar("type", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(KeyNameObject.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int fetchDimensionsCount(SearchOtsForm form) {
		//PagerInformation pagerInfo = form.getPagerInfo();
		StringBuffer sBuffer = new StringBuffer();
		form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
			if(!form.isShowGeoOverview()) {
				 sBuffer.append("select count(distinct fpsd.RegionKey) as objCount ");
			}else{
				sBuffer.append("select count(distinct parentGeography.GeographyKey) as objCount ");
			}
			sBuffer.append(" from FactMonthlySummaryofFPSD fpsd ")
		    .append(" inner join DimGeography geography on fpsd.RegionKey = geography.GeographyKey");
			if(form.isShowGeoOverview()){
				sBuffer.append(" inner join DimGeography parentGeography on parentGeography.GeographyKey = geography.parentGeographyKey");
			}
			sBuffer.append(" where fpsd.Year *100 + fpsd.Month between ").append(form.getStartDate())
    		.append(" and ").append(form.getEndDate());
			
	    	if(form.getOrderTypeId() == 1) {
	    		sBuffer.append(" and geography.geographyname = 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				sBuffer.append(" and geography.geographyname <> 'PRC'");
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			sBuffer.append(" order by count(fpsd.FPSDStatusKey) desc");
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
		    sBuffer.append("select count(distinct fpsd.ODMKey) as objCount")
		    .append(" from FactMonthlySummaryofFPSD fpsd ")
		    .append(" inner join DimODM odm on fpsd.ODMKey = odm.ODMKey");
	    	sBuffer.append(" where fpsd.Year *100 + fpsd.Month between ").append(form.getStartDate())
	    		.append(" and ").append(form.getEndDate());
			
	    	if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
		    sBuffer.append("select count(distinct fpsd.ProductKey) as objCount ")
		    .append(" from FactMonthlySummaryofFPSD fpsd ")
		    .append(" inner join DimProduct product on fpsd.ProductKey = product.ProductKey");
		    sBuffer.append(" where fpsd.Year *100 + fpsd.Month between ").append(form.getStartDate())
    		.append(" and ").append(form.getEndDate());
			
	    	if(form.getOrderTypeId() == 1) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
				}
			}
			
			if(form.getOrderTypeId() == 2) {
				if(form.getOrderSubTypeId() != -1) {
					sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
				}
				else {
					sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
				}
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("objCount", IntegerType.INSTANCE);
		
		List<Object> dimensionsCountList = query.list();
		int dimensionsCount = 0;
		if(CollectionUtils.isNotEmpty(dimensionsCountList)){
			dimensionsCount = (Integer) dimensionsCountList.get(0);
		}
		return dimensionsCount;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchFpsdRemarkChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum,status.FPSDStatus as scStatusName")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" left join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey");
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			//Defect #10750 modify by Dolly 2014-08-13
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		}else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
				   .append(form.getQuarterFrom())
				   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		    		.append(" and fpsd.Month = ").append(form.getMonth());
			}
		}
		
		sBuffer.append(" and fpsd.FPSDStatusKey in (2,3,5,6)");
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())) {
				sBuffer.append(" and fpsd.DetractorKey is null");
			}
			else {
				sBuffer.append(" and fpsd.DetractorKey in (")
						.append(" select detractorKey from dimDetractor where level1 = '")
						.append(form.getSubDimension()).append("')");
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		sBuffer.append(" group by status.FPSDStatus having status.FPSDStatus <> '' order by status.FPSDStatus");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScRemarkChartData> fetchFpsdGeoRemarkChartData(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum,status.FPSDStatus as scStatusName")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" left join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey");
		
		if(form.getDashboardTypeKey() != -1) {
			if("Region".equals(form.getDashboardType())) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on fpsd.regionkey = geoRegion.regionKey");
			}
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			//Defect #10750 modify by Dolly 2014-08-13
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		}else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
				   .append(form.getQuarterFrom())
				   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		    		.append(" and fpsd.Month = ").append(form.getMonth());
			}
		}
		
		sBuffer.append(" and fpsd.FPSDStatusKey in (2,3,5,6)");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.DetractorKey in (").append("select detractorKey from DimDetractor where level1 = '")
			.append(form.getSubDimension()).append("')");
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				/*if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else */if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		if(form.getDashboardTypeKey() != -1)
			sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
		sBuffer.append(" group by status.FPSDStatus having status.FPSDStatus <> '' order by status.FPSDStatus");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScRemarkChartData.class));
		
		return query.list();
	}

	@Override
	public Integer fetchToltalDimensionFpsdData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum")
			   .append(" from FactMonthlySummaryofFPSD fpsd");
			   //.append(" left join ")
			   //.append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey");
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			//Defect #10750 modify by Dolly 2014-08-13
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
				   .append(form.getQuarterFrom())
				   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		    		.append(" and fpsd.Month = ").append(form.getMonth());
			}
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		sBuffer.append(" and fpsd.FPSDStatusKey in (2,3,5,6)");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			//sBuffer.append(" and fpsd.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			//sBuffer.append(" and fpsd.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			//sBuffer.append(" and fpsd.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			//sBuffer.append(" and fpsd.DetractorKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//sBuffer.append(" group by status.FPSDStatus having status.FPSDStatus <> '' order by status.FPSDStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@Override
	public Integer fetchToltalGeoDimensionFpsdData(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum")
			   .append(" from FactMonthlySummaryofFPSD fpsd");
			   //.append(" left join ")
			   //.append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey");
		
		if(form.getDashboardTypeKey() != -1) {
			if("Region".equals(form.getDashboardType())) {
				sBuffer.append(" left join ")
				       .append("(")
				       .append(" select distinct geo.geographykey as geoKey,region.geographykey as regionKey,geo.geographyname as geoName,geo.geographytype as geographytype")
				       .append(" from dimgeography geo join dimgeography region on geo.geographykey = region.ParentGeographyKey")
				       .append(")")
				       .append(" as geoRegion on fpsd.regionkey = geoRegion.regionKey");
			}
		}
		
		if(ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			//Defect #10750 modify by Dolly 2014-08-13
			form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
			form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		}
		else {
			//quarter
			if(form.isShowQuarterOverview()) {
				form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
				form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		    	sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
				   .append(form.getQuarterFrom())
				   .append(" and ").append(form.getQuarterTo());
			}
			//month
			else {
		    	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		    		.append(" and fpsd.Month = ").append(form.getMonth());
			}
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		sBuffer.append(" and fpsd.FPSDStatusKey in (2,3,5,6)");
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for region remark chart, and overview chart maybe ODM or Product
		if("Region".equals(form.getDimension())) {
			//sBuffer.append(" and fpsd.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:ODM or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Odm remark chart, and overview chart maybe Region or Product
		else if("Odm".equals(form.getDimension())) {
			//sBuffer.append(" and fpsd.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Product
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Product remark chart, and overview chart maybe ODM or Region
		else if("Product".equals(form.getDimension())) {
			//sBuffer.append(" and fpsd.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		//for Detractor remark chart, and overview chart maybe ODM or Region or Product
		else if("Detractor".equals(form.getDimension())) {
			//sBuffer.append(" and fpsd.DetractorKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			
			if(form.getDashboardTypeKey() != -1) {
				/*if("Region".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getDashboardTypeKey());
				else */if("Odm".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getDashboardTypeKey());
				else if("Product".equals(form.getDashboardType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getDashboardTypeKey());
			}
			
			//crossmonth overview chart:Region or Odm or Porduct
			if(form.getCrossMonthTypeKey() != -1) {
				if("Region".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
				else if("Odm".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
				else if("Product".equals(form.getCrossMonthType()))
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			}
		}
		if(form.getDashboardTypeKey() != -1)
			sBuffer.append(" and geoRegion.geoKey = ").append(form.getDashboardTypeKey());
		//sBuffer.append(" group by status.FPSDStatus having status.FPSDStatus <> '' order by status.FPSDStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer)query.uniqueResult();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchFpsdDashboardOverViewChartData(SearchOtsForm form) {
		form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum,status.FPSDStatus as scStatusName")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" left join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
			   .append(" where fpsd.Year * 100 + fpsd.month between ").append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
			if(!form.isShowGeoOverview()) {
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getSubDimensionKey());
			}else{
				sBuffer.append(" and fpsd.RegionKey in( select geographykey from dimgeography where parentGeographyKey = '")
				.append(form.getSubDimensionKey()).append("')");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		sBuffer.append(" group by status.FPSDStatus having status.FPSDStatus <> '' order by status.FPSDStatus");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> fetchFpsdCrossMonthOverviewChartData(SearchOtsForm form) {
		form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
		form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum,status.FPSDStatus as scStatusName")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" left join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey");
		if(form.isShowQuarterOverview())
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
	    else {
	    	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
	    		.append(" and fpsd.Month = ").append(form.getMonth());
	    }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar) + '_' +cast(fpsd.POItem as nvarchar) + '_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		sBuffer.append(" group by status.FPSDStatus having status.FPSDStatus <> '' order by status.FPSDStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ScOverViewChartData> getOverviewOverall(SearchOtsForm form) {
		//Defect #10750 modify by Dolly 2014-08-13
		form.setStartDate(CalendarUtil.yearMonthConvert(form.getStartDate()));
		form.setEndDate(CalendarUtil.yearMonthConvert(form.getEndDate()));
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum,status.FPSDStatus as scStatusName")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" left join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
			   .append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getStartDate())
			   .append(" and ").append(form.getEndDate());
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//crossmonth overview chart:Region or Odm or Porduct
		/*if(form.getCrossMonthTypeKey() != -1) {
			if("Region".equals(form.getCrossMonthType()))
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
			else if("Odm".equals(form.getCrossMonthType()))
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
			else if("Product".equals(form.getCrossMonthType()))
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
		}*/
		
		if("Region".equals(form.getCrossMonthType())) {
			sBuffer.append(" and fpsd.RegionKey = ").append(form.getCrossMonthTypeKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getCrossMonthType())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getCrossMonthTypeKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getCrossMonthType())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getCrossMonthTypeKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}	
		
		sBuffer.append(" group by status.FPSDStatus having status.FPSDStatus <> '' order by status.FPSDStatus");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderNum", IntegerType.INSTANCE)
				.addScalar("scStatusName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));
		
		return query.list();
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<String> fetchFpsdOverViewOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select fpsd.OrderKey as orderKey")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" inner join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey");
		if(form.isShowQuarterOverview()){//modify by Dolly 2014-08-10 Defect #10725
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
	    else {
	    	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
	    			.append(" and fpsd.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
				/*.setResultTransformer(Transformers.aliasToBean(String.class));*/
		
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<String> fetchFpsdOverViewRemarkOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select fpsd.OrderKey as orderKey")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" inner join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey ");
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimGeography geo on fpsd.RegionKey = geo.GeographyKey and geo.GeographyType = '"
					+ GeographyType.Region.name()
					+ "' and geo.GeographyName = '"
					+ form.getSubDimension().toUpperCase()+ "' ");
		}else if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimODM odm on fpsd.ODMKey = odm.ODMKey and odm.ODMEnglishName = '"
					+ form.getSubDimension().toUpperCase() + "' ");
		}else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimProduct pro on fpsd.ProductKey = pro.ProductKey and pro.ProductEnglishName = '"
					+ form.getSubDimension().toUpperCase() + "' ");
		}else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			sBuffer.append("INNER JOIN DimDetractor detractor on fpsd.DetractorKey = detractor.DetractorKey and upper(detractor.Level1) = '"
					+ form.getSubDimension().toUpperCase() + "' ");
		}
		if(form.isShowQuarterOverview()){//modify by Dolly 2014-08-10 Defect #10725
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
	    else {
	    	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
	    			.append(" and fpsd.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
				/*.setResultTransformer(Transformers.aliasToBean(String.class));*/
		
		return query.list();
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<String> fetchFpsdCrossMonthOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  fpsd.OrderKey as orderKey")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" inner join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
	    else {
	    	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
	    		.append(" and fpsd.Month = ").append(form.getMonth());
	    }
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		//for Region overview chart
		if("Region".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.RegionKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDimension())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE);
				/*.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class));*/
		
		return query.list();
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<String> fetchFpsdDashboardOverOderDetail(SearchOtsForm form) {

		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  fpsd.OrderKey as orderKey")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" left join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
			   .append(" where fpsd.Year = ").append(form.getYear())
			   .append(" and fpsd.Month = ").append(form.getMonth());
		
		//for Region overview chart
		if("Region".equals(form.getDashboardType())) {
			if(!form.isShowGeoOverview()) {
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getSubDimensionKey());
			}else{
				sBuffer.append(" and fpsd.RegionKey in( select geographykey from dimgeography where parentGeographyKey = '")
				.append(form.getSubDimensionKey()).append("')");
			}
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getDashboardType())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getDashboardType())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("orderKey", StringType.INSTANCE)
				/*.setResultTransformer(Transformers.aliasToBean(ScOverViewChartData.class))*/;
		
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> fetchFpsdOrderKeysByDims(SearchOtsForm form) {
		StringBuffer sb = new StringBuffer();
		sb.append("select fpsd.OrderKey from FactMonthlySummaryofFPSD fpsd");
		if(StringUtils.isNotBlank(form.getLevel1Detractor()) || StringUtils.isNotBlank(form.getLevel2Detractor())){
			sb.append(" inner join dimdetractor d on d.detractorKey = fpsd.detractorKey");
		}
		sb.append(" where fpsd.year*100 + fpsd.month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			sb.append(" and  fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and  fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and  fpsd.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sb.append(" and  fpsd.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor())){
			sb.append(" and upper(d.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor())){
			sb.append(" and upper(d.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("orderKey", StringType.INSTANCE);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PieDivider> getDetractorMainDivider(SearchOtsForm form) {
		StringBuffer sb = new StringBuffer();
		if(form.getLevel() == 2){
			sb.append("select ISNULL(upper(rtrim(ltrim(d.Level2))),'UNKNOWN') as level2Name,count(fpsd.FPSDStatusKey) as level2Num ");
		}else{
			sb.append("select ISNULL(upper(rtrim(ltrim(d.Level1))),'UNKNOWN') as level1Name,count(fpsd.FPSDStatusKey) as level1Num ");
		}
		sb.append(" from FactMonthlySummaryofFPSD fpsd");
		sb.append(" left join dimdetractor d on d.detractorkey = fpsd.detractorkey ")
			.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
			.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
			;
		sb.append(" where fpsd.year*100 + fpsd.month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sb.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sb.append(form.getPoNumberItemOrderNo());
			sb.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sb.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sb.append(" and  fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and  fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and  fpsd.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sb.append(" and  fpsd.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor())){
			sb.append(" and upper(d.Level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(form.getLevel() == 2){
			sb.append(" group by d.Level2 ");
		}else{
			sb.append(" group by d.Level1 ");
		}
		Query query;
		if(form.getLevel() == 2){
			query = getSession().createSQLQuery(sb.toString())
					.addScalar("level2Name", StringType.INSTANCE)
					.addScalar("level2Num", IntegerType.INSTANCE)
					.setResultTransformer(Transformers.aliasToBean(PieDivider.class));
		}else{
			query = getSession().createSQLQuery(sb.toString())
					.addScalar("level1Name", StringType.INSTANCE)
					.addScalar("level1Num", IntegerType.INSTANCE)
					.setResultTransformer(Transformers.aliasToBean(PieDivider.class));
		}
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DimOrderForDetractor> getDetractorMainUnknownDivider(
			SearchOtsForm form) {
		StringBuffer sb = new StringBuffer();
		sb.append("select d.Level1 as level1Name,count(fpsd.FPSDStatusKey) as level1Num ")
			.append(" from FactMonthlySummaryofFPSD fpsd");
		sb.append(" left join dimdetractor d on d.detractorkey = fpsd.detractorkey ")
			.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
			.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
		;
		sb.append(" where fpsd.year*100 + fpsd.month between ").append(CalendarUtil.yearMonthConvert(form.getStartDate()))
		.append(" and ").append(CalendarUtil.yearMonthConvert(form.getEndDate()));
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sb.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sb.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sb.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sb.append(" and  fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sb.append(" and  fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sb.append(" and  fpsd.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sb.append(" and  fpsd.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		sb.append(" group by d.Level1 having d.Level1 is null ");
		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("level1Name", StringType.INSTANCE)
				.addScalar("level1Num", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(PieDivider.class));
		return query.list();
	}

	@Override
	public int getOverviewOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum")
		   .append(" from FactMonthlySummaryofFPSD fpsd")
		   .append(" left join ")
		   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		 			.append(" and fpsd.Month = ").append(form.getMonth());
		 }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	public int getCrossMonthOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" left join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
			   .append(" left join DimDetractor dimDetractor on fpsd.DetractorKey =  dimDetractor.DetractorKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		 			.append(" and fpsd.Month = ").append(form.getMonth());
		 }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and fpsd.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	public int getDashboardOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" left join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
			   .append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
			   .append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
			   .append(" left join DimDetractor dimDetractor on fpsd.DetractorKey =  dimDetractor.DetractorKey");
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		 			.append(" and fpsd.Month = ").append(form.getMonth());
		 }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey = ").append(form.getRemarkSubDimensionKey());
			else 
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getOverviewOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("fpsd.POItem as poItem,")
				.append("fpsd.PONumber as poNumber,")
				.append("fpsd.POItem as itemNo,")
				.append("fpsd.OrderQuantity as qty,")
				.append("fpsd.OrderDate as orderDate,")
				.append("fpsd.RSDDate as rsd,")
				.append("fpsd.FPSDDate as fpsd,")
				.append("fpsd.ShipDate as shippedDate,")
				.append("fpsd.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("fpsd.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofFPSD fpsd")
				.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
				.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on fpsd.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
				
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		 			.append(" and fpsd.Month = ").append(form.getMonth());
		 }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getCrossMonthOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("fpsd.POItem as poItem,")
				.append("fpsd.PONumber as poNumber,")
				.append("fpsd.POItem as itemNo,")
				.append("fpsd.OrderQuantity as qty,")
				.append("fpsd.OrderDate as orderDate,")
				.append("fpsd.RSDDate as rsd,")
				.append("fpsd.FPSDDate as fpsd,")
				.append("fpsd.ShipDate as shippedDate,")
				.append("fpsd.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("fpsd.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofFPSD fpsd")
				.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
				.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on fpsd.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		 			.append(" and fpsd.Month = ").append(form.getMonth());
		 }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			sBuffer.append(" and fpsd.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getDashboardOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("fpsd.POItem as poItem,")
				.append("fpsd.PONumber as poNumber,")
				.append("fpsd.POItem as itemNo,")
				.append("fpsd.OrderQuantity as qty,")
				.append("fpsd.OrderDate as orderDate,")
				.append("fpsd.RSDDate as rsd,")
				.append("fpsd.FPSDDate as fpsd,")
				.append("fpsd.ShipDate as shippedDate,")
				.append("fpsd.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("fpsd.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofFPSD fpsd")
				.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
				.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on fpsd.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		 			.append(" and fpsd.Month = ").append(form.getMonth());
		 }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}	
		sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey = ").append(form.getRemarkSubDimensionKey());
			else 
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			sBuffer.append(" and fpsd.ODMKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			sBuffer.append(" and fpsd.ProductKey = ").append(form.getRemarkSubDimensionKey());
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension())){
				sBuffer.append(" and dimDetractor.level1 is null ");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getRemarkSubDimension()).append("'");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	public int getRemarkOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum ")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" inner join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey ");
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimGeography geo on fpsd.RegionKey = geo.GeographyKey ");
		}else if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimODM odm on fpsd.ODMKey = odm.ODMKey ");
		}else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append("INNER JOIN DimProduct pro on fpsd.ProductKey = pro.ProductKey ");
		}else if("Detractor".equalsIgnoreCase(form.getDimension())	&& !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
				sBuffer.append(" INNER JOIN DimDetractor detractor on fpsd.DetractorKey = detractor.DetractorKey ");
			}
			else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append("INNER JOIN DimDetractor detractor on fpsd.DetractorKey = detractor.DetractorKey ");
			}
		}
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where fpsd.Year = ").append(form.getYear())
    			   .append(" and fpsd.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), fpsd.Year)+'-'+CONVERT(nvarchar(20), fpsd.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if(form.isShowAllRemarkOrder()){
			sBuffer.append(" and status.FPSDStatusKey in(").append(form.getScStatus()).append(")");
		}
		else{
			sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		}
		
		if("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append("and geo.GeographyName in(" +  form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append("and geo.GeographyName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}else if("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append("and odm.ODMEnglishName in(" +  form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append("and odm.ODMEnglishName = '"	+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}else if("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and pro.ProductEnglishName in(" +  form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append(" and pro.ProductEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
			
		}else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
				sBuffer.append(" and upper(detractor.Level1)  in(" +  form.getSubDimension() + ") ");
			}
			else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append(" and upper(detractor.Level1) = '" + form.getSubDimension().toUpperCase() + "' ");
			}else if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				if("Region".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
						sBuffer.append(" and fpsd.RegionKey = ").append(form.getOverViewSubDimensionKey());				
				}
				else if("Odm".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
						sBuffer.append(" and fpsd.ODMKey = ").append(form.getOverViewSubDimensionKey());			
				}
				else if("Product".equals(form.getOverViewDimension())) {
					if(form.getOverViewSubDimensionKey() != -1)
						sBuffer.append(" and fpsd.ProductKey = ").append(form.getOverViewSubDimensionKey());			
				}
				
				sBuffer.append(" and fpsd.DetractorKey is null");
			 }
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer) query.uniqueResult();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<TtvGridDetractorCodeView> getRemarkOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		if(form.isShowAllRemarkOrder()){
			sBuffer.append("(select top ").append(form.getRowCount() + form.getOrderNumber()).append(" * from ");
		}else{
			sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		}
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("fpsd.POItem as poItem,")
				.append("fpsd.PONumber as poNumber,")
				.append("fpsd.POItem as itemNo,")
				.append("fpsd.OrderQuantity as qty,")
				.append("fpsd.OrderDate as orderDate,")
				.append("fpsd.RSDDate as rsd,")
				.append("fpsd.FPSDDate as fpsd,")
				.append("fpsd.ShipDate as shippedDate,")
				.append("fpsd.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("fpsd.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofFPSD fpsd")
				.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
				.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on fpsd.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where fpsd.Year = ").append(form.getYear())
    			   .append(" and fpsd.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), fpsd.Year)+'-'+CONVERT(nvarchar(20), fpsd.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "'");
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and region.GeographyName in ("+ form.getSubDimension() + ") ");
			}
			else{
				sBuffer.append(" and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if(form.isShowAllRemarkOrder()){
			sBuffer.append(" and status.FPSDStatusKey in(").append(form.getScStatus()).append(")");
		}
		else{
			sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		}
		
		if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and dimODM.ODMEnglishName in(" +  form.getSubDimension() + ")");
			}
			else{
				sBuffer.append(" and dimODM.ODMEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}
		else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			if(form.isShowAllRemarkOrder()){
				sBuffer.append(" and dimProduct.ProductEnglishName in(" +  form.getSubDimension() + ")");
			}
			else{
				sBuffer.append(" and dimProduct.ProductEnglishName = '"
						+ form.getSubDimension().toUpperCase()+ "' ");
			}
		}
		else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
			if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
				sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
				
				sBuffer.append(" union all ");
				sBuffer.append("select  top ").append(form.getOrderNumber());
				sBuffer.append(" dimODM.ODMEnglishName as odm,")
						.append("geo.GeographyName as geo,")
						.append("region.GeographyName as region,")
						.append("country.GeographyName as country,")
						.append("dimProduct.ProductEnglishName as product,")
						.append("mtm.BOMNumberAlternateKey as pn,")
						.append("mtm.MTMEnglishDescription as itemDesc,")
						.append("fpsd.POItem as poItem,")
						.append("fpsd.PONumber as poNumber,")
						.append("fpsd.POItem as itemNo,")
						.append("fpsd.OrderQuantity as qty,")
						.append("fpsd.OrderDate as orderDate,")
						.append("fpsd.RSDDate as rsd,")
						.append("fpsd.FPSDDate as fpsd,")
						.append("fpsd.ShipDate as shippedDate,")
						.append("fpsd.IsShipped as shipped,")
						.append("'' as level1,")
						.append("'' as level2 ,")
						.append("fpsd.LateReason2 as level3 ")
						.append(" from FactMonthlySummaryofFPSD fpsd")
						.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
						.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
						.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
						.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
						.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
						.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
						.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
				
				if(form.isShowQuarterOverview()){
					form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
					form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
					sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
					   .append(form.getQuarterFrom())
					   .append(" and ").append(form.getQuarterTo());
				}
				else {
				 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
				 			.append(" and fpsd.Month = ").append(form.getMonth());
				 }
				
				if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
					sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "'");
					if(form.isShowAllRemarkOrder()){
						sBuffer.append(" and region.GeographyName in ("+ form.getSubDimension() + ") ");
					}
					else{
						sBuffer.append(" and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
					}
				}
				
				if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
					sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
					sBuffer.append(form.getPoNumberItemOrderNo());
					sBuffer.append(")");
				}
				
				if(form.getOrderTypeId() == 1) {
					if(form.getOrderSubTypeId() != -1) {
						sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
					}
					else {
						sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
					}
				}
				
				if(form.getOrderTypeId() == 2) {
					if(form.getOrderSubTypeId() != -1) {
						sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
					}
					else {
						sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
					}
				}
				
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and status.FPSDStatusKey in(").append(form.getScStatus()).append(")");
				}
				else{
					sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
				}
				sBuffer.append(" and fpsd.DetractorKey is null");
			}else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getSubDimension().toUpperCase() + "' ");
			}else if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
				sBuffer.append(" and fpsd.DetractorKey is null");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

	@Override
	public int getDetractorOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum ")
			   	.append(" from FactMonthlySummaryofFPSD fpsd")
				.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
				.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				;
		
		if(!"UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())) {
			if(StringUtils.isNotBlank(form.getLevel1Detractor()) || StringUtils.isNotBlank(form.getLevel2Detractor())){
				sBuffer.append(" inner join dimdetractor d on d.detractorKey = fpsd.detractorKey");
			}
		}
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}else {
	    	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
	    			.append(" and fpsd.Month = ").append(form.getMonth());
	    }
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}	
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sBuffer.append(" and  fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sBuffer.append(" and  fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and  fpsd.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sBuffer.append(" and  fpsd.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		
		if(StringUtils.isNotBlank(form.getLevel1Detractor())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())) 
				sBuffer.append(" and fpsd.DetractorKey is null");
			else
				sBuffer.append(" and upper(d.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())) 
				sBuffer.append(" and fpsd.DetractorKey is null");
			else
				sBuffer.append(" and upper(d.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		
		sBuffer.append(" and status.FPSDStatus in ('Early','Late','To-be Late','To-be Early')");
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		
		return (Integer) query.uniqueResult();
	}

	@Override
	public List<TtvGridDetractorCodeView> getDetractorOrderDetail(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("fpsd.POItem as poItem,")
				.append("fpsd.PONumber as poNumber,")
				.append("fpsd.POItem as itemNo,")
				.append("fpsd.OrderQuantity as qty,")
				.append("fpsd.OrderDate as orderDate,")
				.append("fpsd.RSDDate as rsd,")
				.append("fpsd.FPSDDate as fpsd,")
				.append("fpsd.ShipDate as shippedDate,")
				.append("fpsd.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("fpsd.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofFPSD fpsd")
				.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
				.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on fpsd.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
		
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		 			.append(" and fpsd.Month = ").append(form.getMonth());
		 }
		
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sBuffer.append(" and  fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sBuffer.append(" and  fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and  fpsd.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sBuffer.append(" and  fpsd.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())){
			sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel2Detractor())){
			sBuffer.append(" and upper(dimDetractor.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		
		if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase() + "' ");
		}
		else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and dimProduct.ProductEnglishName = '"+ form.getSubDimension().toUpperCase() + "' ");
		}
		else if("Detractor".equalsIgnoreCase(form.getDimension())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor()) || "UNKNOWN".equalsIgnoreCase(form.getSubDimension())) 
				sBuffer.append(" and fpsd.DetractorKey is null");
			else
				sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getLevel1Detractor().toUpperCase() + "' ");
		}
		
		sBuffer.append(" and status.FPSDStatus in ('Early','Late','To-be Late','To-be Early')");
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
	@Override
	public List<TtvGridDetractorCodeView> getAllOrderDetail(
			SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("fpsd.POItem as poItem,")
				.append("fpsd.PONumber as poNumber,")
				.append("fpsd.POItem as itemNo,")
				.append("fpsd.OrderQuantity as qty,")
				.append("fpsd.OrderDate as orderDate,")
				.append("fpsd.RSDDate as rsd,")
				.append("fpsd.FPSDDate as fpsd,")
				.append("fpsd.ShipDate as shippedDate,")
				.append("fpsd.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("fpsd.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofFPSD fpsd")
				.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
				.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on fpsd.DetractorKey = dimDetractor.DetractorKey")	
			    .append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
			    .append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
			    .append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
			    .append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where fpsd.Year = ").append(form.getYear())
    			   .append(" and fpsd.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), fpsd.Year)+'-'+CONVERT(nvarchar(20), fpsd.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if(form.isShowAllRemarkOrder()){
			sBuffer.append(" and status.FPSDStatusKey in(").append(form.getScStatus()).append(")");
		}
		else{
			sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		}
		
		
		if(form.getChartType().equals("remark")){
			if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
				sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "'");
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and region.GeographyName in ("+ form.getSubDimension() + ") ");
				}
				else{
					sBuffer.append(" and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
				}
			}else if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and dimODM.ODMEnglishName in(" +  form.getSubDimension() + ")");
				}
				else{
					sBuffer.append(" and dimODM.ODMEnglishName = '"
							+ form.getSubDimension().toUpperCase()+ "' ");
				}
			}else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and dimProduct.ProductEnglishName in(" +  form.getSubDimension() + ")");
				}
				else{
					sBuffer.append(" and dimProduct.ProductEnglishName = '"
							+ form.getSubDimension().toUpperCase()+ "' ");
				}
			}else if("Detractor".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension())){
				if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
					sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
					
					if(form.getOrderNumber() > 0){
						sBuffer.append(" union all ");
						sBuffer.append("select  top ").append(form.getOrderNumber());
						sBuffer.append(" dimODM.ODMEnglishName as odm,")
								.append("geo.GeographyName as geo,")
								.append("region.GeographyName as region,")
								.append("country.GeographyName as country,")
								.append("dimProduct.ProductEnglishName as product,")
								.append("mtm.BOMNumberAlternateKey as pn,")
								.append("mtm.MTMEnglishDescription as itemDesc,")
								.append("fpsd.POItem as poItem,")
								.append("fpsd.PONumber as poNumber,")
								.append("fpsd.POItem as itemNo,")
								.append("fpsd.OrderQuantity as qty,")
								.append("fpsd.OrderDate as orderDate,")
								.append("fpsd.RSDDate as rsd,")
								.append("fpsd.FPSDDate as fpsd,")
								.append("fpsd.ShipDate as shippedDate,")
								.append("fpsd.IsShipped as shipped,")
								.append("'' as level1,")
								.append("'' as level2 ,")
								.append("fpsd.LateReason2 as level3 ")
								.append(" from FactMonthlySummaryofFPSD fpsd")
								.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
								.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
								.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
								.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
								.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
								.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
								.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
						
						if(form.isShowQuarterOverview()){
							form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
							form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
							sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
							   .append(form.getQuarterFrom())
							   .append(" and ").append(form.getQuarterTo());
						}
						else {
						 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
						 			.append(" and fpsd.Month = ").append(form.getMonth());
						 }
						
						if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
							sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "'");
							if(form.isShowAllRemarkOrder()){
								sBuffer.append(" and region.GeographyName in ("+ form.getSubDimension() + ") ");
							}
							else{
								sBuffer.append(" and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
							}
						}
						
						if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
							sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
							sBuffer.append(form.getPoNumberItemOrderNo());
							sBuffer.append(")");
						}
						
						if(form.getOrderTypeId() == 1) {
							if(form.getOrderSubTypeId() != -1) {
								sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
							}
							else {
								sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
							}
						}
						
						if(form.getOrderTypeId() == 2) {
							if(form.getOrderSubTypeId() != -1) {
								sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
							}
							else {
								sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
							}
						}
						
						if(form.isShowAllRemarkOrder()){
							sBuffer.append(" and status.FPSDStatusKey in(").append(form.getScStatus()).append(")");
						}
						else{
							sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
						}
						sBuffer.append(" and fpsd.DetractorKey is null");
					}
				}else if(!"UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
					sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getSubDimension().toUpperCase() + "' ");
				}else if("UNKNOWN".equalsIgnoreCase(form.getSubDimension())){
					sBuffer.append(" and fpsd.DetractorKey is null");
				}
				
			}
		}else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName()) 
				|| form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())){
			//for Region overview chart
			if("Region".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1) {
					if(form.isShowGeoOverview())//geo overview
						sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
					else 
						sBuffer.append(" and fpsd.RegionKey = ").append(form.getOverViewSubDimensionKey());
				}
				
				if(!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
				}
			}
			//for Odm overview chart
			else if("Odm".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getOverViewSubDimensionKey());
				
				if(!StringUtil.isEmpty(form.getGeoIds())) {
					sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getProductIds())) {
					sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
				}
			}
			//for Product overview chart
			else if("Product".equals(form.getOverViewDimension())) {
				if(form.getOverViewSubDimensionKey() != -1)
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getOverViewSubDimensionKey());
				
				if(!StringUtil.isEmpty(form.getOdmIds())) {
					sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
				}
				if(!StringUtil.isEmpty(form.getGeoIds())) {
					sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
				}
			}
			
			//for Region remark chart
			if("Region".equals(form.getRemarkDimension())) {
				if(form.isShowDashBoradCrossMonth()){
					sBuffer.append(" and region.GeographyName in(").append(form.getSubDimension()).append(")");
				}else{
					if(form.isShowGeoOverview())//geo overview
						sBuffer.append(" and geo.GeographyKey = ").append(form.getRemarkSubDimensionKey());
					else 
						sBuffer.append(" and fpsd.RegionKey = ").append(form.getRemarkSubDimensionKey());
				}
			}
			//for Odm remark chart
			else if("Odm".equals(form.getRemarkDimension())) {
				if(form.isShowDashBoradCrossMonth()){
					sBuffer.append(" and dimODM.ODMEnglishName in(").append(form.getSubDimension()).append(")");
				}else{
					sBuffer.append(" and fpsd.ODMKey = ").append(form.getRemarkSubDimensionKey());
				}
			}
			//for Product remark chart
			else if("Product".equals(form.getRemarkDimension())) {
				if(form.isShowDashBoradCrossMonth()){
					sBuffer.append(" and dimProduct.ProductEnglishName in(").append(form.getSubDimension()).append(")");
				}else{
					sBuffer.append(" and fpsd.ProductKey = ").append(form.getRemarkSubDimensionKey());
				}
			}
			//for Detractor remark chart
			else if("Detractor".equals(form.getRemarkDimension())) {
				if(form.isShowAllRemarkOrder() && (!form.isShowUnknownOrder())){
					sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
					
					sBuffer.append(" union all ");
					sBuffer.append("select  top ").append(form.getOrderNumber());
					sBuffer.append(" dimODM.ODMEnglishName as odm,")
							.append("geo.GeographyName as geo,")
							.append("region.GeographyName as region,")
							.append("country.GeographyName as country,")
							.append("dimProduct.ProductEnglishName as product,")
							.append("mtm.BOMNumberAlternateKey as pn,")
							.append("mtm.MTMEnglishDescription as itemDesc,")
							.append("fpsd.POItem as poItem,")
							.append("fpsd.PONumber as poNumber,")
							.append("fpsd.POItem as itemNo,")
							.append("fpsd.OrderQuantity as qty,")
							.append("fpsd.OrderDate as orderDate,")
							.append("fpsd.RSDDate as rsd,")
							.append("fpsd.FPSDDate as fpsd,")
							.append("fpsd.ShipDate as shippedDate,")
							.append("fpsd.IsShipped as shipped,")
							.append("'' as level1,")
							.append("'' as level2 ,")
							.append("fpsd.LateReason2 as level3 ")
							.append(" from FactMonthlySummaryofFPSD fpsd")
							.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
							.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
							.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
							.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
							.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
							.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
							.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
					
					if(form.isShowQuarterOverview()){
						form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
						form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
						sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
						   .append(form.getQuarterFrom())
						   .append(" and ").append(form.getQuarterTo());
					}
					else {
					 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
					 			.append(" and fpsd.Month = ").append(form.getMonth());
					 }
					
					if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
						sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "'");
						if(form.isShowAllRemarkOrder()){
							sBuffer.append(" and region.GeographyName in ("+ form.getSubDimension() + ") ");
						}
						else{
							sBuffer.append(" and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
						}
					}
					
					if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
						sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
						sBuffer.append(form.getPoNumberItemOrderNo());
						sBuffer.append(")");
					}
					
					if(form.getOrderTypeId() == 1) {
						if(form.getOrderSubTypeId() != -1) {
							sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
						}
						else {
							sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
						}
					}
					
					if(form.getOrderTypeId() == 2) {
						if(form.getOrderSubTypeId() != -1) {
							sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
						}
						else {
							sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
						}
					}
					
					if(form.isShowAllRemarkOrder()){
						sBuffer.append(" and status.FPSDStatusKey in(").append(form.getScStatus()).append(")");
					}
					else{
						sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
					}
					
					//for Region overview chart
					if("Region".equals(form.getOverViewDimension())) {
						if(form.getOverViewSubDimensionKey() != -1) {
							if(form.isShowGeoOverview())//geo overview
								sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
							else 
								sBuffer.append(" and fpsd.RegionKey = ").append(form.getOverViewSubDimensionKey());
						}
						
						if(!StringUtil.isEmpty(form.getOdmIds())) {
							sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
						}
					}
					//for Odm overview chart
					else if("Odm".equals(form.getOverViewDimension())) {
						if(form.getOverViewSubDimensionKey() != -1)
							sBuffer.append(" and fpsd.ODMKey = ").append(form.getOverViewSubDimensionKey());
						
						if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getProductIds())) {
							sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
						}
					}
					//for Product overview chart
					else if("Product".equals(form.getOverViewDimension())) {
						if(form.getOverViewSubDimensionKey() != -1)
							sBuffer.append(" and fpsd.ProductKey = ").append(form.getOverViewSubDimensionKey());
						
						if(!StringUtil.isEmpty(form.getOdmIds())) {
							sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
						}
						if(!StringUtil.isEmpty(form.getGeoIds())) {
							sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
						}
					}
					sBuffer.append(" and fpsd.DetractorKey is null");
				}
				else{
					if("UNKNOWN".equalsIgnoreCase(form.getRemarkSubDimension()))
						sBuffer.append(" and fpsd.DetractorKey is null ");
					else
						sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getRemarkSubDimension() + "' ");
				}
			}
			
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

	@Override
	public List<TtvGridDetractorCodeView> getDashCrossRemarkOrderDetail(
			SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select * from ");
		sBuffer.append("(select top ").append(form.getRowCount()).append(" * from ");
		sBuffer.append("(select  top ").append(form.getEndRow());
		if("Detractor".equals(form.getRemarkDimension())){
			sBuffer.append(" sum.odm,sum.geo,sum.region,sum.country,sum.product,sum.pn,sum.itemDesc,sum.poItem,sum.poNumber,")
					.append("sum.itemNo,sum.qty,sum.orderDate,sum.rsd,sum.fpsd,sum.shippedDate,sum.shipped,")
					.append("sum.level1,sum.level2,sum.level3 from (select ");
		}
		
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
		.append("geo.GeographyName as geo,")
		.append("region.GeographyName as region,")
		.append("country.GeographyName as country,")
		.append("dimProduct.ProductEnglishName as product,")
		.append("mtm.BOMNumberAlternateKey as pn,")
		.append("mtm.MTMEnglishDescription as itemDesc,")
		.append("fpsd.POItem as poItem,")
		.append("fpsd.PONumber as poNumber,")
		.append("fpsd.POItem as itemNo,")
		.append("fpsd.OrderQuantity as qty,")
		.append("fpsd.OrderDate as orderDate,")
		.append("fpsd.RSDDate as rsd,")
		.append("fpsd.FPSDDate as fpsd,")
		.append("fpsd.ShipDate as shippedDate,")
		.append("fpsd.IsShipped as shipped,")
		.append("dimDetractor.Level1 as level1,")
		.append("dimDetractor.Level2 as level2 ,")
		.append("fpsd.LateReason2 as level3 ")
		.append(" from FactMonthlySummaryofFPSD fpsd")
		.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
		.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
		.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
		.append(" left join DimDetractor dimDetractor on fpsd.DetractorKey = dimDetractor.DetractorKey")
		.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
		.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
		.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
		.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where fpsd.Year = ").append(form.getYear())
    			   .append(" and fpsd.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), fpsd.Year)+'-'+CONVERT(nvarchar(20), fpsd.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}	
		if(form.isShowAllRemarkOrder()){
			sBuffer.append(" and status.FPSDStatusKey in(").append(form.getScStatus()).append(")");
		}
		else{
			sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		}
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and region.GeographyName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and dimODM.ODMEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and dimProduct.ProductEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			sBuffer.append("  and upper(dimDetractor.Level1) in(" +  form.getSubDimension() + ")");
			if(form.getOrderNumber() > 0){
				sBuffer.append(" union all ");
				sBuffer.append("select  top ").append(form.getOrderNumber());
				sBuffer.append(" dimODM.ODMEnglishName as odm,")
						.append("geo.GeographyName as geo,")
						.append("region.GeographyName as region,")
						.append("country.GeographyName as country,")
						.append("dimProduct.ProductEnglishName as product,")
						.append("mtm.BOMNumberAlternateKey as pn,")
						.append("mtm.MTMEnglishDescription as itemDesc,")
						.append("fpsd.POItem as poItem,")
						.append("fpsd.PONumber as poNumber,")
						.append("fpsd.POItem as itemNo,")
						.append("fpsd.OrderQuantity as qty,")
						.append("fpsd.OrderDate as orderDate,")
						.append("fpsd.RSDDate as rsd,")
						.append("fpsd.FPSDDate as fpsd,")
						.append("fpsd.ShipDate as shippedDate,")
						.append("fpsd.IsShipped as shipped,")
						.append("'' as level1,")
						.append("'' as level2 ,")
						.append("fpsd.LateReason2 as level3 ")
						.append(" from FactMonthlySummaryofFPSD fpsd")
						.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
						.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
						.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
						.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
						.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
						.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
						.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
				
				if(form.isShowQuarterOverview()){
					form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
					form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
					sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
					   .append(form.getQuarterFrom())
					   .append(" and ").append(form.getQuarterTo());
				}
				else {
				 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
				 			.append(" and fpsd.Month = ").append(form.getMonth());
				 }
				
				if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
					sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "'");
					if(form.isShowAllRemarkOrder()){
						sBuffer.append(" and region.GeographyName in ("+ form.getSubDimension() + ") ");
					}
					else{
						sBuffer.append(" and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
					}
				}
				
				if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
					sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
					sBuffer.append(form.getPoNumberItemOrderNo());
					sBuffer.append(")");
				}
				
				if(form.getOrderTypeId() == 1) {
					if(form.getOrderSubTypeId() != -1) {
						sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
					}
					else {
						sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
					}
				}
				
				if(form.getOrderTypeId() == 2) {
					if(form.getOrderSubTypeId() != -1) {
						sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
					}
					else {
						sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
					}
				}
				
				if(form.isShowAllRemarkOrder()){
					sBuffer.append(" and status.FPSDStatusKey in(").append(form.getScStatus()).append(")");
				}
				else{
					sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
				}
				sBuffer.append(" and fpsd.DetractorKey is null");
			}
			
			sBuffer.append(")sum");
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType()).append(" ) t");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType()).append(" ) t");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getReversalSortType())
					.append(", poNumber ").append(form.getReversalSortType()).append(" ) tt");
		}else{
			sBuffer.append(" order by poNumber ").append(form.getReversalSortType());
			sBuffer.append(",poItem ").append(form.getReversalSortType());
			sBuffer.append(",qty ").append(form.getReversalSortType()).append(" ) tt");
		}
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}

	@Override
	public int getDashCrossRemarkOrderDetailCount(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(fpsd.FPSDStatusKey) as orderNum")
			   .append(" from FactMonthlySummaryofFPSD fpsd")
			   .append(" left join ")
			   .append(" DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
			   .append(" left join DimDetractor dimDetractor on fpsd.DetractorKey =  dimDetractor.DetractorKey")
			   .append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
		   	   .append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
		   	   .append(" left join DimProduct product on fpsd.ProductKey = product.ProductKey");
		
		if(form.getStartDate().equals(form.getEndDate())){
			sBuffer.append(" where fpsd.Year = ").append(form.getYear())
    			   .append(" and fpsd.Month = ").append(form.getMonth());
		}else{
			sBuffer.append(" where CONVERT(nvarchar(20), fpsd.Year)+'-'+CONVERT(nvarchar(20), fpsd.Month) between '")
			   .append(form.getStartDate()).append("'")
			   .append(" and '").append(form.getEndDate()).append("'");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}
		
		if(form.isShowAllRemarkOrder()){
			sBuffer.append(" and status.FPSDStatusKey in(").append(form.getScStatus()).append(")");
		}
		else{
			sBuffer.append(" and status.FPSDStatus = '").append(form.getScStatus()).append("'");
		}
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getProductIds())) {
				sBuffer.append(" and fpsd.ProductKey in(").append(form.getProductIds()).append(")");
			}
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getOverViewSubDimensionKey());
			
			if(!StringUtil.isEmpty(form.getOdmIds())) {
				sBuffer.append(" and fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
			}
			if(!StringUtil.isEmpty(form.getGeoIds())) {
				sBuffer.append(" and fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
			}
		}
		
		//for Region remark chart
		if("Region".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and region.GeographyName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and fpsd.RegionKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Odm remark chart
		else if("Odm".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and dimODM.ODMEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Product remark chart
		else if("Product".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and product.ProductEnglishName in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getRemarkSubDimensionKey());
			}
		}
		//for Detractor remark chart
		else if("Detractor".equals(form.getRemarkDimension())) {
			if(form.isShowDashBoradCrossMonth()){
				sBuffer.append(" and upper(dimDetractor.level1) in(").append(form.getSubDimension()).append(")");
			}else{
				sBuffer.append(" and upper(dimDetractor.level1) = ").append(form.getRemarkSubDimension());
			}
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString());
		return (Integer) query.uniqueResult();
	}

	@Override
	public List<TtvGridDetractorCodeView> getAllDetractorOrder(SearchOtsForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select  top ").append(form.getEndRow());
		sBuffer.append(" dimODM.ODMEnglishName as odm,")
				.append("geo.GeographyName as geo,")
				.append("region.GeographyName as region,")
				.append("country.GeographyName as country,")
				.append("dimProduct.ProductEnglishName as product,")
				.append("mtm.BOMNumberAlternateKey as pn,")
				.append("mtm.MTMEnglishDescription as itemDesc,")
				.append("fpsd.POItem as poItem,")
				.append("fpsd.PONumber as poNumber,")
				.append("fpsd.POItem as itemNo,")
				.append("fpsd.OrderQuantity as qty,")
				.append("fpsd.OrderDate as orderDate,")
				.append("fpsd.RSDDate as rsd,")
				.append("fpsd.FPSDDate as fpsd,")
				.append("fpsd.ShipDate as shippedDate,")
				.append("fpsd.IsShipped as shipped,")
				.append("dimDetractor.Level1 as level1,")
				.append("dimDetractor.Level2 as level2 ,")
				.append("fpsd.LateReason2 as level3 ")
				.append(" from FactMonthlySummaryofFPSD fpsd")
				.append(" left join DimFPSDStatus status on fpsd.FPSDStatusKey = status.FPSDStatusKey")
				.append(" left join DimProduct dimProduct on fpsd.ProductKey = dimProduct.ProductKey ")
				.append(" left join DimODM dimODM on fpsd.ODMKey = dimODM.ODMKey")
				.append(" left join DimDetractor dimDetractor on fpsd.DetractorKey = dimDetractor.DetractorKey")
				.append(" left join DimMTM mtm on fpsd.MTMKey = mtm.MTMKey")
				.append(" left join DimGeography region on fpsd.RegionKey = region.GeographyKey")
				.append(" left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey")
				.append(" left join DimGeography country on fpsd.CountryKey = country.GeographyKey");
		
		
		if(form.isShowQuarterOverview()){
			form.setQuarterFrom(CalendarUtil.yearMonthConvert(form.getQuarterFrom()));
			form.setQuarterTo(CalendarUtil.yearMonthConvert(form.getQuarterTo()));
			sBuffer.append(" where fpsd.Year*100 + fpsd.Month between ")
			   .append(form.getQuarterFrom())
			   .append(" and ").append(form.getQuarterTo());
		}
		else {
		 	sBuffer.append(" where fpsd.Year = ").append(form.getYear())
		 			.append(" and fpsd.Month = ").append(form.getMonth());
		 }
		
		if(("region".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and region.GeographyType = '"+ GeographyType.Region.name()+ "' and region.GeographyName = '"+ form.getSubDimension().toUpperCase()+ "' ");
		}
		
		if(!StringUtil.isEmpty(form.getPoNumberItemOrderNo())){
			sBuffer.append(" and cast(fpsd.PONumber as nvarchar)+'_'+cast(fpsd.POItem as nvarchar)+'_'+cast(isnull(fpsd.OrderNo,0) as nvarchar) not in(");
			sBuffer.append(form.getPoNumberItemOrderNo());
			sBuffer.append(")");
		}
		
		if(form.getOrderTypeId() == 1) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (1,2)");
			}
		}
		
		if(form.getOrderTypeId() == 2) {
			if(form.getOrderSubTypeId() != -1) {
				sBuffer.append(" and fpsd.OTSTypeKey = ").append(form.getOrderSubTypeId());
			}
			else {
				sBuffer.append(" and fpsd.OTSTypeKey in (3,4,5,6)");
			}
		}	
		
		//for Region overview chart
		if("Region".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1) {
				if(form.isShowGeoOverview())//geo overview
					sBuffer.append(" and geo.GeographyKey = ").append(form.getOverViewSubDimensionKey());
				else 
					sBuffer.append(" and fpsd.RegionKey = ").append(form.getOverViewSubDimensionKey());
			}
		}
		//for Odm overview chart
		else if("Odm".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ODMKey = ").append(form.getOverViewSubDimensionKey());
		}
		//for Product overview chart
		else if("Product".equals(form.getOverViewDimension())) {
			if(form.getOverViewSubDimensionKey() != -1)
				sBuffer.append(" and fpsd.ProductKey = ").append(form.getOverViewSubDimensionKey());
		}
		
		if(StringUtils.isNotBlank(form.getGeoIds())){
			if(form.isShowGeoOverview())//geo overview
				sBuffer.append(" and geo.GeographyKey in(").append(form.getGeoIds()).append(")");
			else 
				sBuffer.append(" and  fpsd.RegionKey in(").append(form.getGeoIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getOdmIds())){
			sBuffer.append(" and  fpsd.ODMKey in(").append(form.getOdmIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getProductIds())){
			sBuffer.append(" and  fpsd.ProductKey in(").append(form.getProductIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getDetractorIds())){
			sBuffer.append(" and  fpsd.DetractorKey in(").append(form.getDetractorIds()).append(")");
		}
		if(StringUtils.isNotBlank(form.getLevel1Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor())){
			sBuffer.append(" and upper(dimDetractor.level1) = '").append(form.getLevel1Detractor().toUpperCase()).append("'");
		}
		if(StringUtils.isNotBlank(form.getLevel2Detractor()) && !"UNKNOWN".equalsIgnoreCase(form.getLevel2Detractor())){
			sBuffer.append(" and upper(dimDetractor.level2) = '").append(form.getLevel2Detractor().toUpperCase()).append("'");
		}
		
		if(("odm".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and dimODM.ODMEnglishName = '" + form.getSubDimension().toUpperCase() + "' ");
		}
		else if(("product".equalsIgnoreCase(form.getDimension()) && !StringUtil.isEmpty(form.getSubDimension()))){
			sBuffer.append(" and dimProduct.ProductEnglishName = '"+ form.getSubDimension().toUpperCase() + "' ");
		}
		else if("Detractor".equalsIgnoreCase(form.getDimension())){
			if("UNKNOWN".equalsIgnoreCase(form.getLevel1Detractor()) || "UNKNOWN".equalsIgnoreCase(form.getSubDimension())) 
				sBuffer.append(" and fpsd.DetractorKey is null");
			else
				sBuffer.append(" and upper(dimDetractor.Level1) = '"+ form.getLevel1Detractor().toUpperCase() + "' ");
		}
		
		sBuffer.append(" and status.FPSDStatus in ('Early','Late','To-be Late','To-be Early')");
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType())
					.append(", poNumber ").append(form.getSortType());
		}else{
			sBuffer.append(" order by poNumber ").append(form.getSortType());
			sBuffer.append(",poItem ").append(form.getSortType());
			sBuffer.append(",qty ").append(form.getSortType());
		}
		Query query = getSession().createSQLQuery(sBuffer.toString()).addScalar("odm", StringType.INSTANCE).addScalar("geo", StringType.INSTANCE)
				.addScalar("region", StringType.INSTANCE).addScalar("country", StringType.INSTANCE).addScalar("product", StringType.INSTANCE)
				.addScalar("pn", StringType.INSTANCE).addScalar("itemDesc", StringType.INSTANCE).addScalar("poItem", StringType.INSTANCE)
				.addScalar("poNumber", StringType.INSTANCE).addScalar("itemNo", StringType.INSTANCE)
				.addScalar("qty", StringType.INSTANCE).addScalar("orderDate", DateType.INSTANCE).addScalar("rsd", DateType.INSTANCE)
				.addScalar("fpsd", StringType.INSTANCE)
				.addScalar("shippedDate", DateType.INSTANCE).addScalar("shipped", StringType.INSTANCE).addScalar("level1", StringType.INSTANCE)
				.addScalar("level2", StringType.INSTANCE).addScalar("level3", StringType.INSTANCE).setResultTransformer(Transformers.aliasToBean(TtvGridDetractorCodeView.class));
		return query.list();
	}
	
}
