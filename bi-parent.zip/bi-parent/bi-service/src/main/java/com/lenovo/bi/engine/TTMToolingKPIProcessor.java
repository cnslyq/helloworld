package com.lenovo.bi.engine;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.lenovo.bi.dao.common.ToolingCapacityDao;
import com.lenovo.bi.dto.ToolingCapacity;
import com.lenovo.bi.enumobj.KPILights;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.service.common.MasterDataService;
import com.lenovo.bi.util.CalendarUtil;
/**
 * 
 * 
 * @author henry_lian
 *
 */
@Component
@Order(2)
public class TTMToolingKPIProcessor implements TTMKPIProcessor {

	@Inject
	private MasterDataService masterDataService;
	@Inject
	private ToolingCapacityDao toolingCapacityDao;
	
	@Override
	public void process(ProjectSummary ps, Date versionDate) {
		if(ps.getTtmStatus().equals(Status.NA.name())){
			return;
		}
		Date targetDate = ps.getTtmTargetDate();
		if(targetDate != null){
			targetDate = CalendarUtil.getMondayDateByDate(targetDate);
			//targetDate = CalendarUtil.getMondayDateByWeeks(targetDate, 1);
		}
		List<ToolingCapacity> coverCapList = toolingCapacityDao.getToolingCapacityByWave(ps.getPmsWaveId(),targetDate, versionDate);
		//List<ToolingCapacity> coverCapList = toolingCapacityDao.getToolingCapacityByWave(ps.getPmsWaveId(),versionDate, versionDate);
		if(coverCapList.isEmpty()){
			ps.setTooling(KPILights.GREEN.name());
		} else{
			Float threshold = masterDataService.getThresholdByName(Threshold.TTM_TOOLING.name());
			
			Integer totalCap = null;
			for(ToolingCapacity tc:coverCapList){
				if(totalCap == null){
					totalCap = tc.getBoh() + tc.getCapacity();
				} else{
					if(totalCap > tc.getBoh()+tc.getCapacity() ){
						totalCap = tc.getBoh() + tc.getCapacity();
					}
				}
			}
			
			if(totalCap >= ps.getTtmTargetDateDemand()){
				ps.setTooling(KPILights.GREEN.name());
				
			} else if(totalCap >= ps.getTtmTargetDateDemand()*threshold){
				ps.setTooling(KPILights.YELLOW.name());
			} else{
				ps.setTooling(KPILights.RED.name());
			}
		}
	}

}
