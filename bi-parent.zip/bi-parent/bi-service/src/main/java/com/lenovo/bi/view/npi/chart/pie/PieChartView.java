package com.lenovo.bi.view.npi.chart.pie;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PieChartView {
	
 	private PieChartInformation chartInfo;
	
	private List<PieSlice> elements;
	
	public List<PieSlice> getElements() {
		return elements;
	}
	@JsonProperty("data")
	public void setElements(List<PieSlice> elements) {
		this.elements = elements;
	}

	public PieChartInformation getChartInfo() {
		return chartInfo;
	}
	@JsonProperty("chart")
	public void setChartInfo(PieChartInformation chartInfo) {
		this.chartInfo = chartInfo;
	}
	
	public PieChartView(){
		chartInfo = new PieChartInformation();
	}
	
}
