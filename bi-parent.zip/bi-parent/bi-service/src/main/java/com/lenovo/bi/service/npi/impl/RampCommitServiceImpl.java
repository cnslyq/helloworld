package com.lenovo.bi.service.npi.impl;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.npi.impl.RampCommitDaoImpl;
import com.lenovo.bi.dto.RampCommitDTO;
import com.lenovo.bi.service.npi.RampCommitService;

@Service
@Transactional("dw")
public class RampCommitServiceImpl implements RampCommitService {

	@Inject
	private RampCommitDaoImpl rampCommitDao;

	@Override
	public List<RampCommitDTO> getRampCommitByWaveId(int waveId) {
		return rampCommitDao.getRampCommitByWaveId(waveId);
	}

	@Override
	public int getRampCommitQty(int waveId, Date startDate) {
		Integer qty = rampCommitDao.getRampCommit(startDate, waveId);
		if(qty != null){
			return qty.intValue();
		}else{
			return 0;
		}
	}

	@Override
	public List<RampCommitDTO> getRampCommitByWaveIdAndTargetDate(String waveId,
			String startDate, String endDate) {
		return rampCommitDao.getRampCommitByWaveIdAndTargetDate(waveId,startDate,endDate);
	}

}
