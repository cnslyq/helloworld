package com.lenovo.bi.dao.npi.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.type.IntegerType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.dao.npi.NPIFilterDao;
import com.lenovo.bi.model.NPIFilter;
import com.lenovo.bi.model.NPIFilterDetail;
@Repository
@SuppressWarnings("unchecked")
public class NPIFilterDaoImpl extends HibernateBaseDaoImplBi<Object> implements NPIFilterDao{

	@Override
	public List<NPIFilter> getNPIFilter(String userId, String phase,
			String scope,String filterId) {
		StringBuffer hql = new StringBuffer("from NPIFilter where UserId = :userId ")
		.append("and Phase = :phase ")
		.append("and Scope = :scope ");
		if(StringUtils.isNotBlank(filterId)){
			hql.append("and Id = :id ");
		}
		hql.append("order by LastUsedFilter desc , LastModifiedDate desc");

		Query query = getSession().createQuery(hql.toString());
		query.setParameter("userId", userId);
		query.setParameter("phase", phase);
		query.setParameter("scope", scope);
		if(StringUtils.isNotBlank(filterId)){
			query.setParameter("id", filterId);
		}
		return query.list();
	}
	@Override
	public String getLastUsedFilterID(String userId, String phase, String scope) {
		StringBuffer hql = new StringBuffer("select id from NPIFilter where lastUsedFilter = 1 ")
		.append("and userId = '").append(userId).append("' ")
		.append("and phase = '").append(phase).append("' ")
		.append("and scope = '").append(scope).append("' ");
		Query query = getSession().createQuery(hql.toString());
		
		List<String> list = query.list();
		if(CollectionUtils.isNotEmpty(list)){
			return list.get(0);
		}
		return null;
	}

	@Override
	public List<NPIFilterDetail> getNPIFilterDetailByFilterId(String filterId) {
		StringBuffer hql = new StringBuffer("from NPIFilterDetail where parentId = :parentId ");
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("parentId", filterId);
		return query.list();
	}

	@Override
	public List<Integer> getNPIFilterWaveIdsByFilterId(String filterId) {
		StringBuffer hql = new StringBuffer("select npiWaveId from BI_NPIFilterDetail where parentId = :parentId ");
		
		Query query = getSession().createSQLQuery(hql.toString())
				.addScalar("npiWaveId", IntegerType.INSTANCE);
		query.setParameter("parentId", filterId);
		return query.list();
	}

	@Override
	public int deleteFilterByFilterId(String filterId) {
		StringBuilder sql = new StringBuilder("delete from BI_NPIFilter where id = :id ");
		SQLQuery q = getSession().createSQLQuery(sql.toString());
		q.setParameter("id", filterId);
		return q.executeUpdate();
	}

	@Override
	public int deleteFilterDetailByParentId(String parentId) {
		StringBuilder sql = new StringBuilder("delete from BI_NPIFilterDetail where parentId = :parentId ");
		SQLQuery q = getSession().createSQLQuery(sql.toString());
		q.setParameter("parentId", parentId);
		return q.executeUpdate();
	}

	@Override
	public void saveFilter(NPIFilter npiFilter) {
		 getSession().save(npiFilter);
	}

	@Override
	public void updateFilter(NPIFilter npiFilter) {
		getSession().merge(npiFilter);
	}

	@Override
	public void saveFilterDetail(NPIFilterDetail npiFilterDetail) {
		getSession().save(npiFilterDetail);
	}

}
