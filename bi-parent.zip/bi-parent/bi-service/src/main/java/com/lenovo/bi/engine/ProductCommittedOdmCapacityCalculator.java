package com.lenovo.bi.engine;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.SysConstants;
import com.lenovo.common.logging.Logger;
import com.lenovo.common.logging.LoggerFactory;

abstract public class ProductCommittedOdmCapacityCalculator<T> {
	protected Date versionDate;
	//protected Date targetDate;
	protected Integer pmsWaveId;

	protected TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;

	protected static Logger LOGGER = LoggerFactory.getLogger(SysConstants.LOG_WEEKLY_BATCH_CATALOG);

	/*
	public ProductCommittedOdmCapacityCalculator(Date targetDate, Date versionDate) {
		this.versionDate = versionDate;
		this.targetDate = targetDate;
	}
	*/
	public ProductCommittedOdmCapacityCalculator(Integer pmsWaveId, Date versionDate) {
		this.pmsWaveId = pmsWaveId;
		this.versionDate = versionDate;
	}
	
	abstract public void calculate(List<T> npiWeeklyDetails);

	public void setTtvOutlookServiceDwHelper(TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper) {
		this.ttvOutlookServiceDwHelper = ttvOutlookServiceDwHelper;
	}

}
