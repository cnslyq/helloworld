package com.lenovo.bi.dao.common.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.common.ForecastDao;
import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dto.CtoCvConfig;
import com.lenovo.bi.dto.CvQuantity;
import com.lenovo.bi.dto.EolForecast;
import com.lenovo.bi.dto.Forecast;
import com.lenovo.bi.dto.MtmGeographyOdmCvQuantity;
import com.lenovo.bi.dto.NpiDnsEntry;
import com.lenovo.bi.dto.NpiForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.util.SysConstants;
import com.lenovo.bi.view.npi.ForecastCompare;
import com.lenovo.common.logging.Logger;
import com.lenovo.common.logging.LoggerFactory;

@Repository
public class ForecastDaoImpl extends HibernateBaseDaoImplDw<Object> implements
		ForecastDao {

	private static Logger log = LoggerFactory.getLogger("ForecastDaoImpl");

	@Override
	@SuppressWarnings("unchecked")
	public List<Forecast> getAllMtmForecastsInWeek(Date targetDate,
			Date versionDate) {
		// ENGINE
		// USE MPS FORECAST
		StringBuffer sql = new StringBuffer(
				"select m.BOMNumberAlternateKey as forecastId, m.BOMNumberAlternateKey as bomNumber, f.quantity, fct.FCType as forecastType, ")
				.append("pr.productKey, g.geographyName, odm.ODMEnglishName as odmName, ")
				.append("t1.FullDateAlternateKey as targetDate, t2.FullDateAlternateKey as versionDate ")
				.append("from FactWeeklyForecast f, DimForecastAndCommitType fct, DimMTM m, ")
				.append("DimProduct pr, DimGeography g, DimODM odm, DimTime t1, DimTime t2 ")
				.append("where f.ForecastType = fct.FCTypeKey ")
				.append("and f.MTMKey = m.MTMKey ")
				.append("and m.ProductKey = pr.ProductKey ")
				.append("and f.TargetDateKey = t1.TimeKey ")
				.append("and f.VersionDateKey = t2.TimeKey ")
				.append("and g.GeographyKey = f.GeographyKey ")
				.append("and f.ODMKey = odm.ODMKey ")
				.append("and (fct.FCType = '59' ) ")
				.append("and datediff(day, t1.FullDateAlternateKey, ?) = 0 ")
				.append("and datediff(day, t2.FullDateAlternateKey, ?) = 0 ")
				.append("and f.Quantity > 0 ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(Forecast.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, versionDate);
		List<Forecast> forecasts = query.list();

		return forecasts;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<CtoCvConfig> getAllCtoForecastsInWeek(Date targetDate,
			Date versionDate) {
		// ENGINE
		StringBuffer sql = new StringBuffer(
				"select m.BOMNumberAlternateKey as bomNumber, f.quantity as numberOfUnits, ")
				.append("pr.productKey, g.geographyName, odm.ODMEnglishName as odmName ")
				.append("from FactWeeklyForecast f, DimForecastAndCommitType fct, DimMTM m, ")
				.append("DimProduct pr, DimGeography g, DimODM odm, DimTime t1, DimTime t2 ")
				.append("where f.ForecastType = fct.FCTypeKey ")
				.append("and f.MTMKey = m.MTMKey ")
				.append("and m.ProductKey = pr.ProductKey ")
				.append("and f.TargetDateKey = t1.TimeKey ")
				.append("and f.VersionDateKey = t2.TimeKey ")
				.append("and g.GeographyKey = f.GeographyKey ")
				.append("and f.ODMKey = odm.ODMKey ")
				.append("and fct.FCType = 'CTO' ")
				.append("and DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0 ")
				.append("and DATEDIFF(day, t2.FullDateAlternateKey, ?) = 0 ")
				.append("and f.Quantity > 0 ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(CtoCvConfig.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, versionDate);
		List<CtoCvConfig> forecasts = query.list();

		for (CtoCvConfig forecast : forecasts) {
			fillCtoCvConfig(forecast, targetDate, versionDate);
		}

		return forecasts;
	}

	/**
	 * Return forecasts for EOL products in the week.
	 * 
	 * @param targetDate
	 * @param versionDate
	 * @param justLastWeek
	 *            Whether to include all EOL product in the past or just the
	 *            last week
	 * @return
	 */
	@Deprecated
	public List<EolForecast> getAllEolMtmForecastsInWeek(Date targetDate,
			Date versionDate, boolean justLastWeek) {
		// ENGINE
		// USE MPS FORECAST
		StringBuffer sql = new StringBuffer(
				"select m.BOMNumberAlternateKey as forecastId, m.BOMNumberAlternateKey as bomNumber, f.quantity, fct.FCType as forecastType, ")
				.append("pr.productKey, g.geographyName, t3.FullDateAlternateKey as eolDate, ")
				.append("t1.FullDateAlternateKey as targetDate, t2.FullDateAlternateKey as versionDate ")
				.append("from FactWeeklyForecast f, FactEOLProduct fep, DimForecastAndCommitType fct, DimMTM m, ")
				.append("DimProduct pr, DimGeography g, DimTime t1, DimTime t2, DimTime t3 ")
				.append("where f.ForecastType = fct.FCTypeKey ")
				.append("and f.MTMKey = m.MTMKey ")
				.append("and m.ProductKey = pr.ProductKey ")
				.append("and f.TargetDateKey = t1.TimeKey ")
				.append("and f.VersionDateKey = t2.TimeKey ")
				.append("and fep.EOLDateKey = t3.TimeKey ")
				.append("and g.GeographyKey = f.GeographyKey ")
				.append("and (fct.FCType = '59' ) ")
				.append("and datediff(day, t1.FullDateAlternateKey, ?) = 0 ")
				.append("and datediff(day, t2.FullDateAlternateKey, ?) = 0 ")
				.append("and datediff(day, t3.FullDateAlternateKey, ?) > 0 ")
				.append("and f.Quantity > 0 ");

		if (justLastWeek) {
			sql.append("and datediff(day, t3.FullDateAlternateKey, ?) <= 7 ");
		}

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(EolForecast.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, versionDate);
		query.setParameter(2, targetDate);

		if (justLastWeek) {
			query.setParameter(3, targetDate);
		}

		@SuppressWarnings("unchecked")
		List<EolForecast> forecasts = query.list();

		return forecasts;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Forecast> getAllMtmForecastsInWeekForVersionDate(
			Date targetDate, Date versionDate) {
		// ENGINE
		// USE MPS FORECAST
		StringBuffer sql = new StringBuffer(
				"select m.BOMNumberAlternateKey as forecastId, m.BOMNumberAlternateKey as bomNumber, f.quantity, fct.FCType as forecastType, ")
				.append("pr.productKey, g.geographyName, odm.ODMEnglishName as odmName, ")
				.append("t1.FullDateAlternateKey as targetDate, t2.FullDateAlternateKey as versionDate ")
				.append("from FactWeeklyForecast f")
				.append(" left join DimForecastAndCommitType fct on f.ForecastType = fct.FCTypeKey")
				.append(" left join DimMTM m on f.MTMKey = m.MTMKey")
				.append(" left join DimProduct pr on m.ProductKey = pr.ProductKey")
				.append(" left join DimGeography g on g.GeographyKey = f.GeographyKey")
				.append(" left join DimODM odm on f.ODMKey = odm.ODMKey")
				.append(" left join DimTime t1 on f.TargetDateKey = t1.TimeKey")
				.append(" left join DimTime t2 on f.VersionDateKey = t2.TimeKey")
				.append(" left join (")
				.append(" select distinct min(t2.FullDateAlternateKey) over(partition by mtm.BOMNumberAlternateKey) as MinTargetDate, mtm.BOMNumberAlternateKey as bomNumber")
				.append(" from FactWeeklyForecast fwf")
				.append(" left join DimMTM mtm on fwf.MTMKey = mtm.MTMKey")
				.append(" left join DimTime t1 on fwf.TargetDateKey = t1.TimeKey")
				.append(" left join DimTime t2 on fwf.VersionDateKey = t2.TimeKey")
				.append(" left join DimForecastAndCommitType fct on fwf.ForecastType = fct.FCTypeKey")
				.append(" where (fct.FCType = '59' ) and fwf.Quantity > 0")
				.append(" and DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0")
				.append(" and DATEDIFF(day, ?, t2.FullDateAlternateKey) = 0")
				.append(" )")
				.append(" as mtd on m.BOMNumberAlternateKey = mtd.BOMNumber and (fct.FCType = '59')")
				.append(" where DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0")
				.append(" and DATEDIFF(day, t2.FullDateAlternateKey, mtd.MinTargetDate) = 0 and f.Quantity > 0");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(Forecast.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, versionDate);
		query.setParameter(2, targetDate);
		List<Forecast> forecasts = query.list();
		return forecasts;
	}

	@SuppressWarnings("unchecked")
	public List<Forecast> getForecastsInWeekByProductKey(Date targetDate,
			Date startDate, Date endDate, String productKey, String waveId) {
		StringBuffer sql = new StringBuffer(
				"select mtm.BOMNumberAlternateKey as bomNumber,region.GeographyName as geographyName")
				.append(",t2.FullDateAlternateKey as versionDate ")
				.append(",odm.ODMEnglishName as odmName,isnull(sum(f.quantity),0) as quantity ");
		sql.append("from FactWeeklyForecast f ");
		sql.append("inner join DimMTM mtm on f.MTMKey = mtm.MTMKey ");
		sql.append("inner join DimForecastAndCommitType fct on f.ForecastType = fct.FCTypeKey ");
		sql.append("inner join DimTime t1 on f.TargetDateKey = t1.TimeKey ");
		sql.append("inner join DimTime t2 on f.VersionDateKey = t2.TimeKey ");
		sql.append("inner join DimGeography region on region.GeographyKey = f.GeographyKey ");
		sql.append("inner join DimODM odm on f.ODMKey = odm.ODMKey ");
		sql.append("inner join view_getNew_mtm_wave wave on mtm.mtmkey = wave.mtmkey ");
		sql.append("INNER JOIN DimNPIWave npiwave ON wave.NPIWaveKey = npiwave.NPIWaveKey ");
		sql.append("where DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0 ");
		sql.append("and DATEDIFF(day, t2.FullDateAlternateKey, ?) >= 0 ");
		sql.append("and DATEDIFF(day, t2.FullDateAlternateKey, ?) <= 0 ");
		sql.append("and fct.FCType = '59' ");
		sql.append("and f.Quantity > 0 ");
		sql.append("and mtm.productKey = ? ");
		sql.append("and npiwave.PMSWaveIDAlternateKey = ? ");
		sql.append("group by mtm.BOMNumberAlternateKey,region.GeographyName,odm.ODMEnglishName,t2.FullDateAlternateKey ");
		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(Forecast.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, endDate);
		query.setParameter(2, startDate);
		query.setParameter(3, productKey);
		query.setParameter(4, waveId);

		List<Forecast> forecasts = query.list();
		return forecasts;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CtoCvConfig> getAllCtoForecastsInWeekForVersionDate(
			Date targetDate, Date versionDate) {
		// ENGINE
		StringBuilder sql = new StringBuilder(
				"select m.BOMNumberAlternateKey as bomNumber, f.quantity as numberOfUnits, ")
				.append("pr.productKey, g.geographyName, odm.ODMEnglishName as odmName ")
				.append("from FactWeeklyForecast f")
				.append(" inner join DimForecastAndCommitType fct on f.ForecastType = fct.FCTypeKey")
				.append(" inner join DimMTM m on f.MTMKey = m.MTMKey")
				.append(" inner join DimProduct pr on m.ProductKey = pr.ProductKey")
				.append(" inner join DimGeography g on g.GeographyKey = f.GeographyKey")
				.append(" inner join DimODM odm on f.ODMKey = odm.ODMKey")
				.append(" inner join DimTime t1 on f.TargetDateKey = t1.TimeKey")
				.append(" inner join DimTime t2 on  f.VersionDateKey = t2.TimeKey")
				.append(" inner join (")
				.append(" select distinct min(t2.FullDateAlternateKey) over(partition by mtm.BOMNumberAlternateKey) as MinTargetDate, mtm.BOMNumberAlternateKey as bomNumber")
				.append(" from FactWeeklyForecast fwf")
				.append(" inner join DimMtm mtm on fwf.MTMKey = mtm.MTMKey")
				.append(" inner join DimTime t1 on fwf.TargetDateKey = t1.TimeKey")
				.append(" inner join DimTime t2 on fwf.VersionDateKey = t2.TimeKey")
				.append(" inner join DimForecastAndCommitType fct on fwf.ForecastType = fct.FCTypeKey")
				.append(" where fct.FCType = 'CTO' and fwf.Quantity > 0")
				.append(" and DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0")
				.append(" and DATEDIFF(day, ?, t2.FullDateAlternateKey) = 0")
				.append(")")
				.append(" as mtd on m.BOMNumberAlternateKey = mtd.BOMNumber and DATEDIFF(day, t2.FullDateAlternateKey, mtd.MinTargetDate) = 0")
				.append(" where fct.FCType = 'CTO' and DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0")
				.append("and f.Quantity > 0");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(CtoCvConfig.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, versionDate);
		query.setParameter(2, targetDate);
		List<CtoCvConfig> forecasts = query.list();

		for (CtoCvConfig forecast : forecasts) {
			fillCtoCvConfig(forecast, targetDate, versionDate);
		}

		return forecasts;
	}

	@Deprecated
	@Override
	public CtoCvConfig getCtoForecast(String productKey, String geographyName,
			String odmName, Date targetDate, Date versionDate) {
		// ENGINE
		StringBuilder sql = new StringBuilder(
				"select m.BOMNumberAlternateKey as bomNumber, f.Quantity as numberOfUnits ")
				.append("from FactWeeklyForecast f, DimForecastAndCommitType fct, DimGeography g, DimODM odm, DimMTM m, DimTime t1, DimTime t2 ")
				.append("where f.ForecastType = fct.FCTypeKey ")
				.append("and f.GeographyKey = g.GeographyKey ")
				.append("and f.ODMKey = odm.ODMKey ")
				.append("and f.MTMKey = m.MTMKey ")
				.append("and f.TargetDateKey = t1.TimeKey ")
				.append("and f.VersionDateKey = t2.TimeKey ")
				.append("and m.ProductKey = ? ")
				.append("and g.GeographyName = ? ")
				.append("and odm.ODMEnglishName = ? ")
				.append("and fct.FCType = 'CTO'  ")
				.append("and datediff(day, t1.FullDateAlternateKey, ?) = 0 ")
				.append("and datediff(day, t2.FullDateAlternateKey, ?) = 0 ")
				.append("and f.Quantity > 0 ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(CtoCvConfig.class));
		query.setParameter(0, productKey);
		query.setParameter(1, geographyName);
		query.setParameter(2, odmName);
		query.setParameter(3, targetDate);
		query.setParameter(4, versionDate);
		@SuppressWarnings("unchecked")
		List<CtoCvConfig> ctos = (List<CtoCvConfig>) query.list();

		if (ctos.size() > 0) {
			return ctos.get(0); // A product has only a single CTO in a
								// geography and region
		}

		return null;
	}

	@Override
	public void fillCtoCvConfig(CtoCvConfig ctoCvConfig, Date targetDate,
			Date versionDate) {
		// ENGINE
		StringBuilder sql = new StringBuilder(
				"select sgf.GlobalCVKey as cvKey, sgf.Quantity * f.quantity as quantity ")
				.append("from FactWeeklyForecast f, FactSBBinGlobalCVFormat sgf, DimForecastAndCommitType fct, DimMTM m, DimTime t1, DimTime t2 ")
				.append("where f.SBBKey = sgf.SBBKey ")
				.append("and f.ForecastType = fct.FCTypeKey ")
				.append("and f.MTMKey = m.MTMKey ")
				.append("and f.TargetDateKey = t1.TimeKey ")
				.append("and f.VersionDateKey = t2.TimeKey ")
				.append("and m.BOMNumberAlternateKey = ? ")
				.append("and fct.FCType = 'CTO+SBB' ")
				.append("and datediff(day, t1.FullDateAlternateKey, ?) = 0 ")
				.append("and datediff(day, t2.FullDateAlternateKey, ?) = 0 ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(CvQuantity.class));
		query.setParameter(0, ctoCvConfig.getBomNumber());
		query.setParameter(1, targetDate);
		query.setParameter(2, versionDate);

		@SuppressWarnings("unchecked")
		List<CvQuantity> cvQuantityList = query.list();

		if (cvQuantityList.size() > 0) {
			for (CvQuantity cq : cvQuantityList) {
				ctoCvConfig.addCv(cq.getCvKey(), cq.getQuantity());
			}
		}
	}

	@Override
	public List<MtmGeographyOdmCvQuantity> getAllCtoForecastCvQuantityInMonth(
			Date targetDate, Date versionDate) {
		// ENGINE
		StringBuilder sql = new StringBuilder(
				"select m.BOMNumberAlternateKey as bomNumber, g.geographyName, odm.ODMEnglishName as odmName, ")
				.append("sgf.GlobalCVKey as cvKey, sum(f.Quantity * sgf.Quantity) as quantity ")
				.append("from FactWeeklyForecast f, FactSBBinGlobalCVFormat sgf, DimGeography g, DimODM odm, DimForecastAndCommitType fct, DimMTM m, DimTime t1, DimTime t2 ")
				.append("where f.SBBKey = sgf.SBBKey ")
				.append("and f.ForecastType = fct.FCTypeKey ")
				.append("and f.GeographyKey = g.GeographyKey ")
				.append("and f.ODMKey = odm.ODMKey ")
				.append("and f.MTMKey = m.MTMKey ")
				.append("and f.TargetDateKey = t1.TimeKey ")
				.append("and f.VersionDateKey = t2.TimeKey ")
				.append("and fct.FCType = 'CTO+SBB' ")
				.append("and datediff(month, t1.FullDateAlternateKey, ?) = 0 ")
				.append("and datediff(day, t2.FullDateAlternateKey, ?) = 0 ")
				.append("group by m.BOMNumberAlternateKey, g.GeographyName, odm.ODMEnglishName, sgf.GlobalCVKey ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers
								.aliasToBean(MtmGeographyOdmCvQuantity.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, versionDate);

		@SuppressWarnings("unchecked")
		List<MtmGeographyOdmCvQuantity> cvQuantityList = query.list();

		return cvQuantityList;
	}

	@Override
	public List<MtmGeographyOdmCvQuantity> getAllMtmForecastCvQuantityInMonth(
			Date targetDate, Date versionDate) {
		// ENGINE
		// USE MPS FORECAST
		StringBuilder sql = new StringBuilder(
				"select  m.BOMNumberAlternateKey as bomNumber, g.geographyName, odm.ODMEnglishName as odmName, ")
				.append("cvf.GlobalCVKey as cvKey, case when sum(f.Quantity * cvf.Quantity) is null then 0")
				.append(" else sum(f.Quantity * cvf.Quantity) end as quantity ")
				.append("from FactWeeklyForecast f, FactPORinGlobalCVFormat cvf, DimGeography g, DimODM odm, DimForecastAndCommitType fct, DimMTM m, DimTime t1, DimTime t2 ")
				.append("where m.BOMNumberAlternateKey = cvf.MTMBOMNumber ")
				.append("and f.ForecastType = fct.FCTypeKey ")
				.append("and f.GeographyKey = g.GeographyKey ")
				.append("and f.ODMKey = odm.ODMKey ")
				.append("and f.MTMKey = m.MTMKey ")
				.append("and f.TargetDateKey = t1.TimeKey ")
				.append("and f.VersionDateKey = t2.TimeKey ")
				.append("and (fct.FCType = '59' ) ")
				.append("and datediff(month, t1.FullDateAlternateKey, ?) = 0 ")
				.append("and datediff(day, t2.FullDateAlternateKey, ?) = 0 ")
				.append("group by m.BOMNumberAlternateKey, g.GeographyName, odm.ODMEnglishName, cvf.GlobalCVKey ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers
								.aliasToBean(MtmGeographyOdmCvQuantity.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, versionDate);

		@SuppressWarnings("unchecked")
		List<MtmGeographyOdmCvQuantity> cvQuantityList = query.list();

		return cvQuantityList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Forecast> getCausedByForecastByForecastData(Date targetDate,
			Date versionDate, List<NpiWeeklyComponentCommitmentOnForecast> list) {

		if (list == null || list.isEmpty()) {
			return null;
		}

		List<String> keys = new ArrayList<String>();
		// for (ForecastData fcst : list) {
		// keys.add("'" + fcst.getBomNumber() + "'+'"
		// + fcst.getGeographyName() + "'+'" + fcst.getOdmName() + "'");
		// }

		StringBuilder sql = new StringBuilder(
				"select dm.BOMNumberAlternateKey as forecastId, dp.ProductKey as productKey, dg.GeographyName as geographyName,  dm.BOMNumberAlternateKey as bomNumber, ff.Quantity, df.FCType as forecastType, ")
				.append("odm.ODMEnglishName as odmName,dt.FullDateAlternateKey as targetDate, t.FullDateAlternateKey as versionDate, dm.MTMEnglishName as mtmDesc, ")
				.append("dp.ProductEnglishName as productname, dg.GeographyName as region from FactWeeklyForecast ff inner join DimForecastAndCommitType df on ff.ForecastType = df.FCTypeKey ")
				.append("inner join DimMTM dm on dm.MTMKey = ff.MTMKey ")
				.append("inner join DimProduct dp on dp.ProductKey = dm.ProductKey ")
				.append("inner join DimNPIProject dnp on dp.ProductKey = dnp.ProductKey ")
				.append("inner join DimNPIWave dw on dw.NPIProjectKey = dnp.NPIProjectKey ")
				.append("inner join DimGeography dg on dg.GeographyKey = ff.GeographyKey ")
				.append("inner join DimODM odm on odm.ODMKey = ff.ODMKey ")
				.append("inner join DimTime dt on dt.TimeKey = ff.TargetDateKey ")
				.append("inner join DimTime t on t.TimeKey = ff.VersionDateKey ")
				.append("where dm.BOMNumberAlternateKey+dg.GeographyName+odm.ODMEnglishName in (?) ")
				.append("and datediff(day, dt.FullDateAlternateKey, ?) = 0 ")
				.append("and datediff(day, t.FullDateAlternateKey, ?) = 0 ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(Forecast.class));
		query.setParameter(1, targetDate);
		query.setParameter(2, versionDate);
		query.setParameter(0, keys);

		return query.list();
	}

	@SuppressWarnings("unchecked")
	public Map<Date, List<Forecast>> getForecastByRange(int waveId,
			Date targetDate, Date versionEndWeek, Date versionStartWeek,
			boolean showGeo) {

		// StringBuilder sql = new StringBuilder(
		// "select dp.ProductKey as productKey, dg.GeographyName as geographyName,  dm.BOMNumberAlternateKey as bomNumber, ff.Quantity, df.FCType as forecastType, ")
		// .append("odm.ODMEnglishName as odmName,dt.FullDateAlternateKey as targetDate, t.FullDateAlternateKey as versionDate, dm.MTMEnglishName as mtmDesc, ")
		// .append("dp.ProductEnglishName as productname, dg.GeographyName as region, ge.GeographyName as geo from FactWeeklyForecast ff inner join DimForecastAndCommitType df on ff.ForecastType = df.FCTypeKey ")
		// .append("inner join DimMTM dm on dm.MTMKey = ff.MTMKey ").append("inner join DimProduct dp on dp.ProductKey = dm.ProductKey ")
		// .append("inner join DimNPIProject dnp on dp.ProductKey = dnp.ProductKey ")
		// .append("inner join DimNPIWave dw on dw.NPIProjectKey = dnp.NPIProjectKey ")
		// .append("inner join DimGeography dg on dg.GeographyKey = ff.GeographyKey ")
		// .append("inner join DimGeography ge on dg.ParentGeographyKey = ge.GeographyKey ").append("inner join DimODM odm on odm.ODMKey = ff.ODMKey ")
		// .append("inner join DimTime dt on dt.TimeKey = ff.TargetDateKey ").append("inner join DimTime dt1 on dt1.TimeKey = ff.TargetDateKey ")
		// .append("inner join DimTime t on t.TimeKey = ff.VersionDateKey ").append("where dw.PMSWaveIDAlternateKey = ? ")
		// .append("and datediff(day, dt.FullDateAlternateKey, ?) <= 0 ").append("and datediff(day, dt1.FullDateAlternateKey, ?) >= 0 ")
		// .append("and datediff(day, t.FullDateAlternateKey, ?) = 0 ");

		StringBuilder sql = new StringBuilder();
		sql.append(" select sum(f.quantity) as quantity , t2.FullDateAlternateKey as versionDate ");
		if (showGeo) {
			sql.append(" ,dg.GeographyName  as geographyName ");
		}
		sql.append(" from FactWeeklyForecast f ");
		if (showGeo) {
			sql.append(" inner join DimGeography dg on f.GeographyKey = dg.GeographyKey ");
		}
		// sql.append(" inner join DimMTM m on f.MTMKey = m.MTMKey ")
		sql.append(
				" inner join DimForecastAndCommitType fct on f.ForecastType = fct.FCTypeKey ")
				.append(" inner join DimTime t1 on f.TargetDateKey = t1.TimeKey ")
				.append(" inner join DimTime t2 on f.VersionDateKey = t2.TimeKey ")
				.append(" inner join view_getNew_mtm_wave wave on f.MTMKey = wave.MTMKey ")
				.append(" inner join DimNPIWave npiwave on wave.NPIWaveKey = npiwave.NPIWaveKey ")
				.append(" where DATEDIFF(day, t1.FullDateAlternateKey, ?) = 0 ")
				// targetDate
				.append(" and DATEDIFF(day, t2.FullDateAlternateKey, ? ) >= 0 ")
				// startVersionWeek
				.append(" and DATEDIFF(day, t2.FullDateAlternateKey, ? ) <= 0  ")
				// endVersionWeek
				.append(" and fct.FCType = '59' and f.Quantity > 0 ")
				// .append(" and m.productKey= ")
				// 根据waveId查productId的子查询
				// .append(" ( select p.ProductKey ")
				// .append(" from DimNPIProject p, DimNPIWave w, DimProduct pr  ")
				// .append(" where w.NPIProjectKey = p.NPIProjectKey  ")
				// .append(" and p.ProductKey = pr.ProductKey  ")
				// .append(" and p.IsCurrent <> 0  ")
				// .append(" and w.IsCurrent <> 0  ")
				// .append(" and w.PMSWaveIDAlternateKey=? ) ")// waveId
				.append(" and npiwave.PMSWaveIDAlternateKey  =  ? ")
				.append(" group by f.versiondatekey , t2.FullDateAlternateKey ");
		if (showGeo) {
			sql.append(" , dg.GeographyName  ");
		}
		sql.append(" order by VersionDateKey desc ");

		Query query = getSession().createSQLQuery(sql.toString())
				.addScalar("quantity", IntegerType.INSTANCE)
				.addScalar("versionDate", DateType.INSTANCE);
		if (showGeo) {
			((SQLQuery) query).addScalar("geographyName", StringType.INSTANCE);
		}
		query.setResultTransformer(Transformers.aliasToBean(Forecast.class));

		query.setParameter(0, targetDate);
		query.setParameter(1, versionStartWeek);
		query.setParameter(2, versionEndWeek);
		query.setParameter(3, waveId);
		List<Forecast> list = query.list();

		return convertToMap(list);

	}

	@SuppressWarnings("rawtypes")
	public List getForecast(int waveId, Date verionDate) {
		// USE MPS FORECAST
		StringBuilder sql = new StringBuilder(
				"select t2.FullDateAlternateKey , SUM(fwf.Quantity) as quantity ")
				.append(" from FactWeeklyForecast fwf  ")
				.append("join DimMTM dm on dm.MTMKey = fwf.MTMKey ")
				.append(" join DimNPIProject dnp on dnp.ProductKey = dm.ProductKey ")
				// .append(" join FactProductMTMWave fpm on fpm.MTMKey = dm.MTMKey ")
				// // added to support multiple waves
				.append(" join view_getNew_mtm_wave fpm on fpm.MTMKey = dm.MTMKey ")
				.append(" join DimNPIWave dnw on dnw.NPIWaveKey = fpm.NPIWaveKey ")
				// added to support multiple waves
				// remove start
				//.append(" join DimNPIWave dnw1 on dnw1.NPIProjectKey = dnp.NPIProjectKey ")
				// remove end
				.append(" join DimTime t1 on t1.TimeKey = fwf.VersionDateKey ")
				.append(" join DimTime t2 on t2.TimeKey = fwf.TargetDateKey  ")
				.append("  where fwf.ForecastType = 1 and dnw.PMSWaveIDAlternateKey = ? and t1.FullDateAlternateKey = ? and dnw.IsCurrent = 1 and dnp.IsCurrent = 1 ")
				.append("  group by (t2.FullDateAlternateKey)");
		Query query = getSession().createSQLQuery(sql.toString());
		query.setParameter(0, waveId);
		query.setParameter(1, verionDate);

		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<ForecastCompare> getForecastByDates(String waveId,
			Date targetDate, Date comparedDate, Date compareDate, String region) {

		StringBuilder sql = new StringBuilder();
		sql.append(
				" select a.mtm,a.description,a.geo,a.region,a.fcst,isNull(b.fcst,0) as comparedFcst        ")
				.append(" from                                                                              ")
				.append(" (                                                                                 ")
				.append("    select                                                                         ")
				.append("    mtm.BOMNumberAlternateKey as mtm,                                              ")
				.append("    max(mtm.MTMEnglishDescription) as description,                                 ")
				.append("    geo.GeographyName as geo,                                                      ")
				.append("    region.GeographyName as region,                                                ")
				.append("    sum(f.quantity) as fcst                                                        ")
				.append("    from FactWeeklyForecast f                                                      ")
				.append("    inner join DimMTM mtm on f.MTMKey = mtm.MTMKey                                 ")
				.append("    inner join DimForecastAndCommitType fct on f.ForecastType = fct.FCTypeKey      ")
				.append("    inner join DimTime t1 on f.TargetDateKey = t1.TimeKey                          ")
				.append("    inner join DimTime t2 on f.VersionDateKey = t2.TimeKey                         ")
				.append("    inner join view_getNew_mtm_wave wave on f.MTMKey = wave.MTMKey                 ")
				.append("    inner join DimNPIWave npiwave on wave.NPIWaveKey = npiwave.NPIWaveKey          ")
				.append("    left join DimGeography region on region.GeographyKey = f.GeographyKey          ")
				.append("    left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey     ")
				.append("    where DATEDIFF (day, t1.FullDateAlternateKey, ?)= 0                 ")
				.append("    and DATEDIFF(day, t2.FullDateAlternateKey, ?) = 0                   ")
				.append("    and fct.FCType = '59'                                                          ")
				.append("    and f.Quantity > 0                                                             ")
				.append("    and npiwave.PMSWaveIDAlternateKey	= ?                                         ")
				.append("    group by mtm.BOMNumberAlternateKey,geo.GeographyName,region.GeographyName      ")
				.append(" ) as a                                                                            ")
				.append(" left join                                                                         ")
				.append(" (                                                                                 ")
				.append("    select                                                                         ")
				.append("    mtm.BOMNumberAlternateKey as mtm,                                              ")
				.append("    max(mtm.MTMEnglishDescription) as description,                                 ")
				.append("    geo.GeographyName as geo,                                                      ")
				.append("    region.GeographyName as region,                                                ")
				.append("    sum(f.quantity) as fcst                                                        ")
				.append("    from FactWeeklyForecast f                                                      ")
				.append("    inner join DimMTM mtm on f.MTMKey = mtm.MTMKey                                 ")
				.append("    inner join DimForecastAndCommitType fct on f.ForecastType = fct.FCTypeKey      ")
				.append("    inner join DimTime t1 on f.TargetDateKey = t1.TimeKey                          ")
				.append("    inner join DimTime t2 on f.VersionDateKey = t2.TimeKey                         ")
				.append("	 inner join view_getNew_mtm_wave wave on f.MTMKey = wave.MTMKey					")
				.append("	 inner join DimNPIWave npiwave on wave.NPIWaveKey = npiwave.NPIWaveKey 			")
				.append("    left join DimGeography region on region.GeographyKey = f.GeographyKey          ")
				.append("    left join DimGeography geo on geo.GeographyKey = region.ParentGeographyKey     ")
				.append("    where DATEDIFF (day, t1.FullDateAlternateKey, ?)= 0                 ")
				.append("    and DATEDIFF(day, t2.FullDateAlternateKey, ?) = 0                   ")
				.append("    and fct.FCType = '59'                                                          ")
				.append("    and f.Quantity > 0                                                             ")
				.append("    and npiwave.PMSWaveIDAlternateKey	= ?                                                          ")
				.append("    group by mtm.BOMNumberAlternateKey,geo.GeographyName,region.GeographyName      ")
				.append(" ) as b                                                                            ")
				.append(" on  b.region=a.region                                                             ")
				.append(" and b.geo=a.geo                                                                   ")
				.append(" and b.mtm=a.mtm                                                                   ");

		if (!StringUtil.isEmpty(region)) {
			sql.append(" where a.region=?                                                             ");
		}

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(ForecastCompare.class));
		query.setParameter(0, targetDate);
		query.setParameter(1, comparedDate);
		query.setParameter(2, waveId);
		query.setParameter(3, targetDate);
		query.setParameter(4, compareDate);
		query.setParameter(5, waveId);
		if (!StringUtil.isEmpty(region)) {
			query.setParameter(6, region);
		}

		return query.list();
	}

	private Map<Date, List<Forecast>> convertToMap(List<Forecast> list) {
		Map<Date, List<Forecast>> map = new HashMap<Date, List<Forecast>>();
		for (Forecast f : list) {
			List<Forecast> fcst = map.get(f.getVersionDate());
			if (fcst == null) {
				fcst = new ArrayList<Forecast>();
				map.put(f.getVersionDate(), fcst);
			}
			fcst.add(f);
		}
		return map;
	}

	public List<NpiForecast> getNpiForecastByTargetDate(Integer cvKey,
			Integer versionDateKey, Integer targetDateKey, Integer weeks) {

		// StringBuffer datesql = new StringBuffer();
		// datesql.append("select top 1 ShipDateKey from FactBizCalendarMapping a join ");
		// datesql.append("(select BizYear,BizMonth from FactBizCalendarMapping where ShipDateKey = :targetDateKey) ");
		// datesql.append("b ");
		// datesql.append("on a.BizYear=b.BizYear and a.BizMonth = b.BizMonth ");
		// datesql.append("order by a.bizweek) ");
		// Query datequery = getSession().createSQLQuery(datesql.toString());
		// datequery.setInteger("targetDateKey", targetDateKey);
		// Integer firstWeekOfMonth = (Integer) datequery.list().get(0);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String dateStr = versionDateKey.toString();
		Date d = null;
		try {
			d = sdf.parse(dateStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Date WeeksAgoMonday = CalendarUtil.getMondayDateByWeeks(d, weeks);

		Integer WeekAgoversionDateKey = Integer.parseInt(sdf
				.format(WeeksAgoMonday));

		// TODO
		StringBuffer sql = new StringBuffer();
		sql.append("	select a.productKey,SUM(quantity) as quantity   from (");
		sql.append("	select temp.VersionDateKey,");
		sql.append("	temp.TargetDateKey,");
		sql.append("	temp.ProductKey,");
		sql.append("	SUM(temp.Quantity)");
		sql.append("	*(select quantity from DimGlobalCV where GlobalCVKey = :globalCVKey) ");
		sql.append("	as quantity ");
		sql.append("	from (");
		sql.append("	select a.*,b.ProductKey,b.SF,b.GlobalCVKey ");
		sql.append("	from ");
		sql.append("	(");
		sql.append("	select  VersionDateKey,TargetDateKey,mtmkey,SUM(Quantity) ");
		sql.append("	as Quantity ");
		sql.append("	from view_factweeklyforecast_forUI");
		sql.append("	group by VersionDateKey,TargetDateKey,mtmkey having VersionDateKey = :versionDatekey ");
		sql.append("	) a inner join  FactProductMTMCV b");
		sql.append("	on a.MTMKey = b.MTMKey");
		sql.append("	where VersionDateKey = :WeekAgoversionDateKey ");
		sql.append("	and GlobalCVKey = :globalCVKey");
		sql.append("	and TargetDateKey in (select b.ShipDateKey from FactBizCalendarMapping a inner join FactBizCalendarMapping b on a.BizYear=b.BizYear and a.BizMonth= b.BizMonth where a.ShipDateKey = :targetDateKey)");
		sql.append("	)temp");
		sql.append("	group by temp.ProductKey, temp.TargetDateKey,temp.VersionDateKey");
		sql.append("    ) a inner join ");
		sql.append("	(select * from FactCVProductMappingForDNS ");
		sql.append("	where globalcvkey=:globalCVKey and versiondatekey=:versionDatekey) b");
		sql.append("	on a.ProductKey = b.productkey group by a.productkey");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(NpiForecast.class));
		query.setInteger("WeekAgoversionDateKey", WeekAgoversionDateKey);
		query.setInteger("globalCVKey", cvKey);
		query.setInteger("targetDateKey", targetDateKey);
		query.setInteger("versionDatekey", versionDateKey);
		return query.list();
	}

	@Override
	public List<NpiForecast> getForecastRateMonthone(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2, NpiDnsEntry dns,
			Integer forecastDate, Integer dnsversion) {
		// Integer forecastDate =
		// get2MonthsAgoMondayOfMonthkDate(dns.getTargetDateKey());

		StringBuffer sql = new StringBuffer();
		sql.append(
				"select forecast.ProductKey,(forecast.quantity-isnull(shipment.quantity,0)) as quantity ")
				.append("	from ")
				.append("	(select ProductKey,SUM(quantity)  as quantity from ")
				.append("	(select a.* from ")
				.append("	(select temp.VersionDateKey,")
				.append("	temp.TargetDateKey,")
				.append("	temp.ProductKey,")
				.append("	SUM(temp.Quantity)")
				.append("	*(select quantity from DimGlobalCV where GlobalCVKey = :globalCVKey) ")
				.append("	as quantity ")
				.append("	from (")
				.append("	select a.*,b.ProductKey,b.SF,b.GlobalCVKey ")
				.append("	from ")
				.append("	(")
				.append("	select  VersionDateKey,TargetDateKey,mtmkey,SUM(Quantity) ")
				.append("	as Quantity ")
				.append("	from view_factweeklyforecast_forUI")
				.append("	group by VersionDateKey,TargetDateKey,mtmkey having VersionDateKey = :forecastDate ")
				.append("	) a inner join  FactProductMTMCV b")
				.append("	on a.MTMKey = b.MTMKey")
				.append("	where VersionDateKey =:forecastDate")
				.append("	and GlobalCVKey = :globalCVKey")
				.append("	and TargetDateKey in( ")
				.append("	SELECT  timekey as FullDateAlternateKey")
				.append("	FROM DimTime")
				.append("	where (BizMonth =:month_1 and BizYear=:year_1) or (BizMonth =:month_2 and BizYear=:year_2) or")
				.append("	(BizMonth =:month_0 and BizYear=:year_0)")
				.append("	))temp")
				.append("	group by temp.ProductKey, temp.TargetDateKey,temp.VersionDateKey")
				.append("	) a inner join ")
				.append("	(select * from FactCVProductMappingForDNS ")
				.append("	where globalcvkey=:globalCVKey and versiondatekey=:versionDatekey) b")
				.append("	on a.ProductKey = b.productkey) tem group by productkey)")
				.append("	forecast")
				.append("	left join ")
				.append("	(	")
				.append("	select ta.* from ")
				.append("	(select torder.ProductKey,sum(quantity)*(select quantity from DimGlobalCV where GlobalCVKey = :globalCVKey)  ")
				.append("	as quantity ")
				.append("	from  (select * from View_OrderDetail where ShipDate in 	(select FullDateAlternateKey 	from DimTime 	where  (BizMonth =:month_1 and BizYear=:year_1) or (BizMonth =:month_2 and BizYear=:year_2) )and IsShipped = 1)  torder")
				.append("	inner join FactProductMTMCV  mtmcv")
				.append("	on torder.MTMKey = mtmcv.MTMKey and torder.ProductKey=mtmcv.ProductKey")
				.append("	where mtmcv.GlobalCVKey=:globalCVKey")
				.append("	and torder.ShipDate in ")
				.append("	(select FullDateAlternateKey ")
				.append("	from DimTime ")
				.append("	where (BizMonth =:month_1 and BizYear=:year_1) or (BizMonth =:month_2 and BizYear=:year_2))")
				.append("	group by torder.productkey)  ")
				.append("	ta ")
				.append("	inner join (")
				.append("	select * from FactCVProductMappingForDNS ")
				.append("	where globalcvkey=:globalCVKey and versiondatekey=:versionDatekey) b")
				.append("	on ta.ProductKey = b.ProductKey) shipment")
				.append("	on forecast.ProductKey = shipment.ProductKey");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(NpiForecast.class));
		query.setInteger("month_0", dns.getBizMonth());
		query.setInteger("month_1", month_1);
		query.setInteger("month_2", month_2);
		query.setInteger("year_0", dns.getBizYear());
		query.setInteger("year_1", year_1);
		query.setInteger("year_2", year_2);
		query.setInteger("globalCVKey", dns.getCvKey());
		query.setInteger("versionDatekey", dnsversion);
		query.setInteger("forecastDate", forecastDate);

		return query.list();
	}

	@Override
	public List<NpiForecast> getForecastRateMonthtwo(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2,
			String shortegeCode_1, NpiDnsEntry dns, Integer forecastDate,
			Integer dnsversion) {

		// Integer forecastDate =
		// get2MonthsAgoMondayOfMonthkDate(dns.getTargetDateKey());

		StringBuffer sql = new StringBuffer();
		sql.append("select forecast.ProductKey,(forecast.quantity-isnull(shipment.quantity,0)");
		if (shortegeCode_1.equals("Shortage")
				|| shortegeCode_1.equals("Timing Issue")) {
			sql.append("-isnull(component.quantity,0)");
		}

		sql.append(") as quantity ")
				.append("	from ")
				.append("	(select ProductKey,SUM(quantity)  as quantity from ")
				.append("	(select a.* from ")
				.append("	(select temp.VersionDateKey,")
				.append("	temp.TargetDateKey,")
				.append("	temp.ProductKey,")
				.append("	SUM(temp.Quantity)")
				.append("	*(select quantity from DimGlobalCV where GlobalCVKey = :globalCVKey) ")
				.append("	as quantity ")
				.append("	from (")
				.append("	select a.*,b.ProductKey,b.SF,b.GlobalCVKey ")
				.append("	from ")
				.append("	(")
				.append("	select  VersionDateKey,TargetDateKey,mtmkey,SUM(Quantity) ")
				.append("	as Quantity ")
				.append("	from view_factweeklyforecast_forUI")
				.append("	group by VersionDateKey,TargetDateKey,mtmkey having VersionDateKey = :forecastDate ")
				.append("	) a inner join  FactProductMTMCV b")
				.append("	on a.MTMKey = b.MTMKey")
				.append("	where VersionDateKey =:forecastDate")
				.append("	and GlobalCVKey = :globalCVKey")
				.append("	and TargetDateKey in( ")
				.append("	SELECT  timekey as FullDateAlternateKey")
				.append("	FROM DimTime").append("	where ");
		if (!shortegeCode_1.equals("No Shortage")) {
			sql.append("(BizMonth =:month_1 and BizYear=:year_1) or");
		}
		sql.append("	(BizMonth =:month_2 and BizYear=:year_2) or")
				.append("	(BizMonth =:month_0 and BizYear=:year_0)")
				.append("	))temp")
				.append("	group by temp.ProductKey, temp.TargetDateKey,temp.VersionDateKey")
				.append("	) a inner join ")
				.append("	(select * from FactCVProductMappingForDNS ")
				.append("	where globalcvkey=:globalCVKey and versiondatekey=:versionDatekey) b")
				.append("	on a.ProductKey = b.productkey) tem group by productkey)")
				.append("	forecast")
				.append("	left join ")
				.append("	(	")
				.append("	select ta.* from ")
				.append("	(select torder.ProductKey,sum(quantity)*(select quantity from DimGlobalCV where GlobalCVKey = :globalCVKey)  ")
				.append("	as quantity ")
				.append("	from   (select * from View_OrderDetail where ShipDate in 	(select FullDateAlternateKey 	from DimTime 	where  (BizMonth =:month_1 and BizYear=:year_1) or (BizMonth =:month_2 and BizYear=:year_2) ) and IsShipped = 1) torder")
				.append("	inner join FactProductMTMCV  mtmcv")
				.append("	on torder.MTMKey = mtmcv.MTMKey and torder.ProductKey=mtmcv.ProductKey")
				.append("	where mtmcv.GlobalCVKey=:globalCVKey")
				.append("	and torder.ShipDate in ")
				.append("	(select FullDateAlternateKey ")
				.append("	from DimTime ")
				.append("	where ")
				.append("	(BizMonth =:month_1 and BizYear=:year_1) or")
				.append("	(BizMonth =:month_2 and BizYear=:year_2))")
				.append("	group by torder.productkey)  ")
				.append("	ta ")
				.append("	inner join (")
				.append("	select * from FactCVProductMappingForDNS ")
				.append("	where globalcvkey=:globalCVKey and versiondatekey=:versionDatekey) b")
				.append("	on ta.ProductKey = b.ProductKey) shipment")
				.append("	on forecast.ProductKey = shipment.ProductKey")
				.append("	left join (")
				.append("	select productKey, sum(commitment) as   quantity from LenovoBI.dbo.BI_WeeklyComponentCommitmentOnProduct p with (nolock)")
				.append("	inner join DimTime t on p.targetDate = t.TimeKey")
				.append("	where  t.BizMonth = :month_1 and t.BizYear=:year_1 and globalCVKey=:globalCVKey")
				.append("	group by productKey ")
				.append("	)component 	on forecast.ProductKey = component.productKey ");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(NpiForecast.class));
		query.setInteger("month_0", dns.getBizMonth());
		query.setInteger("month_1", month_1);
		query.setInteger("month_2", month_2);
		query.setInteger("year_0", dns.getBizYear());
		query.setInteger("year_1", year_1);
		query.setInteger("year_2", year_2);
		query.setInteger("globalCVKey", dns.getCvKey());
		query.setInteger("versionDatekey", dnsversion);
		query.setInteger("forecastDate", forecastDate);
		return query.list();
	}

	@Override
	public Integer get2MonthsAgoMondayOfMonthkDate(int targetDateKey) {
		StringBuilder sql = new StringBuilder();

		sql.append("	select a.ShipDateKey from FactBizCalendarMapping a ")
				.append("	inner join (")
				.append("	select BizYear,bizmonth from FactBizCalendarMapping fbcm")
				.append("	where shipdatekey = (")
				.append("	select [60DaysDateKey] from FactForecastVersion  ffv")
				.append("	inner join (")
				.append("	select a.BizMonth,a.bizyear  from dbo.FactBizCalendarMapping a")
				.append("	inner join FactBizCalendarMapping b")
				.append("	on a.BizYear=b.BizYear and a.BizMonth=b.BizMonth")
				.append("	where a.ShipDateKey = :targetDateKey and b.BizWeek = 1) as  temp on ffv.BizMonth=temp.BizMonth")
				.append("	and ffv.BizYear = temp.bizyear)) b")
				.append("	on a.BizMonth = b.BizMonth and a.BizYear = b.BizYear and a.BizWeek=1");
		Query query = getSession().createSQLQuery(sql.toString());
		query.setInteger("targetDateKey", targetDateKey);
		return (Integer) (query.list() != null ? query.list().get(0) : null);
	}

	@Override
	public Integer get3MonthsAgo4WeeksMondayOfMonthkDate(int targetDateKey) {
		StringBuilder sql = new StringBuilder();

		sql.append("	select a.ShipDateKey from FactBizCalendarMapping a ")
				.append("	inner join (")
				.append("	select BizYear,bizmonth from FactBizCalendarMapping fbcm")
				.append("	where shipdatekey = (")
				.append("	select [60DaysDateKey] from FactForecastVersion  ffv")
				.append("	inner join (")
				.append("	select a.BizMonth,a.bizyear  from dbo.FactBizCalendarMapping a")
				.append("	inner join FactBizCalendarMapping b")
				.append("	on a.BizYear=b.BizYear and a.BizMonth=b.BizMonth")
				.append("	where a.ShipDateKey = :targetDateKey and b.BizWeek = 1) as  temp on ffv.BizMonth=temp.BizMonth")
				.append("	and ffv.BizYear = temp.bizyear)) b")
				.append("	on a.BizMonth = b.BizMonth and a.BizYear = b.BizYear and a.BizWeek=2");
		Query query = getSession().createSQLQuery(sql.toString());
		query.setInteger("targetDateKey", targetDateKey);
		return (Integer) (query.list() != null ? query.list().get(0) : null);
	}

	@Override
	public List<NpiForecast> getForecastRateMonththree(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2,
			String shortegeCode_1, String shortegeCode_2, NpiDnsEntry dns,
			Integer forecastDate, Integer dnsversion) {

		// Integer forecastDate =
		// get2MonthsAgoMondayOfMonthkDate(dns.getTargetDateKey());

		StringBuffer sql = new StringBuffer();
		sql.append("select forecast.ProductKey,(forecast.quantity");
		if (shortegeCode_1.equals("Shortage")
				|| shortegeCode_1.equals("Timing Issue")) {
			sql.append("-isnull(component.quantity,0)");
		}

		sql.append(") as quantity ")
				.append("	from ")
				.append("	(select ProductKey,SUM(quantity)  as quantity from ")
				.append("	(select a.* from ")
				.append("	(select temp.VersionDateKey,")
				.append("	temp.TargetDateKey,")
				.append("	temp.ProductKey,")
				.append("	SUM(temp.Quantity)")
				.append("	*(select quantity from DimGlobalCV where GlobalCVKey = :globalCVKey) ")
				.append("	as quantity ")
				.append("	from (")
				.append("	select a.*,b.ProductKey,b.SF,b.GlobalCVKey ")
				.append("	from ")
				.append("	(")
				.append("	select  VersionDateKey,TargetDateKey,mtmkey,SUM(Quantity) ")
				.append("	as Quantity ")
				.append("	from view_factweeklyforecast_forUI")
				.append("	group by VersionDateKey,TargetDateKey,mtmkey having VersionDateKey = :forecastDate ")
				.append("	) a inner join  FactProductMTMCV b")
				.append("	on a.MTMKey = b.MTMKey")
				.append("	where VersionDateKey =:forecastDate")
				.append("	and GlobalCVKey = :globalCVKey")
				.append("	and TargetDateKey in( ")
				.append("	SELECT  timekey as FullDateAlternateKey")
				.append("	FROM DimTime").append("	where ");
		if (!shortegeCode_1.equals("No Shortage")) {
			sql.append("(BizMonth =:month_1 and BizYear=:year_1) or");
		}
		if (!shortegeCode_2.equals("No Shortage")) {
			sql.append("(BizMonth =:month_2 and BizYear=:year_2) or");
		}
		sql.append("	(BizMonth =:month_0 and BizYear=:year_0)")
				.append("	))temp")
				.append("	group by temp.ProductKey, temp.TargetDateKey,temp.VersionDateKey")
				.append("	) a inner join ")
				.append("	(select * from FactCVProductMappingForDNS ")
				.append("	where globalcvkey=:globalCVKey and versiondatekey=:versionDatekey) b")
				.append("	on a.ProductKey = b.productkey) tem group by productkey)")
				.append("	forecast")
				.append("	left join (")
				.append("	select productKey, sum(commitment) as  quantity from LenovoBI.dbo.BI_WeeklyComponentCommitmentOnProduct p with (nolock)")
				.append("	inner join DimTime t on p.targetDate = t.TimeKey")
				.append("	where ( (t.BizMonth = :month_1 and t.BizYear=:year_1) or (t.BizMonth = :month_2 and t.BizYear=:year_2)) and globalCVKey=:globalCVKey ")
				.append("	group by productKey ")
				.append("	)component 	on forecast.ProductKey = component.productKey");

		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(
						Transformers.aliasToBean(NpiForecast.class));
		query.setInteger("month_0", dns.getBizMonth());
		query.setInteger("month_1", month_1);
		query.setInteger("month_2", month_2);
		query.setInteger("year_0", dns.getBizYear());
		query.setInteger("year_1", year_1);
		query.setInteger("year_2", year_2);
		query.setInteger("globalCVKey", dns.getCvKey());
		query.setInteger("versionDatekey", dnsversion);
		query.setInteger("forecastDate", forecastDate);
		return query.list();
	}

	@Override
	public List getForecastByVersionDate(Integer forecastDate) {
		StringBuffer sb = new StringBuffer();
		sb.append("select top 1 id from view_factweeklyforecast_forui where versiondatekey = :forecastDate");
		Query query = getSession().createSQLQuery(sb.toString());
		query.setInteger("forecastDate", forecastDate);
		return query.list();
	}

	// private Integer getFirstWeekDateOfBizMonthByTargetDateKey(
	// Integer targetDatekey) {
	// StringBuffer sb = new StringBuffer();
	// sb.append(
	// "select b.shipdatekey from FactBizCalendarMapping a inner join FactBizCalendarMapping b")
	// .append("on a.bizmonth = b.bizmonth and a.bizyear= b.bizyear")
	// .append("where  a.ShipDateKey = :targetDatekey and b.BizWeek=1");
	//
	// Query query = getSession().createSQLQuery(sb.toString());
	// query.setInteger("targetDatekey", targetDatekey);
	//
	// return (Integer) (query.list() == null ? null : query.list().get(0));
	// }
}
