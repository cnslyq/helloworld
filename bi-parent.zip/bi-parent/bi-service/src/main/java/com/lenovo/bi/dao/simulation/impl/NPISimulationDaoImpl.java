package com.lenovo.bi.dao.simulation.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateQueryBaseBi;
import com.lenovo.bi.dao.simulation.NPISimulationDao;
import com.lenovo.bi.form.simulation.SearchNPISimulationForm;
import com.lenovo.bi.form.simulation.SearchNPISimulationHistoryForm;
import com.lenovo.bi.model.NPISimulationDetail;
import com.lenovo.bi.model.NPISimulationSummary;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.view.simulation.NPISimulationSummaryView;
import com.lenovo.common.model.Pager;
@Repository
@SuppressWarnings("unchecked")
public class NPISimulationDaoImpl extends HibernateQueryBaseBi implements NPISimulationDao {

	@Override
	public List<NPISimulationSummary> getNPISimulationSummaryByCondition(
			SearchNPISimulationForm form,Pager<NPISimulationSummaryView>pager) {
		StringBuffer sb=new StringBuffer();
		sb.append(" from NPISimulationSummary summary where 1=1 ");
		//select dialog
		if("select".equalsIgnoreCase(form.getFormType())){
			if(form.getProductName()!=null&&!"".equals(form.getProductName().trim())){
				sb.append(" and summary.productName = '"+form.getProductName()+"'");
			}
			if(form.getWaveName()!=null&&!"".equals(form.getWaveName().trim())){
				sb.append(" and summary.waveName = '"+form.getWaveName()+"'");
			}
			sb.append(" and summary.type= '"+form.getSgaSleType().toLowerCase()+"'");
			//可以看见自己创建和public的
			sb.append(" and ( summary.createdBy = '"+form.getUsername()+"'" +" or summary.IsShared = 1 ) " );
		}
		//public||private simulation
		if(form.getFormType().indexOf("Simulation")!=-1){
			if(form.getProductName()!=null&&!"".equals(form.getProductName().trim())){
				sb.append(" and summary.productName like '%"+form.getProductName()+"%'");
			}
			if(form.getSimulationName()!=null&&!"".equals(form.getSimulationName().trim())){
				sb.append(" and summary.name like '%"+form.getSimulationName()+"%'");
			}
			if(form.getSgaSleType()!=null){
				sb.append(" and summary.type = '"+form.getSgaSleType().toLowerCase()+"'");
			}
		}
		
		if("privateSimulation".equalsIgnoreCase(form.getFormType())){
			sb.append(" and summary.createdBy = '"+form.getUsername()+"'");
		}
		
		if("publicSimulation".equalsIgnoreCase(form.getFormType())){
			sb.append(" and summary.IsShared = 1 ");
			if(!"-1".equals(form.getCreatedBy())){
				sb.append(" and summary.createdBy= '"+form.getCreatedBy()+"'");
			}
		}
		
		if(StringUtils.isNotBlank(form.getSortColumn())){
			sb.append(" order by "+form.getSortColumn()+" "+form.getSortType());
		}else{
			sb.append(" order by LastModifiedDate desc ");
		}
		
		String hql=sb.toString();
		
		Query q=getSession().createQuery(hql.toString());
		
		if(form.getCurrentPage()!=null){
			if(pager!=null){
				q.setMaxResults(pager.getPagerInfo().getPageSize());
				q.setFirstResult(pager.getPagerInfo().getStartRow());
			}
		}
		
		return q.list();
	}

	@Override
	public List<NPISimulationDetail> getLastestNPISimulationDetailByCondition(
			int simulationId) {
		StringBuffer sql=new StringBuffer();
		sql.append("select id,indicator1,indicator2,indicator3,indicator4,")
		.append("targetDate,itemName,categoryCode,modifiedDate,originalData,modifiedData from (select ")
		.append("ROW_NUMBER()OVER(partition by SimulationId,Indicator1,Indicator2,Indicator3,Indicator4,TargetDate,ItemName Order by ModifiedDate DESC,id DESC)as rn,")
		.append("* from bi_npisimulationdetail where SimulationId=").append(simulationId).append(")a ")
		.append(" where a.rn=1");
		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(NPISimulationDetail.class));
		return query.list();
	}

	@Override
	public List<NPISimulationDetail> getHistoricalNPISimulationDetailByCondition(
			SearchNPISimulationHistoryForm form) {
		StringBuffer sql=new StringBuffer();
	    sql.append(" select case CategoryCode                                                                                  ")
	    .append("       when 'ODM' then itemName+':'+ originalData                                                      ")
	    .append("       when 'defect' then itemName+':'+ originalData                                                   ")
	    .append("       else originalData                                                                               ")
	    .append("  end   as originalData,                                                                               ")
	    .append("  case  CategoryCode                                                                                       ")
	    .append("   when 'ODM' then itemName+':'+ modifiedData                                                          ")
	    .append("       when 'defect' then itemName+':'+ modifiedData                                                   ")
	    .append("       else modifiedData                                                                               ")
	    .append("  end   as modifiedData,                                                                               ")
	    .append(" targetDate,   ModifiedDate,                                                                                        ")
	    .append("   case CategoryCode                                                                                   ")
		.append("         when 'supply' then CategoryCode+'('+isnull(Indicator1,'')+'/'+isnull(Indicator2,'')+')'       ")
		.append("         when 'ODM' then  CategoryCode+'('+Indicator1+')'                                              ")
		.append("         else CategoryCode                                                                             ")
		.append("  end   as    itemName                                                                                 ")
		.append(" from bi_NPISimulationDetail    where simulationId=:id                                                    ");
		 if(!"ALL".equals(form.getItem())&&!StringUtil.isEmpty(form.getItem())){
			 sql.append(" and  CategoryCode = :categoryCode");
		 }
		 if(!StringUtil.isEmpty(form.getFromDate())){
			 sql.append(" and ModifiedDate >:fromDate ");
		 }
		 if(!StringUtil.isEmpty(form.getToDate())){
			 sql.append(" and ModifiedDate <:toDate ");
		 }
		Query query = getSession().createSQLQuery(sql.toString())
		.setResultTransformer(Transformers.aliasToBean(NPISimulationDetail.class));
		 query.setParameter("id", form.getSimulationId());
		 if(!"ALL".equals(form.getItem())&&!StringUtil.isEmpty(form.getItem())){
			 query.setParameter("categoryCode", form.getItem());
		 }
         if(!StringUtil.isEmpty(form.getFromDate())){
			 query.setParameter("fromDate", form.getFromDate());
		 }
         if(!StringUtil.isEmpty(form.getToDate())){
        	 query.setParameter("toDate", form.getToDate());
         }
		return query.list();
	}

	@Override
	public void batchDeleteNPISimulationSummary(
			List<NPISimulationSummary> simulationSummaryList) {
		for(NPISimulationSummary summary:simulationSummaryList){
			getSession().delete(summary);
		}
	}


	@Override
	public void updateNPISimulationSummary(
			NPISimulationSummary simulationSummary) {
		try {
			NPISimulationSummary summary=(NPISimulationSummary) getSession().get(NPISimulationSummary.class, simulationSummary.getId());
			simulationSummary.setCreatedDate(summary.getCreatedDate());
			PropertyUtils.copyProperties(summary, simulationSummary);
			if(summary.getCreatedDate()==null){
				summary.setCreatedDate(new Date());
			}
			getSession().update(summary);
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	@Override
	public void batchUpdateNPISimulationDetail(
			List<NPISimulationDetail> simulationDetailList) {
		for(NPISimulationDetail detail:simulationDetailList){
			getSession().update(detail);
		}
	}

	@Override
	public NPISimulationSummary addNPISimulationSummary(NPISimulationSummary simulationSummary) {
            	getSession().save(simulationSummary);
//                getSession().flush();
//                getSession().close();
            	return simulationSummary;
	}

	@Override
	public void batchAddNPISimulationDetail(
			List<NPISimulationDetail> simulationDetailList) {
      for(NPISimulationDetail detail:simulationDetailList){
    	  getSession().save(detail);
      }
//      getSession().flush();
//      getSession().close();
	}
	
	@Override
	public int getTotalCountNPISimulationSummaryByCondition(SearchNPISimulationForm form){
		StringBuffer sb=new StringBuffer();
		sb.append(" select count(summary.id) from NPISimulationSummary AS summary where 1=1 ");
		
		if("select".equalsIgnoreCase(form.getFormType())){
			if(form.getProductName()!=null&&!"".equals(form.getProductName().trim())){
				sb.append(" and summary.productName = '"+form.getProductName()+"'");
			}
			if(form.getWaveName()!=null&&!"".equals(form.getWaveName().trim())){
				sb.append(" and summary.waveName = '"+form.getWaveName()+"'");
			}
			sb.append(" and summary.type= '"+form.getSgaSleType().toLowerCase()+"'");
			//可以看见自己创建和public的
			sb.append(" and ( summary.createdBy = '"+form.getUsername()+"'" +" or summary.IsShared = 1 ) " );
		}
		
		if(form.getFormType().indexOf("Simulation")!=-1){
			if(form.getProductName()!=null&&!"".equals(form.getProductName().trim())){
				sb.append(" and summary.productName like '%"+form.getProductName()+"%'");
			}
			if(form.getSimulationName()!=null&&!"".equals(form.getSimulationName().trim())){
				sb.append(" and summary.name like '%"+form.getSimulationName()+"%'");
			}
			if(form.getSgaSleType()!=null){
				sb.append(" and summary.type = '"+form.getSgaSleType().toLowerCase()+"'");
			}
		}
		
		if("privateSimulation".equalsIgnoreCase(form.getFormType())){
			sb.append(" and summary.createdBy = '"+form.getUsername()+"'");
		}
		
		if("publicSimulation".equalsIgnoreCase(form.getFormType())){
			sb.append(" and summary.IsShared = 1 ");
			if(!"-1".equals(form.getCreatedBy())){
				sb.append(" and summary.createdBy= '"+form.getCreatedBy()+"'");
			}
		}
		
		String hql=sb.toString();
		Query query=getSession().createQuery(hql.toString());
		int count = ((Long)query.uniqueResult()).intValue();
		return count;
	}
	
	@Override
	public NPISimulationSummary getNPISimulationSummaryById(String id) {
		StringBuffer sb=new StringBuffer();
		sb.append(" from NPISimulationSummary summary where id =  ").append(id);
		String hql=sb.toString();
		Query q=getSession().createQuery(hql.toString());
		List<NPISimulationSummary> list = q.list();
		if(CollectionUtils.isNotEmpty(list)){
			return list.get(0);
		}
		return null;
	}
	
	@Override
	public void batchDeleteNPISimulationSummary(Integer[]ids){
		StringBuffer str=new StringBuffer();
		str.append(" delete from BI_NPISimulationDetail where SimulationId in (:ids) ");
		Query q=getSession().createSQLQuery(str.toString());
		q.setParameterList("ids", ids);
		q.executeUpdate();
		
		StringBuffer sb=new StringBuffer();
		sb.append(" delete from BI_NPISimulationSummary  where id in (:ids)  ");
		Query query=getSession().createSQLQuery(sb.toString());
		query.setParameterList("ids", ids);
		query.executeUpdate();
	}
	
	@Override
	public List<String> getCreatedBy(){
		StringBuffer sb=new StringBuffer();
		sb.append(" select distinct createdBy from BI_NPISimulationSummary summary ");
		sb.append(" where summary.IsShared = 1 ");
		sb.append(" order by summary.createdBy  ");
		Query query=getSession().createSQLQuery(sb.toString());
		return query.list();
	}

	@Override
	public List<NPISimulationDetail> getSimulationDetailBySimulationId(Integer id) {
		StringBuffer sb=new StringBuffer();
		sb.append(" from NPISimulationDetail summary where id =  ").append(id);
		String hql=sb.toString();
		Query q=getSession().createQuery(hql.toString());
		return q.list();
	}
	
}
