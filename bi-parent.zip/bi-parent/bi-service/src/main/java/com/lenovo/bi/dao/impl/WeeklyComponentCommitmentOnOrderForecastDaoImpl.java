package com.lenovo.bi.dao.impl;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dto.SupplyShortage;
import com.lenovo.bi.model.WeeklyComponentCommitmentOnOrderForecast;
import com.lenovo.bi.util.CalendarUtil;

@Repository
public class WeeklyComponentCommitmentOnOrderForecastDaoImpl extends HibernateBaseDaoImplBi<WeeklyComponentCommitmentOnOrderForecast> {
	public void deleteWeeklyComponentCommitmentOnOrderForecastForVersionDate(Date versionDate) {
		deleteDataForVersionDate("WeeklyComponentCommitmentOnOrderForecast", versionDate);
	}
	@SuppressWarnings("unchecked")
	public List<SupplyShortage> querySupplyShortageByProductKey(String productKey, Date versionDate, Date startDate, Date endDate, String ttvPhase){
		StringBuffer sb = new StringBuffer("select sum(Delta) as shortage,sum(Demand) as demand,sum(Commitment) as commitment,targetDate,globalCVKey ");
		sb.append("from BI_WeeklyComponentCommitmentOnOrderForecast c ")
		.append("where fornpi = 1 and Delta > 0 ")
		.append("and productKey = :productKey and ttvphase = :ttvphase ")
		.append("and versiondate = :versiondate and targetDate >= :startDate and targetDate <= :endDate ")
		.append("group by globalCVKey,targetDate");
		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("shortage", IntegerType.INSTANCE)
				.addScalar("demand", IntegerType.INSTANCE)
				.addScalar("commitment", IntegerType.INSTANCE)
				.addScalar("globalCVKey", StringType.INSTANCE)
				.addScalar("targetDate", DateType.INSTANCE)
				.setResultTransformer(
						Transformers.aliasToBean(SupplyShortage.class));
		
		query.setParameter("productKey", productKey);
		query.setParameter("ttvphase", ttvPhase);
		try {
			query.setParameter("versiondate", CalendarUtil.date2String(versionDate));
			query.setParameter("startDate", CalendarUtil.date2String(startDate));
			query.setParameter("endDate", CalendarUtil.date2String(endDate));
		} catch (HibernateException e) {
			e.printStackTrace();
			return null;
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
		
		return query.list();
	}
	@SuppressWarnings("unchecked")
	public List<SupplyShortage> queryBomNumberByProductKey(String productKey, Date versionDate, Date startDate, Date endDate, String ttvPhase){
		StringBuffer sb = new StringBuffer("select distinct targetDate,bomNumber ");
		sb.append("from BI_WeeklyComponentCommitmentOnOrderForecast c ")
		.append("where fornpi = 1 and Delta > 0 ")
		.append("and productKey = :productKey and ttvphase = :ttvphase ")
		.append("and versiondate = :versiondate and targetDate >= :startDate and targetDate <= :endDate order by bomNumber ");
		Query query = getSession().createSQLQuery(sb.toString())
				.addScalar("bomNumber", StringType.INSTANCE)
				.addScalar("targetDate", DateType.INSTANCE)
				.setResultTransformer(
						Transformers.aliasToBean(SupplyShortage.class));
		
		query.setParameter("productKey", productKey);
		query.setParameter("ttvphase", ttvPhase);
		try {
			query.setParameter("versiondate", CalendarUtil.date2String(versionDate));
			query.setParameter("startDate", CalendarUtil.date2String(startDate));
			query.setParameter("endDate", CalendarUtil.date2String(endDate));
		} catch (HibernateException e) {
			e.printStackTrace();
			return null;
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
		
		return query.list();
	}
}
