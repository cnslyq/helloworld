package com.lenovo.bi.dao.system.console.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DoubleType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.dao.system.console.ConsoleDao;
import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.BiWeeklyProcessStatus;
import com.lenovo.bi.model.system.ThresholdDetail;
import com.lenovo.common.model.PagerInformation;

@Repository
public class ConsoleDaoImpl extends HibernateBaseDaoImplBi implements ConsoleDao  {

	@Override
	public List<ThresholdDetail> listThreshold(DictSearchForm form, PagerInformation pagerInfo) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biConfigurables.id as id,")
			   .append("biConfigurables.Name as name,")
			   .append("biConfigurables.Value as value,")
			   .append("biConfigurables.Description as description")
			   .append( " from BI_Configurables biConfigurables");
		if(form.getSearchBy() != null) {
			sBuffer.append(" where biConfigurables.Name like '%").append(form.getSearchBy().replace("'","''")).append("%'");
		}
		
		if(form.getSortColumn() != null && form.getSortType() != null) {
			sBuffer.append(" order by ").append(form.getSortColumn()).append(" ").append(form.getSortType());
		}
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				//.addScalar("value", FloatType.INSTANCE)
				.addScalar("value", DoubleType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ThresholdDetail.class));
		query.setMaxResults(pagerInfo.getPageSize());
		query.setFirstResult(pagerInfo.getStartRow());
		
		return query.list();
	}
	
	@Override
	public ThresholdDetail findThresholdById(Integer thresholdId) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append( "from ThresholdDetail thresholdDetail")
			   .append( " where thresholdDetail.id=").append(thresholdId)
			   ;
		Query query = getSession().createQuery(sBuffer.toString());
		return (ThresholdDetail)(query.list().get(0));
	}

	@Override
	public void saveThreshold(ThresholdDetail thresholdDetail) {
		this.add(thresholdDetail);
	}
	
	@Override
	public void saveEditedThreshold(ThresholdDetail thresholdDetail) {
		//Transaction tx = this.getSession().beginTransaction();
		getSession().update(thresholdDetail);
		getSession().flush();
		//tx.commit();
	}
	
	@Override
	public void deleteThresholds(String thresholdIds) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("delete")
			   .append( " from ThresholdDetail thresholdDetail")
			   .append(" where thresholdDetail.id in (")
			   .append(thresholdIds).append(")");
		Query q = getSession().createQuery(sBuffer.toString());
		q.executeUpdate();
		
	}
	
	public void deleteThresholdById(Integer thresholdId) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("delete")
			   .append( " from ThresholdDetail thresholdDetail")
			   .append(" where thresholdDetail.id =").append(thresholdId);
		Query q = getSession().createQuery(sBuffer.toString());
		q.executeUpdate();
		
	}
	
	public ThresholdDetail getThresholdById(Integer thresholdId) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select biConfigurables.id as id,biConfigurables.Name as name,biConfigurables.Value as value,biConfigurables.Description as description")
			   .append( " from BI_Configurables biConfigurables");
	    sBuffer.append(" where biConfigurables.id=").append(thresholdId);
		
		Query query = getSession().createSQLQuery(sBuffer.toString())
				.addScalar("id", IntegerType.INSTANCE)
				.addScalar("name", StringType.INSTANCE)
				//.addScalar("value", FloatType.INSTANCE)
				.addScalar("value", DoubleType.INSTANCE)
				.addScalar("description", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(ThresholdDetail.class));
		
		return (ThresholdDetail)query.list().get(0);
	}

	@Override
	public int getThresholdDetailCountByConditions(DictSearchForm form) {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append("select count(name)")
			   .append( " from BI_Configurables biConfigurables");
		if(form.getSearchBy() != null) {
			sBuffer.append(" where biConfigurables.Name like '%").append(form.getSearchBy().replace("'","''")).append("%'");
		}
		Query query = getSession().createSQLQuery(sBuffer.toString());
		List<Integer> rs = query.list(); 
		if (rs.size() == 0){
			return 0;
		} else{
			return rs.get(0).intValue(); 
		}
	}

	@Override
	public List<BiWeeklyProcessStatus> getEngineStatusHistory() {
		StringBuffer sBuffer = new StringBuffer();
		sBuffer.append( "from BiWeeklyProcessStatus bps order by bps.processDate desc");
		Query query = getSession().createQuery(sBuffer.toString());
		query.setMaxResults(15);
		return query.list();
	}

}
