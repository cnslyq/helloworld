package com.lenovo.bi.engine;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.lenovo.bi.dto.TTMDemand;
import com.lenovo.bi.dto.WeeklyComponentCommitment;
import com.lenovo.bi.enumobj.KPILights;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.service.npi.helper.NPIDOIHelper;
import com.lenovo.bi.util.CalendarUtil;
/**
 * 
 * 
 * @author henry_lian
 *
 */
@Component
@Order(2)
public class TTMDOIKPIProcessor implements TTMKPIProcessor {

	@Autowired
	private NPIDOIHelper nPIDOIHelper;
	
	@Override
	public void process(ProjectSummary ps, Date versionDate) {
		
		if(ps.getTtmStatus().equals(Status.NA.name())){
			return;
		}
		List<TTMDemand> ttmDemand = nPIDOIHelper.getTTMDemandListByWaveId(ps.getPmsWaveId());
		Date targetDate = ps.getTtmTargetDate();
		if(targetDate != null){
			targetDate = CalendarUtil.getMondayDateByDate(targetDate);
			//targetDate = CalendarUtil.getMondayDateByWeeks(targetDate, 1);
		}
		List<WeeklyComponentCommitment> componentCommit = nPIDOIHelper.getCommitmentByTargetDate(targetDate, versionDate,ps.getPmsWaveId());
		//List<WeeklyComponentCommitment> componentCommit = nPIDOIHelper.getCommitmentByTargetDate(versionDate, versionDate,ps.getPmsWaveId());
		
		Map<String, Integer> componentCommitMap = new HashMap<String, Integer>();
		
		for(WeeklyComponentCommitment wc:componentCommit){
			componentCommitMap.put(String.valueOf(wc.getCvkey()), wc.getCommitment());
		}
		
		ps.setDoi(KPILights.GREEN.name());
		for(TTMDemand td: ttmDemand){
			if(td.getDemand() == 0){
				continue;
			}
			String mapKey = String.valueOf(td.getCvKey());
			if(componentCommitMap.get(mapKey) == null || componentCommitMap.get(mapKey) < td.getDemand()){
				ps.setDoi(KPILights.RED.name());
				break;
			}
		}
	}

}
