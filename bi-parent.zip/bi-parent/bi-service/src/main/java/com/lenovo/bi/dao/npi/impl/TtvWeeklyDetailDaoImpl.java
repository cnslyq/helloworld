package com.lenovo.bi.dao.npi.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.model.TtvWeeklyDetail;
import com.lenovo.bi.util.CalendarUtil;

@Repository
public class TtvWeeklyDetailDaoImpl extends HibernateBaseDaoImplBi<TtvWeeklyDetail> {
	@SuppressWarnings("unchecked")
	public List<TtvWeeklyDetail> getNpiWeeklyDetail(int pmsWaveId, Date versionDate) {
		StringBuffer hql = new StringBuffer("from TtvWeeklyDetail where pmsWaveId = :pmsWaveId ").append("and datediff(day, versionDate, :versionDate) = 0 ")
				.append("order by targetDate");

		Query query = getSession().createQuery(hql.toString());
		query.setParameter("pmsWaveId", pmsWaveId);
		query.setParameter("versionDate", versionDate);
		return query.list();
	}

	/**
	 * Return the details between start date and end date, both inclusively
	 * 
	 * @param pmsWaveId
	 * @param startDate
	 *            can be null
	 * @param endDate
	 *            can be null
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<TtvWeeklyDetail> getNpiWeeklyDetail(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		StringBuffer hql = new StringBuffer("from TtvWeeklyDetail tt where pmsWaveId = :pmsWaveId ");
		if (versionDate == null) {
			versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins());
		}
		hql.append(" and versionDate in (select max(versionDate) from TtvWeeklyDetail where tt.targetDate = targetDate and tt.pmsWaveId = pmsWaveId ")
		.append(" and datediff(day, :versionDate, versionDate) <= 0) ");

		if (startDate != null) {
			hql.append("and datediff(day, :startDate, targetDate) >= 0 ");
		}

		if (endDate != null) {
			hql.append("and datediff(day, targetDate, :endDate) >= 0 ");
		}

		hql.append("order by targetDate ");
		Query query = getSession().createQuery(hql.toString());
		if (versionDate != null)
			query.setParameter("versionDate", versionDate);
		query.setParameter("pmsWaveId", pmsWaveId);

		if (startDate != null) {
			query.setParameter("startDate", startDate);
		}

		if (endDate != null) {
			query.setParameter("endDate", endDate);
		}

		return (List<TtvWeeklyDetail>) query.list();
	}
	@SuppressWarnings("unchecked")
	public List<TtvWeeklyDetail> getLastNpiWeeklyDetail(int pmsWaveId, Date startDate, Date endDate, Date versionDate) {
		StringBuffer hql = new StringBuffer("from TtvWeeklyDetail d where pmsWaveId = :pmsWaveId ");
		if (versionDate == null) {
			versionDate = CalendarUtil.getMondayDateByDate(CalendarUtil.getTodayWithoutMins());
		}
		hql.append(" and versionDate in (select max(versionDate) from TtvWeeklyDetail where d.targetDate = targetDate and d.pmsWaveId = pmsWaveId ")
		.append(" and datediff(day, :versionDate, versionDate) <= 0) ");

		if (startDate != null) {
			hql.append("and datediff(day, :startDate, targetDate) >= 0 ");
		}

		if (endDate != null) {
			hql.append("and datediff(day, targetDate, :endDate) >= 0 ");
		}

		hql.append("order by targetDate ");
		Query query = getSession().createQuery(hql.toString());
		if (versionDate != null)
			query.setParameter("versionDate", versionDate);
		query.setParameter("pmsWaveId", pmsWaveId);

		if (startDate != null) {
			query.setParameter("startDate", startDate);
		}

		if (endDate != null) {
			query.setParameter("endDate", endDate);
		}

		return (List<TtvWeeklyDetail>) query.list();
	}

	@SuppressWarnings("unchecked")
	public List<Integer> getPmsWaveIdsForVersionDate(Date versionDate) {
		StringBuffer hql = new StringBuffer(
				"select distinct pmsWaveId from TtvWeeklyDetail where datediff(day, versionDate, :versionDate) = 0 order by pmsWaveId");
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("versionDate", versionDate);

		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<TtvWeeklyDetail> getNpiWeeklyDetail(Date targetDate, Date versionDate) {
		StringBuffer hql = new StringBuffer("from TtvWeeklyDetail where datediff(day, targetDate, :targetDate) = 0 ")
				.append("and datediff(day, versionDate, :versionDate) = 0 ");
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("targetDate", targetDate);
		query.setParameter("versionDate", versionDate);

		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<Date> getTargetDates(Date versionDate) {
		StringBuffer sql = new StringBuffer(
				"select distinct TargetDate from BI_TTVWeeklyDetail where datediff(day, versionDate, :versionDate) = 0 order by TargetDate");
		Query query = getSession().createSQLQuery(sql.toString());
		query.setParameter("versionDate", versionDate);

		return query.list();
	}
	
	public Date getMaxVersionDateByWaveId(String waveId) {
		StringBuffer sql = new StringBuffer(
				"select max(versionDate) from BI_TTVWeeklyDetail where pmswaveid = :waveId ");
		Query query = getSession().createSQLQuery(sql.toString());
		query.setParameter("waveId", waveId);
		return (Date) query.uniqueResult();
	}
	public List<Object[]> getTTVDemandByWaveId(String waveId,String versionDate,String startDate,String endDate){
		StringBuffer sql=new StringBuffer("select targetDate,"
				+ " case when versionDate>targetDate then (case when OrderQuantity<0 then 0 else OrderQuantity end) else (case when futureOrderQuantity<0 then 0 else futureOrderQuantity end) + (case when futureForecastQuantity<0 then 0 else futureForecastQuantity end) end as demand "
				+ " from bi_ttvweeklydetail "
				+ " where versiondate=:versionDate and pmswaveid=:waveId "
				+ " and targetDate between :startDate and :endDate ");
		Query query=getSession().createSQLQuery(sql.toString());
		query.setParameter("versionDate", "2014-08-18");
		query.setParameter("waveId", 127);
		query.setParameter("startDate", "2013-01-01");
		query.setParameter("endDate", "2015-12-12");
		return query.list();
	}
}
