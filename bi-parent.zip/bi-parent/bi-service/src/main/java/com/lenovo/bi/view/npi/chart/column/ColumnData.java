package com.lenovo.bi.view.npi.chart.column;

public class ColumnData {

	private Number value;
	private String color;
	private String link;
	private String tooltext;
	private String dashed = "0";
	
	public String getDashed() {
		return dashed;
	}

	public void setDashed(String dashed) {
		this.dashed = dashed;
	}

	public Number getValue() {
		return value;
	}

	public void setValue(Number value) {
		this.value = value;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getTooltext() {
		return tooltext;
	}

	public void setTooltext(String tooltext) {
		this.tooltext = tooltext;
	}
}
