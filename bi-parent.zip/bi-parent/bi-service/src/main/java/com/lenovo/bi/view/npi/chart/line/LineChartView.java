package com.lenovo.bi.view.npi.chart.line;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;

public class LineChartView {

	private LineChartConfig config;

	private Categories cats;

	private List<DataSetParent> dataSetList;

	public List<DataSetParent> getDataSetList() {
		return dataSetList;
	}

	@JsonProperty("dataset")
	public void setDataSetList(List<DataSetParent> dataSetList) {
		this.dataSetList = dataSetList;
	}

	public LineChartConfig getConfig() {
		return config;
	}

	@JsonProperty("chart")
	public void setConfig(LineChartConfig config) {
		this.config = config;
	}

	public Categories getCats() {
		return cats;
	}

	@JsonProperty("categories")
	public void setCats(Categories cats) {
		this.cats = cats;
	}

}
