package com.lenovo.bi.service.sc.impl;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.sc.LtfcDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FaOverViewChartData;
import com.lenovo.bi.dto.sc.LTFCRemarkChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.LtfcTypeEnum;
import com.lenovo.bi.enumobj.OTSStatusEnum;
import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.service.common.CommonService;
import com.lenovo.bi.service.sc.LTFCService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.DataSetLine;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.chart.pie.PieSlice;
import com.lenovo.bi.view.sc.fa.LTFCDetailView;

@Service
public class LTFCServiceImpl implements LTFCService {

	@Inject
	LtfcDao ltfcDao;
	
	@Inject
	CommonService commonService;
	
	@Override
	public ColumnChartView getOverviewChart(SearchFaForm form) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();
		setOverviewChartInfomation(columnChartView);
		columnChartView.getChartInfo().setForceDecimals("2");
		columnChartView.getChartInfo().setNumdivlines("9");
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
				|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
			String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
			
		    //if(!form.isShowQuarterOverview()) {
				for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
					String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
					if (form.getEndDate()!=null && yearMonth.compareTo(form.getEndDate()) > 0) 
						break;
					Category category = new Category();
					category.setName(yearMonth);
					categoryList.add(category);
				}
		/*}
			else 
				for(int i=0; i<4; i++) {
					Category category = new Category();
					category.setName("Q"+ (i+1));
					String quarterFrom = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i*3);
					String quarterTo = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i*3+2);
					category.setQuarterValue(quarterFrom + "||" + quarterTo);
					categoryList.add(category);
				}
			}*/
		}
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		//dataset list and lineset list
		//List<DataSet> dataSetList = new ArrayList<DataSet>();
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();
		
		//dataset:seriesName
		DataSetColumn ltfcDataSetColumn = new DataSetColumn();
		ltfcDataSetColumn.setSeriesName("LTFC");
		ltfcDataSetColumn.setColor("6699ff");
		DataSetColumn mpsDataSetColumn = null;
		DataSetColumn outlookDataSetColumn = null;
		DataSetColumn orderDataSetColumn = null;
		//DataSetColumn toolingWasteDataSetColumn = null;
		
		List<ColumnData> ltfcCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> mpsCloumnDataList = null;
		List<ColumnData> outlookCloumnDataList = null;
		List<ColumnData> orderCloumnDataList = null;
		List<ColumnData> toolingWasteCloumnDataList = null;
		
		//line:  mps;outlook;order
		DataSetLine mpsDataSetline = null;
		DataSetLine outlookDataSetline = null;
		DataSetLine orderDataSetline = null;
		
		List<ColumnData> mpsLineCloumnDataList = null;
		ColumnData mpsLineCloumnData = null;
		
		List<ColumnData> outlookLineCloumnDataList = null;
		ColumnData outlookLineCloumnData = null;
		
		List<ColumnData> orderLineCloumnDataList = null;
		ColumnData orderLineCloumnData = null;
		
		//if(LtfcTypeEnum.Mps.getTypeName().equals(form.getLtfcType())) {
			mpsDataSetline = new DataSetLine();
			mpsDataSetline.setParentYaxis("S");
			mpsDataSetline.setSeriesName("LTFC vs. MPS");
			mpsDataSetline.setRenderas("Line");
			mpsDataSetline.setColor("ffcc33");
			
			mpsDataSetColumn = new DataSetColumn();
			mpsDataSetColumn.setSeriesName("Mps");
			mpsDataSetColumn.setColor("888888");
			mpsCloumnDataList = new ArrayList<ColumnData>();
			
			mpsLineCloumnDataList = new ArrayList<ColumnData>();
		//}
		
		//else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
			orderDataSetline = new DataSetLine();
			orderDataSetline.setParentYaxis("S");
			orderDataSetline.setSeriesName("LTFC vs. Order");
			orderDataSetline.setRenderas("Line");
			orderDataSetline.setColor("ffcc33");
			
			orderDataSetColumn = new DataSetColumn();
			orderDataSetColumn.setSeriesName("Order");
			orderDataSetColumn.setColor("888888");
			orderCloumnDataList = new ArrayList<ColumnData>();
			
			orderLineCloumnDataList = new ArrayList<ColumnData>();
		//}
		
		/*if(form.isShowToolingWaste()) {
			toolingWasteDataSetColumn = new DataSetColumn();
			toolingWasteDataSetColumn.setSeriesName("Tooling Waste");
			toolingWasteDataSetColumn.setColor("ff3300");
			toolingWasteCloumnDataList = new ArrayList<ColumnData>();
		}*/
		
		LinkedHashMap<Object,List<FaOverViewChartData>> ltfcOverviewMap = null;
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())) 
			ltfcOverviewMap = fetchLtfcOverViewChartData(form);
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName()))
			ltfcOverviewMap = fetchLtfcCrossMonthOverviewChartData(form);
		else
			ltfcOverviewMap = fetchLtfcDashboardOverViewChartData(form);
		int i=0;
		for(Map.Entry<Object, List<FaOverViewChartData>> entry : ltfcOverviewMap.entrySet()) {
			String name = ((KeyNameObject)entry.getKey()).getObjName();
			int key = -1;
			if(((KeyNameObject)entry.getKey()).getObjKey() != null)
				key = ((KeyNameObject)entry.getKey()).getObjKey();
			List<FaOverViewChartData> chartDataList = entry.getValue();
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				Category category = new Category();
				category.setName(name);
				categoryList.add(category);
			}

//			else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
//				orderLineCloumnData = new ColumnData();
//				orderLineCloumnData.setValue(40);
//				orderLineCloumnDataList.add(orderLineCloumnData);
//			}
			
			ColumnData ltfc = new ColumnData();
			setLTFCOverviewColumnLink(ltfc,name,key);
			ltfc.setValue(0);
			
			ColumnData mps = new ColumnData();
			setLTFCOverviewColumnLink(mps,name,key);
			mps.setValue(0);
			
			ColumnData outlook = new ColumnData();
			setLTFCOverviewColumnLink(outlook,name,key);
			outlook.setValue(0);
			
			ColumnData order = new ColumnData();
			setLTFCOverviewColumnLink(order,name,key);
			order.setValue(0);
			
			ColumnData toolingWaste = new ColumnData();
			setLTFCOverviewColumnLink(toolingWaste,name,key);
			toolingWaste.setValue(0);
			
			Map<String,Integer> dataMap = new HashMap<String,Integer>();
			StringBuffer valueBuffer = new StringBuffer("[{");
			Category category = (Category)(categoryList.get(i));
			float ltfcValue=0f;
			float mapsValue=0.1f;
			float orderValue=0.1f;
			float minRemarkMPS=0f;
			float maxRemarkMPS=0f;
			float minRemarkOrder=0f;
			float maxRemarkOrder=0f;
			float ltfcVsMpsRate=0f;
			float ltfcVsOrderRate=0f;
			for(FaOverViewChartData ltfcOverViewChartData : chartDataList) {
				if(LtfcTypeEnum.Ltfc.getTypeName().equals(ltfcOverViewChartData.getTypeName())) {
					setLTFCOverviewColumnLink(ltfc,name,key);
					ltfcValue=ltfcOverViewChartData.getTypeValue();
					ltfc.setValue(ltfcValue);
					valueBuffer.append("ltfc:");
//					dataMap.put("LTFC", ltfcOverViewChartData.getTypeValue());
					valueBuffer.append(ltfcOverViewChartData.getTypeValue()).append(",");
					ltfcCloumnDataList.add(ltfc);
				}
				
				if(LtfcTypeEnum.Mps.getTypeName().equals(ltfcOverViewChartData.getTypeName())) {
					setLTFCOverviewColumnLink(mps,name,key);
					mapsValue=ltfcOverViewChartData.getTypeValue();
					mps.setValue(mapsValue);
					valueBuffer.append("mps:");
//					dataMap.put("Mps", ltfcOverViewChartData.getTypeValue());
					valueBuffer.append(ltfcOverViewChartData.getTypeValue()).append(",");
					mpsCloumnDataList.add(mps);
				}
				
				else if(LtfcTypeEnum.Order.getTypeName().equals(ltfcOverViewChartData.getTypeName())) {
					setLTFCOverviewColumnLink(order,name,key);
					orderValue=ltfcOverViewChartData.getTypeValue();
					order.setValue(ltfcOverViewChartData.getTypeValue());
					valueBuffer.append("order:");
//					dataMap.put("Order", ltfcOverViewChartData.getTypeValue());
					valueBuffer.append(ltfcOverViewChartData.getTypeValue()).append(",");
					orderCloumnDataList.add(order);
				}
				else if("minRemarkMPS".equals(ltfcOverViewChartData.getTypeName())) {
//					dataMap.put("ToolingWaste", ltfcOverViewChartData.getTypeValue());
					minRemarkMPS=ltfcOverViewChartData.getTypeValue();
				}
				else if("maxRemarkMPS".equals(ltfcOverViewChartData.getTypeName())) {
//					dataMap.put("ToolingWaste", ltfcOverViewChartData.getTypeValue());
					maxRemarkMPS=ltfcOverViewChartData.getTypeValue();
				}
				else if("minRemarkOrder".equals(ltfcOverViewChartData.getTypeName())) {
//					dataMap.put("ToolingWaste", ltfcOverViewChartData.getTypeValue());
					minRemarkOrder=ltfcOverViewChartData.getTypeValue();
				}
				else if("maxRemarkOrder".equals(ltfcOverViewChartData.getTypeName())) {
//					dataMap.put("ToolingWaste", ltfcOverViewChartData.getTypeValue());
					maxRemarkOrder=ltfcOverViewChartData.getTypeValue();
				}
			}
			//if(LtfcTypeEnum.Mps.getTypeName().equals(form.getLtfcType())) {
				mpsLineCloumnData = new ColumnData();
				ltfcVsMpsRate=calLTFCVSMPS(minRemarkMPS,maxRemarkMPS);
				mpsLineCloumnData.setValue(ltfcVsMpsRate);
				mpsLineCloumnDataList.add(mpsLineCloumnData);
			//}else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
				orderLineCloumnData = new ColumnData();
				//calculate ltfcValue/orderValue
				ltfcVsOrderRate=calLTFCVSMPS(minRemarkOrder,maxRemarkOrder);
				orderLineCloumnData.setValue(ltfcVsOrderRate);
				orderLineCloumnDataList.add(orderLineCloumnData);
			//}
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				valueBuffer.append("subDimensionName:");
				valueBuffer.append("'" + name + "'").append(",");
			}
			
//			float makeRateValue;
//			if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
//					|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
//				makeRateValue = commonService.calculateMakeRate(category.getName(), dataMap);
//			}
//			else
//				makeRateValue = commonService.calculateMakeRate(form.getSelectMonth(), dataMap);
			
			valueBuffer.append("ltfcMpsRate:");
			valueBuffer.append(ltfcVsMpsRate).append(",");
			
			valueBuffer.append("ltfcVsOrderRate:");
			valueBuffer.append(ltfcVsOrderRate).append(",");
			
			if("mps".equalsIgnoreCase(form.getLtfcType())){
				valueBuffer.append("ltfcRate:");
				valueBuffer.append(ltfcVsMpsRate).append(",");
				String lightColor = commonService.getKPILightColor(form.getOrderTypeName(),ltfcVsMpsRate);
				valueBuffer.append("lightColor:");
				valueBuffer.append("'" + lightColor + "'");
			}else if("order".equalsIgnoreCase(form.getLtfcType())){
				valueBuffer.append("ltfcRate:");
				valueBuffer.append(ltfcVsOrderRate).append(",");
				String lightColor = commonService.getKPILightColor(form.getOrderTypeName(),ltfcVsOrderRate);
				valueBuffer.append("lightColor:");
				valueBuffer.append("'" + lightColor + "'");
			}
			
//			valueBuffer.append("ltfcRate:");
//			valueBuffer.append(ltfcRateValue).append(",");
//			
//			String lightColor = commonService.getKPILightColor(form.getOrderTypeName(),ltfcRateValue);
//			valueBuffer.append("lightColor:");
//			valueBuffer.append("'" + lightColor + "'");
			valueBuffer.append("}").append("]");
			//System.out.println("----------KPI:" + valueBuffer.toString());
			
			category.setValues(valueBuffer.toString());
			i++;
		}
		
		ltfcDataSetColumn.setDataList(ltfcCloumnDataList);
		dataSetList.add(ltfcDataSetColumn);
		
		if(LtfcTypeEnum.Mps.getTypeName().equals(form.getLtfcType())) {
			mpsDataSetColumn.setDataList(mpsCloumnDataList);
			dataSetList.add(mpsDataSetColumn);
			
			//line: mps
			mpsDataSetline.setDataList(mpsLineCloumnDataList);
			dataSetList.add(mpsDataSetline);
		}
		else if(LtfcTypeEnum.Order.getTypeName().equals(form.getLtfcType())) {
			orderDataSetColumn.setDataList(orderCloumnDataList);
			dataSetList.add(orderDataSetColumn);
			
			//line: order
			orderDataSetline.setDataList(orderLineCloumnDataList);
			dataSetList.add(orderDataSetline);
		}
		
		/*if(form.isShowToolingWaste()) {
			toolingWasteDataSetColumn.setDataList(toolingWasteCloumnDataList);
			dataSetList.add(toolingWasteDataSetColumn);
		}*/
		
		columnChartView.setDataSetList(dataSetList);
		
		return columnChartView;
	}
	
	public float calLTFCVSMPS(float ltfc,float mps){
		if(mps==0f){
			return ltfc/mps*100;
		}
		BigDecimal ltfcRate = new BigDecimal(0.00);
		MathContext mc = new MathContext(4, RoundingMode.HALF_DOWN);
		ltfcRate = new BigDecimal(ltfc).divide
				   (
						 new BigDecimal(mps)
					,mc
				   )
					.multiply(new BigDecimal(100));
		return ltfcRate.floatValue();
	}
	
	public LinkedHashMap<Object,List<FaOverViewChartData>> fetchLtfcOverViewChartData(SearchFaForm form) throws ParseException {
		LinkedHashMap<Object,List<FaOverViewChartData>> ltfcOverviewMap = new LinkedHashMap<Object,List<FaOverViewChartData>>();
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				ltfcOverviewMap.put(keyNameObject, ltfcDao.fetchLtfcOverViewChartData(form));
			}
		
		
		
		return ltfcOverviewMap;
	}
	
	public LinkedHashMap<Object,List<FaOverViewChartData>> fetchLtfcCrossMonthOverviewChartData(SearchFaForm form) throws ParseException {
		LinkedHashMap<Object,List<FaOverViewChartData>> ltfcOverviewMap = new LinkedHashMap<Object,List<FaOverViewChartData>>();
		String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				ltfcOverviewMap.put(keyNameObject, ltfcDao.fetchLtfcCrossMonthOverviewChartData(form));
			}
		
		return ltfcOverviewMap;
	}
	
	public LinkedHashMap<Object,List<FaOverViewChartData>> fetchLtfcDashboardOverViewChartData(SearchFaForm form) throws ParseException {
		LinkedHashMap<Object,List<FaOverViewChartData>> ltfcDashboardOverviewMap = new LinkedHashMap<Object,List<FaOverViewChartData>>();
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		List<KeyNameObject> dimensionList = ltfcDao.fetchDimensions(form);
		for(KeyNameObject keyNameObject : dimensionList) {
			form.setSubDimensionKey(keyNameObject.getObjKey());
			ltfcDashboardOverviewMap.put(keyNameObject, ltfcDao.fetchLtfcDashboardOverViewChartData(form));
		}
		
		return ltfcDashboardOverviewMap;
	}
	
	public void setLTFCOverviewColumnLink(ColumnData cloumnData,String name, int key) {
		/*cloumnData.setLink("j-showDetractorMainPieAndData-"
				+ weekNo + "," 
				+ trackingCausesMonday + "|" 
				+trackingCausesSunday);*/
		cloumnData.setLink("j-refreshRemark-" + name + "," + key);
	}
	
	@Override
	public ColumnChartView getRemarkChart(SearchFaForm form) throws ParseException {
		ColumnChartView columnChartView = setRemarkChartInfomation();
		
		//dataset:seriesName
		List<DataSetParent> ltfcDimensionDataSetList = new ArrayList<DataSetParent>();
		
		DataSetColumn ltfcDataSetColumn = new DataSetColumn();
		if("Odm".equals(form.getDimension()))
			ltfcDataSetColumn.setSeriesName("FA by ODM");
		else if("Family".equals(form.getDimension()))
			ltfcDataSetColumn.setSeriesName("FA by Family");
		else if("Product".equals(form.getDimension()))
			ltfcDataSetColumn.setSeriesName("FA by Product");
		ltfcDataSetColumn.setColor("ff3300");
		List<ColumnData> ltfcCloumnDataList = new ArrayList<ColumnData>();
		
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		List<LTFCRemarkChartData> ltfcRemarkList = fetchLtfcRemarkChartData(form);
		
		
		/*for(LTFCRemarkChartData LTFCRemarkChartData : ltfcRemarkList) {
			Category category = new Category();
			category.setName(LTFCRemarkChartData.getSubDimensionName());
			//category.setValue(LTFCRemarkChartData.getSubDimensionValue());
			category.setValue(LTFCRemarkChartData.getSubDimensionKey());
			categoryList.add(category);
			
			ColumnData ltfc = new ColumnData();
			setRemarkColumnLink(1,ltfc);
			ltfc.setValue(LTFCRemarkChartData.getRate());
			
			ltfcCloumnDataList.add(ltfc);
		}*/
		
		for(int i=0; i<ltfcRemarkList.size(); i++) {
			if(i == 15) break;
			LTFCRemarkChartData LTFCRemarkChartData = ltfcRemarkList.get(i);
			String name = LTFCRemarkChartData.getSubDimensionName();
			int value = LTFCRemarkChartData.getSubDimensionKey();
			
			Category category = new Category();
			category.setName(name);
			category.setValue(value);
			categoryList.add(category);
			
			String dimensionInfo = "";
			if(ChartTypeEnum.OverView.getTypeName().equals(form.getChartType()))
				dimensionInfo = form.getDimension()+ "," + name;
			else
				dimensionInfo = form.getDimension()+ "," + name + "~" + value;
			ColumnData ltfc = new ColumnData();
			setRemarkColumnLink(dimensionInfo,ltfc,form);
			ltfc.setValue(LTFCRemarkChartData.getRate());
			ltfc.setTooltext(ltfcDataSetColumn.getSeriesName()+", "+name+ ", "+LTFCRemarkChartData.getRate()+"%");
			setRemarkColumnLink(dimensionInfo+","+ OTSStatusEnum.FAIL.getTypeName(),ltfc,form);
			
			ltfcCloumnDataList.add(ltfc);
		}
		Categories categories = new Categories();
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		ltfcDataSetColumn.setDataList(ltfcCloumnDataList);
		ltfcDimensionDataSetList.add(ltfcDataSetColumn);
		
		columnChartView.setDataSetList(ltfcDimensionDataSetList);
		
		return columnChartView;
	}

	
	public List<LTFCRemarkChartData> fetchLtfcRemarkChartData(SearchFaForm form) throws ParseException {
		if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
				int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
				int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
				form.setYear(year);
				form.setMonth(month);
		}
		/*if(!StringUtil.isEmpty(form.getOdmIds()) && "Odm".equals(form.getDimension())
				|| !StringUtil.isEmpty(form.getProductIds()) && "Product".equals(form.getDimension())
				|| !StringUtil.isEmpty(form.getGeoIds()) && "Region".equals(form.getDimension()))*/
		List<LTFCRemarkChartData> remarkChartDataList = ltfcDao.fetchLtfcRemarkChartData(form);
		for(LTFCRemarkChartData LTFCRemarkChartData : remarkChartDataList) {
			float rate = calAccuracy(LTFCRemarkChartData.getMaxQTY(),LTFCRemarkChartData.getMinQTY());
			LTFCRemarkChartData.setRate(rate);
		}
		return remarkChartDataList;
	}
	
	public float calFaRate(int totalFa, int subFa) {
		BigDecimal faRate = new BigDecimal(0);
		MathContext mc = new MathContext(1, RoundingMode.HALF_DOWN);
		
		try{
			faRate = new BigDecimal(subFa).divide(new BigDecimal(totalFa),mc).multiply(new BigDecimal(100));
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return faRate.floatValue();
	}
	
	public float calAccuracy(int max, int min){
		BigDecimal minDec=new BigDecimal(min);
		BigDecimal maxDec=new BigDecimal(max);
		MathContext three= new MathContext(3, RoundingMode.HALF_DOWN);
		BigDecimal faRate = new BigDecimal(0);
		try{
			faRate = minDec.divide(maxDec,three).multiply(new BigDecimal("100"));
		}
		catch(ArithmeticException e) {
			return 0;
		}
		return faRate.floatValue();
	}
	
	@Override
	public List<KeyNameObject> fetchTop15SubDimensions(SearchOtsForm form) {
		return ltfcDao.fetchTop15SubDimensions(form);
	}
	
	public void setColumnLink(int weekNo,ColumnData cloumnData) {
		
		cloumnData.setLink("j-refreshRemark-");
	
	}
	
	public void setRemarkColumnLink(int regionId,ColumnData cloumnData) {
		
		cloumnData.setLink( "j-showOrderDetail-"+regionId );
	
	}
	
	public void setRemarkColumnLink(String dimensionInfo,ColumnData cloumnData,SearchFaForm form) {
		
		if(ChartTypeEnum.CrossMonth.getTypeName().equals(form.getChartType()))
			cloumnData.setLink( "j-ltfcCrossMonthOrderDetailShow-"+dimensionInfo );
		else if(ChartTypeEnum.Dashboard.getTypeName().equals(form.getChartType()))
			cloumnData.setLink( "j-ltfcDashboardOrderDetailShow-"+dimensionInfo );
		else
			cloumnData.setLink( "j-showLTFCOrderDetail-"+dimensionInfo );
		
	}
	
	private ColumnChartView setRemarkChartInfomation() {
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		columnChartView.getChartInfo().setFormatNumber("%");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setShowBorder("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setShowValues("0");
//		columnChartView.getChartInfo().setSnumberSuffix("%");
		columnChartView.getChartInfo().setNumbersuffix("%");
//		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");
		columnChartView.getChartInfo().setChartRightMargin("50");
		
		return columnChartView;
	}
	
	private void setOverviewChartInfomation(ColumnChartView mSColumnChartView) {
		mSColumnChartView.getChartInfo().setCaption("");
		mSColumnChartView.getChartInfo().setNumdivlines("8");
		mSColumnChartView.getChartInfo().setyAxisMinValue("0");
		mSColumnChartView.getChartInfo().setyAxisMaxValue("160");
		mSColumnChartView.getChartInfo().setsYAxisMinValue("0");
		mSColumnChartView.getChartInfo().setsYAxisMaxValue("100");
		mSColumnChartView.getChartInfo().setFormatNumberScale("0");
		mSColumnChartView.getChartInfo().setLegendIconScale("1");
		mSColumnChartView.getChartInfo().setShowBorder("1");
		mSColumnChartView.getChartInfo().setCanvasBorderThickness("1");
		mSColumnChartView.getChartInfo().setShowZeroPlaneValue("1");
		mSColumnChartView.getChartInfo().setCanvasBorderAlpha("60");
		mSColumnChartView.getChartInfo().setPlotSpacePercent("70");
		mSColumnChartView.getChartInfo().setBgalpha("0,0");
		mSColumnChartView.getChartInfo().setLegendPosition("");
		mSColumnChartView.getChartInfo().setShowBorder("0");
		mSColumnChartView.getChartInfo().setShowPlotBorder("0");
		mSColumnChartView.getChartInfo().setShowValues("0");
	}

	@Override
	public List<FaOverViewChartData> getOverviewOverall(SearchOtsForm form) {
		
		return ltfcDao.getOverviewOverall(form);
	}
	
	@Override
	public PieChartView getOverviewPieChart(SearchFaForm form) throws ParseException{
			PieChartView pView = new PieChartView();
			pView.getChartInfo().setLegendPosition("bottom");
			pView.getChartInfo().setPieRadius("90");
			pView.getChartInfo().setManageLabelOverflow("1");
			//pView.getChartInfo().setEnableSmartLabels("0");
            pView.getChartInfo().setUseEllipsesWhenOverflow("0");
            pView.getChartInfo().setSkipOverlapLabels("0");
			
			if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
				int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
				int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
				form.setYear(year);
				form.setMonth(month);
			}
			List<FaOverViewChartData> faList = ltfcDao.getFaPieChart(form);
			List<PieSlice> pieList = new ArrayList<PieSlice>();
			PieSlice p = null;
			for(FaOverViewChartData fa : faList){
				p = new PieSlice();
				p.setLabel(fa.getRowName());
				p.setValue(String.valueOf(fa.getValue()));
				
				String functionName = null;
				String params = null;
				/*
				 * function showLTFCOrderDetail(any),overview
				   ltfcDashboardOrderDetailShow(any),dashboard
				  
				 * */
				functionName = "showLTFCOrderDetail";
				/*if(fa.getRowName().indexOf("under")!=-1){
					
				}*/
				if(fa.getRowName().equalsIgnoreCase("under plan")){
					params="under plan";
				}else if(fa.getRowName().equalsIgnoreCase("equal plan")){
					params="equal plan";
				}else{
					params="over plan";
				}
				p.setLink("j-"+functionName+"-" + params);
				pieList.add(p);
			}
			pView.setElements(pieList);
			return pView;
		}
	
	@Override
	public PieChartView getCrossMonthPieChart(SearchFaForm form) throws ParseException{
		PieChartView pView = new PieChartView();
		pView.getChartInfo().setLegendPosition("bottom");
		pView.getChartInfo().setPieRadius("90");
		pView.getChartInfo().setManageLabelOverflow("1");
		//pView.getChartInfo().setEnableSmartLabels("0");
        pView.getChartInfo().setUseEllipsesWhenOverflow("0");
        pView.getChartInfo().setSkipOverlapLabels("0");
			if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
				int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
				int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
				form.setYear(year);
				form.setMonth(month);
			}
			List<FaOverViewChartData> faList = ltfcDao.getFaCrossMonthPieChart(form);
			List<PieSlice> pieList = new ArrayList<PieSlice>();
			PieSlice p = null;
			for(FaOverViewChartData fa : faList){
				p = new PieSlice();
				p.setLabel(fa.getRowName());
				p.setValue(String.valueOf(fa.getValue()));
				
				String functionName = "ltfcCrossMonthOrderDetailShow";
				
				String params = null;
				
				if(fa.getRowName().equalsIgnoreCase("under plan")){
					params="under plan";
				}else if(fa.getRowName().equalsIgnoreCase("equal plan")){
					params="equal plan";
				}else{
					params="over plan";
				}
				p.setLink("j-"+functionName+"-" + params);
				
				pieList.add(p);
			}
			pView.setElements(pieList);
			return pView;
		}
		
	@Override
	public PieChartView getDashboardPieChart(SearchFaForm form) throws ParseException{
			PieChartView pView = new PieChartView();
			pView.getChartInfo().setLegendPosition("bottom");
			pView.getChartInfo().setPieRadius("90");
			pView.getChartInfo().setManageLabelOverflow("1");
			//pView.getChartInfo().setEnableSmartLabels("0");
            pView.getChartInfo().setUseEllipsesWhenOverflow("0");
            pView.getChartInfo().setSkipOverlapLabels("0");
			if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
				int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
				int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
				form.setYear(year);
				form.setMonth(month);
			}
			List<FaOverViewChartData> faList = ltfcDao.getFaDashboardPieChart(form);
			List<PieSlice> pieList = new ArrayList<PieSlice>();
			PieSlice p = null;
			for(FaOverViewChartData fa : faList){
				p = new PieSlice();
				p.setLabel(fa.getRowName());
				p.setValue(String.valueOf(fa.getValue()));
				
				String functionName = "ltfcDashboardOrderDetailShow";
				
				String params = null;
				
				if(fa.getRowName().equalsIgnoreCase("under plan")){
					params="under plan";
				}else if(fa.getRowName().equalsIgnoreCase("equal plan")){
					params="equal plan";
				}else{
					params="over plan";
				}
				p.setLink("j-"+functionName+"-" + params);
				
				pieList.add(p);
			}
			pView.setElements(pieList);
			return pView;
		}
		
	@Override
	public Map<String,Object> getOverviewOrderDetail(SearchFaForm form) throws ParseException {
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
		}
		List<LTFCDetailView> grid = null;
		int totalCount = 0;
		
		totalCount = ltfcDao.getDashboardOrderDetailCount(form);
		
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			grid = ltfcDao.getDashboardOrderDetail(form);
			transfer(grid,form);
		}
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	
	}
	
	@Override
	public List<LTFCDetailView> getFADetailView(SearchFaForm form) {
		
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
		}
		
		List<LTFCDetailView> grid=ltfcDao.getAllOrderDetail(form);
		transfer(grid,form);
		return grid;
	}

	@Override
	public Map<String, Object> getLTFCRemarkOrderDetail(SearchFaForm form)
			throws ParseException {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		List<LTFCDetailView> grid = null;
		int totalCount = 0;
		int unkownTotalCount = 0;
		
		
			totalCount = ltfcDao.getRemarkOrderDetailCount(form);
		
		
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			grid = ltfcDao.getRemarkOrderDetail(form);
			transfer(grid,form);
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		map.put("unkownTotalCount", unkownTotalCount);
		return map;
	}

	@Override
	public String getPoorProduct(SearchFaForm form) throws ParseException {
		//TODO
		int target=70;
		Object products=ltfcDao.getPoorProducts(form,target);
		if(products!=null){
			return ((List<String>)products).toString();
		}else{
			return "";
		}
		
	}
	
	private void transfer(List<LTFCDetailView> grid,SearchFaForm form){
		for(LTFCDetailView view:grid){
			if(view.getLtfcQty()==null){
				view.setLtfcQty("0");
			}
			if(view.getMpsQty()==null){
				view.setMpsQty("0");
			}
			if(view.getOrderQty()==null){
				view.setOrderQty("0");
			}
			if("Mps".equals(form.getLtfcType())){
				if(Integer.parseInt(view.getLtfcQty())>Integer.parseInt(view.getMpsQty())){
					view.setRootCause("over plan");
				}else if(Integer.parseInt(view.getLtfcQty())==Integer.parseInt(view.getMpsQty())){
					view.setRootCause("equal plan");
				}else{
					view.setRootCause("under plan");
				}
			}else{
				if(Integer.parseInt(view.getLtfcQty())>Integer.parseInt(view.getOrderQty())){
					view.setRootCause("over plan");
				}else if(Integer.parseInt(view.getLtfcQty())==Integer.parseInt(view.getOrderQty())){
					view.setRootCause("equal plan");
				}else{
					view.setRootCause("under plan");
				}
			}
			BigDecimal ltfc=new BigDecimal(view.getLtfcQty());
			BigDecimal mps=new BigDecimal(view.getMpsQty());
			BigDecimal order=new BigDecimal(view.getOrderQty());
			if(view.getLtfcVsMps()==null){//还没算过
				if(ltfc.compareTo(mps)<0){
					if(view.getMpsQty().equals("0")){
						view.setLtfcVsMps("0.00");
					}else{
						view.setLtfcVsMps(ltfc.divide(mps, 2,BigDecimal.ROUND_HALF_UP)+"");
					}
				}else{
					if(view.getLtfcQty().equals("0")){
						view.setLtfcVsMps("0.00");
					}else{
						view.setLtfcVsMps(mps.divide(ltfc, 2,BigDecimal.ROUND_HALF_UP)+"");
					}
				}
			}
			if(view.getLtfcVsOrder()==null){
				if(ltfc.compareTo(order)<0){
					if(view.getOrderQty().equals("0")){
						view.setLtfcVsOrder("0.00");
					}else{
						view.setLtfcVsOrder(ltfc.divide(order, 2,BigDecimal.ROUND_HALF_UP)+"");
					}
				}else{
					if(view.getLtfcQty().equals("0")){
						view.setLtfcVsMps("0.00");
					}else{
						view.setLtfcVsOrder(order.divide(ltfc, 2,BigDecimal.ROUND_HALF_UP)+"");
					}
				}
			}
		}
	}
	
	
}
