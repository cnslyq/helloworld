package com.lenovo.bi.service.sc.impl;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.npi.NpiOrderDaoDw;
import com.lenovo.bi.dao.sc.CADao;
import com.lenovo.bi.dto.CaKeyNameObject;
import com.lenovo.bi.dto.sc.CARemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.enumobj.CAStatusEnum;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.OrderTypeEnum;
import com.lenovo.bi.form.sc.ca.SearchCaForm;
import com.lenovo.bi.service.common.CommonService;
import com.lenovo.bi.service.sc.CAService;
import com.lenovo.bi.util.CARemarkChartDataComparator;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.DataSetLine;
import com.lenovo.bi.view.npi.chart.common.CaCategory;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;
import com.lenovo.bi.view.sc.ca.CaDetailGridView;

@Service
public class CAServiceImpl implements CAService {

	@Inject
	CADao caDao;
	
	@Inject
	CommonService commonService;
	
	@Inject
	NpiOrderDaoDw npiOrderDaoDw;
	
	@Override
	public ColumnChartView getOverviewChart(SearchCaForm form) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();
		setOverviewChartInfomation(columnChartView,form);
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
				|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
			String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
			
			if(!form.isShowQuarterOverview()) {
				for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
					String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
					if (form.getEndDate()!=null && yearMonth.compareTo(form.getEndDate()) > 0) 
						break;
					Category category = new Category();
					category.setName(yearMonth);
					categoryList.add(category);
				}
			}
			else {
				String date = "";
				if(form.getStartDate().substring(5).compareTo("04") < 0)
					date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
				else
					date = form.getStartDate().substring(0, 5) + "04";
				for(int i=0; i<4; i++) {
					Category category = new Category();
					category.setName("Q"+ (i+1));
					String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
					String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
					category.setQuarterValue(quarterFrom + "||" + quarterTo);
					categoryList.add(category);
				}
			}
			
		}
		
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();
		
		//if MFG CA: Commitment,Risk order,Commited order,Shipment
		DataSetColumn shipmentDataSetColumn = new DataSetColumn();
		if(form.isShowSalesOverview())
			shipmentDataSetColumn.setSeriesName("Sales Shipment");
		else
			shipmentDataSetColumn.setSeriesName("Actual Shipment");
		shipmentDataSetColumn.setColor("6699FF");
		List<ColumnData> shipmentCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn totalDataSetColumn = new DataSetColumn();
		totalDataSetColumn.setSeriesName("Total");
		totalDataSetColumn.setColor("6633FF");
		List<ColumnData> totalCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn commitmentDataSetColumn = new DataSetColumn();
		commitmentDataSetColumn.setSeriesName("Commitment");
		commitmentDataSetColumn.setColor("CCCCCC");
		List<ColumnData> commitmentCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn riskDataSetColumn = new DataSetColumn();
		riskDataSetColumn.setSeriesName("Risk Order");
		riskDataSetColumn.setColor("FF3366");
		List<ColumnData> riskCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetLine caTargetLineDataSetColumn = new DataSetLine();
		caTargetLineDataSetColumn.setSeriesName("CA Target");
		caTargetLineDataSetColumn.setParentYaxis("P");
		caTargetLineDataSetColumn.setRenderas("Line");
		caTargetLineDataSetColumn.setColor("FF0099");
		List<ColumnData> caTargetLineCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetLine ctpLineDataSetColumn = new DataSetLine();
		ctpLineDataSetColumn.setSeriesName("CTP");
		ctpLineDataSetColumn.setParentYaxis("P");
		ctpLineDataSetColumn.setRenderas("Line");
		ctpLineDataSetColumn.setColor("9932CC");
		List<ColumnData> ctpLineCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetLine caLineDataSetColumn = new DataSetLine();
		caLineDataSetColumn.setSeriesName("CA Achievement");
		caLineDataSetColumn.setParentYaxis("S");
		caLineDataSetColumn.setRenderas("Line");
		caLineDataSetColumn.setColor("009966");
		List<ColumnData> caLineCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetLine ctpAchievementLineDataSetColumn = new DataSetLine();
		ctpAchievementLineDataSetColumn.setSeriesName("CTP Achievement");
		ctpAchievementLineDataSetColumn.setParentYaxis("S");
		ctpAchievementLineDataSetColumn.setRenderas("Line");
		ctpAchievementLineDataSetColumn.setColor("800000");
		List<ColumnData> ctpAchievementLineCloumnDataList = new ArrayList<ColumnData>();
		
		LinkedHashMap<Object,List<ScOverViewChartData>> caOverviewMap = null;
		//fetchData
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())) 
			caOverviewMap = fetchCaOverViewChartData(form);
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName()))
			caOverviewMap = fetchCaCrossMonthOverviewChartData(form);
		else
			caOverviewMap = fetchCaDashboardOverViewChartData(form);
		int i=0;
		for(Map.Entry<Object, List<ScOverViewChartData>> entry : caOverviewMap.entrySet()) {
			String name = ((CaKeyNameObject)entry.getKey()).getObjName();
			String key = "-1";
			if(((CaKeyNameObject)entry.getKey()).getObjKey() != null)
				key = ((CaKeyNameObject)entry.getKey()).getObjKey();
			List<ScOverViewChartData> chartDataList = entry.getValue();
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				Category category = new Category();
				category.setName(name);
				categoryList.add(category);
			}
			
			ColumnData shipment = new ColumnData();
			setCAOverviewColumnLink(shipment,name,key);
			shipment.setValue(0);
			ColumnData total = new ColumnData();
			setCAOverviewColumnLink(total,name,key);
			total.setValue(0);
			
			ColumnData commitment = new ColumnData();
			setCAOverviewColumnLink(commitment,name,key);
			commitment.setValue(0);
			
			ColumnData risk = new ColumnData();
			setCAOverviewColumnLink(risk,name,key);
			risk.setValue(0);
			
			ColumnData caTarget = new ColumnData();
			caTarget.setValue(0);
			
			ColumnData ctp = new ColumnData();
			ctp.setValue(0);
			
			ColumnData ca = new ColumnData();
			ca.setValue(92);
			
			ColumnData ctpAchievement = new ColumnData();
			ctpAchievement.setValue(92);
			
			Map<String,Integer> dataMap = new HashMap<String,Integer>();
			StringBuffer valueBuffer = new StringBuffer("[{");
			
			Integer odmCommitment = ((CaKeyNameObject)entry.getKey()).getOdmCommitment();
			if(odmCommitment != null)
				commitment.setValue(odmCommitment);
			else 
				odmCommitment = 0;
			valueBuffer.append("commitment:" + odmCommitment + ",");
			dataMap.put(CAStatusEnum.Commitment.getTypeName(), odmCommitment);
			
			Category category = (Category)(categoryList.get(i));
			Integer commitedValue = 0; Integer unknownValue = 0; Integer future = 0;
			for(ScOverViewChartData overViewChartData : chartDataList) {
				if(overViewChartData.getScStatusName().equals(CAStatusEnum.RiskOrder.getTypeName())) {
					setCAOverviewColumnLink(risk,name,key);
					risk.setValue(-overViewChartData.getOrderNum());
					valueBuffer.append("risk:");
					valueBuffer.append(-overViewChartData.getOrderNum()).append(",");
					dataMap.put(CAStatusEnum.RiskOrder.getTypeName(), -overViewChartData.getOrderNum());
				}
				else if(overViewChartData.getScStatusName().equals(CAStatusEnum.Shipment.getTypeName())) {
					setCAOverviewColumnLink(shipment,name,key);
					
					Integer boh = ((CaKeyNameObject)entry.getKey()).getBoh() == null ? 0 : ((CaKeyNameObject)entry.getKey()).getBoh();
					if(!form.isShowSalesOverview())
						shipment.setValue(overViewChartData.getOrderNum() + boh);
					else
						shipment.setValue(overViewChartData.getOrderNum());
					valueBuffer.append("shipment:");
					valueBuffer.append(shipment.getValue().intValue()).append(",");
					dataMap.put(CAStatusEnum.Shipment.getTypeName(), shipment.getValue().intValue());//boh need be added for calculation
				}
				else if(overViewChartData.getScStatusName().equals(CAStatusEnum.CommitedOrder.getTypeName())) {
					commitedValue = overViewChartData.getOrderNum();
				}
				else if(overViewChartData.getScStatusName().equals(CAStatusEnum.FUTURE.getTypeName())) {
					future = overViewChartData.getOrderNum();
				}
				else if(overViewChartData.getScStatusName().equals(CAStatusEnum.UNKNOWN.getTypeName())) {
					unknownValue = overViewChartData.getOrderNum();
				}
			}
			
			Integer caTargetVolume = ((CaKeyNameObject)entry.getKey()).getCaTarget();
			caTarget.setValue(caTargetVolume == null ? 0 : caTargetVolume);
			dataMap.put(CAStatusEnum.CATarget.getTypeName(), caTargetVolume == null ? 0 : caTargetVolume);
			valueBuffer.append("CATarget:");
			valueBuffer.append(caTargetVolume == null ? 0 : caTargetVolume).append(",");
			
			setCAOverviewColumnLink(total,name,key);
			
			int riskValue = risk.getValue().intValue();
			if(riskValue < 0)
				riskValue = -riskValue;
			Integer totalValue= commitedValue + shipment.getValue().intValue() + riskValue + unknownValue + future;
			total.setValue(totalValue);
			valueBuffer.append("total:");
			valueBuffer.append(totalValue == null ? 0 : totalValue).append(",");
			
			Integer ctpTarget = ((CaKeyNameObject)entry.getKey()).getCtp();
			ctp.setValue(ctpTarget == null ? 0 : ctpTarget);
			dataMap.put(CAStatusEnum.CTP.getTypeName(), ctpTarget == null ? 0 : ctpTarget);
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				valueBuffer.append("subDimensionName:");
				valueBuffer.append("'" + name + "'").append(",");
			}
			
			float caValue;float ctpAchievementValue;String categoryDate;
			if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
					|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
				if(!form.isShowQuarterOverview()){
					categoryDate = category.getName();
				}
				else{
					categoryDate = category.getQuarterValue();
				}
			}
			else{
				categoryDate = form.getSelectMonth();
			}
			
			if(!form.isShowSalesOverview()){
				caValue = commonService.calculateMFGCaMakeRate(categoryDate, form.getCurrentRolMonth(), dataMap, true);
				ctpAchievementValue = commonService.calculateMFGCaMakeRate(categoryDate, form.getCurrentRolMonth(), dataMap, false);
			}
			else{
				caValue = commonService.calculateSalesCaMakeRate(categoryDate, form.getCurrentRolMonth(), dataMap, true);
				ctpAchievementValue = commonService.calculateSalesCaMakeRate(categoryDate, form.getCurrentRolMonth(), dataMap, false);
			}
			
			ca.setValue(caValue);
			ctpAchievement.setValue(ctpAchievementValue);
			
			valueBuffer.append("ca:");
			valueBuffer.append(caValue).append(",");
			valueBuffer.append("ctpAchievement:");
			valueBuffer.append(ctpAchievementValue).append(",");
			
			String lightColor = commonService.getKPILightColor(OrderTypeEnum.CA.getType(),caValue);
			valueBuffer.append("lightColor:");
			valueBuffer.append("'" + lightColor + "'");
			valueBuffer.append("}").append("]");
			//System.out.println("----------KPI:" + valueBuffer.toString());
			
			category.setValues(valueBuffer.toString());
			
			if(commitment.getValue().intValue() != 0) 
				commitmentCloumnDataList.add(commitment);
			else
				commitmentCloumnDataList.add(null);
			
			if(risk.getValue().intValue() != 0) 
				riskCloumnDataList.add(risk);
			else
				riskCloumnDataList.add(null);
			
			if(shipment.getValue().intValue() != 0) 
				shipmentCloumnDataList.add(shipment);
			else
				shipmentCloumnDataList.add(null);
			
			if(total.getValue().intValue() != 0) 
				totalCloumnDataList.add(total);
			else
				totalCloumnDataList.add(null);
			
			caTargetLineCloumnDataList.add(caTarget);
			ctpLineCloumnDataList.add(ctp);
			caLineCloumnDataList.add(ca);
			ctpAchievementLineCloumnDataList.add(ctpAchievement);
			
			i++;
		}
		
		shipmentDataSetColumn.setDataList(shipmentCloumnDataList);
		totalDataSetColumn.setDataList(totalCloumnDataList);
		commitmentDataSetColumn.setDataList(commitmentCloumnDataList);
		riskDataSetColumn.setDataList(riskCloumnDataList);
		caTargetLineDataSetColumn.setDataList(caTargetLineCloumnDataList);
		ctpLineDataSetColumn.setDataList(ctpLineCloumnDataList);
		caLineDataSetColumn.setDataList(caLineCloumnDataList);
		ctpAchievementLineDataSetColumn.setDataList(ctpAchievementLineCloumnDataList);
		
		dataSetList.add(shipmentDataSetColumn);
		if(!form.isShowSalesOverview())
			dataSetList.add(totalDataSetColumn);
		if(!form.isShowSalesOverview() && form.isShowCommitment())
			dataSetList.add(commitmentDataSetColumn);
		dataSetList.add(riskDataSetColumn);
		
		if(form.isShowCaTarget())
			dataSetList.add(caTargetLineDataSetColumn);
		if(form.isShowCtp())
			dataSetList.add(ctpLineDataSetColumn);
		if(form.isShowCaAchievement())
			dataSetList.add(caLineDataSetColumn);
		if(form.isShowCtpAchievement())
			dataSetList.add(ctpAchievementLineDataSetColumn);
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		columnChartView.setDataSetList(dataSetList);
		
		//set sYMax ans sYMin
		List<Float>list=new ArrayList<Float>();
		for(DataSetParent dataSet:columnChartView.getDataSetList()){
			//parentYaxis
			if(dataSet instanceof DataSetLine){
				DataSetLine dataSetLine=(DataSetLine)dataSet;
				if("S".equalsIgnoreCase(dataSetLine.getParentYaxis())){
					List<ColumnData>dataList=dataSetLine.getDataList();
					for(ColumnData data:dataList){
						if(data.getValue()!=null){
							list.add((Float) data.getValue());
						}
					}
				}
			}
		}
		Collections.sort(list, new Comparator<Float>(){
			@Override
			public int compare(Float o1, Float o2) {
				return (int) (o1-o2);
			}
		});
		if(list!=null&&list.size()>0){
			float min=list.get(0);
			float max=list.get(list.size()-1);
			float sYMax=getMax(max);
			float sYMin=getMin(max,min);
			columnChartView.getChartInfo().setsYAxisMaxValue(String.valueOf(sYMax));
			columnChartView.getChartInfo().setsYAxisMinValue(String.valueOf(sYMin));
		}
		
		return columnChartView;
	}

	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchCaOverViewChartData(SearchCaForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> caOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		if(!form.isShowQuarterOverview()) {
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				CaKeyNameObject keyNameObject = new CaKeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				keyNameObject.setOdmCommitment(caDao.fetchOverviewOdmCommitment(form));
				
				CaKeyNameObject keyName = new CaKeyNameObject();
				keyName = caDao.fetchOverviewCaTargetAndCtp(form);
				keyNameObject.setCaTarget(keyName.getCaTarget());
				keyNameObject.setCtp(keyName.getCtp());
				
				Integer boh = caDao.fetchBoh(form);
				if(boh != null)
					keyNameObject.setBoh(boh);
				
				caOverviewMap.put(keyNameObject, caDao.fetchCaOverViewChartData(form));
			}
		}
		else {
			String date = "";
			if(form.getStartDate().substring(5).compareTo("04") < 0)
				date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
			else
				date = form.getStartDate().substring(0, 5) + "04";
			for(int i=0; i<4; i++) {
				CaKeyNameObject keyNameObject = new CaKeyNameObject();
				String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
				String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
				form.setQuarterFrom(quarterFrom);
				form.setQuarterTo(quarterTo);
				keyNameObject.setObjName(quarterFrom + "||" + quarterTo);
				keyNameObject.setOdmCommitment(caDao.fetchOverviewOdmCommitment(form));
				
				CaKeyNameObject keyName = new CaKeyNameObject();
				keyName = caDao.fetchOverviewCaTargetAndCtp(form);
				keyNameObject.setCaTarget(keyName.getCaTarget());
				keyNameObject.setCtp(keyName.getCtp());
				
				Integer boh = caDao.fetchBoh(form);
				if(boh != null)
					keyNameObject.setBoh(boh);
				
				caOverviewMap.put(keyNameObject, caDao.fetchCaOverViewChartData(form));
			}
		}
		
		return caOverviewMap;
	}
	
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchCaCrossMonthOverviewChartData(SearchCaForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> fpsdOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
		
		if(!form.isShowQuarterOverview()) {
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(startDate, i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				CaKeyNameObject keyNameObject = new CaKeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				form.setStartDate(date);
				keyNameObject.setOdmCommitment(caDao.fetchCrossMonthOdmCommitment(form));
				
				CaKeyNameObject keyName = new CaKeyNameObject();
				keyName = caDao.fetchCrossMonthCaTargetAndCtp(form);
				keyNameObject.setCaTarget(keyName.getCaTarget());
				keyNameObject.setCtp(keyName.getCtp());
				
				Integer boh = caDao.fetchBoh(form);
				if(boh != null)
					keyNameObject.setBoh(boh);
				
				fpsdOverviewMap.put(keyNameObject, caDao.fetchCaCrossMonthOverviewChartData(form));
			}
		}
		else {
			String date = "";
			if(form.getStartDate().substring(5).compareTo("04") < 0)
				date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
			else
				date = form.getStartDate().substring(0, 5) + "04";
			for(int i=0; i<4; i++) {
				CaKeyNameObject keyNameObject = new CaKeyNameObject();
				String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
				String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
				form.setStartDate(quarterFrom);
				form.setEndDate(quarterTo);
				keyNameObject.setObjName(quarterFrom + "||" + quarterTo);
				keyNameObject.setOdmCommitment(caDao.fetchCrossMonthOdmCommitment(form));
				
				CaKeyNameObject keyName = new CaKeyNameObject();
				keyName = caDao.fetchCrossMonthCaTargetAndCtp(form);
				keyNameObject.setCaTarget(keyName.getCaTarget());
				keyNameObject.setCtp(keyName.getCtp());
				
				Integer boh = caDao.fetchBoh(form);
				if(boh != null)
					keyNameObject.setBoh(boh);
				
				fpsdOverviewMap.put(keyNameObject, caDao.fetchCaDataByDimKeys(form));
			}
		}
		
		return fpsdOverviewMap;
	}
	
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchCaDashboardOverViewChartData(SearchCaForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> fpsdDashboardOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		List<CaKeyNameObject> dimensionList = caDao.fetchDimensions(form);
		for(CaKeyNameObject keyNameObject : dimensionList) {
			form.setSubDimensionKey(keyNameObject.getObjKey());
			keyNameObject.setOdmCommitment(caDao.fetchDashboardOdmCommitment(form));
			
			CaKeyNameObject keyName = new CaKeyNameObject();
			keyName = caDao.fetchDashboardCaTargetAndCtp(form);
			keyNameObject.setCaTarget(keyName.getCaTarget());
			keyNameObject.setCtp(keyName.getCtp());
			
			Integer boh = caDao.fetchBoh(form);
			if(boh != null)
				keyNameObject.setBoh(boh);
			
			fpsdDashboardOverviewMap.put(keyNameObject, caDao.fetchCaDashboardOverViewChartData(form));
		}
		
		return fpsdDashboardOverviewMap;
	}
	
	public void setCAOverviewColumnLink(ColumnData cloumnData,String name, String key) {
		/*cloumnData.setLink("j-showDetractorMainPieAndData-"
				+ weekNo + "," 
				+ trackingCausesMonday + "|" 
				+trackingCausesSunday);*/
		cloumnData.setLink("j-refreshRemark-" + name + "," + key);
	}
	
	@Override
	public ColumnChartView getRemarkChart(SearchCaForm form) throws ParseException {
		ColumnChartView columnChartView = setRemarkChartInfomation();
		
		//dataset:seriesName
		List<DataSetParent> caDimensionDataSetList = new ArrayList<DataSetParent>();
		
		DataSetColumn riskDataSetColumn = new DataSetColumn();
		riskDataSetColumn.setSeriesName(CAStatusEnum.RiskOrder.getTypeName());
		riskDataSetColumn.setColor("FF3366");
		List<ColumnData> riskCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn shipmentDataSetColumn = new DataSetColumn();
		shipmentDataSetColumn.setSeriesName(CAStatusEnum.Shipment.getTypeName());
		shipmentDataSetColumn.setColor("6699FF");
		List<ColumnData> shipmentCloumnDataList = new ArrayList<ColumnData>();
		
		//for history month report
		DataSetColumn totalDataSetColumn = new DataSetColumn();
		totalDataSetColumn.setSeriesName("Total");
		totalDataSetColumn.setColor("6633FF");
		List<ColumnData> totalCloumnDataList = new ArrayList<ColumnData>();
		
		//for current month report
		DataSetColumn committedDataSetColumn = new DataSetColumn();
		committedDataSetColumn.setSeriesName("Committed Backlog");
		committedDataSetColumn.setColor("33CCFF");
		List<ColumnData> committedCloumnDataList = new ArrayList<ColumnData>();
		
		DataSetColumn bohDataSetColumn = new DataSetColumn();
		bohDataSetColumn.setSeriesName("BOH");
		bohDataSetColumn.setColor("660066");
		List<ColumnData> bohCloumnDataList = new ArrayList<ColumnData>();
		
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		List<CARemarkChartData> caRemarkChartDataList = fetchCaRemarkChartData(form);
		
		for(int i=0; i<caRemarkChartDataList.size(); i++) {
			if(i == 15) break;
			CARemarkChartData caRemarkChartData = caRemarkChartDataList.get(i);
			String name = caRemarkChartData.getDimensionName();
			String value = caRemarkChartData.getDimensionKey();
			int caTarget = caRemarkChartData.getCaTarget();
			
			CaCategory category = new CaCategory();
			category.setName(name);
			category.setValue(value);
			categoryList.add(category);
			
			String dimensionInfo = "";
			if(ChartTypeEnum.OverView.getTypeName().equals(form.getChartType()))
				dimensionInfo = form.getDimension()+ "," + name;
			else if(ChartTypeEnum.CrossMonth.getTypeName().equals(form.getChartType()))
				dimensionInfo = form.getDimension()+ "," + name + "~" + value;
			else if(ChartTypeEnum.Dashboard.getTypeName().equals(form.getChartType()))
				dimensionInfo = form.getDimension()+ "," + name + "~" + value;
			
			ColumnData risk = new ColumnData();
			setRemarkColumnLink(form,category,risk,caTarget);
			risk.setValue(0);
			
			ColumnData shipment = new ColumnData();
			setRemarkColumnLink(form,category,shipment,caTarget);
			shipment.setValue(0);
			
			ColumnData total = new ColumnData();
			setRemarkColumnLink(form,category,total,caTarget);
			total.setValue(0);
			
			ColumnData committed = new ColumnData();
			setRemarkColumnLink(form,category,committed,caTarget);
			committed.setValue(0);
			
			ColumnData boh = new ColumnData();
			setRemarkColumnLink(form,category,boh,caTarget);
			boh.setValue(0);
			
			risk.setValue(caRemarkChartData.getRiskRate());
			risk.setTooltext(CAStatusEnum.RiskOrder.getTypeName() +", " + name + ", "+ caRemarkChartData.getRiskRate() + "%");
			setRemarkColumnLink(form,category,risk,caTarget);
			
			shipment.setValue(caRemarkChartData.getShipmentRate());
			shipment.setTooltext(CAStatusEnum.Shipment.getTypeName() +", " + name + ", "+ caRemarkChartData.getShipmentRate() + "%");
			setRemarkColumnLink(form,category,shipment,caTarget);
			
			total.setValue(caRemarkChartData.getTotalRateForRender());
			total.setTooltext(CAStatusEnum.Total.getTypeName() +", " + name + ", "+ caRemarkChartData.getTotalRate() + "%");
			setRemarkColumnLink(form,category,total,caTarget);
			
			committed.setValue(caRemarkChartData.getCommittedRate());
			committed.setTooltext(CAStatusEnum.CommitedOrder.getTypeName() +", " + name + ", "+ caRemarkChartData.getCommittedRate() + "%");
			setRemarkColumnLink(form,category,committed,caTarget);
			
			boh.setValue(caRemarkChartData.getBohRate());
			boh.setTooltext(CAStatusEnum.BOH.getTypeName() +", " + name + ", "+ caRemarkChartData.getBohRate() + "%");
			setRemarkColumnLink(form,category,boh,caTarget);
			
			if(risk.getValue().intValue() != 0) 
				riskCloumnDataList.add(risk);
			else
				riskCloumnDataList.add(null);
			
			if(shipment.getValue().intValue() != 0) 
				shipmentCloumnDataList.add(shipment);
			else
				shipmentCloumnDataList.add(null);
			
			totalCloumnDataList.add(total);
			
			committedCloumnDataList.add(committed);
			
			if(boh.getValue().intValue() != 0) 
				bohCloumnDataList.add(boh);
			else
				bohCloumnDataList.add(null);
		}
		Categories categories = new Categories();
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		riskDataSetColumn.setDataList(riskCloumnDataList);
		shipmentDataSetColumn.setDataList(shipmentCloumnDataList);
		
		if(!form.isShowQuarterOverview()) {
			//for history: risk is before shipment, but for current month risk is after shipment
			if(form.getSelectMonth().compareTo(form.getCurrentRolMonth()) < 0) {
				if("Region".equals(form.getDimension())) {
					if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
						caDimensionDataSetList.add(riskDataSetColumn);
					}
				}
				caDimensionDataSetList.add(shipmentDataSetColumn);
			}
			
			if(form.getSelectMonth().compareTo(form.getCurrentRolMonth()) == 0) {
				caDimensionDataSetList.add(shipmentDataSetColumn);
				if("Region".equals(form.getDimension())) {
					if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
						caDimensionDataSetList.add(riskDataSetColumn);
					}
				}
			}
		}
		else {
			//for history: risk is before shipment, but for current month risk is after shipment
			String currentRolMonth = form.getCurrentRolMonth().replace("-", "");
			if(form.getQuarterTo().compareTo(currentRolMonth) < 0) {
				if("Region".equals(form.getDimension())) {
					if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
						caDimensionDataSetList.add(riskDataSetColumn);
					}
				}
				caDimensionDataSetList.add(shipmentDataSetColumn);
			}
			
			if(form.getQuarterFrom().compareTo(currentRolMonth) <= 0 
					&& form.getQuarterTo().compareTo(currentRolMonth) >= 0 ) {
				caDimensionDataSetList.add(shipmentDataSetColumn);
				if("Region".equals(form.getDimension())) {
					if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
						caDimensionDataSetList.add(riskDataSetColumn);
					}
				}
			}
		}
		
		totalDataSetColumn.setDataList(totalCloumnDataList);
		committedDataSetColumn.setDataList(committedCloumnDataList);
		
		if(!form.isShowSalesOverview()) {
			if(form.getSelectMonth().compareTo(form.getCurrentRolMonth()) == 0) {
				caDimensionDataSetList.add(committedDataSetColumn);
			}
			else if(form.getSelectMonth().compareTo(form.getCurrentRolMonth()) < 0) {
				caDimensionDataSetList.add(totalDataSetColumn);
			}
		}
		
		bohDataSetColumn.setDataList(bohCloumnDataList);
		
		if(!form.isShowSalesOverview())
			caDimensionDataSetList.add(bohDataSetColumn);
		
		columnChartView.setDataSetList(caDimensionDataSetList);
		
		return columnChartView;
	}

	
	public List<CARemarkChartData> fetchCaRemarkChartData(SearchCaForm form) throws ParseException {
		if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			if(!form.isShowQuarterOverview()) {
				String yearStr = form.getSelectMonth().substring(0,4);
				String monthStr = form.getSelectMonth().substring(5,7);
				int year = Integer.parseInt(yearStr);
				int month = Integer.parseInt(monthStr);
				form.setYear(year);
				form.setMonth(month);
			}
		}
		
		List<CARemarkChartData> caRemarkChartDataList = new ArrayList<CARemarkChartData>();
		caRemarkChartDataList = caDao.fetchDimensionRemarkDataList(form);
		
		//use ca target for calculation when showing region remark chart, otherwise use odm commitment
		Integer odmCommitment = null; Integer caTarget = null; Integer boh = null;
		for(CARemarkChartData caRemarkChartData : caRemarkChartDataList) {
			if(ChartTypeEnum.CrossMonth.getTypeName().equals(form.getChartType()))
				caRemarkChartData.setChartType(ChartTypeEnum.CrossMonth.getTypeName());
			else if(ChartTypeEnum.Dashboard.getTypeName().equals(form.getChartType()))
				caRemarkChartData.setChartType(ChartTypeEnum.Dashboard.getTypeName());
			else if(ChartTypeEnum.OverView.getTypeName().equals(form.getChartType()))
				caRemarkChartData.setChartType(ChartTypeEnum.OverView.getTypeName());
			
			if(!form.isShowSalesOverview()) {
				boh = caDao.fetchRemarkBoh(caRemarkChartData,form);
				if(boh != null)
					caRemarkChartData.setBoh(boh);
			}
			
			//if("Region".equals(caRemarkChartData.getRemarkType())) {
				caTarget = caDao.fetchRemarkCaTarget(caRemarkChartData,form);
				if(caTarget != null && caTarget != 0)
					caRemarkChartData.setCaTarget(caTarget);
			//}
			//else {
				odmCommitment = caDao.fetchRemarkOdmCommitment(caRemarkChartData,form);
				if(odmCommitment != null && odmCommitment != 0)
					caRemarkChartData.setOdmCommitment(odmCommitment);
			//}
		}
		
		CARemarkChartDataComparator caRemarkChartDataComparator = new CARemarkChartDataComparator();
		Collections.sort(caRemarkChartDataList, caRemarkChartDataComparator);
		
		return caRemarkChartDataList;
	}
	
	public float calCaRate(int totalFa, int subFa) {
		BigDecimal faRate = new BigDecimal(0);
		MathContext mc = new MathContext(1, RoundingMode.HALF_DOWN);
		
		try{
			faRate = new BigDecimal(subFa).divide(new BigDecimal(totalFa),mc).multiply(new BigDecimal(100));
		}
		catch(ArithmeticException e) {
			return 0;
		}
		
		return faRate.floatValue();
	}
	
	public void setColumnLink(int weekNo,ColumnData cloumnData) {
		
		cloumnData.setLink("j-refreshRemark-");
	
	}
	
	public void setRemarkColumnLink(String dimensionInfo,ColumnData cloumnData,SearchCaForm form) {
		
		//if(!form.isShowSalesOverview()){
			if(ChartTypeEnum.CrossMonth.getTypeName().equals(form.getChartType()))
				cloumnData.setLink( "j-mfgCaCrossMonthOrderDetailShow-"+dimensionInfo );
			else if(ChartTypeEnum.Dashboard.getTypeName().equals(form.getChartType()))
				cloumnData.setLink( "j-mfgCaDashboardOrderDetailShow-"+dimensionInfo );
			else
				cloumnData.setLink( "j-showMfgCaOrderDetail-"+dimensionInfo );
		/*}
		else{
			//cloumnData.setLink( "j-showSalesCaDetail-"+sb.toString() );
		}*/
		
	}
	
	public void setRemarkColumnLink(SearchCaForm form,CaCategory category,ColumnData cloumnData,int caTarget) {
		StringBuffer sb = new StringBuffer();
		String durationFrom = form.getQuarterFrom() != null ? form.getQuarterFrom() : form.getStartDate();
		String durationTo = form.getQuarterTo() != null ? form.getQuarterTo() : form.getEndDate();
		if(StringUtils.isBlank(durationTo)){
			durationTo = durationFrom;
		}
		sb.append("{");
		sb.append("durationFrom:")
			.append("\"").append(durationFrom).append("\"").append(",");
		sb.append("durationTo:")
			.append("\"").append(durationTo).append("\"").append(",");
		sb.append("dimension:")
			.append("\"").append(form.getDimension()).append("\"").append(",");
		sb.append("dimensionKey:")
		.append("\"").append(category.getValue()).append("\"").append(",");
		sb.append("caTarget:")
			.append(caTarget)
			.append(form.getPortfolioIds()).append("}");
		if(!form.isShowSalesOverview()){
			cloumnData.setLink( "j-showMfgCaDetail-"+sb.toString() );
		}
		else{
			cloumnData.setLink( "j-showSalesCaDetail-"+sb.toString() );
		}
		
	}
	
	private ColumnChartView setRemarkChartInfomation() {
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		columnChartView.getChartInfo().setFormatNumber("%");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setShowBorder("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setShowValues("0");
//		columnChartView.getChartInfo().setSnumberSuffix("%");
		columnChartView.getChartInfo().setNumbersuffix("%");
//		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");
		columnChartView.getChartInfo().setChartRightMargin("50");//data will not be overflow
		
		return columnChartView;
	}
	
	private ColumnChartView setCaRemarkChartInfomation() {
		
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumbersuffix("%");
		columnChartView.getChartInfo().setNumdivlines("10");
		columnChartView.getChartInfo().setShowValues("1");
		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setShowBorder("0");
		
		/*columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		columnChartView.getChartInfo().setFormatNumber("%");*/
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		//columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");
		
		return columnChartView;
	}
	
	private void setOverviewChartInfomation(ColumnChartView mSColumnChartView,SearchCaForm form) {
		mSColumnChartView.getChartInfo().setCaption("");
		mSColumnChartView.getChartInfo().setNumdivlines("9");
		mSColumnChartView.getChartInfo().setyAxisMinValue("0");
		mSColumnChartView.getChartInfo().setyAxisMaxValue("160");
		mSColumnChartView.getChartInfo().setsYAxisMinValue("0");
		if(form.isShowSalesOverview())
			mSColumnChartView.getChartInfo().setsYAxisMinValue("0");
		mSColumnChartView.getChartInfo().setsYAxisMaxValue("150");
		mSColumnChartView.getChartInfo().setFormatNumberScale("0");
		mSColumnChartView.getChartInfo().setLegendIconScale("1");
		mSColumnChartView.getChartInfo().setShowBorder("1");
		mSColumnChartView.getChartInfo().setCanvasBorderThickness("1");
		mSColumnChartView.getChartInfo().setShowZeroPlaneValue("1");
		mSColumnChartView.getChartInfo().setCanvasBorderAlpha("60");
		mSColumnChartView.getChartInfo().setPlotSpacePercent("8");
		mSColumnChartView.getChartInfo().setBgalpha("0,0");
		mSColumnChartView.getChartInfo().setLegendPosition("");
		mSColumnChartView.getChartInfo().setShowBorder("0");
		mSColumnChartView.getChartInfo().setShowPlotBorder("0");
		mSColumnChartView.getChartInfo().setShowValues("0");
	}

	@Override
	public String getOverviewOverall(SearchCaForm form) throws ParseException {
		List<ScOverViewChartData> charDats = caDao.fetchCaDataByDimKeys(form);
		ScOverViewChartData caTarget =  new ScOverViewChartData();
		caTarget.setOrderNum(120000);//TODO
		caTarget.setScStatusName("CaTarget");
		StringBuffer valueBuffer = new StringBuffer("[{");
		if(CollectionUtils.isNotEmpty(charDats)){
			Map<String,Integer> dataMap = new HashMap<String,Integer>();
			for(ScOverViewChartData data : charDats){
				if(data.getScStatusName().equals(CAStatusEnum.Commitment.getTypeName())) {
					valueBuffer.append("commitment:");
					dataMap.put(CAStatusEnum.Commitment.getTypeName(), data.getOrderNum());
				}
				else if(data.getScStatusName().equals(CAStatusEnum.Outlook.getTypeName())) {
					valueBuffer.append("outlook:");
					dataMap.put(CAStatusEnum.Outlook.getTypeName(), data.getOrderNum());
				}
				else if(data.getScStatusName().equals(CAStatusEnum.RiskOrder.getTypeName())) {
					valueBuffer.append("risk:");
					dataMap.put(CAStatusEnum.RiskOrder.getTypeName(), data.getOrderNum());
				}
				else if(data.getScStatusName().equals(CAStatusEnum.Shipment.getTypeName())) {
					valueBuffer.append("shipment:");
					dataMap.put(CAStatusEnum.Shipment.getTypeName(), data.getOrderNum());
				}
				else if(data.getScStatusName().equals(CAStatusEnum.CommitedOrder.getTypeName())) {
					valueBuffer.append("commited:");
					dataMap.put(CAStatusEnum.CommitedOrder.getTypeName(), data.getOrderNum());
				}
				valueBuffer.append(data.getOrderNum()).append(",");
				
			}
			dataMap.put("CATarget", caTarget.getOrderNum());
			float caValue; float ctpAchievementValue;
			String categoryDate = form.getStartDate() +"-"+form.getEndDate();
			if(!form.isShowSalesOverview()){
				caValue = commonService.calculateMFGCaMakeRate(categoryDate, form.getCurrentRolMonth(), dataMap, true);
				ctpAchievementValue = commonService.calculateMFGCaMakeRate(categoryDate, form.getCurrentRolMonth(), dataMap, false);
			}
			else{
				caValue = commonService.calculateSalesCaMakeRate(categoryDate, form.getCurrentRolMonth(), dataMap, true);
				ctpAchievementValue = commonService.calculateSalesCaMakeRate(categoryDate, form.getCurrentRolMonth(), dataMap, false);
			}
			valueBuffer.append("makeRate:").append(caValue).append(",");
			valueBuffer.append("ctpAchievement:").append(ctpAchievementValue).append(",");
		}
		valueBuffer.append("caTarget:")
					.append(caTarget.getOrderNum()).append("}]");
		return valueBuffer.toString();
	}

	/**
	 * CA Overview Summary detail
	 */
	@Override
	public List<CaDetailGridView> getSumCaDetails(SearchCaForm form)
			throws ParseException {
		this.makeOrderDetailQueryCondition(form);
		if(form != null){
			if(!form.isShowSalesOverview()){
				return this.getMfgCaDetails(form);
			}
			else{
				return this.getSalesCaDetails(form);
			}
		}
		return null;
	}
	
	
	@Override
	public List<CaDetailGridView> getRemarkCaDetails(SearchCaForm form) {
		if(!form.isShowSalesOverview()){
			return this.getMfgCaDetails(form);
		}
		else{
			return this.getSalesCaDetails(form);
		}
	}
	
	private void makeOrderDetailQueryCondition(SearchCaForm form){
		if(form != null){
			if(ChartTypeEnum.OverView.getTypeName().equals(form.getChartType())){
				
			}
			else if(ChartTypeEnum.CrossMonth.getTypeName().equals(form.getChartType())){
				if(StringUtils.isNotBlank(form.getOverViewSubDimensionKey()) && !"-1".equals(form.getOverViewSubDimensionKey())){
					this.setFormDimParam(form, form.getOverViewDimension(), String.valueOf(form.getOverViewSubDimensionKey()));
				}
			}
			else if(ChartTypeEnum.Dashboard.getTypeName().equals(form.getChartType())){
				List<CaKeyNameObject> dimensionList = caDao.fetchDimensions(form);
				if(CollectionUtils.isNotEmpty(dimensionList)){
					StringBuffer tempDimKeys = new StringBuffer();
					for(CaKeyNameObject dim : dimensionList){
						tempDimKeys.append(dim.getObjKey()).append(",");
					}
					String dimKeys = tempDimKeys.toString();
					if(StringUtils.isNotBlank(dimKeys)){
						dimKeys = dimKeys.substring(0, dimKeys.length() - 1);
						this.setFormDimParam(form, form.getOverViewDimension(), dimKeys);
					}
					else{
						form = null;
					}
				}
				else{
					form = null;
				}
			}
		}
	}
	
	public void setFormDimParam(SearchCaForm form, String dim, String dimKeys){
		if("Family".equals(dim)){
			if(StringUtils.isBlank(form.getFamilyIds())){
				form.setFamilyIds(dimKeys);
			}else{
				form.setFamilyIds(form.getFamilyIds()+","+dimKeys);
			}
		}
		else if("Product".equals(dim)){
			if(StringUtils.isBlank(form.getProductIds())){
				form.setProductIds(dimKeys);
			}else{
				form.setProductIds(form.getProductIds()+","+dimKeys);
			}
		}
		else if("Region".equals(dim)){
			if(StringUtils.isBlank(form.getGeoIds())){
				form.setGeoIds(dimKeys);
			}else{
				form.setGeoIds(form.getGeoIds()+","+dimKeys);
			}
		}
		else if("Portfolio".equals(dim)){
			if(StringUtils.isBlank(form.getPortfolioIds())){
				form.setPortfolioIds(dimKeys);
			}else{
				form.setPortfolioIds(form.getPortfolioIds()+","+dimKeys);
			}
		}
	}

	@Override
	public Map<String,Object> getCaRemarkOrderDetail(SearchCaForm form) throws ParseException {
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
		}
		else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		
		totalCount = caDao.getRemarkOrderDetailCount(form);
		
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			if(form.isShowSalesOverview())
				grid = caDao.getSalesRemarkOrderDetail(form);
			else
				grid = caDao.getRemarkOrderDetail(form);
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	
	@Override
	public Map<String,Object> getCaOrderDetail(SearchCaForm form) throws ParseException {
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
			String yearMonth =  month < 10 ? year + "-0" + month : year + "-" +month;
		}
		else {
			form.setShowQuarterOverview(true);
			form.setQuarterFrom(form.getStartDate());
			form.setQuarterTo(form.getEndDate());
		}
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			totalCount = caDao.getOverviewOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				
				if(form.isShowSalesOverview())
					grid = caDao.getSalesOverviewOrderDetail(form);
				else
					grid = caDao.getOverviewOrderDetail(form);
			}
		}
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			totalCount = caDao.getCrossMonthOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				if(form.isShowSalesOverview())
					grid = caDao.getSalesCrossMonthOrderDetail(form);
				else
					grid = caDao.getCrossMonthOrderDetail(form);
			}
		}
		else{
			totalCount = caDao.getDashboardOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				if(form.isShowSalesOverview())
					grid = caDao.getSalesDashboardOrderDetail(form);
				else
					grid = caDao.getDashboardOrderDetail(form);
			}
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	
	private List<CaDetailGridView> getMfgCaDetails(SearchCaForm form){
		List<CaDetailGridView> caDetails = caDao.fetchMfgCaDetail(form);
		int commitmentSum = 0;
		int orderQtySum = 0;
		int shipmentOrderSum = 0;
		int committedOrderSum = 0;
		int riskOrderSum = 0;
		int gapSum = 0;
		if(CollectionUtils.isNotEmpty(caDetails)){
			Map<String,String> regionMap = new HashMap<String,String>();
			int regionCount =1;
			Integer regionShipment = 0;
			for(CaDetailGridView detail : caDetails){
				if(!regionMap.containsKey(detail.getRegion())) {
					regionCount = 1;
					regionShipment = 0;
				}
				else {
					++regionCount;
				}
				regionShipment += detail.getShipmentOrder();
				regionMap.put(detail.getRegion(), regionCount + ":" + regionShipment);
				
			}
			
			for(CaDetailGridView detail : caDetails){
				Integer caTarget = detail.getCaTarget();
				Integer shipment = detail.getShipmentOrder();
				Integer targetBalance = caTarget - shipment;
				
				if(regionMap.containsKey(detail.getRegion())) {
					String[] strArr = regionMap.get(detail.getRegion()).split(":");
					detail.setRegionCount(Integer.parseInt(strArr[0]));
					targetBalance = detail.getCaTarget() - Integer.parseInt(strArr[1]);
				}
				
				detail.setGap(detail.getCommitment() -  shipment);
				detail.setCaTarget(caTarget);
				detail.setTargetBalance(targetBalance);
				
				orderQtySum = orderQtySum + detail.getOrderQTY();
				commitmentSum = commitmentSum + detail.getCommitment();
				shipmentOrderSum = shipmentOrderSum + detail.getShipmentOrder();
				committedOrderSum = committedOrderSum + detail.getCommittedOrder();
				riskOrderSum = riskOrderSum + detail.getRiskOrder();
				gapSum = gapSum + detail.getGap();
			}
			caDetails.get(0).setOrderQTYSum(orderQtySum);
			caDetails.get(0).setCommitmentSum(commitmentSum);
			caDetails.get(0).setShipmentOrderSum(shipmentOrderSum);
			caDetails.get(0).setCommittedOrderSum(committedOrderSum);
			caDetails.get(0).setRiskOrderSum(riskOrderSum);
			caDetails.get(0).setGapSum(gapSum);
		}
		return caDetails;
	}
	
	private List<CaDetailGridView> getSalesCaDetails(SearchCaForm form){
		List<CaDetailGridView> caDetails = caDao.fetchSalesCaDetail(form);
		int shipmentOrderSum = 0;
		
		if(CollectionUtils.isNotEmpty(caDetails)){
			Map<String,String> regionMap = new HashMap<String,String>();
			int regionCount =1;
			Integer regionShipment = 0;
			for(CaDetailGridView detail : caDetails){
				if(!regionMap.containsKey(detail.getRegion())) {
					regionCount = 1;
					regionShipment = 0;
				}
				else {
					++regionCount;
				}
				regionShipment += detail.getShipmentOrder();
				regionMap.put(detail.getRegion(), regionCount + ":" + regionShipment);
				
			}
			
			for(CaDetailGridView detail : caDetails) {
				Integer caTarget = detail.getCaTarget();
				Integer shipment = detail.getShipmentOrder();
				Integer targetBalance = caTarget - shipment;
				
				if(regionMap.containsKey(detail.getRegion())) {
					String[] strArr = regionMap.get(detail.getRegion()).split(":");
					detail.setRegionCount(Integer.parseInt(strArr[0]));
					targetBalance = detail.getCaTarget() - Integer.parseInt(strArr[1]);
				}
				
				detail.setCaTarget(caTarget);
				detail.setTargetBalance(targetBalance);
				shipmentOrderSum = shipmentOrderSum + detail.getShipmentOrder();
			}
			caDetails.get(0).setShipmentOrderSum(shipmentOrderSum);
		}
		return caDetails;
	}
	public static int getMin(float fMax,float fMin){
		int max=getMax(fMax);
		float min=fMin;
		int i=0;
		int myMin;
		for(i=10;;i+=5){
			myMin=max-10*i;
			if(myMin<=min){
				break;
			}
		}
		return myMin;
	}
	private static int getMax(float max){
		int i=0;
		while(i<=max){
			i+=50;
		}
		return i;
	}
}

