package com.lenovo.bi.engine;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.CtoCvConfig;
import com.lenovo.bi.dto.MtmCvConfig;
import com.lenovo.bi.dto.MtmGeographyOdmCvConfig;
import com.lenovo.bi.enumobj.PhaseEnum;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.ForecastData;
import com.lenovo.bi.model.OrderData;
import com.lenovo.bi.model.TtvWeeklyDetail;
import com.lenovo.bi.model.WeeklyComponentCommitmentOnOrderForecast;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;

public class SLESupplyCapabilityAllocator extends SupplyCapabilityAllocator<TtvWeeklyDetail> {

	public SLESupplyCapabilityAllocator(MtmCvConfigMap mtmCvConfigMap, PhaseEnum phase, Date targetDate, Date versionDate,
			TTVOutlookServiceBiHelper ttvOutlookServiceBiHelper) {
		super(mtmCvConfigMap, phase, targetDate, versionDate, ttvOutlookServiceBiHelper);
	}

	public void processOrderData(List<OrderData> orderDataList, ComponentQuota mtmComponentQuota, Map<String, TtvWeeklyDetail> weeklyDetailMap) {
		for (OrderData orderData : orderDataList) {
			int orderQuantity = orderData.getQuantity();

			MtmGeographyOdmCvConfig mtmCvConfig = new MtmGeographyOdmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(orderData.getBomNumber()),
					orderQuantity, orderData.getGeographyName(), orderData.getOdmName());
			int commitQuantity = mtmComponentQuota.calculateMaxMtmNumberOfUnits(mtmCvConfig);

			// Set material data on orderData
			orderData.setMaterialCommit(commitQuantity);
			orderData.setMaterialShortage(orderQuantity - commitQuantity);

			// Set box-level supply commit on TtvWeeklyDetail
			TtvWeeklyDetail ttvWeeklyDetail = weeklyDetailMap.get(orderData.getProductKey()+orderData.getPmsWaveId());
			if (ttvWeeklyDetail != null && TTVPhase.sle.name().equals(orderData.getTtvPhase())) // add by nicolas on Jun 30,2014
				ttvWeeklyDetail.setSupplyCommit(ttvWeeklyDetail.getSupplyCommit() + commitQuantity);

			// Record all materials
			Date now = new Date();

			MtmCvConfig committedCvConfig = new MtmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(orderData.getBomNumber()), commitQuantity);
			List<WeeklyComponentCommitmentOnOrderForecast> commitments = new ArrayList<WeeklyComponentCommitmentOnOrderForecast>();
			for (Integer cvKey : committedCvConfig.getAllCvs()) {
				WeeklyComponentCommitmentOnOrderForecast commitment = new WeeklyComponentCommitmentOnOrderForecast();
				commitment.setPoNumber(orderData.getPoNumber());
				commitment.setPoItem(orderData.getPoItem());
				commitment.setOrderDate(orderData.getOrderDate());
				commitment.setRsdDate(orderData.getRsdDate());
				commitment.setRegion(orderData.getGeographyName());
				commitment.setOrderQuantity(orderData.getQuantity());
				commitment.setTtvPhase(orderData.getTtvPhase());
				commitment.setGlobalCvKey(cvKey);
				commitment.setDemand(mtmCvConfig.getQuantity(cvKey));
				commitment.setCommitment(committedCvConfig.getQuantity(cvKey));
				commitment.setDelta(mtmCvConfig.getQuantity(cvKey) - committedCvConfig.getQuantity(cvKey));
				commitment.setProductKey(Integer.valueOf(orderData.getProductKey()));
				commitment.setBomNumber(orderData.getBomNumber());
				commitment.setForNpi(phase == PhaseEnum.NPI);
				commitment.setTargetDate(targetDate);
				commitment.setVersionDate(versionDate);
				commitment.setCreatedDate(now);
				commitment.setLastModifiedDate(now);

				commitments.add(commitment);
			}

			ttvOutlookServiceBiHelper.addWeeklyComponentCommitmentOnOrderForecast(commitments);

			// Deduct the CVs from component quota
			mtmCvConfig = new MtmGeographyOdmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(orderData.getBomNumber()), commitQuantity,
					orderData.getGeographyName(), orderData.getOdmName());
			mtmComponentQuota.deductMtmUnits(mtmCvConfig);
		}
	}

	public void processForecastData(List<ForecastData> forecastDataList, ComponentQuota ctoComponentQuota, Map<String, TtvWeeklyDetail> weeklyDetailMap) {
		for (ForecastData forecastData : forecastDataList) {
			Date now = new Date();

			if (!forecastData.getCtoForecast()) { // 59 and MTM
				if (forecastData.getMaterialCommit() == forecastData.getQuantity()) { // Already
																						// has
																						// box-level
																						// commit
					// Set box-level supply commit on TtvWeeklyDetail
					TtvWeeklyDetail ttvWeeklyDetail = weeklyDetailMap.get(forecastData.getProductKey()+forecastData.getPmsWaveId());
					if (ttvWeeklyDetail != null && TTVPhase.sle.name().equals(forecastData.getTtvPhase())) // add by nicolas on Jun
													// 30,2014
						ttvWeeklyDetail.setSupplyCommit(ttvWeeklyDetail.getSupplyCommit() + forecastData.getQuantity());
				} else {
					int forecastQuantity = forecastData.getQuantity();

					MtmGeographyOdmCvConfig mtmCvConfig = new MtmGeographyOdmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(forecastData.getBomNumber()),
							forecastQuantity, forecastData.getGeographyName(), forecastData.getOdmName());
					int commitQuantity = ctoComponentQuota.calculateMaxMtmNumberOfUnits(mtmCvConfig);

					// Set material data on forecastData
					forecastData.setMaterialCommit(commitQuantity);
					forecastData.setMaterialShortage(forecastQuantity - commitQuantity);

					// Set box-level supply commit on TtvWeeklyDetail
					TtvWeeklyDetail ttvWeeklyDetail = weeklyDetailMap.get(forecastData.getProductKey()+forecastData.getPmsWaveId());
					if (ttvWeeklyDetail != null && TTVPhase.sle.name().equals(forecastData.getTtvPhase())) // add by nicolas on Jun
													// 30,2014
						ttvWeeklyDetail.setSupplyCommit(ttvWeeklyDetail.getSupplyCommit() + commitQuantity);

					// Record all materials
					MtmCvConfig committedCvConfig = new MtmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(forecastData.getBomNumber()), commitQuantity);
					List<WeeklyComponentCommitmentOnOrderForecast> commitments = new ArrayList<WeeklyComponentCommitmentOnOrderForecast>();
					for (Integer cvKey : committedCvConfig.getAllCvs()) {
						WeeklyComponentCommitmentOnOrderForecast commitment = new WeeklyComponentCommitmentOnOrderForecast();
						commitment.setGlobalCvKey(cvKey);
						commitment.setDemand(mtmCvConfig.getQuantity(cvKey));
						commitment.setCommitment(committedCvConfig.getQuantity(cvKey));
						commitment.setDelta(mtmCvConfig.getQuantity(cvKey) - committedCvConfig.getQuantity(cvKey));
						commitment.setProductKey(Integer.valueOf(forecastData.getProductKey()));
						commitment.setBomNumber(forecastData.getBomNumber());
						commitment.setForNpi(phase == PhaseEnum.NPI);
						commitment.setTargetDate(targetDate);
						commitment.setVersionDate(versionDate);
						commitment.setCreatedDate(now);
						commitment.setLastModifiedDate(now);
						commitment.setTtvPhase(TTVPhase.sga.name());

						commitments.add(commitment);
					}

					ttvOutlookServiceBiHelper.addWeeklyComponentCommitmentOnOrderForecast(commitments);

					// Deduct the CVs from component quota
					mtmCvConfig = new MtmGeographyOdmCvConfig(mtmCvConfigMap.getSingleUnitCvConfigOfMtm(forecastData.getBomNumber()), commitQuantity,
							forecastData.getGeographyName(), forecastData.getOdmName());
					ctoComponentQuota.deductMtmUnits(mtmCvConfig);
				}
			} else { // CTO
				if (forecastData.getMaterialCommit() == forecastData.getQuantity()) { // Already
																						// has
																						// box-level
																						// commit
					// Set box-level supply commit on TtvWeeklyDetail
					TtvWeeklyDetail ttvWeeklyDetail = weeklyDetailMap.get(forecastData.getProductKey()+forecastData.getPmsWaveId());
					if (ttvWeeklyDetail != null && TTVPhase.sle.name().equals(forecastData.getTtvPhase())) // add by nicolas on Jun
													// 30,2014
						ttvWeeklyDetail.setSupplyCommit(ttvWeeklyDetail.getSupplyCommit() + forecastData.getQuantity());
				} else { // No box-level commit. Try again.
							// For CTO forecasts, it is all-or-nothing. Unless
							// the whole CTO can be fulfilled, it is 0
					CtoCvConfig ctoCvConfig = forecastData.getCtoCvConfig();

					if (ctoComponentQuota.canFullfillCto(ctoCvConfig)) { // Fully
																			// fulfilled
						// Set material data on forecastData
						forecastData.setMaterialCommit(forecastData.getQuantity());
						forecastData.setMaterialShortage(0);

						// Set box-level supply commit on TtvWeeklyDetail
						TtvWeeklyDetail ttvWeeklyDetail = weeklyDetailMap.get(forecastData.getProductKey()+forecastData.getPmsWaveId());
						if (ttvWeeklyDetail != null && TTVPhase.sle.name().equals(forecastData.getTtvPhase())) // add by nicolas on Jun
														// 30,2014
							ttvWeeklyDetail.setSupplyCommit(ttvWeeklyDetail.getSupplyCommit() + forecastData.getQuantity());

						// Record all materials that are fulfilled
						List<WeeklyComponentCommitmentOnOrderForecast> commitments = new ArrayList<WeeklyComponentCommitmentOnOrderForecast>();
						for (Integer cvKey : ctoCvConfig.getAllCvs()) {
							WeeklyComponentCommitmentOnOrderForecast commitment = new WeeklyComponentCommitmentOnOrderForecast();
							commitment.setGlobalCvKey(cvKey);
							commitment.setDemand(ctoCvConfig.getQuantity(cvKey));
							commitment.setCommitment(ctoCvConfig.getQuantity(cvKey));
							commitment.setDelta(0);
							commitment.setProductKey(Integer.valueOf(forecastData.getProductKey()));
							commitment.setBomNumber(forecastData.getBomNumber());
							commitment.setForNpi(phase == PhaseEnum.NPI);
							commitment.setTargetDate(targetDate);
							commitment.setVersionDate(versionDate);
							commitment.setCreatedDate(now);
							commitment.setLastModifiedDate(now);

							commitments.add(commitment);
						}

						ttvOutlookServiceBiHelper.addWeeklyComponentCommitmentOnOrderForecast(commitments);

						// Deduct the CVs from component quota
						ctoComponentQuota.deductWholeCto(ctoCvConfig);
					} else { // Not fulfilled
								// Set material data on forecastData
						forecastData.setMaterialCommit(0);
						forecastData.setMaterialShortage(forecastData.getQuantity());

						// Record all materials that are fulfilled
						List<WeeklyComponentCommitmentOnOrderForecast> commitments = new ArrayList<WeeklyComponentCommitmentOnOrderForecast>();
						for (Integer cvKey : ctoCvConfig.getAllCvs()) {
							WeeklyComponentCommitmentOnOrderForecast commitment = new WeeklyComponentCommitmentOnOrderForecast();
							commitment.setGlobalCvKey(cvKey);
							commitment.setDemand(ctoCvConfig.getQuantity(cvKey));
							commitment.setCommitment(0);
							commitment.setDelta(ctoCvConfig.getQuantity(cvKey));
							commitment.setProductKey(Integer.valueOf(forecastData.getProductKey()));
							commitment.setBomNumber(forecastData.getBomNumber());
							commitment.setForNpi(phase == PhaseEnum.NPI);
							commitment.setTargetDate(targetDate);
							commitment.setVersionDate(versionDate);
							commitment.setCreatedDate(now);
							commitment.setLastModifiedDate(now);

							commitments.add(commitment);
						}

						ttvOutlookServiceBiHelper.addWeeklyComponentCommitmentOnOrderForecast(commitments);
					}
				}
			}
		}
	}
}
