package com.lenovo.bi.engine;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lenovo.bi.dto.MtmCvQuantity;
import com.lenovo.bi.dto.SingleUnitCvConfig;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.SysConstants;

@Component
public class MtmCvConfigMap {
	private Map<String, SingleUnitCvConfig> mtmCvConfigMap = new HashMap<String, SingleUnitCvConfig>();
	private static Logger LOGGER = Logger.getLogger(SysConstants.LOG_WEEKLY_BATCH_CATALOG);
	
	@Autowired
	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	
	//@PostConstruct
	public synchronized void constructMap() {
		List<MtmCvQuantity> allMtmCvQuantity = ttvOutlookServiceDwHelper.getAllMtmCvQuantity();
		
		for (MtmCvQuantity cq : allMtmCvQuantity) {
			SingleUnitCvConfig singleUnitCvConfig = mtmCvConfigMap.get(cq.getBomNumber());
			if (singleUnitCvConfig == null) {
				singleUnitCvConfig = new SingleUnitCvConfig();
				mtmCvConfigMap.put(cq.getBomNumber(), singleUnitCvConfig);		
			}
			
			singleUnitCvConfig.addCv(cq.getCvKey(), cq.getQuantity());
		}
		
		LOGGER.info("Number of entries in MTMCVConifgMap: " + mtmCvConfigMap.size());
	}
	
	// TODO-Ying, remove comment sign
	//@Scheduled(cron="0 0 20 * * *")  // Run every day at 20 o'clock
	public void refreshMaps() {
		constructMap();
	}
	
	public synchronized SingleUnitCvConfig getSingleUnitCvConfigOfMtm(String bomNumber) {
		return mtmCvConfigMap.get(bomNumber);
	}
}
