package com.lenovo.bi.service.common.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.common.ExcludeOrderDao;
import com.lenovo.bi.model.ExcludeOrder;
import com.lenovo.bi.service.common.ExcludeOrderService;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.common.model.Pager;
import com.lenovo.common.model.PagerInformation;

@Service
public class ExcludeOrderServiceImpl implements ExcludeOrderService {

	@Inject
	private ExcludeOrderDao excludeOrderDao;
	

	@Override
	public void batchSaveExcludeOrder(List<ExcludeOrder> excludeOrders) {
		// TODO Auto-generated method stub
		excludeOrderDao.batchSaveExcludeOrder(excludeOrders);
	}


	@Override
	public void deleteExcludeOrderByMonth(String month) {
		// TODO Auto-generated method stub
		excludeOrderDao.deleteExcudeOrder(month);
	}

	@Override
	public int getExcludeOrderCountByMonth(String month) {
		// TODO Auto-generated method stub
		return excludeOrderDao.getExcludeOrderCountByMonth(month);
	}

	@Override
	public Pager<ExcludeOrder> getExcludeOrderByConditions(String month , int currentPage) {
		// TODO Auto-generated method stub
		Pager<ExcludeOrder> pager = new Pager<ExcludeOrder>();
		PagerInformation info = new PagerInformation();
		pager.setPagerInfo(info);
		info.setCurrentPage(currentPage);
		info.setPageSize(SysConfig.NUMBER_OF_ROW_COUNT);
		List<ExcludeOrder> list = excludeOrderDao.getExcludeOrdersByCondition(month, info);

		pager.setDatas(list);

		int recordCount = excludeOrderDao.getExcludeOrderCountByMonth(month);
		info.setRecordCount(recordCount);
		return pager;
	}

}
