package com.lenovo.bi.engine;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.model.SGATtvWeeklySummary;
import com.lenovo.bi.service.npi.helper.NPIWaveSummaryHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.util.CalendarUtil;

/**
 * 
 * 
 * @author henry_lian
 * 
 */
@Component
@Order(1)
public class SgaTTVStatusProcessor implements SgaTTVKPIProcessor {

	@Autowired
	private NPIWaveSummaryHelper nPIWaveSummaryHelper;
	@Autowired
	private TTVOutlookServiceBiHelper biHelper;

	@Override
	public void process(ProjectSummary ps, Date versionDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String todayStr = sdf.format(new Date())  ;
		Date today = null;
		try {
			today = sdf.parse(todayStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		float ttvTarget = 0f;
		if(ps.getSgaTtvTarget() != null){
			ttvTarget = ps.getSgaTtvTarget();
		}
		if (ps.getSgaTtvTargetDate() == null) {
			ps.setSgaTtvStatus(Status.NA.name());
		} else if (ps.getSgaTtvSignOffDate() != null) {
			if (ps.getSgaTtvSignOffDate().before(ps.getSgaTtvTargetDate())) {
				Date sgaSignOffDate = CalendarUtil.getMondayDateByDate(ps.getSgaTtvSignOffDate());
				List<SGATtvWeeklySummary> summary = biHelper.getSgaNpiWeeklySummary(ps.getPmsWaveId(), sgaSignOffDate, sgaSignOffDate, sgaSignOffDate);
				if(summary != null && !summary.isEmpty()){
					ps.setSgaActualTTV(summary.get(0).getTtvOdm());
				} else{
					//hope this never happens
					//ps.setSgaActualTTV(0f);
					ps.setSgaActualTTV(-1f);
				}
				if (ps.getSgaActualTTV() >= ttvTarget) {
					ps.setSgaTtvStatus(Status.Success.name());
				} else {
					ps.setSgaTtvStatus(Status.Fail.name());
				}
			} else {
				Date sgaTargeDateDate = CalendarUtil.getMondayDateByDate(ps.getSgaTtvTargetDate());
				Date sgaSignOffDate = CalendarUtil.getMondayDateByDate(ps.getSgaTtvSignOffDate());
				List<SGATtvWeeklySummary> summary = biHelper.getSgaNpiWeeklySummary(ps.getPmsWaveId(), sgaTargeDateDate, sgaTargeDateDate, sgaSignOffDate);
				if (CollectionUtils.isEmpty(summary)) {
					ps.setSgaTtvStatus(Status.Fail.name());
					//ps.setSgaActualTTV(0f);
					ps.setSgaActualTTV(-1f);
				} else{
					float actulaTTV = summary.get(0).getTtvOdm();
					ps.setSgaActualTTV(actulaTTV);
					if (actulaTTV >= ttvTarget) {
						ps.setSgaTtvStatus(Status.Success.name());
					} else {
						ps.setSgaTtvStatus(Status.Fail.name());
					}
				}
			}
		} else {
			if (today.after(ps.getSgaTtvTargetDate())) {
				ProjectSummary snapshot = nPIWaveSummaryHelper
						.getProductInfoByWaveId(ps.getPmsWaveId(),
								CalendarUtil.getMondayDateByDate(ps.getSgaTtvTargetDate()));
				if (snapshot != null && snapshot.getSgaActualTTV() >= ttvTarget) {
					ps.setSgaTtvStatus(Status.In_Progress.name());
					ps.setIsSgaTtvRisk(false);
				} else {
					ps.setSgaTtvStatus(Status.Fail.name());
				}
			} else {
				ps.setSgaTtvStatus(Status.In_Progress.name());
				if (ps.getSgaEstimatedTTV() >= ttvTarget) {
					ps.setIsSgaTtvRisk(false);
				} else {
					ps.setIsSgaTtvRisk(true);
				}
			}
		}

	}

}
