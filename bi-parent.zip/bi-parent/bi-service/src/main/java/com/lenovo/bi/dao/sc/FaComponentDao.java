package com.lenovo.bi.dao.sc;

import java.util.List;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.FaOverViewChartData;
import com.lenovo.bi.dto.sc.GeoFA;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.view.sc.fa.FADetailView;

public interface FaComponentDao {
	
	public List<FaOverViewChartData> fetchFaComponentOverViewChartData(SearchFaForm form);
	
	public List<KeyNameObject> fetchDimensions(SearchFaForm form);
	
	public List<ScRemarkChartData> fetchFaComponentRemarkChartData(SearchFaForm form);
	public List<ScRemarkChartData> fetchFaComponentCrossMonthRemarkChartData(SearchFaForm form);
	public List<ScRemarkChartData> fetchFaComponentDashboardRemarkChartData(SearchFaForm form);
	
	public List<FaOverViewChartData> fetchFaDashboardOverViewChartData(SearchFaForm form);

	public List<FaOverViewChartData> fetchFaCrossMonthOverviewChartData(SearchFaForm form);
	public List<FaOverViewChartData> getcomponentFaPieChart(SearchFaForm form);
	public List<FaOverViewChartData> getcomponentFaDashboardPieChart(SearchFaForm form);
	public List<FaOverViewChartData> getcomponentFaCrossmonthPieChart(SearchFaForm form);
	
	public List<String> getLackProduct(SearchFaForm form, int target);
	
	public List<String> getLackRegion(SearchFaForm form, int target);
	
	public List<FADetailView> getComponentFaDetail(SearchFaForm form);
	public List<FADetailView> getComponentFaGEODetail(SearchFaForm form);
	public List<FADetailView> getComponentFaPieDetail(SearchFaForm form);
	
	public long getComponentFaDetailCount(SearchFaForm form);
	public long getComponentFaDashboardDetailCount(SearchFaForm form);
	public long getComponentFaGEODetailCount(SearchFaForm form);
	
	public List<FADetailView> getComponentFADetailExport(SearchFaForm form);
	public List<FADetailView> getComponentFAGEODetailExport(SearchFaForm form);
	
	public List<GeoFA> getGeoFa(SearchFaForm form);
}
