package com.lenovo.bi.service.common.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.springframework.stereotype.Component;

import com.lenovo.bi.dao.common.ConfigurablesDao;
import com.lenovo.bi.dao.common.MasterDataDao;
import com.lenovo.bi.dto.GeoData;
import com.lenovo.bi.model.system.Configurables;
import com.lenovo.bi.service.common.MasterDataService;

/**
 * 
 * 
 * @author henry_lian
 *
 */
@Component
public class MasterDataServiceImpl implements MasterDataService {

	private Set<String> orderTypeMap;
	private Map<String, Set<String>> geoRegionFullMap;
	private Set<String> regionMap;
	private Map<String, Float> threshold;
	
	@Inject
	private MasterDataDao masterDataDao;
	@Inject
	private ConfigurablesDao configurablesDao;
	
	@PostConstruct
	public synchronized void intialMap(){
		orderTypeMap = new HashSet<String>();
		List<String> orderTypeList =  masterDataDao.getOrderType();
		for(String orderType: orderTypeList){
			orderTypeMap.add(orderType);
		}
		
		geoRegionFullMap = new HashMap<String, Set<String>>();
		regionMap = new HashSet<String>();
		List<GeoData> geoList = masterDataDao.getRegions();
		for(GeoData gd:geoList){
			String parent = gd.getParentGeo();
			Set<String> regions = null;
			if (geoRegionFullMap.get(parent) == null){
				regions = new HashSet<String>();
				geoRegionFullMap.put(parent, regions);
			} else{
				regions = geoRegionFullMap.get(parent);
			}
			regions.add(gd.getGeographyName());
			//might as well put region into set
			regionMap.add(gd.getGeographyName());
		}
		threshold = new HashMap<String, Float>();
		List<Configurables> configurables = configurablesDao.getConfiguables();
		for(Configurables c: configurables){
			threshold.put(c.getName(), c.getValue());
		}
		
	}
	@Override
	public void refreshMaps() {
		intialMap();
	}
	
	@Override
	public Set<String> getRegions() {
		return regionMap;
	}

	@Override
	public Set<String> getGeos() {
		return geoRegionFullMap.keySet();
	}

	@Override
	public Set<String> getRegionsByGeos(String geo) {
		return geoRegionFullMap.get(geo);
	}

	@Override
	public Set<String> getOrderTypes() {
		return orderTypeMap;
	}

	@Override
	public Float getThresholdByName(String name) {
		return threshold.get(name);
	}
}
