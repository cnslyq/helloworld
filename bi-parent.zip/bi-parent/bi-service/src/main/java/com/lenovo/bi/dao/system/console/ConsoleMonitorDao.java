package com.lenovo.bi.dao.system.console;

import java.util.List;

import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.view.system.console.FailedJobDetailView;
import com.lenovo.common.model.PagerInformation;

public interface ConsoleMonitorDao{

	public List<FailedJobDetailView> listFailedJobs(DictSearchForm form, PagerInformation pagerInfo);
	
	public int getFailedJobDetailCountByConditions(DictSearchForm form);
	
	public List<FailedJobDetailView> listFailedJobs(String startDate);
}
