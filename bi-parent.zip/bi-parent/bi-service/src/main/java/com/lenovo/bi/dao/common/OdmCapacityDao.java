package com.lenovo.bi.dao.common;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.OdmCapacityPlan;
import com.lenovo.bi.dto.OdmCapacityPlanDetail;
import com.lenovo.bi.dto.OdmCommitDto;
import com.lenovo.bi.dto.TdmsDefect;
import com.lenovo.bi.dto.TdmsDefectDetail;
/**
 * 
 * 
 * @author henry_lian  ying_han
 *
 */
public interface OdmCapacityDao {

	public List<OdmCapacityPlan> getOdmNpiCapacityPlanForTargetDate(int pmsWaveId, Date targetDate, Date versionDate);
	
	public List<OdmCapacityPlanDetail> getDetailCapacityPlanByTargetDate(int pmsWaveId, Date targetDate, Date versionDate);

	public List<TdmsDefect> getTdmsDefectsForTargetDate(int pmsWaveId, Date targetDate, Date versionDate);
	
	public List<OdmCapacityPlanDetail> getOdmItems(int pmsWaveId, String versionDate, String startDate,String endDate);
	
	public List<TdmsDefectDetail> getDefectItems(String pmsWaveId, Date versionDate);
	
	//public List<OdmCommitDto> getOdmCommit(Date versionDate, Date targetDate, Date dnsVersionDate);
	public List<OdmCommitDto> getOdmCommit(Date versionDate, Integer pmsWaveId, Date dnsVersionDate);
}
