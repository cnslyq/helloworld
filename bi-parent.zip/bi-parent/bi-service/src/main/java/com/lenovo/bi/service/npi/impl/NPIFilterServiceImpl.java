package com.lenovo.bi.service.npi.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lenovo.bi.dao.npi.NPIFilterDao;
import com.lenovo.bi.dao.npi.NPIOverviewDao;
import com.lenovo.bi.dto.ProductDataForPopup;
import com.lenovo.bi.enumobj.PermissionScope;
import com.lenovo.bi.form.npi.SearchProductsFormForPopUp;
import com.lenovo.bi.model.NPIFilter;
import com.lenovo.bi.model.NPIFilterDetail;
import com.lenovo.bi.service.npi.NPIFilterService;

@Service
public class NPIFilterServiceImpl implements NPIFilterService{
	@Inject
	private NPIFilterDao npiFilterDao;
	@Inject
	private NPIOverviewDao nPIOverviewDao;
	
	@Override
	public List<NPIFilter> getNPIFilter(String userId, String phase,
			String scope) {
		return npiFilterDao.getNPIFilter(userId, phase, scope, null);
	}
	@Override
	public List<ProductDataForPopup> getNPIFilterDetailByFilterId(String filterId) {
		List<Integer> waveIds = npiFilterDao.getNPIFilterWaveIdsByFilterId(filterId);
		if(CollectionUtils.isNotEmpty(waveIds)){
			SearchProductsFormForPopUp form = new SearchProductsFormForPopUp();
			form.setWaveIds(waveIds);
			form.setScope(PermissionScope.all);
			List<ProductDataForPopup> basePopUpViews = nPIOverviewDao.getPopupGridDataByConditions(form);
			return basePopUpViews;
		}
		return null;
	}
	@Override
	public List<NPIFilter> getNPIFilterByFilterId(String userId, String phase,
			String scope, String filterId) {
		return npiFilterDao.getNPIFilter(userId, phase, scope, filterId);
	}
	@Override
	@Transactional("bi")
	public int deleteFilter(String filterId) {
		int deleteCount = npiFilterDao.deleteFilterByFilterId(filterId);
		npiFilterDao.deleteFilterDetailByParentId(filterId);
		return deleteCount;
	}
	@Override
	@Transactional("bi")
	public String saveFilter(NPIFilter npiFilter, List<Integer> waveIds) {
		String filterId = npiFilter.getId();
		if(StringUtils.isBlank(filterId) && npiFilter.getIsLastUsedFilter()){
			filterId = npiFilterDao.getLastUsedFilterID(npiFilter.getUserID(),npiFilter.getPhase(),npiFilter.getScope());
			npiFilter.setId(filterId);
		}
		Date lastModifyDate = new Date();
		npiFilter.setLastModifiedDate(lastModifyDate);
		if(StringUtils.isNotBlank(filterId)){
			npiFilterDao.updateFilter(npiFilter);
			npiFilterDao.deleteFilterDetailByParentId(filterId);
		}else{
			UUID uuid = UUID.randomUUID();
			filterId = uuid.toString();
			npiFilter.setId(filterId);
			npiFilter.setCreateDate(lastModifyDate);
			npiFilterDao.saveFilter(npiFilter);
		}
		
		if(CollectionUtils.isNotEmpty(waveIds)){
			NPIFilterDetail npiFilterDetail = null;
			for(Integer waveId : waveIds){
				npiFilterDetail = new NPIFilterDetail();
				npiFilterDetail.setParentId(filterId);
				npiFilterDetail.setNpiWaveId(waveId);
				npiFilterDao.saveFilterDetail(npiFilterDetail);
			}
		}
		return filterId;
	}
	@Override
	public String saveLastUsedFilter(String scope, String phase,
			List<Integer> waveIds, Date durationFrom, Date durationTo, String userId) {
		NPIFilter npiFilter = new NPIFilter();
		npiFilter.setFilterName("Last Used Filter");
		npiFilter.setScope(scope.toUpperCase());
		npiFilter.setPhase(phase.toUpperCase());
		npiFilter.setDurationFrom(durationFrom);
		npiFilter.setDurationTo(durationTo);
		npiFilter.setUserID(userId);
		npiFilter.setIsLastUsedFilter(true);
		
		return this.saveFilter(npiFilter, waveIds);
	}

}
