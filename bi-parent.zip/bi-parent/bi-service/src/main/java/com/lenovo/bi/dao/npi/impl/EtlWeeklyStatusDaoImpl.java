package com.lenovo.bi.dao.npi.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.model.EtlWeeklyStatus;

@Repository
public class EtlWeeklyStatusDaoImpl extends HibernateBaseDaoImplBi<EtlWeeklyStatus>{
	public EtlWeeklyStatus getLatestEtlWeeklyStatus() {
		// Give it one more day for processing.  We get the latest one.
		//StringBuffer hql = new StringBuffer("from EtlWeeklyStatus where datediff(day, processDate, getdate()) <= 1 order by processDate desc");
		StringBuffer hql = new StringBuffer("from EtlWeeklyStatus order by processDate desc");
		List<EtlWeeklyStatus> list = list(hql.toString());
		
		if (list.size() > 0) {
			EtlWeeklyStatus status = list.get(0);  // Get the object with the latest processDate 
			getSession().refresh(status);
			return status;
		}
		
		return null;
	}
}
