package com.lenovo.bi.batch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationAwareOrderComparator;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dto.NPIWaveInfo;
import com.lenovo.bi.engine.SgaTTVKPIProcessor;
import com.lenovo.bi.engine.TTMKPIProcessor;
import com.lenovo.bi.engine.TTVKPIProcessor;
import com.lenovo.bi.enumobj.KPILights;
import com.lenovo.bi.enumobj.Status;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.model.SGATtvWeeklySummary;
import com.lenovo.bi.model.TtvWeeklySummary;
import com.lenovo.bi.service.npi.helper.NPIDOIHelper;
import com.lenovo.bi.service.npi.helper.NPIWaveSummaryHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceBiHelper;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.CalendarUtil;

@Service
public class NpiWaveSummaryBatch{
	
	@Autowired
	private NPIWaveSummaryHelper nPIWaveSummaryHelper;
	@Autowired
	private NPIDOIHelper nPIDOIHelper;
	@Autowired
	private TTVOutlookServiceBiHelper biHelper;
	@Autowired
	private List<TTMKPIProcessor> ttmProcessors;
	@Autowired
	private List<TTVKPIProcessor> ttvProcessors;
	@Autowired
	private List<SgaTTVKPIProcessor> sgaTtvProcessors;
	@Autowired
	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	
	@PostConstruct
	public void init() {
	    Collections.sort(ttmProcessors, AnnotationAwareOrderComparator.INSTANCE);
	    Collections.sort(ttvProcessors, AnnotationAwareOrderComparator.INSTANCE);
	    Collections.sort(sgaTtvProcessors, AnnotationAwareOrderComparator.INSTANCE);
	}
	
	public void runBatch(Date versionDate) {
		//extract data
		List<NPIWaveInfo> projects = nPIWaveSummaryHelper.getProjectSummaryByDate(versionDate);
		
		List<ProjectSummary> prevSummary = nPIWaveSummaryHelper.getPrevSummary(versionDate);
		
		Map<Integer, ProjectSummary> prevOnGoingList = new HashMap<Integer, ProjectSummary>();
		List<Integer> closedProjects = new ArrayList<Integer>();
		for(ProjectSummary ps: prevSummary){
			if(isProjectClosed(ps)){
				closedProjects.add(ps.getPmsWaveId());
			} else{
				prevOnGoingList.put(ps.getPmsWaveId(), ps);
			}
		}
		
		List<String> status = new ArrayList<String>();
		status.add(Status.Success.name());
		
		//NPI CR
		//status.add(Status.Fail.name());
		
		List<ProjectSummary> list = new ArrayList<ProjectSummary>();
		for(NPIWaveInfo wave: projects){
			//we don't process it if the project has been closed
			if(closedProjects.contains(wave.getPmsWaveId())){
				continue;
			}
			//transform data
			/**ttvSignOffDate
			 * ttvTargetDate
			 * ttvTarget
			 * 
			 * sgaTtvSignOffDate
			 * sgaTtvTargetDate
			 * sgaTtvTarget
			 * */
			ProjectSummary ps = transformDetails(wave, versionDate);
			
			//process ttm
			//success project won't be re-calculated except TTM KPI
			//NPI CR
			if(prevOnGoingList.get(ps.getPmsWaveId()) != null && status.contains(prevOnGoingList.get(ps.getPmsWaveId()).getTtmStatus())&&prevOnGoingList.get(ps.getPmsWaveId()).getTtmSignOffDate()!=null){
				ProjectSummary projectSummary = prevOnGoingList.get(wave.getPmsWaveId());
				ps.setTtmStatus(projectSummary.getTtmStatus());
				ps.setTTMRisk(projectSummary.isTTMRisk());
				ps.setTtmDelays(projectSummary.getTtmDelays());
				//re-calculate TTM KPI for success project start
				/*
				ps.setDefects(projectSummary.getDefects());
				ps.setDoi(projectSummary.getDoi());
				ps.setOdm(projectSummary.getOdm());
				ps.setTooling(projectSummary.getTooling());
				ps.setFpy(projectSummary.getFpy());
				ps.setObe(projectSummary.getObe());
				*/
				calcTTMKPI(ps, versionDate);
				//re-calculate TTM KPI for success project end
				ps.setTtmTargetDateDemand(projectSummary.getTtmTargetDateDemand());
			} else{
				//get TTM demand
				if(ps.getTtmTargetDate() != null){
					//set -8 version forecast as demand start
					//ps.setTtmTargetDateDemand(nPIDOIHelper.getTTMTargetDemandByWaveId(ps.getPmsWaveId()));
					Map<Date, Integer> forecastMap = ttvOutlookServiceDwHelper.getSGAForecastByWaveId(ps.getPmsWaveId());
					Date ttmTargetDate = CalendarUtil.getMondayDateByDate(ps.getTtmTargetDate());
					if(null == forecastMap.get(ttmTargetDate)){
						ps.setTtmTargetDateDemand(0);
					}else{
						ps.setTtmTargetDateDemand(forecastMap.get(ttmTargetDate));
					}
					//set -8 version forecast as demand end
				}
				calcTTM(ps, versionDate);
			}
			
			//process sga
			 /** sgaStatus
			 * sgaRisk
			 * sgaActualTTV
			 * sgaEstimatedTTV
			 * */
			//NPI CR
			if(prevOnGoingList.get(ps.getPmsWaveId()) != null && status.contains(prevOnGoingList.get(ps.getPmsWaveId()).getSgaTtvStatus())&&prevOnGoingList.get(ps.getPmsWaveId()).getSgaTtvSignOffDate()!= null){
				ProjectSummary projectSummary = prevOnGoingList.get(wave.getPmsWaveId());
				ps.setSgaTtvStatus(projectSummary.getSgaTtvStatus());
				ps.setIsSgaTtvRisk(projectSummary.getIsSgaTtvRisk());
				ps.setSgaActualTTV(projectSummary.getSgaActualTTV());
				ps.setSgaEstimatedTTV(projectSummary.getSgaEstimatedTTV());
//				ps.setActualTTV(projectSummary.getActualTTV());
			} else{
				 /**
				  * sgaActualTTV
				  *sgaEstimatedTTV
				 **/
				if(ps.getSgaTtvSignOffDate() == null){
					Date sgaTtvTargetDate;
					if(ps.getSgaTtvTargetDate() != null){
						sgaTtvTargetDate = CalendarUtil.getMondayDateByDate(ps.getSgaTtvTargetDate());
					}else{
						sgaTtvTargetDate = versionDate;
					}
					List<SGATtvWeeklySummary> summaryOnSGA = biHelper.getSgaNpiWeeklySummary(ps.getPmsWaveId(), sgaTtvTargetDate, sgaTtvTargetDate, versionDate);
					if(summaryOnSGA != null && !summaryOnSGA.isEmpty()){
						ps.setSgaEstimatedTTV(summaryOnSGA.get(0).getTtvOdm());
					} else{
						//hope this never happens
						//ps.setSgaEstimatedTTV(0f);
						ps.setSgaEstimatedTTV(-1f);
					}
						
				} /*else if(ps.getSgaTtvSignOffDate().equals(versionDate)){
					List<SGATtvWeeklySummary> summary = biHelper.getSgaNpiWeeklySummary(ps.getPmsWaveId(), versionDate, versionDate, versionDate);
					if(summary != null && !summary.isEmpty()){
						ps.setSgaActualTTV(summary.get(0).getTtvOdm());
					} else{
						//hope this never happens
						ps.setSgaActualTTV(0f);
					}
				}*/
				
				calcSgaTTV(ps, versionDate);
				
			}
			
			//process sle
			// last stage of calculation, always calculate the ttv and status
			/**status
			 * risk
			 * actualTTV
			 * estimatedTTV
			 */
//			if(prevOnGoingList.get(ps.getPmsWaveId()) != null && status.contains(prevOnGoingList.get(ps.getPmsWaveId()).getTtvStatus())){
//				ProjectSummary projectSummary = prevOnGoingList.get(wave.getPmsWaveId());
//				ps.setTtvStatus(projectSummary.getTtvStatus());
//				ps.setTTVRisk(projectSummary.isTTVRisk());
//				ps.setActualTTV(projectSummary.getActualTTV());
//				ps.setEstimatedTTV(projectSummary.getEstimatedTTV());
				
//			} else{
				/**actualTTV
				 * estimatedTTV
				 * */
				if(ps.getTtvSignOffDate() == null){
					Date ttvTargetDate;
					if(ps.getTtvTargetDate() != null){
						ttvTargetDate = CalendarUtil.getMondayDateByDate(ps.getTtvTargetDate());
					}else{
						ttvTargetDate = versionDate;
					}
					List<TtvWeeklySummary> summaryOnSLE = biHelper.getNpiWeeklySummary(ps.getPmsWaveId(), ttvTargetDate, ttvTargetDate, versionDate);
					if(summaryOnSLE != null && !summaryOnSLE.isEmpty()){
						ps.setEstimatedTTV(summaryOnSLE.get(0).getTtvOdm());
					} else{
						//hope this never happens
						ps.setEstimatedTTV(0f);
					}
						
				} else {
					if(ps.getTtvSignOffDate().before(ps.getTtvTargetDate())){
						Date ttvSignedOffDate = CalendarUtil.getMondayDateByDate(ps.getTtvSignOffDate());
						List<TtvWeeklySummary> summary = biHelper.getNpiWeeklySummary(ps.getPmsWaveId(), ttvSignedOffDate, ttvSignedOffDate, ttvSignedOffDate);
						if(summary != null && !summary.isEmpty()){
							ps.setActualTTV(summary.get(0).getTtvOdm());
						} else{
							//hope this never happens
							ps.setActualTTV(0f);
						}
					} else{
						Date ttvTargetDate = CalendarUtil.getMondayDateByDate(ps.getTtvTargetDate());
						Date ttvSignedOffDate = CalendarUtil.getMondayDateByDate(ps.getTtvSignOffDate());
						List<TtvWeeklySummary> summary = biHelper.getNpiWeeklySummary(ps.getPmsWaveId(), ttvTargetDate, ttvTargetDate, ttvSignedOffDate);
						if (CollectionUtils.isEmpty(summary)) {
							ps.setActualTTV(0f);
						} else{
							float actulaTTV = summary.get(0).getTtvOdm();
							ps.setActualTTV(actulaTTV);
						}	
					}
					
				}
				
				calcTTV(ps, versionDate);
//			}
			
			list.add(ps);
		}
		//persist data
		nPIWaveSummaryHelper.saveProjectSummaries(list, versionDate);

	}

	private boolean isProjectClosed(ProjectSummary ps) {
		boolean isClosed = true;
		List<String> status = new ArrayList<String>();
		status.add(Status.In_Progress.name());
		status.add(Status.NA.name());
		//NPI CR
		status.add(Status.Fail.name());
		if(status.contains(ps.getTtmStatus())){
			isClosed = false;
		}
		if(status.contains(ps.getTtvStatus())){
			isClosed = false;
		}
		if(status.contains(ps.getSgaTtvStatus())){
			isClosed = false;
		}
		
		return isClosed;
	}

	private void calcTTV(ProjectSummary ps, Date versionDate) {
		for(TTVKPIProcessor nkp:ttvProcessors){
			nkp.process(ps, versionDate);
		}
	}
	private void calcSgaTTV(ProjectSummary ps, Date versionDate) {
		for(SgaTTVKPIProcessor nkp:sgaTtvProcessors){
			nkp.process(ps, versionDate);
		}
	}
	private void calcTTM(ProjectSummary ps, Date versionDate) {
		//TTM KPI LIGHTS calculation
		for(TTMKPIProcessor nkp:ttmProcessors){
			nkp.process(ps, versionDate);
		}
		//Project status
		if(ps.getTtmStatus().equals(Status.Success.name())){
			ps.setTtmDelays(Days.daysBetween(new DateTime(ps.getTtmTargetDate()), new DateTime(ps.getTtmSignOffDate())).getDays());
		}
		if(!ps.getTtmStatus().equals(Status.NA.name())&& ps.getDefects().equals(KPILights.GREEN.name())
				&& ps.getDoi().equals(KPILights.GREEN.name())
				&& ps.getOdm().equals(KPILights.GREEN.name())
				&& ps.getTooling().equals(KPILights.GREEN.name())
				&& ps.getFpy().equals(KPILights.GREEN.name())
				&& ps.getObe().equals(KPILights.GREEN.name())){
			ps.setTTMRisk(false);
		} else{
			ps.setTTMRisk(true);
		}
		//is project planned
		if(ps.getPhaseNumber() == null){
			ps.setProjectPlanned(false);
		} else{
			ps.setProjectPlanned(true);
		}
		
	}
	private void calcTTMKPI(ProjectSummary ps, Date versionDate) {
		//TTM KPI LIGHTS calculation
		for(TTMKPIProcessor nkp:ttmProcessors){
			nkp.process(ps, versionDate);
		}
	}

	private ProjectSummary transformDetails(NPIWaveInfo wave, Date versionDate) {
		
		ProjectSummary ps = new ProjectSummary();
		ps.setPmsWaveId(wave.getPmsWaveId());
		ps.setPmsProjectId(wave.getPmsProjectId());
		ps.setStartDate(wave.getStartDate());
		ps.setProductName(wave.getProductName());
		ps.setWaveName(wave.getWaveName());
		ps.setTtmTargetDate(wave.getTtmTargetDate());
		ps.setTtmSignOffDate(wave.getTtmSignOffDate());
		ps.setTtvTargetDate(wave.getTtvTargetDate());
		ps.setSgaTtvTargetDate(wave.getSgaTtvTargetDate());//add by nicolas on July 4,2014: for sga ttv target date
		ps.setSgaTtvSignOffDate(wave.getSgaTtvSignOffDate());
		ps.setTtvSignOffDate(wave.getTtvSignOffDate());
		ps.setTtvTarget(wave.getTtvTarget());
		ps.setSgaTtvTarget(wave.getSgaTtvTarget());
		ps.setFamily(wave.getFamily());
		ps.setPm(wave.getPm());
		ps.setSvtPlanDate(wave.getSvtPlanDate());
		ps.setSovpPlanDate(wave.getSovpPlanDate());
		ps.setPhaseNumber(wave.getPhaseNumber());
		ps.setCurrentPhase(wave.getCurrentPhase());
		ps.setObeTarget(wave.getObeTarget());
		ps.setFpyTarget(wave.getFpyTarget());
		ps.setEndDate(wave.getEndDate());
		//timestamp
		ps.setVersionDate(versionDate);
		return ps;
	}


}
