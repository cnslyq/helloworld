package com.lenovo.bi.view.npi.ttm;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * 
 * @author henry_lian
 *
 */
public class ToolingCapacityGrid {
	
	private String weekDate;
	private List<ToolingCovers> covers = new ArrayList<ToolingCovers>();
	public String getWeekDate() {
		return weekDate;
	}
	public void setWeekDate(String weekDate) {
		this.weekDate = weekDate;
	}
	public List<ToolingCovers> getCovers() {
		return covers;
	}
	public void setCovers(List<ToolingCovers> covers) {
		this.covers = covers;
	}
	
}
