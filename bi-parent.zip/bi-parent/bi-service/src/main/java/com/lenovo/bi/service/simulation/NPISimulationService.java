package com.lenovo.bi.service.simulation;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.lenovo.bi.form.simulation.NPISimulationForm;
import com.lenovo.bi.form.simulation.NPISimulationPreviewData;
import com.lenovo.bi.form.simulation.PreviewOutlookDataForm;
import com.lenovo.bi.form.simulation.SearchNPISimulationForm;
import com.lenovo.bi.form.simulation.SearchNPISimulationHistoryForm;
import com.lenovo.bi.model.NPISimulationDetail;
import com.lenovo.bi.model.NPISimulationSummary;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;
import com.lenovo.bi.view.simulation.NPISimulationItemsView;
import com.lenovo.bi.view.simulation.NPISimulationSummaryView;
import com.lenovo.bi.view.simulation.ODMView;
import com.lenovo.common.model.Pager;

public interface NPISimulationService {
	/**
	 * use to Private Simulation,Public Simulation,Select TTV Simulation
	 */
	//query npi simulation 
	public List<NPISimulationSummaryView> getNPISimulationSummaryByCondition(SearchNPISimulationForm form,Pager<NPISimulationSummaryView>pager);
	/**
	 * use to Private Simulation 
	 */
	//batch delete npi simulation 
	public void deleteNPISimulation(Integer[]ids);
	/**
	 * use to Create TTV Simulation 
	 */
	//add or update npi simulation summary
	public void saveNPISimulationSummary(NPISimulationForm simulation);
	
	/**
	 * use to TTV Simulation History List
	 */
	//query npi simulation history 
	public List<NPISimulationDetail> getNPISimulationHistoryByCondition(SearchNPISimulationHistoryForm form);
	/**
	 * use to TTV Simulation
	 */
	public NPISimulationSummaryView getNPISimulationSummaryById(String id);
	//query all npi simulation items grid from dw and bi
	public NPISimulationItemsView getNPISimulationItemsGrid(NPISimulationForm simulation) throws ParseException;
	//preview outlook chart data
	public MSColumnChartView previewOutlookJsonChartData(PreviewOutlookDataForm form);
	
	public void saveBatchNPISimulationDetail(List<NPISimulationDetail> list);
	//save as npi simulation and detail(all history)
	public Integer saveAsNPISimulation(NPISimulationForm simulation);
	//for split page
	public int getTotalCountNPISimulationSummaryByCondition(SearchNPISimulationForm form);
	//get createdBy select
	public List<String> getCreatedBy();
	
	public NPISimulationSummary loadNPISimulationSummaryById(String id);
	
	public void calculateSupplyCommitment(Date versionDate,Date startDate,Date endDate,String waveId,String ttvPhase,List<NPISimulationPreviewData> perviewDataList);
	
	public void getUseRPY(ODMView odmView,NPISimulationDetail odmDetails);
}
