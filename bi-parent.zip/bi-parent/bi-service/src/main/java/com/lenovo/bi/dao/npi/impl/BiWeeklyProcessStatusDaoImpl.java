package com.lenovo.bi.dao.npi.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.enumobj.JobStatusEnum;
import com.lenovo.bi.model.BiWeeklyProcessStatus;

@Repository
public class BiWeeklyProcessStatusDaoImpl extends HibernateBaseDaoImplBi<BiWeeklyProcessStatus> {
	public JobStatusEnum getBiWeeklyProcessStatus() {
		// Get the latest one within today and yesterday
		StringBuffer hql = new StringBuffer("from BiWeeklyProcessStatus where datediff(day, processDate, getdate()) <= 1 order by processDate desc");
		List<BiWeeklyProcessStatus> list = list(hql.toString());
		
		if (list.size() > 0) {
			BiWeeklyProcessStatus status = list.get(0);  // Get the object with the latest processDate 
			getSession().refresh(status);
			return status.getJobStatus();
		}
		
		return JobStatusEnum.COMPLETE;
	}
}
