package com.lenovo.bi.dao.npi;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.NpiOrder;

public interface NpiOrderDaoBi {

	public List<NpiOrder> getTTVExcludedOrder(int pmsWaveId, TTVPhase ttvPhase, Date versionDate);

	public List<NpiOrder> getTTVAllExcludedOrders(TTVPhase ttvPhase, Date versionDate);

	public void updateExcludeOrder(List<NpiOrder> orders, Integer waveId, Date versionDate,TTVPhase ttvPhase);

	public List<NpiOrder> getNpiOrderByWaveId(int waveId);
	
	public List<NpiOrder> getNpiOrderByWaveId(int waveId, Date versionDate, TTVPhase ttvPhase);

	public List<NpiOrder> getNegativeNpiOrderByWaveId(int waveId, Date versionDate, TTVPhase ttvPhase);
	
	public List<NpiOrder> getTTVExcludedOrderInWeek(Date targetDate, Date versionDate, TTVPhase ttvPhase);
	
	public List<NpiOrder> getAllExcludedOrdersByNpiOrderIds(List<Integer> npiOrderIds);

}
