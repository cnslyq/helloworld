package com.lenovo.bi.service.sc.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.sc.BPSDao;
import com.lenovo.bi.dto.BpsCrossMonth;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.enumobj.BPSStatusEnum;
import com.lenovo.bi.enumobj.KPILights;
import com.lenovo.bi.form.sc.bps.SearchBpsForm;
import com.lenovo.bi.service.sc.BPSService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.ListSortUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.DataSetLine;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.npi.chart.common.MonthAndDayCategory;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.chart.pie.PieSlice;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;
import com.lenovo.bi.view.sc.bps.BPSDetailView;
import com.lenovo.bi.view.sc.bps.FactDetailView;

@Service
public class BPSServiceImpl implements BPSService {

	@Inject
	private BPSDao bpsDao;

	/*
	 * (non-Javadoc)
	 * @see com.lenovo.bi.service.sc.BPSService#getOverviewChart(com.lenovo.bi.form.sc.bps.SearchBpsForm)
	 * 
	 * draw overView
	 */
	@Override
	public ColumnChartView getOverviewChart(SearchBpsForm form) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();
		// Chart
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setsYAxisMinValue("0");
		columnChartView.getChartInfo().setsYAxisMaxValue("100");
		columnChartView.getChartInfo().setNumdivlines("9");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("160");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setShowBorder("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setPlotSpacePercent("70");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setShowValues("0");
		

		// Categories
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		String startDate = form.getStartDate().substring(0, 7);
		
		//day
		if(!form.isShowMonthOverview()) {
			for(int i=0; i<SysConfig.NUMBER_OF_FUTURE_WEEKS1; i++) {
				String date = CalendarUtil.getDateByDays1(form.getStartDate(), i);
				if (form.getEndDate()!=null && date.compareTo(form.getEndDate()) > 0) 
					break;
				MonthAndDayCategory category = new MonthAndDayCategory();
				category.setName(date);
				categoryList.add(category);
			}
		}
		//month
		else {
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
				if (form.getDurationTo()!=null && yearMonth.compareTo(form.getDurationTo()) > 0) 
					break;
				MonthAndDayCategory category = new MonthAndDayCategory();
				category.setName(yearMonth);
				categoryList.add(category);
			}
		}
		
		List<ColumnData> bpsColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> unshippedCloumnDataList = new ArrayList<ColumnData>();
		ColumnData bpsColumnData = null;
		ColumnData unshippedColumnData = null;
		
		//day
		if (form.getFrequency().equals("Day")) {
			
			Calendar calendar = Calendar.getInstance();
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date startDay = format.parse(form.getStartDate());
			calendar.setTime(startDay);
			
			LinkedHashMap<Object,List<ScOverViewChartData>> bpsOverviewMap = null;
			bpsOverviewMap = fetchbpsOverViewChartData(form);
			
			for(Map.Entry<Object, List<ScOverViewChartData>> entry : bpsOverviewMap.entrySet()) {
				String name = ((KeyNameObject)entry.getKey()).getObjName();
				int key = -1;
				
				bpsColumnData = new ColumnData();
				setBPSOverviewColumnLink(bpsColumnData,name,key);
				bpsColumnData.setValue(0);
				
				unshippedColumnData = new ColumnData();
				setBPSOverviewColumnLink(unshippedColumnData,name,key);
				unshippedColumnData.setValue(0);
				
				List<ScOverViewChartData> chartDataList = entry.getValue();
				StringBuffer valueBuffer = new StringBuffer("[{");
				
				for(ScOverViewChartData bpsOverViewChartData : chartDataList) {
					if(bpsOverViewChartData.getScStatusName().equals(BPSStatusEnum.BPS.getTypeName())) {
						setBPSOverviewColumnLink(bpsColumnData,name,key);
						bpsColumnData.setValue(bpsOverViewChartData.getOrderNum());
						valueBuffer.append("bps:");
					}
					else if(bpsOverViewChartData.getScStatusName().equals(BPSStatusEnum.Unshipped.getTypeName())) {
						setBPSOverviewColumnLink(unshippedColumnData,name,key);
						unshippedColumnData.setValue(bpsOverViewChartData.getOrderNum());
						valueBuffer.append("Unshipped:");
					}
				}
				bpsColumnDataList.add(bpsColumnData);
				unshippedCloumnDataList.add(unshippedColumnData);
			}
			form.setEndDate(format.format(calendar.getTime()));
		}
		
		//month-----------------------------------------------------------------
		else {
			Calendar calendar = Calendar.getInstance();
			DateFormat format = new SimpleDateFormat("yyyy-MM");
			Date startDay = format.parse(form.getStartDate());
			calendar.setTime(startDay);
			
			LinkedHashMap<Object,List<ScOverViewChartData>> bpsOverviewMap = null;
			bpsOverviewMap = fetchbpsOverViewChartData(form);
			
			//int i = 0;
			for(Map.Entry<Object, List<ScOverViewChartData>> entry : bpsOverviewMap.entrySet()) {
				String name = ((KeyNameObject)entry.getKey()).getObjName();
				int key = -1;
				
				bpsColumnData = new ColumnData();
				setBPSOverviewColumnLink(bpsColumnData,name,key);
				bpsColumnData.setValue(0);
				
				unshippedColumnData = new ColumnData();
				setBPSOverviewColumnLink(unshippedColumnData,name,key);
				unshippedColumnData.setValue(0);
				
				List<ScOverViewChartData> chartDataList = entry.getValue();
				StringBuffer valueBuffer = new StringBuffer("[{");
				
				for(ScOverViewChartData bpsOverViewChartData : chartDataList) {
					if(bpsOverViewChartData.getScStatusName().equals(BPSStatusEnum.BPS.getTypeName())) {
						setBPSOverviewColumnLink(bpsColumnData,name,key);
						bpsColumnData.setValue(bpsOverViewChartData.getOrderNum());
						valueBuffer.append("bps:");
					}
					else if(bpsOverViewChartData.getScStatusName().equals(BPSStatusEnum.Unshipped.getTypeName())) {
						setBPSOverviewColumnLink(unshippedColumnData,name,key);
						unshippedColumnData.setValue(bpsOverViewChartData.getOrderNum());
						valueBuffer.append("Unshipped:");
					}
				}
				
				bpsColumnDataList.add(bpsColumnData);
				unshippedCloumnDataList.add(unshippedColumnData);
			}
			form.setEndDate(format.format(calendar.getTime()));
		}

		// Dataset
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();

		// BPS
		DataSetColumn bpsDataSet = new DataSetColumn();
		bpsDataSet.setSeriesName("BPS");
		bpsDataSet.setColor("#FF0000");

		bpsDataSet.setDataList(bpsColumnDataList);
		dataSetList.add(bpsDataSet);

		// Unshipped Backlog
		DataSetColumn unshippedDataSet = new DataSetColumn();
		unshippedDataSet.setSeriesName("Unshipped Backlog");
		unshippedDataSet.setColor("#F8CBAD");

		unshippedDataSet.setDataList(unshippedCloumnDataList);
		dataSetList.add(unshippedDataSet);

		// BPS Rate
		DataSetLine bpsRateDataSet = new DataSetLine();
		bpsRateDataSet.setParentYaxis("S");
		bpsRateDataSet.setSeriesName("BPS Rate");
		bpsRateDataSet.setRenderas("Line");
		bpsRateDataSet.setColor("#3333FF");
		List<ColumnData> bpsRateCloumnDataList = new ArrayList<ColumnData>();
		ColumnData bpsRateCloumnData = null;
		BigDecimal bpsOrder = null;
		BigDecimal unshippedOrder = null;
		BigDecimal bpsRate = null;

		// Target
		DataSetLine targetDataSet = new DataSetLine();
		//targetDataSet.setParentYaxis("S");
		targetDataSet.setSeriesName("Target");
		targetDataSet.setRenderas("Line");
		targetDataSet.setColor("#BF9000");
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		ColumnData targetCloumnData = new ColumnData();

		StringBuffer values = null;
		for (int i = 0; i < bpsColumnDataList.size(); i++) {
			bpsOrder = new BigDecimal(bpsColumnDataList.get(i).getValue().floatValue());
			unshippedOrder = new BigDecimal(unshippedCloumnDataList.get(i).getValue().floatValue());
			if (bpsOrder.compareTo(BigDecimal.ZERO) == 0) {
				bpsRate = BigDecimal.ZERO;
			}else {
				if(unshippedOrder.compareTo(BigDecimal.ZERO) == 0){
					bpsRate = BigDecimal.ONE.multiply(new BigDecimal("100"));
				}else{
					bpsRate = bpsOrder.divide(unshippedOrder, 2, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal("100"));
				}
			}
			bpsRateCloumnData = new ColumnData();
			bpsRateCloumnData.setValue(bpsRate.floatValue() > 100 ? 100 : bpsRate.floatValue());
			bpsRateCloumnData.setColor("#3333FF");
			bpsRateCloumnDataList.add(bpsRateCloumnData);
			//TODO 
			targetCloumnData.setValue(4000);
			targetCloumnData.setColor("#BF9000");
			targetCloumnDataList.add(targetCloumnData);

			values = new StringBuffer("[{");
			values.append("\"unshipped\":\"" + unshippedOrder + "\"");
			values.append(", \"bps\":\"" + bpsOrder + "\"");
			values.append("}]");
			((MonthAndDayCategory)categoryList.get(i)).setValues(values.toString());
		}

		// BPS Rate
		bpsRateDataSet.setDataList(bpsRateCloumnDataList);
		dataSetList.add(bpsRateDataSet);
		// Target
		targetDataSet.setDataList(targetCloumnDataList);
		dataSetList.add(targetDataSet);

		columnChartView.setDataSetList(dataSetList);
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		return columnChartView;
	}
	
	/*
	 * LINK METHOD
	 */
	public void setBPSOverviewColumnLink(ColumnData cloumnData,String name, int key) {
		/*cloumnData.setLink("j-showDetractorMainPieAndData-"
				+ weekNo + "," 
				+ trackingCausesMonday + "|" 
				+trackingCausesSunday);*/
		cloumnData.setLink("j-refreshRemark-" + name + "," + key);
	}
	
	private List<BpsCrossMonth> getBpsOrderQty4RemarkBySubDimension(SearchBpsForm form){
		if("region".equals(form.getSubDimension())){
			return bpsDao.getBpsOrderQty4RemarkByRegion(form);
		}else if("odm".equals(form.getSubDimension())){
			return bpsDao.getBpsOrderQty4RemarkByODM(form);
		}else if("product".equals(form.getSubDimension())){
			return bpsDao.getBpsOrderQty4RemarkByProduct(form);
		}else if("productFamily".equals(form.getSubDimension())){
			return bpsDao.getBpsOrderQty4RemarkByProductFamily(form);
		}else if ("purchase".equals(form.getSubDimension())) {
			if("region".equals(form.getDimension())){
				return bpsDao.getBpsOrderQty4PieByPurchaseType(form);	
			}else{
				return bpsDao.getBpsOrderQty4PieByCVPurchaseType(form);	
			}
		} else if ("parts".equals(form.getSubDimension())) {
			if("region".equals(form.getDimension())){
				return bpsDao.getBpsOrderQty4PieByParts(form);
			}else{
				List<BpsCrossMonth> bpsList = new ArrayList<BpsCrossMonth>();
				List<BpsCrossMonth> bpsByPartsList = bpsDao.getBpsOrderQty4PieByParts(form);
				List<BpsCrossMonth> bpsByBpsPurchaseTypeList = bpsDao.getBpsOrderQty4PieByBpsPurchaseType(form);
				if(CollectionUtils.isNotEmpty(bpsByPartsList)){
					bpsList.addAll(bpsByPartsList);
				}
				if(CollectionUtils.isNotEmpty(bpsByBpsPurchaseTypeList)){
					bpsList.addAll(bpsByBpsPurchaseTypeList);
				}
				return bpsList;
			}
		}else if("subParts".equals(form.getSubDimension())){
			return bpsDao.getBpsOrderQty4PieBySubParts(form);
		}else{
			return null;
		}
	}
	
	private List<BpsCrossMonth> getMaxProductBpsQty4RemarkBySubDimension(SearchBpsForm form){
		if("region".equals(form.getSubDimension())){
			if("odm".equals(form.getDimension())){
				return bpsDao.getMaxProductFamilyBpsOrderQty4RemarkByRegion(form);
			}else{
				return bpsDao.getMaxProductBpsOrderQty4RemarkByRegion(form);
			}
			
		}else if("odm".equals(form.getSubDimension())){
			return bpsDao.getMaxProductBpsOrderQty4RemarkByODM(form);
		}else if("product".equals(form.getSubDimension())){
			return bpsDao.getMaxProductBpsOrderQty4RemarkByProduct(form);
		}else if("productFamily".equals(form.getSubDimension())){
			return bpsDao.getMaxProductFamilyBpsOrderQty4RemarkByProductFamily(form);
		}else{
			return null;
		}
	}

	private List<BpsCrossMonth> getBpsOrderQty4RemarkByDimension(SearchBpsForm form){
		List<BpsCrossMonth> bpsOrders = this.getBpsOrderQty4RemarkBySubDimension(form);
		if("region".equals(form.getDimension())){
			//do nothing
		}else if(StringUtils.isBlank(form.getDimension()) && "region".equals(form.getSubDimension())){//overview region remark
			//do nothing
		}else{
			if(CollectionUtils.isNotEmpty(bpsOrders)){
				List<BpsCrossMonth> maxProductBpsOrders = this.getMaxProductBpsQty4RemarkBySubDimension(form);
				Map<String,Float> maxProductBpsOrderMap = new HashMap<String,Float>();
				if(CollectionUtils.isNotEmpty(maxProductBpsOrders)){
					for(BpsCrossMonth bps : maxProductBpsOrders){
						if("region".equals(form.getSubDimension()) || "productFamily".equals(form.getSubDimension())){
							maxProductBpsOrderMap.put(bps.getRowName(), bps.getBpsOrder());
						}else{
							maxProductBpsOrderMap.put(String.valueOf(bps.getRowValue()), bps.getBpsOrder());
						}	
					}
					
					Float bpsQty = 0f;
					for(BpsCrossMonth bpsOrder : bpsOrders){
						if("region".equals(form.getSubDimension()) || "productFamily".equals(form.getSubDimension())){
							bpsQty = maxProductBpsOrderMap.get(String.valueOf(bpsOrder.getRowName()));
						}else{
							bpsQty = maxProductBpsOrderMap.get(String.valueOf(bpsOrder.getRowValue()));
						}
						if(bpsQty == null){
							bpsQty = 0f;
						}
						
						bpsOrder.setBpsOrder(bpsQty);
						if(bpsQty == 0){
							bpsOrder.setBpsRate(0);
						}else{
							if(bpsOrder.getUnshippedOrder() == 0){
								bpsOrder.setBpsRate(100);
							}else{
								bpsOrder.setBpsRate(bpsOrder.getBpsOrder()/bpsOrder.getBpsRate());
							}
						}
					}
				}
			}
		}
		if(CollectionUtils.isNotEmpty(bpsOrders)){
			if("region".equals(form.getSubDimension()) && "overview".equals(form.getPageType())){
				ListSortUtil.sort(bpsOrders, "bpsRate", "desc");
			}else if("parts".equals(form.getSubDimension()) || "subParts".equals(form.getSubDimension()) || "purchase".equals(form.getSubDimension())){
				ListSortUtil.sort(bpsOrders, "bpsOrder", "asc");
			}else{
				ListSortUtil.sort(bpsOrders, "bpsOrder", "desc");
			}
			
			int maxlenth = 15;
			if(bpsOrders.size() < maxlenth){
				maxlenth = bpsOrders.size();
			}
			bpsOrders = bpsOrders.subList(0, maxlenth);
		}
		return bpsOrders;
	}
	/*
	 * (non-Javadoc)
	 * @see com.lenovo.bi.service.sc.BPSService#getOverviewRemarkChart(com.lenovo.bi.form.sc.bps.SearchBpsForm)
	 * 
	 * drew remark
	 */
	@Override
	public ColumnChartView getOverviewRemarkChart(SearchBpsForm form) throws ParseException {
		List<BpsCrossMonth> bpsOrderResultList = this.getBpsOrderQty4RemarkByDimension(form);
		//List<BpsCrossMonth> unshippedResultList = null;
		ColumnChartView columnChartView = setRemarkChartInfomation();
		DataSetColumn dataSetColumn = new DataSetColumn();
		if("region".equals(form.getSubDimension())){
			dataSetColumn.setSeriesName("BPS by Region");
		}else if("odm".equals(form.getSubDimension())){
			dataSetColumn.setSeriesName("BPS by ODM");
		}else if("product".equals(form.getSubDimension()) || "productFamily".equals(form.getSubDimension())){
			dataSetColumn.setSeriesName("BPS by Product");
		}else{
			return columnChartView;
		}
		
		if(bpsOrderResultList == null){
			return columnChartView;
		}
		
		// dataset:seriesName
		dataSetColumn.setColor("#FF0000");
		Category category = null;
		ColumnData bspRateColumnData = null;
		StringBuffer toolText = null;
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		List<ColumnData> cloumnDataList = new ArrayList<ColumnData>();
		//double yAxisMaxValue = 100;
		for (BpsCrossMonth bps : bpsOrderResultList) {
			category = new Category();
			category.setValue(bps.getRowValue());
			category.setName(bps.getRowName());
			

			bspRateColumnData = new ColumnData();
			toolText = new StringBuffer();
			toolText.append("BPS by ");
			if("odm".equals(form.getSubDimension())){
				toolText.append("odm".toUpperCase());
			}else{
				toolText.append(StringUtil.toUpperCaseFirstOne(form.getSubDimension()));
			}
			toolText.append(", ").append(category.getName()).append(", ");
			
			if("region".equals(form.getSubDimension()) && "overview".equals(form.getPageType())){
				if(bps.getBpsRate() >1){
					bspRateColumnData.setValue(100f);
				}else{
					bspRateColumnData.setValue(bps.getBpsRate()*100);
				}
				toolText.append(this.formartTipValue(String.format("%.2f",bspRateColumnData.getValue()))).append("%");
				columnChartView.getChartInfo().setNumbersuffix("%");
			}else{
				bspRateColumnData.setValue(bps.getBpsOrder());
				double value = 0.0;	
				if(bspRateColumnData.getValue() != null){
					value = bspRateColumnData.getValue().doubleValue();
				}
				String toolValue = String.valueOf(value);
				if(value < 1000){
					toolValue = this.formartTipValue(String.format("%.2f", value));
				}else if(1000 <=value && value< 1000000){
					toolValue = this.formartTipValue(String.format("%.2f", value/1000.0));
					//toolValue = String.valueOf(value/1000.0);
					toolValue = toolValue+"K";
				}else if(1000000 <=value && value< 1000000000){
					toolValue = this.formartTipValue(String.format("%.2f", value/1000000.0));
					//toolValue = String.valueOf(value/1000000.0);
					toolValue = toolValue+"M";
				}else{
					toolValue = this.formartTipValue(String.format("%.2f", value/1000000000.0));
					//toolValue = String.valueOf(value/1000000000.0);
					toolValue = toolValue+"B";
				}
				toolText.append(toolValue);
				columnChartView.getChartInfo().setNumbersuffix("");
			}
			
			bspRateColumnData.setTooltext(toolText.toString());
			String functionName = null;
			String params = null;
			if("region".equals(form.getDimension()) || (StringUtils.isBlank(form.getDimension())&&"region".equals(form.getSubDimension()))){
				functionName = "showBpsOrderDetail";
				
			}else{
				functionName = "showRemarkBpsDetail";
			}
			if("overview".equals(form.getPageType())){
				params = "1,";
			}else if("crossmonth".equals(form.getPageType())){
				params = "2,";
			}else{
				params = "3,";
			}
			if("region".equals(form.getSubDimension()) || "productFamily".equals(form.getSubDimension())){
				params = params + form.getSubDimension() + "," +bps.getRowName();
			}else{
				params = params + form.getSubDimension() + "," +bps.getRowValue();
			}
			
			bspRateColumnData.setLink("j-" + functionName+"-" + params);
			if(bspRateColumnData.getValue() != null && bspRateColumnData.getValue().doubleValue() > 0){
				cloumnDataList.add(bspRateColumnData);
				categoryList.add(category);
				//yAxisMaxValue = Math.max(yAxisMaxValue, bspRateColumnData.getValue().doubleValue()*1.15);
			}
		}
		//columnChartView.getChartInfo().setyAxisMaxValue(String.valueOf(yAxisMaxValue));
		Categories categories = new Categories();
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();
		dataSetColumn.setDataList(cloumnDataList);
		dataSetList.add(dataSetColumn);
		columnChartView.setDataSetList(dataSetList);

		return columnChartView;
	}
	private String formartTipValue(String str){
		str = str.replace(".00", "");
		str = str.replace(".0", "");
		if(str.endsWith("0") && str.contains(".")){
			str = str.substring(0,str.length() - 1);
		}
		return str;
	}
	@Override
	public String getOverviewRemarkTotal(SearchBpsForm form)
			throws ParseException {
		BpsCrossMonth bps = bpsDao.getTotalBpsOrderQty4Remark(form);
		StringBuffer sb = new StringBuffer();
		sb.append("[{unshippedOrder:");
		if(bps != null){
			sb.append(bps.getUnshippedOrder()).append(",");
			sb.append("bpsOrder:").append(bps.getBpsOrder()).append(",");
			sb.append("bpsRate:").append(bps.getBpsRate());
		}else{
			sb.append(0).append(",");
			sb.append("bpsOrder:").append(0).append(",");
			sb.append("bpsRate:").append(0);
		}
		sb.append("}]");
		return sb.toString();
	}
	
	/*
	 * get overview data
	 */
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchbpsOverViewChartData(SearchBpsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> bpsOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		if(!form.isShowMonthOverview()){
			for(int i=0; i<SysConfig.NUMBER_OF_FUTURE_WEEKS1; i++) {
				String date = CalendarUtil.getDateByDays1(form.getStartDate(), i);
				if (date.compareTo(form.getDurationTo()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				form.setVersionDate(date);
				if("region".equals(form.getDimension())){
					bpsOverviewMap.put(keyNameObject, bpsDao.fetchBpsOverViewCrossMonthChartDataRegion(form));
				}else if("odm".equals(form.getDimension())){
					bpsOverviewMap.put(keyNameObject, bpsDao.fetchBpsOverViewCrossMonthChartDataODM(form));
				}else if("product".equals(form.getDimension())){
					bpsOverviewMap.put(keyNameObject, bpsDao.fetchBpsOverViewCrossMonthChartDataProduct(form));
				}
				else{
					bpsOverviewMap.put(keyNameObject, bpsDao.fetchBpsOverViewChartData(form));
				}
			}
		}
		else{
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
				if (date.compareTo(form.getDurationTo()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setVersionDate(date);
				form.setYear(year);
				form.setMonth(month);
				if("region".equals(form.getDimension())){
					bpsOverviewMap.put(keyNameObject, bpsDao.fetchBpsOverViewCrossMonthChartDataRegion(form));
				}else if("odm".equals(form.getDimension())){
					bpsOverviewMap.put(keyNameObject, bpsDao.fetchBpsOverViewCrossMonthChartDataODM(form));
				}else if("product".equals(form.getDimension())){
					bpsOverviewMap.put(keyNameObject, bpsDao.fetchBpsOverViewCrossMonthChartDataProduct(form));
				}
				else{
					bpsOverviewMap.put(keyNameObject, bpsDao.fetchBpsOverViewChartData(form));
				}
			}
		}
		return bpsOverviewMap;
	}

	/*
	 * (non-Javadoc)
	 * @see com.lenovo.bi.service.sc.BPSService#getOverviewPieChart(com.lenovo.bi.form.sc.bps.SearchBpsForm)
	 * 
	 * drew pie chart
	 */

	@Override
	public PieChartView getOverviewPieChart(SearchBpsForm form) throws ParseException {
		
		List<BpsCrossMonth> bpsList = this.getBpsOrderQty4RemarkByDimension(form);
		PieChartView pView = new PieChartView();
		//pView.getChartInfo().setEnableSmartLabels("0");
		pView.getChartInfo().setManageLabelOverflow("1");
		pView.getChartInfo().setUseEllipsesWhenOverflow("0");
		pView.getChartInfo().setPieRadius("80");
		pView.getChartInfo().setLegendPosition("bottom");
		pView.getChartInfo().setDecimals("1");
		pView.getChartInfo().setShowPercentInToolTip("0");
		pView.getChartInfo().setShowPercentValues("0");
		pView.getChartInfo().setNumbersuffix("%");
		//pView.getChartInfo().setShowValues("1");
		pView.getChartInfo().setSkipOverlapLabels("0");
		if("subParts".equals(form.getSubDimension())){
			//pView.getChartInfo().setPieRadius("30");
		}
		List<PieSlice> pieList = new ArrayList<PieSlice>();
		PieSlice p = null;
		if(bpsList != null){
			BigDecimal totalValue = BigDecimal.ZERO;
			for(BpsCrossMonth bps : bpsList){
				totalValue = totalValue.add(new BigDecimal(bps.getBpsOrder()));
			}
			BigDecimal percentage = BigDecimal.ZERO;
			BigDecimal hundred = new BigDecimal(100);
			for(BpsCrossMonth bps : bpsList){
				p = new PieSlice();
				p.setLabel(bps.getRowName());
				percentage = new BigDecimal(bps.getBpsOrder()).divide(totalValue, 3, BigDecimal.ROUND_HALF_UP).multiply(hundred);
				//客户要求不满1%的部分显示1%，总和可以超过100%
				if(percentage.compareTo(BigDecimal.ONE) < 0){
					percentage = BigDecimal.ONE;
				}
				p.setValue(percentage.toString());
				if("parts".equals(form.getSubDimension()) && !"purchaseType".equals(bps.getType())){
					p.setLink("j-showSubParts-" + bps.getRowValue());
				}else{
					String functionName = null;
					String params = null;
					if("region".equals(form.getDimension()) || (StringUtils.isBlank(form.getDimension())&&"region".equals(form.getSubDimension()))){
						functionName = "showBpsOrderDetail";
					}else{
						functionName = "showRemarkBpsDetail";
					}
					if("overview".equals(form.getPageType())){
						params = "1,";
					}else if("crossmonth".equals(form.getPageType())){
						params = "2,";
					}else{
						params = "3,";
					}
					params = params + form.getSubDimension() + ",";
					
					if(("region".equals(form.getDimension())||"geo".equals(form.getDimension())) && "purchase".equals(form.getSubDimension())){
						params = params + bps.getRowName();
					}else{
						params = params + bps.getRowValue();
					}
					 
					p.setLink("j-"+functionName+"-" + params);
				}
				pieList.add(p);
			}
		}
		pView.setElements(pieList);
		return pView;
	}
	@Override
	public List<TtvGridDetractorCodeView> getBpsAgingAnglysisOrderDetail(SearchBpsForm form) throws ParseException {
		return null;
	}

	/**
	 * dashboard-overview
	 * 
	 * 
	 * 
	 * 
	 */
	@Override
	public ColumnChartView getDashboardOverviewChart(SearchBpsForm form) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();

		// Chart
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setsYAxisMinValue("0");
		columnChartView.getChartInfo().setsYAxisMaxValue("100");
		columnChartView.getChartInfo().setNumdivlines("9");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("160");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setShowBorder("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setPlotSpacePercent("70");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setShowValues("0");

		// Categories
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		Category category = null;

		// Dataset
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();

		// BPS
		ColumnData bpsColumnData = null;
		List<ColumnData> bpsCloumnDataList = new ArrayList<ColumnData>();

		DataSetColumn bpsDataSet = new DataSetColumn();
		bpsDataSet.setSeriesName("BPS");
		bpsDataSet.setColor("#FF0000");

		// Unshipped Backlog
		ColumnData unshippedCloumnData = null;
		List<ColumnData> unshippedCloumnDataList = new ArrayList<ColumnData>();

		DataSetColumn unshippedDataSet = new DataSetColumn();
		unshippedDataSet.setSeriesName("Unshipped Backlog");
		unshippedDataSet.setColor("#F8CBAD");

		//----------------choice of dashboard's dimension------------
		List<BpsCrossMonth> bpsOrderResultList = new ArrayList<BpsCrossMonth>();
		List<BpsCrossMonth> unshippedResultList = new ArrayList<BpsCrossMonth>();
		if("region".equals(form.getSubDimension())){
			if(form.isShowGeo()==false || "undefine".equals(form.isShowGeo())){
				bpsOrderResultList = bpsDao.getBpsDashboardRegion(form);
				unshippedResultList = bpsDao.getBpsDashboardRegion(form);
				
			}else{
				bpsOrderResultList = bpsDao.getBpsDashboardRegion(form);
				unshippedResultList = bpsDao.getBpsDashboardRegion(form);
			}
			
		}else if("odm".equals(form.getSubDimension())){
			bpsOrderResultList = bpsDao.getBpsDashboardODM(form);
			unshippedResultList = bpsDao.getUnshippedDashboardODM(form);
		}else if("product".equals(form.getSubDimension())){
			bpsOrderResultList = bpsDao.getBpsDashboardProduct(form);
			unshippedResultList = bpsDao.getUnshippedDashboardProduct(form);
		}
		Map<String,Float> unshippedMap = new HashMap<String,Float>();
		for(BpsCrossMonth unshipped : unshippedResultList){
			unshippedMap.put(unshipped.getRowName(), unshipped.getUnshippedOrder());
		}
		ColumnData bpsRateCloumnData = null;
		BigDecimal bpsOrder = null;
		BigDecimal unshippedOrder = null;
		BigDecimal bpsRate = null;

		// BPS Rate
		DataSetLine bpsRateDataSet = new DataSetLine();
		bpsRateDataSet.setParentYaxis("S");
		bpsRateDataSet.setSeriesName("BPS Rate");
		bpsRateDataSet.setRenderas("Line");
		bpsRateDataSet.setColor("#3333FF");
		List<ColumnData> bpsRateCloumnDataList = new ArrayList<ColumnData>();

		StringBuffer values = null;
		for (int i = 0; i < bpsOrderResultList.size(); i++) {
			bpsOrder = new BigDecimal(bpsOrderResultList.get(i).getBpsOrder());
			Float unshippedBacklog = unshippedMap.get(bpsOrderResultList.get(i).getRowName());
			if(unshippedBacklog != null && unshippedBacklog != 0){
				unshippedOrder = new BigDecimal(unshippedBacklog);
				bpsRate = bpsOrder.divide(unshippedOrder, 2, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal("100"));
			}else{
				bpsRate = new BigDecimal(100);
			}
			bpsOrderResultList.get(i).setBpsRate(bpsRate.floatValue() > 100 ? 100 : bpsRate.floatValue());
			//unshippedResultList.get(i).setBpsRate(bpsRate.floatValue());
		}

		// Sort the bps and unshipped order by bps rate in order to display in
		// UI by rate asc
		Collections.sort(bpsOrderResultList, new SortByBPSRateDesc());
		//Collections.sort(unshippedResultList, new SortByBPSRateAsc());

		for (int i = 0; i < bpsOrderResultList.size(); i++) {
			float kpi = bpsOrderResultList.get(i).getBpsRate();
			String name;
			name = bpsOrderResultList.get(i).getRowValue() + "," + bpsOrderResultList.get(i).getRowName();

			// Set bpsOrder
			bpsColumnData = new ColumnData();
			bpsColumnData.setColor("#FF0000");
			bpsColumnData.setValue(bpsOrderResultList.get(i).getBpsOrder());
			bpsColumnData.setLink("j-refreshRemark-" + name);
			bpsCloumnDataList.add(bpsColumnData);

			// Set unshipped order
			unshippedCloumnData = new ColumnData();
			Float unshippedBacklog = unshippedMap.get(bpsOrderResultList.get(i).getRowName());
			if(unshippedBacklog != null){
				unshippedCloumnData.setValue(unshippedBacklog);
			}else{
				unshippedBacklog = 0f;
				unshippedCloumnData.setValue(0);
			}
			
			unshippedCloumnData.setColor("#F8CBAD");
			unshippedCloumnData.setLink("j-refreshRemark-" + name);
			unshippedCloumnDataList.add(unshippedCloumnData);

			bpsRateCloumnData = new ColumnData();
			bpsRateCloumnData.setValue(kpi);
			bpsRateCloumnData.setColor("#3333FF");
			bpsRateCloumnDataList.add(bpsRateCloumnData);

			// Set category
			category = new Category();
			category.setValue(bpsOrderResultList.get(i).getRowValue());
			category.setName(bpsOrderResultList.get(i).getRowName());

			int green = 10;
			int red = 20;
			String lightColor = null;

			if (kpi <= green)
				lightColor = KPILights.GREEN.toString();
			else if (kpi > green && kpi <= red)
				lightColor = KPILights.YELLOW.toString();
			else if (kpi > red)
				lightColor = KPILights.RED.toString();

			values = new StringBuffer("[{");
			values.append("\"unshipped\":" + unshippedBacklog);
			values.append(", \"bps\":" + bpsOrderResultList.get(i).getBpsOrder());
			values.append(", \"rate\":" + kpi);
			values.append(", \"lightColor\":\"" + lightColor + "\"");
			values.append(", \"subDimensionName\":\"" + category.getName() + "\"");
			values.append("}]");
			category.setValues(values.toString());
			categoryList.add(category);
		}

		bpsDataSet.setDataList(bpsCloumnDataList);
		dataSetList.add(bpsDataSet);

		unshippedDataSet.setDataList(unshippedCloumnDataList);
		dataSetList.add(unshippedDataSet);

		if("region".equals(form.getSubDimension()) || "odm".equals(form.getSubDimension())){
			bpsRateDataSet.setDataList(bpsRateCloumnDataList);
			dataSetList.add(bpsRateDataSet);
		}
		

		columnChartView.setDataSetList(dataSetList);

		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		return columnChartView;
	}

	/**
	 * CrossMonth chart
	 * 
	 * 
	 */
	@Override
	public ColumnChartView getCrossMonthDashboardOverviewChart(SearchBpsForm form) throws ParseException {
		ColumnChartView columnChartView = new ColumnChartView();

		// Chart
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setsYAxisMinValue("0");
		columnChartView.getChartInfo().setsYAxisMaxValue("100");
		columnChartView.getChartInfo().setNumdivlines("9");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("160");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setShowBorder("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setPlotSpacePercent("70");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setShowValues("0");
		
		// Categories
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		String startDate = form.getStartDate().substring(0, 7);
		
		//day
		if(!form.isShowMonthOverview()) {
			for(int i=0; i<SysConfig.NUMBER_OF_FUTURE_WEEKS1; i++) {
				String date = CalendarUtil.getDateByDays1(form.getStartDate(), i);
				if (form.getEndDate()!=null && date.compareTo(form.getEndDate()) > 0) 
					break;
				MonthAndDayCategory category = new MonthAndDayCategory();
				category.setName(date);
				categoryList.add(category);
			}
		}
		//month
		else {
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
				if (form.getDurationTo()!=null && yearMonth.compareTo(form.getDurationTo()) > 0) 
					break;
				MonthAndDayCategory category = new MonthAndDayCategory();
				category.setName(yearMonth);
				categoryList.add(category);
			}
		}
				
		List<ColumnData> bpsColumnDataList = null;
		bpsColumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> unshippedCloumnDataList = new ArrayList<ColumnData>();
		ColumnData bpsColumnData = null;
		ColumnData unshippedColumnData = null;
				
				
		//day
		if (form.getFrequency().equals("Day")) {
			
			Calendar calendar = Calendar.getInstance();
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date startDay = format.parse(form.getStartDate());
			calendar.setTime(startDay);
			
			LinkedHashMap<Object,List<ScOverViewChartData>> bpsOverviewMap = null;
			bpsOverviewMap = fetchbpsOverViewChartData(form);
			
			for(Map.Entry<Object, List<ScOverViewChartData>> entry : bpsOverviewMap.entrySet()) {
				String name = ((KeyNameObject)entry.getKey()).getObjName();
				int key = -1;
				
				bpsColumnData = new ColumnData();
				setBPSOverviewColumnLink(bpsColumnData,name,key);
				bpsColumnData.setValue(0);
				
				unshippedColumnData = new ColumnData();
				setBPSOverviewColumnLink(unshippedColumnData,name,key);
				unshippedColumnData.setValue(0);
				
				List<ScOverViewChartData> chartDataList = entry.getValue();
				StringBuffer valueBuffer = new StringBuffer("[{");
				
				for(ScOverViewChartData bpsOverViewChartData : chartDataList) {
					if(bpsOverViewChartData.getScStatusName().equals(BPSStatusEnum.BPS.getTypeName())) {
						setBPSOverviewColumnLink(bpsColumnData,name,key);
						bpsColumnData.setValue(bpsOverViewChartData.getOrderNum());
						valueBuffer.append("bps:");
					}
					else if(bpsOverViewChartData.getScStatusName().equals(BPSStatusEnum.Unshipped.getTypeName())) {
						setBPSOverviewColumnLink(unshippedColumnData,name,key);
						unshippedColumnData.setValue(bpsOverViewChartData.getOrderNum());
						valueBuffer.append("Unshipped:");
					}
				}
				bpsColumnDataList.add(bpsColumnData);
				unshippedCloumnDataList.add(unshippedColumnData);
			}
			form.setEndDate(format.format(calendar.getTime()));
		}
		
		//month-----------------------------------------------------------------
		else {
			Calendar calendar = Calendar.getInstance();
			DateFormat format = new SimpleDateFormat("yyyy-MM");
			Date startDay = format.parse(form.getStartDate());
			calendar.setTime(startDay);
			
			LinkedHashMap<Object,List<ScOverViewChartData>> bpsOverviewMap = null;
			bpsOverviewMap = fetchbpsOverViewChartData(form);
			
			for(Map.Entry<Object, List<ScOverViewChartData>> entry : bpsOverviewMap.entrySet()) {
				String name = ((KeyNameObject)entry.getKey()).getObjName();
				int key = -1;
				
				bpsColumnData = new ColumnData();
				setBPSOverviewColumnLink(bpsColumnData,name,key);
				bpsColumnData.setValue(0);
				
				unshippedColumnData = new ColumnData();
				setBPSOverviewColumnLink(unshippedColumnData,name,key);
				unshippedColumnData.setValue(0);
				
				List<ScOverViewChartData> chartDataList = entry.getValue();
				StringBuffer valueBuffer = new StringBuffer("[{");
				
				for(ScOverViewChartData bpsOverViewChartData : chartDataList) {
					if(bpsOverViewChartData.getScStatusName().equals(BPSStatusEnum.BPS.getTypeName())) {
						setBPSOverviewColumnLink(bpsColumnData,name,key);
						bpsColumnData.setValue(bpsOverViewChartData.getOrderNum());
						valueBuffer.append("bps:");
					}
					else if(bpsOverViewChartData.getScStatusName().equals(BPSStatusEnum.Unshipped.getTypeName())) {
						setBPSOverviewColumnLink(unshippedColumnData,name,key);
						unshippedColumnData.setValue(bpsOverViewChartData.getOrderNum());
						valueBuffer.append("Unshipped:");
					}
				}
				
				bpsColumnDataList.add(bpsColumnData);
				unshippedCloumnDataList.add(unshippedColumnData);
			}
			form.setEndDate(format.format(calendar.getTime()));
		}

		// Dataset
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();

		// BPS
		DataSetColumn bpsDataSet = new DataSetColumn();
		bpsDataSet.setSeriesName("BPS");
		bpsDataSet.setColor("#FF0000");
		bpsDataSet.setDataList(bpsColumnDataList);
		dataSetList.add(bpsDataSet);

		// Unshipped Backlog
		DataSetColumn unshippedDataSet = new DataSetColumn();
		unshippedDataSet.setSeriesName("Unshipped Backlog");
		unshippedDataSet.setColor("#F8CBAD");

		unshippedDataSet.setDataList(unshippedCloumnDataList);
		dataSetList.add(unshippedDataSet);

		// BPS Rate
		DataSetLine bpsRateDataSet = new DataSetLine();
		bpsRateDataSet.setParentYaxis("S");
		bpsRateDataSet.setSeriesName("BPS Rate");
		bpsRateDataSet.setRenderas("Line");
		bpsRateDataSet.setColor("#3333FF");
		List<ColumnData> bpsRateCloumnDataList = new ArrayList<ColumnData>();
		ColumnData bpsRateCloumnData = null;
		BigDecimal bpsOrder = null;
		BigDecimal unshippedOrder = null;
		BigDecimal bpsRate = null;

		// Target
		DataSetLine targetDataSet = new DataSetLine();
		targetDataSet.setParentYaxis("S");
		targetDataSet.setSeriesName("Target");
		targetDataSet.setRenderas("Line");
		targetDataSet.setColor("#BF9000");
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		ColumnData targetCloumnData = new ColumnData();

		StringBuffer values = null;
		for (int i = 0; i < bpsColumnDataList.size(); i++) {
			bpsOrder = new BigDecimal(bpsColumnDataList.get(i).getValue().floatValue());
			unshippedOrder = new BigDecimal(unshippedCloumnDataList.get(i).getValue().floatValue());
			if (bpsOrder.compareTo(BigDecimal.ZERO) == 0 || unshippedOrder.compareTo(BigDecimal.ZERO) == 0) {
				bpsRate = BigDecimal.ZERO;
			} else {
				bpsRate = bpsOrder.divide(unshippedOrder, 2, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal("100"));
			}
			bpsRateCloumnData = new ColumnData();
			bpsRateCloumnData.setValue(bpsRate.floatValue() > 100 ? 100 : bpsRate.floatValue());
			bpsRateCloumnData.setColor("#3333FF");
			bpsRateCloumnDataList.add(bpsRateCloumnData);

			targetCloumnData.setValue(15);
			targetCloumnData.setColor("#BF9000");
			targetCloumnDataList.add(targetCloumnData);

			values = new StringBuffer("[{");
			values.append("\"unshipped\":\"" + unshippedOrder + "\"");
			values.append(", \"bps\":\"" + bpsOrder + "\"");
			values.append("}]");
			((MonthAndDayCategory)categoryList.get(i)).setValues(values.toString());
		}

		if("region".equals(form.getDimension())||"odm".equals(form.getDimension())){
			// BPS Rate
			bpsRateDataSet.setDataList(bpsRateCloumnDataList);
			dataSetList.add(bpsRateDataSet);
			// Target
			targetDataSet.setDataList(targetCloumnDataList);
			//dataSetList.add(targetDataSet);
		}
		

		columnChartView.setDataSetList(dataSetList);
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);

		return columnChartView;
	}
	

	private ColumnChartView setRemarkChartInfomation() {
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumdivlines("10");
		columnChartView.getChartInfo().setShowValues("1");
		columnChartView.getChartInfo().setAlternatevgridalpha("0");
		columnChartView.getChartInfo().setCanvasBorderAlpha("60");
		columnChartView.getChartInfo().setShowBorder("0");
		
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("0");
		columnChartView.getChartInfo().setUseroundedges("0");
		columnChartView.getChartInfo().setShowAlternateHGridColor("0");

		return columnChartView;
	}

	/**
	 * bps overview crossmonth dashboard
	 * orderdetail
	 */
	@Override
	public Map<String,Object> getBpsSumOrderDetail(SearchBpsForm form) throws ParseException {
		List<TtvGridDetractorCodeView> grid = new ArrayList<TtvGridDetractorCodeView>();
		long totalCount = 0;
		
		totalCount = bpsDao.getUnshippedDetailCount(form);
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			grid = bpsDao.getOverviewOrderDetail(form);
		}
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}

	@Override
	public List<TtvGridDetractorCodeView> getExportBpsOrderDetail(SearchBpsForm form) throws ParseException {
		List<TtvGridDetractorCodeView> aa = new ArrayList<TtvGridDetractorCodeView>();
		aa = bpsDao.getOverviewOrderDetail(form);
		return aa;
	}

	@Override
	public ColumnChartView getDaysOfOverDue(SearchBpsForm form) throws ParseException {
		ColumnChartView columnChartView = setRemarkChartInfomation();
		return columnChartView;
	}

	@Override
	public List<BPSDetailView> getBpsDetail(SearchBpsForm form) {
		return bpsDao.getBpsDetail(form);
	}
	@Override
	public long getBpsDetailCount(SearchBpsForm form) {
		return bpsDao.getBpsDetailCount(form);
	}

	@Override
	public float calOverViewBpsRateByMonth(String month) {
		SearchBpsForm form = new SearchBpsForm();
		form.setShowMonthOverview(true);
		form.setVersionDate(month);
		List<ScOverViewChartData> bpsList = bpsDao.fetchBpsOverViewChartData(form);
		if(CollectionUtils.isNotEmpty(bpsList)){
			int bpsNum = 0;
			int unshippedNum = 0;
			for(ScOverViewChartData bps : bpsList){
				if(bps.getScStatusName().equals(BPSStatusEnum.BPS.getTypeName())){
					bpsNum = bps.getOrderNum();
				}else if(bps.getScStatusName().equals(BPSStatusEnum.Unshipped.getTypeName())){
					unshippedNum = bps.getOrderNum();
				}
			}
			if(bpsNum == 0){
				return 0;
			}
			if(unshippedNum == 0){
				return 100;
			}
			float bpsRate = (float)(Math.round(bpsNum*10000.0f/unshippedNum)/100.0f);
			if(bpsRate > 100){
				bpsRate = 100;
			}
			return bpsRate;
		}else{
			return 0;
		}
		
	}

	@Override
	public Map<String,Object> getBpsSumFactDetail(SearchBpsForm form){
		List<FactDetailView> grid = new ArrayList<FactDetailView>();
		long totalCount = 0;
		
		//totalCount = bpsDao.getUnshippedDetailCount(form);
		totalCount = bpsDao.getOverviewFactDetailCount(form);
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			//grid = bpsDao.getOverviewOrderDetail(form);
			grid = bpsDao.getOverviewFactDetail(form);
		}
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
}

class SortByBPSRateAsc implements Comparator<BpsCrossMonth> {

	@Override
	public int compare(BpsCrossMonth o1, BpsCrossMonth o2) {
		if (o1.getBpsRate() > o2.getBpsRate()) {
			return 1;
		}
		return 0;
	}

}

class SortByBPSRateDesc implements Comparator<BpsCrossMonth> {

	@Override
	public int compare(BpsCrossMonth o1, BpsCrossMonth o2) {
		if (o1.getBpsRate() < o2.getBpsRate()) {
			return 1;
		}
		return 0;
	}

}