package com.lenovo.bi.dao.sc;


import java.util.List;

import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.dto.sc.OnsRemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.dto.sc.ScRemarkChartData;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;

public interface OnsDao {

	public List<ScOverViewChartData> fetchOnsOverViewChartData(SearchOtsForm form);
	
	public List<OnsRemarkChartData> fetchDimensionRemarkDataList(SearchOtsForm form);
	
	public List<KeyNameObject> fetchDimensions(SearchOtsForm form);
	
	public List<KeyNameObject> fetchGeoDimensions(SearchOtsForm form);
	
	public List<ScRemarkChartData> fetchOnsRemarkChartData(SearchOtsForm form);
	
	public List<ScRemarkChartData> fetchOnsGeoRemarkChartData(SearchOtsForm form);
	
	public List<ScOverViewChartData> fetchOnsDashboardOverViewChartData(SearchOtsForm form);
	
	public List<ScOverViewChartData> fetchOnsGeoDashboardOverViewChartData(SearchOtsForm form);

	public List<ScOverViewChartData> fetchOnsCrossMonthOverviewChartData(SearchOtsForm form);
	
	public List<ScOverViewChartData> getOverviewOverall(SearchOtsForm form);
	
	public List<String> fetchOnsOverViewSumOrderDetailData(SearchOtsForm form);
	
	public List<String> fetchOnsCrossMonthSumOrderDetailData(SearchOtsForm form);
	
	public List<String> fetchOnsDashboardSumOrderDetailData(SearchOtsForm form);

	public List<String> fetchOnsOrderKeysByDims(SearchOtsForm form);

	public List<PieDivider> getDetractorMainDivider(SearchOtsForm form);
	
	public List<String> fetchOnsOverViewRemarkOrderDetailData(SearchOtsForm form);
	
	//overview order detail
	public int getOverviewOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getOverviewOrderDetail(SearchOtsForm form);
	
	public int getCrossMonthOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getCrossMonthOrderDetail(SearchOtsForm form);
	
	public int getDashboardOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getDashboardOrderDetail(SearchOtsForm form);
	
	//remark order detail
	public int getRemarkOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getRemarkOrderDetail(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getAllOrderDetail(SearchOtsForm form);
	
	//detractor order detail
	public int getDetractorOrderDetailCount(SearchOtsForm form);
		
	public List<TtvGridDetractorCodeView> getDetractorOrderDetail(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getDashCrossRemarkOrderDetail(SearchOtsForm form);
	
	public int getDashCrossRemarkOrderDetailCount(SearchOtsForm form);
	
	public List<TtvGridDetractorCodeView> getAllDetractorOrder(SearchOtsForm form);
}
