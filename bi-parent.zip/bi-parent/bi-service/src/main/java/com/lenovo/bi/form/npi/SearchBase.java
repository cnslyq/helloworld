package com.lenovo.bi.form.npi;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.enumobj.PermissionScope;

public class SearchBase {
	private Date durationFrom;
	private Date durationTo;
	private String currentUserId;
	private PermissionScope scope;
	private List<Integer> waveIds;

	public List<Integer> getWaveIds() {
		return waveIds;
	}

	public void setWaveIds(List<Integer> waveIds) {
		this.waveIds = waveIds;
	}
	
	public PermissionScope getScope() {
		return scope;
	}
	public void setScope(PermissionScope scope) {
		this.scope = scope;
	}
	public String getCurrentUserId() {
		return currentUserId;
	}
	public void setCurrentUserId(String currentUserId) {
		this.currentUserId = currentUserId;
	}
	public Date getDurationFrom() {
		return durationFrom;
	}
	public void setDurationFrom(Date durationFrom) {
		this.durationFrom = durationFrom;
	}
	public Date getDurationTo() {
		return durationTo;
	}
	public void setDurationTo(Date durationTo) {
		this.durationTo = durationTo;
	}
}
