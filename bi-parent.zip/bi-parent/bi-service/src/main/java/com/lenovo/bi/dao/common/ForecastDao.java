package com.lenovo.bi.dao.common;

import java.util.Date;
import java.util.List;

import com.lenovo.bi.dto.CtoCvConfig;
import com.lenovo.bi.dto.Forecast;
import com.lenovo.bi.dto.MtmGeographyOdmCvQuantity;
import com.lenovo.bi.dto.NpiDnsEntry;
import com.lenovo.bi.dto.NpiForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;

/**
 * 
 * 
 * @author henry_lian ying_han
 * 
 */
public interface ForecastDao {
	public List<Forecast> getAllMtmForecastsInWeek(Date processDate, Date versionDate);

	public List<CtoCvConfig> getAllCtoForecastsInWeek(Date targetDate, Date versionDate);

	/**
	 * Find the MTM forecasts whose target date is the same as the one passed
	 * in, and whose version date is the earliest one after versionDate passed
	 * in.
	 * 
	 * @param targetDate
	 * @param versionDate
	 * @return
	 */
	public List<Forecast> getAllMtmForecastsInWeekForVersionDate(Date targetDate, Date versionDate);

	/**
	 * Find the CTO forecasts whose target date is the same as the one passed
	 * in, and whose version date is the earliest one after versionDate passed
	 * in.
	 * 
	 * @param targetDate
	 * @param versionDate
	 * @return
	 */
	public List<CtoCvConfig> getAllCtoForecastsInWeekForVersionDate(Date targetDate, Date versionDate);

	/**
	 * Fill CV breakdown of the CTO forecast
	 * 
	 * @param ctoForecast
	 * @param targetDate
	 * @param versionDate
	 */
	public void fillCtoCvConfig(CtoCvConfig ctoCvConfig, Date targetDate, Date versionDate);

	/**
	 * Return the unique CTO forecast for the product, geography (region), and
	 * ODM if there is one
	 * 
	 * @param productKey
	 * @param geographyName
	 * @param odmName
	 * @param targetDate
	 *            Always Monday
	 * @param versionDate
	 * @return CTO forecast without CV breakdown
	 */
	public CtoCvConfig getCtoForecast(String productKey, String geographyName, String odmName, Date targetDate, Date versionDate);

	public List<MtmGeographyOdmCvQuantity> getAllCtoForecastCvQuantityInMonth(Date targetDate, Date versionDate);

	public List<MtmGeographyOdmCvQuantity> getAllMtmForecastCvQuantityInMonth(Date targetDate, Date versionDate);

	public List<Forecast> getCausedByForecastByForecastData(Date targetDate, Date versionDate, List<NpiWeeklyComponentCommitmentOnForecast> list);

	public List getForecast(int waveId, Date verionDate);

	List<NpiForecast> getForecastRateMonththree(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2,
			String shortegeCode_1, String shortegeCode_2, NpiDnsEntry dns,Integer forecastDate, Integer dnsversion);

	List<NpiForecast> getForecastRateMonthtwo(Integer month_1, Integer month_2,
			Integer year_1, Integer year_2, String shortegeCode_1, NpiDnsEntry dns,Integer forecastDate, Integer dnsversion);

	public List<NpiForecast> getNpiForecastByTargetDate(Integer cvKey,
			Integer versionDateKey, Integer targetDateKey, Integer i);

	public List<NpiForecast> getForecastRateMonthone(Integer month_1,
			Integer month_2, Integer year_1, Integer year_2, NpiDnsEntry dns,Integer forecastDate, Integer dnsversion);

	public Integer get2MonthsAgoMondayOfMonthkDate(int targetDateKey);

	public Integer get3MonthsAgo4WeeksMondayOfMonthkDate(int targetDateKey);

	public List getForecastByVersionDate(Integer forecastDate);

}
