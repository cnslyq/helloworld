package com.lenovo.bi.service.common;

public class ConfigurableContext {

	private static int successStatus = 7;
	
}
