package com.lenovo.bi.service.npi;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.dto.Defect;
import com.lenovo.bi.exception.BusinessException;
import com.lenovo.bi.form.npi.ttm.OverviewSearchForm;
import com.lenovo.bi.form.npi.ttv.SearchOutlookDataForm;
import com.lenovo.bi.form.simulation.NPISimulationPreviewData;
import com.lenovo.bi.model.NpiOrder;
import com.lenovo.bi.view.npi.ProductWave;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.ttv.ProjectOutLookView;
import com.lenovo.bi.view.npi.ttv.TtvGridProduct;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvDetractorCodeView;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.TtvGridTrackingCauses;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.odm.TtvGridCapacityCausesView;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.odm.TtvGridOdmDetailsView;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.supply.TtvGridSupplyDetailsView;
import com.lenovo.bi.view.npi.ttv.outlook.tracking.tooling.TtvGridToolingDetailsView;
import com.lenovo.common.model.Pager;

/**
 * 
 * 
 * @author henry_lian
 * 
 */
public interface TTVService {

	/**
	 * this method for ttm/my products grid use
	 * 
	 * @param form
	 * @return
	 */
	public Pager<TtvGridProduct> getProductsByConditions(OverviewSearchForm form);

	/**
	 * this method for ttv/my products pie chart use
	 * 
	 * @param form
	 * @return
	 */
	public PieChartView getChartDataByConditions(OverviewSearchForm form);

	/**
	 * this method for ttv/my products pillar chart use,return outlook json
	 * string by weekly
	 * 
	 * @param form
	 * @return
	 */
	public MSColumnChartView getOutlookJsonChartDataByWeekly(SearchOutlookDataForm form, Boolean isPreview, List<NpiOrder> orders, boolean isSnapshot) throws ParseException;

	public MSColumnChartView getOutlookJsonChartDataByWeekly(SearchOutlookDataForm form, Boolean isPreview, List<NpiOrder> orders, boolean isSnapshot,Map<String,NPISimulationPreviewData> previewDataMap) throws ParseException;

	
	public MSColumnChartView getSgaOutlookJsonChartDataByWeekly(SearchOutlookDataForm form, Boolean isPreview, List<NpiOrder> orders, boolean isSnapshot) throws ParseException, BusinessException;
	public MSColumnChartView getSgaOutlookJsonChartDataByWeekly(SearchOutlookDataForm form, Boolean isPreview, List<NpiOrder> orders, boolean isSnapshot,Map<String,NPISimulationPreviewData> previewDataMap) throws ParseException, BusinessException;


	/**
	 * this method for ttv/my products pillar chart use,return outlook json
	 * string by daily
	 * 
	 * @param form
	 * @return
	 */
	public ColumnChartView getOutlookJsonChartDataByDaily(SearchOutlookDataForm form, String isPreview, String selectedExcludeOrderIds) throws ParseException;

	/**
	 * this method for ttv/my products pillar chart use,return short bars json
	 * string
	 * 
	 * @param form
	 * @return
	 */
	public ColumnChartView getShortBarJsonChartDataByConditions(SearchOutlookDataForm form);

	/**
	 * this method for ttv/outlook pie chart use,return main detractor chart
	 * 
	 * @param form
	 * @returnget
	 */
	/*public PieChartView getDetractorMainPieChart(SearchOutlookDataForm form);*/
	
	/*public TtvDetractorCodeView getDetractorMainPie(SearchOutlookDataForm form);*/
	
	public TtvDetractorCodeView getDetractorCodeView(SearchOutlookDataForm form);

	/**
	 * this method for ttv/outlook pie chart use,return main detractor chart
	 * 
	 * @param form
	 * @return
	 */
	/*public PieChartView getDetractorSubPieChart(SearchOutlookDataForm form);*/

	/**
	 * this method for ttv/outlook tracking cause
	 * 
	 * @param form
	 * @return
	 */
	public TtvGridTrackingCauses getTrackingCausesByWeek(SearchOutlookDataForm form);

	public TtvGridTrackingCauses getSgaTrackingCausesByWeek(SearchOutlookDataForm form);

	/**
	 * this method for ttv/outlook detractor code
	 * 
	 * @param form
	 * @return
	 */
	/*public List<TtvGridDetractorCodeView> getDetractorDataByWeek(SearchOutlookDataForm form);*/

	/**
	 * this method for project outlook
	 * 
	 * @param proWave
	 * @return
	 */
	public ProjectOutLookView getProjectOutLook(ProductWave proWave) throws ParseException;
	
	/**
	 * 
	 * 
	 * @param proWave
	 * @param versionDate
	 * @return
	 * @throws ParseException
	 */
	public ProjectOutLookView getProjecteView(ProductWave proWave, Date versionDate) throws ParseException;

	/**
	 * this method for project outlook
	 * 
	 * @param proWave
	 * @return
	 */
	public ProjectOutLookView getProjectSummary(ProductWave proWave) throws ParseException;

	public ProjectOutLookView getProjectSnapshot(ProductWave proWave, Date versionDate) throws ParseException;

	/**
	 * this method for ttv/my products pillar chart use,return outlook json
	 * string by daily
	 * 
	 * @param waveId
	 * @return
	 */
	public MSColumnChartView getSummaryJsonChartData(Integer waveId, boolean showSga, boolean fpy) throws ParseException;

	public MSColumnChartView getSgaSummaryJsonChartData(Integer waveId, boolean showSle, boolean fpy) throws ParseException, BusinessException;

	/**
	 * this method for project outlook: ODM Capacity
	 * 
	 * @param form
	 * @return
	 */
	public ProjectOutLookView getOdmCapacity(ProductWave pw) throws ParseException;

	/**
	 * this method for ttv/outlook/odm pie chart use,return main detractor chart
	 * 
	 * @param form
	 * @returnget
	 */
	public PieChartView getOdmMainPieChart(SearchOutlookDataForm form);

	/**
	 * this method for ttv/my products pillar chart use,return odm detail json
	 * string by weekly
	 * 
	 * @param form
	 * @return
	 */
	public ColumnChartView getOdmDetailColumnDataByWeekly(SearchOutlookDataForm form, String isPreview, String selectedExcludeOrderIds) throws ParseException;

	/**
	 * this method for ttv/my products pillar chart use,return odm detail json
	 * string by weekly
	 * 
	 * @param form
	 * @return
	 */
	public List<TtvGridOdmDetailsView> getOdmDetailsDataByWeek(SearchOutlookDataForm form, String isPreview, String selectedExcludeOrderIds)
			throws ParseException;

	/**
	 * this method for ttv/outlook odm capacity tracking cause
	 * 
	 * @param form
	 * @return
	 */
	public TtvGridCapacityCausesView getOdmCausesByWeek(SearchOutlookDataForm form);

	/**
	 * this method for ttv/my products pillar chart use,return odm capacity
	 * defects
	 * 
	 * @param form
	 * @return
	 */
	public List<Defect> getOdmDefectsByWeek(SearchOutlookDataForm form, String isPreview, String selectedExcludeOrderIds) throws ParseException;

	/**
	 * this method for project outlook: ODM Capacity
	 * 
	 * @param form
	 * @return
	 */
	public ProjectOutLookView getSupplyMaterialShortage(ProductWave pw) throws ParseException;

	/**
	 * this method for ttv/my products pillar chart use,return odm detail json
	 * string by weekly
	 * 
	 * @param form
	 * @return
	 */
	public ColumnChartView getSupplyDetailColumnDataByWeekly(SearchOutlookDataForm form, String isPreview, String selectedExcludeOrderIds)
			throws ParseException;

	/**
	 * this method for ttv/outlook/supply pie chart use,return main supply pie
	 * chart
	 * 
	 * @param form
	 * @returnget
	 */
	public PieChartView getSupplyMainPieChart(SearchOutlookDataForm form);

	/**
	 * this method for ttv/outlook/supply pie chart use,return C Level supply
	 * pie chart
	 * 
	 * @param form
	 * @returnget
	 */
	public PieChartView getSupplyCLevelPieChart(SearchOutlookDataForm form);

	/**
	 * this method for ttv/outlook/supply pie chart use,return V Level supply
	 * pie chart
	 * 
	 * @param form
	 * @returnget
	 */
	public PieChartView getSupplyVLevelPieChart(SearchOutlookDataForm form);

	/**
	 * this method for ttv/my products pillar chart use,return supply detail
	 * weekly
	 * 
	 * @param form
	 * @return
	 */
	public List<TtvGridSupplyDetailsView> getSupplyDetailsDataByWeek(SearchOutlookDataForm form, String isPreview, String selectedExcludeOrderIds)
			throws ParseException;

	/**
	 * this method for ttv/outlook supply capacity tracking cause
	 * 
	 * @param form
	 * @return
	 */
	public TtvGridCapacityCausesView getSupplyCausesByWeek(SearchOutlookDataForm form);

	/**
	 * this method for project outlook: ODM Capacity
	 * 
	 * @param form
	 * @return
	 */
	public ProjectOutLookView getToolingCapacity(ProductWave pw) throws ParseException;

	/**
	 * this method for ttv/outlook/Tooling pie chart use,return main detractor
	 * chart
	 * 
	 * @param form
	 * @returnget
	 */
	public PieChartView getToolingMainPieChart(SearchOutlookDataForm form);

	/**
	 * this method for ttv/my products pillar chart use,return Tooling detail
	 * json string by weekly
	 * 
	 * @param form
	 * @return
	 */
	public ColumnChartView getToolingDetailColumnDataByWeekly(SearchOutlookDataForm form, String isPreview, String selectedExcludeOrderIds)
			throws ParseException;

	/**
	 * this method for ttv/my products pillar chart use,return Tooling detail
	 * json string by weekly
	 * 
	 * @param form
	 * @return
	 */
	public List<TtvGridToolingDetailsView> getToolingDetailsDataByWeek(SearchOutlookDataForm form, String isPreview, String selectedExcludeOrderIds)
			throws ParseException;

	/**
	 * this method for ttv/my products pillar chart use,return Tooling detail
	 * json string by weekly
	 * 
	 * @param form
	 * @return
	 */
	public ColumnChartView getToolingColumnChartByCover(SearchOutlookDataForm form) throws ParseException;

	/**
	 * this method for ttv/outlook Tooling capacity tracking cause
	 * 
	 * @param form
	 * @return
	 */
	public TtvGridCapacityCausesView getToolingCausesByWeek(SearchOutlookDataForm form);


}
