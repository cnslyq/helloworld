package com.lenovo.bi.dao.npi.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.dao.npi.NPIProjectWaveDao;
import com.lenovo.bi.dto.NPIWaveInfo;
import com.lenovo.bi.dto.ProductKeyPmsWaveId;

@SuppressWarnings("rawtypes")
@Repository
public class NpiProjectWaveDaoImpl extends HibernateBaseDaoImplDw implements NPIProjectWaveDao{
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ProductKeyPmsWaveId> getProductKeyPmsWaveIdList() {
		StringBuffer sql = new StringBuffer("select p.ProductKey, w.PMSWaveIDAlternateKey as pmsWaveId ")
			.append("from DimNPIProject p, DimNPIWave w, DimProduct pr ")
			.append("where w.NPIProjectKey = p.NPIProjectKey ")
			.append("and p.ProductKey = pr.ProductKey ")
			.append("and p.IsCurrent <> 0 ")
			.append("and w.IsCurrent <> 0 ");
	
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(ProductKeyPmsWaveId.class));
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public String getProductKeyByPmsWaveId(Integer waveId) {
		StringBuffer sql = new StringBuffer("select p.ProductKey ")
		.append("from DimNPIProject p, DimNPIWave w, DimProduct pr ")
		.append("where w.NPIProjectKey = p.NPIProjectKey ")
		.append("and p.ProductKey = pr.ProductKey ")
		.append("and p.IsCurrent <> 0 ")
		.append("and w.IsCurrent <> 0 ")
		.append("and w.PMSWaveIDAlternateKey = " + waveId);

		Query query = getSession().createSQLQuery(sql.toString());
		List<String> productKeyList = query.list();
		if(CollectionUtils.isNotEmpty(productKeyList)){
			return String.valueOf(productKeyList.get(0));
		}else{
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NPIWaveInfo> getProjectDetail(Date versionDate) {
		StringBuffer sql = new StringBuffer("select nw.PMSWaveIDAlternateKey as pmsWaveId, np.PMSProjectIDAlternateKey as pmsProjectId, dt.FullDateAlternateKey as startDate,dt1.FullDateAlternateKey as endDate, ")
		.append("pd.ProductEnglishName as productName, nw.currentPhase, nw.NPIWaveName as waveName,nw.TTVTarget as ttvTarget,nw.SGATTVTarget as sgaTtvTarget, pf.ProductFamilyEnglishName as family, np.Manager as pm,phase.ttmTargetDate,")
		.append("phase.phaseNumber, phase.ttmSignOffDate ,phase.ttvTargetDate,phase.ttvSignOffDate,phase.svtPlanDate,phase.sovpPlanDate,phase.sgaTtvTargetDate,phase.sgaTtvSignOffDate, ")
		.append("nw.obeTarget,nw.fpyTarget ")
		.append("from DimNPIProject np ")
		.append("inner join DimProduct pd on np.ProductKey = pd.ProductKey ")
		.append("inner join DimTime dt on np.StartDateKey = dt.TimeKey ")
		.append("left join DimTime dt1 on np.EndDateKey = dt1.TimeKey ")
		.append("left join DimProductFamily pf on pf.ProductFamilyKey = pd.ProductFamilyKey ")
		.append("inner join DimNPIWave nw on nw.NPIProjectKey = np.NPIProjectKey ")
		.append("left join ")
		.append("(select dp.ParentNPIWaveKey,")
		.append("Max(case when dp.BuiltinCode = 'SS' then t2.FullDateAlternateKey end) as 'ttmTargetDate',")
		.append("Max(case when dp.BuiltinCode = 'SS' then t1.FullDateAlternateKey end) as 'ttmSignOffDate',")
		.append("Max(case when dp.BuiltinCode = 'SLE' then t2.FullDateAlternateKey end) as 'ttvTargetDate',")
		.append("Max(case when dp.BuiltinCode = 'SLE' then t1.FullDateAlternateKey end) as 'ttvSignOffDate',")
		.append("Max(case when dp.BuiltinCode = 'SGA' then t2.FullDateAlternateKey end) as 'sgaTtvTargetDate',")
		.append("Max(case when dp.BuiltinCode = 'SGA' then t1.FullDateAlternateKey end) as 'sgaTtvSignOffDate',")
		.append("Max(case when dp.BuiltinCode = 'SVT' then t3.FullDateAlternateKey end) as 'svtPlanDate',")
		.append("Max(case when dp.BuiltinCode = 'SOVP' then t1.FullDateAlternateKey end) as 'sovpPlanDate', ")
		.append("COUNT(dp.ParentNPIWaveKey) as phaseNumber ")
		.append("from dimnpiphase dp ")
		.append("left join dimtime t1 on t1.TimeKey = dp.ActualMilestoneDateKey ")
		.append("left join dimtime t2 on t2.TimeKey = dp.planMilestoneDateKey ")
		.append("left join dimtime t3 on t3.TimeKey = dp.PlanExitDateKey ")
		.append("where dp.IsCurrent = 1 ")
		.append("group by dp.ParentNPIWaveKey ")
		.append(") as phase on phase.ParentNPIWaveKey = nw.NPIWaveKey ")
		.append("where np.IsCurrent = 1 and nw.IsCurrent = 1");

		Query q = getSession().createSQLQuery(sql.toString())
		.setResultTransformer(Transformers.aliasToBean(NPIWaveInfo.class));
		
		return q.list();
	}
}
