package com.lenovo.bi.service.sc;

import java.text.ParseException;
import java.util.Date;
import java.util.Map;

import com.lenovo.bi.form.sc.mwd.SearchMWDForm;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView;

public interface MWDService {
	
	public MSColumnChartView getOverviewChart(SearchMWDForm form) throws ParseException;
	
	public ColumnChartView getRemarkChart(SearchMWDForm form) throws ParseException;
	
	public Map<String,Object> getMWDDetail(SearchMWDForm form) throws ParseException ;
	
	public Date getMRPRunTime();
}
