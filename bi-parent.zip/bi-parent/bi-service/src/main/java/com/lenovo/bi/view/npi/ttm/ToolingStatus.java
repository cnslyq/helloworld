package com.lenovo.bi.view.npi.ttm;
/**
 * ttm detail tooling pojo
 * 
 * @author henry_lian
 *
 */
public class ToolingStatus {
	private String cover;
	private String supply;
	private String tech;
	private String boh;
	private String capacity;
	private String signOffDate;
	public String getSupply() {
		return supply;
	}
	public void setSupply(String supply) {
		this.supply = supply;
	}
	public String getTech() {
		return tech;
	}
	public void setTech(String tech) {
		this.tech = tech;
	}
	public String getBoh() {
		return boh;
	}
	public void setBoh(String boh) {
		this.boh = boh;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	public String getSignOffDate() {
		return signOffDate;
	}
	public void setSignOffDate(String signOffDate) {
		this.signOffDate = signOffDate;
	}
	public String getCover() {
		return cover;
	}
	public void setCover(String cover) {
		this.cover = cover;
	}

}
