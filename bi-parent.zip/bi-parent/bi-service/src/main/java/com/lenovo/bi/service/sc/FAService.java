package com.lenovo.bi.service.sc;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.lenovo.bi.form.sc.fa.SearchFaForm;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.sc.fa.FADetailView;

public interface FAService {
	
	public ColumnChartView getOverviewChart(SearchFaForm form) throws ParseException;
	
	public ColumnChartView getRemarkChart(SearchFaForm form) throws ParseException;
	
	public PieChartView getOverviewPieChart(SearchFaForm form) throws ParseException;
	
	public List<FADetailView> getFaDetail(SearchFaForm form);
	
	public List<FADetailView> getFaGEODetail(SearchFaForm form);
	
	public List<FADetailView> getFaPieDetail(SearchFaForm form);
	
	public long getFaDetailCount(SearchFaForm form);
	
	public long getFaPieDetailCount(SearchFaForm form);
	
	public String getLackProduct(SearchFaForm form) throws ParseException;
	
	public String getLackRegion(SearchFaForm form) throws ParseException;
	
	public String getGeo(SearchFaForm form) throws ParseException;
	
	public Map<String,Object> getFADetailExprot(SearchFaForm form);
}
