package com.lenovo.bi.dao.npi.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.formula.functions.T;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.enumobj.TTVPhase;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnForecast;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnOrder;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnProduct;

@Repository
@SuppressWarnings("unchecked")
public class NpiCommittedCVAllocatorDaoBiImpl extends HibernateBaseDaoImplBi<T> {

	/**
	 * get commit CV on product
	 * @param versionDate
	 * @param initDate
	 * @param financeEndDate
	 * @return
	 */
	public List<NpiWeeklyComponentCommitmentOnProduct> getCommitmentOnProduct(Date versionDate, Date initDate, Date financeEndDate){
		StringBuffer sql = new StringBuffer();
		sql.append(" select * from BI_WeeklyComponentCommitmentOnProduct ");
		sql.append(" where versionDate = :versionDate ");
		sql.append(" and targetDate between :initDate and :financeEndDate ");
		Query query = getSession().createSQLQuery(sql.toString()).addScalar("id", IntegerType.INSTANCE)
				.addScalar("globalCVKey", IntegerType.INSTANCE)
				.addScalar("commitment", LongType.INSTANCE)
				.addScalar("productKey", IntegerType.INSTANCE)
				.addScalar("targetDate", IntegerType.INSTANCE)
				.addScalar("versionDate", IntegerType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(NpiWeeklyComponentCommitmentOnProduct.class));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		query.setParameter("versionDate", Integer.parseInt(sdf.format(versionDate)));
		query.setParameter("initDate", Integer.parseInt(sdf.format(initDate)));
		query.setParameter("financeEndDate", Integer.parseInt(sdf.format(financeEndDate)));
		return query.list();
	}
	
	/**
	 * save order allocation results
	 * @param commitOnOrderList
	 */
	public void saveCommitmentOnOrder(List<NpiWeeklyComponentCommitmentOnOrder> commitOnOrderList){
		for(NpiWeeklyComponentCommitmentOnOrder commitOnOrder : commitOnOrderList){
			getSession().save(commitOnOrder);
		}
		getSession().flush();
	}
	
	/**
	 * save forecast allocation results
	 * @param commitOnForecastList
	 */
	public void saveCommitmentOnForecast(List<NpiWeeklyComponentCommitmentOnForecast> commitOnForecastList){
		for(NpiWeeklyComponentCommitmentOnForecast commitForecast : commitOnForecastList){
			getSession().save(commitForecast);
		}
		getSession().flush();
	}
	
	/**
	 * update order allocation results
	 * @param commitOnOrderList
	 */
	public void updateCommitmentOnOrder(List<NpiWeeklyComponentCommitmentOnOrder> commitOnOrderList){
		for(NpiWeeklyComponentCommitmentOnOrder commitOnOrder : commitOnOrderList){
			//getSession().update(commitOnOrder);
			getSession().merge(commitOnOrder);
		}
		getSession().flush();
	}
	
	/**
	 * update forecast allocation results
	 * @param commitOnForecastList
	 */
	public void updateCommitmentOnForecast(List<NpiWeeklyComponentCommitmentOnForecast> commitOnForecastList){
		for(NpiWeeklyComponentCommitmentOnForecast commitForecast : commitOnForecastList){
			//getSession().update(commitForecast);
			getSession().merge(commitForecast);
		}
		getSession().flush();
	}
	
	/**
	 * clean old data
	 * @param versionDate
	 */
	public void cleanDataByVersionDate(Date versionDate){
		deleteDataForVersionDate("NpiWeeklyComponentCommitmentOnOrder", versionDate);
		deleteDataForVersionDate("NpiWeeklyComponentCommitmentOnForecast", versionDate);
	}
	
	/**
	 * update supplyCommit in ttv weekly details
	 * @param versionDate
	 * @param dateWaveCommitMap
	 * @param ttvPhase
	 */
	public void updateTtvWeeklyDetail(Date versionDate, Map<Date, Map<Integer, Integer>> dateWaveCommitMap, 
			String ttvPhase){
		StringBuffer sql = new StringBuffer();
		if(TTVPhase.sle.name().equalsIgnoreCase(ttvPhase)){
			sql.append(" update BI_TTVWeeklyDetail set supplyCommit = :supplyCommit, lastModifiedDate = getdate() ");
		}else if(TTVPhase.sga.name().equalsIgnoreCase(ttvPhase)){
			sql.append(" update BI_SGATTVWeeklyDetail set supplyCommit = :supplyCommit, lastModifiedDate = getdate() ");
		}
		sql.append(" where versionDate = :versionDate ");
		sql.append(" and targetDate = :targetDate ");
		sql.append(" and pmsWaveId = :pmsWaveId ");
		for(Date targetDate : dateWaveCommitMap.keySet()){
			Map<Integer, Integer> waveCommitMap = dateWaveCommitMap.get(targetDate);
			for(int pmsWaveId : waveCommitMap.keySet()){
				int supplyCommit = waveCommitMap.get(pmsWaveId);
				Query query = getSession().createSQLQuery(sql.toString());
				query.setParameter("supplyCommit", supplyCommit);
				query.setParameter("versionDate", versionDate);
				query.setParameter("targetDate", targetDate);
				query.setParameter("pmsWaveId", pmsWaveId);
				query.executeUpdate();
			}
		}
		getSession().flush();
	}
	
	/**
	 * get unfulfilled order allocation results
	 * @param versionDate
	 * @param targetDate
	 * @param ttvPhase
	 * @return
	 */
	//public List<NpiWeeklyComponentCommitmentOnOrder> getUnfulfilledOrder(Date versionDate, Date targetDate, String ttvPhase){
	public List<NpiWeeklyComponentCommitmentOnOrder> getUnfulfilledOrder(Date versionDate, Integer pmsWaveId, String ttvPhase){
		StringBuffer sql = new StringBuffer();
		sql.append(" select id, productKey, pmsWaveId, mtmKey, bomNumber, geographyKey, geographyName, odmKey, odmName, quantity, orderLabel, ");
		sql.append(" abnormalQuantity, materialShortage, coverAShortage, coverBShortage, coverCShortage, coverDShortage, odmShortage, ");
		sql.append(" ttvPhase, targetDate, versionDate from BI_WeeklyComponentCommitmentOnOrder ");
		sql.append(" where materialShortage = 1 ");
		sql.append(" and versionDate = :versionDate ");
		//sql.append(" and targetDate = :targetDate ");
		sql.append(" and pmsWaveId = :pmsWaveId ");
		sql.append(" and ttvPhase = :ttvPhase ");
		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(NpiWeeklyComponentCommitmentOnOrder.class));
		query.setParameter("versionDate", versionDate);
		//query.setParameter("targetDate", targetDate);
		query.setParameter("pmsWaveId", pmsWaveId);
		query.setParameter("ttvPhase", ttvPhase);
		return query.list();
	}
	
	/**
	 * get unfulfilled forecast allocation results
	 * @param versionDate
	 * @param targetDate
	 * @param ttvPhase
	 * @return
	 */
	//public List<NpiWeeklyComponentCommitmentOnForecast> getUnfulfilledForecast(Date versionDate, Date targetDate, String ttvPhase){
	public List<NpiWeeklyComponentCommitmentOnForecast> getUnfulfilledForecast(Date versionDate, Integer pmsWaveId, String ttvPhase){
		StringBuffer sql = new StringBuffer();
		sql.append(" select id, productKey, pmsWaveId, mtmKey, bomNumber, geographyKey, geographyName, odmKey, odmName, quantity, forecastLabel, ");
		sql.append(" abnormalQuantity, materialShortage, coverAShortage, coverBShortage, coverCShortage, coverDShortage, odmShortage, ");
		sql.append(" ttvPhase, targetDate, versionDate from BI_WeeklyComponentCommitmentOnForecast ");
		sql.append(" where materialShortage = 1 ");
		sql.append(" and versionDate = :versionDate ");
		//sql.append(" and targetDate = :targetDate ");
		sql.append(" and pmsWaveId = :pmsWaveId ");
		sql.append(" and ttvPhase = :ttvPhase ");
		Query query = getSession().createSQLQuery(sql.toString())
				.setResultTransformer(Transformers.aliasToBean(NpiWeeklyComponentCommitmentOnForecast.class));
		query.setParameter("versionDate", versionDate);
		//query.setParameter("targetDate", targetDate);
		query.setParameter("pmsWaveId", pmsWaveId);
		query.setParameter("ttvPhase", ttvPhase);
		return query.list();
	}
	
	
	/*
	public void updateTtvWeeklyDetail(Date versionDate){
		Query query = getUpdateQuery(versionDate, "BI_TTVWeeklyDetail", "sle");
		query.executeUpdate();
		getSession().flush();
	}
	
	public void updateSGATtvWeeklyDetail(Date versionDate){
		Query query = getUpdateQuery(versionDate, "BI_SGATTVWeeklyDetail", "sga");
		query.executeUpdate();
		getSession().flush();
	}
	
	private Query getUpdateQuery(Date versionDate, String tableName, String ttvPhase){
		StringBuffer sql = new StringBuffer();
		sql.append(" update wd  ");
		sql.append("    set supplyCommit = isnull(o.orderQuantity, 0) + isnull(f.forecastQuantity, 0), lastModifiedDate = getdate() ");
		sql.append("   from " + tableName + " as wd ");
		sql.append("  inner join (select sum(quantity) orderQuantity, versionDate, targetDate, pmsWaveId ");
		sql.append("                from BI_WeeklyComponentCommitmentOnOrder ");
		sql.append("               where datediff(day, versionDate, ?) = 0 ");
		sql.append("                 and ttvPhase = '" + ttvPhase+ "' ");
		sql.append("                 and materialShortage = 0 ");
		sql.append("               group by versionDate, targetDate, pmsWaveId) o ");
		sql.append("          on wd.versionDate = o.versionDate ");
		sql.append("         and wd.targetDate = o.targetDate ");
		sql.append("         and wd.pmsWaveId = o.pmsWaveId ");
		sql.append("  inner join (select sum(quantity) forecastQuantity, versionDate, targetDate, pmsWaveId ");
		sql.append("                from BI_WeeklyComponentCommitmentOnForecast ");
		sql.append("               where datediff(day, versionDate, ?) = 0 ");
		sql.append("                 and ttvPhase = '" + ttvPhase+ "' ");
		sql.append("                 and materialShortage = 0 ");
		sql.append("               group by versionDate, targetDate, pmsWaveId) f ");
		sql.append("          on wd.versionDate = f.versionDate ");
		sql.append("         and wd.targetDate = f.targetDate ");
		sql.append("         and wd.pmsWaveId = f.pmsWaveId ");
		
		Query query = getSession().createSQLQuery(sql.toString());
		query.setParameter(0, versionDate);
		query.setParameter(1, versionDate);
		return query;
	}
	*/
	
}
