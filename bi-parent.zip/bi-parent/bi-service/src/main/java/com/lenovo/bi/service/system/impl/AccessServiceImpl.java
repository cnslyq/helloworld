package com.lenovo.bi.service.system.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.lenovo.bi.dao.privileges.access.AccessDao;
import com.lenovo.bi.dao.privileges.dict.DictionaryDao;
import com.lenovo.bi.dto.privilege.PrivilegeTree;
import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.system.GroupPrivilege;
import com.lenovo.bi.model.system.RolePrivilege;
import com.lenovo.bi.service.system.AccessService;
import com.lenovo.bi.view.system.access.GroupPrivilegeDetailView;
import com.lenovo.bi.view.system.access.RolesDetailView;
import com.lenovo.bi.view.system.dictionary.GroupDetailView;
import com.lenovo.bi.view.system.dictionary.PrivilegeDetailView;
import com.lenovo.common.model.Pager;
import com.lenovo.common.model.PagerInformation;

@Service
public class AccessServiceImpl implements AccessService {

	@Inject
	private AccessDao accessDao;
	
	@Inject
	private DictionaryDao dictDao;

	@Override
	public String getRoleTreeJson(String roleId){
		
		List<PrivilegeTree> treeList = accessDao.getRolePrivilegeTreeList(roleId);
		for(int i=0; i<treeList.size(); i++) {
			PrivilegeTree privilegeTree = treeList.get(i);
			privilegeTree.setType("ProjectRole");
			if(roleId.equals(privilegeTree.getRoleId())) {
				privilegeTree.setChecked(true);
			}
		}
		String jsonStr = new Gson().toJson(treeList);
		/*ObjectMapper mapper = new ObjectMapper();
		String jsonStr = mapper.writeValueAsString(treeList);*/
		
		//System.out.println("the return json is: " + jsonStr);
		return jsonStr;
	}
	
	@Override
	public Pager<RolesDetailView> listRoles(DictSearchForm form) {
		Pager<RolesDetailView> pager = new Pager<RolesDetailView>();
		PagerInformation pageInfo = new PagerInformation();
		pager.setPagerInfo(pageInfo);
		pageInfo.setCurrentPage(form.getCurrentPage());
		pageInfo.setPageSize(10);
		List<RolesDetailView> roleList = accessDao.listRoles(form, pager.getPagerInfo());
		pager.setDatas(roleList);
		
		int recordCount = accessDao.getRoleDetailCountByConditions(form);
		pageInfo.setRecordCount(recordCount);
		form.setRecordCount(recordCount);
		
		return pager;
	}
	
	@Override
	public Pager<PrivilegeDetailView> listPrivileges(DictSearchForm form) {
		Pager<PrivilegeDetailView> pager = new Pager<PrivilegeDetailView>();
		PagerInformation pageInfo = new PagerInformation();
		pager.setPagerInfo(pageInfo);
		pageInfo.setCurrentPage(form.getCurrentPage());
		pageInfo.setPageSize(10);
		List<PrivilegeDetailView> groupList = accessDao.listPrivilegeDetailList(form, pager.getPagerInfo());
		pager.setDatas(groupList);
		
		int recordCount = accessDao.getPrivilegeDetailCountByConditions(form);
		pageInfo.setRecordCount(recordCount);
		form.setRecordCount(recordCount);
		
		return pager;
	}

	@Override
	public void saveRolePrivilege(RolePrivilege[] rolePrivilegeArr) {
		for(int j=0; j<rolePrivilegeArr.length; j++) {
			rolePrivilegeArr[j].setLastModifiedBy("pmsadmin");
			rolePrivilegeArr[j].setLastModifiedDate(DateUtils.addDays(new Date(), 0));
		}
		
		accessDao.saveRolePrivilege(rolePrivilegeArr);
	}
	
	@Override
	public void savePrivilegesForRole(String privilegeId, String roleIds) {
		//String[] roleIdArr = new String[9];
		String[] roleIdArr = roleIds.split(",");
		List<RolePrivilege> rolePrivilegeList = new ArrayList<RolePrivilege>();
		for(int i=0; i<roleIdArr.length; i++) {
			RolePrivilege rolePrivilege = new RolePrivilege();
			rolePrivilege.setPrivilegeId(Integer.parseInt(privilegeId));
			rolePrivilege.setRoleId(Integer.parseInt(roleIdArr[i]));
			rolePrivilege.setLastModifiedBy("pmsadmin");
			rolePrivilege.setLastModifiedDate(DateUtils.addDays(new Date(), 0));
			rolePrivilegeList.add(rolePrivilege);
		}
		accessDao.savePrivilegesForRole(Integer.parseInt(privilegeId),rolePrivilegeList);
	}
	

	@Override
	public List<RolePrivilege> listRolePrivilege(Integer roleId) {
		return accessDao.listRolePrivilege(roleId);
	}
	
	@Override
	public List<RolePrivilege> listRolePrivileges() {
		return accessDao.listRolePrivileges();
	}

	@Override
	public void deleteRolePrivilegeByRole(Integer roleId) {

		accessDao.deleteRolePrivilegeByRole(roleId);
	}
	
	@Override
	public void deleteRolePrivilegeByPrivilege(Integer roleId) {

		accessDao.deleteRolePrivilegeByPrivilege(roleId);
	}

	@Override
	public List<RolesDetailView> listRolesForPrivilege(Integer privilegeId) {
		List<RolesDetailView> roleList = accessDao.listRolesForPrivilege(privilegeId);
		return roleList;
	}

	@Override
	public List<RolesDetailView> listRoles() {
		return accessDao.listRoles();
	}

	@Override
	public List<PrivilegeDetailView> listPrivilegesForRole() {
		return accessDao.listPrivilegesForRole();
	}

	@Override
	public String getGroupTreeJson(String groupId) {
		List<PrivilegeTree> treeList = accessDao.getGroupPrivilegeTreeList(groupId);
		for(int i=0; i<treeList.size(); i++) {
			PrivilegeTree privilegeTree = treeList.get(i);
			privilegeTree.setType("Orgnization Privilege");
			if(groupId.equals(privilegeTree.getGroupId())) {
				privilegeTree.setChecked(true);
			}
		}
		String jsonStr = new Gson().toJson(treeList);
		/*ObjectMapper mapper = new ObjectMapper();
		String jsonStr = mapper.writeValueAsString(treeList);*/
		
		//System.out.println("the return json is: " + jsonStr);
		return jsonStr;
	}

	@Override
	public void saveGroupPrivilege(GroupPrivilege[] groupPrivilegeArr,String groupId) {
		for(int j=0; j<groupPrivilegeArr.length; j++) {
			groupPrivilegeArr[j].setLastModifiedBy("pmsadmin");
			groupPrivilegeArr[j].setLastModifiedDate(DateUtils.addDays(new Date(), 0));
		}
		
		accessDao.saveGroupPrivilege(groupPrivilegeArr,groupId);
	}

	@Override
	public List<GroupDetailView> listGroups() {
		return accessDao.listGroups();
	}
	
	@Override
	public List<String> listGroupsForExcel() {
		return accessDao.listGroupsForExcel();
	}

	@Override
	public List<GroupPrivilege> listGroupPrivileges() {
		return accessDao.listGroupPrivileges();
	}

	@Override
	public List<PrivilegeDetailView> listPrivilegesForGroup() {
		return accessDao.listPrivilegesForGroup();
	}
	
	@Override
	public List<GroupPrivilegeDetailView> listGroupPrivilegesForExcel(DictSearchForm form) {
		return accessDao.listGroupPrivilegesForExcel(form);
	}
	
	@Override
	public List<GroupDetailView> listGroupsForPrivilege(Integer privilegeId) {
		
		return accessDao.listGroupsForPrivilege(privilegeId);
	}
	
	@Override
	public void savePrivilegesForGroup(String privilegeId, String groupIds) {
		//String[] groupIdArr = new String[9];
		String[] groupIdArr = groupIds.split(",");
		List<GroupPrivilege> groupPrivilegeList = new ArrayList<GroupPrivilege>();
		for(int i=0; i<groupIdArr.length; i++) {
			GroupPrivilege groupPrivilege = new GroupPrivilege();
			groupPrivilege.setPrivilegeId(Integer.parseInt(privilegeId));
			groupPrivilege.setGroupId(Integer.parseInt(groupIdArr[i]));
			groupPrivilege.setLastModifiedBy("pmsadmin");
			groupPrivilege.setLastModifiedDate(DateUtils.addDays(new Date(), 0));
			groupPrivilegeList.add(groupPrivilege);
		}
		accessDao.savePrivilegesForGroup(Integer.parseInt(privilegeId),groupPrivilegeList);
	}
}
