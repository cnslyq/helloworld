package com.lenovo.bi.view.npi.ttv;

public class OrderHitRateView {
	
	
	private String geo;
	private String region;
	private String mtm;
	private String description;
	private String odm;
	private Integer forecast;
	private Integer quantity;
	private Integer upside;
	private Integer downside;
	private Integer offset;
	
	public String getGeo() {
		return geo;
	}
	public void setGeo(String geo) {
		this.geo = geo;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getMtm() {
		return mtm;
	}
	public void setMtm(String mtm) {
		this.mtm = mtm;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getForecast() {
		return forecast;
	}
	public void setForecast(Integer forecast) {
		this.forecast = forecast;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Integer getUpside() {
		return upside;
	}
	public void setUpside(Integer upside) {
		this.upside = upside;
	}
	public Integer getDownside() {
		return downside;
	}
	public void setDownside(Integer downside) {
		this.downside = downside;
	}
	public Integer getOffset() {
		return offset;
	}
	public void setOffset(Integer offset) {
		this.offset = offset;
	}
	public String getOdm() {
		return odm;
	}
	public void setOdm(String odm) {
		this.odm = odm;
	}
}
