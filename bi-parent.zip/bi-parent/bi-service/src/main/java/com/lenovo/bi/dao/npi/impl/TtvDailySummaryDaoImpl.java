package com.lenovo.bi.dao.npi.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplBi;
import com.lenovo.bi.model.TtvDailySummary;
import com.lenovo.bi.util.CalendarUtil;

@Repository
public class TtvDailySummaryDaoImpl extends HibernateBaseDaoImplBi<TtvDailySummary> {

	public List<TtvDailySummary> getNpiDailySummary(int pmsWaveId) {
		return list("from TtvDailySummary where pmsWaveId = :pmsWaveId order by targetDate", "pmsWaveId", new Integer[]{pmsWaveId});		
	}
	
	@SuppressWarnings("unchecked")
	public List<TtvDailySummary> getNpiDailySummary(int pmsWaveId, Date startDate, Date endDate) {
		StringBuffer hql = new StringBuffer("from TtvDailySummary where pmsWaveId = :pmsWaveId and datediff(day, :startDate, targetDate) >= 0 ");
		hql.append("and datediff(day, targetDate, :endDate) >= 0 order by targetDate ");
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("pmsWaveId", pmsWaveId);
		query.setParameter("startDate", startDate);
		query.setParameter("endDate", endDate);
		
		return (List<TtvDailySummary>)query.list();
	}
	
	public void deleteTtvDailySummaryAfter(int pmsWaveId, Date targetDate) {
		targetDate = CalendarUtil.adjustTimeToMidnight(targetDate);
		
		StringBuffer hql = new StringBuffer("delete from TtvDailySummary where pmsWaveId = :pmsWaveId ");
		
		if (targetDate != null) {
			hql.append("and targetDate >= :targetDate");
		}
		
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("pmsWaveId", pmsWaveId);
		
		if (targetDate != null) {
			query.setParameter("targetDate", targetDate);
		}
		
		query.executeUpdate();
	}

	@SuppressWarnings("unchecked")
	public TtvDailySummary getPreviousDailySummary(int pmsWaveId, Date targetDate) {
		StringBuffer hql = new StringBuffer("from TtvDailySummary where pmsWaveId = :pmsWaveId and datediff(day, targetDate, :targetDate) = 1 ");
		
		Query query = getSession().createQuery(hql.toString());
		query.setParameter("pmsWaveId", pmsWaveId);
		query.setParameter("targetDate", targetDate);
		
		List<TtvDailySummary> list = query.list();
		
		if (list.size() > 0) {
			return list.get(0);
		}
		
		return null;
	}

}
