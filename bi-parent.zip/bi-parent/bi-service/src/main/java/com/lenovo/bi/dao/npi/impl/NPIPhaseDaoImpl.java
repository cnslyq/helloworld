package com.lenovo.bi.dao.npi.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateBaseDaoImplDw;
import com.lenovo.bi.model.dw.NPIPhase;

@Repository
public class NPIPhaseDaoImpl extends HibernateBaseDaoImplDw {

	@SuppressWarnings("unchecked")
	public List<NPIPhase> getNPIPhase(String[] builtinCodes, Integer pmsWaveId) {
		String sql = "SELECT p.NPIPhaseName as phaseName ,p.BuiltinCode as builtinCode,t.FullDateAlternateKey as planDate,"
				+ "w.PMSWaveIDAlternateKey as pmsWave FROM DimNPIPhase p join DimTime t on p.PlanMilestoneDateKey = t.TimeKey "
				+ " join DimNPIWave w on w.NPIWaveKey = p.ParentNPIWaveKey where w.IsCurrent = 1 and p.IsCurrent = 1 and p.BuiltinCode in(:builtinCodes) and "
				+ " w.PMSWaveIDAlternateKey = :pmsWaveId order by t.FullDateAlternateKey ";
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.aliasToBean(NPIPhase.class));
		query.setParameterList("builtinCodes", builtinCodes);
		query.setParameter("pmsWaveId", pmsWaveId);
		return query.list();
	}

}
