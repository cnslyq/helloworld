package com.lenovo.bi.batch;

import java.util.Date;

import org.springframework.stereotype.Service;

import com.lenovo.bi.util.CalendarUtil;

/**
 * Run TTV weekly batch with supplied version date.  If version date is null, 
 * use yesterday as version date. 
 * @author ying_han
 *
 */
@Service
//use the new engine to replace the old one
//public class AdhocTtvWeeklyBatch extends TtvWeeklyBatch {
public class AdhocTtvWeeklyBatch extends EnagineWeeklyBatch {	
	private Date versionDate;		

	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}

	@Override
	protected Date retrieveVersionDate() {
		if (versionDate == null) {
			// The default is yesterday.
			Date now = new Date();
			return CalendarUtil.addDays(now, -1);			
		}
		else {
			return versionDate;
		}
	}
}
