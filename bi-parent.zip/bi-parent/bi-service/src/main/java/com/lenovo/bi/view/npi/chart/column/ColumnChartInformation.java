package com.lenovo.bi.view.npi.chart.column;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.lenovo.bi.util.SysConfig;

public class ColumnChartInformation {
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	private String caption;
	private String showValues;
	private String snumberSuffix;
	private String decimals;
	private String setAdaptiveYmin;
	private String setAdaptiveSYmin;
	private String lineThickness;
	private String plotSpacePercent;
	private String numdivlines;
	private String yAxisMinValue;
	private String yAxisMaxValue;
	private String sYAxisMaxValue;
	private String sYAxisMinValue;
	private String formatNumber;
	private String formatNumberScale;
	private String legendIconScale;
	private String showBorder;
	private String canvasBorderThickness;
	private String showZeroPlaneValue;
	private String canvasBorderAlpha;
	private String bgalpha;
	private String plotGradientColor;
	private String legendPosition;
	private String showPlotBorder;
	private String numbersuffix;
	private String alternatevgridalpha;
	private String showsum;
	private String forceDecimals;
	private String useroundedges;
	private String xAxisMaxValue;
	private String showAlternateHGridColor;
	private String pyaxisname;
	private String syaxisname;
	
	
	public String getPyaxisname() {
		return pyaxisname;
	}

	public void setPyaxisname(String pyaxisname) {
		this.pyaxisname = pyaxisname;
	}

	public String getSyaxisname() {
		return syaxisname;
	}

	public void setSyaxisname(String syaxisname) {
		this.syaxisname = syaxisname;
	}

	private String manageLabelOverflow;
	private String chartRightMargin;
	public ColumnChartInformation() {
		this.showValues = SysConfig.COLUMN_CHART_SHOWVALUES;
		this.snumberSuffix = SysConfig.COLUMN_CHART_SNUMBERSUFFIX;
		this.decimals = SysConfig.COLUMN_CHART_DECIMALS;
		this.setAdaptiveYmin = SysConfig.COLUMN_CHART_SETADAPTIVEYMIN;
		this.setAdaptiveSYmin = SysConfig.COLUMN_CHART_SETADAPTIVESYMIN;
		this.lineThickness = SysConfig.COLUMN_CHART_LINETHICKNESS;
		this.plotSpacePercent = SysConfig.COLUMN_CHART_PLOTSPACEPERCENT;
		this.numdivlines = SysConfig.COLUMN_CHART_NUMDIVLINES;
		this.yAxisMinValue = SysConfig.COLUMN_CHART_YAXISMINVALUE;
		this.yAxisMaxValue = SysConfig.COLUMN_CHART_YAXISMAXVALUE;
		this.sYAxisMaxValue = SysConfig.COLUMN_CHART_SYAXISMAXVALUE;
		this.sYAxisMinValue = SysConfig.COLUMN_CHART_SYAXISMINVALUE;
		this.formatNumber = SysConfig.COLUMN_CHART_FORMATNUMBER;
		this.formatNumberScale = SysConfig.COLUMN_CHART_FORMATNUMBERSCALE;
		this.legendIconScale = SysConfig.COLUMN_CHART_LEGENDICONSCALE;
		this.showBorder = SysConfig.COLUMN_CHART_SHOWBORDER;
		this.canvasBorderThickness = SysConfig.COLUMN_CHART_CANVASBORDERTHICKNESS;
		this.showZeroPlaneValue = SysConfig.COLUMN_CHART_SHOWZEROPLANEVALUE;
		this.canvasBorderAlpha = SysConfig.COLUMN_CHART_CANVASBORDERALPHA;
		this.bgalpha = SysConfig.COLUMN_CHART_BGALPHA;
		this.plotGradientColor = SysConfig.COLUMN_CHART_PLOTGRADIENTCOLOR;
		this.legendPosition = SysConfig.COLUMN_CHART_LEGENDPOSITION;
		this.showPlotBorder = SysConfig.COLUMN_CHART_SHOWPLOTBORDER;
		this.numbersuffix = SysConfig.COLUMN_CHART_NUMBERSUFFIX;
		this.alternatevgridalpha = SysConfig.COLUMN_CHART_ALTERNATEVGRIDALPHA;
		this.showsum = SysConfig.COLUMN_CHART_SHOWSUM;
		this.forceDecimals = SysConfig.COLUMN_CHART_FORCEDECIMALS;
		this.useroundedges = "0";
		this.xAxisMaxValue = "";
		this.showAlternateHGridColor = "1";
		this.pyaxisname = "";
		this.syaxisname = "";
		this.manageLabelOverflow = "1";
		this.chartRightMargin = "20";
	}
	
	public String getCaption() {
		return caption;
	}

	public void setCaption(String caption) {
		this.caption = caption;
	}

	public String getShowValues() {
		return showValues;
	}

	public void setShowValues(String showValues) {
		this.showValues = showValues;
	}

	public String getSnumberSuffix() {
		return snumberSuffix;
	}

	public void setSnumberSuffix(String snumberSuffix) {
		this.snumberSuffix = snumberSuffix;
	}

	public String getDecimals() {
		return decimals;
	}

	public void setDecimals(String decimals) {
		this.decimals = decimals;
	}

	public String getSetAdaptiveYmin() {
		return setAdaptiveYmin;
	}

	public void setSetAdaptiveYmin(String setAdaptiveYmin) {
		this.setAdaptiveYmin = setAdaptiveYmin;
	}

	public String getSetAdaptiveSYmin() {
		return setAdaptiveSYmin;
	}

	public void setSetAdaptiveSYmin(String setAdaptiveSYmin) {
		this.setAdaptiveSYmin = setAdaptiveSYmin;
	}

	public String getLineThickness() {
		return lineThickness;
	}

	public void setLineThickness(String lineThickness) {
		this.lineThickness = lineThickness;
	}

	public String getPlotSpacePercent() {
		return plotSpacePercent;
	}

	public void setPlotSpacePercent(String plotSpacePercent) {
		this.plotSpacePercent = plotSpacePercent;
	}

	public String getNumdivlines() {
		return numdivlines;
	}

	public void setNumdivlines(String numdivlines) {
		this.numdivlines = numdivlines;
	}

	public String getyAxisMinValue() {
		return yAxisMinValue;
	}

	public void setyAxisMinValue(String yAxisMinValue) {
		this.yAxisMinValue = yAxisMinValue;
	}

	public String getyAxisMaxValue() {
		return yAxisMaxValue;
	}

	public void setyAxisMaxValue(String yAxisMaxValue) {
		this.yAxisMaxValue = yAxisMaxValue;
	}

	public String getFormatNumber() {
		return formatNumber;
	}

	public void setFormatNumber(String formatNumber) {
		this.formatNumber = formatNumber;
	}

	public String getFormatNumberScale() {
		return formatNumberScale;
	}

	public void setFormatNumberScale(String formatNumberScale) {
		this.formatNumberScale = formatNumberScale;
	}

	public String getLegendIconScale() {
		return legendIconScale;
	}

	public void setLegendIconScale(String legendIconScale) {
		this.legendIconScale = legendIconScale;
	}

	public String getShowBorder() {
		return showBorder;
	}

	public void setShowBorder(String showBorder) {
		this.showBorder = showBorder;
	}

	public String getCanvasBorderThickness() {
		return canvasBorderThickness;
	}

	public void setCanvasBorderThickness(String canvasBorderThickness) {
		this.canvasBorderThickness = canvasBorderThickness;
	}

	public String getShowZeroPlaneValue() {
		return showZeroPlaneValue;
	}

	public void setShowZeroPlaneValue(String showZeroPlaneValue) {
		this.showZeroPlaneValue = showZeroPlaneValue;
	}

	public String getCanvasBorderAlpha() {
		return canvasBorderAlpha;
	}

	public void setCanvasBorderAlpha(String canvasBorderAlpha) {
		this.canvasBorderAlpha = canvasBorderAlpha;
	}

	public String getBgalpha() {
		return bgalpha;
	}

	public void setBgalpha(String bgalpha) {
		this.bgalpha = bgalpha;
	}

	public String getPlotGradientColor() {
		return plotGradientColor;
	}

	public void setPlotGradientColor(String plotGradientColor) {
		this.plotGradientColor = plotGradientColor;
	}

	public String getLegendPosition() {
		return legendPosition;
	}

	public void setLegendPosition(String legendPosition) {
		this.legendPosition = legendPosition;
	}

	public String getShowPlotBorder() {
		return showPlotBorder;
	}

	public void setShowPlotBorder(String showPlotBorder) {
		this.showPlotBorder = showPlotBorder;
	}

	public String getsYAxisMaxValue() {
		return sYAxisMaxValue;
	}

	public void setsYAxisMaxValue(String sYAxisMaxValue) {
		this.sYAxisMaxValue = sYAxisMaxValue;
	}

	public String getsYAxisMinValue() {
		return sYAxisMinValue;
	}

	public void setsYAxisMinValue(String sYAxisMinValue) {
		this.sYAxisMinValue = sYAxisMinValue;
	}

	public String getNumbersuffix() {
		return numbersuffix;
	}

	public void setNumbersuffix(String numbersuffix) {
		this.numbersuffix = numbersuffix;
	}

	public String getAlternatevgridalpha() {
		return alternatevgridalpha;
	}

	public void setAlternatevgridalpha(String alternatevgridalpha) {
		this.alternatevgridalpha = alternatevgridalpha;
	}

	public String getShowsum() {
		return showsum;
	}

	public void setShowsum(String showsum) {
		this.showsum = showsum;
	}

	public String getForceDecimals() {
		return forceDecimals;
	}

	public void setForceDecimals(String forceDecimals) {
		this.forceDecimals = forceDecimals;
	}

	public String getUseroundedges() {
		return useroundedges;
	}

	public void setUseroundedges(String useroundedges) {
		this.useroundedges = useroundedges;
	}

	public String getxAxisMaxValue() {
		return xAxisMaxValue;
	}

	public void setxAxisMaxValue(String xAxisMaxValue) {
		this.xAxisMaxValue = xAxisMaxValue;
	}

	public String getShowAlternateHGridColor() {
		return showAlternateHGridColor;
	}

	public void setShowAlternateHGridColor(String showAlternateHGridColor) {
		this.showAlternateHGridColor = showAlternateHGridColor;
	}

	public String getManageLabelOverflow() {
		return manageLabelOverflow;
	}

	public void setManageLabelOverflow(String manageLabelOverflow) {
		this.manageLabelOverflow = manageLabelOverflow;
	}

	public String getChartRightMargin() {
		return chartRightMargin;
	}

	public void setChartRightMargin(String chartRightMargin) {
		this.chartRightMargin = chartRightMargin;
	}
	
}
