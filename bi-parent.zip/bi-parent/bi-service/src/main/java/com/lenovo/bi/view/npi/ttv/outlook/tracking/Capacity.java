package com.lenovo.bi.view.npi.ttv.outlook.tracking;

public class Capacity {

	private String causesCategory;//ODM Capacity,Tooling Capacity,Supply Capacity
	private String causes;//ODM Shortage,Tooling Shortage,Supply Shortage
	private long demand;//[Demand]
	private long estimatedCapacity;//[ODM Capacity],[Tooling Capacity],[Supply Capacity]
	private long gap;//Demand - Estimated Capacity
	private String unit;//"PCS"

	public String getCausesCategory() {
		return causesCategory;
	}

	public void setCausesCategory(String causesCategory) {
		this.causesCategory = causesCategory;
	}

	public String getCauses() {
		return causes;
	}

	public void setCauses(String causes) {
		this.causes = causes;
	}

	public long getDemand() {
		return demand;
	}

	public void setDemand(long demand) {
		this.demand = demand;
	}

	public long getEstimatedCapacity() {
		return estimatedCapacity;
	}

	public void setEstimatedCapacity(long estimatedCapacity) {
		this.estimatedCapacity = estimatedCapacity;
	}

	public long getGap() {
		return gap;
	}

	public void setGap(long gap) {
		this.gap = gap;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}
}
