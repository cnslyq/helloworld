package com.lenovo.bi.dao.common;

import java.util.List;

import com.lenovo.bi.model.system.Configurables;

public interface ConfigurablesDao {
	
	public void saveConfiguable(Configurables configurables);
	
	public List<Configurables> getConfiguables();
}
