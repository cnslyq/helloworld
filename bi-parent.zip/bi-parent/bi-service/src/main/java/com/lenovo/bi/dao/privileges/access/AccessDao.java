package com.lenovo.bi.dao.privileges.access;

import java.util.List;

import com.lenovo.bi.dto.privilege.PrivilegeTree;
import com.lenovo.bi.form.system.dict.DictSearchForm;
import com.lenovo.bi.model.system.GroupPrivilege;
import com.lenovo.bi.model.system.RolePrivilege;
import com.lenovo.bi.view.system.access.GroupPrivilegeDetailView;
import com.lenovo.bi.view.system.access.RolesDetailView;
import com.lenovo.bi.view.system.dictionary.GroupDetailView;
import com.lenovo.bi.view.system.dictionary.PrivilegeDetailView;
import com.lenovo.common.model.PagerInformation;


public interface AccessDao {

	public List<PrivilegeTree> getRolePrivilegeTreeList(String roleId);
	
	public List<PrivilegeDetailView> listPrivilegeDetailList(DictSearchForm form, PagerInformation pagerInfo);
	
	public List<PrivilegeDetailView> listPrivilegesForRole();
	
	public int getPrivilegeDetailCountByConditions(DictSearchForm form);
	
	public List<RolesDetailView> listRoles(DictSearchForm form, PagerInformation pagerInfo);
	
	public List<RolesDetailView> listRoles();
	
	public int getRoleDetailCountByConditions(DictSearchForm form);
	
	public void saveRolePrivilege(RolePrivilege[] rolePrivilegeArr);
	
	public void savePrivilegesForRole(Integer privilegeId,List<RolePrivilege> rolePrivilegeList);
	
	public List<RolePrivilege> listRolePrivilege(Integer roleId);
	
	public List<RolePrivilege> listRolePrivileges();
	
	public void deleteRolePrivilegeByRole(Integer roleId);
	
	public void deleteRolePrivilegeByPrivilege(Integer privilegeId);
	
	public List<RolesDetailView> listRolesForPrivilege(Integer privilegeId);
	
	
	
	public List<PrivilegeTree> getGroupPrivilegeTreeList(String groupId);
	
	public List<PrivilegeTree> getUserPrivilegeTreeList(String userId);
	
	public void saveGroupPrivilege(GroupPrivilege[] groupPrivilegeArr,String groupId);
	
	public void deleteGroupPrivilegeByGroup(Integer groupId);
	
	public List<GroupDetailView> listGroups();
	
	public List<String> listGroupsForExcel();

	public List<GroupPrivilege> listGroupPrivileges();
	
	public List<GroupPrivilegeDetailView> listGroupPrivilegesForExcel(DictSearchForm form);

	public List<PrivilegeDetailView> listPrivilegesForGroup();
	
	public List<GroupDetailView> listGroupsForPrivilege(Integer privilegeId);
	
	public void savePrivilegesForGroup(Integer privilegeId,List<GroupPrivilege> groupPrivilegeList);
	
	public void deleteGroupPrivilegeByPrivilege(Integer groupId);
	
}
