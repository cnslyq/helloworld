package com.lenovo.bi.dao.system.console;


public interface ConsoleMonitorForRestartJobDao{

	public void restartFailedJobs(String pathName,String packageName);
	
}
