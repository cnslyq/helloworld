package com.lenovo.bi.service.common;

import java.util.List;

import com.lenovo.bi.model.ExcludeOrder;
import com.lenovo.common.model.Pager;

public interface ExcludeOrderService {
	
	
	void batchSaveExcludeOrder(List<ExcludeOrder> excludeOrders);
	
	void deleteExcludeOrderByMonth(String month);
	
	int getExcludeOrderCountByMonth(String month);
	
	Pager<ExcludeOrder> getExcludeOrderByConditions(String month , int currentPage);

}
