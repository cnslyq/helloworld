package com.lenovo.bi.engine;

import java.util.Date;
import java.util.Map;

import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.SysConstants;
import com.lenovo.common.logging.Logger;
import com.lenovo.common.logging.LoggerFactory;

abstract public class ProductCommittedToolingCapacityCalculator<T> {
	protected Date versionDate;
	//protected Date targetDate;
	protected Integer pmsWaveId;

	protected TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	//protected ProductKeyPmsWaveIdMap productKeyPmsWaveIdMap;

	protected static Logger LOGGER = LoggerFactory.getLogger(SysConstants.LOG_WEEKLY_BATCH_CATALOG);

	/*
	public ProductCommittedToolingCapacityCalculator(Date targetDate, Date versionDate, ProductKeyPmsWaveIdMap productKeyPmsWaveIdMap) {
		super();
		this.targetDate = targetDate;
		this.versionDate = versionDate;
		this.productKeyPmsWaveIdMap = productKeyPmsWaveIdMap;
	}

	abstract public void calculate(Map<String, T> weeklyDetailMap);
	*/
	public ProductCommittedToolingCapacityCalculator(Integer pmsWaveId, Date versionDate) {
		super();
		this.pmsWaveId = pmsWaveId;
		this.versionDate = versionDate;
	}
	
	abstract public void calculate(Map<Date, T> weeklyDetailMap);

	public void setTtvOutlookServiceDwHelper(TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper) {
		this.ttvOutlookServiceDwHelper = ttvOutlookServiceDwHelper;
	}
}
