package com.lenovo.bi.engine;
/**
 * 
 * 
 * @author henry_lian
 *
 */
public interface TTVKPIProcessor extends NPIKPIProcessor {

}
