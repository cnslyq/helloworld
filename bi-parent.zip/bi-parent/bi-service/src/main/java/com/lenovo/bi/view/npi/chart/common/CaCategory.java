package com.lenovo.bi.view.npi.chart.common;


public class CaCategory extends CategoryParent {

	private String name;
	
	private String value;
	
	private String quarterValue;
	
	private String values;

	public String getValues() {
		return values;
	}

	public void setValues(String values) {
		this.values = values;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getQuarterValue() {
		return quarterValue;
	}

	public void setQuarterValue(String quarterValue) {
		this.quarterValue = quarterValue;
	}
	
}
