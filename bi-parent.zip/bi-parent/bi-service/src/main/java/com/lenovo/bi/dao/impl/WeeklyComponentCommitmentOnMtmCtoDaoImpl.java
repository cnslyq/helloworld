package com.lenovo.bi.dao.impl;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dto.WeeklyComponentCommitment;
import com.lenovo.bi.model.WeeklyComponentCommitmentOnMtmCto;
import com.lenovo.bi.util.CalendarUtil;

/**
 * 
 * 
 * @author henry_lian
 * 
 */
@Repository
public class WeeklyComponentCommitmentOnMtmCtoDaoImpl extends
		HibernateBaseDaoImplBi<WeeklyComponentCommitmentOnMtmCto> {

	@SuppressWarnings("unchecked")
	public List<WeeklyComponentCommitment> getCommitmentByTargetDate(
			Date targetDate, Date versionDate, Integer waveId) {
		//
		// StringBuilder hql = new
		// StringBuilder("from WeeklyComponentCommitmentOnMtmCto where datediff(day, :targetDate, targetDate) = 0 and datediff(day, :versionDate, versionDate) = 0");
		// Query query = getSession().createQuery(hql.toString());
		// query.setParameter("targetDate", targetDate);
		// query.setParameter("versionDate", versionDate);
		// return query.list();
		StringBuffer sb = new StringBuffer(
				"select GlobalCVKey as cvkey,SUM(Quantity) as  commitment from ")
				.append(" (select od.PMSWaveID,od.Quantity,od.ProductKey,od.MTMKey,pmc.GlobalCVKey from BI_WeeklyComponentCommitmentOnOrder od")
				.append(" left join LenovoDW.dbo.FactProductMTMCV  pmc on od.MTMKey = pmc.MTMKey ")
				.append(" where  od.MaterialShortage = 0 and  od.VersionDate = :versionDate and od.TargetDate = :targetDate and od.PMSWaveID = :waveId and TTVPhase = 'sle'")
				.append(" union all")
				.append(" select ofo.PMSWaveID,ofo.Quantity,ofo.ProductKey,ofo.MTMKey,pmc.GlobalCVKey from BI_WeeklyComponentCommitmentOnForecast ofo")
				.append(" left join LenovoDW.dbo.FactProductMTMCV  pmc on ofo.MTMKey = pmc.MTMKey ")
				.append(" where  ofo.MaterialShortage = 0 and  ofo.VersionDate =  :versionDate and ofo.TargetDate =:targetDate and ofo.PMSWaveID =:waveId and TTVPhase = 'sle'")
				.append(" ) temp group by temp.GlobalCVKey");

		Query query = getSession()
				.createSQLQuery(sb.toString())
				.addScalar("cvkey", IntegerType.INSTANCE)
				.addScalar("commitment", IntegerType.INSTANCE)
				.setResultTransformer(
						Transformers
								.aliasToBean(WeeklyComponentCommitment.class));
		try {
			query.setParameter("versionDate",
					CalendarUtil.date2String(versionDate));
			query.setParameter("targetDate",
					CalendarUtil.date2String(targetDate));
			query.setParameter("waveId", waveId);
		} catch (HibernateException e) {
			e.printStackTrace();
			return null;
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
		return query.list();
	}

	public void deleteWeeklyComponentCommitmentOnMtmCtoForVersionDate(
			Date versionDate) {
		deleteDataForVersionDate("WeeklyComponentCommitmentOnMtmCto",
				versionDate);
	}
}
