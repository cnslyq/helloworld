package com.lenovo.bi.service.sc.impl;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.common.ExcludeOrderDao;
import com.lenovo.bi.dao.sc.OnsDao;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.PieDivider;
import com.lenovo.bi.dto.sc.OnsRemarkChartData;
import com.lenovo.bi.dto.sc.ScOverViewChartData;
import com.lenovo.bi.enumobj.ChartTypeEnum;
import com.lenovo.bi.enumobj.KPILights;
import com.lenovo.bi.enumobj.Threshold;
import com.lenovo.bi.form.sc.ots.SearchOtsForm;
import com.lenovo.bi.service.common.CommonService;
import com.lenovo.bi.service.common.MasterDataService;
import com.lenovo.bi.service.sc.ONSService;
import com.lenovo.bi.service.sc.ScCommonService;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.util.StringUtil;
import com.lenovo.bi.util.SysConfig;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.DataSetLine;
import com.lenovo.bi.view.npi.chart.column.MSColumnChartView2DLine;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.npi.chart.pie.PieChartView;
import com.lenovo.bi.view.npi.ttv.outlook.detractor.TtvGridDetractorCodeView;

@Service
public class ONSServiceImpl implements ONSService {

	@Inject
	OnsDao onsDao;
	
	@Inject
	CommonService commonService;
	
	@Inject
	ScCommonService scCommonService;
	
	@Inject
	ExcludeOrderDao excludeOrderDao;
	
	@Inject
	private MasterDataService masterDataService;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public MSColumnChartView2DLine getOverviewChart(SearchOtsForm form) throws ParseException {
		MSColumnChartView2DLine columnChartView = new MSColumnChartView2DLine();
		setOverviewChartInfomation(columnChartView);
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName()) 
				|| form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())) {
			String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
			if(!form.isShowQuarterOverview()) {
				for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
					String yearMonth = CalendarUtil.getYearMonthByMonths(startDate, i);
					if (form.getEndDate()!=null && yearMonth.compareTo(form.getEndDate()) > 0) 
						break;
					Category category = new Category();
					category.setName(yearMonth);
					categoryList.add(category);
				}
			}
			else {
				String date = "";
				if(form.getStartDate().substring(5).compareTo("04") < 0)
					date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
				else
					date = form.getStartDate().substring(0, 5) + "04";
				for(int i=0; i<4; i++) {
					Category category = new Category();
					category.setName("Q"+ (i+1));
					String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
					String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
					category.setQuarterValue(quarterFrom + "||" + quarterTo);
					categoryList.add(category);
				}
			}
			
		}
		
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		@SuppressWarnings("unused")
		List dataSet = new ArrayList();
		
		//dataset list and lineset list
		List onsOrderDataSetList = new ArrayList();
		@SuppressWarnings("unused")
		List<DataSetLine> targetLineDataSetList = new ArrayList<DataSetLine>();
		
		//dataset
		DataSetColumn onsDataSetColumn = new DataSetColumn();
		onsDataSetColumn.setSeriesName("ONS");
		onsDataSetColumn.setColor("FF6666");
		
		DataSetLine targetDataSetLine = new DataSetLine();
		targetDataSetLine.setSeriesName("Target");
		targetDataSetLine.setRenderas("Line");
		targetDataSetLine.setColor("FF0099");
		
		
		List<ColumnData> onsCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> targetCloumnDataList = new ArrayList<ColumnData>();
		
		LinkedHashMap<Object,List<ScOverViewChartData>> onsOverviewMap = null;
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())) 
			onsOverviewMap = fetchOnsOverViewChartData(form);
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName()))
			onsOverviewMap = fetchOnsCrossMonthOverviewChartData(form);
		else
			onsOverviewMap = fetchOnsDashboardOverViewChartData(form);
		int i=0;
		for(Map.Entry<Object, List<ScOverViewChartData>> entry : onsOverviewMap.entrySet()) {
			String name = ((KeyNameObject)entry.getKey()).getObjName();
			int key = -1;
			if(((KeyNameObject)entry.getKey()).getObjKey() != null)
				key = ((KeyNameObject)entry.getKey()).getObjKey();
			List<ScOverViewChartData> chartDataList = entry.getValue();
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				Category category = new Category();
				category.setName(name);
				categoryList.add(category);
			}
			
			ColumnData ons = new ColumnData();
			setFPSDOverviewColumnLink(ons,name,key);
			ons.setValue(0);
			
			Map<String,Integer> dataMap = new HashMap<String,Integer>();
			StringBuffer valueBuffer = new StringBuffer("[{");
			Category category = (Category)(categoryList.get(i));
			for(ScOverViewChartData onsOverViewChartData : chartDataList) {
				setFPSDOverviewColumnLink(ons,name,key);
				ons.setValue(onsOverViewChartData.getOrderNum());
				valueBuffer.append("ons:");
				dataMap.put("ONS", onsOverViewChartData.getOrderNum());
				valueBuffer.append(onsOverViewChartData.getOrderNum()).append(",");
			}
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) {
				valueBuffer.append("subDimensionName:");
				valueBuffer.append("'" + name + "'").append(",");
			}
			
			float makeRateValue = dataMap.get("ONS");
			
			valueBuffer.append("makeRate:");
			valueBuffer.append(makeRateValue).append(",");
			
			String lightColor = null;
			if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName()))
				lightColor = KPILights.GRAY.toString();
			else
				lightColor = commonService.getOnsKPILightColor(makeRateValue);
			
			if(form.getChartType().equals(ChartTypeEnum.Dashboard.getTypeName())) 
				lightColor = KPILights.GRAY.toString();
				
			onsCloumnDataList.add(ons);
			
			float targetValue = 0;
			Float thresholdValue = masterDataService.getThresholdByName(Threshold.SC_OTS_ONS_TARGET.name());
			if(thresholdValue != null)
				targetValue = thresholdValue.floatValue();
			//Target
			if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())) {
				ColumnData target = new ColumnData();
				target.setValue(targetValue);
				targetCloumnDataList.add(target);
			}
			
			valueBuffer.append("target:");
			valueBuffer.append(targetValue).append(",");
			valueBuffer.append("lightColor:");
			valueBuffer.append("'" + lightColor + "'");
			valueBuffer.append("}").append("]");
			//System.out.println("----------KPI:" + valueBuffer.toString());
			
			category.setValues(valueBuffer.toString());
			
			i++;
		}
		
		onsDataSetColumn.setDataList(onsCloumnDataList);
		onsOrderDataSetList.add(onsDataSetColumn);
		
		//only overview page has target line
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())) {
			targetDataSetLine.setDataList(targetCloumnDataList);
			onsOrderDataSetList.add(targetDataSetLine);
		}
		
		columnChartView.setDataSet(onsOrderDataSetList);
		
		return columnChartView;
	}
	
	public float calOnsNum(String date,SearchOtsForm form) throws ParseException {
		
		float onsNumValue = 0;
		form.setStartDate(date);
		LinkedHashMap<Object,List<ScOverViewChartData>> onsOverviewMap = fetchOnsOverViewChartDataByMonth(form);
		
		for(Map.Entry<Object, List<ScOverViewChartData>> entry : onsOverviewMap.entrySet()) {
		
			List<ScOverViewChartData> chartDataList = entry.getValue();
			
			Map<String,Integer> dataMap = new HashMap<String,Integer>();
		
			for(ScOverViewChartData onsOverViewChartData : chartDataList) {
				dataMap.put("ONS", onsOverViewChartData.getOrderNum());
			}
			
			onsNumValue = dataMap.get("ONS");
			
			//lightColor = commonService.getOnsKPILightColor(onsNumValue);
		}
		return onsNumValue;
	}

	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchOnsOverViewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> onsOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		if(!form.isShowQuarterOverview()) {
			String yearMonth = "";
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(form.getStartDate(), i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				onsOverviewMap.put(keyNameObject, onsDao.fetchOnsOverViewChartData(form));
			}
		}
		else {
			String date = "";
			if(form.getStartDate().substring(5).compareTo("04") < 0)
				date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
			else
				date = form.getStartDate().substring(0, 5) + "04";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			for(int i=0; i<4; i++) {
				KeyNameObject keyNameObject = new KeyNameObject();
				String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
				String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
				if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0)
					form.setQuarterTo(currentDate.replace("-0", "-"));
				else
					form.setQuarterTo(quarterTo.replace("-0", "-"));
				form.setQuarterFrom(quarterFrom.replace("-0", "-"));
				
				keyNameObject.setObjName(quarterFrom + "||" + quarterTo);
				onsOverviewMap.put(keyNameObject, onsDao.fetchOnsOverViewChartData(form));
			}
		}
		
		return onsOverviewMap;
	}
	
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchOnsOverViewChartDataByMonth(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> onsOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		
		String date = form.getStartDate();
		KeyNameObject keyNameObject = new KeyNameObject();
		keyNameObject.setObjName(date);
		int year = Integer.parseInt(date.substring(0,4));
		int month = Integer.parseInt(date.substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		onsOverviewMap.put(keyNameObject, onsDao.fetchOnsOverViewChartData(form));
		
		return onsOverviewMap;
	}
	
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchOnsCrossMonthOverviewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> onsOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		String startDate = form.getStartDate() == null ? form.getSelectMonth() : form.getStartDate();
		if(!form.isShowQuarterOverview()) {
			String yearMonth = "";
			for(int i=0; i<SysConfig.NUMBER_OF_MONTHS; i++) {
				String date = CalendarUtil.getYearMonthByMonths(startDate, i);
				if (date.compareTo(form.getEndDate()) > 0) 
					break;
				KeyNameObject keyNameObject = new KeyNameObject();
				keyNameObject.setObjName(date);
				int year = Integer.parseInt(date.substring(0,4));
				int month = Integer.parseInt(date.substring(5,7));
				form.setYear(year);
				form.setMonth(month);
				onsOverviewMap.put(keyNameObject, onsDao.fetchOnsCrossMonthOverviewChartData(form));
			}
		}
		else {
			String date = "";
			if(form.getStartDate().substring(5).compareTo("04") < 0)
				date = Integer.parseInt(form.getStartDate().substring(0, 4))-1 + "-04";
			else
				date = form.getStartDate().substring(0, 5) + "04";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			for(int i=0; i<4; i++) {
				KeyNameObject keyNameObject = new KeyNameObject();
				String quarterFrom = CalendarUtil.getYearMonthByMonths(date, i*3);
				String quarterTo = CalendarUtil.getYearMonthByMonths(date, i*3+2);
				if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0)
					form.setQuarterTo(currentDate.replace("-0", "-"));
				else
					form.setQuarterTo(quarterTo.replace("-0", "-"));
				form.setQuarterFrom(quarterFrom.replace("-0", "-"));
				
				keyNameObject.setObjName(quarterFrom + "||" + quarterTo);
				onsOverviewMap.put(keyNameObject, onsDao.fetchOnsCrossMonthOverviewChartData(form));
			}
		}
		
		return onsOverviewMap;
	}
	
	public LinkedHashMap<Object,List<ScOverViewChartData>> fetchOnsDashboardOverViewChartData(SearchOtsForm form) throws ParseException {
		LinkedHashMap<Object,List<ScOverViewChartData>> onsDashboardOverviewMap = new LinkedHashMap<Object,List<ScOverViewChartData>>();
		int year = Integer.parseInt(form.getSelectMonth().substring(0,4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5,7));
		form.setYear(year);
		form.setMonth(month);
		List<KeyNameObject> dimensionList = null;
		
		if(form.isShowGeoOverview()) {
			dimensionList = onsDao.fetchGeoDimensions(form);
			for(KeyNameObject keyNameObject : dimensionList) {
				form.setGeoKey(keyNameObject.getObjKey());
				onsDashboardOverviewMap.put(keyNameObject, onsDao.fetchOnsGeoDashboardOverViewChartData(form));
			}
		}
		else {
			dimensionList = onsDao.fetchDimensions(form);
			for(KeyNameObject keyNameObject : dimensionList) {
				form.setSubDimensionKey(keyNameObject.getObjKey());
				onsDashboardOverviewMap.put(keyNameObject, onsDao.fetchOnsDashboardOverViewChartData(form));
			}
		}
		return onsDashboardOverviewMap;
	}
	
	public void setFPSDOverviewColumnLink(ColumnData cloumnData,String name, int key) {
		/*cloumnData.setLink("j-showDetractorMainPieAndData-"
				+ weekNo + "," 
				+ trackingCausesMonday + "|" 
				+trackingCausesSunday);*/
		cloumnData.setLink("j-refreshRemark-" + name + "," + key);
	}
	
	@Override
	public ColumnChartView getRemarkChart(SearchOtsForm form) throws ParseException {
		if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())){
			List<String> dates = CalendarUtil.getDatesByString(form.getSelectMonth());
			if(CollectionUtils.isNotEmpty(dates)){
				if(dates.size() < 2){
					form.setStartDate(dates.get(0));
					form.setEndDate(dates.get(0));
				}
				else{
					form.setStartDate(dates.get(0));
					form.setEndDate(dates.get(1));
				}
			}
			else{
				//return null;
			}
		}
		ColumnChartView columnChartView = setRemarkChartInfomation();
		
		//dataset:seriesName
		List<DataSetParent> onsDimensionDataSetList = new ArrayList<DataSetParent>();
		
		DataSetColumn onsDataSetColumn = new DataSetColumn();
		onsDataSetColumn.setSeriesName("Ons");
		onsDataSetColumn.setColor("FF6666");
		List<ColumnData> onsCloumnDataList = new ArrayList<ColumnData>();
		
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		List<OnsRemarkChartData> onsRemarkChartDataList = fetchOnsRemarkChartData(form);
		
		for(int i=0; i<onsRemarkChartDataList.size(); i++) {
			if(i == 15) break;
			OnsRemarkChartData onsRemarkChartData = onsRemarkChartDataList.get(i);
			String name = onsRemarkChartData.getDimensionName();
			int value = onsRemarkChartData.getDimensionKey();
			
			Category category = new Category();
			category.setName(name);
			category.setValue(value);
			categoryList.add(category);
			
			ColumnData ons = new ColumnData();
			
			String dimensionInfo = "";
			if(ChartTypeEnum.OverView.getTypeName().equals(form.getChartType()))
				dimensionInfo = form.getDimension()+ "," + name;
			else
				dimensionInfo = form.getDimension()+ "," + name + "~" + value;
			
			setRemarkColumnLink(dimensionInfo,ons,form);
			ons.setValue(onsRemarkChartData.getOrderQuantity());
			String orderQuantity =  NumberFormat.getIntegerInstance().format(onsRemarkChartData.getOrderQuantity());
			ons.setTooltext("Ons, "+name+", "+orderQuantity);
			
			onsCloumnDataList.add(ons);
		}
		Categories categories = new Categories();
		categories.setCategoryList(categoryList);
		columnChartView.setCategories(categories);
		
		onsDataSetColumn.setDataList(onsCloumnDataList);
		onsDimensionDataSetList.add(onsDataSetColumn);
		
		columnChartView.setDataSetList(onsDimensionDataSetList);
		
		return columnChartView;
	}

	
	public List<OnsRemarkChartData> fetchOnsRemarkChartData(SearchOtsForm form) throws ParseException {
		if(!ChartTypeEnum.OverRall.getTypeName().equals(form.getChartType())) {
			if(!form.isShowQuarterOverview()) {
				String yearStr = form.getSelectMonth().substring(0,4);
				String monthStr = form.getSelectMonth().substring(5,7);
				int year = Integer.parseInt(yearStr);
				int month = Integer.parseInt(monthStr);
				form.setYear(year);
				form.setMonth(month);
			}
		}
		else {
			if(form.getStartDate().equalsIgnoreCase(form.getEndDate())){
				String yearMonth = form.getStartDate();
				String yearStr = yearMonth.substring(0,4);
				String monthStr = yearMonth.substring(5,7);
				int year = Integer.parseInt(yearStr);
				int month = Integer.parseInt(monthStr);
				form.setYear(year);
				form.setMonth(month);
				String yearMonthTmp =  monthStr.length() < 2 ? yearStr + "-0" + monthStr : yearStr + "-" + monthStr;
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonthTmp , "" , ""));
			}
			else{
				form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
			}
		}
		
		List<OnsRemarkChartData> onsRemarkChartDataList = new ArrayList<OnsRemarkChartData>();
		onsRemarkChartDataList = onsDao.fetchDimensionRemarkDataList(form);
		
		return onsRemarkChartDataList;
	}
	
	
	public void setColumnLink(int weekNo,ColumnData cloumnData) {
		
		cloumnData.setLink("j-refreshRemark-");
	
	}
	
	public void setRemarkColumnLink(String dimensionInfo,ColumnData cloumnData,SearchOtsForm form) {
		
		if(ChartTypeEnum.CrossMonth.getTypeName().equals(form.getChartType()))
			cloumnData.setLink( "j-onsCrossMonthSumOrderDetailShow-"+dimensionInfo );
		else if(ChartTypeEnum.Dashboard.getTypeName().equals(form.getChartType()))
			cloumnData.setLink( "j-onsDashboardSumOrderDetailShow-"+dimensionInfo );
		else
			cloumnData.setLink( "j-showONSOrderDetail-"+dimensionInfo );
	
	}
	
	private ColumnChartView setRemarkChartInfomation() {
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setCaption("");
		columnChartView.getChartInfo().setNumdivlines("1");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		columnChartView.getChartInfo().setyAxisMaxValue("100");
		//snumberSuffix
		columnChartView.getChartInfo().setSnumberSuffix("false");
		//columnChartView.getChartInfo().setFormatNumber("%");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("1");
		columnChartView.getChartInfo().setShowBorder("1");
		columnChartView.getChartInfo().setCanvasBorderThickness("1");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("20");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		columnChartView.getChartInfo().setShowValues("0");
		columnChartView.getChartInfo().setShowsum("1");
		columnChartView.getChartInfo().setChartRightMargin("50");//data will not be overflow
		/*columnChartView.getChartInfo().setDecimals("2");
		columnChartView.getChartInfo().setForceDecimals("2");*/
		
		return columnChartView;
	}
	
	private void setOverviewChartInfomation(MSColumnChartView2DLine mSColumnChartView) {
		mSColumnChartView.getChartInfo().setCaption("");
		mSColumnChartView.getChartInfo().setNumdivlines("9");
		mSColumnChartView.getChartInfo().setyAxisMinValue("0");
		//mSColumnChartView.getChartInfo().setyAxisMaxValue("160");
		mSColumnChartView.getChartInfo().setsYAxisMinValue("0");
		mSColumnChartView.getChartInfo().setsYAxisMaxValue("100");
		mSColumnChartView.getChartInfo().setFormatNumberScale("0");
		mSColumnChartView.getChartInfo().setLegendIconScale("1");
		mSColumnChartView.getChartInfo().setShowBorder("1");
		mSColumnChartView.getChartInfo().setCanvasBorderThickness("1");
		mSColumnChartView.getChartInfo().setShowZeroPlaneValue("1");
		mSColumnChartView.getChartInfo().setCanvasBorderAlpha("60");
		mSColumnChartView.getChartInfo().setPlotSpacePercent("70");
		mSColumnChartView.getChartInfo().setBgalpha("0,0");
		mSColumnChartView.getChartInfo().setLegendPosition("");
		mSColumnChartView.getChartInfo().setShowBorder("0");
		mSColumnChartView.getChartInfo().setShowPlotBorder("0");
		mSColumnChartView.getChartInfo().setShowValues("0");
	}

	@Override
	public List<ScOverViewChartData> getOverviewOverall(SearchOtsForm form) {
		if(form.getStartDate().equalsIgnoreCase(form.getEndDate())){
			String yearMonth = form.getStartDate();
			String yearStr = yearMonth.substring(0,4);
			String monthStr = yearMonth.substring(5,7);
			int year = Integer.parseInt(yearStr);
			int month = Integer.parseInt(monthStr);
			form.setYear(year);
			form.setMonth(month);
			String yearMonthTmp =  monthStr.length() < 2 ? yearStr + "-0" + monthStr : yearStr + "-" + monthStr;
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth(yearMonthTmp , "" , ""));
		}else{
			form.setPoNumberItemOrderNo(excludeOrderDao.getPoNumberItemOrderNoByMonth("" , form.getStartDate().replace("-", "") , form.getEndDate().replace("-", "")));
		}
		return onsDao.getOverviewOverall(form);
	}
	
	@Override
	public Map<String,Object> getOnsRemarkOrderDetail(
			SearchOtsForm form) throws ParseException {
		/*List<String> orderKeys = null;  
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			orderKeys = this.fetchOnsOverVieRemarkwOrderDetailData(form);
		}
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			orderKeys = this.fetchOnsCrossMonthSumOrderDetailData(form);
		}
		else{
			orderKeys = this.fetchOnsDashboardSumOrderDetailData(form);
		}
		return scCommonService.getOrderDetail(orderKeys, form);*/
		
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			String quarterFrom = form.getStartDate();
			String quarterTo = form.getEndDate();
			if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0) {
				form.setEndDate(currentDate.replace("-0", "-"));
				form.setQuarterTo(currentDate.replace("-0", "-"));
			}
			else {
				form.setEndDate(quarterTo.replace("-0", "-"));
				form.setQuarterTo(quarterTo.replace("-0", "-"));
			}
			form.setStartDate(quarterFrom.replace("-0", "-"));
			form.setQuarterFrom(quarterFrom.replace("-0", "-"));
		}
		
		if(form.getSubDimension().contains("'")){
			form.setShowAllRemarkOrder(true);
			form.setShowUnknownOrder(false);
		}
		
		if(!StringUtil.isEmpty(form.getScStatus()) && "all".equalsIgnoreCase(form.getScStatus())){
			form.setShowAllRemarkOrder(true);
			form.setShowUnknownOrder(false);
			/*List<OnsRemarkChartData> onsRemarkChartDatas = new ArrayList<OnsRemarkChartData>();
			onsRemarkChartDatas = onsDao.fetchDimensionRemarkDataList(form);*/
			/*StringBuffer remarkDimensionKey = new StringBuffer();
			StringBuffer remarkSubDimension = new StringBuffer();
			for(OnsRemarkChartData onsRemarkChartData : onsRemarkChartDatas){
				remarkDimensionKey.append(onsRemarkChartData.getDimensionKey()).append(',');
				remarkSubDimension.append("'").append(onsRemarkChartData.getDimensionName()).append("'").append(',');
			}
			String remarkSubDimensionKeys = remarkDimensionKey.toString();
			String remarkSubDimensions = remarkSubDimension.toString();
			form.setRemarkSubDimensionKeys(remarkSubDimensionKeys.substring(0, remarkSubDimensionKeys.length() - 1));
			form.setRemarkSubDimensions(remarkSubDimensions.substring(0, remarkSubDimensions.length() - 1));*/
		}
		
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		int unkownTotalCount = 0;
		if(form.isShowDashBoradCrossMonth()){
			totalCount = onsDao.getDashCrossRemarkOrderDetailCount(form);
		}else{
			totalCount = onsDao.getRemarkOrderDetailCount(form);
		}
		
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			if("Detractor".equalsIgnoreCase(form.getDimension()) && form.isShowAllRemarkOrder()){
				String subDimensionTmp = form.getSubDimension();
				form.setSubDimension("UNKNOWN");
				form.setShowUnknownOrder(true);
				unkownTotalCount = onsDao.getRemarkOrderDetailCount(form);
				totalCount = totalCount + unkownTotalCount ;
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				form.setSubDimension(subDimensionTmp);
				form.setOrderNumber(unkownTotalCount);
				form.setShowUnknownOrder(false);
			}
			
			if(form.isShowDashBoradCrossMonth()){
				grid = onsDao.getDashCrossRemarkOrderDetail(form);
			}else{
				grid = onsDao.getRemarkOrderDetail(form);
			}
		}
		
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		map.put("unkownTotalCount", unkownTotalCount);
		return map;
	}
	@Override
	public Map<String,Object> getSumOderDetail(SearchOtsForm form)
			throws ParseException {
		/*List<String> orderKeys;
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			orderKeys = fetchOnsOverViewSumOrderDetailData(form);
		}else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			orderKeys = fetchOnsCrossMonthSumOrderDetailData(form);
		}else{
			orderKeys = fetchOnsDashboardSumOrderDetailData(form);
		}
		return scCommonService.getOrderDetail(orderKeys, form);*/
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			String quarterFrom = form.getStartDate();
			String quarterTo = form.getEndDate();
			if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0) {
				form.setEndDate(currentDate.replace("-0", "-"));
				form.setQuarterTo(currentDate.replace("-0", "-"));
			}
			else {
				form.setEndDate(quarterTo.replace("-0", "-"));
				form.setQuarterTo(quarterTo.replace("-0", "-"));
			}
			form.setStartDate(quarterFrom.replace("-0", "-"));
			form.setQuarterFrom(quarterFrom.replace("-0", "-"));
		}
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		
		if(form.getChartType().equals(ChartTypeEnum.OverView.getTypeName())){
			totalCount = onsDao.getOverviewOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				grid = onsDao.getOverviewOrderDetail(form);
			}
		}
		else if(form.getChartType().equals(ChartTypeEnum.CrossMonth.getTypeName())){
			totalCount = onsDao.getCrossMonthOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				grid = onsDao.getCrossMonthOrderDetail(form);
			}
		}
		else{
			totalCount = onsDao.getDashboardOrderDetailCount(form);
			if(totalCount > 0){
				if(form.getEndRow() > totalCount){
					form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
				}
				grid = onsDao.getDashboardOrderDetail(form);
			}
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	private List<String> fetchOnsOverVieRemarkwOrderDetailData(SearchOtsForm form) throws ParseException {
		if(!form.isShowQuarterOverview()) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			String quarterFrom = form.getStartDate();
			String quarterTo = form.getEndDate();
			if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0) {
				form.setEndDate(currentDate.replace("-0", "-"));
				form.setQuarterTo(currentDate.replace("-0", "-"));
			}
			else {
				form.setEndDate(quarterTo.replace("-0", "-"));
				form.setQuarterTo(quarterTo.replace("-0", "-"));
			}
			form.setStartDate(quarterFrom.replace("-0", "-"));
			form.setQuarterFrom(quarterFrom.replace("-0", "-"));
		}
		return onsDao.fetchOnsOverViewRemarkOrderDetailData(form);
	}
	private List<String> fetchOnsOverViewSumOrderDetailData(SearchOtsForm form) {
		if (!form.isShowQuarterOverview()) {
			int year = Integer.parseInt(form.getStartDate().substring(0, 4));
			int month = Integer.parseInt(form.getStartDate().substring(5, 7));
			form.setYear(year);
			form.setMonth(month);
		} else {
			for (int i = 0; i < 4; i++) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
				String currentDate = sdf.format(Calendar.getInstance().getTime());
				String quarterFrom = form.getStartDate();
				String quarterTo = form.getEndDate();
				if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0) {
					form.setEndDate(currentDate.replace("-0", "-"));
					form.setQuarterTo(currentDate.replace("-0", "-"));
				}
				else {
					form.setEndDate(quarterTo.replace("-0", "-"));
					form.setQuarterTo(quarterTo.replace("-0", "-"));
				}
				form.setStartDate(quarterFrom.replace("-0", "-"));
				form.setQuarterFrom(quarterFrom.replace("-0", "-"));
				
			}
		}
		return onsDao.fetchOnsOverViewSumOrderDetailData(form);
	}

	private List<String> fetchOnsCrossMonthSumOrderDetailData(SearchOtsForm form) {
		if (!form.isShowQuarterOverview()) {
			int year = Integer.parseInt(form.getStartDate().substring(0, 4));
			int month = Integer.parseInt(form.getStartDate().substring(5, 7));
			form.setYear(year);
			form.setMonth(month);
		} else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			String quarterFrom = form.getStartDate();
			String quarterTo = form.getEndDate();
			if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0) {
				form.setEndDate(currentDate.replace("-0", "-"));
				form.setQuarterTo(currentDate.replace("-0", "-"));
			}
			else {
				form.setEndDate(quarterTo.replace("-0", "-"));
				form.setQuarterTo(quarterTo.replace("-0", "-"));
			}
			form.setStartDate(quarterFrom.replace("-0", "-"));
			form.setQuarterFrom(quarterFrom.replace("-0", "-"));
		}

		return onsDao.fetchOnsCrossMonthSumOrderDetailData(form);
	}

	private List<String> fetchOnsDashboardSumOrderDetailData(SearchOtsForm form) {
		int year = Integer.parseInt(form.getSelectMonth().substring(0, 4));
		int month = Integer.parseInt(form.getSelectMonth().substring(5, 7));
		form.setYear(year);
		form.setMonth(month);
		List<KeyNameObject> dimensionList = onsDao.fetchDimensions(form);
		List<String> orderKeysAll = new ArrayList<String>();
		List<String> orderKeys;
		for (KeyNameObject keyNameObject : dimensionList) {
			form.setSubDimensionKey(keyNameObject.getObjKey());
			orderKeys = onsDao.fetchOnsDashboardSumOrderDetailData(form);
			orderKeysAll.addAll(orderKeys);
		}
		return orderKeysAll;
	}
	
	@Override
	public Map<String,Object> getOnsRemarkDetractorTableDetail(
			SearchOtsForm form) throws ParseException {
		/*List<String> orderKeys = onsDao.fetchOnsOrderKeysByDims(form);
		return scCommonService.getOrderDetail(orderKeys, form);*/
		
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			String quarterFrom = form.getStartDate();
			String quarterTo = form.getEndDate();
			if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0) {
				form.setEndDate(currentDate.replace("-0", "-"));
				form.setQuarterTo(currentDate.replace("-0", "-"));
			}
			else {
				form.setEndDate(quarterTo.replace("-0", "-"));
				form.setQuarterTo(quarterTo.replace("-0", "-"));
			}
			form.setStartDate(quarterFrom.replace("-0", "-"));
			form.setQuarterFrom(quarterFrom.replace("-0", "-"));
		}
		List<TtvGridDetractorCodeView> grid = null;
		int totalCount = 0;
		totalCount = onsDao.getDetractorOrderDetailCount(form);
		if(totalCount > 0){
			if(form.getEndRow() > totalCount){
				form.setRowCount(SysConfig.NUMBER_OF_ROW_COUNT - form.getEndRow() + totalCount);
			}
			grid = onsDao.getDetractorOrderDetail(form);
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("grid", grid);
		map.put("totalCount", totalCount);
		return map;
	}
	@Override
	public PieChartView getOnsDetractorMainPieChart(SearchOtsForm form) {
		form.setLevel(1);
		List<PieDivider> detractorDividerList = onsDao.getDetractorMainDivider(form);
		Map<String, String> detractorMap = new HashMap<String, String>();

		for (PieDivider detractorDivider : detractorDividerList) {
			detractorMap.put(detractorDivider.getLevel1Name(), detractorDivider.getLevel1Num() + "");
		}

		String linkName = "showOnsDetractorSubPieAndData";
		
		return scCommonService.getDetractorMainPieChart(detractorMap, linkName);
	}

	@Override
	public PieChartView getOnsDetractorSubPieChart(SearchOtsForm form) {
		String parentType = form.getLevel1Detractor();
		form.setLevel(2);
		List<PieDivider> detractorDividerList = onsDao.getDetractorMainDivider(form);
		
		Map<String, String> detractorMap = new HashMap<String, String>();

		for (PieDivider detractorDivider : detractorDividerList) {
			detractorMap.put(detractorDivider.getLevel2Name(), detractorDivider.getLevel2Num() + "");
		}
		String linkName = "showOnsDetractorTableBylevel2";
		return scCommonService.getDetractorSubPieChart(detractorMap, linkName, parentType);
	}

	@Override
	public List<TtvGridDetractorCodeView> getTtvGridDetractorCodeView(
			SearchOtsForm form) throws ParseException {
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			String quarterFrom = form.getStartDate();
			String quarterTo = form.getEndDate();
			if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0) {
				form.setEndDate(currentDate.replace("-0", "-"));
				form.setQuarterTo(currentDate.replace("-0", "-"));
			}
			else {
				form.setEndDate(quarterTo.replace("-0", "-"));
				form.setQuarterTo(quarterTo.replace("-0", "-"));
			}
			form.setStartDate(quarterFrom.replace("-0", "-"));
			form.setQuarterFrom(quarterFrom.replace("-0", "-"));
		}
		
		
		if(!StringUtil.isEmpty(form.getScStatus()) && "all".equalsIgnoreCase(form.getScStatus())){
			form.setShowAllRemarkOrder(true);
			form.setShowUnknownOrder(false);
		}
		
		return onsDao.getAllOrderDetail(form);
	}

	@Override
	public List<TtvGridDetractorCodeView> getDetractorOrderDetail(
			SearchOtsForm form) throws ParseException {
		if(form.getStartDate().equals(form.getEndDate())) {
			int year = Integer.parseInt(form.getStartDate().substring(0,4));
			int month = Integer.parseInt(form.getStartDate().substring(5,7));
			form.setYear(year);
			form.setMonth(month);
		}else {
			form.setShowQuarterOverview(true);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
			String currentDate = sdf.format(Calendar.getInstance().getTime());
			String quarterFrom = form.getStartDate();
			String quarterTo = form.getEndDate();
			if(currentDate.compareTo(quarterFrom) >= 0 && currentDate.compareTo(quarterTo) < 0) {
				form.setEndDate(currentDate.replace("-0", "-"));
				form.setQuarterTo(currentDate.replace("-0", "-"));
			}
			else {
				form.setEndDate(quarterTo.replace("-0", "-"));
				form.setQuarterTo(quarterTo.replace("-0", "-"));
			}
			form.setStartDate(quarterFrom.replace("-0", "-"));
			form.setQuarterFrom(quarterFrom.replace("-0", "-"));
		}
		return onsDao.getAllDetractorOrder(form);
	}

}
