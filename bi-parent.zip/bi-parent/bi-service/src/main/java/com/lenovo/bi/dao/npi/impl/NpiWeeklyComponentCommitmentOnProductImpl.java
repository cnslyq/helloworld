package com.lenovo.bi.dao.npi.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.lenovo.bi.dao.impl.HibernateQueryBaseBi;
import com.lenovo.bi.dao.npi.NpiWeeklyComponentCommitmentOnProductDao;
import com.lenovo.bi.model.NpiWeeklyComponentCommitmentOnProduct;

@Repository
public class NpiWeeklyComponentCommitmentOnProductImpl extends
		HibernateQueryBaseBi implements
		NpiWeeklyComponentCommitmentOnProductDao {

	@Override
	public void saveComponentCommitmentOnProduct(
			NpiWeeklyComponentCommitmentOnProduct object) {
		getSession().save(object);
	}

	@Override
	public void deleteComponentCommitmentOnProduct(Date versionDate) {
		StringBuffer hql = new StringBuffer(
				"delete from NpiWeeklyComponentCommitmentOnProduct where versionDate = :versionDate");
		Query query = getSession().createQuery(hql.toString());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		query.setParameter("versionDate", Integer.parseInt(sdf.format(versionDate)));
		query.executeUpdate();
	}

}
