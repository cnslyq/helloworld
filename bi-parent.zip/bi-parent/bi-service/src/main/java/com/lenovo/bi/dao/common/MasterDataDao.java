package com.lenovo.bi.dao.common;

import java.util.List;

import com.lenovo.bi.dto.GeoData;
import com.lenovo.bi.dto.KeyNameObject;
import com.lenovo.bi.dto.privilege.GeoTree;

public interface MasterDataDao {

	public List<GeoData> getRegions();

	public List<String> getOrderType();

	public List<String> getOdmList();
	
	public List<String> getProductFamily();

	public List<String> getProductList();
	
	public List<GeoTree> getRegionTreeList();
	
	public List<KeyNameObject> getOrderSubTypes(Integer orderType);
	
	public List<KeyNameObject> getOdms();
	
	public List<KeyNameObject> getProducts();
	
	public List<KeyNameObject> getComponents();
	
	public List<KeyNameObject> getComponentValues();
	
	public List<KeyNameObject> getProductFamilys();
	
	public List<KeyNameObject> getFamilyList();
	
	public List<KeyNameObject> getPortfolioList();
	
	public List<KeyNameObject> getPurchaseTypeList();
	
	public String getCurrentRolMonth();

}
