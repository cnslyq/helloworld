package com.lenovo.bi.service.npi.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.bi.dao.npi.NPIProductSummaryDao;
import com.lenovo.bi.dao.npi.NpiOrderDaoBi;
import com.lenovo.bi.dao.npi.NpiOrderDaoDw;
import com.lenovo.bi.dto.Forecast;
import com.lenovo.bi.dto.Order;
import com.lenovo.bi.engine.BomNumberGeographyOdmKey;
import com.lenovo.bi.form.npi.ttv.SearchOrderHitRateForm;
import com.lenovo.bi.model.ProjectSummary;
import com.lenovo.bi.service.npi.TTVOutlookOrderHitRateService;
import com.lenovo.bi.service.npi.helper.TTVOutlookServiceDwHelper;
import com.lenovo.bi.util.CalendarUtil;
import com.lenovo.bi.view.npi.chart.column.Categories;
import com.lenovo.bi.view.npi.chart.column.ColumnChartView;
import com.lenovo.bi.view.npi.chart.column.ColumnData;
import com.lenovo.bi.view.npi.chart.column.DataSetColumn;
import com.lenovo.bi.view.npi.chart.column.DataSetLine;
import com.lenovo.bi.view.npi.chart.common.Category;
import com.lenovo.bi.view.npi.chart.common.CategoryParent;
import com.lenovo.bi.view.npi.chart.common.DataSetParent;
import com.lenovo.bi.view.npi.ttv.OrderHitRateView;

@Service
public class TTVOutlookOrderHitRateServiceImpl implements TTVOutlookOrderHitRateService {

	private NpiOrderDaoBi npiOrderDaoBi;

	private NpiOrderDaoDw npiOrderDaoDw;
	@Autowired
	private TTVOutlookServiceDwHelper ttvOutlookServiceDwHelper;
	@Inject
	private NPIProductSummaryDao nPIProductSummaryDao;
	@Override
	public ColumnChartView getColumnChartView(SearchOrderHitRateForm searchForm) throws ParseException {
		Categories categories = new Categories();
		List<CategoryParent> categoryList = new ArrayList<CategoryParent>();
		//int count = Integer.parseInt(SysConfig.TTV_ORDER_HIT_RATE_WEEKS);
		List<ColumnData> forecaseCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> upsideCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> offsetCloumnDataList = new ArrayList<ColumnData>();
		List<ColumnData> orderCloumnDataList = new ArrayList<ColumnData>();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date targetDate = df.parse(searchForm.getTargetDate());
		Date startDate = CalendarUtil.stringT2Date(searchForm.getStartDate());
		Date endDate = CalendarUtil.stringT2Date(searchForm.getEndDate());
		String waveId= String.valueOf(searchForm.getWaveId());
		List<Forecast> allForecastList = ttvOutlookServiceDwHelper.getForecastsInWeekByProductKey(targetDate, startDate, endDate, searchForm.getProductKey(),waveId);
		//List<Order> ordersInWeek = ttvOutlookServiceDwHelper.getSLEOrdersInWeekByProductKey(null,searchForm.getProductKey(),waveId,startDate,endDate);
		Map<Date,List<Forecast>> forecastVersionDateMap = new HashMap<Date,List<Forecast>>();
		for(Forecast forecast : allForecastList){
			List<Forecast> forecastList = forecastVersionDateMap.get(forecast.getVersionDate());
			if(forecastList ==  null){
				forecastList = new ArrayList<Forecast>();
				forecastVersionDateMap.put(forecast.getVersionDate(), forecastList);
			}
				forecastList.add(forecast);
		} 
		
		/*
		Map<Date,List<Order>> orderVersionDateMap = new HashMap<Date,List<Order>>();
		for(Order order : ordersInWeek){
			List<Order> orderList = orderVersionDateMap.get(order.getVersionDate());
			if(orderList ==  null){
				orderList = new ArrayList<Order>();
				orderVersionDateMap.put(order.getVersionDate(), orderList);
			}
				orderList.add(order);
		} 
		*/
		
	//	List<Order> ordersInWeek = ttvOutlookServiceDwHelper.getSLEOrdersInWeekByProductKey(targetDate,searchForm.getProductKey(),waveId);
		Date versionDate = startDate;
		int i = 0;
		ProjectSummary ps = nPIProductSummaryDao.getProductInfoByWaveId(searchForm.getWaveId(),  null);
		String thisMonday = CalendarUtil.date2String(versionDate);
		List<Order> ordersInWeek = ttvOutlookServiceDwHelper.getSLEOrdersInWeekByProductKey(targetDate,searchForm.getProductKey(),waveId,null,null);
		while(versionDate.before(endDate)){
			versionDate = CalendarUtil.getMondayDateByWeeks(startDate,i);
			thisMonday = CalendarUtil.date2String(versionDate);
			
			Category category = new Category();
			if(ps != null){
				if (ps.getTtmTargetDate() != null && thisMonday.equals(CalendarUtil.date2String(CalendarUtil.getMondayDateByDate(ps.getTtmTargetDate())))) {
					category.setName(thisMonday + "(SS)");
				} else if (ps.getTtvTargetDate() != null
						&& thisMonday.equals(CalendarUtil.date2String(CalendarUtil.getMondayDateByDate(ps.getTtvTargetDate())))) {
					category.setName(thisMonday + "(SLE)");
				} else if (ps.getSvtPlanDate() != null && thisMonday.equals(CalendarUtil.date2String(CalendarUtil.getMondayDateByDate(ps.getSvtPlanDate())))) {
					category.setName(thisMonday + "(SVT)");
				} else if (ps.getSovpPlanDate() != null && thisMonday.equals(CalendarUtil.date2String(CalendarUtil.getMondayDateByDate(ps.getSovpPlanDate())))) {
					category.setName(thisMonday + "(SOVP)");
				} else if (ps.getSgaTtvTargetDate() != null
						&& thisMonday.equals(CalendarUtil.date2String(CalendarUtil.getMondayDateByDate(ps.getSgaTtvTargetDate())))) {
					category.setName(thisMonday + "(SGA)");
				} else
					category.setName(thisMonday);
			}else{
				category.setName(thisMonday);
			}
			categoryList.add(category);
			Map<BomNumberGeographyOdmKey, Integer> forecastMap = new HashMap<BomNumberGeographyOdmKey, Integer>();
			long forecastTlt = 0;
			long orderTlt = 0;
			long upsideOrderTlt = 0;
			long offsetOrderTlt = 0;
			List<Forecast> forecastList = forecastVersionDateMap.get(versionDate);
			//List<Order> ordersList=  orderVersionDateMap.get(versionDate);
			if(CollectionUtils.isNotEmpty(forecastList)){
				for(Forecast forecast : forecastList){
					BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(forecast.getBomNumber(),forecast.getGeographyName(),forecast.getOdmName());
					forecastMap.put(key, forecast.getQuantity());
					forecastTlt = forecastTlt +forecast.getQuantity();
				}
			}
			Integer forecastQty = 0;
			Integer zero = new Integer(0);
			//if(CollectionUtils.isNotEmpty(ordersList)){
			//for(Order order : ordersList){
			for(Order order : ordersInWeek){
				BomNumberGeographyOdmKey key = new BomNumberGeographyOdmKey(order.getBomNumber(),order.getGeographyName(),order.getOdmName()); 
				forecastQty = forecastMap.get(key);
				if(forecastQty != null && zero.compareTo(forecastQty) < 0){
					if(forecastQty.compareTo(order.getQuantity()) < 0){
						upsideOrderTlt = upsideOrderTlt + (order.getQuantity() - forecastQty);
					}
				}else{
					offsetOrderTlt = offsetOrderTlt + order.getQuantity();
				}
				orderTlt = orderTlt + order.getQuantity();
			}
			//}
			//forecase data
			ColumnData forecaseData = new ColumnData();
			forecaseData.setColor("#66CCFF");//淡蓝
			setColumnLink(versionDate,forecaseData);
			forecaseData.setValue(forecastTlt);
			//upside data
			ColumnData upsidesetData = new ColumnData();
			upsidesetData.setColor("#FF6666");//淡红
			setColumnLink(versionDate,upsidesetData);
			upsidesetData.setValue(upsideOrderTlt);
			//offset data
			ColumnData offsetData = new ColumnData();
			offsetData.setColor("#990000");//黑红
			setColumnLink(versionDate,offsetData);
			offsetData.setValue(offsetOrderTlt);
			//order data
			ColumnData orderData = new ColumnData();
			orderData.setColor("#FF0000");//红色
			setColumnLink(versionDate,orderData);
			orderData.setValue(orderTlt);
			
			//data list
			forecaseCloumnDataList.add(forecaseData);
			upsideCloumnDataList.add(upsidesetData);
			offsetCloumnDataList.add(offsetData);
			orderCloumnDataList.add(orderData);
			i++;
		}
		categories.setCategoryList(categoryList);
		
		//forecast
		DataSetColumn forecastDataSet = new DataSetColumn();
		forecastDataSet.setSeriesName("Forecast");
		forecastDataSet.setColor("#66CCFF");
		forecastDataSet.setDataList(forecaseCloumnDataList);
		//upside
		DataSetColumn orderUpsideDataSet = new DataSetColumn();
		orderUpsideDataSet.setSeriesName("Order Upside");
		orderUpsideDataSet.setColor("#FF6666");
		orderUpsideDataSet.setDataList(upsideCloumnDataList);
		//offSet
		DataSetColumn orderOffSetDataSet = new DataSetColumn();
		orderOffSetDataSet.setSeriesName("Order OffSet");
		orderOffSetDataSet.setColor("#990000");
		orderOffSetDataSet.setDataList(offsetCloumnDataList);
		//order
		DataSetLine orderDataSet = new DataSetLine();
		orderDataSet.setSeriesName("Order");
		orderDataSet.setParentYaxis("");
		orderDataSet.setRenderas("Line");
		orderDataSet.setColor("FF0000");
		orderDataSet.setDrawAnchors("1");
		orderDataSet.setDataList(orderCloumnDataList);
		
		List<DataSetParent> dataSetList = new ArrayList<DataSetParent>();
		dataSetList.add(forecastDataSet);
		dataSetList.add(orderUpsideDataSet);
		dataSetList.add(orderOffSetDataSet);
		dataSetList.add(orderDataSet);
				
		ColumnChartView columnChartView = setChartInfomation();
		columnChartView.setCategories(categories);
		columnChartView.setDataSetList(dataSetList);
		
		return columnChartView;
	}

	private ColumnChartView setChartInfomation() {
		ColumnChartView columnChartView = new ColumnChartView();
		columnChartView.getChartInfo().setNumdivlines("5");
		columnChartView.getChartInfo().setyAxisMinValue("0");
		//columnChartView.getChartInfo().setyAxisMaxValue("12000");
		columnChartView.getChartInfo().setFormatNumber("0");
		columnChartView.getChartInfo().setFormatNumberScale("0");
		columnChartView.getChartInfo().setLegendIconScale("2");
		columnChartView.getChartInfo().setCanvasBorderThickness("0");
		columnChartView.getChartInfo().setShowZeroPlaneValue("1");
		columnChartView.getChartInfo().setCanvasBorderAlpha("0");
		columnChartView.getChartInfo().setPlotSpacePercent("50");
		columnChartView.getChartInfo().setBgalpha("0,0");
		columnChartView.getChartInfo().setLegendPosition("RIGHT");
		columnChartView.getChartInfo().setShowBorder("0");
		columnChartView.getChartInfo().setShowPlotBorder("0");
		//columnChartView.getChartInfo().setShowAlternateHGridColor("0");
		columnChartView.getChartInfo().setNumbersuffix("(pcs)");
		return columnChartView;
	}
	
	public void setColumnLink(Date versionDate,ColumnData cloumnData) throws ParseException {
		
			cloumnData.setLink("j-showGrid-"+CalendarUtil.date2String(versionDate));
		
	}

	public NpiOrderDaoBi getNpiOrderDaoBi() {
		return npiOrderDaoBi;
	}
	
	@Inject
	public void setNpiOrderDaoBi(NpiOrderDaoBi npiOrderDaoBi) {
		this.npiOrderDaoBi = npiOrderDaoBi;
	}

	public NpiOrderDaoDw getNpiOrderDaoDw() {
		return npiOrderDaoDw;
	}

	@Inject
	public void setNpiOrderDaoDw(NpiOrderDaoDw npiOrderDaoDw) {
		this.npiOrderDaoDw = npiOrderDaoDw;
	}

	@Override
	public List<OrderHitRateView> getGrid(SearchOrderHitRateForm searchForm)
			throws ParseException {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		 List<OrderHitRateView> list = ttvOutlookServiceDwHelper.getOrderAndForecast(df.parse(searchForm.getStartDate()),
				 df.parse(searchForm.getTargetDate()),searchForm.getProductKey(),searchForm.getRegionName(),String.valueOf(searchForm.getWaveId()));
		return list;
	}

}
