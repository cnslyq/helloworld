package com.lenovo.bi.view;

import java.util.List;

public class BINavigationView {

	private String navigationName;
	private List<BINavigation> biNavigations;

	public List<BINavigation> getBiNavigations() {
		return biNavigations;
	}

	public void setBiNavigations(List<BINavigation> biNavigations) {
		this.biNavigations = biNavigations;
	}

	public String getNavigationName() {
		return navigationName;
	}

	public void setNavigationName(String navigationName) {
		this.navigationName = navigationName;
	}
	
	
	
	
}
