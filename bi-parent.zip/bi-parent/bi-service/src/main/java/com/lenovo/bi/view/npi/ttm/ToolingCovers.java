package com.lenovo.bi.view.npi.ttm;

import java.util.ArrayList;
import java.util.List;
/**
 * 
 * 
 * @author henry_lian
 *
 */
public class ToolingCovers {
	
	private List<ToolingStatus> tooling = new ArrayList<ToolingStatus>();
	private int totalCapacity;
	private int demand;
	private int gap;
	public List<ToolingStatus> getTooling() {
		return tooling;
	}
	public void setTooling(List<ToolingStatus> tooling) {
		this.tooling = tooling;
	}
	public int getTotalCapacity() {
		return totalCapacity;
	}
	public void setTotalCapacity(int totalCapacity) {
		this.totalCapacity = totalCapacity;
	}
	public int getDemand() {
		return demand;
	}
	public void setDemand(int demand) {
		this.demand = demand;
	}
	public int getGap() {
		return gap;
	}
	public void setGap(int gap) {
		this.gap = gap;
	}
	
}
