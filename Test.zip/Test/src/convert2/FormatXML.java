package convert2;

import java.io.File;
import java.io.FileWriter;

import org.dom4j.Document;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class FormatXML{
	public static void main(String str[]){
		formatXMLFile("D:/EDITemp/EDI.xsd");
	}
 
      public static int formatXMLFile(String filename){
          int returnValue = 0 ;
          try{
             SAXReader saxReader  =   new  SAXReader(); 
             Document document  =  saxReader.read( new  File(filename));
             XMLWriter writer  =   null ;
             OutputFormat format  =  OutputFormat.createPrettyPrint();
             format.setEncoding( "UTF-8" );
             writer =   new  XMLWriter( new  FileWriter( new  File(filename)),format);
             writer.write(document);
             writer.close();      
             returnValue  =   1 ;     
         }  catch (Exception ex)  {
             ex.printStackTrace();
         }  
         return  returnValue;
      }
}  
