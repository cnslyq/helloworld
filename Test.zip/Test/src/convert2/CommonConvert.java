package convert2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Convert Data File into XML
 * @author brian_liu01
 */
public class CommonConvert {

	private String xmlConfigPath;
	private String dataFromPath;
	private String xmlToPath;
	private String rootNode;
	private String segId;
	private int startIndex;
	private int endIndex;
	private Map<String, ElementObj> elementMap = new HashMap<String, ElementObj>();
	private Map<String, SegmentRefObj> segmentRefMap = new HashMap<String, SegmentRefObj>();
	
	/**
	 * Main Method
	 */
	public void convert(){
		try{
			parseConfigFile();
			convertData2XML();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Parse Configuration file
	 * @throws Exception
	 */
	private void parseConfigFile() throws Exception {
		//create XSD document
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
        Document xmlDoc = db.parse(xmlConfigPath);
        
        //get root node
        Node root = xmlDoc.getFirstChild();
        //parse root node
        parseNode(root);
	}
	
	/**
	 * Parse a node of XSD
	 * @param node
	 * @throws Exception
	 */
	private void parseNode(Node node) throws Exception{
		//iterate child node
		if(node.hasChildNodes()){
			NodeList nodeList = node.getChildNodes();
			int length = nodeList.getLength();
			for(int i=0;i<length;i++){
				parseNode(nodeList.item(i));
			}
		}
		
		String nodeName = node.getNodeName();
		//<Element>
		if(Constant.ELEMENT.equals(nodeName)){
			//create element object
			ElementObj element = new ElementObj();
			
			//get attributes
			NamedNodeMap attributes = node.getAttributes();
			
			//set attributes
			element.setId(attributes.getNamedItem(Constant.ID).getNodeValue());
			element.setPos(attributes.getNamedItem(Constant.POS).getNodeValue());
			element.setDescription(attributes.getNamedItem(Constant.DESCRIPTION).getNodeValue());
			element.setMaxLength(attributes.getNamedItem(Constant.MAX_LENGTH).getNodeValue());
			element.setMinLength(attributes.getNamedItem(Constant.MIN_LENGTH).getNodeValue());
			element.setType(attributes.getNamedItem(Constant.TYPE).getNodeValue());
			element.setLength(Integer.parseInt(attributes.getNamedItem(Constant.LENGTH).getNodeValue()));
			
			//put in element map
			elementMap.put(element.getId(), element);
			
		//<SegmentRef>
		}else if(Constant.SEGMENT_REF.equals(nodeName)){
			//create segment ref object
			SegmentRefObj segmentRef = new SegmentRefObj();
			
			//get attributes
			NamedNodeMap attributes = node.getAttributes();
			
			//set attributes
			segmentRef.setId(attributes.getNamedItem(Constant.ID).getNodeValue());
			segmentRef.setPos(attributes.getNamedItem(Constant.POS).getNodeValue());
			segmentRef.setDescription(attributes.getNamedItem(Constant.DESCRIPTION).getNodeValue());
			
			//get element list
			NodeList nodeList = node.getChildNodes();
			List<String> elementIdList = new ArrayList<String>();
			int length = nodeList.getLength();
			for(int i=0;i<length;i++){
				Node childNode = nodeList.item(i);
				if(childNode.getNodeType() != Node.ELEMENT_NODE){
					continue;
				}
				elementIdList.add(getAttribute(childNode, Constant.ID));
			}
			
			//set element list
			segmentRef.setElementIdList(elementIdList);
			
			//put in segment ref map
			segmentRefMap.put(segmentRef.getId(), segmentRef);
			
		}
		
	}
	
	/**
	 * Get attribute value
	 * @param node
	 * @param attrName
	 * @return
	 */
	private String getAttribute(Node node, String attrName){
		NamedNodeMap attributes = node.getAttributes();
		Node attribute = attributes.getNamedItem(attrName);
		return null == attribute ? null : attribute.getNodeValue();
	}
	
	/**
	 * Main Convert Logic Method
	 * Convert data files into XML files
	 * @throws Exception
	 */
	private void convertData2XML() throws Exception {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		
		//get data file list
		File files = new File(dataFromPath);
		File[] listFile = files.listFiles();
		
		//iterate data file list
		for(File file:listFile){
			
			//create xml Document
			Document xmlDoc = db.newDocument();
			//create root node
			Node root = xmlDoc.createElement(rootNode);
			//append root node
			xmlDoc.appendChild(root);
			
			//read data file
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String data = null;
			while((data = br.readLine())!=null){
				//skip the first line
				if(data.startsWith("###"))
					continue;
				
				//initialize variables
				startIndex = 0;
				endIndex = 0;
				segId = "";
				
				//convert a line into xml
				convertLine(data, xmlDoc, root);
			}
			
			//generate xml file
			writeXMLFile(xmlDoc, xmlToPath + File.separator + file.getName().split("\\.")[0] + ".xml");
		}
	}
	
	/**
	 * Convert a line of data file into XML
	 * @param data
	 * @param xmlDoc
	 * @param parent
	 * @param nodeName
	 */
	private void convertLine(String data, Document xmlDoc, Node root){
		//get segment id
		endIndex = startIndex + 4;
		segId = data.substring(startIndex, endIndex).trim();
		startIndex = endIndex;
		
		//get segment object
		String segRefId = segId;
		if(null == segmentRefMap.get(segId)){
			String subSeg = data.substring(startIndex, startIndex + 3).trim();
			segRefId = segId + "-" + subSeg;
		}
		SegmentRefObj segObj = segmentRefMap.get(segRefId);
		if(segObj == null)
			return;
		
		//append segment ref node
		Node segParent = getChildNode(root, Constant.SEGMENT_REF + "-" + segRefId);
		if(segParent == null)
			segParent = xmlDoc.createElement(Constant.SEGMENT_REF + "-" + segRefId);
		Element segEle = xmlDoc.createElement(Constant.SEGMENT_REF);
		segEle.setAttribute(Constant.ID, segId);
		segEle.setAttribute(Constant.DESCRIPTION, segObj.getDescription());
		segEle.setAttribute(Constant.POS, segObj.getPos());
		root.appendChild(segParent);
		segParent.appendChild(segEle);
		
		//set SegmentRef position
		segObj.setPos((Integer.parseInt(segObj.getPos()) + 10) + "");
		segmentRefMap.put(segRefId, segObj);
		
		//get element id list
		List<String> eleIdList = segObj.getElementIdList();
		
		//loop element list
		for(String id:eleIdList){
			//get element object
			ElementObj obj = elementMap.get(id);
			
			//get value
			int length = obj.getLength();
			endIndex = startIndex + length;
			String value = data.substring(startIndex, endIndex).trim();
			startIndex = endIndex;
			
			//create element
			Element ele = xmlDoc.createElement(Constant.ELEMENT);
			
			//set attributes
			ele.setAttribute(Constant.ID, id);
			ele.setAttribute(Constant.DESCRIPTION, obj.getDescription());
			ele.setAttribute(Constant.POS, obj.getPos());
			ele.setAttribute(Constant.MAX_LENGTH, obj.getMaxLength());
			ele.setAttribute(Constant.MIN_LENGTH, obj.getMinLength());
			ele.setAttribute(Constant.TYPE, obj.getType());
			ele.setAttribute(Constant.VALUE, value);
			
			//append element node
			segEle.appendChild(ele);
			
		}
	
	}
	
	private Node getChildNode(Node parent, String name){
		NodeList list = parent.getChildNodes();
		for(int i=0;i<list.getLength();i++){
			Node node = list.item(i);
			if(name.equals(node.getNodeName()))
				return node;
		}
		return null;
	}
	
	/**
	 * Generate XML file
	 * @param xmlDoc
	 * @param fileName
	 * @throws Exception
	 */
	private void writeXMLFile(Document xmlDoc, String fileName) throws Exception {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
        DOMSource source = new DOMSource(xmlDoc);
        //transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        //transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        PrintWriter pw = new PrintWriter(new FileOutputStream(fileName));
        StreamResult result = new StreamResult(pw);
        transformer.transform(source, result);
	}
	
	public void setXmlConfigPath(String xmlConfigPath) {
		this.xmlConfigPath = xmlConfigPath;
	}

	public void setDataFromPath(String dataFromPath) {
		this.dataFromPath = dataFromPath;
	}

	public void setXmlToPath(String xmlToPath) {
		this.xmlToPath = xmlToPath;
	}
	
	public String getXmlConfigPath() {
		return xmlConfigPath;
	}

	public String getDataFromPath() {
		return dataFromPath;
	}

	public String getXmlToPath() {
		return xmlToPath;
	}

	public String getRootNode() {
		return rootNode;
	}

	public void setRootNode(String rootNode) {
		this.rootNode = rootNode;
	}

	public static void main(String[] args){
		long startTime=System.currentTimeMillis();
		
		CommonConvert cc = new CommonConvert();
		cc.setDataFromPath(Constant.EDI_DATA_FROM_PATH);
		cc.setRootNode(Constant.EDI_ROOT_NODE);
		cc.setXmlConfigPath(Constant.EDI_XML_CONFIG_PATH);
		cc.setXmlToPath(Constant.EDI_XML_TO_PATH);
		cc.convert();
		
		long endTime=System.currentTimeMillis();
		System.out.println("Run Time： "+(endTime-startTime)+"ms");
	}
	
}
