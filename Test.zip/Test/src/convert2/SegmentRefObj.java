package convert2;

import java.util.List;

public class SegmentRefObj {
	private String id;
	private String pos;
	private String description;
	private List<String> elementIdList;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<String> getElementIdList() {
		return elementIdList;
	}
	public void setElementIdList(List<String> elementIdList) {
		this.elementIdList = elementIdList;
	}
	
}
