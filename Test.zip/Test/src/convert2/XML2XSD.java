package convert2;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Convert Data File into XML
 * @author brian_liu01
 */
public class XML2XSD {
	
	private static String xsdPath = "D:/EDITemp/EDI.xsd";

	private String xmlConfigPath;
	private Map<String, ElementObj> elementMap = new HashMap<String, ElementObj>();
	private Map<String, SegmentRefObj> segmentRefMap = new HashMap<String, SegmentRefObj>();
	
	private static String XS = "xs";
	private static String SCHEMA_URL = "http://www.w3.org/2001/XMLSchema";
	private static String XS_SCHEMA = "xs:schema";
	private static String XS_ELEMENT = "xs:element";
	private static String XS_COMPLEXTYPE = "xs:complexType";
	private static String XS_ALL = "xs:all";
	private static String XS_SEQUENCE = "xs:sequence";
	private static String XS_COMPLEXCONTENT = "xs:complexContent";
	private static String XS_EXTENSION = "xs:extension";
	private static String XS_ATTRIBUTE = "xs:attribute";
	private static String XS_STRING = "xs:string";
	
	private static String NAME = "name";
	private static String TYPE = "type";
	private static String MIN_OCCURS = "minOccurs";
	private static String MAX_OCCURS = "maxOccurs";
	private static String UNBOUNDED = "unbounded";
	private static String BASE = "base";
	private static String USE = "use";
	private static String FIXED = "fixed";
	private static String REQUIRED = "required";

	private static String EDI = "EDI";
	private static String SEG_REF_TYPE = "SEG_REF_TYPE";
	private static String SEGMENT_REF = "SegmentRef";
	private static String SEG = "SEG";
	private static String SEG_REF_ATTR = "SEG_REF_ATTR";
	private static String ELE_ATTR = "ELE_ATTR";
	private static String ELEMENT = "Element";
	private static String TYPE2 = "Type";
	private static String DESCRIPTION = "Description";
	private static String MAX_LENGTH = "MaxLength";
	private static String MIN_LENGTH = "MinLength";
	private static String ID = "ID";
	private static String POS = "Pos";
	private static String VALUE = "Value";
	
	
	/**
	 * convert XML configuration file to XSD
	 */
	public void convert(){
		try{
			parseConfigFile();
			convertXML2XSD();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private void convertXML2XSD() throws Exception{
		org.dom4j.Document document = org.dom4j.DocumentHelper.createDocument();
		
		//<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
		org.dom4j.Element root = document.addElement(XS_SCHEMA);
		root.addNamespace(XS, SCHEMA_URL);
		
		//<xs:element name="EDI" type="SEG_REF_TYPE"/>
		addEle(root, XS_ELEMENT, new String[][]{{NAME, EDI}, {TYPE, SEG_REF_TYPE}});
		
		/*
			<xs:complexType name="SEG_REF_TYPE">
				<xs:all>
					<xs:element name="SegmentRef-BGM" type="SEG_BGM" minOccurs="0"/>
					<xs:element name="SegmentRef-TSR" type="SEG_TSR" minOccurs="0"/>
					......
				</xs:all>
			</xs:complexType>
		 */
		org.dom4j.Element refType = addEle(root, XS_COMPLEXTYPE, new String[][]{{NAME, SEG_REF_TYPE}});
		org.dom4j.Element all = addEle(refType, XS_ALL, null);
		Set<String> keys = segmentRefMap.keySet();
		for(String key:keys){
			addEle(all, XS_ELEMENT, new String[][]{{NAME, SEGMENT_REF + "-" + key}, 
													{TYPE, SEG + "_" + key}, 
													{MIN_OCCURS, "0"}});
		}
		
		/*
			<xs:complexType name="SEG_BGM">
				<xs:sequence maxOccurs="unbounded">
					<xs:element name="SegmentRef" type = "BGM"/>
				</xs:sequence>
			</xs:complexType> 
		 */
		for(String key:keys){
			org.dom4j.Element comp = addEle(root, XS_COMPLEXTYPE, new String[][]{{NAME, SEG + "_" + key}});
			org.dom4j.Element seq = addEle(comp, XS_SEQUENCE, new String[][]{{MAX_OCCURS, UNBOUNDED}});
			addEle(seq, XS_ELEMENT, new String[][]{{NAME, SEGMENT_REF}, {TYPE, key}});
		}

		/*
			<xs:complexType name="BGM">
				<xs:complexContent>
					<xs:extension base="SEG_REF_ATTR">
						<xs:sequence>
							<xs:element name="Element" type="BGM01"/>
							<xs:element name="Element" type="BGM02"/>
							<xs:element name="Element" type="BGM03"/>
							......
						</xs:sequence>
						<xs:attribute name="Description" type="xs:string" use="required" fixed="BGM Desc"/>
					</xs:extension>
				</xs:complexContent>
			</xs:complexType>
		 */
		for(String key:keys){
			org.dom4j.Element comp = addEle(root, XS_COMPLEXTYPE, new String[][]{{NAME, key}});
			org.dom4j.Element cnt = addEle(comp, XS_COMPLEXCONTENT, null);
			org.dom4j.Element ext = addEle(cnt, XS_EXTENSION, new String[][]{{BASE, SEG_REF_ATTR}});
			org.dom4j.Element seq = addEle(ext, XS_SEQUENCE, null);
			
			SegmentRefObj obj = segmentRefMap.get(key);
			List<String> ids = obj.getElementIdList();
			for(String id:ids){
				addEle(seq, XS_ELEMENT, new String[][]{{NAME, ELEMENT}, {TYPE, id}});
			}
			
			addEle(ext, XS_ATTRIBUTE, new String[][]{{NAME, DESCRIPTION}, 
														{TYPE, XS_STRING}, 
														{USE, REQUIRED},
														{FIXED, obj.getDescription()}});
			
		}
		
		/*
			<xs:complexType name="BGM01">
				<xs:complexContent>
					<xs:extension base="ELE_ATTR">
						<xs:attribute name="Description" type="xs:string" use="required" fixed="BGM01 Desc"/>
						<xs:attribute name="Type" type="xs:string" use="required" fixed="string"/>
						<xs:attribute name="MaxLength" type="xs:string" use="required" fixed="3"/>
						<xs:attribute name="MinLength" type="xs:string" use="required" fixed="0"/>
					</xs:extension>
				</xs:complexContent>
			</xs:complexType>		  
		 */
		for(String key:keys){
			SegmentRefObj obj = segmentRefMap.get(key);
			List<String> ids = obj.getElementIdList();
			for(String id:ids){
				ElementObj sub = elementMap.get(id);
				org.dom4j.Element comp = addEle(root, XS_COMPLEXTYPE, new String[][]{{NAME, id}});
				org.dom4j.Element cnt = addEle(comp, XS_COMPLEXCONTENT, null);
				org.dom4j.Element ext = addEle(cnt, XS_EXTENSION, new String[][]{{BASE, ELE_ATTR}});
				
				addEle(ext, XS_ATTRIBUTE, new String[][]{{NAME, DESCRIPTION}, 
														{TYPE, XS_STRING}, 
														{USE, REQUIRED},
														{FIXED, sub.getDescription()}});
				
				addEle(ext, XS_ATTRIBUTE, new String[][]{{NAME, TYPE2}, 
														{TYPE, XS_STRING}, 
														{USE, REQUIRED},
														{FIXED, sub.getType()}});
				
				addEle(ext, XS_ATTRIBUTE, new String[][]{{NAME, MAX_LENGTH}, 
														{TYPE, XS_STRING}, 
														{USE, REQUIRED},
														{FIXED, sub.getMaxLength()}});
				
				addEle(ext, XS_ATTRIBUTE, new String[][]{{NAME, MIN_LENGTH}, 
														{TYPE, XS_STRING}, 
														{USE, REQUIRED},
														{FIXED, sub.getMinLength()}});
			}
		}
		
		/*
			<xs:complexType name="SEG_REF_ATTR">
				<xs:attribute name="ID" type="xs:string"/>
				<xs:attribute name="Pos" type="xs:string" use="required"/>
			</xs:complexType> 
		 */
		org.dom4j.Element segAttr = addEle(root, XS_COMPLEXTYPE, new String[][]{{NAME, SEG_REF_ATTR}});
		addEle(segAttr, XS_ATTRIBUTE, new String[][]{{NAME, ID}, {TYPE, XS_STRING}});
		addEle(segAttr, XS_ATTRIBUTE, new String[][]{{NAME, POS}, {TYPE, XS_STRING}, {USE, REQUIRED}});
		
		/*
			<xs:complexType name="ELE_ATTR">
				<xs:attribute name="ID" type="xs:string"/>
				<xs:attribute name="Pos" type="xs:string" use="required"/>
				<xs:attribute name="Value" type="xs:string" use="required"/>
			</xs:complexType> 
		 */
		org.dom4j.Element eleAttr = addEle(root, XS_COMPLEXTYPE, new String[][]{{NAME, ELE_ATTR}});
		addEle(eleAttr, XS_ATTRIBUTE, new String[][]{{NAME, ID}, {TYPE, XS_STRING}});
		addEle(eleAttr, XS_ATTRIBUTE, new String[][]{{NAME, POS}, {TYPE, XS_STRING}, {USE, REQUIRED}});
		addEle(eleAttr, XS_ATTRIBUTE, new String[][]{{NAME, VALUE}, {TYPE, XS_STRING}, {USE, REQUIRED}});
		
		org.dom4j.io.XMLWriter writer = new org.dom4j.io.XMLWriter(new FileWriter(new File(xsdPath)));
        writer.write(document);
        writer.close();
        
        FormatXML.formatXMLFile(xsdPath);
		
	}
	
	private org.dom4j.Element addEle(org.dom4j.Element parent, String name, String[][] attr){
		org.dom4j.Element child = parent.addElement(name);
		if(attr != null){
			for(int i=0;i<attr.length;i++){
				child.addAttribute(attr[i][0], attr[i][1]);
			}
		}
		return child;
	}
	
	/**
	 * Parse Configuration file
	 * @throws Exception
	 */
	private void parseConfigFile() throws Exception {
		//create XSD document
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
        Document xmlDoc = db.parse(xmlConfigPath);
        
        //get root node
        Node root = xmlDoc.getFirstChild();
        //parse root node
        parseNode(root);
	}
	
	/**
	 * Parse a node of XSD
	 * @param node
	 * @throws Exception
	 */
	private void parseNode(Node node) throws Exception{
		//iterate child node
		if(node.hasChildNodes()){
			NodeList nodeList = node.getChildNodes();
			int length = nodeList.getLength();
			for(int i=0;i<length;i++){
				parseNode(nodeList.item(i));
			}
		}
		
		String nodeName = node.getNodeName();
		//<Element>
		if(Constant.ELEMENT.equals(nodeName)){
			//create element object
			ElementObj element = new ElementObj();
			
			//get attributes
			NamedNodeMap attributes = node.getAttributes();
			
			//set attributes
			element.setId(attributes.getNamedItem(Constant.ID).getNodeValue());
			element.setPos(attributes.getNamedItem(Constant.POS).getNodeValue());
			element.setDescription(attributes.getNamedItem(Constant.DESCRIPTION).getNodeValue());
			element.setMaxLength(attributes.getNamedItem(Constant.MAX_LENGTH).getNodeValue());
			element.setMinLength(attributes.getNamedItem(Constant.MIN_LENGTH).getNodeValue());
			element.setType(attributes.getNamedItem(Constant.TYPE).getNodeValue());
			element.setLength(Integer.parseInt(attributes.getNamedItem(Constant.LENGTH).getNodeValue()));
			
			//put in element map
			elementMap.put(element.getId(), element);
			
		//<SegmentRef>
		}else if(Constant.SEGMENT_REF.equals(nodeName)){
			//create segment ref object
			SegmentRefObj segmentRef = new SegmentRefObj();
			
			//get attributes
			NamedNodeMap attributes = node.getAttributes();
			
			//set attributes
			segmentRef.setId(attributes.getNamedItem(Constant.ID).getNodeValue());
			segmentRef.setPos(attributes.getNamedItem(Constant.POS).getNodeValue());
			segmentRef.setDescription(attributes.getNamedItem(Constant.DESCRIPTION).getNodeValue());
			
			//get element list
			NodeList nodeList = node.getChildNodes();
			List<String> elementIdList = new ArrayList<String>();
			int length = nodeList.getLength();
			for(int i=0;i<length;i++){
				Node childNode = nodeList.item(i);
				if(childNode.getNodeType() != Node.ELEMENT_NODE){
					continue;
				}
				elementIdList.add(getAttribute(childNode, Constant.ID));
			}
			
			//set element list
			segmentRef.setElementIdList(elementIdList);
			
			//put in segment ref map
			segmentRefMap.put(segmentRef.getId(), segmentRef);
			
		}
		
	}
	
	/**
	 * Get attribute value
	 * @param node
	 * @param attrName
	 * @return
	 */
	private String getAttribute(Node node, String attrName){
		NamedNodeMap attributes = node.getAttributes();
		Node attribute = attributes.getNamedItem(attrName);
		return null == attribute ? null : attribute.getNodeValue();
	}
	
	public void setXmlConfigPath(String xmlConfigPath) {
		this.xmlConfigPath = xmlConfigPath;
	}

	public String getXmlConfigPath() {
		return xmlConfigPath;
	}

	public static void main(String[] args){
		long startTime=System.currentTimeMillis();
		
		XML2XSD cc = new XML2XSD();
		cc.setXmlConfigPath(Constant.EDI_XML_CONFIG_PATH);
		cc.convert();
		
		long endTime=System.currentTimeMillis();
		System.out.println("Run Time： "+(endTime-startTime)+"ms");
	}
	
}
