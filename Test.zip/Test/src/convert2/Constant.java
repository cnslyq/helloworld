package convert2;

import com.apl.davinci.services.base.EbizException;
import com.apl.davinci.services.util.ReadIni;
import com.apl.davinci.services.util.UtilsFactory;

public class Constant {
	public static String SEGMENT_REF = "SegmentRef";
	public static String ELEMENT = "Element";
	public static String ID = "ID";
	public static String POS = "Pos";
	public static String DESCRIPTION = "Description";
	public static String LENGTH = "Length";
	public static String MAX_LENGTH = "MaxLength";
	public static String MIN_LENGTH = "MinLength";
	public static String TYPE = "Type";
	public static String VALUE = "Value";
	
	public static String EDI_XML_CONFIG_PATH;
	public static String EDI_DATA_FROM_PATH;
	public static String EDI_XML_TO_PATH;
	public static String EDI_ROOT_NODE;
	
	
	private static ReadIni props;
	
	static{
		try{
			props = UtilsFactory.createIni("XSDConvert.properties");
		} catch (EbizException e) {
			e.printStackTrace();
		}
		EDI_XML_CONFIG_PATH = props.getProperty("EDI_XML_CONFIG_PATH");
		EDI_DATA_FROM_PATH = props.getProperty("EDI_DATA_FROM_PATH");
		EDI_XML_TO_PATH = props.getProperty("EDI_XML_TO_PATH");
		EDI_ROOT_NODE = props.getProperty("EDI_ROOT_NODE");
		
	}
}
