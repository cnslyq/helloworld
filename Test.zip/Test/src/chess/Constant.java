package chess;

public class Constant {

	public static int BOARD_LENGTH = 10;
	public static int BOARD_WIDTH = 9;
	public static int CAMP_RED = 1;
	public static int CAMP_BLACK = 2;
	public static String RANGE_ALL = "A";
	public static String RANGE_HALF = "H";
	public static String RANGE_SUDOKU = "S";
	
	
}
