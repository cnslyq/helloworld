package chess.piece;

import java.util.ArrayList;

public class Vehicle extends ChessPiece {

	public Vehicle(){
		rangeType = "A";
	}
	
	@Override
	public boolean stepCheck(int tx, int ty, ChessPiece[][] board) {
		// TODO Auto-generated method stub
		if(px == tx){
			if(py > ty){
				return checkLine(ty, py, "X", px, board);
			}else if(py < ty){
				return checkLine(py, ty, "X", px, board);
			}
		}else if(py == ty){
			if(px > tx){
				return checkLine(tx, px, "Y", py, board);
			}else if(px < tx){
				return checkLine(px, tx, "Y", py, board);
			}
		}
		return false;
	}
	
	private boolean checkLine(int start, int end, String type, int fixed, ChessPiece[][] board){
		if("X".equals(type)){
			for(int i=start;i<=end;i++){
				ChessPiece temp = board[fixed][i];
				if((i<end && temp != null) || (i==end && temp.getCamp() == camp))
					return false;
			}
			return true;
		}else if("Y".equals(type)){
			for(int i=start;i<=end;i++){
				ChessPiece temp = board[i][fixed];
				if((i<end && temp != null) || (i==end && temp.getCamp() == camp))
					return false;
			}
			return true;
		}
		return false;
	}

	@Override
	public ArrayList<int[]> stepList(ChessPiece[][] board) {
		// TODO Auto-generated method stub
		ArrayList<int[]> list = new ArrayList<int[]>();
		
		for(int i=px+1;i<=range.getEx();i++){
			if(addStep(list, i, py, board))
				break;
		}
		for(int i=px-1;i>=range.getSx();i--){
			if(addStep(list, i, py, board))
				break;
		}
		for(int i=py+1;i<=range.getEy();i++){
			if(addStep(list, px, i, board))
				break;
		}
		for(int i=py-1;i>=range.getSy();i--){
			if(addStep(list, px, i, board))
				break;
		}
		
		return list;
	}
	
	private boolean addStep(ArrayList<int[]> list, int x, int y, ChessPiece[][] board){
		if(board[x][y] == null){
			list.add(new int[]{x, y});
		}else{
			if(camp != board[x][y].getCamp())
				list.add(new int[]{x, y});
			return true;
		}
		return false;
	}
	
}
