package chess.piece;

import java.util.ArrayList;

public class Horse extends ChessPiece {

	public Horse(){
		rangeType = "A";
	}

	@Override
	protected boolean stepCheck(int tx, int ty, ChessPiece[][] board) {
		// TODO Auto-generated method stub
		if(Math.abs(px - tx) == 1 && Math.abs(py - ty) == 2){
			if(py > ty){
				if(board[px][py-1] == null && targetCheck(board[tx][ty]))
					return true;
			}else if(py < ty){
				if(board[px][py+1] == null && targetCheck(board[tx][ty]))
					return true;
			}
		}else if(Math.abs(px - tx) == 2 && Math.abs(py - ty) == 1){
			if(px > tx){
				if(board[px-1][py] == null && targetCheck(board[tx][ty]))
					return true;
			}else if(px < tx){
				if(board[px+1][py] == null && targetCheck(board[tx][ty]))
					return true;
			}
		}
		return false;
	}

	@Override
	public ArrayList<int[]> stepList(ChessPiece[][] board) {
		// TODO Auto-generated method stub
		ArrayList<int[]> list = new ArrayList<int[]>();
		int[][] array = {{px+2, py+1, px+1, py}, {px+2, py-1, px+1, py},
						 {px-2, py+1, px-1, py}, {px-2, py-1, px-1, py},
						 {px+1, py+2, px, py+1}, {px-1, py+2, px, py+1},
						 {px+1, py-2, px, py-1}, {px-1, py-2, px, py-1}};
		for(int[] temp:array){
			if(rangeCheck(temp[0], temp[1]) && targetCheck(board[temp[0]][temp[1]])
					&& board[temp[2]][temp[3]] == null){
				list.add(temp);
			}
		}
		return list;
	}
	
}
