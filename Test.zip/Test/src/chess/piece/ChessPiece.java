package chess.piece;

import java.util.ArrayList;

import chess.ChessUtil;
import chess.PieceRange;

public abstract class ChessPiece {

	protected int px;
	protected int py;
	protected int camp;
	protected String rangeType;
	protected PieceRange range;

	public void step(int tx, int ty, ChessPiece[][] board){
		if(rangeCheck(tx, ty)){
			if(stepCheck(tx, ty, board)){
				board[px][py] = null;
				px = tx;
				py = ty;
				board[px][py] = this;
			}else{
				System.out.println("Wrong Step!!");
			}
		}else{
			System.out.println("Out of Bound!");
		}
	}
	
	protected boolean rangeCheck(int tx, int ty){
		if((px == tx && py == ty) || tx < range.getSx() || ty < range.getSy() || tx > range.getEx() || ty > range.getEy())
			return false;
		return true;
	}
	
	protected boolean targetCheck(ChessPiece piece){
		if(piece == null || this.camp != piece.getCamp())
			return true;
		return false;
	}
	
	protected abstract boolean stepCheck(int tx, int ty, ChessPiece[][] board);
	
	public abstract ArrayList<int[]> stepList(ChessPiece[][] board);
	
	public int getPx() {
		return px;
	}

	public void setPx(int px) {
		this.px = px;
	}

	public int getPy() {
		return py;
	}

	public void setPy(int py) {
		this.py = py;
	}

	public int getCamp() {
		return camp;
	}

	public void setCamp(int camp) {
		this.camp = camp;
		range = ChessUtil.getRange(camp, rangeType);
	}

}
