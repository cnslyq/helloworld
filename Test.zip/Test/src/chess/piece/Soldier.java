package chess.piece;

import java.util.ArrayList;

import chess.Constant;

public class Soldier extends ChessPiece {

	public Soldier(){
		rangeType = "A";
	}
	
	@Override
	protected boolean stepCheck(int tx, int ty, ChessPiece[][] board) {
		// TODO Auto-generated method stub
		if(!(Math.abs(px-tx) == 1 && py==ty) && !(px==tx && Math.abs(py-ty) == 1))
			return false;
		if((camp == Constant.CAMP_RED && py > ty) || (camp == Constant.CAMP_BLACK && py < ty))
			return false;
		return targetCheck(board[tx][ty]);
	}

	@Override
	public ArrayList<int[]> stepList(ChessPiece[][] board) {
		// TODO Auto-generated method stub
		ArrayList<int[]> list = new ArrayList<int[]>();
		int[][] array;
		if(camp == Constant.CAMP_RED){
			array = new int[][]{{px+1, py}, {px-1, py}, {px, py+1}};
		}else{
			array = new int[][]{{px+1, py}, {px-1, py}, {px, py-1}};
		}
		for(int[] temp:array){
			if(rangeCheck(temp[0], temp[1]) && targetCheck(board[temp[0]][temp[1]])){
				list.add(temp);
			}
		}
		return list;
	}

}
