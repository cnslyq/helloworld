package chess.piece;

import java.util.ArrayList;

public class General extends ChessPiece {

	public General(){
		rangeType = "S";
	}
	
	@Override
	protected boolean stepCheck(int tx, int ty, ChessPiece[][] board) {
		// TODO Auto-generated method stub
		if(!(Math.abs(px-tx) == 1 && py==ty) && !(px==tx && Math.abs(py-ty) == 1))
			return false;
		return targetCheck(board[tx][ty]);
	}

	@Override
	public ArrayList<int[]> stepList(ChessPiece[][] board) {
		// TODO Auto-generated method stub
		ArrayList<int[]> list = new ArrayList<int[]>();
		int[][] array = {{px+1, py}, {px-1, py}, {px, py+1}, {px, py-1}};
		for(int[] temp:array){
			if(rangeCheck(temp[0], temp[1]) && targetCheck(board[temp[0]][temp[1]])){
				list.add(temp);
			}
		}
		return list;
	}

}
