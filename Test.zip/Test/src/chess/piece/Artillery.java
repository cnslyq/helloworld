package chess.piece;

import java.util.ArrayList;

public class Artillery extends ChessPiece {

	public Artillery(){
		rangeType = "A";
	}
	
	@Override
	public boolean stepCheck(int tx, int ty, ChessPiece[][] board) {
		// TODO Auto-generated method stub
		if(px == tx){
			if(py > ty){
				return checkLine(ty, py, "X", px, board);
			}else if(py < ty){
				return checkLine(py, ty, "X", px, board);
			}
		}else if(py == ty){
			if(px > tx){
				return checkLine(tx, px, "Y", py, board);
			}else if(px < tx){
				return checkLine(px, tx, "Y", py, board);
			}
		}
		return false;
	}
	
	private boolean checkLine(int start, int end, String type, int fixed, ChessPiece[][] board){
		int count = 0;
		if("X".equals(type)){
			for(int i=start;i<end;i++){
				if(board[fixed][i] != null)
					count++;
			}
			if((count == 0 && board[fixed][end] == null) || (count == 1 && camp != board[fixed][end].getCamp()))
				return true;
		}else if("Y".equals(type)){
			for(int i=start;i<end;i++){
				if(board[i][fixed] != null)
					count++;
			}
			if((count == 0 && board[end][fixed] == null) || (count == 1 && camp != board[end][fixed].getCamp()))
				return true;
		}
		return false;
	}

	@Override
	public ArrayList<int[]> stepList(ChessPiece[][] board) {
		// TODO Auto-generated method stub
		ArrayList<int[]> list = new ArrayList<int[]>();
		
		boolean flag = false;
		for(int i=px+1;i<=range.getEx();i++){
			if(!flag){
				if(addStep(list, i, py, board)){
					flag = true;
				}
			}else{
				if(addStep2(list, i, py, board)){
					break;
				}
			}
		}
		
		flag = false;
		for(int i=px-1;i>=range.getSx();i--){
			if(!flag){
				if(addStep(list, i, py, board)){
					flag = true;
				}
			}else{
				if(addStep2(list, i, py, board)){
					break;
				}
			}
		}
		
		flag = false;
		for(int i=py+1;i<=range.getEy();i++){
			if(!flag){
				if(addStep(list, px, i, board)){
					flag = true;
				}
			}else{
				if(addStep2(list, px, i, board)){
					break;
				}
			}
		}
		
		flag = false;
		for(int i=py-1;i>=range.getSy();i--){
			if(!flag){
				if(addStep(list, px, i, board)){
					flag = true;
				}
			}else{
				if(addStep2(list, px, i, board)){
					break;
				}
			}
		}
		
		return list;
	}
	
	private boolean addStep(ArrayList<int[]> list, int x, int y, ChessPiece[][] board){
		if(board[x][y] == null){
			list.add(new int[]{x, y});
		}else{
			return true;
		}
		return false;
	}
	
	private boolean addStep2(ArrayList<int[]> list, int x, int y, ChessPiece[][] board){
		if(board[x][y] != null){
			if(camp != board[x][y].getCamp())
				list.add(new int[]{x,y});
			return true;
		}
		return false;
	}

}
