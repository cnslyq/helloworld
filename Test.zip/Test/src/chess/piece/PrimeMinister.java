package chess.piece;

import java.util.ArrayList;

public class PrimeMinister extends ChessPiece {

	public PrimeMinister(){
		rangeType = "H";
	}
	
	@Override
	protected boolean stepCheck(int tx, int ty, ChessPiece[][] board) {
		// TODO Auto-generated method stub
		if(Math.abs(px-tx) != 2 || Math.abs(py-ty) != 2)
			return false;
		if(board[(px+tx)/2][(py+ty)/2] == null && targetCheck(board[tx][ty]))
			return true;
		return false;
	}

	@Override
	public ArrayList<int[]> stepList(ChessPiece[][] board) {
		// TODO Auto-generated method stub
		ArrayList<int[]> list = new ArrayList<int[]>();
		int[][] array = {{px+2, py+2}, {px-2, py-2}, {px-2, py+2}, {px+2, py-2}};
		for(int[] temp:array){
			if(rangeCheck(temp[0], temp[1]) && targetCheck(board[temp[0]][temp[1]])
					&& board[(px+temp[0])/2][(py+temp[1])/2] == null){
				list.add(temp);
			}
		}
		return list;
	}

}
