package chess.piece;

import java.util.ArrayList;

public class Guard extends ChessPiece {

	public Guard(){
		rangeType = "S";
	}
	
	@Override
	protected boolean stepCheck(int tx, int ty, ChessPiece[][] board) {
		// TODO Auto-generated method stub
		if(Math.abs(px-tx) != 1 || Math.abs(py-ty) != 1)
			return false;
		return targetCheck(board[tx][ty]);
	}

	@Override
	public ArrayList<int[]> stepList(ChessPiece[][] board) {
		// TODO Auto-generated method stub
		ArrayList<int[]> list = new ArrayList<int[]>();
		int[][] array = {{px+1, py+1}, {px-1, py-1}, {px-1, py+1}, {px+1, py-1}};
		for(int[] temp:array){
			if(rangeCheck(temp[0], temp[1]) && targetCheck(board[temp[0]][temp[1]])){
				list.add(temp);
			}
		}
		return list;
	}

}
