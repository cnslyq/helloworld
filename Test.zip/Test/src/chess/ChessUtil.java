package chess;

import java.io.FileInputStream;
import java.util.Properties;


public class ChessUtil {

	private static Properties prop;
	
	static{
		try {
			FileInputStream is = new FileInputStream("chess/range.properties");
			prop.load(is);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static PieceRange getRange(int camp, String type){
		String str = prop.getProperty(camp + type);
		String[] arr = str.split(",");
		PieceRange range = new PieceRange();
		range.setSx(Integer.parseInt(arr[0]));
		range.setEx(Integer.parseInt(arr[1]));
		range.setSy(Integer.parseInt(arr[2]));
		range.setEy(Integer.parseInt(arr[3]));
		return range;
	}
	
}
