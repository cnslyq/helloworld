package chess;

import java.io.BufferedReader;
import java.io.FileReader;

import chess.piece.ChessPiece;

public class ChessBoard {

	private static ChessPiece[][] board = new ChessPiece[Constant.BOARD_WIDTH][Constant.BOARD_LENGTH];
	
	static{
		try {
			BufferedReader br = new BufferedReader(new FileReader("chess/piece.txt"));
			String s = "";
			while((s = br.readLine()) != null){
				String[] arr = s.split(",");
				int x = Integer.parseInt(arr[1]);
				int y = Integer.parseInt(arr[2]);
				Class<?> c = Class.forName("chess." + arr[0]);
				ChessPiece piece1 = (ChessPiece)c.newInstance();
				piece1.setCamp(Constant.CAMP_RED);
				piece1.setPx(x);
				piece1.setPy(y);
				board[x][y] = piece1;
				ChessPiece piece2 = (ChessPiece)c.newInstance();
				piece2.setCamp(Constant.CAMP_BLACK);
				piece2.setPx(x);
				piece2.setPy(Constant.BOARD_LENGTH-1-y);
				board[x][Constant.BOARD_LENGTH-1-y] = piece2;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static ChessPiece[][] getChessBoard(){
		return board;
	}
	
	
	
}
