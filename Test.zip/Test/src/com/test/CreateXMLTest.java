package com.test;

import java.util.ArrayList;
import java.util.List;
/*
 * Source
 * 1 A
 * 2 B
 * 3 C
 * 2 D
 * 
 * Target
 * <A>
 *   <B>
 * 	   <C>
 *     </C>
 *   </B>
 *   <D>
 *   </D>
 * </A>
 * 
 */
public class CreateXMLTest {

	private List<String[]> list = new ArrayList<String[]>();
	private String filename = "";
	
	public CreateXMLTest(){
		//read file, add each row to list
	}
	
	private void printStart(int line){
		int n = getNum(line);
		String name = getName(line);
		for(int i=0; i<n; i++){
			System.out.print("\t");
		}
		System.out.println("<" + name + ">");
	}
	
	private void printEnd(int line){
		int n = getNum(line);
		String name = getName(line);
		for(int i=0; i<n; i++){
			System.out.print("\t");
		}
		System.out.println("<" + name + "/>");
	}
	
	private int getNum(int line){
		return Integer.parseInt(list.get(line)[0]);
	}
	
	private String getName(int line){
		return list.get(line)[1];
	}
	
	private void print(int line){
		int num = getNum(line);
		printStart(line);
		
		if(line < list.size()-1){
			int nextNum = getNum(line+1);
			if(nextNum <= num){
				printEnd(line);
				print(line+1);
			}else if(nextNum > num){
				print(line+1);
				printEnd(line);
			}
		}else{
			printEnd(line);
		}
	}
	
	public static void main(String args[]){
		CreateXMLTest test = new CreateXMLTest();
		test.print(0);
	}
	
}
