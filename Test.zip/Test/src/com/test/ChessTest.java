package com.test;

public class ChessTest {

	public static int WHITE = 1;
	public static int BLACK = 2;
	private int value = WHITE;
	private int x = 5;
	private int y = 5;
	private int[][] array = new int[x][y];
	
	
	public void convert(int px, int py){
		if(0 != array[px][py])
			return;
		
		if(value == WHITE){
			value = BLACK;
		}else{
			value = WHITE;
		}
		array[px][py] = value;
		if(!convertLine(px, py, 0, 1, value))
			convertLine(px, py, 0, -1, value);
		if(!convertLine(px, py, 1, -1, value))
			convertLine(px, py, -1, 1, value);
		if(!convertLine(px, py, 1, 0, value))
			convertLine(px, py, -1, 0, value);
		if(!convertLine(px, py, 1, 1, value))
			convertLine(px, py, -1, -1, value);
	}
	
	private boolean convertLine(int px, int py, int dx, int dy, int value){
		if(findPosition(px, py, dx, dy, value)){
			px = px + dx;
			py = py + dy;
			while(px>=0 && px<x && py>=0 && py<y){
				if(value == array[px][py]){
					break;
				}
				array[px][py] = value;
				px = px + dx;
				py = py + dy;
			}
			return true;
		}
		return false;
	}
	
	private boolean findPosition(int px, int py, int dx, int dy, int value){
		px = px + dx;
		py = py + dy;
		while(px>=0 && px<x && py>=0 && py<y){
			if(value == array[px][py]){
				return true;
			}
			px = px + dx;
			py = py + dy;
		}
		return false;
	}
	
	public void print(){
		System.out.print("  ");
		for(int i=0;i<x;i++){
			System.out.print(i + " ");
		}
		System.out.println();
		for(int j=0;j<y;j++){
			System.out.print(j + " ");
			for(int i=0;i<x;i++){
				if(0 == array[i][j]){
					System.out.print("  ");
				}else if(WHITE == array[i][j]){
					System.out.print("○ ");
				}else if(BLACK == array[i][j]){
					System.out.print("● ");
				}
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args){
		ChessTest test = new ChessTest();
		test.convert(2, 3);
		test.convert(0, 2);
		test.convert(0, 1);
		test.print();
		System.out.println("*********************************");
		test.convert(4, 2);
		test.print();
		System.out.println("*********************************");
		test.convert(2, 1);
		test.print();
		System.out.println("*********************************");
		test.convert(4, 2);
		test.print();
		System.out.println("*********************************");
		test.convert(1, 0);
		test.print();
		System.out.println("*********************************");
		test.convert(4, 1);
		test.print();
	}
	
	
}
