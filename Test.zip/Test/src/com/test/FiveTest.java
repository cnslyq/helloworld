package com.test;

public class FiveTest {

	private int x = 9;
	private int y = 9;
	private int[][] array = new int[x][y];
	private int[][] dArray = {{1, 0, -1, 0}, {1, 1, -1, -1}, {0, 1, 0, -1}, {1, -1, -1, 1}};
	private static int BLACK = 1;
	private static int WHITE = 2;
	private int current = BLACK;
	
	public void step(int px, int py){
		array[px][py] = current;
		if(checkFive(px, py)){
			System.out.println((current == BLACK? "BLACK" : "WHITE") + " Win!!!");
			return;
		}
		current = (current == BLACK ? WHITE : BLACK);
		
	}
	
	private boolean checkFive(int px, int py){
		for(int i=0;i<4;i++){
			int count = 0;
			count += checkLine(px, py, dArray[i][0], dArray[i][1]);
			count += checkLine(px, py, dArray[i][2], dArray[i][3]);
			if(count >= 4)
				return true;
		}
		return false;
	}
	
	private int checkLine(int px, int py, int dx, int dy){
		int count = 0;
		px = px + dx;
		py = py + dy;
		while(px>=0 && px<x && py>=0 && py<y){
			if(array[px][py] == current){
				count++;
			}else{
				break;
			}
			px = px + dx;
			py = py + dy;
		}
		return count;
	}
	
	public void print(){
		System.out.print("  ");
		for(int i=0;i<x;i++){
			System.out.print(i + " ");
		}
		System.out.println();
		for(int j=0;j<y;j++){
			System.out.print(j + " ");
			for(int i=0;i<x;i++){
				if(0 == array[i][j]){
					System.out.print("  ");
				}else if(WHITE == array[i][j]){
					System.out.print("○ ");
				}else if(BLACK == array[i][j]){
					System.out.print("● ");
				}
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args){
		FiveTest test = new FiveTest();
		test.step(4, 4);
		//test.print();
		//System.out.println("*******************************");
		test.step(4, 5);
		//test.print();
		//System.out.println("*******************************");
		test.step(5, 5);
		test.print();
		System.out.println("*******************************");
	}
	
}
