package com.test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Test {

	private void testStringBufferInsert(){
		StringBuffer sb = new StringBuffer("abcdefghijklmnopqrstuvwxyz");
		char[] c = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
		sb.insert(3, c, 0, 5);
		System.out.println(sb.toString());
	}
	
	public ArrayList<int[]> getList(int px, int py, int d1, int d2){
		ArrayList<int[]> list = new ArrayList<int[]>();
		if(d1 > 0){
			list.add(new int[]{px+d1, py+d1});
			list.add(new int[]{px+d1, py-d1});
			list.add(new int[]{px-d1, py+d1});
			list.add(new int[]{px-d1, py-d1});
		}
		if(d2 > 0){
			list.add(new int[]{px+d2, py+d2});
			list.add(new int[]{px+d2, py-d2});
			list.add(new int[]{px-d2, py+d2});
			list.add(new int[]{px-d2, py-d2});
		}
		if(d1 < 0){
			
		}
		if(d2 < 0){
			
		}
		return list;
	}
	
	public static void initMap(Map<Integer, Integer> map, int startIdx, int length, int factor){
		for(int i=startIdx;i<startIdx + length;i++){
			map.put(i, i * factor);
		}
	}
	
	public static void printMap(Map<Integer, Integer> map){
		System.out.println("****************************************************");
		for(int key : map.keySet()){
			System.out.println(key + " : " + map.get(key));
		}
		System.out.println("****************************************************");
	}
	
	public static void add(Integer i){
		i++;
		System.out.println(i);
	}
	
	public static Map<Integer, Long> mergeCvMap(Map<Integer, Long> thisWeekCommittedCvMap, 
			Map<Integer, Long> lastWeekRemainCvMap){
		
		Map<Integer, Long> remainCvMap = new HashMap<Integer, Long>();
		remainCvMap.putAll(thisWeekCommittedCvMap);
		
		for(int cvKey : thisWeekCommittedCvMap.keySet()){
			if(null != lastWeekRemainCvMap.get(cvKey)){
				remainCvMap.put(cvKey, thisWeekCommittedCvMap.get(cvKey) + lastWeekRemainCvMap.get(cvKey));
			}
		}
		return remainCvMap;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		/*
		Map<Integer, Long> thisWeekCommittedCvMap = new HashMap<Integer, Long>();
		thisWeekCommittedCvMap.put(1, 1L);
		thisWeekCommittedCvMap.put(3, 30L);
		Map<Integer, Long> lastWeekRemainCvMap = new HashMap<Integer, Long>();
		lastWeekRemainCvMap.put(1, 10L);
		lastWeekRemainCvMap.put(2, 20L);
		Map<Integer, Long> remainCVMap = mergeCvMap(thisWeekCommittedCvMap, lastWeekRemainCvMap);
		for(Integer key : remainCVMap.keySet()){
			System.out.println(key + " : " + remainCVMap.get(key));
		}
		*/
		/*
		List<Integer> list = new ArrayList<Integer>();
		List<Integer> delList = new ArrayList<Integer>();
		for(int i=1;i<10;i++){
			list.add(i*10);
		}
		for(Integer i : list){
			if(30 == i || 40 == i)
				delList.add(i);
		}
		list.removeAll(delList);
		for(Integer i : list){
			System.out.println(i);
		}
		*/
		/*
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = formatter.parse("2015-12-30");
		Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2016, 0, 1);
        Date date2 = cal.getTime();
        boolean after = date2.after(date);
        System.out.println("after : " + after);
        */
		/*
		float a = 0.3f;
		float b = 10f;
		System.out.println(a/b);
		
		a *= b;
		System.out.println(a);
		System.out.println(a/b);
		*/
		/*
		Date date = new Date();
		Date date2 = null;
		if(date2.after(date2)){
			System.out.println("1");
		}else{
			System.out.println("2");
		}
		*/
		
		/*
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date endDate = sdf.parse("20160125");
		Date targetDate = sdf.parse("20151123");
		while(targetDate.compareTo(endDate) <= 0){
			System.out.println(targetDate);
			targetDate = getMondayDateByWeeks(targetDate, 1);
		}
		*/
		
		//System.out.println(date.compareTo(date2));
		//System.out.println(date2.after(date));
		
		//System.out.println(true ? 0 : 1 - 2);
		
		System.out.println("" + 1 + 2);
		System.out.println(1 + 3 + "");
		
		
	}
	
	public static Date getMondayDateByWeeks(Date date, int weeks) {
		int days = weeks * 7;
		Calendar calendar = Calendar.getInstance();
		Date modayDate = getMondayDateByDate(date);
		calendar.setTime(modayDate);
		calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + days);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}
	
	public static Date getMondayDateByDate(Date date) {
		Calendar cal = Calendar.getInstance();

		cal.setTime(date);

		cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);

		return cal.getTime();
	}

}
