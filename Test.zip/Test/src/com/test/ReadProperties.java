package com.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadProperties {

	private static String filename = "D:/APL/Drayman/ltptapp/ltptappWeb/JavaSource/ltptapp.properties";
	private static String[] properties = new String[]{"CICS_PROGID", 
													  "CICS_TRANID", 
													  "CICS_LINKPID", 
													  "CICS_CVDESIG", 
													  "CICS_READY_MODE", 
													  "CICS_HOST"};
	private static String[] environments = new String[]{"DEV", "INT", "STG", "LVT", "PRD"};
	
	public static void readProperties() throws FileNotFoundException, IOException{
		Properties props = new Properties();
		props.load(new FileInputStream(new File(filename)));
		//print title
		System.out.print("ENVIRONMENT"+",");
		for(String prop:properties){
			System.out.print(prop+",");
		}
		System.out.println();
		//print content
		for(String env:environments){
			System.out.print(env+",");
			for(String prop:properties){
				System.out.print(props.get(env+"_"+prop)+",");
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		try {
			readProperties();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
