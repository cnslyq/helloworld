package com.test;

public class FlyChessTest {

	private int size = 20;
	private int[] array = new int[size];
	private static int RED = 0;
	private static int GREEN = 1;
	private static int BLUE = 2;
	private static int YELLOW = 3;
	private static int[] COLORS = new int[]{RED, GREEN, BLUE, YELLOW};
	private int[] positions = new int[]{-1, -1, -1, -1};
	private int index = 0;
	
	public FlyChessTest(){
		init();
	}
	
	private void init(){
		for(int i=0;i<size;i++){
			array[i] = COLORS[i%4];
		}
	}
	
	private int getCurrentColor(){
		if(index == COLORS.length){
			index = 0;
		}
		return COLORS[index];
	}
	
	private int getCurrentPosition(){
		if(index == positions.length){
			index = 0;
		}
		return positions[index];
	}
	
	private int getStep(){
		return (int)Math.round(Math.random() * 6) + 1;
	}
	
	public void dice(){
		int color = getCurrentColor();
		int position = getCurrentPosition();
		int step = getStep();
		position += step;
		if(position == size){
			System.out.println("You Win!!");
		}else if(position > size){
			position = size * 2 - position;
		}
		if(color == array[position]){
			position += 4;
			if(position == size){
				System.out.println("You Win!!");
			}else if(position > size){
				position = size * 2 - position;
			}
		}
		
		positions[index] = position;
		index++;
	}
	
	public void print(){
		for(int i=0;i<positions.length;i++){
			System.out.print(positions[i] + "  ");
		}
		System.out.println();
	}
	
	public static void main(String[] args){
		FlyChessTest test = new FlyChessTest();
		for(int i=0;i<8;i++){
			test.dice();
			test.print();
		}
	}
	
	
}
