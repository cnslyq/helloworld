package com.test;

public class ArrayTest {

	private int x = 3;
	private int y = 3;
	private boolean[][] array = new boolean[x][y];
	private int[] rows = new int[y];
	private int[] columns = new int[x];
	
	public void init(){
		for(int i=0;i<x;i++){
			for(int j=0;j<y;j++){
				double d = Math.random();
				if(d < 0.5){
					array[i][j] = true;
				}else{
					array[i][j] = false;
				}
			}
		}
		
		for(int i=0;i<x;i++){
			int count = 0;
			for(int j=0;j<y;j++){
				if(array[i][j])
					count++;
			}
			columns[i] = count;
		}
		
		for(int j=0;j<y;j++){
			int count = 0;
			for(int i=0;i<x;i++){
				if(array[i][j])
					count++;
			}
			rows[j] = count;
		}
		
	}
	
	
	public void print(){
		System.out.print("\t");
		for(int i=0;i<x;i++){
			System.out.print(columns[i] + "\t");
		}
		System.out.println();
		
		for(int j=0;j<y;j++){
			System.out.print(rows[j] + "\t");
			for(int i=0;i<x;i++){
				System.out.print((array[i][j] ? "O" : "X") + "\t");
			}
			System.out.println();
		}
		
	}
	
	
	public static void main(String[] args){
		
		ArrayTest test = new ArrayTest();
		test.init();
		test.print();
		
	}
	
}
