package com.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile {

	public static boolean getLinesOfFiles(String filepath, String appName, String[] fileSuffix) 
	  			throws FileNotFoundException, IOException {
		try {
			File file = new File(filepath);
			if(!file.isDirectory()){
				for(String suffix : fileSuffix){
					if(filepath.endsWith(suffix)){
						System.out.println(appName+","+file.getName()+","+file.getPath()+","+getLinesOfFile(file));
						break;
					}
				}
			}else if(file.isDirectory()){
				String[] filelist = file.list();
				for (int i = 0; i < filelist.length; i++) {
					File readfile = new File(filepath + "\\" + filelist[i]);
					if (!readfile.isDirectory()) {
						for(String suffix : fileSuffix){
							if(readfile.getName().endsWith(suffix)){
								System.out.println(appName+","+readfile.getName()+","+readfile.getPath()+","+getLinesOfFile(readfile));
								break;
							}
						}
					}else if(readfile.isDirectory()){
						getLinesOfFiles(filepath + "\\" + filelist[i], appName, fileSuffix);
					}
				}
			}
	    }catch(FileNotFoundException e){
	    	e.printStackTrace();
	    }
	    return true;
	}
	
	private static int getLinesOfFile(File filename) throws FileNotFoundException, IOException{
		int count = 0;
		BufferedReader br = new BufferedReader(new FileReader(filename));
		while(br.readLine() != null){
			count++;
		}
		return count;
	}

	public static boolean search(String filepath, String appName, String searchStr, String[] fileSuffix)
				throws FileNotFoundException, IOException {
		File file = new File(filepath);
		String[] filelist = file.list();
		for (int i = 0; i < filelist.length; i++) {
			File readfile = new File(filepath + "\\" + filelist[i]);
			if (!readfile.isDirectory()) {
				for(String suffix : fileSuffix){
					if(readfile.getName().endsWith(suffix)){
						String tempStr = "";
						BufferedReader br = new BufferedReader(new FileReader(readfile));
						while((tempStr = br.readLine()) != null){
							if(tempStr.contains(searchStr)){
								System.out.println(appName+","+readfile.getName()+","+readfile.getPath());
								break;
							}
						}
					}
				}
			}else if(readfile.isDirectory()){
				search(filepath + "\\" + filelist[i], appName, searchStr, fileSuffix);
			}
		}
		return true;
	}
	
	public static int countFiles(String filepath, String fileSuffix, int cnt) 
			throws FileNotFoundException, IOException {
		try {
			File file = new File(filepath);
			if(!file.isDirectory()){
				if(filepath.endsWith(fileSuffix)){
					cnt++;
				}
			}else if(file.isDirectory()){
				String[] filelist = file.list();
				for (int i = 0; i < filelist.length; i++) {
					File readfile = new File(filepath + "\\" + filelist[i]);
					if (!readfile.isDirectory()) {
						if(readfile.getName().endsWith(fileSuffix)){
							cnt++;
						}
					}else if(readfile.isDirectory()){
						cnt += countFiles(filepath + "\\" + filelist[i], fileSuffix, 0);
					}
				}
			}
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
		return cnt;
	}

	
	public static void main(String[] args){
		try {
			long startTime=System.currentTimeMillis();  

			//String appPath = "D:/APL/Drayman/drayin";
			String appPath = "D:/temp";
			String appName = "drayin";
			String searchStr = "new ActionError(";
			//String[] fileSuffix = new String[]{".jsp", ".html", ".htm", ".inc", ".js"};
			//String[] fileSuffix = new String[]{".java"};
			String[] fileSuffix = new String[]{".fex", ".html", ".htm", ".cgi"};
			
			//getLinesOfFiles(appPath, appName, fileSuffix);
			//search(appPath, appName, searchStr, fileSuffix);

			//for(String suffix : fileSuffix){
			//	System.out.print(suffix.substring(1).toUpperCase() + ",");
			//}
			//System.out.println();
			for(String suffix : fileSuffix){
				System.out.print(countFiles(appPath, suffix, 0) + ",");
			}
			System.out.println();
			
			long endTime=System.currentTimeMillis();
			System.out.println("*************************************************");
			System.out.println("Run Time： "+(endTime-startTime)+"ms");   
		
		}catch(FileNotFoundException ex){
			ex.printStackTrace();
		}catch(IOException ex){
			ex.printStackTrace();
		}
	}
}
