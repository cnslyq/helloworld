package EJB.server;

import EJB.Person;

public class PersonServer implements Person {

	private int age;
	private String name;
	
	public PersonServer(String name, int age){
		this.name = name;
		this.age = age;
	}
	
	public int getAge() throws Throwable {
		return age;
	}

	public String getName() throws Throwable {
		return name;
	}

}
