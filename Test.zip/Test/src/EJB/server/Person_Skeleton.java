package EJB.server;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import EJB.Person;

public class Person_Skeleton extends Thread{

	private Person person;
	
	public Person_Skeleton(Person person){
		this.person = person;
	}

	public void run(){
		try{
			ServerSocket serverSocket = new ServerSocket(9000);
			Socket socket = serverSocket.accept();
			while(socket != null){
				ObjectInputStream inStream =
					new ObjectInputStream(socket.getInputStream());
				String method = (String)inStream.readObject();
				if("age".equals(method)){
					int age = person.getAge();
					ObjectOutputStream outStream =
						new ObjectOutputStream(socket.getOutputStream());
					outStream.writeInt(age);
					outStream.flush();
				}else if("name".equals(method)){
					String name = person.getName();
					ObjectOutputStream outStream = 
						new ObjectOutputStream(socket.getOutputStream());
					outStream.writeObject(name);
					outStream.flush();
				}
			}
		}catch(Throwable t){
			t.printStackTrace();
			System.exit(0);
		}
	}
	
	public static void main(String[] args){
		Person person = new PersonServer("liu", 27);
		Person_Skeleton skeleton = new Person_Skeleton(person);
		skeleton.run();
	}
	
}
