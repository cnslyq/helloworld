package EJB.client;

import EJB.Person;

public class PersonClient {

	public static void main(String[] args){
		try{
	       /*
	        * 客户端从服务器获得HomeImpl_stub .class文件,并获得HomeImpl_stub的对象
	        * 
	        * home.create()-->HomeImpl_stub.create()-->网络发送-->HomeImpl_skel.create()-->
	        * HomeImpl创建ComputeBean对象-->
	        * ComputeBean.ejbcreate()&&HomeImpl还要创建EOImpl_stub对象,返回HomeImpl_skel--->
	        * [网络往回传输]--->HomeImpl_stub--->客户端拿到EOImpl_stub对象。
	        *
	        * 这时完成了第一次rmi
	        *
	        * c获得了EOImpl_Stub对象,
	        * 
	        * c.add(32,32)----> EOImpl_Stub.add()--->网络发送--->EOImpl_Skel.add()--->
	        * EOImpl--->[根据xml描述的事务,进行事务描述]--->判断add方法是否开始事务--->
	        * 调用创建好Bean对象的add方法---->方法结果给EOImpl_Skel---->网络往回传输---->
	        * EOImpl_Stub----客户端拿到结果。
	        *
	        * 第二次rmi完成。
		    */			
			
			Person person = new Person_Stub();
			System.out.println(person.getAge());
			System.out.println(person.getName());
		}catch(Throwable t){
			t.printStackTrace();
		}
	}
	
}
