package probability;
//求排列，求各种排列或组合后排列
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import convert.ElementObj;

public class Permutation {
    private static boolean f[];
    
    /**
     * 
     * @param num 表示要排列的数组
     * @param str 以排列好的字符串
     * @param nn  剩下需要排列的个数，如果需要全排列，则nn为数组长度
     */
    private static void count(int[] num, String str, int nn) {
        if(nn==0){
            System.out.println(str);
            return;
        }
        for(int i=0;i<num.length;i++){
            if(!f[i]){
                continue;
            }
            f[i]=false;
            count(num,str+num[i],nn-1);
            f[i]=true;
        }
    }
    
    private static void count(char[] source, char[] chars, int index, int n){
    	if(n == 0){
    		for(int i=0;i<chars.length;i++){
    			System.out.print(chars[i] + "  ");
    		}
    		System.out.println();
    		return;
    	}
    	
    	for(int i=0;i<source.length;i++){
    		if(!f[i]){
    			continue;
    		}
    		f[i] = false;
    		chars[index] = source[i];
    		count(source, chars, index+1, n-1);
    		f[i] = true;
    	}
    	
    }
    
    private static ArrayList<Object[]> permutation(Object[] source, Object[] objs, int idx, int n){
    	ArrayList<Object[]> result = new ArrayList<Object[]>();
    	if(n == 0){
    		result.add(objs.clone());
    		return result;
    	}
    	
    	for(int i=0;i<source.length;i++){
    		if(!f[i]){
    			continue;
    		}
    		f[i] = false;
    		objs[idx] = source[i];
    		result.addAll(permutation(source, objs, idx+1, n-1));
    		f[i] = true;
    	}
    	return result;
    }
    
    private static double probability(ArrayList<Object[]> result, Map<Object, Integer> source, double d){
    	double tp = 0;
    	Map<Object, Integer> map = new HashMap<Object, Integer>();
    	Set<Object> keys = source.keySet();
    	for(Object[] objArr:result){
    		for(Object obj:objArr){
    			System.out.print(obj + "  ");
    		}
    		System.out.println();
    		
    		for(Object key:keys){
    			map.put(key, 0);
    		}
    		double dd = d;
    		double p = 1;
    		for(Object obj:objArr){
    			System.out.print((int)dd + "  ");
    			p *= 1/dd;
    			int times = map.get(obj)+1;
    			if(times == source.get(obj))
    				dd--;
    			map.put(obj, times);
    		}
    		System.out.println();
    		//System.out.println("****"+p);
    		tp += p;
    	}
    	return tp;
    }
    
    private static ArrayList<Object[]> removeDuplicate(ArrayList<Object[]> list)   {
    	ArrayList<Object[]> result = new ArrayList<Object[]>();
    	result.add(list.get(0));
    	boolean flag;
    	for(Object[] obj1:list){
    		flag = true;
    		for(Object[] obj2:result){
    			if(compare(obj1, obj2)){
    				flag = false;
    				break;
    			}
    		}
    		if(flag)
    			result.add(obj1);
    	}
    	
    	return result;
    }
    
    private static boolean compare(Object[] o1, Object[] o2){
    	if(o1.length != o2.length)
    		return false;
    	for(int i=0;i<o1.length;i++){
    		if(!o1[i].equals(o2[i]))
    			return false;
    	}
    	return true;
    }
    
    public static void main(String[] args) {
        /*Scanner sc=new Scanner(System.in);
        int sz=sc.nextInt();
        for(int i=0;i<sz;i++){
            int sum=sc.nextInt();
            f=new boolean[sum];
            Arrays.fill(f, true);
            int[] num=new int[sum];
            for(int j=0;j<sum;j++){
                num[j]=j+1;
            }
            int nn=sc.nextInt();
            String str="";
            count(num,str,nn);
        }*/
/*    	int[] num = {1, 2, 3, 4};
    	String str = "";
    	int nn = 3;
    	f=new boolean[num.length];
    	Arrays.fill(f, true);
    	count(num, str, nn);*/
    	
/*    	char[] source = {'a', 'a', 'b', 'c'};
    	int n = 3;
    	char[] chars = new char[n];

    	f=new boolean[source.length];
    	Arrays.fill(f, true);
    	
    	count(source, chars, 0, n);*/
    	
    	Object[] source = {'a', 'a', 'a', 'b', 'b', 'b', 'c', 'c'};
    	Map<Object, Integer> sMap = new HashMap<Object, Integer>();
    	sMap.put('a', 3);
    	sMap.put('b', 3);
    	sMap.put('c', 2);
    	int n = 8;
    	Object[] objs = new Object[n];
    	f = new boolean[source.length];
    	Arrays.fill(f, true);
    	ArrayList<Object[]> result = permutation(source, objs, 0, n);
    	result = removeDuplicate(result);

/*    	
    	for(int i=0;i<result.size();i++){
    		for(int j=0;j<n;j++){
    			System.out.print(result.get(i)[j] + "  ");
    		}
    		System.out.println();
    	}
    	System.out.println("****************************************");
*/    	
    	System.out.println(probability(result, sMap, 4));
    	
    	
    }
    
    
}