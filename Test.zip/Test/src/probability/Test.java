package probability;

public class Test {

	private String[] array = {"a", "a", "b", "b"};
	
	public void	printAllArray(String[] array){
		
	}
	
	public long factorial(int num){
		if(num == 1)
			return 1;
		return num * factorial(num-1);
	}
	
	public long permutation(int m, int n){
		return factorial(m) / factorial(m-n);
	}
	
	public long combination(int m, int n){
		return factorial(m) / factorial(m-n) / factorial(n);
	}
	
	
	public long permutation2(int m, int n){
		long result = 1;
		for(int i=m;i>m-n;i--){
			result *= i;
		}
		return result;
	}
	
	public long combination2(int m, int n){
		if(n > m-n)
			n = m-n;
		
		long result = 1;
		for(int i=m;i>m-n;i--){
			result *= i;
		}
		for(int i=2;i<=n;i++){
			result /= i;
		}
		return result;
	}
	
	public static void main(String[] args){
		Test test = new Test();
		//System.out.println(test.factorial(5));
		int m = 20;
		int n = 11;
		
		long startTime=System.currentTimeMillis();
		System.out.println(test.permutation(m, n));
		long endTime=System.currentTimeMillis();
		System.out.println("Run Time： "+(endTime-startTime)+"ms");
		
		startTime=System.currentTimeMillis();
		System.out.println(test.permutation2(m, n));
		endTime=System.currentTimeMillis();
		System.out.println("Run Time： "+(endTime-startTime)+"ms");
		
		
		System.out.println(test.combination(10, 2));
		System.out.println(test.combination2(10, 2));
		
		//m n index  
		
	}
	
}
