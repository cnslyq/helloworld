package ClassLoader;

public class ClassLoaderTest {

	public static void main(String[] args) {

        Class c;
        ClassLoader cl;
        cl = ClassLoader.getSystemClassLoader();

        System.out.println(cl);
        while (cl != null) {
            cl = cl.getParent();
            System.out.println(cl);
        }

        try {
            c = Class.forName("java.lang.Object");
            cl = c.getClassLoader();
            System.out.println("java.lang.Object's loader is " + cl);
            c = Class.forName("ClassLoader.ClassLoaderTest");
            cl = c.getClassLoader();
            System.out.println("ClassLoaderTest's loader is " + cl);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
