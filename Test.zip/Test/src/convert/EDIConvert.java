package convert;

/**
 * Convert EDI Data files into XML
 * @author brian_liu01
 */
public class EDIConvert extends CommonConvert{

	public EDIConvert(){
		setXsdPath(Constant.EDI_XSD_PATH);
		setDataFromPath(Constant.EDI_DATA_FROM_PATH);
		setXmlToPath(Constant.EDI_XML_TO_PATH);
		setRootElement(Constant.EDI_ROOT_ELEMENT);
		setSegId(Constant.EDI_SEG_ID);
	}
	
	public static void main(String[] args){
		long startTime=System.currentTimeMillis();
		
		EDIConvert c = new EDIConvert();
		c.Convert();
		
		long endTime=System.currentTimeMillis();
		System.out.println("Run Time： "+(endTime-startTime)+"ms");
	}
	
}
