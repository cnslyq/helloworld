package convert;

import java.util.List;

/**
 * '<xs:complexType>' tag in XSD file
 * @author brian_liu01
 */
public class ComplexTypeObj {
	private String name;
	private String typeFlag;
	private List<ElementObj> elementList;
	
	public ComplexTypeObj(){}
	public ComplexTypeObj(String name, String typeFlag, List<ElementObj> elementList){
		this.name = name;
		this.typeFlag = typeFlag;
		this.elementList = elementList;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTypeFlag() {
		return typeFlag;
	}
	public void setTypeFlag(String typeFlag) {
		this.typeFlag = typeFlag;
	}
	public List<ElementObj> getElementList() {
		return elementList;
	}
	public void setElementList(List<ElementObj> elementList) {
		this.elementList = elementList;
	}
	
}
