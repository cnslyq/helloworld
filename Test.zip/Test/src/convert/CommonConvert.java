package convert;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Convert Data File into XML
 * @author brian_liu01
 */
public class CommonConvert {

	private String xsdPath;
	private String dataFromPath;
	private String xmlToPath;
	private String rootElement;
	private String segId;
	private String segIdValue;
	private int startIndex;
	private int endIndex;
	private Map<String, ElementObj> elementMap = new HashMap<String, ElementObj>();
	private Map<String, ComplexTypeObj> complexTypeMap = new HashMap<String, ComplexTypeObj>();
	private Map<String, SimpleTypeObj> simpleTypeMap = new HashMap<String, SimpleTypeObj>();
	
	/**
	 * Main Method
	 */
	public void Convert(){
		try{
			parseXSD();
			//printElementMap();
			//printComplexTypeMap();
			convertData2XML();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Parse XSD file
	 * @throws Exception
	 */
	private void parseXSD() throws Exception {
		//create XSD document
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
        Document xsdDoc = db.parse(xsdPath);
        //get root node
        Node root = xsdDoc.getFirstChild();
        //parse root node
        parseNode(root);
	}
	
	/**
	 * Parse a node of XSD
	 * @param node
	 * @throws Exception
	 */
	private void parseNode(Node node) throws Exception{
		//iterate child node
		if(node.hasChildNodes()){
			NodeList nodeList = node.getChildNodes();
			int length = nodeList.getLength();
			for(int i=0;i<length;i++){
				parseNode(nodeList.item(i));
			}
		}
		
		String nodeName = node.getNodeName();
		//NodeName: xs:element
		if(Constant.XS_ELEMENT.equals(nodeName)){
			String name = getAttribute(node, Constant.NAME);
			String type = getAttribute(node, Constant.TYPE);
			elementMap.put(name, new ElementObj(name, type));
			
		//NodeName: xs:complexType
		}else if(Constant.XS_COMPLEX_TYPE.equals(nodeName)){
			String name = getAttribute(node, Constant.NAME);
			String typeFlag = node.getFirstChild().getNextSibling().getNodeName();
			NodeList nodeList = node.getFirstChild().getNextSibling().getChildNodes();
			List<ElementObj> elementList = new ArrayList<ElementObj>();
			int length = nodeList.getLength();
			for(int i=0;i<length;i++){
				Node childNode = nodeList.item(i);
				if(childNode.getNodeType() != Node.ELEMENT_NODE){
					continue;
				}
				elementList.add(elementMap.get(getAttribute(childNode, Constant.NAME)));
			}
			complexTypeMap.put(name, new ComplexTypeObj(name, typeFlag, elementList));
			
		//NodeName: xs:simpleType
		}else if(Constant.XS_SIMPLE_TYPE.equals(nodeName)){
			String name = getAttribute(node, Constant.NAME);
			Node restrictionNode = node.getFirstChild().getNextSibling();
			String base = getAttribute(restrictionNode, Constant.BASE);
			int length = 0;
			
			//BaseType: xs:string
			if(Constant.XS_STRING.equals(base)){
				length = Integer.parseInt(getAttribute(restrictionNode.getFirstChild().getNextSibling(), 
								Constant.VALUE));
				
			//BaseType: xs:decimal
			}else if(Constant.XS_DECIMAL.equals(base)){
				length = Integer.parseInt(getAttribute(restrictionNode.getFirstChild().getNextSibling(), 
								Constant.VALUE)) + 1;
				
			//BaseType: xs:int
			}else if (Constant.XS_INT.equals(base)){
				length = Integer.parseInt(getAttribute(restrictionNode.getFirstChild().getNextSibling(), 
								Constant.VALUE));
			}
			simpleTypeMap.put(name, new SimpleTypeObj(name, base, length));
		}
		
	}
	
	/**
	 * Get attribute value
	 * @param node
	 * @param attrName
	 * @return
	 */
	private String getAttribute(Node node, String attrName){
		NamedNodeMap attributes = node.getAttributes();
		Node attribute = attributes.getNamedItem(attrName);
		return null == attribute ? null : attribute.getNodeValue();
	}
	
	/**
	 * Main Convert Logic Method
	 * Convert data files into XML files
	 * @throws Exception
	 */
	private void convertData2XML() throws Exception {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		//get data file list
		File files = new File(dataFromPath);
		File[] listFile = files.listFiles();
		
		//iterate data file list
		for(File file:listFile){
			//create xml Document
			Document xmlDoc = db.newDocument();
			//create root node
			Node root = xmlDoc.createElement(rootElement + "-ROOT");
			//append root node
			xmlDoc.appendChild(root);
			//read data file
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String data = null;
			while((data = br.readLine())!=null){
				//skip the first line
				if(data.startsWith("###"))
					continue;
				//initialize variables
				startIndex = 0;
				endIndex = 0;
				segIdValue = "";
				//convert a line into xml
				convertLine(data, xmlDoc, root, rootElement);
			}
			//generate xml file
			writeXMLFile(xmlDoc, xmlToPath + File.separator + file.getName().split("\\.")[0] + ".xml");
		}
	}
	
	/**
	 * Convert a line of data file into XML
	 * @param data
	 * @param xmlDoc
	 * @param parent
	 * @param nodeName
	 */
	private void convertLine(String data, Document xmlDoc, Node parent, String nodeName){
		//create node
		Node node = xmlDoc.createElement(nodeName);
		//append node
		parent.appendChild(node);
		//get node type
		String nodeType = elementMap.get(nodeName).getType();
		
		//XSD tag: xs:complexType
		if(null != complexTypeMap.get(nodeType)){
			//get complexType object
			ComplexTypeObj obj = complexTypeMap.get(nodeType);
			String typeFlag = obj.getTypeFlag();
			
			//XSD tag: xs:sequence
			if(Constant.XS_SEQUENCE.equals(typeFlag)){
				//get element object list
				List<ElementObj> list = obj.getElementList();
				//iterate element object list
				for(ElementObj ele:list){
					convertLine(data, xmlDoc, node, ele.getName());
				}
				
			//XSD tag: xs:choice
			}else if(Constant.XS_CHOICE.equals(typeFlag)){
				//get element object list
				List<ElementObj> list = obj.getElementList();
				//iterate element object list
				for(ElementObj ele:list){
					if(segIdValue.equals(ele.getType())){
						convertLine(data, xmlDoc, node, ele.getName());
						break;
					}
				}
			}
			
		//XSD tag: xs:simpleType
		}else if(null != simpleTypeMap.get(nodeType)){
			//get simpleType object
			SimpleTypeObj obj = simpleTypeMap.get(nodeType);
			int length = obj.getLength();
			//get text value
			endIndex = startIndex + length;
			String value = data.substring(startIndex, endIndex).trim();
			startIndex = endIndex;
			//set SEG-ID
			if("".equals(segIdValue) && segId.equals(node.getNodeName())){
				segIdValue = value;
			}
			//append text value
			node.appendChild(xmlDoc.createTextNode(value)); 
		}
		
	}
	
	/**
	 * Generate XML file
	 * @param xmlDoc
	 * @param fileName
	 * @throws Exception
	 */
	private void writeXMLFile(Document xmlDoc, String fileName) throws Exception {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
        DOMSource source = new DOMSource(xmlDoc);
        //transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        //transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        PrintWriter pw = new PrintWriter(new FileOutputStream(fileName));
        StreamResult result = new StreamResult(pw);
        transformer.transform(source, result);
	}
	
	/**
	 * print node list, only for test
	 * @param list
	 */
	public void printNodeList(NodeList list){
		int length=list.getLength();
		System.out.println(length);
		for(int i=0;i<length;i++){
			Node node = list.item(i);
			if(node.getNodeType() != Node.ELEMENT_NODE){
				continue;
			}
			System.out.println(node.getNodeName());
			NamedNodeMap attributes = node.getAttributes();
			for(int j=0;j<attributes.getLength();j++){
				Node attribute = attributes.item(j);
				System.out.println("Attribute: " + attribute.getNodeName() + "=" + attribute.getNodeValue());
			}
		}
	}

	/**
	 * print element map, only for test
	 */
	public void printElementMap(){
		int size = elementMap.size();
		System.out.println(size);
		Set<String> keys = elementMap.keySet();
		for(String key:keys){
			ElementObj obj = elementMap.get(key);
			System.out.println(obj.getName() + ":" + obj.getType());
		}
	}

	/**
	 * print complex type map, only for test
	 */
	public void printComplexTypeMap(){
		int size = complexTypeMap.size();
		System.out.println(size);
		Set<String> keys = complexTypeMap.keySet();
		for(String key:keys){
			ComplexTypeObj obj = complexTypeMap.get(key);
			System.out.println(obj.getName() + ":" + obj.getTypeFlag());
		}
	}

	
	public void setXsdPath(String xsdPath) {
		this.xsdPath = xsdPath;
	}

	public void setDataFromPath(String dataFromPath) {
		this.dataFromPath = dataFromPath;
	}

	public void setXmlToPath(String xmlToPath) {
		this.xmlToPath = xmlToPath;
	}
	
	public void setRootElement(String rootElement) {
		this.rootElement = rootElement;
	}
	
	public void setSegId(String segId){
		this.segId = segId;
	}

	public String getXsdPath() {
		return xsdPath;
	}

	public String getDataFromPath() {
		return dataFromPath;
	}

	public String getXmlToPath() {
		return xmlToPath;
	}

	public String getRootElement() {
		return rootElement;
	}

	public String getSegId() {
		return segId;
	}
	
}
