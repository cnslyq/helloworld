package convert;

/**
 * '<xs:simpleType>' tag in XSD file
 * @author brian_liu01
 */
public class SimpleTypeObj {
	private String name;
	private String base;
	private int length;
	
	public SimpleTypeObj(){}
	public SimpleTypeObj(String name, String base, int length){
		this.name = name;
		this.base = base;
		this.length = length;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBase() {
		return base;
	}
	public void setBase(String base) {
		this.base = base;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	
}
