package convert;

import com.apl.davinci.services.base.EbizException;
import com.apl.davinci.services.util.ReadIni;
import com.apl.davinci.services.util.UtilsFactory;

public class Constant {
	public static String NAME = "name";
	public static String TYPE = "type";
	public static String BASE = "base";
	public static String VALUE = "value";
	public static String MAX_OCCURS = "maxOccurs";
	public static String MIN_OCCURS = "minOccurs";
	public static String XS_ELEMENT = "xs:element";
	public static String XS_COMPLEX_TYPE = "xs:complexType";
	public static String XS_SIMPLE_TYPE = "xs:simpleType";
	public static String XS_SEQUENCE = "xs:sequence";
	public static String XS_CHOICE = "xs:choice";
	public static String XS_STRING = "xs:string";
	public static String XS_DECIMAL = "xs:decimal";
	public static String XS_INT = "xs:int";
	
	public static String EDI_XSD_PATH;
	public static String EDI_DATA_FROM_PATH;
	public static String EDI_XML_TO_PATH;
	public static String EDI_ROOT_ELEMENT;
	public static String EDI_SEG_ID;
	
	private static ReadIni props;
	
	static{
		try{
			props = UtilsFactory.createIni("XSDConvert.properties");
		} catch (EbizException e) {
			e.printStackTrace();
		}
		EDI_XSD_PATH = props.getProperty("EDI_XSD_PATH");
		EDI_DATA_FROM_PATH = props.getProperty("EDI_DATA_FROM_PATH");
		EDI_XML_TO_PATH = props.getProperty("EDI_XML_TO_PATH");
		EDI_ROOT_ELEMENT = props.getProperty("EDI_ROOT_ELEMENT");
		EDI_SEG_ID = props.getProperty("EDI_SEG_ID");
		
	}
}
