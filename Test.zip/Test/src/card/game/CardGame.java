package card.game;

import java.util.List;

import card.CardBox;
import card.Player;

public interface CardGame {
	public void init(List<Player> players);
	public void dealCard(Player player);
	public void removeCards(Player player, List<Integer> list);
	public Player getWinner(List<Player> players);
	public CardBox getBox();
}
