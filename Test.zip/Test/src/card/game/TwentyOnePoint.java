package card.game;

import java.util.ArrayList;
import java.util.List;

import card.CardBox;
import card.Player;

public class TwentyOnePoint implements CardGame {
	
	private CardBox box;
	
	public void init(List<Player> players){
		if(box == null)
			initBox();
		initPlayers(players);
	}
	
	private void initBox(){
		box = new CardBox();
		List<Integer> cards = new ArrayList<Integer>();
		for(int i=1;i<=52;i++){
			cards.add(i);
		}
		box.setCards(cards);
		box.shuffle();
	}
	
	private void initPlayers(List<Player> players){
		for(Player player:players){
			List<Integer> cards = new ArrayList<Integer>();
			box.dealCard(cards, 2);
			player.setHandCards(cards);
			player.setScore(calcScore(cards));
		}
	}
	
	public void dealCard(Player player){
		List<Integer> cards = player.getHandCards();
		if(cards.size() >= 5){
			System.out.println("You have 5 cards!!");
			return;
		}
		if(player.getScore() == 0){
			System.out.println("You out!!");
			return;
		}
		box.dealCard(cards);
		player.setHandCards(cards);
		player.setScore(calcScore(cards));
	}

	public int calcScore(List<Integer> cards){
		int point = 0;
		for(Integer card:cards){
			point += calcCardPoint(card);
		}
		if(point > 21){
			point = checkAce(cards, point, 1);
		}
		return point;
	}
	
	private int calcCardPoint(int card){
		int point = card % 13;
		if(point == 0 || point > 10){
			point = 10;
		}
		if(point == 1){
			point = 11;
		}
		return point;
	}
	
	private int checkAce(List<Integer> cards, int point, int count){
		int temp = 1;
		for(Integer card:cards){
			if(1 == card % 13){
				if(temp == count){
					point -= 10;
					if(point > 21){
						return checkAce(cards, point, ++count);
					}
					return point;
				}
				temp++;
			}
		}
		return 0;
	}
	
	public Player getWinner(List<Player> players){
		int score = 0;
		Player player = null;
		for(Player p:players){
			if(p.getScore() > score){
				score = p.getScore();
				player = p;
			}
		}
		return player;
	}

	public void removeCards(Player player, List<Integer> list) {}
	
	public CardBox getBox(){
		return box;
	}
}
