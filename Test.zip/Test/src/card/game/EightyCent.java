package card.game;

import java.util.ArrayList;
import java.util.List;

import card.CardBox;
import card.Player;

public class EightyCent implements CardGame {

	private CardBox box;
	
	public void init(List<Player> players) {
		if(box == null)
			initBox();
		initPlayers(players);
	}
	
	private void initBox(){
		box = new CardBox();
		List<Integer> cards = new ArrayList<Integer>();
		for(int i=1;i<=54;i++){
			cards.add(i);
			cards.add(i);
		}
		box.setCards(cards);
		box.shuffle();
	}
	
	private void initPlayers(List<Player> players){
		
	}

	public void dealCard(Player player) {

	}

	public void removeCards(Player player, List<Integer> cards) {

	}

	public Player getWinner(List<Player> players) {
		return null;
	}

	public CardBox getBox() {
		return box;
	}

}
