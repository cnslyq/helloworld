package card;

import java.util.List;

public class CardUtil {
	
	private static String[] cardNoArray = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
	private static String[] cardTypeArray = {"♠", "♥", "♣", "♦"};
	
	public static String getCard(int card){
		if(!checkCard(card)){
			System.out.println("Error Card!");
			return null;
		}
		return getCardType(card) + getCardNo(card);
	}
	
	public static String getCardType(int card){
		if(!checkCard(card)){
			System.out.println("Error Card!");
			return null;
		}
		if(card == 53 || card == 54)
			return "";
		return cardTypeArray[(card-1)/13];
	}

	public static String getCardNo(int card){
		if(!checkCard(card)){
			System.out.println("Error Card!");
			return null;
		}
		if(card == 53)
			return "SJ";
		if(card == 54)
			return "BJ";
		return cardNoArray[(card-1)%13];
	}
	
	private static boolean checkCard(int card){
		if(card > 0 && card <= 54)
			return true;
		return false;
	}
	
	public static void printCards(List<Integer> list){
		for(Integer i:list){
			System.out.print(getCard(i) + "  ");
		}
		System.out.println();
	}
}
