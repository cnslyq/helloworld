package card;

import java.util.List;

public class Player {

	private String name;
	private List<Integer> handCards;
	private int score;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Integer> getHandCards() {
		return handCards;
	}
	public void setHandCards(List<Integer> handCards) {
		this.handCards = handCards;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
}
