package card;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CardBox {

	private List<Integer> cards;
	private int index = 0;
	
	public void dealCard(List<Integer> handCards, int num){
		for(int i=0;i<num;i++){
			if(index >= cards.size()){
				shuffle();
			}
			handCards.add(cards.get(index++));
		}
	}
	
	public void dealCard(List<Integer> handCards){
		dealCard(handCards, 1);
	}
	
	public void removeCards(List<Integer> handCards, List<Integer> list){
		handCards.removeAll(list);
	}
	
	public void shuffle(){
		index = 0;
		Collections.shuffle(cards);
	}
	
	public List<Integer> getCards(){
		return cards;
	}
	
	public void setCards(List<Integer> cards){
		this.cards = cards;
	}
	
	
	public static void main(String[] args){
		CardBox box = new CardBox();
		List<Integer> cards = new ArrayList<Integer>();
		for(int i=1;i<=52;i++){
			cards.add(i);
		}
		box.setCards(cards);
		//card.printCards(card.getCards());
		List<Integer> list = new ArrayList<Integer>();
		for(int i=1;i<50;i++){
			list.add(i);
		}
		box.removeCards(box.getCards(), list);
		CardUtil.printCards(box.getCards());
		box.shuffle();
		CardUtil.printCards(box.getCards());
		
	}
	
}
