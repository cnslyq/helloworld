package card;

import java.util.List;

import card.game.CardGame;
import card.game.TwentyOnePoint;

public class Table {

	private List<Player> players;
	private CardGame game;
	
	public Table(){}
	public Table(List<Player> players, CardGame game){
		this.players = players;
		this.game = game;
	}
	
	public void gameBegin(){
		game.init(players);
	}
	
	public void gameOver(){
		Player winner = game.getWinner(players);
		System.out.println("Winner : " + winner.getName());
	}
	
	public void shuffle(){
		game.getBox().shuffle();
	}
	
	public List<Player> getPlayers() {
		return players;
	}
	public void setPlayers(List<Player> players) {
		this.players = players;
	}
	public CardGame getGame() {
		return game;
	}
	public void setGame(CardGame game) {
		this.game = game;
	}
	
	
	public static void main(String[] args){
		/*
		Player p1 = new Player();
		p1.setName("p1");
		Player p2 = new Player();
		p2.setName("p2");
		List<Player> players = new java.util.ArrayList<Player>();
		players.add(p1);
		players.add(p2);
		CardGame game = new TwentyOnePoint();
		Table table = new Table(players, game);
		for(int i=0;i<10;i++){
			table.gameBegin();
			game.dealCard(p1);
			game.dealCard(p1);
			table.gameOver();
			System.out.println("Score : " + p1.getScore());
			CardUtil.printCards(p1.getHandCards());
			System.out.println("Score : " + p2.getScore());
			CardUtil.printCards(p2.getHandCards());
			System.out.println("***********************************");
		}
		 */		

		List<Integer> cards = new java.util.ArrayList<Integer>();
		cards.add(1);
		cards.add(10);
		cards.add(9);
		
		TwentyOnePoint game = new TwentyOnePoint();
		CardUtil.printCards(cards);
		System.out.println(game.calcScore(cards));
		
		
	}
	
}
